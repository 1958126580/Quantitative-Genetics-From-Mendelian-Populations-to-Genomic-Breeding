#!/usr/bin/env python3
"""习题 11.19  双生子设计：ACE 与 ADE 模型的最大似然拟合及其不可识别性

同卵（MZ）与异卵（DZ）双生子对的协方差：
    Cov_MZ = A + D + C，Cov_DZ = A/2 + D/4 + C，Var = A + D + C + E
只有三个可识别的二阶矩（Var、Cov_MZ、Cov_DZ），因此 A、C、D、E 四个组分不能同时估计：
ACE 与 ADE 只能二选一（C 与 D 的方向相反地影响 Cov_DZ/Cov_MZ 比值）。
程序：真实模型含 A、D、C、E 四项，模拟 300 组资料，分别拟合 ACE 与 ADE（二元正态 ML，非负约束），
比较估计偏差，并显示“真实 C 与 D 同时存在时，两模型都给出有偏的 A”。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent


def nll(params, S_mz, S_dz, n_mz, n_dz, model):
    a, x, e = np.exp(params)          # x = C 或 D
    if model == "ACE": cm, cd = a + x, a / 2 + x
    else: cm, cd = a + x, a / 2 + x / 4
    v = a + x + e
    tot = 0.0
    for S, c, n in ((S_mz, cm, n_mz), (S_dz, cd, n_dz)):
        Sig = np.array([[v, c], [c, v]]); det = np.linalg.det(Sig)
        if det <= 0: return 1e10
        tot += 0.5 * n * (np.log(det) + np.trace(np.linalg.solve(Sig, S)))
    return tot


def fit(S_mz, S_dz, n_mz, n_dz, model):
    best = None
    for x0 in ([0.4, 0.1, 0.4], [0.2, 0.3, 0.4], [0.6, 0.01, 0.3]):
        r = minimize(nll, np.log(x0), args=(S_mz, S_dz, n_mz, n_dz, model), method="Nelder-Mead", options={"xatol": 1e-8, "fatol": 1e-10, "maxiter": 4000})
        if best is None or r.fun < best.fun: best = r
    return np.exp(best.x), best.fun


def main():
    cfg = json.loads((HERE / "data" / "ex11_19_twins.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); T = cfg["true"]; A, D, C, E = T["A"], T["D"], T["C"], T["E"]
    V = A + D + C + E; cov_mz = A + D + C; cov_dz = A / 2 + D / 4 + C
    Smz = np.array([[V, cov_mz], [cov_mz, V]]); Sdz = np.array([[V, cov_dz], [cov_dz, V]])
    print(f"真值 A={A}, D={D}, C={C}, E={E}；r_MZ = {cov_mz/V:.3f}，r_DZ = {cov_dz/V:.3f}；Falconer h² = 2(r_MZ − r_DZ) = {2*(cov_mz-cov_dz)/V:.3f}")
    res = {"ACE": [], "ADE": []}
    for _ in range(cfg["reps"]):
        y_mz = rng.multivariate_normal([0, 0], Smz, cfg["n_mz_pairs"]); y_dz = rng.multivariate_normal([0, 0], Sdz, cfg["n_dz_pairs"])
        S1 = y_mz.T @ y_mz / len(y_mz); S2 = y_dz.T @ y_dz / len(y_dz)
        for m in ("ACE", "ADE"):
            est, _ = fit(S1, S2, len(y_mz), len(y_dz), m); res[m].append(est)
    out = {}
    for m in ("ACE", "ADE"):
        e = np.array(res[m]); mean = e.mean(0); tot = e.sum(1, keepdims=True)
        sh = (e / tot).mean(0)
        out[m] = {"mean_components": mean.tolist(), "mean_shares": sh.tolist()}
        lab = ("A", "C", "E") if m == "ACE" else ("A", "D", "E")
        print(f"{m}：" + "，".join(f"{l} 比例 {s:.3f}" for l, s in zip(lab, sh)))
    print(f"真实比例：A {A/V:.3f}，D {D/V:.3f}，C {C/V:.3f}，E {E/V:.3f}（广义遗传 {(A+D)/V:.3f}）")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex11_19_twin_models.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
