# 第11章　亲属间的相似性与遗传协方差——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex11_15_gene_dropping.py
python3 ex11_16_relative_covariance.py
python3 ex11_17_realized_relationship.py
python3 ex11_18_family_means.py
python3 ex11_19_twin_models.py
python3 ex11_20_maternal_covariance.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex11_15_gene_dropping.py | 11.15 | 基因下落模拟与表格法：亲缘系数、IBD 状态概率 (k0, k1, k2) 与显性关系 |
| ex11_16_relative_covariance.py | 11.16 | 亲属间遗传协方差的 Cockerham 系数：Cov = Σ r^m u^n V_{A^m D^n} |
| ex11_17_realized_relationship.py | 11.17 | 期望关系与实际关系：全同胞与半同胞基因组共享比例的离散度 |
| ex11_18_family_means.py | 11.18 | 家系均值的方差、组内相关与“有效独立记录数” |
| ex11_19_twin_models.py | 11.19 | 双生子设计：ACE 与 ADE 模型的最大似然拟合及其不可识别性 |
| ex11_20_maternal_covariance.py | 11.20 | 直接—母体效应模型下的亲属协方差（Willham 1963） |
