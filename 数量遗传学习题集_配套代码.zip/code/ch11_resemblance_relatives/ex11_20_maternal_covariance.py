#!/usr/bin/env python3
"""习题 11.20  直接—母体效应模型下的亲属协方差（Willham 1963）

个体表型 y = A_o(自身直接) + A_m(母亲的母体遗传) + PE_m(母亲的母体永久环境) + E。
设直接、母体加性方差 σ_o²、σ_m²，协方差 σ_om。两个体 i、j 的协方差
    Cov = r_ij σ_o² + r_{m(i)m(j)} σ_m² + (r_{i,m(j)} + r_{m(i),j}) σ_om + [同一母亲] σ_PE²
其中 m(i) 为 i 的母亲。程序用一个小系谱（祖代—母亲—后代）的加性关系矩阵自动计算各类亲属的协方差，
并检查 (σ_o², σ_om, σ_m²) 是否构成合法协方差矩阵；最后比较“母系半同胞 − 父系半同胞”差值的组成。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
# 系谱：0 祖母(母系)，1 外祖父, 2 母亲 = 1×0, 3 父亲A, 4 父亲B(另一公畜), 5 母亲2(无关)
# 后代：6 = 3×2, 7 = 3×2 (全同胞), 8 = 4×2 (母系半同胞 of 6), 9 = 3×5 (父系半同胞 of 6)
PED = [(-1, -1), (-1, -1), (1, 0), (-1, -1), (-1, -1), (-1, -1), (3, 2), (3, 2), (4, 2), (3, 5)]


def A_matrix(ped):
    n = len(ped); A = np.zeros((n, n))
    for i, (s, d) in enumerate(ped):
        for j in range(i):
            A[i, j] = A[j, i] = 0.5 * ((A[j, s] if s >= 0 else 0) + (A[j, d] if d >= 0 else 0))
        A[i, i] = 1 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0)
    return A


def main():
    cfg = json.loads((HERE / "data" / "ex11_20_maternal.json").read_text(encoding="utf-8"))
    so, sm, som, spe, se = cfg["VAo"], cfg["VAm"], cfg["CovAoAm"], cfg["VPE_m"], cfg["VE"]
    G = np.array([[so, som], [som, sm]]); ev = np.linalg.eigvalsh(G)
    print(f"G = [[{so}, {som}], [{som}, {sm}]]，特征值 {np.round(ev,4)}，直接—母体相关 {som/np.sqrt(so*sm):.3f}")
    assert ev.min() >= 0
    A = A_matrix(PED); mother = {i: d for i, (s, d) in enumerate(PED)}
    def cov(i, j):
        mi, mj = mother[i], mother[j]
        c = A[i, j] * so
        if mi >= 0 and mj >= 0: c += A[mi, mj] * sm
        if mj >= 0: c += A[i, mj] * som
        if mi >= 0: c += A[mi, j] * som
        if mi >= 0 and mi == mj: c += spe
        return c
    # 表型方差：个体 i 与自身（非近交、母亲非近交）：σo² + σm² + 2·(1/2)σom + σPE² + σE²
    VP = so + sm + som + spe + se
    pairs = {"全同胞": (6, 7), "母系半同胞": (6, 8), "父系半同胞": (6, 9), "母—子": (2, 6), "父—子": (3, 6), "祖母—孙(母系)": (0, 6)}
    out = {"VP": VP, "pairs": {}}
    print(f"表型方差 V_P = {VP:.4f}")
    for k, (i, j) in pairs.items():
        c = cov(i, j); out["pairs"][k] = {"cov": c, "corr": c / VP}
        print(f"  {k:<10s} 协方差 {c:.4f}，相关 {c/VP:.4f}")
    diff = out["pairs"]["母系半同胞"]["cov"] - out["pairs"]["父系半同胞"]["cov"]
    print(f"母系半同胞 − 父系半同胞 = {diff:.4f} = σ_m² + σ_om + σ_PE² = {sm+som+spe:.4f}")
    assert np.isclose(diff, sm + som + spe)
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex11_20_maternal_covariance.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
