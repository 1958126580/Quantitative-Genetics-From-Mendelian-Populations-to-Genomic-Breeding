#!/usr/bin/env python3
"""习题 11.17  期望关系与实际关系：全同胞与半同胞基因组共享比例的离散度

系谱只给出期望：全同胞加性关系 1/2、半同胞 1/4。实际共享比例因有限次重组而波动（Visscher 等 2006）。
用 Haldane 无干涉交换（泊松）在每条染色体上模拟父母向两个后代的传递，计算
    全同胞的实际加性关系 r̂ = (IBD 父源比例 + IBD 母源比例)/2
    半同胞 r̂ = 父源 IBD 比例 / 2
比较不同基因组大小（染色体条数 × 长度）的标准差；理论近似 SD(r̂_FS) ≈ 0.25·sqrt(... ) 与染色体总长成反比的平方根。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def transmit(L, grid, rng):
    """返回长度 L(M) 染色体上各格点所继承的亲本单倍型标签 0/1。"""
    k = rng.poisson(L); pts = np.sort(rng.uniform(0, L, k)); start = rng.integers(0, 2)
    return (start + np.searchsorted(pts, grid)) % 2


def main():
    cfg = json.loads((HERE / "data" / "ex11_17_genome.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); out = {}
    for name, (L,) in cfg["chrom_lengths_M"].items():
        C = cfg["n_chrom"][name]; grid = np.linspace(0, L, int(L * cfg["grid_per_M"]))
        fs, hs = [], []
        for _ in range(cfg["reps"]):
            pat, mat = 0.0, 0.0
            for _ in range(C):
                pat += np.mean(transmit(L, grid, rng) == transmit(L, grid, rng))
                mat += np.mean(transmit(L, grid, rng) == transmit(L, grid, rng))
            pat /= C; mat /= C; fs.append((pat + mat) / 2); hs.append(pat / 2)
        fs, hs = np.array(fs), np.array(hs)
        out[name] = {"total_M": C * L, "FS_mean": float(fs.mean()), "FS_sd": float(fs.std()), "FS_range": [float(fs.min()), float(fs.max())],
                     "HS_mean": float(hs.mean()), "HS_sd": float(hs.std())}
        print(f"{name}：全同胞 r̂ 均值 {fs.mean():.4f}，SD {fs.std():.4f}，范围 [{fs.min():.3f}, {fs.max():.3f}]；半同胞均值 {hs.mean():.4f}，SD {hs.std():.4f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex11_17_realized_relationship.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
