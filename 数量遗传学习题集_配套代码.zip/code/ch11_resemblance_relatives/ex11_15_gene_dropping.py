#!/usr/bin/env python3
"""习题 11.15  基因下落模拟与表格法：亲缘系数、IBD 状态概率 (k0, k1, k2) 与显性关系

系谱（10 头，见数据文件）含全同胞、半同胞、近交个体与复杂交错亲缘。
    (1) 表格法递推加性关系矩阵 A（含近交），亲缘系数 f_xy = A_xy / 2；
    (2) 基因下落：给每个创始者两个唯一标签，按孟德尔规律传递 20 万次，统计
        每对个体共享 0/1/2 个 IBD 标签的概率 k0, k1, k2 以及 f_xy（随机各抽一个拷贝 IBD 的概率）；
    (3) 对非近交个体对，显性关系 u_xy = k2，且 r_xy = k1/2 + k2；核对表格法与模拟一致。
"""
from __future__ import annotations
import csv, json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def tabular_A(ped):
    n = len(ped); A = np.zeros((n, n))
    for i, (s, d) in enumerate(ped):
        for j in range(i):
            A[i, j] = A[j, i] = 0.5 * ((A[j, s] if s >= 0 else 0) + (A[j, d] if d >= 0 else 0))
        A[i, i] = 1 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0)
    return A


def gene_drop(ped, R, rng):
    n = len(ped); G = np.zeros((n, 2, R), np.int32); lab = 0
    for i, (s, d) in enumerate(ped):
        for k, par in enumerate((s, d)):
            if par < 0:
                G[i, k] = lab; lab += 1
            else:
                G[i, k] = G[par, rng.integers(0, 2, R), np.arange(R)]
    return G


def main():
    rows = list(csv.DictReader(open(HERE / "data" / "ex11_15_pedigree.csv", encoding="utf-8")))
    ids = [int(r["id"]) for r in rows]; idx = {v: k for k, v in enumerate(ids)}
    ped = [(idx.get(int(r["sire"]), -1), idx.get(int(r["dam"]), -1)) for r in rows]
    A = tabular_A(ped); rng = np.random.default_rng(1115); R = 200000; G = gene_drop(ped, R, rng)
    F = np.diag(A) - 1
    print("近交系数 F：", {ids[i]: round(float(F[i]), 4) for i in range(len(ids)) if F[i] > 0})
    pairs = [(4, 5), (5, 6), (7, 8), (9, 10), (4, 7), (3, 9), (1, 9)]
    out = {"F": dict(zip(ids, F.tolist())), "pairs": {}}
    print(f"{'个体对':>8s}{'A_xy':>8s}{'f模拟':>8s}{'k0':>7s}{'k1':>7s}{'k2':>7s}{'k1/2+k2':>9s}")
    for a, b in pairs:
        i, j = idx[a], idx[b]
        same = [(G[i, x] == G[j, y]) for x in range(2) for y in range(2)]
        f_sim = float(np.mean([m.mean() for m in same]))
        # 共享 IBD 等位基因数（仅对非近交个体有意义）
        k2 = np.mean((same[0] & same[3]) | (same[1] & same[2]))
        k1 = np.mean((same[0] | same[1] | same[2] | same[3])) - k2; k0 = 1 - k1 - k2
        assert abs(2 * f_sim - A[i, j]) < 0.01, "基因下落与表格法不一致"
        out["pairs"][f"{a}-{b}"] = {"A": A[i, j], "f_sim": f_sim, "k0": float(k0), "k1": float(k1), "k2": float(k2)}
        print(f"{a:>3d}-{b:<4d}{A[i,j]:8.4f}{f_sim:8.4f}{k0:7.3f}{k1:7.3f}{k2:7.3f}{k1/2+k2:9.4f}")
    print("注：个体 9、10 近交，对含近交个体的对，r ≠ k1/2 + k2，需用 Jacquard 九状态描述。")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex11_15_gene_dropping.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
