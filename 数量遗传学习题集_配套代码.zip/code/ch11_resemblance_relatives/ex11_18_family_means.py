#!/usr/bin/env python3
"""习题 11.18  家系均值的方差、组内相关与“有效独立记录数”

n 个成员的家系均值方差  Var(ȳ) = V_P [t + (1 − t)/n]，t 为组内相关（成员间表型协方差 / V_P）。
    半同胞（不同母亲、无共同环境）：t_HS = h²/4
    全同胞（同窝）：t_FS = h²/2 + V_D/(4V_P) + c²
有效独立记录数 n_eff = n / [1 + (n − 1)t]：n 只同胞的均值在估计“家系均值”时只相当于 n_eff 条独立记录。
半同胞均值预测公畜育种值的可靠度：Cov(公畜育种值, 均值) = V_A/2，故
    R = (V_A/2)² / [V_A · Var(ȳ_HS)] = n h² / [4 + (n − 1) h²]。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex11_18_family.json").read_text(encoding="utf-8"))
    VP, h2, c2, vd = cfg["VP"], cfg["h2"], cfg["c2_litter"], cfg["VD_frac"]; VA = h2 * VP
    tHS = h2 / 4; tFS = h2 / 2 + vd / 4 + c2; out = []
    print(f"t_HS = {tHS:.4f}，t_FS = {tFS:.4f}")
    print(f"{'n':>5s}{'Var(HS均值)':>12s}{'n_eff(HS)':>10s}{'公畜可靠度':>10s}{'Var(FS均值)':>12s}{'n_eff(FS)':>10s}")
    for n in cfg["family_sizes"]:
        vhs = VP * (tHS + (1 - tHS) / n); vfs = VP * (tFS + (1 - tFS) / n)
        nhs = n / (1 + (n - 1) * tHS); nfs = n / (1 + (n - 1) * tFS)
        cov = VA / 2                                    # Cov(公畜育种值, 一只后代表型) = V_A/2 ⇒ 与均值相同
        R = cov ** 2 / (VA * vhs)
        out.append({"n": n, "var_HS_mean": vhs, "neff_HS": nhs, "sire_reliability": R, "var_FS_mean": vfs, "neff_FS": nfs})
        print(f"{n:5d}{vhs:12.3f}{nhs:10.2f}{R:10.4f}{vfs:12.3f}{nfs:10.2f}")
    print(f"n → ∞：n_eff(HS) → {1/tHS:.1f}，n_eff(FS) → {1/tFS:.2f}；公畜可靠度 → {(VA/2)**2/(VA*VP*tHS):.3f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex11_18_family_means.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
