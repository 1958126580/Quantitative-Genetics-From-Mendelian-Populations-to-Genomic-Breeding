#!/usr/bin/env python3
"""习题 11.16  亲属间遗传协方差的 Cockerham 系数：Cov = Σ r^m u^n V_{A^m D^n}

非近交亲属对、连锁平衡、无共同环境时（Cockerham 1954；Kempthorne 1954）
    Cov = r V_A + u V_D + r² V_AA + r u V_AD + u² V_DD + …，r = 2f（加性关系），u = k2（显性关系）
程序：(1) 给定方差组分，列出常见亲属对的遗传协方差与各组分贡献；
      (2) 用两个不连锁的加性位点 + 加性×加性互作的双位点模型，模拟亲子、全同胞、半同胞，
          验证 V_AA 的系数分别为 1/4、1/4、1/16。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def cov_coef(r, u):
    return {"VA": r, "VD": u, "VAA": r * r, "VAD": r * u, "VDD": u * u}


def gametes(par, rng):
    """par: (n, 2 位点, 2 拷贝) → 每个位点随机传一个拷贝（不连锁）。"""
    n = par.shape[0]; pick = rng.integers(0, 2, (n, par.shape[1]))
    return np.take_along_axis(par, pick[:, :, None], axis=2)[:, :, 0]


def genval(g, a, aa, p):
    """g: (n, 2 位点, 2 拷贝) 0/1 → 加性 + 加性×加性（中心化剂量乘积）。"""
    x = g.sum(2).astype(float); xc = x - 2 * np.array(p)
    return xc @ np.array(a) + aa * xc[:, 0] * xc[:, 1]


def main():
    cfg = json.loads((HERE / "data" / "ex11_16_components.json").read_text(encoding="utf-8"))
    comps = {k: cfg[k] for k in ("VA", "VD", "VAA", "VAD", "VDD")}; out = {"table": {}}
    print(f"方差组分：{comps}")
    print(f"{'亲属':<10s}{'r':>6s}{'u':>7s}{'协方差':>9s}{'其中上位':>9s}")
    for name, (r, u) in cfg["relatives"].items():
        c = cov_coef(r, u); tot = sum(c[k] * comps[k] for k in comps); epi = sum(c[k] * comps[k] for k in ("VAA", "VAD", "VDD"))
        out["table"][name] = {"r": r, "u": u, "cov": tot, "epistatic_part": epi}
        print(f"{name:<10s}{r:6.3f}{u:7.4f}{tot:9.3f}{epi:9.3f}")
    s = cfg["sim"]; rng = np.random.default_rng(s["seed"]); n = s["n"]; p = s["p"]
    def ind(): return np.stack([rng.binomial(1, p[l], (n, 2)) for l in range(2)], axis=1)
    sire, dam, dam2 = ind(), ind(), ind()
    o1 = np.stack([gametes(sire, rng), gametes(dam, rng)], axis=2)
    o2 = np.stack([gametes(sire, rng), gametes(dam, rng)], axis=2)
    o3 = np.stack([gametes(sire, rng), gametes(dam2, rng)], axis=2)
    gs, g1, g2, g3 = (genval(x, s["a"], s["aa"], p) for x in (sire, o1, o2, o3))
    # 该模型下的方差组分（中心化剂量正交、HWE）：V_A = Σ a²·2pq，V_AA = aa²·(2p1q1)(2p2q2)
    v = [2 * pi * (1 - pi) for pi in p]; VA = sum(ai * ai * vi for ai, vi in zip(s["a"], v)); VAA = s["aa"] ** 2 * v[0] * v[1]
    cov = lambda x, y: float(np.cov(x, y)[0, 1])
    sim = {"亲子": (cov(gs, g1), 0.5 * VA + 0.25 * VAA), "全同胞": (cov(g1, g2), 0.5 * VA + 0.25 * VAA), "半同胞": (cov(g1, g3), 0.25 * VA + VAA / 16)}
    print(f"\n双位点模拟：V_A = {VA:.4f}，V_AA = {VAA:.4f}")
    for k, (a_, b_) in sim.items():
        print(f"  {k}：模拟协方差 {a_:.4f}，理论 {b_:.4f}")
        assert abs(a_ - b_) < 0.01
    out["simulation"] = {k: {"sim": a_, "theory": b_} for k, (a_, b_) in sim.items()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex11_16_relative_covariance.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
