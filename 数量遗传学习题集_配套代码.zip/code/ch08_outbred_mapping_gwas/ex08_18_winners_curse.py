#!/usr/bin/env python3
"""习题 8.18  赢家诅咒：发现—重复设计中的效应高估与条件似然校正

设 2000 个 SNP 的真实标准化效应（以发现样本 z 尺度表示）μ_j ~ N(0, 2²)。
发现样本 z_j ~ N(μ_j, 1)，以 p < 5×10⁻⁸ 选出“显著”位点；重复样本（同等规模）z'_j ~ N(μ_j, 1)。
比较四种效应估计：
    (1) 朴素：发现 z；
    (2) 重复样本 z'（对被选位点无偏，但只用一半资料）；
    (3) 条件最大似然（Ghosh 等 2008；Zhong & Prentice 2008）：
        L(μ) = φ(z − μ) / [Φ(−c − μ) + 1 − Φ(c − μ)]，对每个显著位点数值最大化；
    (4) 经验贝叶斯 Tweedie 公式：E(μ | z) = z + d/dz log f(z)，f 为全部 z 的核密度估计。
评价各估计相对真值 μ 的平均偏差（按发现方向取符号）与均方误差。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm, gaussian_kde
from scipy.optimize import minimize_scalar

HERE = Path(__file__).resolve().parent


def cond_mle(z, c):
    def nll(mu):
        return -(norm.logpdf(z - mu) - np.log(norm.cdf(-c - mu) + norm.sf(c - mu)))
    return minimize_scalar(nll, bounds=(-abs(z) - 5, abs(z) + 5), method="bounded").x


def main():
    cfg = json.loads((HERE / "data" / "ex08_18_winners.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["reps_seed"]); m = cfg["n_snps_true"]
    mu = rng.normal(0, cfg["effect_sd_z"], m); z = mu + rng.standard_normal(m); z2 = mu + rng.standard_normal(m)
    c = norm.isf(cfg["alpha"] / 2); sel = np.abs(z) > c
    kde = gaussian_kde(z, bw_method=0.25); h = 1e-3
    tweedie = z + (np.log(kde(z + h)) - np.log(kde(z - h))) / (2 * h)
    cm = np.array([cond_mle(v, c) for v in z[sel]])
    est = {"朴素发现 z": z[sel], "重复样本 z": z2[sel], "条件 MLE": cm, "Tweedie 经验贝叶斯": tweedie[sel]}
    print(f"显著阈值 |z| > {c:.3f}；显著位点 {sel.sum()} 个；其真实平均 |μ| = {np.mean(np.abs(mu[sel])):.3f}")
    print(f"{'估计':<16s}{'平均偏差':>10s}{'均方误差':>10s}")
    out = {"n_sig": int(sel.sum()), "mean_abs_true_mu": float(np.mean(np.abs(mu[sel])))}
    for k, v in est.items():
        bias = float(np.mean((v - mu[sel]) * np.sign(z[sel]))); mse = float(np.mean((v - mu[sel]) ** 2))
        out[k] = {"bias": bias, "mse": mse}
        print(f"{k:<16s}{bias:10.3f}{mse:10.3f}")
    rep = np.mean(np.sign(z2[sel]) == np.sign(z[sel])); rep_sig = np.mean(np.abs(z2[sel]) > c)
    print(f"重复样本中同向比例 = {rep:.3f}，再次达到全基因组显著的比例 = {rep_sig:.3f}")
    out.update({"replication_same_sign": float(rep), "replication_significant": float(rep_sig)})
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex08_18_winners_curse.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
