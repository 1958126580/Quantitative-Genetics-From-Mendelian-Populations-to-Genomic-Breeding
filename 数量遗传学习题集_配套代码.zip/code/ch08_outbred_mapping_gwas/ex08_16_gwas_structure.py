#!/usr/bin/env python3
"""习题 8.16  群体分层与隐性亲缘下的 GWAS：朴素回归、主成分校正与混合模型

模拟两个亚群（各 300 只，均由 15 头公畜的半同胞家系构成），2000 个 SNP 的频率在亚群间按 F_ST 型扰动；
15 个致因 SNP 合计解释 h² = 0.4，另有两亚群表型均值差 0.5σ（环境/管理差异，与基因无关）。
    (a) 朴素：y ~ SNP；
    (b) PC：y ~ SNP + 前 5 个基因组主成分；
    (c) 混合模型：y = μ + SNP·β + u + e，u ~ N(0, Kσu²)，K 为 VanRaden 关系矩阵；先用 ML 在 δ = σe²/σu² 网格上估计，
        再对每个 SNP 做 GLS（P3D/EMMAX 思路），并加入亚群固定效应。
比较零 SNP 的 λ_GC 与第一类错误率（α = 1e-4），以及致因 SNP 的功效。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    m = cfg["n_snp"]; p0 = rng.uniform(0.1, 0.9, m); sh = cfg["fst_shift"]
    G, sub = [], []
    for s, ns in enumerate(cfg["n_sub"]):
        ps = np.clip(p0 + (1 if s == 0 else -1) * rng.normal(0, sh, m) * np.sqrt(p0 * (1 - p0)) * 2, 0.02, 0.98)
        per = ns // cfg["n_sires_per_sub"]
        for _ in range(cfg["n_sires_per_sub"]):
            sire = rng.binomial(1, ps, (2, m))
            for _ in range(per):
                pat = sire[rng.integers(0, 2, m), np.arange(m)]
                G.append(pat + rng.binomial(1, ps)); sub.append(s)
    return np.array(G, float), np.array(sub)


def assoc_ols(y, X0, G):
    """对每个 SNP 做含协变量 X0 的回归 t 检验（向量化）。"""
    Q, _ = np.linalg.qr(X0); ry = y - Q @ (Q.T @ y); RG = G - Q @ (Q.T @ G)
    b = RG.T @ ry / np.sum(RG ** 2, 0); df = len(y) - X0.shape[1] - 1
    s2 = (ry @ ry - b ** 2 * np.sum(RG ** 2, 0)) / df
    t = b / np.sqrt(s2 / np.sum(RG ** 2, 0)); return 2 * stats.t.sf(np.abs(t), df), t ** 2


def main():
    cfg = json.loads((HERE / "data" / "ex08_16_gwas.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); G, sub = simulate(cfg, rng); n, m = G.shape
    causal = rng.choice(m, cfg["n_causal"], replace=False); beta = np.zeros(m); beta[causal] = rng.normal(0, 1, cfg["n_causal"])
    g = (G - G.mean(0)) @ beta; g *= np.sqrt(cfg["h2"] / g.var())
    y = g + rng.normal(0, np.sqrt(1 - cfg["h2"]), n) + cfg["sub_mean_diff"] * (sub == 0)
    W = G - G.mean(0); K = W @ W.T / np.sum(2 * G.mean(0) / 2 * (1 - G.mean(0) / 2))
    one = np.ones((n, 1)); out = {}
    p_naive, c_naive = assoc_ols(y, one, G)
    U, S, _ = np.linalg.svd(W, full_matrices=False); PCs = U[:, :cfg["n_pc"]]
    p_pc, c_pc = assoc_ols(y, np.hstack([one, PCs]), G)
    # 混合模型：K 的特征分解后旋转，ML 估计 δ
    X0 = np.hstack([one, (sub == 0)[:, None].astype(float)])
    ev, V = np.linalg.eigh(K); ev = np.maximum(ev, 0); yr = V.T @ y; Xr = V.T @ X0
    def negll(logd):
        d = np.exp(logd); w = 1 / (ev + d); b = np.linalg.solve(Xr.T @ (w[:, None] * Xr), Xr.T @ (w * yr))
        r = yr - Xr @ b; s2 = np.sum(w * r * r) / n; return 0.5 * (n * np.log(s2) + np.sum(np.log(ev + d)))
    grid = np.linspace(-4, 4, 161); best = grid[np.argmin([negll(x) for x in grid])]; d = np.exp(best)
    w = 1 / np.sqrt(ev + d)
    p_mm, c_mm = assoc_ols(w * yr, w[:, None] * Xr, w[:, None] * (V.T @ G))
    null = np.setdiff1d(np.arange(m), causal)
    print(f"n = {n}，m = {m}，估计 σe²/σu² = {d:.3f}（h²_SNP ≈ {1/(1+d):.3f}）")
    print(f"{'方法':<14s}{'λ_GC':>8s}{'零SNP拒绝率':>12s}{'致因SNP功效':>12s}")
    for name, p, c in (("朴素回归", p_naive, c_naive), ("PC 校正", p_pc, c_pc), ("混合模型+亚群", p_mm, c_mm)):
        lam = float(np.median(c[null]) / stats.chi2.ppf(0.5, 1))
        t1 = float(np.mean(p[null] < cfg["alpha"])); pw = float(np.mean(p[causal] < cfg["alpha"]))
        out[name] = {"lambda_gc": lam, "type1": t1, "power": pw}
        print(f"{name:<14s}{lam:8.3f}{t1:12.4f}{pw:12.3f}")
    out["delta"] = d
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex08_16_gwas_structure.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
