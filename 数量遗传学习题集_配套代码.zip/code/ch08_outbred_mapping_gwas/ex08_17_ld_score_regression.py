#!/usr/bin/env python3
"""习题 8.17  LD 分数回归：区分多基因信号与群体分层混杂

构造 10000 个 SNP（400 个块 × 25，块内 AR(1) 相关 ρ 在块间取 0.2/0.5/0.8/0.95 以产生不同 LD 分数），
LD 分数 ℓ_j = Σ_k r²_jk。在无穷小模型下（Bulik-Sullivan 等 2015）
    E(χ²_j) = 1 + N a + N h² ℓ_j / M，
其中 N a 为分层/隐性亲缘造成的均匀膨胀。模拟 z ~ N(√N R b, R)，b_k ~ N(0, h²/M)，再加与 LD 无关的混杂方差 N a（z 加上独立的 √(N a)·N(0,1) 项）。
回归 χ² ~ ℓ：截距估计 1 + N a，斜率 × M/N 估计 h²。比较两种情景下 λ_GC 与 LDSC 截距的差异。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent


def ar1(k, rho):
    i = np.arange(k); return rho ** np.abs(i[:, None] - i[None, :])


def main():
    cfg = json.loads((HERE / "data" / "ex08_17_ldsc.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); B, k, N, h2 = cfg["n_blocks"], cfg["block_size"], cfg["N"], cfg["h2"]; M = B * k
    rhos = [cfg["rho_values"][b % len(cfg["rho_values"])] for b in range(B)]
    Rs = [ar1(k, r) for r in rhos]; Ls = [np.linalg.cholesky(R) for R in Rs]
    ell = np.concatenate([np.sum(R ** 2, 1) for R in Rs])
    out = {}
    for Na in cfg["confounding_Na"]:
        a = Na / N
        ints, h2s, lams = [], [], []
        for _ in range(cfg["reps"]):
            z = []
            for R, L in zip(Rs, Ls):
                b = rng.normal(0, np.sqrt(h2 / M), k)
                z.append(np.sqrt(N) * R @ b + L @ rng.standard_normal(k))
            z = np.concatenate(z)
            # 混杂：与 LD 分数无关的额外方差 N·a（分层/隐性亲缘的一阶近似）
            z = z + np.sqrt(N * a) * rng.standard_normal(M)
            chi = z ** 2
            X = np.column_stack([np.ones(M), ell]); w = 1 / (1 + N * h2 * ell / M) ** 2 / ell   # 近似 LDSC 权重
            beta = np.linalg.lstsq(X * np.sqrt(w)[:, None], chi * np.sqrt(w), rcond=None)[0]
            ints.append(beta[0]); h2s.append(beta[1] * M / N); lams.append(np.median(chi) / stats.chi2.ppf(0.5, 1))
        key = f"Na={Na}"
        out[key] = {"intercept": float(np.mean(ints)), "intercept_sd": float(np.std(ints)), "h2_hat": float(np.mean(h2s)),
                    "h2_sd": float(np.std(h2s)), "lambda_gc": float(np.mean(lams)), "mean_chisq": float(np.mean(chi)), "expected_intercept": 1 + N * a}
        print(f"混杂 N·a = {N*a:.2f}：λ_GC = {np.mean(lams):.3f}，平均 χ² = {np.mean(chi):.3f}，"
              f"LDSC 截距 = {np.mean(ints):.3f}±{np.std(ints):.3f}（期望 {1+N*a:.2f}），ĥ² = {np.mean(h2s):.3f}±{np.std(h2s):.3f}（真值 {h2}）")
    print(f"平均 LD 分数 = {ell.mean():.2f}，范围 [{ell.min():.2f}, {ell.max():.2f}]")
    out["mean_ld_score"] = float(ell.mean())
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex08_17_ld_score_regression.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
