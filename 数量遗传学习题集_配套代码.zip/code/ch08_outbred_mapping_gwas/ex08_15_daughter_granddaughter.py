#!/usr/bin/env python3
"""习题 8.15  奶牛女儿设计与孙女儿设计的功效比较（固定分型数目）

杂合公畜 M Q / m q（或相反相位），标记与 QTL 重组率 c，QTL 替代效应 α（以表型标准差为单位）。
    女儿设计：每头杂合祖公畜有 n_d 个女儿，每个女儿有 1 条自身记录并分型。
        家系内标记对比 = (1 − 2c)α/... 每个女儿表型 y = ±α/2(继承的父源 QTL) + 其他。
    孙女儿设计：每头祖公畜有 n_s 个儿子（分型），每个儿子以其 100 个女儿的均值（女儿产量离差 DYD）作表型。
        儿子 DYD 的遗传部分 = 儿子育种值的一半；QTL 对 DYD 的贡献 = ±α/4·2 … 统一以“父源 QTL 等位基因效应”记。
固定分型总数为 1000（女儿设计：1000 个女儿；孙女儿设计：1000 个儿子），各分 10 个祖公畜家系，比较功效。
模型均为家系内标记效应的 F 检验（10 个家系，各自估计对比）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent


def within_family_F(y_by_fam, m_by_fam):
    """家系内标记对比的联合 F 检验：模型 y = 家系 + 家系×标记 + e。"""
    ss_marker, ss_res, df_res, k = 0.0, 0.0, 0, 0
    for y, m in zip(y_by_fam, m_by_fam):
        g1, g0 = y[m == 1], y[m == 0]
        if len(g1) < 2 or len(g0) < 2: continue
        diff = g1.mean() - g0.mean(); ss_marker += diff ** 2 / (1 / len(g1) + 1 / len(g0)); k += 1
        ss_res += np.sum((g1 - g1.mean()) ** 2) + np.sum((g0 - g0.mean()) ** 2); df_res += len(y) - 2
    F = (ss_marker / k) / (ss_res / df_res)
    return F, stats.f.sf(F, k, df_res)


def main():
    cfg = json.loads((HERE / "data" / "ex08_15_designs.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); h2, a, c = cfg["h2"], cfg["qtl_alpha_sd"], cfg["c"]
    F_s, B, nd = cfg["n_sires"], cfg["genotyped_budget"], cfg["daughters_per_son"]; per = B // F_s
    VA = h2; VQ = 2 * 0.5 * 0.5 * a * a        # 群体 p = 0.5 时 QTL 加性方差
    VApoly = VA - VQ
    hits_d = hits_g = 0
    for _ in range(cfg["reps"]):
        Yd, Md, Yg, Mg = [], [], [], []
        for _ in range(F_s):
            # —— 女儿设计 ——
            mk = rng.integers(0, 2, per); qtl = np.where(rng.random(per) < c, 1 - mk, mk)
            phase = rng.integers(0, 2)                      # 家系相位随机
            qa = np.where(qtl == phase, a / 2, -a / 2)      # 父源 QTL 等位基因相对效应（替代效应的一半）
            other = rng.normal(0, np.sqrt(1 - a * a / 4), per)   # 其余变异：母源、其他基因、环境（表型方差标准化为 1）
            Yd.append(qa + other); Md.append(mk)
            # —— 孙女儿设计：儿子 DYD ——
            mk2 = rng.integers(0, 2, per); qtl2 = np.where(rng.random(per) < c, 1 - mk2, mk2)
            qa2 = np.where(qtl2 == phase, a / 2, -a / 2)
            # 家系内儿子育种值中除父源 QTL 外：多基因（母源一半 + 孟德尔抽样）方差 3/4·VApoly，母源 QTL 等位基因方差 α²/4
            son_other = rng.normal(0, np.sqrt(0.75 * VApoly + a * a / 4), per)
            bv = qa2 + son_other
            dyd = bv / 2 + rng.normal(0, np.sqrt((1 - 0.25 * VA) / nd), per)   # 女儿均值：一半育种值 + 平均掉的部分
            Yg.append(dyd); Mg.append(mk2)
        hits_d += within_family_F(Yd, Md)[1] < cfg["alpha"]; hits_g += within_family_F(Yg, Mg)[1] < cfg["alpha"]
    pd, pg = hits_d / cfg["reps"], hits_g / cfg["reps"]
    # 解析对照：家系内标记对比的信号/噪声比
    # 解析对照：家系内单个记录的标准化标记对比 δ = 期望对比 / 残差标准差
    d_d = (1 - 2 * c) * a / np.sqrt(1 - a * a / 4)
    noise_g = np.sqrt((0.75 * VApoly + a * a / 4) / 4 + (1 - 0.25 * VA) / nd)
    d_g = (1 - 2 * c) * (a / 2) / noise_g
    ncp = lambda d: F_s * (per / 4) * d * d      # 每家系对比方差 ≈ 4σ²/n
    pw = lambda d: float(stats.ncf.sf(stats.f.isf(cfg["alpha"], F_s, B - 2 * F_s), F_s, B - 2 * F_s, ncp(d)))
    print(f"每个设计分型 {B} 头（{F_s} 个家系 × {per}），QTL 替代效应 α = {a}σP，c = {c}，女儿均值基于 {nd} 个女儿")
    print(f"模拟功效：女儿设计 {pd:.3f}，孙女儿设计 {pg:.3f}（α = {cfg['alpha']}）")
    print(f"标准化对比 δ：女儿 {d_d:.3f}，孙女儿 {d_g:.3f}（比值 {d_g/d_d:.2f}）；非中心 F 解析功效：{pw(d_d):.3f} / {pw(d_g):.3f}")
    out = {"power_daughter": pd, "power_granddaughter": pg, "delta_daughter": float(d_d), "delta_granddaughter": float(d_g),
           "power_theory": [pw(d_d), pw(d_g)]}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex08_15_daughter_granddaughter.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
