#!/usr/bin/env python3
"""习题 8.20  全同胞对的 Haseman–Elston 回归：基于同祖同源（IBD）共享的连锁检测

全同胞对在 QTL 处共享 IBD 等位基因比例 π_Q ∈ {0, 1/2, 1}（概率 1/4, 1/2, 1/4）。加性 QTL 方差 σ_Q²，
给定 π_Q 时 Cov(y1, y2 | π_Q) = π_Q σ_Q² + σ_s²（σ_s² 为其余共享方差），故
    E[(y1 − y2)² | π_Q] = 2(σ_Q² + σ_e²) − 2σ_Q² π_Q。
在标记处观察 π_M（假定标记完全信息），π_Q 对 π_M 的回归系数为 (1 − 2c)²，于是
    回归斜率 β = −2(1 − 2c)² σ_Q²（Haseman–Elston 1972）。
程序模拟同胞对、用 π_M 回归平方差，检验 β < 0（单侧 α = 0.001），给出功效与斜率估计。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent


def sib_pairs(n, VQ, Vs, Ve, c, rng):
    # 父、母各两条单倍型标签：0/1（父），2/3（母）；QTL 等位基因效应独立 N(0, VQ/2)
    qeff = rng.normal(0, np.sqrt(VQ / 2), (n, 4))
    def transmit():
        pq = rng.integers(0, 2, n); mq = 2 + rng.integers(0, 2, n)
        # 标记与 QTL 之间以概率 c 重组
        pm = np.where(rng.random(n) < c, 1 - pq, pq); mm = np.where(rng.random(n) < c, 5 - mq, mq)
        return pq, mq, pm, mm
    a = transmit(); b = transmit()
    gq1 = qeff[np.arange(n), a[0]] + qeff[np.arange(n), a[1]]; gq2 = qeff[np.arange(n), b[0]] + qeff[np.arange(n), b[1]]
    shared = rng.normal(0, np.sqrt(Vs), n)
    y1 = gq1 + shared + rng.normal(0, np.sqrt(Ve), n); y2 = gq2 + shared + rng.normal(0, np.sqrt(Ve), n)
    pi_m = ((a[2] == b[2]).astype(float) + (a[3] == b[3]).astype(float)) / 2
    return y1, y2, pi_m


def main():
    cfg = json.loads((HERE / "data" / "ex08_20_sibpairs.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); VQ, Vs, Ve = cfg["qtl_var"], cfg["residual_shared"], cfg["residual_unique"]; out = []
    print(f"σ_Q² = {VQ}，共享方差 {Vs}，个体特有方差 {Ve}")
    print(f"{'c':>5s}{'同胞对数':>8s}{'理论斜率':>10s}{'平均估计':>10s}{'功效':>8s}")
    for c in cfg["c_marker_qtl"]:
        for n in cfg["n_pairs_grid"]:
            hits, bs = 0, []
            for _ in range(cfg["reps"]):
                y1, y2, pi = sib_pairs(n, VQ, Vs, Ve, c, rng)
                r = stats.linregress(pi, (y1 - y2) ** 2); bs.append(r.slope)
                t = r.slope / r.stderr; hits += stats.t.cdf(t, n - 2) < cfg["alpha"]
            th = -2 * (1 - 2 * c) ** 2 * VQ
            out.append({"c": c, "n_pairs": n, "slope_theory": th, "slope_mean": float(np.mean(bs)), "power": hits / cfg["reps"]})
            print(f"{c:5.2f}{n:8d}{th:10.3f}{np.mean(bs):10.3f}{hits/cfg['reps']:8.3f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex08_20_haseman_elston.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
