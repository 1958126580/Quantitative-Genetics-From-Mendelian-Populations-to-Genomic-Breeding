# 第8章　远交群体的连锁分析、关联定位与全基因组关联研究——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex08_15_daughter_granddaughter.py
python3 ex08_16_gwas_structure.py
python3 ex08_17_ld_score_regression.py
python3 ex08_18_winners_curse.py
python3 ex08_19_finemapping.py
python3 ex08_20_haseman_elston.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex08_15_daughter_granddaughter.py | 8.15 | 奶牛女儿设计与孙女儿设计的功效比较（固定分型数目） |
| ex08_16_gwas_structure.py | 8.16 | 群体分层与隐性亲缘下的 GWAS：朴素回归、主成分校正与混合模型 |
| ex08_17_ld_score_regression.py | 8.17 | LD 分数回归：区分多基因信号与群体分层混杂 |
| ex08_18_winners_curse.py | 8.18 | 赢家诅咒：发现—重复设计中的效应高估与条件似然校正 |
| ex08_19_finemapping.py | 8.19 | 单致因假定下的统计精细定位：近似贝叶斯因子、后验包含概率与可信集 |
| ex08_20_haseman_elston.py | 8.20 | 全同胞对的 Haseman–Elston 回归：基于同祖同源（IBD）共享的连锁检测 |
