#!/usr/bin/env python3
"""习题 8.19  单致因假定下的统计精细定位：近似贝叶斯因子、后验包含概率与可信集

区域内 12 个 SNP 的 LD 相关矩阵 R 由相邻相关构成的链式结构生成（R_ij = Π 相邻 ρ）。
真实致因为 S4，其标准化效应使期望 z = 6。观测 z ~ N(R_{·,4}·6, R)。
Wakefield (2009) 近似贝叶斯因子（单 SNP，效应先验 N(0, W)，估计方差 V）：
    ABF_j = sqrt(V/(V+W)) · exp( z_j² W / [2(V+W)] )
单致因假定下后验包含概率 PIP_j = ABF_j / Σ_k ABF_k；按 PIP 降序累加至 ≥ 95% 得可信集。
程序重复 2000 次，报告：可信集覆盖真实致因的频率、平均可信集大小，以及“最显著 SNP 即致因”的比例。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def chain_corr(rhos):
    m = len(rhos) + 1; R = np.eye(m)
    for i in range(m):
        for j in range(i + 1, m):
            R[i, j] = R[j, i] = float(np.prod(rhos[i:j]))
    return R


def log_abf(z, V, W):
    return 0.5 * np.log(V / (V + W)) + z * z * W / (2 * (V + W))


def credible_set(pip, level):
    o = np.argsort(-pip); cs = []; tot = 0.0
    for i in o:
        cs.append(int(i)); tot += pip[i]
        if tot >= level: break
    return cs


def main():
    cfg = json.loads((HERE / "data" / "ex08_19_finemap.json").read_text(encoding="utf-8"))
    R = chain_corr(cfg["rho_chain"]); m = R.shape[0]; k = cfg["causal_index_1based"] - 1
    L = np.linalg.cholesky(R + 1e-12 * np.eye(m)); rng = np.random.default_rng(cfg["seed"])
    V, W = cfg["se_V"] ** 2, cfg["prior_sd_W"] ** 2
    mean_z = R[:, k] * cfg["ncp"]
    # 一次示例
    z = mean_z + L @ rng.standard_normal(m)
    la = log_abf(z, V, W); pip = np.exp(la - la.max()); pip /= pip.sum()
    cs = credible_set(pip, cfg["credible"])
    print("期望 z =", np.round(mean_z, 2))
    print("一次示例 z =", np.round(z, 2))
    print("PIP =", np.round(pip, 3))
    print(f"95% 可信集 = {[f'S{i+1}' for i in cs]}（累积 PIP {pip[cs].sum():.3f}）；最显著 SNP = S{int(np.argmax(np.abs(z)))+1}")
    cover, size, top = 0, [], 0
    for _ in range(2000):
        z = mean_z + L @ rng.standard_normal(m)
        la = log_abf(z, V, W); p = np.exp(la - la.max()); p /= p.sum(); c = credible_set(p, cfg["credible"])
        cover += k in c; size.append(len(c)); top += int(np.argmax(np.abs(z))) == k
    print(f"2000 次重复：可信集覆盖率 = {cover/2000:.3f}，平均大小 = {np.mean(size):.2f}，最显著 SNP 恰为致因的比例 = {top/2000:.3f}")
    out = {"R": R.round(4).tolist(), "example_z": z.tolist(), "example_pip": pip.tolist(), "example_cs": [i + 1 for i in cs],
           "coverage": cover / 2000, "mean_cs_size": float(np.mean(size)), "top_is_causal": top / 2000}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex08_19_finemapping.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
