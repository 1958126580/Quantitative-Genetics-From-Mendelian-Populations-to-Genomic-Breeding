# 第32章　基因型×环境、韧性与可持续育种——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex32_15_reaction_norm.py
python3 ex32_16_target_environment.py
python3 ex32_17_resilience_indicators.py
python3 ex32_18_state_space_recovery.py
python3 ex32_19_threshold_heat_stress.py
python3 ex32_20_emission_selection.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex32_15_reaction_norm.py | 32.15 | 连续环境梯度下的反应规范：随机回归、仅主效应模型与跨环境遗传相关 |
| ex32_16_target_environment.py | 32.16 | 目标环境分布决定怎样选择：对环境积分的育种目标、稳健（最大化最差）与选错目标的损失 |
| ex32_17_resilience_indicators.py | 32.17 | 从偏离曲线计算韧性指标：对数方差、一阶自相关与累计损失的遗传力，及测量噪声与记录长度的影响 |
| ex32_18_state_space_recovery.py | 32.18 | 状态空间模型把测量噪声与真实恢复分开：朴素自相关、滞后比值与卡尔曼极大似然 |
| ex32_19_threshold_heat_stress.py | 32.19 | 阈值反应与环境测量：热应激的折线模型、阈值估计、暴露权重与未来热年预测 |
| ex32_20_emission_selection.py | 32.20 | 排放性状的定义改变选择方向：总量、强度（比值）、遗传残差排放与约束指数 |
