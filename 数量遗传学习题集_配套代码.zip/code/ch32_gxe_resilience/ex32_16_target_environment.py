#!/usr/bin/env python3
"""习题 32.16  目标环境分布决定怎样选择：对环境积分的育种目标、稳健（最大化最差）与选错目标的损失

沿用习题 32.15 的反应规范 g_i(x)=a_i+b_i x。目标环境 x ~ N(μ_T, s_T²)，则对环境积分后的育种目标
    H_T = E_x[g(x)] = a + μ_T b，（可再加风险厌恶项 −κ·sd_x(g)，sd_x=|b|·s_T）。
对每头公畜（女儿均匀分布于梯度，BLUP 得 (â, b̂)），比较四种选择规则（取前 select_frac）：
  S1 只用 â（忽略 G×E）；  S2 â+μ_T b̂（对目标分布积分）；  S3 maximin：max_i min_{x∈[−2,2]} (â+b̂x)；
  S4 对"错误的目标"（μ=−1 时按 μ=+1 选择）。
指标：被选公畜在目标分布下的真实平均 E_x[g] 的选择差（相对群体均值）、在最差环境（x=−2 与 2 取小）的真实值。
理论：线性指数 I=wᵀ(â,b̂)，目标 H=hᵀ(a,b)，选择差 ΔG = i·wᵀVh/√(wᵀVw)，V=Var(â,b̂)；用样本 V 与蒙特卡罗对照。
断言：S2 在其目标下选择差最大；S4 的损失显著；maximin 的最差环境值高于 S2 且平均值低于 S2；
理论 ΔG 与蒙特卡罗相差 <10%。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex32_16_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n, d, ve = cfg["n_sires"], cfg["daughters"], cfg["var_e"]
    sa, sb, rho = np.sqrt(cfg["var_a"]), np.sqrt(cfg["var_b"]), cfg["rho_ab"]
    Sigma = np.array([[sa ** 2, rho * sa * sb], [rho * sa * sb, sb ** 2]]); Si = np.linalg.inv(Sigma)
    ab = rng.multivariate_normal([0, 0], Sigma, n); est = np.empty((n, 2))
    for i in range(n):
        x = rng.uniform(-2, 2, d); X = np.column_stack([np.ones(d), x])
        y = X @ ab[i] + rng.normal(0, np.sqrt(ve), d)
        est[i] = np.linalg.solve(Si + X.T @ X / ve, X.T @ y / ve)
    V = np.cov(est.T); f = cfg["select_frac"]; k = int(f * n); inten = norm.pdf(norm.isf(f)) / f
    lo, hi = cfg["env_range"]; grid = np.linspace(lo, hi, 41)
    true_min = lambda sel: np.mean([np.min(ab[s, 0] + ab[s, 1] * np.array([lo, hi])) for s in sel])
    print(f"V=Var(â,b̂)=[[{V[0,0]:.3f},{V[0,1]:.3f}],[{V[0,1]:.3f},{V[1,1]:.3f}]]；选择强度 i={inten:.3f}（前{f:.0%}）")
    out = {}
    print(f"{'目标 μ_T':>9}{'规则':<14}{'目标下选择差':>14}{'理论ΔG':>9}{'最差环境值':>12}")
    for mu in cfg["target_mu"]:
        h = np.array([1.0, mu]); Htrue = ab @ h; base = Htrue.mean()
        rules = {}
        rules["S1 只用â"] = np.argsort(-est[:, 0])[:k]
        w = np.array([1.0, mu]); rules["S2 对目标积分"] = np.argsort(-(est @ w))[:k]
        rules["S3 maximin"] = np.argsort(-np.minimum(est[:, 0] + est[:, 1] * lo, est[:, 0] + est[:, 1] * hi))[:k]
        wrong = np.array([1.0, -mu if mu != 0 else 1.0]); rules["S4 选错目标"] = np.argsort(-(est @ wrong))[:k]
        wvec = {"S1 只用â": np.array([1.0, 0.0]), "S2 对目标积分": w, "S4 选错目标": wrong}
        for name, sel in rules.items():
            gain = Htrue[sel].mean() - base
            theo = inten * (wvec[name] @ V @ h) / np.sqrt(wvec[name] @ V @ wvec[name]) if name in wvec else float("nan")
            out[f"{mu}|{name}"] = dict(gain=float(gain), theory=float(theo), worst=float(true_min(sel)))
            print(f"{mu:>9.1f}  {name:<14}{gain:>14.3f}{theo:>9.3f}{true_min(sel):>12.3f}")
    for mu in cfg["target_mu"]:
        g = {n_: out[f"{mu}|{n_}"]["gain"] for n_ in ("S1 只用â", "S2 对目标积分", "S3 maximin", "S4 选错目标")}
        assert g["S2 对目标积分"] >= max(g["S1 只用â"], g["S4 选错目标"]) - 0.01
        for nm in ("S1 只用â", "S2 对目标积分", "S4 选错目标"):
            o = out[f"{mu}|{nm}"]
            assert abs(o["gain"] - o["theory"]) < 0.12 * max(abs(o["theory"]), 0.3) + 0.03
    o1 = out["1.0|S2 对目标积分"]; o3 = out["1.0|S3 maximin"]
    assert o3["worst"] > o1["worst"] and o3["gain"] < o1["gain"]
    assert out["1.0|S4 选错目标"]["gain"] < 0.75 * out["1.0|S2 对目标积分"]["gain"]
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex32_16_target_environment.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
