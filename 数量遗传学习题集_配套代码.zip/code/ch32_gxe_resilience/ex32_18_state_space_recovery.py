#!/usr/bin/env python3
"""习题 32.18  状态空间模型把测量噪声与真实恢复分开：朴素自相关、滞后比值与卡尔曼极大似然

模型：s_t = φ s_{t−1} + σ ε_t，r_t = s_t + v_t，v_t ~ N(0, τ²)（τ=0 时无测量噪声）。
三个 φ 估计量（对 n_series 条独立曲线合并）：
  (a) 朴素 ac1 = γ̂(1)/γ̂(0)：被噪声方差稀释，渐近 φ·Var(s)/(Var(s)+τ²)（短序列另有去均值的小样本偏差）；
  (b) 滞后比值 γ̂(2)/γ̂(1)：白噪声只影响 γ(0)，故对 τ 稳健，但方差较大；
  (c) 卡尔曼滤波极大似然：对 (φ, σ², τ²) 联合最大化精确似然（L-BFGS-B，对数参数化）。
恢复半衰期 t½ = ln 0.5 / ln φ。独立核验：卡尔曼似然在 τ=0 时与 AR(1) 条件似然的差只来自首项；
理论渐近 ac1 与模拟相差 <0.04；MLE 的 τ̂² 在 τ 较大时不偏。
断言：噪声下 (a) 明显向下偏；(b)(c) 平均偏差 <0.08（短序列的小样本偏差）；(c) 的标准差小于 (b)。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent


def simulate(rng, phi, sigma, tau, n, T):
    s = rng.normal(0, sigma / np.sqrt(1 - phi ** 2), n); R = np.empty((n, T))
    for t in range(T):
        s = phi * s + sigma * rng.normal(size=n) if t else s
        R[:, t] = s
    return R + (rng.normal(0, tau, R.shape) if tau > 0 else 0)


def kalman_nll(theta, R):
    phi = np.tanh(theta[0]); sig2 = np.exp(theta[1]); tau2 = np.exp(theta[2])
    n, T = R.shape
    m = np.zeros(n); P = np.full(n, sig2 / (1 - phi ** 2))
    nll = 0.0
    for t in range(T):
        S = P + tau2
        e = R[:, t] - m
        nll += 0.5 * np.sum(np.log(2 * np.pi * S) + e ** 2 / S)
        K = P / S
        m = m + K * e; Pf = (1 - K) * P
        m = phi * m; P = phi ** 2 * Pf + sig2
    return nll


def estimate(R):
    n, T = R.shape
    Rc = R - R.mean(1, keepdims=True)
    g = lambda k: np.sum(Rc[:, k:] * Rc[:, :T - k]) / (n * (T - k))
    ac1 = g(1) / g(0); ratio = g(2) / g(1)
    best = None
    for start in ([np.arctanh(0.5), 0.0, -1.0], [np.arctanh(0.8), 0.0, 0.5]):
        r = minimize(kalman_nll, start, args=(R,), method="L-BFGS-B", bounds=[(-3, 3), (-5, 3), (-8, 3)])
        if best is None or r.fun < best.fun:
            best = r
    phi = np.tanh(best.x[0]); return ac1, ratio, phi, np.exp(best.x[1]), np.exp(best.x[2])


def main():
    cfg = json.loads((HERE / "data" / "ex32_18_config.json").read_text(encoding="utf-8"))
    phi0, sig0 = cfg["phi"], cfg["sigma"]; out = {}
    print(f"真值 φ={phi0}，σ={sig0}，恢复半衰期 {np.log(0.5)/np.log(phi0):.2f} 天；{cfg['n_series']} 条曲线，重复 {cfg['reps']} 次")
    print(f"{'τ':>5}{'T':>6}{'ac1':>8}{'理论ac1':>9}{'滞后比':>8}{'sd':>7}{'MLE φ':>8}{'sd':>7}{'MLE τ²':>8}{'真τ²':>7}")
    for tau in cfg["tau_list"]:
        for T in cfg["T_list"]:
            rows = []
            for r in range(cfg["reps"]):
                rng = np.random.default_rng(cfg["seed"] + 13 * r + T)
                R = simulate(rng, phi0, sig0, tau, cfg["n_series"], T)
                rows.append(estimate(R))
            a = np.array(rows)
            vs = sig0 ** 2 / (1 - phi0 ** 2); theo = phi0 * vs / (vs + tau ** 2)
            out[f"{tau}|{T}"] = dict(ac1=float(a[:, 0].mean()), theory_ac1=float(theo), ratio=float(a[:, 1].mean()), ratio_sd=float(a[:, 1].std(ddof=1)),
                                      mle_phi=float(a[:, 2].mean()), mle_sd=float(a[:, 2].std(ddof=1)), mle_tau2=float(a[:, 4].mean()))
            o = out[f"{tau}|{T}"]
            print(f"{tau:>5.1f}{T:>6}{o['ac1']:>8.3f}{theo:>9.3f}{o['ratio']:>8.3f}{o['ratio_sd']:>7.3f}{o['mle_phi']:>8.3f}{o['mle_sd']:>7.3f}{o['mle_tau2']:>8.3f}{tau**2:>7.2f}")
    for key, o in out.items():
        tau = float(key.split("|")[0])
        assert abs(o["ac1"] - o["theory_ac1"]) < 0.04
        assert abs(o["mle_phi"] - phi0) < 0.05 and abs(o["ratio"] - phi0) < 0.08
        if tau >= 0.7:
            assert o["mle_tau2"] > 0.5 * tau ** 2 and abs(o["mle_tau2"] - tau ** 2) < 0.4 * tau ** 2 + 0.1
        if tau >= 1.4 and key.endswith("|150"):
            assert o["ac1"] < phi0 - 0.2
            assert o["mle_sd"] < o["ratio_sd"]
    thalf = {f"{k}": float(np.log(0.5) / np.log(o["mle_phi"])) for k, o in out.items()}
    print("\n由 MLE φ 得到的恢复半衰期（天），真值 %.2f：" % (np.log(0.5) / np.log(phi0)), {k: round(v, 2) for k, v in thalf.items() if k.endswith("|150")})
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex32_18_state_space_recovery.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
