#!/usr/bin/env python3
"""习题 32.17  从偏离曲线计算韧性指标：对数方差、一阶自相关与累计损失的遗传力，及测量噪声与记录长度的影响

数据生成：每个女儿的日偏离（相对个体预期曲线）r_t = s_t + v_t，
  潜在状态  s_t = φ s_{t−1} + σ ε_t（φ：恢复持续性，σ：扰动敏感度；logit φ 与 ln σ 含公畜效应，h²≈0.25），
  冲击      在 shock_day 给状态加一个负向冲击 shock_size（所有个体相同），
  测量噪声  v_t ~ N(0, τ²)。
指标：lnVar = ln Var(稳态段 r)；ac1 = 稳态段 r 的一阶自相关；loss = 冲击后 loss_window 天内偏离相对冲击前均值的累计亏损。
稳态段 = 冲击后 loss_window 天起至记录结束。
公畜半同胞方差分析：σ_s² = (MSB−MSW)/k，h² = 4σ_s²/(σ_s²+σ_w²)。
噪声衰减：ac1_obs ≈ ac1_clean·(1 − τ²/Var(r))（把噪声方差占比从分子中扣除），与模拟对照。
断言：无噪声时三个指标的遗传力为正；lnVar 与 ac1 的 h² 随记录长度 T 增大；
ac1 与公畜真实 φ 的相关随 τ 增大而下降；衰减公式与模拟 ac1 相差 <0.06。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
SIRE_SHARE, IND_SHARE = 0.25, 0.968            # 公畜 / 个体成分占总标准差的比例（h² ≈ 4×0.25² = 0.25）


def simulate(rng, cfg, T, tau):
    n, k = cfg["n_sires"], cfg["daughters"]
    zs = rng.normal(size=(n, 1)); zi = rng.normal(size=(n, k))
    lg = np.log(cfg["phi_mean"] / (1 - cfg["phi_mean"]))
    phi = 1 / (1 + np.exp(-(lg + cfg["sd_logit_phi"] * (SIRE_SHARE * zs + IND_SHARE * zi))))
    phi_sire = 1 / (1 + np.exp(-(lg + cfg["sd_logit_phi"] * SIRE_SHARE * zs[:, 0])))
    zs2 = rng.normal(size=(n, 1)); zi2 = rng.normal(size=(n, k))
    sig = np.exp(cfg["sd_log_sigma"] * (SIRE_SHARE * zs2 + IND_SHARE * zi2))
    s = np.zeros((n, k)); R = np.empty((n, k, T))
    for t in range(T):
        s = phi * s + sig * rng.normal(size=(n, k))
        if t == cfg["shock_day"]:
            s = s + cfg["shock_size"]
        R[:, :, t] = s
    if tau > 0:
        R = R + rng.normal(0, tau, R.shape)
    return R, phi_sire


def indicators(R, cfg):
    a, w = cfg["shock_day"], cfg["loss_window"]
    x = R[:, :, a + w:]
    lnvar = np.log(x.var(axis=2))
    xc = x - x.mean(2, keepdims=True)
    ac1 = (xc[:, :, 1:] * xc[:, :, :-1]).sum(2) / (xc ** 2).sum(2)
    pre = R[:, :, :a].mean(2, keepdims=True)
    loss = -(R[:, :, a:a + w] - pre).sum(2)
    return lnvar, ac1, loss, x.var(axis=2).mean()


def h2_halfsib(M):
    n, k = M.shape
    mb = k * np.sum((M.mean(1) - M.mean()) ** 2) / (n - 1)
    mw = np.sum((M - M.mean(1, keepdims=True)) ** 2) / (n * (k - 1))
    ss = (mb - mw) / k
    return float(4 * ss / (ss + mw))


def main():
    cfg = json.loads((HERE / "data" / "ex32_17_config.json").read_text(encoding="utf-8"))
    out = {}
    print(f"{cfg['n_sires']} 公畜 × {cfg['daughters']} 女儿，重复 {cfg['reps']} 次；冲击 {cfg['shock_size']}（第 {cfg['shock_day']} 天），损失窗口 {cfg['loss_window']} 天")
    print(f"{'T':>5}{'τ':>5}{'h²(lnVar)':>11}{'h²(ac1)':>10}{'h²(loss)':>10}{'r(公畜ac1,φ)':>14}{'ac1均值':>9}{'Var(r)':>8}")
    for T in cfg["T_list"]:
        for tau in cfg["meas_noise_sd"]:
            rows = []
            for r in range(cfg["reps"]):
                rng = np.random.default_rng(cfg["seed"] + 31 * r + int(T))
                R, phi_sire = simulate(rng, cfg, T, tau)
                lv, ac, ls, vr = indicators(R, cfg)
                rows.append((h2_halfsib(lv), h2_halfsib(ac), h2_halfsib(ls), np.corrcoef(ac.mean(1), phi_sire)[0, 1], ac.mean(), vr))
            a = np.mean(rows, axis=0)
            out[f"{T}|{tau}"] = dict(h2_lnvar=float(a[0]), h2_ac1=float(a[1]), h2_loss=float(a[2]), r_ac1_phi=float(a[3]), ac1_mean=float(a[4]), var_r=float(a[5]))
            print(f"{T:>5}{tau:>5.1f}{a[0]:>11.3f}{a[1]:>10.3f}{a[2]:>10.3f}{a[3]:>14.3f}{a[4]:>9.3f}{a[5]:>8.3f}")
    T0 = cfg["T_list"][-1]; clean = out[f"{T0}|0.0"]; chk = {}
    for tau in cfg["meas_noise_sd"][1:]:
        noisy = out[f"{T0}|{tau}"]
        pred = clean["ac1_mean"] * (1 - tau ** 2 / noisy["var_r"])
        chk[tau] = (noisy["ac1_mean"], pred)
        print(f"τ={tau}: 模拟 ac1 {noisy['ac1_mean']:.3f}，衰减公式 ac1_clean·(1−τ²/Var(r)) = {pred:.3f}")
    out["attenuation_check"] = {str(k): v for k, v in chk.items()}
    for T in cfg["T_list"]:
        for key in ("h2_lnvar", "h2_ac1", "h2_loss"):
            assert out[f"{T}|0.0"][key] > 0.02, (T, key)
    for key in ("h2_lnvar", "h2_ac1"):
        assert out[f"{T0}|0.0"][key] > out[f"{cfg['T_list'][0]}|0.0"][key]
    t = cfg["meas_noise_sd"]
    assert out[f"{T0}|{t[0]}"]["r_ac1_phi"] > out[f"{T0}|{t[-1]}"]["r_ac1_phi"]
    assert all(abs(a - b) < 0.06 for a, b in chk.values())
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex32_17_resilience_indicators.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
