#!/usr/bin/env python3
"""习题 32.15  连续环境梯度下的反应规范：随机回归、仅主效应模型与跨环境遗传相关

模型：公畜 i 的女儿 j 在环境 x_ij（标准化环境梯度，如温湿度指数）下的记录
    y_ij = a_i + b_i x_ij + e_ij，(a_i, b_i) ~ N(0, Σ)，Σ=[[σa², ρσaσb],[ρσaσb, σb²]]，e ~ N(0, σe²)。
环境 x 与 x' 间的遗传协方差 σa² + ρσaσb(x+x') + σb² x x'，遗传相关 r_g(x,x') 由此得到（可以小于 1）。
设计 A（平衡）：每头公畜的女儿的环境均匀分布在梯度 [−2,2] 上；
设计 B（集中）：每头公畜的女儿集中在其所在牛场的环境中心附近（中心随机，sd 为 env_sd_within_sire）。
比较三种评定：(M) 仅主效应（只估 a_i，忽略斜率）；(R) 随机回归（已知方差分量的 BLUP，同时估 a_i、b_i）；
评价指标：在各目标环境 x 上，预测值 â_i+b̂_i x 与真值 a_i+b_i x 的相关（准确性），以及前 10% 公畜在极端环境下的重排。
断言：真实 G×E 存在时 R 在极端环境的准确性高于 M；设计 B 的 R 比设计 A 的 R 更差；
遗传相关 r_g(−2,2) 小于 1，并与模拟样本相关一致。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def blup(X_list, y_list, Sigma, ve, main_only):
    out = []
    for X, y in zip(X_list, y_list):
        if main_only:
            Xi = X[:, :1]; Si = Sigma[:1, :1]
        else:
            Xi = X; Si = Sigma
        prec = np.linalg.inv(Si) + Xi.T @ Xi / ve
        est = np.linalg.solve(prec, Xi.T @ y / ve)
        if main_only:
            est = np.array([est[0], 0.0])
        out.append(est)
    return np.array(out)


def main():
    cfg = json.loads((HERE / "data" / "ex32_15_config.json").read_text(encoding="utf-8"))
    sa, sb, rho, ve = np.sqrt(cfg["var_a"]), np.sqrt(cfg["var_b"]), cfg["rho_ab"], cfg["var_e"]
    Sigma = np.array([[sa ** 2, rho * sa * sb], [rho * sa * sb, sb ** 2]])
    pts = cfg["env_points"]
    def cov(x1, x2): return Sigma[0, 0] + Sigma[0, 1] * (x1 + x2) + Sigma[1, 1] * x1 * x2
    rg = lambda x1, x2: cov(x1, x2) / np.sqrt(cov(x1, x1) * cov(x2, x2))
    print(f"Σ=[[{Sigma[0,0]:.2f},{Sigma[0,1]:.3f}],[{Sigma[0,1]:.3f},{Sigma[1,1]:.2f}]]；"
          f"遗传相关 r_g(−2,2)={rg(-2,2):.3f}，r_g(−1,1)={rg(-1,1):.3f}，r_g(0,2)={rg(0,2):.3f}")
    res = {}
    for design in ("A", "B"):
        accs = {m: {x: [] for x in pts} for m in ("M", "R")}
        samp_rg = []
        for r in range(cfg["reps"]):
            rng = np.random.default_rng(cfg["seed"] + r)
            n, d = cfg["n_sires"], cfg["daughters"]
            ab = rng.multivariate_normal([0, 0], Sigma, n)
            Xl, yl = [], []
            for i in range(n):
                if design == "A":
                    x = rng.uniform(-2, 2, d)
                else:
                    x = np.clip(rng.uniform(-1.5, 1.5) + cfg["env_sd_within_sire"] * rng.normal(size=d), -2.5, 2.5)
                X = np.column_stack([np.ones(d), x])
                Xl.append(X); yl.append(X @ ab[i] + rng.normal(0, np.sqrt(ve), d))
            for m, mo in (("M", True), ("R", False)):
                est = blup(Xl, yl, Sigma, ve, mo)
                for x in pts:
                    truth = ab[:, 0] + ab[:, 1] * x; pred = est[:, 0] + est[:, 1] * x
                    accs[m][x].append(np.corrcoef(pred, truth)[0, 1])
            samp_rg.append(np.corrcoef(ab[:, 0] - 2 * ab[:, 1], ab[:, 0] + 2 * ab[:, 1])[0, 1])
        res[design] = {m: {str(x): float(np.mean(v)) for x, v in d.items()} for m, d in accs.items()}
        res[design]["sample_rg"] = float(np.mean(samp_rg))
        print(f"\n设计 {design}（{'女儿均匀分布于全梯度' if design=='A' else '女儿集中在牧场环境附近'}）：环境 x 处的准确性")
        print(f"{'x':>6}" + "".join(f"{x:>8.1f}" for x in pts))
        for m, name in (("M", "仅主效应"), ("R", "随机回归")):
            print(f"{name:<8}" + "".join(f"{res[design][m][str(x)]:>8.3f}" for x in pts))
    print(f"\n模拟样本 r_g(−2,2) 均值 {np.mean(samp_rg):.3f}（理论 {rg(-2,2):.3f}）")
    ext = ["-2.0", "2.0"]
    assert rg(-2, 2) < 0.9
    assert abs(res["B"]["sample_rg"] - rg(-2, 2)) < 0.05
    for e in ext:
        assert res["A"]["R"][e] > res["A"]["M"][e] + 0.03
        assert res["B"]["R"][e] < res["A"]["R"][e]
    assert res["A"]["R"]["0.0"] >= res["A"]["M"]["0.0"] - 0.03
    res["rg"] = {"-2,2": float(rg(-2, 2)), "-1,1": float(rg(-1, 1)), "0,2": float(rg(0, 2))}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex32_15_reaction_norm.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
