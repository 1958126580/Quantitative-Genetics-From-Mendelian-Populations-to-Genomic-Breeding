#!/usr/bin/env python3
"""习题 32.20  排放性状的定义改变选择方向：总量、强度（比值）、遗传残差排放与约束指数

遗传（以相对均值的比例表示）：生产 P 的遗传标准差 sd_P_rel，排放 E 的遗传标准差 sd_E_rel，遗传相关 r_g>0。
选择对象的四种定义（对估计育种值 EBV 作线性指数，取前 select_frac，单位：相对均值的百分比）：
  I1 只选 P（最大化生产）；
  I2 排放强度：线性化的比值 E/P → 指数 J = EBV_E/μ_E − EBV_P/μ_P，选 J 最小；
  I3 遗传残差排放：E_res = E − bP（b=Cov(E,P)/Var(P)，在真值上与 P 遗传不相关），选 EBV 残差最小；
     I3a 直接用 b 套在 EBV 上；I3b 用 EBV 尺度的回归 bR=Cov(EBV_E,EBV_P)/Var(EBV_P)=b·ρ_E/ρ_P（准确性不同时二者不同）；
  I4 约束指数：在 E 的响应为 0 的约束下使 P 响应最大（Kempthorne–Nordskog），指数 w = G⁻¹ 的约束解。
理论：线性指数 w、目标 h 下选择差 ΔG = i·(GRw)/√(wᵀRw)（R 为 EBV 协方差），这里用 MC 与解析并列；
并报告残差排放 EBV 的准确性（差值型性状的准确性低于两个分量）。
断言：I1 使 E 上升；I2 使 P 上升且 E 下降（相对）；I3b 的 P 响应≈0 且 E 下降，I3a 在准确性不等时 P 响应不为零；I4 的 E 响应≈0 而 P 响应小于 I1；
残差 EBV 准确性 < min(P,E 的准确性 的某个界)；MC 与理论相差 <5% 或 <0.05 个百分点。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex32_20_config.json").read_text(encoding="utf-8"))
    sP, sE, rg = cfg["sd_P_rel"], cfg["sd_E_rel"], cfg["rg"]; aP, aE = cfg["acc_P"], cfg["acc_E"]
    G = np.array([[sP ** 2, rg * sP * sE], [rg * sP * sE, sE ** 2]])
    A = np.diag([aP, aE]); Rm = A @ G @ A                      # EBV 协方差（BLUP 性质 Cov(EBV, a)=Var(EBV)）：
    # 严格的 BLUP：Var(EBV_k)=ρ_k² σ_k²；EBV 间的协方差取 ρ_Pρ_E r_g σ_Pσ_E 的近似（相关预测误差忽略）
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n"]; f = cfg["select_frac"]; k = int(f * n); inten = norm.pdf(norm.isf(f)) / f
    ebv = rng.multivariate_normal([0, 0], Rm, n)
    # 真值 a = EBV + 独立误差，误差协方差 G − Rm（须半正定）
    ev = np.linalg.eigvalsh(G - Rm); assert ev.min() > -1e-12
    a = ebv + rng.multivariate_normal([0, 0], G - Rm, n)
    b = G[0, 1] / G[0, 0]                                       # E 对 P 的遗传回归
    mu_P, mu_E = cfg["mean_P_rel"], cfg["mean_E_rel"]
    # 约束指数：maximize P 响应 s.t. E 响应=0。基于 R 的指数 w 的响应向量 ΔG = i·G A... 这里用 Cov(a, EBV)=Rm
    # 响应 = i·Rm w/√(wᵀ Rm w)；令 e_E'Rm w=0 → w ∝ (I − Rm e_E (e_E'Rm e_E)⁻¹ e_E')e_P 的方向：求解
    e_P, e_E = np.array([1.0, 0.0]), np.array([0.0, 1.0])
    Rinv = np.linalg.inv(Rm)
    # 目标 h=e_P，约束 c=e_E：w = R⁻¹[h − Rm c (cᵀ Rm R⁻¹ Rm c)⁻¹... ]，对 EBV 为二维时直接解：w ⟂ 使 Rm[1,:]·w = 0
    w4 = np.array([Rm[1, 1], -Rm[1, 0]])
    if w4 @ Rm @ e_P < 0:
        w4 = -w4
    rules = {
        "I1 只选P": np.array([1.0, 0.0]),
        "I2 排放强度": np.array([1.0 / mu_P, -1.0 / mu_E]),
        "I3a 残差(用b)": np.array([b, -1.0]),                     # −(EBV_E − b·EBV_P)：直接套用遗传回归 b
        "I3b 残差(用bR)": np.array([Rm[0, 1] / Rm[0, 0], -1.0]),   # bR=Cov(EBV_E,EBV_P)/Var(EBV_P)=b·ρ_E/ρ_P：EBV 尺度上的零响应
        "I4 约束指数": w4,
    }
    print(f"G=[[{G[0,0]:.4f},{G[0,1]:.4f}],[{G[0,1]:.4f},{G[1,1]:.4f}]]；遗传相关 {rg}，EBV 准确性 P={aP}、E={aE}；选择强度 i={inten:.3f}（前{f:.0%}）")
    print(f"E 对 P 的遗传回归 b={b:.3f}（P 每增加1%，E 相应增加 {b:.3f}%）")
    print(f"\n{'指数':<12}{'ΔP(%)':>8}{'ΔE(%)':>8}{'理论ΔP':>9}{'理论ΔE':>9}{'强度ΔE−ΔP':>12}")
    out = {}
    for name, w in rules.items():
        idx = np.argsort(-(ebv @ w))[:k]
        dP, dE = 100 * a[idx, 0].mean(), 100 * a[idx, 1].mean()
        th = inten * (Rm @ w) / np.sqrt(w @ Rm @ w) * 100
        out[name] = dict(dP=float(dP), dE=float(dE), th_dP=float(th[0]), th_dE=float(th[1]))
        print(f"{name:<12}{dP:>8.2f}{dE:>8.2f}{th[0]:>9.2f}{th[1]:>9.2f}{dE - dP:>12.2f}")
    # 残差排放 EBV 的准确性
    res_true = a[:, 1] - b * a[:, 0]; res_ebv = ebv[:, 1] - b * ebv[:, 0]
    acc_res = np.corrcoef(res_ebv, res_true)[0, 1]
    acc_P = np.corrcoef(ebv[:, 0], a[:, 0])[0, 1]; acc_E = np.corrcoef(ebv[:, 1], a[:, 1])[0, 1]
    print(f"\nEBV 准确性：P {acc_P:.3f}，E {acc_E:.3f}，遗传残差排放 {acc_res:.3f}；残差遗传 sd = {100*np.sqrt(G[1,1]*(1-rg**2)):.2f}%")
    out["acc"] = dict(P=float(acc_P), E=float(acc_E), res=float(acc_res))
    o1, o2, o3a, o3, o4 = (out[k_] for k_ in rules)
    print(f"EBV 尺度上的回归 bR={Rm[0,1]/Rm[0,0]:.3f}（b={b:.3f}，比值 ρ_E/ρ_P={aE/aP:.3f}）；用 b 的残差指数使 P 仍有 {o3a['dP']:.2f}% 的响应")
    assert o1["dE"] > 0.3
    assert o2["dP"] > 0 and o2["dE"] < o1["dE"] and o2["dE"] - o2["dP"] < 0
    assert abs(o3["dP"]) < 0.05 * abs(o1["dP"]) + 0.05 and o3["dE"] < 0
    assert o3a["dP"] > 0.2 * o1["dP"] and o3a["dE"] < 0              # 直接套用 b 并非零响应
    assert abs(o4["dE"]) < 0.1 and 0 < o4["dP"] < o1["dP"]
    assert acc_res < max(acc_P, acc_E) and acc_res > 0
    for o in out.values():
        if "th_dP" in o:
            assert abs(o["dP"] - o["th_dP"]) < 0.05 * max(abs(o["th_dP"]), 1) + 0.05 and abs(o["dE"] - o["th_dE"]) < 0.05 * max(abs(o["th_dE"]), 1) + 0.05
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex32_20_emission_selection.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
