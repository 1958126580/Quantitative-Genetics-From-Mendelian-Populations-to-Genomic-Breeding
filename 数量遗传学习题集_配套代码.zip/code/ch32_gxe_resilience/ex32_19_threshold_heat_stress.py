#!/usr/bin/env python3
"""习题 32.19  阈值反应与环境测量：热应激的折线模型、阈值估计、暴露权重与未来热年预测

数据：n_cows 头奶牛，同一季节 n_days 个测定日；日温湿度指数 THI_d ~ N(thi_mean, thi_sd²)（群体共享）。
产量偏差 y_id = −β_i·max(0, THI_d − T0) + e_id，β_i = β0 + u_i（耐热性的个体差异，sd_beta），e ~ N(0, var_e)。
记录到的 THI 含测量误差 THI*_d = THI_d + m_d，m ~ N(0, τ_m²)。
分析：
  (1) 对群体平均反应在 T0 网格上做折线回归（profile），取残差平方和最小的阈值 T̂0；
  (2) 个体耐热性 BLUP：x_d = max(0, THI*_d − T)，β̂_i = Σ x̃ y/Σ x̃²，û_i = λ(β̂_i − β̂0)；
      比较三种暴露定义：折线（T̂0）、折线（错误阈值 T=66）、线性（x=THI*−THI 均值）；
  (3) 预测未来热年（THI 整体 +hot_shift）的个体产量损失，评价与真实损失的相关与 RMSE。
断言：τ_m=0 时 T̂0 接近真值；τ_m 增大使 T̂0 略偏低、斜率估计衰减；折线（T̂0）对 β_i 的准确性高于线性暴露；
线性暴露在热年预测上 RMSE 大于折线。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def fit_threshold(y_mean, thi, grid):
    best = (np.inf, None, None)
    for T in grid:
        x = np.maximum(0, thi - T); xc = x - x.mean()
        if np.sum(xc ** 2) < 1e-9:
            continue
        b = np.sum(xc * (y_mean - y_mean.mean())) / np.sum(xc ** 2)
        rss = np.sum((y_mean - y_mean.mean() - b * xc) ** 2)
        if rss < best[0]:
            best = (rss, T, b)
    return best[1], -best[2]


def individual_blup(Y, x, ve, sd_beta):
    xc = x - x.mean(); Yc = Y - Y.mean(1, keepdims=True)
    sxx = np.sum(xc ** 2); b_hat = -(Yc @ xc) / sxx           # 损失系数 β 的 OLS（y = −βx）
    lam = sd_beta ** 2 / (sd_beta ** 2 + ve / sxx)
    return b_hat, lam * (b_hat - b_hat.mean()) + b_hat.mean()


def main():
    cfg = json.loads((HERE / "data" / "ex32_19_config.json").read_text(encoding="utf-8"))
    n, D, ve = cfg["n_cows"], cfg["n_days"], cfg["var_e"]; grid = np.arange(cfg["scan"][0], cfg["scan"][1] + 0.01, 0.5)
    out = {}
    print(f"真值 T0={cfg['T0']}，β0={cfg['beta0']}，sd_β={cfg['sd_beta']}；{n} 头 × {D} 天；热年 THI +{cfg['hot_shift']}")
    print(f"{'τ_m':>5}{'T̂0':>7}{'平均斜率':>9}{'r(β,折线T̂0)':>14}{'r(β,折线T=66)':>15}{'r(β,线性)':>11}{'热年RMSE 折线':>14}{'热年RMSE 线性':>14}")
    for tm in cfg["meas_sd_list"]:
        rows = []
        for r in range(cfg["reps"]):
            rng = np.random.default_rng(cfg["seed"] + r)
            thi = rng.normal(cfg["thi_mean"], cfg["thi_sd"], D); thi_obs = thi + rng.normal(0, tm, D)
            beta = cfg["beta0"] + rng.normal(0, cfg["sd_beta"], n)
            Y = -beta[:, None] * np.maximum(0, thi - cfg["T0"])[None] + rng.normal(0, np.sqrt(ve), (n, D))
            T_hat, slope = fit_threshold(Y.mean(0), thi_obs, grid)
            acc = {}
            for name, x in (("pw", np.maximum(0, thi_obs - T_hat)), ("pw66", np.maximum(0, thi_obs - 66.0)), ("lin", thi_obs - thi_obs.mean())):
                bh, bl = individual_blup(Y, x, ve, cfg["sd_beta"])
                acc[name] = (np.corrcoef(bl, beta)[0, 1], bh, bl, x)
            # 热年：THI 整体 +hot_shift；真实损失用真实 THI 与真实阈值，预测用观测暴露与各模型系数
            thi_h = thi + cfg["hot_shift"]; thi_h_obs = thi_obs + cfg["hot_shift"]
            true_tot = (beta[:, None] * np.maximum(0, thi_h - cfg["T0"])[None]).sum(1)
            res = {}
            for name in ("pw", "lin"):
                bl = acc[name][2]
                xh = np.maximum(0, thi_h_obs - T_hat) if name == "pw" else np.maximum(0, thi_h_obs - thi_obs.mean())
                res[name] = np.sqrt(np.mean(((bl[:, None] * xh[None]).sum(1) - true_tot) ** 2))
            rows.append((T_hat, slope, acc["pw"][0], acc["pw66"][0], acc["lin"][0], res["pw"], res["lin"]))
        a = np.mean(rows, axis=0)
        out[str(tm)] = dict(T_hat=float(a[0]), slope=float(a[1]), r_pw=float(a[2]), r_pw66=float(a[3]), r_lin=float(a[4]), rmse_pw=float(a[5]), rmse_lin=float(a[6]))
        print(f"{tm:>5.1f}{a[0]:>7.1f}{a[1]:>9.3f}{a[2]:>14.3f}{a[3]:>15.3f}{a[4]:>11.3f}{a[5]:>14.1f}{a[6]:>14.1f}")
    o0, o2, o4 = out["0.0"], out["2.0"], out["4.0"]
    assert abs(o0["T_hat"] - cfg["T0"]) <= 1.0
    assert o4["T_hat"] < o0["T_hat"] - 0.3 and o4["slope"] < o0["slope"]
    assert o0["r_pw"] > o0["r_lin"] + 0.03
    assert o0["rmse_pw"] < o0["rmse_lin"]
    assert o0["r_pw"] > o4["r_pw"]
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex32_19_threshold_heat_stress.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
