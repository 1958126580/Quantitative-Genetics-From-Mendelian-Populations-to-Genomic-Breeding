#!/usr/bin/env python3
"""习题 31.19  有测量误差与未测混杂的中介分析：乘积法、可靠性校正与工具变量的识别边界

结构模型（X 为标准化遗传评分，M 为分子中介，Y 为目标性状，U 为 M 与 Y 共有的未测混杂，Z 为独立工具）：
    M  = α X + κ U + s Z + η,            η ~ N(0, v_η)
    Y  = θ M + c X + κ U + d Z + ε,      ε ~ N(0, v_ε)
    M* = M + δ,                          δ ~ N(0, v_δ)      （实际观测的中介含测量误差）
总效应 = c + αθ（X 与 U、Z 独立，故总效应对混杂与测量误差都稳健），间接效应 = αθ，直接效应 = c。
估计量：
    (a) 朴素乘积法   â = M* 对 X 的斜率，b̂ = 在 X 条件下 Y 对 M* 的斜率，间接 = â b̂，直接 = 总效应 − 间接；
    (b) 可靠性校正   b̂ = Cov(M*⊥, Y⊥)/(Var(M*⊥) − v_δ)（⊥ 表示对 X 残差化，v_δ 已知）；
    (c) 两阶段工具变量法（2SLS）：用 Z 工具化 M*，X 作外生协变量；排除限制被违反时 b̂ → θ + d/s。
独立核验：用总体协方差矩阵直接计算每个估计量的概率极限，并要求 40 次重复的均值落在 4 个蒙特卡罗标准误之内。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
NAMES = ["X", "U", "Z", "Mstar", "Y"]


def population_cov(cfg: dict, kappa: float, error: bool, d: float) -> np.ndarray:
    """(X,U,Z,M*,Y) 的总体协方差矩阵，由线性结构方程直接推出。"""
    a, th, c, s = cfg["alpha"], cfg["theta"], cfg["c_direct"], cfg["iv_strength"]
    # 变量 = B e，e = (X,U,Z,η,ε,δ) 相互独立
    vs = np.array([1, 1, 1, cfg["v_eta"], cfg["v_eps"], cfg["v_delta"] if error else 0.0])
    Mrow = np.array([a, kappa, s, 1, 0, 0.0])
    Yrow = th * Mrow + np.array([c, kappa, d, 0, 1, 0.0])
    Msrow = Mrow + np.array([0, 0, 0, 0, 0, 1.0])
    B = np.array([[1, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0], Msrow, Yrow], float)
    return B @ np.diag(vs) @ B.T


def estimators(S: np.ndarray, n: int, v_delta_known: float, d_out: bool = True) -> dict:
    """由（总体或样本）协方差矩阵 S 计算各估计量；样本协方差同样适用。"""
    iX, iZ, iM, iY = 0, 2, 3, 4
    def partial(i, j, k):  # Cov(i,j | X) 的残差协方差
        return S[i, j] - S[i, k] * S[k, j] / S[k, k]
    total = S[iX, iY] / S[iX, iX]
    a_hat = S[iX, iM] / S[iX, iX]
    # 朴素：Y ~ M* + X
    A = S[np.ix_([iM, iX], [iM, iX])]; bvec = S[np.ix_([iM, iX], [iY])].ravel()
    b_naive, c_naive = np.linalg.solve(A, bvec)
    # 可靠性校正：减去已知的误差方差
    vM = partial(iM, iM, iX) - v_delta_known
    b_corr = partial(iM, iY, iX) / vM
    # 2SLS：Z 作为 M* 的工具，X 外生
    b_iv = partial(iZ, iY, iX) / partial(iZ, iM, iX)
    return {"total": total, "a": a_hat, "b_naive": b_naive, "b_corr": b_corr, "b_iv": b_iv,
            "ind_naive": a_hat * b_naive, "ind_corr": a_hat * b_corr, "ind_iv": a_hat * b_iv,
            "dir_naive": c_naive, "dir_iv": total - a_hat * b_iv}


def simulate(cfg: dict, kappa: float, error: bool, d: float, rng: np.random.Generator) -> np.ndarray:
    n = cfg["n"]
    X, U, Z = rng.standard_normal((3, n))
    eta = np.sqrt(cfg["v_eta"]) * rng.standard_normal(n); eps = np.sqrt(cfg["v_eps"]) * rng.standard_normal(n)
    M = cfg["alpha"] * X + kappa * U + cfg["iv_strength"] * Z + eta
    Y = cfg["theta"] * M + cfg["c_direct"] * X + kappa * U + d * Z + eps
    Ms = M + (np.sqrt(cfg["v_delta"]) * rng.standard_normal(n) if error else 0.0)
    return np.cov(np.vstack([X, U, Z, Ms, Y]))


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex31_19_mediation.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n"]
    true_ind = cfg["alpha"] * cfg["theta"]; true_dir = cfg["c_direct"]; true_tot = true_ind + true_dir
    print(f"习题 31.19  有误差、有混杂的中介分析（n = {n}，重复 {cfg['replicates']} 次；"
          f"真值：间接 {true_ind:.3f}，直接 {true_dir:.3f}，总 {true_tot:.3f}，b = θ = {cfg['theta']}）")
    rows = []
    hdr = f"{'κ':>4s}{'中介误差':>8s}{'排除限制':>8s}{'总效应':>8s}{'间接(朴素)':>11s}{'间接(校正)':>11s}{'间接(2SLS)':>11s}{'直接(朴素)':>11s}{'直接(2SLS)':>11s}{'b(2SLS)理论':>12s}"
    print(hdr)
    for kappa in cfg["kappa_values"]:
        for error in (False, True):
            for d in (0.0, cfg["iv_direct"]):
                reps = [estimators(simulate(cfg, kappa, error, d, rng), n, cfg["v_delta"] if error else 0.0)
                        for _ in range(cfg["replicates"])]
                mean = {k: float(np.mean([r[k] for r in reps])) for k in reps[0]}
                sd = {k: float(np.std([r[k] for r in reps], ddof=1)) for k in reps[0]}
                lim = estimators(population_cov(cfg, kappa, error, d), n, cfg["v_delta"] if error else 0.0)
                # 独立核验：均值与概率极限一致（4 个 MC 标准误 + 小容差）
                for k in mean:
                    tol = 4 * sd[k] / np.sqrt(cfg["replicates"]) + 2e-3
                    assert abs(mean[k] - lim[k]) < tol, (kappa, error, d, k, mean[k], lim[k])
                # 解析式核验：总效应恒为 c + αθ；2SLS 的 b 极限 = θ + d/s
                assert abs(lim["total"] - true_tot) < 1e-10
                assert abs(lim["b_iv"] - (cfg["theta"] + d / cfg["iv_strength"])) < 1e-10
                rows.append({"kappa": kappa, "error": error, "iv_direct": d, **{k: mean[k] for k in mean},
                             **{k + "_limit": lim[k] for k in lim}, "b_iv_sd": sd["b_iv"], "ind_naive_sd": sd["ind_naive"]})
                print(f"{kappa:4.1f}{'有' if error else '无':>9s}{'满足' if d == 0 else '违反':>9s}{mean['total']:8.3f}"
                      f"{mean['ind_naive']:11.3f}{mean['ind_corr']:11.3f}{mean['ind_iv']:11.3f}{mean['dir_naive']:11.3f}{mean['dir_iv']:11.3f}{lim['b_iv']:12.3f}")
    # 可靠性：M* 对 X 残差化后的可靠程度
    lam = cfg["v_eta"] / (cfg["v_eta"] + cfg["v_delta"] + 0.0)
    s2 = cfg["iv_strength"] ** 2
    lam_full = (cfg["v_eta"] + s2) / (cfg["v_eta"] + s2 + cfg["v_delta"])
    print(f"\n条件于 X 的中介可靠程度 λ = (v_η + s²)/(v_η + s² + v_δ) = {lam_full:.4f}（无混杂时 b 的衰减因子）")
    r0 = [r for r in rows if r["kappa"] == 0.0 and r["error"] and r["iv_direct"] == 0.0][0]
    assert abs(r0["b_naive"] - cfg["theta"] * lam_full) < 0.01
    print(f"核验：κ=0、有误差时朴素 b = {r0['b_naive']:.4f}，θλ = {cfg['theta'] * lam_full:.4f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex31_19_mediation.json").write_text(
        json.dumps({"truth": {"indirect": true_ind, "direct": true_dir, "total": true_tot}, "lambda": lam_full, "rows": rows},
                   ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
