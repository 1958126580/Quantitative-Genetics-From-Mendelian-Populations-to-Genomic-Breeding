# 第31章　多组学、功能先验与因果推断——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex31_15_conditional_info.py
python3 ex31_16_mr_pleiotropy.py
python3 ex31_17_twas.py
python3 ex31_18_bayesrc.py
python3 ex31_19_mediation.py
python3 ex31_20_multikernel.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex31_15_conditional_info.py | 31.15 | 组学辅助记录的条件遗传信息：舒尔补增量、表型相关的误导与技术重复的边际收益 |
| ex31_16_mr_pleiotropy.py | 31.16 | 两样本孟德尔随机化：IVW、MR-Egger、加权中位数在不同多效性情景下的偏差与覆盖率 |
| ex31_17_twas.py | 31.17 | 转录组关联研究（TWAS）：表达权重训练、汇总统计 z 值与“连锁的直接作用”造成的假介导 |
| ex31_18_bayesrc.py | 31.18 | 功能先验的 BayesR 与 BayesRC：注释类别各自的混合比例如何改变收缩与预测 |
| ex31_19_mediation.py | 31.19 | 有测量误差与未测混杂的中介分析：乘积法、可靠性校正与工具变量的识别边界 |
| ex31_20_multikernel.py | 31.20 | 多核 REML：基因组核 G 与组学核 O 的方差分解何时可识别 |
