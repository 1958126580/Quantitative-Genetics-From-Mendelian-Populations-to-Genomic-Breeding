#!/usr/bin/env python3
"""习题 31.20  多核 REML：基因组核 G 与组学核 O 的方差分解何时可识别

模型：y = μ1 + u + v + p + e，
    u ~ N(0, σ_g² G)，v ~ N(0, σ_o² O)，p ~ N(0, σ_p² Z_pen Z_penᵀ)（栏舍），e ~ N(0, σ_e² I)。
G = ZZᵀ/m（标准化 SNP），O = FFᵀ/q（标准化组学特征）。特征 = √s·遗传部分 + √(1−s)·(栏舍 + 噪声)，
s 为“组学特征的遗传份额”：s 大时 O 近似 G 的复制品，二者方差难以拆分；s 小时 O 携带独立信息。
限制性似然 ℓ(σ) = −½[log|V| + log|1ᵀV⁻¹1| + yᵀPy]，P = V⁻¹ − V⁻¹1(1ᵀV⁻¹1)⁻¹1ᵀV⁻¹，
解析梯度 ∂ℓ/∂σ_k² = −½[tr(P K_k) − yᵀP K_k P y]，信息矩阵 I_kl = ½ tr(P K_k P K_l)，用 L-BFGS-B 最大化。
独立核验：(1) 解析梯度与差分梯度一致；(2) 当 O ≡ G 时，限制性对数似然沿 σ_g²+σ_o² 固定的直线完全不变，
信息矩阵奇异；(3) 估计的总遗传方差 σ_g²+σ_o² 在两种情景中都比分量本身稳定。
预测：训练 70% 公畜的后代，在留出公畜的后代上比较 G 单核与 G+O 双核的 BLUP 预测与真实 u+v 的相关。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent


def reml_parts(y: np.ndarray, kernels: list[np.ndarray], s2: np.ndarray):
    """返回 (-ℓ, 梯度(对 -ℓ), P, 信息矩阵)。kernels 最后一个应为单位阵 I。"""
    n = len(y); V = sum(s * K for s, K in zip(s2, kernels))
    cf = cho_factor(V, lower=True)
    Vi1 = cho_solve(cf, np.ones(n)); Viy = cho_solve(cf, y); d = Vi1.sum()
    Py = Viy - Vi1 * (Vi1 @ y) / d
    logdet = 2 * np.log(np.diag(cf[0])).sum()
    nll = 0.5 * (logdet + np.log(d) + y @ Py)
    Vinv = cho_solve(cf, np.eye(n))
    P = Vinv - np.outer(Vi1, Vi1) / d
    PK = [P @ K for K in kernels]
    grad = np.array([0.5 * (np.trace(pk) - Py @ K @ Py) for pk, K in zip(PK, kernels)])
    info = np.array([[0.5 * np.sum(a * b.T) for b in PK] for a in PK])
    return nll, grad, P, info


def fit(y, kernels, init, max_iter):
    f = lambda s: reml_parts(y, kernels, s)[:2]
    res = minimize(f, init, jac=True, method="L-BFGS-B", bounds=[(1e-6, None)] * len(init),
                   options={"maxiter": max_iter})
    return res.x, -res.fun


def build_data(cfg: dict, share: float, rng: np.random.Generator) -> dict:
    ns, k = cfg["n_sires"], cfg["offspring_per_sire"]; n = ns * k; m, q = cfg["n_snp"], cfg["n_feat"]
    sire = np.repeat(np.arange(ns), k)
    # 公畜与母畜的单倍型 → 后代基因型（半同胞结构）
    p = rng.uniform(0.15, 0.5, m)
    gs = (rng.random((ns, m)) < p).astype(float) + (rng.random((ns, m)) < p)
    gd = (rng.random((n, m)) < p).astype(float)
    gam_s = rng.random((ns, m)) < gs / 2
    Z = gam_s[sire] + gd
    Z = (Z - Z.mean(0)) / Z.std(0)
    pen = rng.integers(0, cfg["n_pens"], n); Zp = np.eye(cfg["n_pens"])[pen]
    A = rng.standard_normal((m, q)) / np.sqrt(m)
    gpart = Z @ A
    env = np.sqrt(cfg["pen_share"]) * (Zp @ rng.standard_normal((cfg["n_pens"], q))) + np.sqrt(1 - cfg["pen_share"]) * rng.standard_normal((n, q))
    F = np.sqrt(share) * gpart + np.sqrt(1 - share) * env
    F = (F - F.mean(0)) / F.std(0)
    G = Z @ Z.T / m; O = F @ F.T / q; Kp = Zp @ Zp.T
    u = Z @ rng.normal(0, cfg["sigma_u"] / np.sqrt(m), m)
    v = F @ rng.normal(0, cfg["sigma_v"] / np.sqrt(q), q)
    pe = Zp @ rng.normal(0, cfg["sigma_pen"], cfg["n_pens"])
    y = 5.0 + u + v + pe + cfg["sigma_e"] * rng.standard_normal(n)
    return {"y": y, "G": G, "O": O, "Kp": Kp, "u": u, "v": v, "sire": sire, "n": n}


def kernel_corr(G: np.ndarray, O: np.ndarray) -> float:
    iu = np.triu_indices_from(G, 1); return float(np.corrcoef(G[iu], O[iu])[0, 1])


def blup_test(y, kernels, s2, tr, te, comps):
    """留出动物的随机效应 BLUP：Σ_k σ_k² K_k[te,tr] V_tr⁻¹ (y_tr − μ̂)，comps 指定包含的核。"""
    V = sum(s * K for s, K in zip(s2, kernels))[np.ix_(tr, tr)]
    cf = cho_factor(V, lower=True); one = np.ones(len(tr))
    mu = (cho_solve(cf, one) @ y[tr]) / (cho_solve(cf, one) @ one)
    w = cho_solve(cf, y[tr] - mu)
    return sum(s2[c] * kernels[c][np.ix_(te, tr)] @ w for c in comps)


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex31_20_multikernel.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    truth = np.array([cfg["sigma_u"] ** 2, cfg["sigma_v"] ** 2, cfg["sigma_pen"] ** 2, cfg["sigma_e"] ** 2])
    print(f"习题 31.20  多核 REML（n = {cfg['n_sires'] * cfg['offspring_per_sire']}，真实 σ_g²,σ_o²,σ_p²,σ_e² = {np.round(truth, 4).tolist()}，重复 {cfg['replicates']} 次）")
    out = {"scenarios": []}
    first = None
    for share in cfg["feat_genetic_share_values"]:
        est, accG, accGO, tot, kc, minev = [], [], [], [], [], []
        for r in range(cfg["replicates"]):
            d = build_data(cfg, share, rng)
            n = d["n"]; I = np.eye(n)
            K4 = [d["G"], d["O"], d["Kp"], I]
            s_hat, _ = fit(d["y"], K4, np.full(4, d["y"].var() / 4), cfg["max_iter"])
            _, _, _, info = reml_parts(d["y"], K4, s_hat)
            ev = np.linalg.eigvalsh(info / np.outer(s_hat, s_hat) ** 0.5 / 1.0)[0]
            est.append(s_hat); tot.append(s_hat[0] + s_hat[1]); kc.append(kernel_corr(d["G"], d["O"]))
            minev.append(np.sqrt(np.linalg.eigvalsh(np.linalg.inv(info)))[-1])
            if first is None:
                first = (d["y"], K4, s_hat)       # 用于梯度核验
                g_num = np.array([(reml_parts(d["y"], K4, s_hat + h * np.eye(4)[i])[0] - reml_parts(d["y"], K4, s_hat - h * np.eye(4)[i])[0]) / (2 * h)
                                  for i in range(4) for h in [1e-6]])
                g_an = reml_parts(d["y"], K4, s_hat)[1]
                assert np.allclose(g_num, g_an, rtol=1e-3, atol=1e-4), (g_num, g_an)
            # 预测：留出公畜
            ntr = int(cfg["train_sire_fraction"] * cfg["n_sires"])
            tr = np.where(d["sire"] < ntr)[0]; te = np.where(d["sire"] >= ntr)[0]
            ytr = d["y"][tr]
            K3 = [d["G"][np.ix_(tr, tr)], d["Kp"][np.ix_(tr, tr)], I[np.ix_(tr, tr)]]
            s3, _ = fit(ytr, K3, np.full(3, ytr.var() / 3), cfg["max_iter"])
            pg = blup_test(d["y"], [d["G"], d["Kp"], I], s3, tr, te, [0])
            s4, _ = fit(ytr, [k[np.ix_(tr, tr)] for k in K4], np.full(4, ytr.var() / 4), cfg["max_iter"])
            pgo = blup_test(d["y"], K4, s4, tr, te, [0, 1])
            tg = (d["u"] + d["v"])[te]
            accG.append(np.corrcoef(pg, tg)[0, 1]); accGO.append(np.corrcoef(pgo, tg)[0, 1])
        est = np.array(est)
        rho_ge = float(np.corrcoef(est[:, 0], est[:, 1])[0, 1])
        sc = {"share": share, "kernel_corr": float(np.mean(kc)), "est_mean": est.mean(0).tolist(), "est_sd": est.std(0, ddof=1).tolist(),
              "total_g_mean": float(np.mean(tot)), "total_g_sd": float(np.std(tot, ddof=1)), "corr_go": rho_ge,
              "acc_G": float(np.mean(accG)), "acc_GO": float(np.mean(accGO)), "se_ratio_max": float(np.mean(minev))}
        out["scenarios"].append(sc)
        print(f"\n组学特征遗传份额 s = {share}：核相关 corr(G,O) = {sc['kernel_corr']:.3f}")
        for nm, t, m_, s_ in zip(["σ_g²", "σ_o²", "σ_p²", "σ_e²"], truth, sc["est_mean"], sc["est_sd"]):
            print(f"   {nm}：真值 {t:.4f}  估计均值 {m_:.4f}  SD {s_:.4f}")
        print(f"   σ_g²+σ_o²：真值 {truth[0] + truth[1]:.4f}  估计均值 {sc['total_g_mean']:.4f}  SD {sc['total_g_sd']:.4f}；corr(σ̂_g²,σ̂_o²) = {rho_ge:.3f}")
        print(f"   留出公畜后代对 u+v 的预测相关：G 单核 {sc['acc_G']:.3f}，G+O 双核 {sc['acc_GO']:.3f}")

    # 核验 (2)：O ≡ G 时似然沿 σ_g²+σ_o² = c 的直线不变
    rng2 = np.random.default_rng(cfg["seed"] + 1)
    d = build_data(cfg, cfg["feat_genetic_share_values"][0], rng2); n = d["n"]
    Kc = [d["G"], d["G"], d["Kp"], np.eye(n)]
    s_hat, ll = fit(d["y"], [d["G"], d["Kp"], np.eye(n)], np.full(3, 0.1), cfg["max_iter"])
    c = s_hat[0]; lls = []
    for w in (0.0, 0.25, 0.5, 0.75, 1.0):
        lls.append(-reml_parts(d["y"], Kc, np.array([c * (1 - w), c * w, s_hat[1], s_hat[2]]))[0])
    spread = max(lls) - min(lls)
    _, _, _, info = reml_parts(d["y"], Kc, np.array([c / 2, c / 2, s_hat[1], s_hat[2]]))
    ev = np.linalg.eigvalsh(info)
    assert spread < 1e-8 and ev[0] / ev[-1] < 1e-10
    print(f"\n核验：O ≡ G 时，沿 σ_g²+σ_o² = {c:.4f} 取 5 个分配比例，限制性对数似然最大差 {spread:.2e}；信息矩阵最小/最大特征值 = {ev[0] / ev[-1]:.2e}")
    out["identical_kernel"] = {"total": float(c), "loglik_spread": float(spread), "eig_ratio": float(ev[0] / ev[-1])}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex31_20_multikernel.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    plt = get_pyplot()
    if plt is not None:
        fig, ax = plt.subplots(1, 2, figsize=(8, 3.4))
        for a, sc in zip(ax, out["scenarios"]):
            a.bar(["σ_g²", "σ_o²", "σ_p²", "σ_e²"], sc["est_mean"], yerr=sc["est_sd"], color="#4c78a8", alpha=.8, label="估计")
            a.scatter(range(4), truth, color="#e45756", zorder=3, label="真值"); a.set_title(f"遗传份额 s = {sc['share']}")
        ax[0].legend(); fig.tight_layout(); fig.savefig(HERE / "results" / "ex31_20_multikernel.png"); plt.close(fig)


if __name__ == "__main__":
    main()
