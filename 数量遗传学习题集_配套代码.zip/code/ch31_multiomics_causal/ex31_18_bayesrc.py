#!/usr/bin/env python3
"""习题 31.18  功能先验的 BayesR 与 BayesRC：注释类别各自的混合比例如何改变收缩与预测

模型：y = μ1 + Xβ + e，X 为标准化基因型，e ~ N(0, σ_e² I)。
BayesR：β_j ~ Σ_k π_k N(0, γ_k σ_g²)，γ = (0, 0.001, 0.01, 0.1)，π ~ Dirichlet。
BayesRC（MacLeod 等, 2016）：SNP 按功能注释分成类别 c，每类有自己的 π_c ~ Dirichlet，
    数据可以让注释类别有更高的非零比例，也可以否定注释（随机注释时两类 π 应相近）。
Gibbs 抽样：对 SNP j 计算 rhs = x_jᵀ r + x_jᵀx_j β_j，k > 0 时 C_k = x_jᵀx_j + σ_e²/(γ_k σ_g²)，
    log p(k) ∝ log π_ck − ½ log(γ_k σ_g² C_k / σ_e²) + rhs² /(2 σ_e² C_k)，β_j | k ~ N(rhs/C_k, σ_e²/C_k)。
σ_g² 固定为 h² Var(y)（教学简化），σ_e² 由逆卡方抽样。
独立核验：Gibbs 中的类别概率公式与“rhs 的边缘正态似然”直接计算一致；π 各行和为 1；
基线为同一 σ_g² 下的岭回归（等价 SNP-BLUP），由线性方程直接求解。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")   # 小矩阵运算单线程更快、结果可复现
import json
import math
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def genotypes(n, p, rho, rng):
    J = len(p); thr = norm.ppf(p); G = np.zeros((n, J))
    for _ in range(2):
        z = np.empty((n, J)); z[:, 0] = rng.standard_normal(n); e = rng.standard_normal((n, J))
        for j in range(1, J):
            z[:, j] = rho * z[:, j - 1] + math.sqrt(1 - rho ** 2) * e[:, j]
        G += z < thr
    return G


def class_logprob(rhs: float, xx: float, se2: float, sg2: float, gam, logpi) -> np.ndarray:
    lp = np.empty(len(gam)); lp[0] = logpi[0]
    for k in range(1, len(gam)):
        C = xx + se2 / (gam[k] * sg2)
        lp[k] = logpi[k] - 0.5 * math.log(gam[k] * sg2 * C / se2) + rhs * rhs / (2 * se2 * C)
    return lp


def check_class_formula(rng) -> None:
    """Gibbs 类别概率 = rhs 的边缘似然 N(0, σ_e² x'x + (x'x)² γσ_g²) × 先验。"""
    xx, se2, sg2, gam = 480.0, 0.6, 0.5, [0.0, 0.001, 0.01, 0.1]
    pi = np.array([0.7, 0.15, 0.1, 0.05])
    for rhs in (0.0, 3.0, 25.0):
        a = class_logprob(rhs, xx, se2, sg2, gam, np.log(pi)); a = np.exp(a - a.max()); a /= a.sum()
        v = [se2 * xx + xx ** 2 * g * sg2 for g in gam]
        b = pi * np.array([norm.pdf(rhs, 0, math.sqrt(x)) for x in v]); b /= b.sum()
        assert np.allclose(a, b, atol=1e-10)


def gibbs(X, y, cls, cfg, sg2, rng):
    n, p = X.shape; gam = cfg["var_classes"]; K = len(gam); nc = int(cls.max()) + 1
    xx = (X ** 2).sum(0); Xt = np.ascontiguousarray(X.T)
    beta = np.zeros(p); mu = float(y.mean()); r = y - mu; se2 = float(np.var(y)) * (1 - cfg["h2"])
    pi = np.tile(np.array([0.95, 0.03, 0.015, 0.005]), (nc, 1))
    keep_b = np.zeros(p); keep_pi = np.zeros((nc, K)); keep_nz = np.zeros(p); nkeep = 0
    for it in range(cfg["n_iter"]):
        r += mu; mu = float(r.mean() + math.sqrt(se2 / n) * rng.standard_normal()); r -= mu
        logpi = np.log(pi); counts = np.zeros((nc, K))
        u = rng.random(p); zz = rng.standard_normal(p)
        for j in range(p):
            xj = Xt[j]; bj = beta[j]
            rhs = float(xj @ r) + xx[j] * bj
            lp = class_logprob(rhs, xx[j], se2, sg2, gam, logpi[cls[j]])
            pr = np.exp(lp - lp.max()); cum = np.cumsum(pr); k = int(np.searchsorted(cum, u[j] * cum[-1]))
            if k == 0:
                bnew = 0.0
            else:
                C = xx[j] + se2 / (gam[k] * sg2); bnew = rhs / C + math.sqrt(se2 / C) * zz[j]
            if bnew != bj:
                r -= xj * (bnew - bj); beta[j] = bnew
            counts[cls[j], k] += 1
        for c in range(nc):
            pi[c] = rng.dirichlet(counts[c] + np.array(cfg["dirichlet_prior"]))
        se2 = float(r @ r / rng.chisquare(n))
        if it >= cfg["burn_in"]:
            keep_b += beta; keep_pi += pi; keep_nz += beta != 0; nkeep += 1
    assert np.allclose((keep_pi / nkeep).sum(1), 1.0)
    return keep_b / nkeep, keep_pi / nkeep, keep_nz / nkeep, mu


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex31_18_bayesrc.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    check_class_formula(rng)
    p = cfg["n_snp"]; maf = rng.uniform(0.05, 0.5, p)
    n = cfg["n_train"] + cfg["n_test"]
    G = genotypes(n, maf, cfg["ld_rho"], rng)
    keep = G.std(0) > 0; G = G[:, keep]; p = G.shape[1]
    X = (G - G.mean(0)) / G.std(0)
    annot = np.zeros(p, int); annot[rng.choice(p, int(cfg["frac_annot"] * p), replace=False)] = 1
    ia, iu = np.flatnonzero(annot == 1), np.flatnonzero(annot == 0)
    causal = np.r_[rng.choice(ia, cfg["causal_in_annot"], replace=False), rng.choice(iu, cfg["n_causal"] - cfg["causal_in_annot"], replace=False)]
    beta_true = np.zeros(p); beta_true[causal] = rng.standard_normal(len(causal))
    g = X @ beta_true; g *= math.sqrt(cfg["h2"] / g.var()); beta_true *= math.sqrt(cfg["h2"] / (X @ beta_true).var())
    g = X @ beta_true
    y = g + math.sqrt(1 - cfg["h2"]) * rng.standard_normal(n)
    tr, te = np.arange(cfg["n_train"]), np.arange(cfg["n_train"], n)
    Xtr, ytr = X[tr], y[tr]; sg2 = cfg["h2"] * float(np.var(ytr))
    rand_annot = rng.permutation(annot)
    enrich = (annot[causal].mean()) / annot.mean()
    print(f"习题 31.18  BayesR 与 BayesRC（训练 {cfg['n_train']}，验证 {cfg['n_test']}，SNP {p}，注释比例 {annot.mean():.2f}，因果 SNP 注释富集 {enrich:.1f} 倍）")
    res = {}
    lam = (1 - cfg["h2"]) / (cfg["h2"] / p)
    b_ridge = np.linalg.solve(Xtr.T @ Xtr + lam * np.eye(p), Xtr.T @ (ytr - ytr.mean()))
    models = {"SNP-BLUP": None, "BayesR": np.zeros(p, int), "BayesRC(真实注释)": annot, "BayesRC(随机注释)": rand_annot}
    print(f"{'模型':<18s}{'验证准确度':>10s}{'回归斜率':>9s}{'注释类非零π':>12s}{'非注释类非零π':>14s}{'因果PIP(注释)':>14s}{'因果PIP(非注释)':>15s}")
    for name, cls in models.items():
        if cls is None:
            bhat = b_ridge; pis = None; pip = np.ones(p)
        else:
            bhat, pis, pip, _ = gibbs(Xtr, ytr, cls, cfg, sg2, rng)
        gh = X[te] @ bhat
        acc = float(np.corrcoef(gh, g[te])[0, 1]); slope = float(np.cov(g[te], gh)[0, 1] / gh.var(ddof=1))
        ca, cu = causal[annot[causal] == 1], causal[annot[causal] == 0]
        if pis is None:
            nzA = nzU = float("nan")
        elif pis.shape[0] == 1:
            nzA = nzU = float(1 - pis[0, 0])
        else:
            nzA, nzU = float(1 - pis[1, 0]), float(1 - pis[0, 0])
        res[name] = {"accuracy": acc, "slope": slope, "nonzero_pi_annot": nzA, "nonzero_pi_unannot": nzU,
                     "pip_causal_annot": float(pip[ca].mean()), "pip_causal_unannot": float(pip[cu].mean()),
                     "pi": None if pis is None else pis.tolist()}
        print(f"{name:<18s}{acc:10.3f}{slope:9.3f}{nzA:12.3f}{nzU:14.3f}{res[name]['pip_causal_annot']:14.3f}{res[name]['pip_causal_unannot']:15.3f}")
    assert res["BayesRC(真实注释)"]["nonzero_pi_annot"] > res["BayesRC(真实注释)"]["nonzero_pi_unannot"]
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex31_18_bayesrc.json").write_text(json.dumps({"enrichment": enrich, "models": res}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
