#!/usr/bin/env python3
"""习题 31.17  转录组关联研究（TWAS）：表达权重训练、汇总统计 z 值与“连锁的直接作用”造成的假介导

步骤：
  1. 参考面板（基因型 + 表达，n_ref）中用岭回归学习顺式表达预测权重 w（λ 由五折交叉验证选择）；
  2. 独立 GWAS 群体（只有基因型与性状）中计算各 SNP 的标准化边际 z 值；
  3. 汇总统计 TWAS：z_T = wᵀ z / √(wᵀ R w)，R 为参考面板的 LD 相关矩阵；
  4. 个体水平 TWAS：在 GWAS 群体中用 w 预测表达，再对性状回归，比较两种 z 值（独立核验）。
情景：表达介导（θ ≠ 0）、与 eQTL 连锁的 SNP 直接作用于性状（表达无因果作用）、完全无作用（检验 I 类错误）。
另报告 GWAS 峰顶 SNP 与 eQTL 峰顶 SNP 一致的比例，说明“峰顶一致”与“同一因果”之间的距离。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")   # 小矩阵运算单线程更快、结果可复现
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def genotypes(n: int, p: np.ndarray, rho: float, rng) -> np.ndarray:
    """潜在 AR(1) 高斯过程阈值化产生具有 LD 的两条单倍型并相加。"""
    J = len(p); thr = norm.ppf(p); G = np.zeros((n, J))
    for _ in range(2):
        z = np.empty((n, J)); z[:, 0] = rng.standard_normal(n)
        e = rng.standard_normal((n, J)); s = np.sqrt(1 - rho ** 2)
        for j in range(1, J):
            z[:, j] = rho * z[:, j - 1] + s * e[:, j]
        G += z < thr
    return G


def standardize(G: np.ndarray, mu: np.ndarray, sd: np.ndarray) -> np.ndarray:
    return (G - mu) / sd


def ridge(X: np.ndarray, y: np.ndarray, lam: float) -> np.ndarray:
    return np.linalg.solve(X.T @ X + lam * np.eye(X.shape[1]), X.T @ y)


def cv_ridge(X, y, lams, rng, k=5):
    idx = rng.permutation(len(y)); folds = np.array_split(idx, k); best = None
    for lam in lams:
        sse = 0.0
        for f in folds:
            tr = np.setdiff1d(idx, f); w = ridge(X[tr], y[tr] - y[tr].mean(), lam)
            sse += np.sum((y[f] - y[tr].mean() - X[f] @ w) ** 2)
        r2 = 1 - sse / np.sum((y - y.mean()) ** 2)
        if best is None or r2 > best[1]:
            best = (lam, r2)
    return best


def one_rep(cfg, sc, rng):
    J = cfg["n_snp"]; p = rng.uniform(*cfg["maf_range"], J)
    eq = np.array(cfg["eqtl_snps"]); be = np.array(cfg["eqtl_effects"])
    # 参考面板
    Gr = genotypes(cfg["n_ref"], p, cfg["ld_rho"], rng)
    expr_r = Gr[:, eq] @ be + cfg["expr_resid_sd"] * rng.standard_normal(cfg["n_ref"])
    mu, sd = Gr.mean(0), Gr.std(0) + 1e-12
    Xr = standardize(Gr, mu, sd)
    lam, r2cv = cv_ridge(Xr, expr_r, cfg["ridge_lambdas"], rng)
    w = ridge(Xr, expr_r - expr_r.mean(), lam)
    R = np.corrcoef(Xr, rowvar=False)
    eq_lead = int(np.argmax(np.abs(Xr.T @ (expr_r - expr_r.mean()))))
    # GWAS 群体
    Gg = genotypes(cfg["n_gwas"], p, cfg["ld_rho"], rng)
    expr_g = Gg[:, eq] @ be + cfg["expr_resid_sd"] * rng.standard_normal(cfg["n_gwas"])
    y = sc["theta"] * expr_g + sc["direct"] * Gg[:, cfg["pleio_snp"]] + rng.standard_normal(cfg["n_gwas"])
    Xg = (Gg - Gg.mean(0)) / (Gg.std(0) + 1e-12); yc = (y - y.mean()) / y.std()
    n = cfg["n_gwas"]
    r = Xg.T @ yc / n                                   # 标准化边际回归系数（≈相关）
    z = r * np.sqrt((n - 2) / (1 - r ** 2))
    zT = float(w @ z / np.sqrt(w @ R @ w))
    # 个体水平 TWAS
    pred = standardize(Gg, mu, sd) @ w
    rr = np.corrcoef(pred, y)[0, 1]; z_ind = float(rr * np.sqrt((n - 2) / (1 - rr ** 2)))
    gw_lead = int(np.argmax(np.abs(z)))
    return {"zT": zT, "z_ind": z_ind, "r2cv": r2cv, "lam": lam, "lead_match": gw_lead == eq_lead,
            "gw_lead_is_pleio": gw_lead == cfg["pleio_snp"]}


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex31_17_twas.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); crit = norm.ppf(1 - cfg["alpha"] / 2)
    out = []; allz = []
    print(f"习题 31.17  TWAS（参考面板 {cfg['n_ref']}，GWAS {cfg['n_gwas']}，{cfg['n_snp']} 个顺式 SNP，重复 {cfg['replicates']} 次）")
    print(f"{'情景':<12s}{'表达CV R²':>10s}{'平均|z_T|':>10s}{'显著率':>8s}{'z_T与个体z相关':>15s}{'峰顶一致率':>10s}{'GWAS峰在直接作用SNP':>20s}")
    for sc in cfg["scenarios"]:
        reps = [one_rep(cfg, sc, rng) for _ in range(cfg["replicates"])]
        zT = np.array([r["zT"] for r in reps]); zi = np.array([r["z_ind"] for r in reps])
        cz = float(np.corrcoef(zT, zi)[0, 1]) if zT.std() > 0 else 1.0
        allz.append(np.column_stack([zT, zi]))
        row = {"name": sc["name"], "expr_cv_r2": float(np.mean([r["r2cv"] for r in reps])), "mean_abs_zT": float(np.mean(np.abs(zT))),
               "reject_rate": float(np.mean(np.abs(zT) > crit)), "corr_summary_individual": cz,
               "lead_match_rate": float(np.mean([r["lead_match"] for r in reps])),
               "gwas_lead_at_direct_snp": float(np.mean([r["gw_lead_is_pleio"] for r in reps]))}
        out.append(row)
        print(f"{sc['name']:<12s}{row['expr_cv_r2']:10.3f}{row['mean_abs_zT']:10.2f}{row['reject_rate']:8.2f}{cz:15.3f}{row['lead_match_rate']:10.2f}{row['gwas_lead_at_direct_snp']:20.2f}")
    Z = np.vstack(allz)
    assert np.corrcoef(Z[:, 0], Z[:, 1])[0, 1] > 0.98, "汇总统计 TWAS 应与个体水平 TWAS 一致"
    assert out[2]["reject_rate"] < 0.15, "无作用情景的显著率应接近名义水平"
    print(f"\n全部重复中汇总 z_T 与个体水平 z 的相关 = {np.corrcoef(Z[:, 0], Z[:, 1])[0, 1]:.4f}；平均绝对差 = {np.mean(np.abs(Z[:, 0] - Z[:, 1])):.3f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex31_17_twas.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
