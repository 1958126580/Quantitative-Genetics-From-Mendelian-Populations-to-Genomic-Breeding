#!/usr/bin/env python3
"""习题 31.16  两样本孟德尔随机化：IVW、MR-Egger、加权中位数在不同多效性情景下的偏差与覆盖率

生成模型（每个重复独立模拟两个不重叠样本）：
    m = Σ_j g_j γ_j + a·U + e_m,        y = θ m + Σ_j g_j α_j + b·U + e_y
U 为未测混杂，α_j 为水平多效性（直接作用）。暴露样本估计 β̂_gm,j，结局样本估计 β̂_gy,j。
    Wald 比值  θ_j = β̂_gy,j / β̂_gm,j；一阶方差 se_y²/β²_gm，二阶再加 β²_gy se_m²/β⁴_gm
    IVW       θ̂ = Σ β_gm β_gy w / Σ β²_gm w, w = 1/se_y²（等价于过原点加权回归），乘性随机效应标准误
    MR-Egger  定向使 β_gm > 0 后，β_gy 对 β_gm 带截距加权回归；截距检验定向多效性（InSIDE 假设）
    加权中位数  Bowden 等（2016）的插值加权中位数，半数以上权重来自有效工具时一致
独立核验：IVW 与 lstsq 加权回归一致；二阶方差不小于一阶；有效工具情景 IVW 均值接近 θ。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")   # 小矩阵运算单线程更快、结果可复现
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def assoc(G: np.ndarray, x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """逐 SNP 简单回归（含截距）的效应与标准误。"""
    Gc = G - G.mean(0); xc = x - x.mean()
    ss = (Gc ** 2).sum(0); beta = Gc.T @ xc / ss
    resid_ss = (xc ** 2).sum() - beta ** 2 * ss
    se = np.sqrt(resid_ss / (len(x) - 2) / ss)
    return beta, se


def ivw(bm, by, sy):
    w = 1 / sy ** 2
    est = np.sum(w * bm * by) / np.sum(w * bm ** 2)
    resid = (by - est * bm) / sy
    phi = max(1.0, np.sum(resid ** 2) / (len(bm) - 1))
    se = np.sqrt(phi / np.sum(w * bm ** 2))
    return est, se


def egger(bm, by, sy):
    s = np.sign(bm); bm, by = bm * s, by * s
    X = np.column_stack([np.ones_like(bm), bm]) / sy[:, None]; yv = by / sy
    coef, *_ = np.linalg.lstsq(X, yv, rcond=None)
    r = yv - X @ coef; phi = max(1.0, r @ r / (len(bm) - 2))
    cov = phi * np.linalg.inv(X.T @ X)
    return coef[1], np.sqrt(cov[1, 1]), coef[0], np.sqrt(cov[0, 0])


def weighted_median(ratio, w):
    o = np.argsort(ratio); r, w = ratio[o], w[o] / w.sum()
    cum = np.cumsum(w) - 0.5 * w
    return float(np.interp(0.5, cum, r))


def one_rep(cfg, sc, rng):
    J = cfg["n_snp"]; p = rng.uniform(*cfg["maf_range"], J)
    gamma = np.abs(rng.normal(0, cfg["instrument_sd"], J)) * sc["weak_factor"]   # 按增加暴露的等位基因编码
    invalid = rng.random(J) < sc["frac_invalid"]
    alpha = np.where(invalid, sc["pleio_mean"] + sc["pleio_sd"] * rng.standard_normal(J), 0.0)

    def sample(n):
        G = (rng.random((n, J)) < p).astype(float) + (rng.random((n, J)) < p); U = rng.standard_normal(n)
        m = G @ gamma + cfg["confounder_on_m"] * U + cfg["resid_sd_m"] * rng.standard_normal(n)
        y = cfg["theta"] * m + G @ alpha + cfg["confounder_on_y"] * U + cfg["resid_sd_y"] * rng.standard_normal(n)
        return G, m, y
    G1, m1, y1 = sample(cfg["n_exposure"]); G2, _, y2 = sample(cfg["n_outcome"])
    bm, sm = assoc(G1, m1); by, sy = assoc(G2, y2)
    # 核验：IVW = 过原点加权最小二乘
    est, se = ivw(bm, by, sy)
    ls, *_ = np.linalg.lstsq((bm / sy)[:, None], by / sy, rcond=None)
    assert abs(ls[0] - est) < 1e-10
    v1 = sy ** 2 / bm ** 2; v2 = v1 + by ** 2 * sm ** 2 / bm ** 4
    assert np.all(v2 >= v1)
    eg, eg_se, eg_int, eg_int_se = egger(bm, by, sy)
    wm = weighted_median(by / bm, 1 / v2)
    ols = np.polyfit(m1, y1, 1)[0]
    F = np.mean(bm ** 2 / sm ** 2)
    return {"ols": ols, "ivw": est, "ivw_se": se, "egger": eg, "egger_se": eg_se, "egger_int": eg_int,
            "egger_int_p_sig": abs(eg_int / eg_int_se) > 1.96, "wm": wm, "F": F,
            "ratio_se_ratio": float(np.median(np.sqrt(v2 / v1)))}


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex31_16_mr.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); th = cfg["theta"]
    out = []
    print(f"习题 31.16  两样本 MR（真实 θ = {th}，{cfg['n_snp']} 个工具，各样本 {cfg['n_exposure']} 头，重复 {cfg['replicates']} 次）")
    print(f"{'情景':<10s}{'平均F':>7s}{'OLS':>8s}{'IVW':>8s}{'IVW_SD':>8s}{'IVW覆盖':>8s}{'Egger':>8s}{'Egger_SD':>9s}{'截距显著率':>10s}{'加权中位数':>10s}{'WM_SD':>7s}")
    for sc in cfg["scenarios"]:
        reps = [one_rep(cfg, sc, rng) for _ in range(cfg["replicates"])]
        A = {k: np.array([r[k] for r in reps], float) for k in reps[0]}
        cover = np.mean(np.abs(A["ivw"] - th) <= 1.96 * A["ivw_se"])
        row = {"name": sc["name"], "mean_F": A["F"].mean(), "ols": A["ols"].mean(), "ivw": A["ivw"].mean(), "ivw_sd": A["ivw"].std(ddof=1),
               "ivw_cover": cover, "egger": A["egger"].mean(), "egger_sd": A["egger"].std(ddof=1),
               "egger_int_sig_rate": A["egger_int_p_sig"].mean(), "wm": A["wm"].mean(), "wm_sd": A["wm"].std(ddof=1),
               "median_se_inflation_2nd_order": A["ratio_se_ratio"].mean()}
        out.append(row)
        print(f"{sc['name']:<10s}{row['mean_F']:7.1f}{row['ols']:8.3f}{row['ivw']:8.3f}{row['ivw_sd']:8.3f}{cover:8.2f}"
              f"{row['egger']:8.3f}{row['egger_sd']:9.3f}{row['egger_int_sig_rate']:10.2f}{row['wm']:10.3f}{row['wm_sd']:7.3f}")
    valid = out[0]
    assert abs(valid["ivw"] - th) < 4 * valid["ivw_sd"] / np.sqrt(cfg["replicates"]) + 0.01, "有效工具情景 IVW 应近似无偏"
    assert valid["ols"] > th + 0.1, "存在正向混杂时 OLS 应高估"
    print("\n二阶 Delta 方差相对一阶的标准误放大倍数（工具中位数）：" + "，".join(f"{r['name']} {r['median_se_inflation_2nd_order']:.3f}" for r in out))
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex31_16_mr_pleiotropy.json").write_text(json.dumps(out, ensure_ascii=False, indent=2, default=float), encoding="utf-8")


if __name__ == "__main__":
    main()
