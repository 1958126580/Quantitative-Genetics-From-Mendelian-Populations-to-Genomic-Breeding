#!/usr/bin/env python3
"""习题 31.15  组学辅助记录的条件遗传信息：舒尔补增量、表型相关的误导与技术重复的边际收益

模型：目标育种值 u，已有基因组预测 b（BLUP 性质 Cov(u,b)=Var(b)=r_b²），
组学记录 m = u_m + e_m（q 维），目标表型 y = u + e_y（只用于展示表型相关）。
新增信息的价值由“组学对已有信息残差化后”与 u 的协方差决定：
    r_m   = m − C_mb V_b⁻¹ b
    S_m   = V_m − C_mb V_b⁻¹ C_mbᵀ,     c_ur = c_m − C_mb V_b⁻¹ c_b
    ΔPEV  = c_urᵀ S_m⁻¹ c_ur
独立核验：(1) 全信息选择指数 R² = c_Iᵀ V_I⁻¹ c_I 与 r_b² + ΔPEV 相等；(2) 二十万次蒙特卡罗模拟的回归 R² 与理论一致；
(3) 技术误差 Ω 半正定时 ΔPEV 不增加。技术重复部分：e_m = 共同批次偏差 + 独立误差/r。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")   # 小矩阵运算单线程更快、结果可复现
import json
from pathlib import Path
import numpy as np
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent


def joint_cov(cfg: dict, sc: dict) -> tuple[np.ndarray, int]:
    """返回 (u, b, u_m[q], e_m[q], e_y) 的联合协方差矩阵。"""
    vum = np.array(sc["var_um"], float); q = vum.shape[0]
    n = 2 + 2 * q + 1; S = np.zeros((n, n))
    iu, ib = 0, 1; ium = slice(2, 2 + q); iem = slice(2 + q, 2 + 2 * q); iey = n - 1
    S[iu, iu] = cfg["var_u"]; S[ib, ib] = S[iu, ib] = S[ib, iu] = cfg["rel_b"]
    S[ium, ium] = vum
    S[iu, ium] = S[ium, iu] = sc["cov_um_u"]
    S[ib, ium] = S[ium, ib] = sc["cov_um_b"]
    S[iem, iem] = np.array(sc["var_em"], float)
    S[iey, iey] = cfg["var_ey"]
    S[iem, iey] = S[iey, iem] = sc["cov_em_ey"]
    np.linalg.cholesky(S)                     # 若参数不合法（非正定）在此报错
    return S, q


def observed_moments(S: np.ndarray, q: int):
    """观测信息 (b, m) 的协方差及其与 u 的协方差。m = u_m + e_m。"""
    n = S.shape[0]
    L = np.zeros((1 + q, n)); L[0, 1] = 1
    for k in range(q):
        L[1 + k, 2 + k] = 1; L[1 + k, 2 + q + k] = 1
    VI = L @ S @ L.T; cI = L @ S[:, 0]
    return VI, cI, L


def schur_increment(VI: np.ndarray, cI: np.ndarray, Omega: np.ndarray | None = None) -> float:
    Vb = VI[0, 0]; Cmb = VI[1:, 0]; Vm = VI[1:, 1:].copy(); cb = cI[0]; cm = cI[1:]
    if Omega is not None:
        Vm = Vm + Omega
    Sm = Vm - np.outer(Cmb, Cmb) / Vb
    cur = cm - Cmb * cb / Vb
    return float(cur @ np.linalg.solve(Sm, cur))


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex31_15_conditional_info.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    out = {"scenarios": []}
    print("习题 31.15  组学辅助记录的条件信息（目标遗传方差 = 1，已有可靠性 r_b² = %.2f）" % cfg["rel_b"])
    print(f"{'情景':<12s}{'r_P(m,y)':>9s}{'r_g':>8s}{'r(m,u)':>8s}{'单用m可靠性':>11s}{'ΔPEV':>9s}{'联合可靠性':>10s}{'MC可靠性':>10s}{'增量权重':>18s}")
    for sc in cfg["scenarios"]:
        S, q = joint_cov(cfg, sc)
        VI, cI, L = observed_moments(S, q)
        dpev = schur_increment(VI, cI)
        r2_full = float(cI @ np.linalg.solve(VI, cI))
        assert abs(r2_full - (cfg["rel_b"] + dpev)) < 1e-12, "舒尔补与全指数不一致"
        # 表型相关与遗传相关（第一个指标）
        vm = VI[1, 1]; vy = cfg["var_u"] + cfg["var_ey"]
        cov_my = sc["cov_um_u"][0] + sc["cov_em_ey"][0]
        rP = cov_my / np.sqrt(vm * vy)
        rg = sc["cov_um_u"][0] / np.sqrt(sc["var_um"][0][0] * cfg["var_u"])
        r_mu = sc["cov_um_u"][0] / np.sqrt(vm * cfg["var_u"])
        rel_m_alone = float(cI[1:] @ np.linalg.solve(VI[1:, 1:], cI[1:]))
        # 蒙特卡罗核验
        X = rng.standard_normal((cfg["mc_n"], S.shape[0])) @ np.linalg.cholesky(S).T
        u = X[:, 0]; I = X @ L.T
        coef, *_ = np.linalg.lstsq(I, u, rcond=None)
        r2_mc = 1 - np.var(u - I @ coef) / np.var(u)
        assert abs(r2_mc - r2_full) < 0.01, "蒙特卡罗与理论差异过大"
        w = np.linalg.solve(VI, cI)           # 指数权重（b 在前）
        # 半正定技术误差不会增加信息
        assert schur_increment(VI, cI, 0.3 * np.eye(q)) <= dpev + 1e-12
        print(f"{sc['name']:<12s}{rP:9.3f}{rg:8.3f}{r_mu:8.3f}{rel_m_alone:11.4f}{dpev:9.4f}{r2_full:10.4f}{r2_mc:10.4f}   " + " ".join(f"{x:+.3f}" for x in w))
        out["scenarios"].append({"name": sc["name"], "r_phen_m_y": rP, "r_g": rg, "r_m_u": r_mu, "rel_m_alone": rel_m_alone,
                                 "delta_pev": dpev, "rel_joint": r2_full, "rel_mc": float(r2_mc), "index_weights": w.tolist()})
    # 技术重复：共同批次偏差不随平均消失
    rd = cfg["replicate_design"]; sc = cfg["scenarios"][rd["scenario"]]
    print("\n技术重复（情景 %s；共同批次误差方差 %.2f，独立误差方差 %.2f）" % (sc["name"], rd["shared_batch_var"], rd["indep_var"]))
    print(f"{'重复数 r':>8s}{'误差方差':>10s}{'ΔPEV(正确)':>12s}{'ΔPEV(误当独立)':>15s}{'记录遗传力':>12s}")
    rows = []
    base = dict(sc); vum = sc["var_um"][0][0]
    for r in rd["r_values"]:
        ve = rd["shared_batch_var"] + rd["indep_var"] / r
        ve_naive = (rd["shared_batch_var"] + rd["indep_var"]) / r
        res = []
        for v in (ve, ve_naive):
            base["var_em"] = [[v]]
            S, q = joint_cov(cfg, base); VI, cI, _ = observed_moments(S, q)
            res.append(schur_increment(VI, cI))
        lam = vum / (vum + ve)
        rows.append({"r": r, "err_var": ve, "dpev": res[0], "dpev_naive": res[1], "h2_record": lam})
        print(f"{r:8d}{ve:10.4f}{res[0]:12.5f}{res[1]:15.5f}{lam:12.4f}")
    assert all(rows[i]["dpev"] <= rows[i + 1]["dpev"] + 1e-12 for i in range(len(rows) - 1))
    out["replicates"] = rows
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex31_15_conditional_info.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    plt = get_pyplot()
    if plt is not None:
        rs = [x["r"] for x in rows if x["r"] <= 8]
        fig, ax = plt.subplots(figsize=(5.2, 3.4))
        ax.plot(rs, [x["dpev"] for x in rows if x["r"] <= 8], "o-", label="含共同批次误差")
        ax.plot(rs, [x["dpev_naive"] for x in rows if x["r"] <= 8], "s--", label="误当全部独立")
        ax.axhline(rows[-1]["dpev"], color="gray", lw=0.8, ls=":", label="r→∞ 极限")
        ax.set_xlabel("技术重复数 r"); ax.set_ylabel("ΔPEV（可靠性增量）"); ax.legend(); fig.tight_layout()
        fig.savefig(HERE / "results" / "ex31_15_replicates.png"); plt.close(fig)


if __name__ == "__main__":
    main()
