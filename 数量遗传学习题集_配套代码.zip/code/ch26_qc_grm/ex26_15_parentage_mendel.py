#!/usr/bin/env python3
"""习题 26.15  基因型质检中的亲子鉴定：孟德尔冲突计数、阈值与 SNP 数

设置：150 头公畜、150 头母畜（无亲缘起始个体）与 400 头子代；每头子代有记录的父亲，其中 12% 记错（真父亲被另一头公畜替换）。
分型误差：每个基因型以概率 ε 被随机替换为另两种基因型之一；90% 的样本 ε=0.4%，10% 的样本（DNA 质量差）ε=3%。
统计量：对记录的父子对，统计对立纯合（AA 对 aa）冲突位点数 C；真亲子的 C 只来自分型误差，非亲子的期望冲突率为 2p²q²（对每个位点）。
分析：
  (1) 理论与模拟的非亲子冲突率比较；
  (2) 以冲突率（C / 可比位点数）为判别量，计算不同 SNP 数 m 下识别记错父亲的 ROC-AUC 与固定阈值（真亲子冲突率 99.5% 分位）下的检出率与假阳性率；
  (3) 样本分型误差高的动物被误判为“记错父亲”的比例，及剔除高误差样本后的改善。
核验：(a) 非亲子冲突率与理论 Σ2p²q²/m 相对差 < 3%；(b) AUC 随 m 增加（单调不降）；(c) m=2000 时 AUC > 0.999；
      (d) 高误差样本的真亲子冲突率至少为低误差样本的 2 倍；剔除高误差样本使 99.5% 阈值下降。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def mendel_off(sire_g, dam_g, rng):
    """由父母基因型 (0/1/2) 生成子代基因型。"""
    ps = sire_g / 2.0; pd = dam_g / 2.0
    return (rng.random(sire_g.shape) < ps).astype(np.int8) + (rng.random(dam_g.shape) < pd).astype(np.int8)


def add_error(g, eps, rng):
    """每个基因型以 eps（逐行）发生错误：改为另两种之一（等概率）。"""
    flip = rng.random(g.shape) < eps[:, None]
    shift = rng.integers(1, 3, g.shape)
    return np.where(flip, (g + shift) % 3, g).astype(np.int8)


def conflict_rate(a, b):
    """对立纯合冲突率：位点上 (0,2) 或 (2,0)。"""
    return ((a == 0) & (b == 2) | (a == 2) & (b == 0)).mean(axis=-1)


def main():
    cfg = json.load(open(HERE / "data" / "ex26_15_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    m = cfg["m"]; p = rng.uniform(cfg["maf_min"], 0.5, m)
    S, D, No = cfg["n_sires"], cfg["n_dams"], cfg["n_off"]
    sires = (rng.random((S, m)) < p).astype(np.int8) + (rng.random((S, m)) < p).astype(np.int8)
    dams = (rng.random((D, m)) < p).astype(np.int8) + (rng.random((D, m)) < p).astype(np.int8)
    ts = rng.integers(0, S, No); td = rng.integers(0, D, No)
    off = mendel_off(sires[ts], dams[td], rng)
    wrong = rng.random(No) < cfg["frac_wrong_sire"]
    rec_sire = ts.copy()
    for i in np.where(wrong)[0]:
        c = rng.integers(0, S)
        while c == ts[i]:
            c = rng.integers(0, S)
        rec_sire[i] = c
    bad_off = rng.random(No) < cfg["frac_bad"]
    bad_sire = rng.random(S) < cfg["frac_bad"]
    eps_o = np.where(bad_off, cfg["err_bad"], cfg["err_good"]); eps_s = np.where(bad_sire, cfg["err_bad"], cfg["err_good"])
    off_o = add_error(off, eps_o, rng); sires_o = add_error(sires, eps_s, rng)

    # (1) 非亲子理论冲突率
    theory_unrel = float(np.sum(2 * p ** 2 * (1 - p) ** 2) / m)
    rand_pairs = np.array([(rng.integers(0, S), i) for i in range(No)])
    unrel_rate = conflict_rate(sires[rand_pairs[:, 0]], off[rand_pairs[:, 1]]).mean()   # 无误差基因型的随机对
    # 记错父亲的子代：真实冲突率（含误差）
    rate_full = conflict_rate(sires_o[rec_sire], off_o)
    true_pairs = ~wrong
    # (d) 真亲子冲突率
    e_eff = 0.5 * (np.mean(eps_o[true_pairs]) + np.mean(eps_s[ts[true_pairs]]))
    emp_true = rate_full[true_pairs].mean()
    # 误差引起冲突的理论期望：对每个位点，从正确基因型出发的对立纯合冲突率，数值方法近似：模拟 Mendel 一致数据加误差
    print("=" * 84)
    print(f"习题 26.15  亲子鉴定：{S} 公畜 × {No} 子代，m={m}；记错父亲 {wrong.sum()} 头（{wrong.mean():.1%}）；高误差样本 {bad_off.sum()} 头")
    print("=" * 84)
    print(f"非亲子冲突率：理论 Σ2p²q²/m = {theory_unrel:.5f}；模拟（无误差）{unrel_rate:.5f}；含误差的记错父亲对 {rate_full[wrong].mean():.5f}")
    print(f"真亲子冲突率：{emp_true:.5f}；其中低误差对 {rate_full[true_pairs & ~bad_off & ~bad_sire[rec_sire]].mean():.5f}，含高误差样本的对 {rate_full[true_pairs & (bad_off | bad_sire[rec_sire])].mean():.5f}")
    assert abs(unrel_rate - theory_unrel) / theory_unrel < 0.03, (unrel_rate, theory_unrel)
    # (2) 不同 m
    print(f"\n{'SNP 数':>8} {'AUC':>7} {'固定阈值':>9} {'检出率':>7} {'假阳性率':>8} {'高误差真亲子的误判率':>20}")
    rows = []; aucs = []
    for k in cfg["panel_sizes"]:
        idx = rng.choice(m, k, replace=False)
        r = conflict_rate(sires_o[rec_sire][:, idx], off_o[:, idx])
        pos = r[wrong]; neg = r[true_pairs]
        # AUC：P(正样本得分>负样本得分)
        auc = float((pos[:, None] > neg[None, :]).mean() + 0.5 * (pos[:, None] == neg[None, :]).mean())
        thr = float(np.quantile(neg, 0.995))
        det = float((pos > thr).mean()); fp = float((neg > thr).mean())
        hb = true_pairs & (bad_off | bad_sire[rec_sire])
        fp_bad = float((r[hb] > thr).mean())
        aucs.append(auc)
        print(f"{k:>8} {auc:>7.4f} {thr:>9.4f} {det:>7.3f} {fp:>8.3f} {fp_bad:>20.3f}")
        rows.append(dict(m=k, auc=auc, thr=thr, detect=det, false_pos=fp, false_pos_high_error=fp_bad))
    assert all(aucs[i] <= aucs[i + 1] + 1e-3 for i in range(len(aucs) - 1)), aucs
    assert aucs[-1] > 0.999, aucs
    # (3) 剔除高误差样本后
    keep = ~(bad_off | bad_sire[rec_sire])
    r = conflict_rate(sires_o[rec_sire], off_o)
    pos = r[wrong & keep]; neg = r[true_pairs & keep]
    thr_c = float(np.quantile(neg, 0.995)); thr_all = float(np.quantile(r[true_pairs], 0.995))
    print(f"\n全部样本：真亲子 99.5% 分位阈值 {thr_all:.5f}；剔除高误差样本后：{thr_c:.5f}（降低 {(1 - thr_c / thr_all):.0%}）")
    print(f"高误差样本占 {np.mean(~keep):.1%}，其中真亲子冲突率均值 {r[true_pairs & ~keep].mean():.5f} 对低误差 {r[true_pairs & keep].mean():.5f}")
    assert r[true_pairs & ~keep].mean() > 2 * r[true_pairs & keep].mean()
    assert thr_c < thr_all
    json.dump(dict(theory_unrelated=theory_unrel, sim_unrelated=float(unrel_rate), true_pair_rate=float(emp_true), rows=rows, thr_all=thr_all, thr_clean=thr_c),
              open(HERE / "results" / "ex26_15_parentage_mendel.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
