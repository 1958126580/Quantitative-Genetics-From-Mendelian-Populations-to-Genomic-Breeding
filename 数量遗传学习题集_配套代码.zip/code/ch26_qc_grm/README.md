# 第26章　基因型质量控制与基因组关系矩阵——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex26_15_parentage_mendel.py
python3 ex26_16_hwe_tests.py
python3 ex26_17_lowpass_dosage_grm.py
python3 ex26_18_grm_vs_pedigree_scaling.py
python3 ex26_19_missing_genotypes_grm.py
python3 ex26_20_frequency_error_invariance.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex26_15_parentage_mendel.py | 26.15 | 基因型质检中的亲子鉴定：孟德尔冲突计数、阈值与 SNP 数 |
| ex26_16_hwe_tests.py | 26.16 | 哈迪—温伯格检验作为质量控制：精确检验、卡方检验、分层与等位基因脱扣的检出能力 |
| ex26_17_lowpass_dosage_grm.py | 26.17 | 低深度测序：基因型似然、后验剂量与关系矩阵的偏倚及对角元校正 |
| ex26_18_grm_vs_pedigree_scaling.py | 26.18 | 基因组关系矩阵 G 与系谱矩阵 A 的尺度相容：基群频率、样本频率与线性变换 |
| ex26_19_missing_genotypes_grm.py | 26.19 | 缺失基因型如何改变 GRM：MCAR 与“杂合子更易缺失”(MNAR) 下的填补策略 |
| ex26_20_frequency_error_invariance.py | 26.20 | 等位基因频率误差对 GBLUP 的影响：一个精确的不变性定理与批次中心化的反例 |
