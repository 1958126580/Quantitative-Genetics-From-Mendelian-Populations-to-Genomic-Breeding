#!/usr/bin/env python3
"""习题 26.20  等位基因频率误差对 GBLUP 的影响：一个精确的不变性定理与批次中心化的反例

分解：设 W_p = X − 2p（真频率中心化），改用 p̂ 后 W_p̂ = W_p + 1δᵀ，δ = 2(p − p̂)。则
      G_p̂ = [W Wᵀ + 1(Wδ)ᵀ + (Wδ)1ᵀ + (δᵀδ)11ᵀ] / s_p̂，   s_p̂ = 2Σ p̂(1−p̂)。
即频率误差只在 G 上叠加形如 1aᵀ + a1ᵀ 的项（a = Wδ + ½(δᵀδ)1），并改变尺度 s。
定理（含固定截距的 BLUP）：对任意 a，G + (1aᵀ + a1ᵀ) 给出的 REML 似然与 BLUP 在“全部个体共同加一个常数”之外完全不变（P 不变，Δ P y = 1(aᵀPy)）。
程序：
  (1) 数值验证分解（1e-9）与不变性（EBV 差在去均值后 < 1e-9，REML 对数似然差 < 1e-9）；
  (2) 频率来自不同大小参照样本（10、40、400 头）时：平均对角元、尺度 s、EBV 的“常数平移”大小相对 EBV SD；
  (3) 固定方差比（不重估）时尺度 s 变化造成的收缩误差，与 REML 重估（等价于调整 σ_u²）的对比；
  (4) 反例：两批动物（来自 F_ST=0.05 的两个亚群），用“各批自己的样本频率”分别中心化（批内中心化），与用统一频率比较：
      批内中心化抹去批间真遗传差异，跨批排序准确度下降。
核验：(a)(b) 见上；(c) 反例中统一频率的跨批准确度高于批内中心化（平均），且差距为正的重复占多数。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar

HERE = Path(__file__).resolve().parent


def reml_ebv(y, G):
    """含截距的 GREML（剖面 h²），返回 EBV、h²、σ_u²、REML 对数似然（含剖面方差）。"""
    n = len(y); S, U = np.linalg.eigh(G); S = np.maximum(S, 0)
    yt, xt = U.T @ y, U.T @ np.ones(n)

    def parts(h2):
        d = h2 * S + (1 - h2)
        xvx = np.sum(xt * xt / d); b = np.sum(xt * yt / d) / xvx
        r = yt - xt * b; ypy = np.sum(r * r / d)
        return d, xvx, b, ypy

    def nll(h2):
        d, xvx, _, ypy = parts(h2)
        return 0.5 * (np.sum(np.log(d)) + np.log(xvx) + (n - 1) * np.log(ypy))
    r = minimize_scalar(nll, bounds=(1e-4, 0.9999), method="bounded", options={"xatol": 1e-10})
    h2 = float(r.x); d, xvx, b, ypy = parts(h2)
    sp = ypy / (n - 1)                       # σ_P²
    su, se = h2 * sp, (1 - h2) * sp
    mu = b
    # EBV = σ_u² G V⁻¹(y − μ)，V = σ_u² G + σ_e² I，在特征空间计算
    ebv = U @ (su * S / (su * S + se) * (yt - xt * mu))
    # 剖面 REML 对数似然（去常数）：−½[Σlog d + log xvx + (n−1)log(σ_P²)]，与 G 的尺度无关（σ_P² 随之变化）
    ll = -0.5 * (np.sum(np.log(d)) + np.log(xvx) + (n - 1) * np.log(sp))
    return ebv, h2, su, float(ll)


def fixed_ratio_ebv(y, G, lam):
    n = len(y); mu = y.mean()
    # 含截距：用 GLS 的 μ
    V = G + lam * np.eye(n); Vi = np.linalg.inv(V); one = np.ones(n)
    mu = (one @ Vi @ y) / (one @ Vi @ one)
    return G @ (Vi @ (y - mu))


def main():
    cfg = json.load(open(HERE / "data" / "ex26_20_config.json"))
    rng = np.random.default_rng(cfg["seed"]); n, m = cfg["n"], cfg["m"]
    p = rng.uniform(cfg["maf_lo"], cfg["maf_hi"], m)
    X = (rng.random((n, m)) < p).astype(float) + (rng.random((n, m)) < p).astype(float)
    W = X - 2 * p; s = 2 * np.sum(p * (1 - p)); G = W @ W.T / s
    beta = rng.standard_normal(m) / np.sqrt(2 * p * (1 - p)) * np.sqrt(cfg["h2"] / m)
    u = W @ beta; y = u + rng.standard_normal(n) * np.sqrt(1 - cfg["h2"])
    ebv0, h20, su0, ll0 = reml_ebv(y, G)
    print("=" * 94)
    print(f"习题 26.20  频率误差不变性：n={n}，m={m}；真频率 G：平均对角元 {np.diag(G).mean():.4f}，REML ĥ²={h20:.4f}")
    print("=" * 94)
    print(f"{'参照样本':>8} {'δ 的 RMS':>9} {'s_p̂/s':>7} {'平均对角':>9} {'分解误差':>9} {'EBV 去均值差':>12} {'平移量/EBV SD':>13} {'ĥ²':>7} {'ΔlogL':>9} {'σ̂_u² 比':>8} {'固定λ收缩误差':>12}")
    rows = []
    lam0 = (1 - cfg["h2"]) / cfg["h2"]
    for nref in cfg["n_ref_list"]:
        ref = rng.choice(n, nref, replace=False)
        ph = X[ref].mean(0) / 2
        ph = np.clip(ph, 0.001, 0.999) if nref < n else ph
        delta = 2 * (p - ph)
        Wh = X - 2 * ph; sh = 2 * np.sum(ph * (1 - ph)); Gh = Wh @ Wh.T / sh
        # (1) 分解
        t = W @ delta
        Gdec = (W @ W.T + np.outer(np.ones(n), t) + np.outer(t, np.ones(n)) + (delta @ delta) * np.ones((n, n))) / sh
        err_dec = float(np.abs(Gh - Gdec).max())
        assert err_dec < 1e-9, err_dec
        # (2) 不变性：REML 重估
        ebv, h2h, suh, llh = reml_ebv(y, Gh)
        # 为比较，同一 G 的尺度调整：用 G·(sh/s) 对应原尺度；EBV 理论上与 G 的常数倍无关
        diff = ebv - ebv0; shift = diff.mean(); dev = float(np.abs(diff - shift).max())
        # 似然等价（把 Gh 变回原尺度）
        # (3) 固定方差比
        e_fix = fixed_ratio_ebv(y, Gh, lam0)
        e_fix0 = fixed_ratio_ebv(y, G, lam0)
        shrink_err = float(np.std(e_fix) / np.std(e_fix0) - 1)
        print(f"{nref:>8} {np.sqrt(np.mean(delta ** 2)):>9.4f} {sh / s:>7.4f} {np.diag(Gh).mean():>9.4f} {err_dec:>9.1e} {dev:>12.2e} {abs(shift) / ebv0.std():>13.3f} {h2h:>7.4f} {llh - ll0:>9.2e} {suh / su0:>8.3f} {shrink_err:>12.3%}")
        assert dev < 1e-6, (nref, dev)
        assert abs(llh - ll0) < 1e-6 * max(1, abs(ll0)) or abs(llh - ll0) < 1e-5, (llh, ll0)
        rows.append(dict(n_ref=nref, delta_rms=float(np.sqrt(np.mean(delta ** 2))), scale_ratio=float(sh / s), diag_mean=float(np.diag(Gh).mean()), decomposition_error=err_dec,
                         ebv_dev_after_centering=dev, shift_over_sd=float(abs(shift) / ebv0.std()), h2=h2h, sigma_u2_ratio=float(suh / su0), fixed_lambda_shrink_error=shrink_err))
    # 常数项精确不变性：对任意 a 的 1aᵀ + a1ᵀ
    a = rng.standard_normal(n) * 0.3
    Gp = G + np.outer(np.ones(n), a) + np.outer(a, np.ones(n))
    Gp = Gp + (abs(np.linalg.eigvalsh(Gp).min()) + 1e-3) * 0     # 不要求正定性对 P 的不变性
    # 用 V 形式计算 P：V = σ_u²(G+Δ) + σ_e² I
    su, se = cfg["h2"], 1 - cfg["h2"]
    def Pmat(Gm):
        V = su * Gm + se * np.eye(n); Vi = np.linalg.inv(V); one = np.ones(n)
        return Vi - np.outer(Vi @ one, Vi @ one) / (one @ Vi @ one)
    P1, P2 = Pmat(G), Pmat(Gp)
    e1 = su * G @ P1 @ y; e2 = su * Gp @ P2 @ y
    inv_P = float(np.abs(P1 - P2).max()); const = e2 - e1
    print(f"\n定理检验（任意 a 的 1aᵀ+a1ᵀ）：max|P−P*| = {inv_P:.1e}；EBV 差的最大离差（去均值）= {np.abs(const - const.mean()).max():.1e}；平移 {const.mean():+.4f}")
    assert inv_P < 1e-9 and np.abs(const - const.mean()).max() < 1e-9
    # (4) 反例：两批动物的批内中心化
    k = cfg["fst"]
    Ps = np.stack([rng.beta(p * (1 - k) / k, (1 - p) * (1 - k) / k) for _ in range(2)]).clip(0.01, 0.99)
    accs = {"统一频率": [], "批内中心化": []}; gaps = []; within = {"统一频率": [], "批内中心化": []}
    for r in range(cfg["n_rep"]):
        rr = np.random.default_rng(cfg["seed"] + 10 + r)
        batch = np.arange(n) % 2
        Pb = Ps[batch]
        Xb = (rr.random((n, m)) < Pb).astype(float) + (rr.random((n, m)) < Pb).astype(float)
        pc = Xb.mean(0) / 2                       # 统一（两批合并）频率
        Wc = Xb - 2 * pc; sc = 2 * np.sum(pc * (1 - pc)); Gc = Wc @ Wc.T / sc
        Wb = Xb.copy()
        for b in range(2):
            pb = Xb[batch == b].mean(0) / 2
            Wb[batch == b] = Xb[batch == b] - 2 * pb
        Gb = Wb @ Wb.T / (2 * np.sum(pc * (1 - pc)))
        bet = rr.standard_normal(m) / np.sqrt(2 * pc * (1 - pc)) * np.sqrt(cfg["h2"] / m)
        ub = Wc @ bet; yb = ub + rr.standard_normal(n) * np.sqrt(1 - cfg["h2"])
        tr = np.zeros(n, bool)
        for b in range(2):
            idx = np.where(batch == b)[0]; tr[idx[:cfg["n_train_per_batch"]]] = True
        te = ~tr
        res = []
        for nm, Gm in (("统一频率", Gc), ("批内中心化", Gb)):
            Vtt = Gm[np.ix_(tr, tr)] + lam0 * np.eye(tr.sum()); Vi = np.linalg.inv(Vtt); one = np.ones(tr.sum())
            mu = (one @ Vi @ yb[tr]) / (one @ Vi @ one)
            hat = Gm[np.ix_(te, tr)] @ (Vi @ (yb[tr] - mu))
            a_ = float(np.corrcoef(hat, ub[te])[0, 1]); accs[nm].append(a_); res.append(a_)
            bt = batch[te]
            within[nm].append(float(np.mean([np.corrcoef(hat[bt == b], ub[te][bt == b])[0, 1] for b in range(2)])))
        gaps.append(res[0] - res[1])
    ma = {k_: float(np.mean(v)) for k_, v in accs.items()}
    print(f"\n反例（两批来自 F_ST={k} 的亚群，合并测试集的跨批准确度，{cfg['n_rep']} 次平均）：统一频率 {ma['统一频率']:.3f}，批内中心化 {ma['批内中心化']:.3f}；统一更优的重复 {np.mean(np.array(gaps) > 0):.0%}")
    wi = {k_: float(np.mean(v)) for k_, v in within.items()}
    print(f"批内（分别在两批各自的测试动物内）准确度：统一频率 {wi['统一频率']:.3f}，批内中心化 {wi['批内中心化']:.3f}（批内排序几乎不受影响，伤害来自跨批比较）")
    assert abs(wi["统一频率"] - wi["批内中心化"]) < 0.05
    assert ma["统一频率"] > ma["批内中心化"] and np.mean(np.array(gaps) > 0) > 0.5
    json.dump(dict(rows=rows, theorem=dict(max_P_diff=inv_P), batch_counterexample=ma, within_batch=wi), open(HERE / "results" / "ex26_20_frequency_error_invariance.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
