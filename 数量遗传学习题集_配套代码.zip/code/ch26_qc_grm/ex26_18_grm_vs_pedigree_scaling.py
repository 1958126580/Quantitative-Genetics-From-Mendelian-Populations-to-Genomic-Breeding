#!/usr/bin/env python3
"""习题 26.18  基因组关系矩阵 G 与系谱矩阵 A 的尺度相容：基群频率、样本频率与线性变换

模拟：120 个起始个体（基群，无亲缘、HWE、各位点频率 p0 已知），连续 6 代、每代 60 头，亲本随机取自上一代（含自交以外的任意配对）。
基因型由基因下传（独立位点）生成，A 由递推公式计算。仅最后两代（120 头）被分型。
比较三种 G（分母均为 2Σ p(1−p)，p 取下列来源）：
  G0：基群频率 p0（理论上与 A 同一参照）；
  Gs：被分型样本的频率（行和为 0，对 A 的参照改变）；
  Gc：Gs 经线性变换 G* = a + bGs，使平均对角元、平均非对角元与 A 相同（Christensen 等 2012 的相容化）。
核验：(1) G0 的平均对角元 ≈ A 的平均对角元（5% 内），非对角元对 A 非对角元的回归斜率 ≈ 1（0.8–1.2）、截距 ≈ 0；
      (2) Gs 的每行行和精确为 0（数值 1e-8），平均非对角元 = −平均对角元/(n−1)，且回归截距明显为负；
      (3) 相容化后两项平均与 A 完全一致（1e-10），并给出 a、b；
      (4) 用 Gs 估计的个体近交系数 F̂ = G_ii − 1 平均偏低于系谱 F，而 G0 的无偏（5% 内相对基群）；
      (5) 以 n_rep 次重复，GBLUP 预测准确度三者之差在 0.02 内（排序相关接近 1），但 EBV 的“水平”相差一个常数。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    nf, ng, npg, m = cfg["n_founders"], cfg["n_gen"], cfg["n_per_gen"], cfg["m"]
    p0 = rng.uniform(cfg["maf_lo"], cfg["maf_hi"], m)
    n = nf + ng * npg
    gen = np.zeros(n, int); sire = -np.ones(n, int); dam = -np.ones(n, int)
    # 单倍型：每个体两条（n×2×m）
    H = np.zeros((n, 2, m), dtype=np.int8)
    H[:nf] = (rng.random((nf, 2, m)) < p0).astype(np.int8)
    idx = nf; prev = np.arange(nf)
    for g in range(1, ng + 1):
        for _ in range(npg):
            s, d = rng.choice(prev, 2, replace=False)
            sire[idx], dam[idx], gen[idx] = s, d, g
            for par, slot in ((s, 0), (d, 1)):
                pick = rng.integers(0, 2, m)
                H[idx, slot] = np.where(pick == 0, H[par, 0], H[par, 1])
            idx += 1
        prev = np.arange(idx - npg, idx)
    X = (H[:, 0] + H[:, 1]).astype(float)
    # 系谱 A
    A = np.zeros((n, n))
    for i in range(n):
        if sire[i] < 0:
            A[i, i] = 1.0
        else:
            s, d = sire[i], dam[i]
            A[i, :i] = 0.5 * (A[s, :i] + A[d, :i]); A[:i, i] = A[i, :i]
            A[i, i] = 1 + 0.5 * A[s, d]
    return p0, gen, A, X


def grm(X, p, s):
    W = X - 2 * p
    return W @ W.T / s


def main():
    cfg = json.load(open(HERE / "data" / "ex26_18_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    p0, gen, A, X = simulate(cfg, rng)
    sel = np.where(np.isin(gen, cfg["genotyped_gens"]))[0]
    n = len(sel); Xs = X[sel]; As = A[np.ix_(sel, sel)]
    iu = np.triu_indices(n, 1)
    s0 = 2 * np.sum(p0 * (1 - p0))
    G0 = grm(Xs, p0, s0)
    ps = Xs.mean(0) / 2; ss = 2 * np.sum(ps * (1 - ps))
    Gs = grm(Xs, ps, ss)
    dA, oA = np.diag(As).mean(), As[iu].mean()
    dS, oS = np.diag(Gs).mean(), Gs[iu].mean()
    # 相容化：G* = a + b Gs，使 mean diag 与 mean off 与 A 相同
    b = (dA - oA) / (dS - oS); a = oA - b * oS
    Gc = a + b * Gs
    def reg(G):
        y = G[iu]; x = As[iu]
        sl = np.cov(x, y)[0, 1] / x.var(); ic = y.mean() - sl * x.mean()
        return float(sl), float(ic)
    r0, rs, rc = reg(G0), reg(Gs), reg(Gc)
    F_ped = np.diag(As) - 1
    print("=" * 84)
    print(f"习题 26.18  G 与 A 的尺度：分型 {n} 头（第 {cfg['genotyped_gens']} 代），m={cfg['m']}，基群 {cfg['n_founders']}")
    print("=" * 84)
    print(f"A：平均对角元 {dA:.4f}，平均非对角元 {oA:.4f}；系谱 F 均值 {F_ped.mean():.4f}")
    print(f"{'矩阵':<22}{'平均对角':>9}{'平均非对角':>11}{'回归斜率':>9}{'回归截距':>9}{'F̂ 均值':>9}")
    for nm, G, r in (("G0（基群频率）", G0, r0), ("Gs（样本频率）", Gs, rs), ("Gc（相容化）", Gc, rc)):
        print(f"{nm:<22}{np.diag(G).mean():>9.4f}{G[iu].mean():>11.4f}{r[0]:>9.3f}{r[1]:>9.4f}{(np.diag(G) - 1).mean():>9.4f}")
    print(f"相容化参数：a={a:.5f}，b={b:.4f}；Gs 的最大行和 |rowsum| = {np.abs(Gs.sum(1)).max():.2e}；−平均对角/(n−1) = {-dS/(n-1):.6f}（平均非对角 {oS:.6f}）")
    assert abs(np.diag(G0).mean() - dA) / dA < 0.05
    assert 0.8 < r0[0] < 1.2 and abs(r0[1]) < 0.02
    assert np.abs(Gs.sum(1)).max() < 1e-8
    assert abs(oS + dS / (n - 1)) < 1e-10
    assert rs[1] < -0.01 and rs[1] < r0[1]
    assert abs(np.diag(Gc).mean() - dA) < 1e-10 and abs(Gc[iu].mean() - oA) < 1e-10
    assert (np.diag(Gs) - 1).mean() < (np.diag(G0) - 1).mean() - 0.005 and abs((np.diag(G0) - 1).mean() - F_ped.mean()) < 0.05
    # 预测
    lam = (1 - cfg["h2"]) / cfg["h2"]
    accs = {"G0": [], "Gs": [], "Gc": []}; rank_corr = []; shift = []
    beta = rng.standard_normal(cfg["m"]) / np.sqrt(2 * p0 * (1 - p0)) * np.sqrt(cfg["h2"] / cfg["m"])
    tr = np.where(gen[sel] == cfg["genotyped_gens"][0])[0]; te = np.where(gen[sel] == cfg["genotyped_gens"][1])[0]
    for r in range(cfg["n_rep"]):
        rr = np.random.default_rng(cfg["seed"] + 1 + r)
        u = (Xs - 2 * p0) @ beta
        y = u + rr.standard_normal(n) * np.sqrt(1 - cfg["h2"])
        outs = {}
        for nm, G in (("G0", G0), ("Gs", Gs), ("Gc", Gc)):
            mu = y[tr].mean()
            outs[nm] = G[np.ix_(te, tr)] @ np.linalg.solve(G[np.ix_(tr, tr)] + lam * np.eye(len(tr)), y[tr] - mu)
            accs[nm].append(np.corrcoef(outs[nm], u[te])[0, 1])
        rank_corr.append(np.corrcoef(outs["G0"], outs["Gc"])[0, 1]); shift.append(float((outs["G0"] - outs["Gs"]).mean()))
    A_ = {k: float(np.mean(v)) for k, v in accs.items()}
    print(f"\nGBLUP 预测准确度（{cfg['n_rep']} 次平均）：G0 {A_['G0']:.3f}，Gs {A_['Gs']:.3f}，Gc {A_['Gc']:.3f}；EBV(G0) 与 EBV(Gc) 相关 {np.mean(rank_corr):.3f}；EBV(G0)−EBV(Gs) 的均值 {np.mean(shift):+.3f}")
    assert max(A_.values()) - min(A_.values()) < 0.02, A_
    json.dump(dict(dA=float(dA), oA=float(oA), a=float(a), b=float(b), regression=dict(G0=r0, Gs=rs, Gc=rc), accuracy=A_, F_ped=float(F_ped.mean()),
                   F_hat_G0=float((np.diag(G0) - 1).mean()), F_hat_Gs=float((np.diag(Gs) - 1).mean())),
              open(HERE / "results" / "ex26_18_grm_vs_pedigree_scaling.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
