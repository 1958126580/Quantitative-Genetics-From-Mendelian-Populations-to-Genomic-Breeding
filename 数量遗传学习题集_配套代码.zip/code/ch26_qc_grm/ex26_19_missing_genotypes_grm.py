#!/usr/bin/env python3
"""习题 26.19  缺失基因型如何改变 GRM：MCAR 与“杂合子更易缺失”(MNAR) 下的填补策略

数据：n 头动物、m 个位点（HWE，包含两个频率有差异的亚群，F_ST=0.04，用于使对角元有变异），真 GRM G* 来自完整基因型。
缺失机制：
  MCAR：每个基因型独立以概率 f 缺失；
  MNAR：杂合子缺失概率为纯合子的 4 倍（模拟杂合子聚类不清而被置空），总体平均缺失率仍为 f。
处理方法：
  (a) 均值填补（缺失处中心化值设为 0，即用 2p 代入），分母仍用 2Σpq；
  (b) 成对完整观测：G_ij = Σ_{k∈O_i∩O_j} W_ik W_jk / Σ_{k∈O_i∩O_j} 2p_kq_k（对每个位点对按可用位点重新标度）；
  (c) 位点“列表删除”：只保留全部动物均有数据的位点（给出保留位点比例）。
指标：平均对角元、非对角元对真值的回归斜率与相关、HE 回归遗传力、GBLUP 预测准确度（真 h²=0.5）。
核验：(1) MCAR 下 (a) 的平均对角元 ≈ (1−f)×真值（相对误差 < 4%），非对角元斜率 ≈ (1−f)²；
      (2) MCAR 下 (b) 的平均对角元与真值相差 < 3%，非对角元斜率在 1 ± 0.06；
      (3) MNAR 下 (b) 的对角元偏差大于 MCAR 下的偏差（f=0.25），说明“成对完整观测”并非总能自动纠正；
      (4) (c) 在 f≥0.10 时保留位点比例 < 10%（几乎无位点可用）；
      (5) 预测准确度：f=0.25 时 (a)、(b) 都不高于完整数据（容许 0.03 波动）。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    n, m = cfg["n"], cfg["m"]
    p0 = rng.uniform(cfg["maf_lo"], cfg["maf_hi"], m)
    sub = np.arange(n) % cfg["n_sub"]
    k = p0 * (1 - cfg["fst"]) / cfg["fst"]
    Ps = np.stack([rng.beta(k, (1 - p0) * (1 - cfg["fst"]) / cfg["fst"]) for _ in range(cfg["n_sub"])]).clip(0.01, 0.99)
    P = Ps[sub]
    X = (rng.random((n, m)) < P).astype(float) + (rng.random((n, m)) < P).astype(float)
    return X, sub


def missing_mask(X, f, mnar, mult, rng):
    if not mnar:
        return rng.random(X.shape) < f
    het = X == 1
    # 令平均缺失率为 f：q_hom = f/(1 + (mult−1)·frac_het)
    frac = het.mean()
    q = f / (1 + (mult - 1) * frac)
    prob = np.where(het, np.minimum(mult * q, 1.0), q)
    return rng.random(X.shape) < prob


def he_h2(y, G):
    z = (y - y.mean()) / y.std(); iu = np.triu_indices(len(y), 1)
    g = G[iu]; gc = g - g.mean()
    return float(np.sum(gc * np.outer(z, z)[iu]) / np.sum(gc * gc))


def acc(G, y, ntr, h2, u):
    tr = np.arange(ntr); te = np.arange(ntr, len(y)); lam = (1 - h2) / h2
    mu = y[tr].mean()
    hat = G[np.ix_(te, tr)] @ np.linalg.solve(G[np.ix_(tr, tr)] + lam * np.eye(ntr), y[tr] - mu)
    return float(np.corrcoef(hat, u[te])[0, 1])


def main():
    cfg = json.load(open(HERE / "data" / "ex26_19_config.json"))
    rng = np.random.default_rng(cfg["seed"]); n, m = cfg["n"], cfg["m"]
    X, sub = simulate(cfg, rng)
    p = X.mean(0) / 2; h = 2 * p * (1 - p); s = h.sum()
    W = X - 2 * p
    Gt = W @ W.T / s; iu = np.triu_indices(n, 1); off_t = Gt[iu]
    beta = rng.standard_normal(m) / np.sqrt(h) * np.sqrt(cfg["h2"] / m)
    u = W @ beta
    ys = [u + np.random.default_rng(cfg["seed"] + r).standard_normal(n) * np.sqrt(1 - cfg["h2"]) for r in range(cfg["n_rep"])]
    h2t = np.mean([he_h2(y, Gt) for y in ys]); acct = np.mean([acc(Gt, y, cfg["n_train"], cfg["h2"], u) for y in ys])
    print("=" * 100)
    print(f"习题 26.19  缺失基因型：n={n}，m={m}；完整数据：平均对角元 {np.diag(Gt).mean():.4f}，HE ĥ² {h2t:.3f}，GBLUP 准确度 {acct:.3f}")
    print("=" * 100)
    print(f"{'机制':<5}{'f':>5}{'方法':<14}{'平均对角':>9}{'对角/真':>8}{'非对角斜率':>10}{'非对角相关':>10}{'HE h²':>7}{'准确度':>8}{'保留位点':>9}")
    rows = []; res = {}
    for mnar in (False, True):
        for f in cfg["miss_rates"]:
            M = missing_mask(X, f, mnar, cfg["het_multiplier"], rng)
            obs = ~M
            Wm = np.where(obs, W, 0.0)
            # (a) 均值填补
            Ga = Wm @ Wm.T / s
            # (b) 成对完整
            O = obs.astype(float)
            num = Wm @ Wm.T; den = (O * h) @ O.T
            Gb = num / den
            # (c) 列表删除
            keep = obs.all(axis=0); kfrac = float(keep.mean())
            if keep.sum() > 20:
                Wk = W[:, keep]; Gc = Wk @ Wk.T / h[keep].sum()
            else:
                Gc = None
            for nm, G in (("(a) 均值填补", Ga), ("(b) 成对完整", Gb), ("(c) 列表删除", Gc)):
                if G is None:
                    print(f"{'MNAR' if mnar else 'MCAR':<5}{f:>5.2f} {nm:<14}{'—':>9}{'—':>8}{'—':>10}{'—':>10}{'—':>7}{'—':>8}{kfrac:>9.3f}")
                    res[(mnar, f, nm[:3])] = None
                    continue
                d = np.diag(G).mean(); dr = d / np.diag(Gt).mean()
                sl = np.cov(off_t, G[iu])[0, 1] / off_t.var(); co = np.corrcoef(off_t, G[iu])[0, 1]
                hh = np.mean([he_h2(y, G) for y in ys]); ac = np.mean([acc(G, y, cfg["n_train"], cfg["h2"], u) for y in ys])
                print(f"{'MNAR' if mnar else 'MCAR':<5}{f:>5.2f} {nm:<14}{d:>9.4f}{dr:>8.3f}{sl:>10.3f}{co:>10.3f}{hh:>7.3f}{ac:>8.3f}{(kfrac if nm[1]=='c' else 1.0):>9.3f}")
                res[(mnar, f, nm[:3])] = dict(diag_ratio=float(dr), slope=float(sl), corr=float(co), he=float(hh), acc=float(ac), keep=kfrac)
                rows.append(dict(mechanism="MNAR" if mnar else "MCAR", f=f, method=nm, **res[(mnar, f, nm[:3])]))
    # 核验
    for f in cfg["miss_rates"]:
        ra = res[(False, f, "(a)")]; rb = res[(False, f, "(b)")]
        assert abs(ra["diag_ratio"] - (1 - f)) < 0.04, (f, ra)
        assert abs(ra["slope"] - (1 - f) ** 2) < 0.06, (f, ra)
        assert abs(rb["diag_ratio"] - 1) < 0.03, (f, rb)
        assert abs(rb["slope"] - 1) < 0.06, (f, rb)
    f = 0.25
    assert abs(res[(True, f, "(b)")]["diag_ratio"] - 1) > abs(res[(False, f, "(b)")]["diag_ratio"] - 1), (res[(True, f, "(b)")], res[(False, f, "(b)")])
    assert res[(False, 0.10, "(c)")] is None or res[(False, 0.10, "(c)")]["keep"] < 0.1
    assert res[(False, f, "(a)")]["acc"] < acct + 0.03 and res[(False, f, "(b)")]["acc"] < acct + 0.03
    json.dump(dict(full=dict(diag=float(np.diag(Gt).mean()), he=float(h2t), acc=float(acct)), rows=rows), open(HERE / "results" / "ex26_19_missing_genotypes_grm.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
