#!/usr/bin/env python3
"""习题 26.17  低深度测序：基因型似然、后验剂量与关系矩阵的偏倚及对角元校正

模型：真实基因型 x∈{0,1,2}（HWE，频率 p 已知）；覆盖 k~Poisson(λ) 条读段，每条读段以概率 x/2 取到 ALT 等位基因，
      并以错误率 ε 被读错（观测 ALT 概率 π_x = (x/2)(1−ε) + (1−x/2)ε）。
后验：P(x | 读段) ∝ HWE 先验 × Π 似然，剂量 d = E[x|·]，不确定度 v = Var(x|·)。
比较的 GRM（按真频率中心化，分母 2Σpq）：
  (a) 真基因型 G*；(b) 最佳猜测（后验众数）的硬调用；(c) 后验剂量 G_d；(d) 对角元校正 G_d^c = G_d + diag(Σ_j v_ij)/s。
核验：(1) 剂量是校准的：真值对 d 的回归斜率在每个深度均在 1±0.05；
      (2) 随深度增加，剂量 R² 单调增，GRM 非对角元与真值的相关单调增；
      (3) G_d 的平均对角元系统低于真值，校正后与真值相差 < 1.5%（所有深度）；
      (4) 硬调用在低深度的非对角元回归斜率低于剂量（更强的衰减或噪声）；
      (5) 非对角元相关在 λ=20 时 > 0.95；GBLUP 预测准确度随深度不下降（容许 0.03 波动）。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg, lam, rng, p, X):
    n, m = X.shape; eps = cfg["eps"]
    k = rng.poisson(lam, (n, m))
    pi = (X / 2.0) * (1 - eps) + (1 - X / 2.0) * eps
    alt = rng.binomial(k, pi)
    # 对数似然（逐基因型）
    ll = np.empty((3, n, m))
    for g in range(3):
        pg = (g / 2.0) * (1 - eps) + (1 - g / 2.0) * eps
        ll[g] = alt * np.log(pg) + (k - alt) * np.log(1 - pg)
    prior = np.stack([(1 - p) ** 2, 2 * p * (1 - p), p ** 2])[:, None, :]
    lw = ll + np.log(prior)
    lw -= lw.max(0)
    w = np.exp(lw); w /= w.sum(0)
    d = w[1] + 2 * w[2]
    v = w[1] + 4 * w[2] - d ** 2
    hard = np.argmax(w, axis=0).astype(float)
    return d, v, hard, w


def grm(D, p, s):
    W = D - 2 * p
    return W @ W.T / s


def gblup_accuracy(G, y, ntr, h2):
    n = len(y); tr = np.arange(ntr); te = np.arange(ntr, n)
    lam = (1 - h2) / h2
    Gtt = G[np.ix_(tr, tr)]
    mu = y[tr].mean()
    u = G[np.ix_(te, tr)] @ np.linalg.solve(Gtt + lam * np.eye(ntr), y[tr] - mu)
    return float(np.corrcoef(u, y[te])[0, 1])


def main():
    cfg = json.load(open(HERE / "data" / "ex26_17_config.json"))
    rng = np.random.default_rng(cfg["seed"]); n, m = cfg["n"], cfg["m"]
    p = rng.uniform(cfg["maf_min"], 0.5, m)
    X = (rng.random((n, m)) < p).astype(float) + (rng.random((n, m)) < p).astype(float)
    s = 2 * np.sum(p * (1 - p))
    Gt = grm(X, p, s)
    iu = np.triu_indices(n, 1)
    off_t = Gt[iu]
    beta = rng.standard_normal(m) / np.sqrt(2 * p * (1 - p)) * np.sqrt(cfg["h2"] / m)
    gv = (X - 2 * p) @ beta
    print("=" * 96)
    print(f"习题 26.17  低深度剂量 GRM：n={n}，m={m}，ε={cfg['eps']}；真 G 平均对角元 {np.diag(Gt).mean():.4f}，非对角元 SD {off_t.std():.4f}")
    print("=" * 96)
    print(f"{'深度λ':>6} {'剂量R²':>7} {'校准斜率':>8} {'硬调用R²':>8} | {'对角元均值：剂量':>13} {'校正后':>7} {'硬调用':>7} | {'非对角相关：剂量':>14} {'硬调用':>7} {'斜率：剂量':>9} {'硬调用':>7} | {'GBLUP 准确度 真/剂量/硬':>20}")
    rows = []; r2s = []; offcor = []
    for lam in cfg["depths"]:
        d, v, hard, w = simulate(cfg, lam, rng, p, X)
        # SNP 水平的剂量 R² 与校准斜率（汇总）
        xc = X - X.mean(); dc = d - d.mean()
        r2 = float(np.corrcoef(X.ravel(), d.ravel())[0, 1] ** 2)
        slope = float((xc * dc).sum() / (dc * dc).sum())
        r2h = float(np.corrcoef(X.ravel(), hard.ravel())[0, 1] ** 2)
        Gd = grm(d, p, s); Gh = grm(hard, p, s)
        Gc = Gd + np.diag(v.sum(1) / s)
        offd, offh = Gd[iu], Gh[iu]
        cd, ch = np.corrcoef(offd, off_t)[0, 1], np.corrcoef(offh, off_t)[0, 1]
        sd = np.cov(offd, off_t)[0, 1] / off_t.var(); sh = np.cov(offh, off_t)[0, 1] / off_t.var()
        acc = []
        for r in range(cfg["n_rep_pred"]):
            rr = np.random.default_rng(cfg["seed"] + 50 + r)
            y = gv + rr.standard_normal(n) * np.sqrt(1 - cfg["h2"])
            acc.append([gblup_accuracy(G, y, cfg["n_train"], cfg["h2"]) for G in (Gt, Gc, Gh)])
        acc = np.mean(acc, axis=0)
        dg, dc_, dh = np.diag(Gd).mean(), np.diag(Gc).mean(), np.diag(Gh).mean()
        print(f"{lam:>6.1f} {r2:>7.3f} {slope:>8.3f} {r2h:>8.3f} | {dg:>13.4f} {dc_:>7.4f} {dh:>7.4f} | {cd:>14.3f} {ch:>7.3f} {sd:>9.3f} {sh:>7.3f} | {acc[0]:.3f}/{acc[1]:.3f}/{acc[2]:.3f}")
        rows.append(dict(depth=lam, dosage_r2=r2, calib_slope=slope, hard_r2=r2h, diag_dosage=float(dg), diag_corrected=float(dc_), diag_hard=float(dh),
                         off_corr_dosage=float(cd), off_corr_hard=float(ch), off_slope_dosage=float(sd), off_slope_hard=float(sh), gblup_true=float(acc[0]), gblup_dosage_corrected=float(acc[1]), gblup_hard=float(acc[2])))
        assert abs(slope - 1) < 0.05, (lam, slope)
        assert abs(dc_ - np.diag(Gt).mean()) / np.diag(Gt).mean() < 0.015, (lam, dc_, np.diag(Gt).mean())
        r2s.append(r2); offcor.append(cd)
    assert all(r2s[i] < r2s[i + 1] for i in range(len(r2s) - 1)), r2s
    assert all(offcor[i] < offcor[i + 1] for i in range(len(offcor) - 1)), offcor
    assert rows[0]["diag_dosage"] < np.diag(Gt).mean() * 0.9
    assert rows[0]["off_slope_hard"] < rows[0]["off_slope_dosage"] + 0.05 or rows[0]["off_corr_hard"] < rows[0]["off_corr_dosage"]
    assert rows[-1]["off_corr_dosage"] > 0.95
    accs = [r["gblup_dosage_corrected"] for r in rows]
    assert accs[-1] > accs[0] - 0.03
    json.dump(dict(true_diag=float(np.diag(Gt).mean()), rows=rows), open(HERE / "results" / "ex26_17_lowpass_dosage_grm.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
