#!/usr/bin/env python3
"""习题 26.16  哈迪—温伯格检验作为质量控制：精确检验、卡方检验、分层与等位基因脱扣的检出能力

内容：
  (1) 精确检验（Wigginton, Cutler & Abecasis 2005）的自写实现，与完全枚举法核对（小样本）；
  (2) 一类错误：稀有等位基因下 Pearson 卡方检验与精确检验的实际水平（α=0.001）；
  (3) 检验效能：等位基因脱扣（杂合子被误判为纯合子的比例 d）造成的杂合子缺失，随 MAF 与 d 的检出率；
  (4) 群体分层（Wahlund 效应）：n_sub 个亚群各自平衡，频率差异使混合群体杂合子缺失 ≈ F_ST，检验是否把分层误当作分型错误；
  (5) 在标准阈值 p<α 下，估计不同 MAF 区间被误剔除的真实位点比例。
核验：(a) 精确检验的 p 值与枚举法在 n=30 的全部杂合数下一致（相对 1e-9）；
      (b) 稀有等位基因（MAF=0.01）卡方检验的实际水平高于/低于名义水平的方向与精确检验给出的保守性一致，并报告两者；
      (c) 脱扣检出率随 d 单调增、随 MAF 增大单调增（MAF 0.3 与 0.5 在样本波动内）；
      (d) Wahlund 效应下杂合度缺失 F=1 − H_obs/H_exp 近似 F_ST(K−1)/K（K 为亚群数；误差 < 0.15 F_ST）。
"""
from __future__ import annotations
import json
from math import lgamma, log, exp
from pathlib import Path
import numpy as np
from scipy.stats import chi2

HERE = Path(__file__).resolve().parent


def hwe_exact(n_ab: int, n_aa: int, n_bb: int) -> float:
    """Wigginton 等（2005）的精确检验：返回双侧 p 值（概率不大于观测的总和）。"""
    n = n_ab + n_aa + n_bb
    n_a = 2 * n_aa + n_ab; n_b = 2 * n - n_a
    rare = min(n_a, n_b)
    # 杂合数的取值范围：与稀有等位基因数同奇偶
    probs = np.zeros(rare + 1)
    mid = rare * (2 * n - rare) // (2 * n)
    if (mid % 2) != (rare % 2):
        mid += 1
    probs[mid] = 1.0
    curr_hets = mid
    curr_homr = (rare - mid) // 2; curr_homc = n - mid - curr_homr
    while curr_hets > 1:
        probs[curr_hets - 2] = probs[curr_hets] * curr_hets * (curr_hets - 1) / (4.0 * (curr_homr + 1) * (curr_homc + 1))
        curr_hets -= 2; curr_homr += 1; curr_homc += 1
    curr_hets = mid
    curr_homr = (rare - mid) // 2; curr_homc = n - mid - curr_homr
    while curr_hets <= rare - 2:
        probs[curr_hets + 2] = probs[curr_hets] * 4.0 * curr_homr * curr_homc / ((curr_hets + 2.0) * (curr_hets + 1.0))
        curr_hets += 2; curr_homr -= 1; curr_homc -= 1
    probs /= probs.sum()
    return float(min(1.0, probs[probs <= probs[n_ab] * (1 + 1e-12)].sum()))


def hwe_enum(n_ab, n_aa, n_bb) -> float:
    """完全枚举（对数阶乘）核对：条件于等位基因计数的杂合子数分布。"""
    n = n_ab + n_aa + n_bb; n_a = 2 * n_aa + n_ab
    lp = {}
    for h in range(n_a % 2, min(n_a, 2 * n - n_a) + 1, 2):
        aa = (n_a - h) // 2; bb = n - h - aa
        if aa < 0 or bb < 0:
            continue
        lp[h] = lgamma(n + 1) - lgamma(aa + 1) - lgamma(h + 1) - lgamma(bb + 1) + h * log(2)   # 条件分布：P(h) ∝ n! 2^h/(aa! h! bb!)
    m = max(lp.values())
    w = {h: exp(v - m) for h, v in lp.items()}; Z = sum(w.values())
    pr = {h: v / Z for h, v in w.items()}
    return float(sum(v for v in pr.values() if v <= pr[n_ab] * (1 + 1e-12)))


def chisq_p(n_ab, n_aa, n_bb) -> float:
    n = n_ab + n_aa + n_bb; p = (2 * n_aa + n_ab) / (2 * n); q = 1 - p
    exp_ = np.array([n * p * p, 2 * n * p * q, n * q * q]); obs = np.array([n_aa, n_ab, n_bb], float)
    if np.any(exp_ == 0):
        return 1.0
    return float(chi2.sf(np.sum((obs - exp_) ** 2 / exp_), 1))


def sample_counts(rng, n, p, size):
    return rng.multinomial(n, [p * p, 2 * p * (1 - p), (1 - p) ** 2], size=size)   # (aa, ab, bb)


def main():
    cfg = json.load(open(HERE / "data" / "ex26_16_config.json"))
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n"]; a = cfg["alpha"]; ns = cfg["n_sim"]
    # (1) 核对
    maxrel = 0.0
    for nab in range(0, 31, 2):
        for naa in range(0, (30 - nab) + 1):
            nbb = 30 - nab - naa
            if (2 * naa + nab) < 1 or (2 * nbb + nab) < 1:
                continue
            e, f = hwe_exact(nab, naa, nbb), hwe_enum(nab, naa, nbb)
            maxrel = max(maxrel, abs(e - f) / max(f, 1e-300))
    print("=" * 80)
    print(f"习题 26.16  HWE 检验：n={n}，α={a}，每格 {ns} 次模拟")
    print("=" * 80)
    print(f"(1) 精确检验与枚举法核对（n=30 的全部可能计数，偶数杂合数）：最大相对差 {maxrel:.2e}")
    assert maxrel < 1e-9
    # (2) 一类错误
    print("\n(2) 一类错误（真平衡）：实际水平 = P(p < α)")
    print(f"{'MAF':>6} {'卡方':>9} {'精确':>9}")
    t1 = {}
    for maf in cfg["maf_grid"]:
        C = sample_counts(rng, n, maf, ns)
        pc = np.array([chisq_p(c[1], c[0], c[2]) for c in C]); pe = np.array([hwe_exact(c[1], c[0], c[2]) for c in C])
        t1[maf] = (float((pc < a).mean()), float((pe < a).mean()))
        print(f"{maf:>6.2f} {t1[maf][0]:>9.5f} {t1[maf][1]:>9.5f}")
    assert t1[0.5][1] <= 3 * a, t1
    assert t1[0.01][1] <= a * 1.5
    # (3) 脱扣效能：杂合子以概率 d 被误判为一种纯合子（等概率）
    print("\n(3) 等位基因脱扣的检出率 P(p<α)：杂合子以概率 d 被误判为纯合子")
    print(f"{'MAF':>6} " + " ".join(f"d={d:>4.2f}" for d in cfg["dropout_grid"]))
    pw = np.zeros((len(cfg["maf_grid"]), len(cfg["dropout_grid"])))
    for i, maf in enumerate(cfg["maf_grid"]):
        for j, d in enumerate(cfg["dropout_grid"]):
            C = sample_counts(rng, n, maf, ns // 2)
            lost = rng.binomial(C[:, 1], d); to_a = rng.binomial(lost, 0.5)
            obs = np.column_stack([C[:, 0] + to_a, C[:, 1] - lost, C[:, 2] + lost - to_a])
            pw[i, j] = np.mean([hwe_exact(o[1], o[0], o[2]) < a for o in obs])
        print(f"{maf:>6.2f} " + " ".join(f"{v:>6.3f}" for v in pw[i]))
    assert np.all(np.diff(pw, axis=1) >= -0.02), pw
    assert pw[0, 1] < pw[2, 1] < pw[3, 1] + 0.05 and pw[0, 2] < pw[3, 2], pw
    # (4) Wahlund
    print("\n(4) Wahlund 效应：各亚群平衡，混合后杂合度缺失")
    print(f"{'F_ST':>6} {'F=1−H_obs/H_exp':>16} {'理论 F_ST(K−1)/K':>16} {'检出率 p<α':>11}")
    wahl = []
    for fst in cfg["fst_grid"]:
        P0 = rng.uniform(0.2, 0.5, 200); Fs, det = [], []
        for s in range(200):
            p0 = P0[s]
            if fst == 0:
                ps = np.full(cfg["n_sub"], p0)
            else:
                k = p0 * (1 - fst) / fst; ps = np.clip(rng.beta(k, (1 - p0) * (1 - fst) / fst, cfg["n_sub"]), 1e-3, 1 - 1e-3)
            cnt = np.zeros(3)
            for pp in ps:
                cnt += rng.multinomial(n // cfg["n_sub"], [pp * pp, 2 * pp * (1 - pp), (1 - pp) ** 2])
            nn = cnt.sum(); pbar = (2 * cnt[0] + cnt[1]) / (2 * nn)
            Fs.append(1 - (cnt[1] / nn) / (2 * pbar * (1 - pbar)))
            det.append(hwe_exact(int(cnt[1]), int(cnt[0]), int(cnt[2])) < a)
        wahl.append((fst, float(np.mean(Fs)), float(np.mean(det))))
        print(f"{fst:>6.2f} {np.mean(Fs):>16.4f} {fst * (1 - 1 / cfg['n_sub']):>16.4f} {np.mean(det):>11.3f}")
    for fst, F, dt in wahl[1:]:
        assert abs(F - fst * (1 - 1 / cfg['n_sub'])) / fst < 0.15, (fst, F)     # K 个子群的样本方差（除以 K）使期望为 F_ST(K−1)/K
    assert wahl[-1][2] > wahl[1][2]
    json.dump(dict(type1=t1, dropout=pw.tolist(), wahlund=wahl), open(HERE / "results" / "ex26_16_hwe_tests.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
