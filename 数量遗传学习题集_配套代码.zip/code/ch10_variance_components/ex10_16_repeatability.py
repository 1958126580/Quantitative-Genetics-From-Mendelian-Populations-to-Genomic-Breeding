#!/usr/bin/env python3
"""习题 10.16  不平衡重复记录的重复力估计：ANOVA（n₀ 校正）与限制最大似然

150 只动物各有 1–5 次记录（不平衡），模型 y_ij = μ + c_i + e_ij，c_i = 育种值 + 永久环境，
Var(c) = V_A + V_PE = 0.40，Var(e) = V_T = 0.60，真实重复力 t = 0.40。
    ANOVA：MSB、MSW 与有效组大小 n₀ = [N − Σ n_i²/N]/(a − 1)，σ̂_c² = (MSB − MSW)/n₀；
    REML：单因素随机模型的限制似然对 (σ_c², σ_e²) 数值最大化（只有一个均值参数，可用解析形式）。
另报告：只有一条记录的动物对重复力估计有无贡献？（对 σ_c²+σ_e² 总和有贡献，对分解无直接贡献）
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent


def reml_oneway(groups):
    """单因素随机模型 REML：V_i = σe² I + σc² J，均值未知。返回 (σc², σe²)。"""
    def nll(theta):
        sc, se = np.exp(theta); ll = 0.0; XtVX = 0.0; XtVy = 0.0; logdet = 0.0; quad = 0.0
        for y in groups:
            n = len(y); lam = se + n * sc
            # V⁻¹ = (I − (sc/λ) J)/se；|V| = se^{n−1} λ
            logdet += (n - 1) * np.log(se) + np.log(lam)
            s1 = y.sum(); XtVX += n / lam; XtVy += s1 / lam
        mu = XtVy / XtVX
        for y in groups:
            n = len(y); lam = se + n * sc; r = y - mu
            quad += (r @ r - sc / lam * r.sum() ** 2) / se
        return 0.5 * (logdet + np.log(XtVX) + quad)
    res = minimize(nll, np.log([0.3, 0.6]), method="Nelder-Mead", options={"xatol": 1e-9, "fatol": 1e-12, "maxiter": 5000})
    return np.exp(res.x)


def main():
    cfg = json.loads((HERE / "data" / "ex10_16_repeat.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); a = cfg["n_animals"]
    ns = rng.choice(cfg["records_per_animal_choices"], size=a, p=cfg["records_prob"])
    c = rng.normal(0, np.sqrt(cfg["VA"] + cfg["VPE"]), a)
    groups = [10 + c[i] + rng.normal(0, np.sqrt(cfg["VT"]), ns[i]) for i in range(a)]
    N = ns.sum(); allv = np.concatenate(groups); gm = allv.mean()
    ssb = sum(len(g) * (g.mean() - gm) ** 2 for g in groups); ssw = sum(((g - g.mean()) ** 2).sum() for g in groups)
    msb, msw = ssb / (a - 1), ssw / (N - a); n0 = (N - np.sum(ns ** 2) / N) / (a - 1)
    sc_a = (msb - msw) / n0; t_a = sc_a / (sc_a + msw)
    sc_r, se_r = reml_oneway(groups); t_r = sc_r / (sc_r + se_r)
    multi = [g for g in groups if len(g) > 1]; sc_m, se_m = reml_oneway(multi)
    print(f"动物 {a} 只，记录 {N} 条，n₀ = {n0:.3f}；单记录动物 {np.sum(ns==1)} 只")
    print(f"ANOVA：MSB = {msb:.4f}，MSW = {msw:.4f}，σ̂c² = {sc_a:.4f}，t̂ = {t_a:.4f}")
    print(f"REML ：σ̂c² = {sc_r:.4f}，σ̂e² = {se_r:.4f}，t̂ = {t_r:.4f}（真值 {(cfg['VA']+cfg['VPE'])/(cfg['VA']+cfg['VPE']+cfg['VT']):.2f}）")
    print(f"剔除单记录动物后 REML：t̂ = {sc_m/(sc_m+se_m):.4f}（σ̂c² = {sc_m:.4f}, σ̂e² = {se_m:.4f}）")
    out = {"N": int(N), "n0": n0, "anova": {"msb": msb, "msw": msw, "sigma_c2": sc_a, "t": t_a}, "reml": {"sigma_c2": sc_r, "sigma_e2": se_r, "t": t_r},
           "reml_multi_only": {"sigma_c2": sc_m, "sigma_e2": se_m, "t": sc_m / (sc_m + se_m)}}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex10_16_repeatability.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
