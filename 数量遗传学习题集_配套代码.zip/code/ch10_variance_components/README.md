# 第10章　遗传方差组分、重复力与性状间相关——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex10_15_pleiotropy_correlation.py
python3 ex10_16_repeatability.py
python3 ex10_17_scale_transformation.py
python3 ex10_18_liability_observed.py
python3 ex10_19_gxe_decomposition.py
python3 ex10_20_genetic_geometry.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex10_15_pleiotropy_correlation.py | 10.15 | 多效性位点如何“合成”遗传协方差：遗传相关的位点数依赖性 |
| ex10_16_repeatability.py | 10.16 | 不平衡重复记录的重复力估计：ANOVA（n₀ 校正）与限制最大似然 |
| ex10_17_scale_transformation.py | 10.17 | 尺度依赖：乘法作用的位点在原始尺度上产生显性与互作，取对数后变为加性 |
| ex10_18_liability_observed.py | 10.18 | 二分类性状：观察尺度与易感性尺度遗传力的换算（Dempster–Lerner 1950；Robertson 1950） |
| ex10_19_gxe_decomposition.py | 10.19 | 基因型×环境互作方差的分解：尺度差异与排序改变（Robertson 1959） |
| ex10_20_genetic_geometry.py | 10.20 | 遗传协方差矩阵的几何：主轴 g_max、可进化性与“最小阻力方向” |
