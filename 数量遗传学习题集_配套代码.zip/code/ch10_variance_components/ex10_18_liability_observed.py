#!/usr/bin/env python3
"""习题 10.18  二分类性状：观察尺度与易感性尺度遗传力的换算（Dempster–Lerner 1950；Robertson 1950）

易感性 ℓ ~ N(0,1)，ℓ > 阈值 T 则患病，发病率 K = 1 − Φ(T)。在易感性尺度遗传力 h_L² 下，0/1 观察尺度遗传力
    h_O² ≈ h_L² · z² / [K(1 − K)]，z = φ(T)
程序：(1) 对不同发病率计算换算系数；(2) 模拟 400 头公畜 × 50 个后代的半同胞资料，按 0/1 记录用 ANOVA 估计
观察尺度 h²（4 倍组内相关），再用公式换算回易感性尺度，与真值 0.30 比较；
(3) 说明发病率越极端，观察尺度遗传力越低，且换算对公式的近似越敏感。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex10_18_threshold.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); h2 = cfg["h2_liability"]; s, n = cfg["n_sires"], cfg["progeny_per_sire"]; out = []
    print(f"易感性尺度 h² = {h2}；{s} 头公畜 × {n} 个后代")
    print(f"{'发病率K':>8s}{'换算系数':>9s}{'理论h²_O':>10s}{'估计h²_O':>10s}{'换算回h²_L':>11s}")
    for K in cfg["incidence_grid"]:
        T = norm.isf(K); z = norm.pdf(T); coef = z * z / (K * (1 - K)); hO = h2 * coef
        sire = rng.normal(0, np.sqrt(h2 / 4), (s, 1)); liab = sire + rng.normal(0, np.sqrt(1 - h2 / 4), (s, n))
        y = (liab > T).astype(float)
        msb = n * np.var(y.mean(1), ddof=1); msw = np.sum((y - y.mean(1, keepdims=True)) ** 2) / (s * (n - 1))
        s2s = (msb - msw) / n; t = s2s / (s2s + msw); hO_hat = 4 * t
        Kh = y.mean(); Th = norm.isf(Kh); hL_hat = hO_hat * Kh * (1 - Kh) / norm.pdf(Th) ** 2
        out.append({"K": K, "coef": coef, "h2_obs_theory": hO, "h2_obs_hat": hO_hat, "h2_liab_back": hL_hat})
        print(f"{K:8.2f}{coef:9.4f}{hO:10.4f}{hO_hat:10.4f}{hL_hat:11.4f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex10_18_liability_observed.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
