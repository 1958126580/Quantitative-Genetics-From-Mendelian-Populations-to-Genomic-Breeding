#!/usr/bin/env python3
"""习题 10.20  遗传协方差矩阵的几何：主轴 g_max、可进化性与“最小阻力方向”

三性状加性协方差矩阵 G。特征分解 G = V Λ Vᵀ：
    最大特征向量 g_max 是遗传变异最多的方向；最小特征值方向最难改变。
沿单位方向 β 的可进化性（Hansen & Houle 2008）  e(β) = βᵀGβ / βᵀβ；
在原始单位不同的性状上应先按表型标准差标准化（G* = D⁻¹ G D⁻¹）。
另计算各方向与 g_max 的夹角，说明为何与 g_max 夹角大的育种目标进展慢。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex10_20_G.json").read_text(encoding="utf-8"))
    G = np.array(cfg["G"]); D = np.diag(cfg["sd_P"]); Gs = np.linalg.inv(D) @ G @ np.linalg.inv(D)
    out = {}
    for label, M in (("原始单位", G), ("表型标准差单位", Gs)):
        w, V = np.linalg.eigh(M); o = np.argsort(-w); w, V = w[o], V[:, o]
        V = V * np.sign(V[0])                      # 统一符号
        assert np.all(w > 0), "G 必须正定"
        print(f"【{label}】特征值 = {np.round(w,4)}，第一主轴解释 {w[0]/w.sum()*100:.1f}% 遗传方差")
        print("  g_max =", np.round(V[:, 0], 4), "；最小方向 =", np.round(V[:, -1], 4))
        res = {"eigvals": w.tolist(), "gmax": V[:, 0].tolist(), "gmin": V[:, -1].tolist(), "directions": {}}
        for name, b in cfg["directions"].items():
            b = np.array(b, float); b = b / np.linalg.norm(b); e = float(b @ M @ b)
            ang = float(np.degrees(np.arccos(abs(b @ V[:, 0]))))
            res["directions"][name] = {"evolvability": e, "angle_to_gmax": ang}
            print(f"  方向“{name}”：e(β) = {e:.4f}，与 g_max 夹角 {ang:.1f}°")
        out[label] = res
    sd = np.sqrt(np.diag(G)); R = G / np.outer(sd, sd); print("遗传相关矩阵 =\n", np.round(R, 3)); out["rA"] = R.tolist()
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex10_20_genetic_geometry.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
