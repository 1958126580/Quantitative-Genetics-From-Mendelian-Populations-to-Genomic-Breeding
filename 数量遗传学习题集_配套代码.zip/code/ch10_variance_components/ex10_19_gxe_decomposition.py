#!/usr/bin/env python3
"""习题 10.19  基因型×环境互作方差的分解：尺度差异与排序改变（Robertson 1959）

两环境中同一组基因型的遗传值 (g1, g2)，标准差 σ1、σ2，遗传相关 r_g。双因素方差分析中的互作方差
    V_GE = ½(σ1 − σ2)² + σ1σ2(1 − r_g)
第一项为“尺度效应”（不改变排序），第二项为“排序改变”（真正影响选择）。程序：
    (1) 三种情景下计算两部分及其比例；
    (2) 模拟 30 个基因型，统计“在环境 1 中选出的前 5 名”在环境 2 中仍为前 5 名的平均个数，
        说明只有第二部分会降低跨环境选择的一致性。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex10_19_gxe.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n, k = cfg["n_genotypes"], cfg["top_k"]; out = {}
    print(f"{'情景':<10s}{'V_GE':>8s}{'尺度项':>8s}{'排序项':>8s}{'前5名重合数':>12s}")
    for name, sc in cfg["scenarios"].items():
        s1, s2, r = sc["sd1"], sc["sd2"], sc["rg"]
        scale = 0.5 * (s1 - s2) ** 2; rank = s1 * s2 * (1 - r); VGE = scale + rank
        # 核对：V_GE = 两环境遗传方差的平均 − 跨环境遗传协方差（基因型主效方差）
        cov = np.array([[s1 * s1, r * s1 * s2], [r * s1 * s2, s2 * s2]])
        vge_direct = 0.5 * (cov[0, 0] + cov[1, 1]) - cov[0, 1]
        assert np.isclose(vge_direct, VGE), "Robertson 分解核对失败"
        overlap = []
        L = np.linalg.cholesky(cov + 1e-12 * np.eye(2))
        for _ in range(cfg["reps"]):
            g = (L @ rng.standard_normal((2, n))).T
            overlap.append(len(set(np.argsort(-g[:, 0])[:k]) & set(np.argsort(-g[:, 1])[:k])))
        out[name] = {"VGE": VGE, "scale_part": scale, "rank_part": rank, "rank_share": rank / VGE if VGE > 0 else 0.0, "mean_overlap_top5": float(np.mean(overlap))}
        print(f"{name:<10s}{VGE:8.3f}{scale:8.3f}{rank:8.3f}{np.mean(overlap):12.2f}")
    print(f"对照：两环境完全独立（r_g = 0）时期望重合数 = {k*k/n:.2f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex10_19_gxe_decomposition.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
