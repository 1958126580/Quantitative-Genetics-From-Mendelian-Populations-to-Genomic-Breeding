#!/usr/bin/env python3
"""习题 10.17  尺度依赖：乘法作用的位点在原始尺度上产生显性与互作，取对数后变为加性

三个不连锁位点按乘法作用：y = μ₀ Π_l (1 + e_l)^{x_l} · exp(ε)。在对数尺度上
    log y = log μ₀ + Σ x_l log(1 + e_l) + ε  —— 完全加性，h² 可解析计算；
在原始尺度上，同样的遗传变异表现出“显性”与“上位”方差，且环境方差随均值增大（异方差）。
程序：(1) 精确枚举 27 种多位点基因型（HWE、连锁平衡），在原始尺度上做正交分解得到 V_A、V_D、V_I；
      (2) 用大样本模拟加入环境误差，比较 Box–Cox 变换 λ = 1, 0.5, 0, −0.5 下的“遗传力”与加性比例；
      (3) 说明为什么“遗传力”与“显性/上位比例”是尺度依赖的量。
"""
from __future__ import annotations
import json
from itertools import product
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def boxcox(y, lam):
    return np.log(y) if lam == 0 else (y ** lam - 1) / lam


def decompose(values, freqs, X):
    """以加权最小二乘把 values 投影到“各位点剂量（加性）”空间，剩余视为非加性。"""
    w = freqs / freqs.sum(); M = w @ values; VG = w @ (values - M) ** 2
    D = np.column_stack([np.ones(len(values)), X]); beta = np.linalg.solve(D.T @ (w[:, None] * D), D.T @ (w * values))
    fit = D @ beta; VA = w @ (fit - M) ** 2
    # 显性：加入各位点杂合指示（与剂量一起）后增加的部分
    H = (X == 1).astype(float); D2 = np.column_stack([D, H]); b2 = np.linalg.solve(D2.T @ (w[:, None] * D2), D2.T @ (w * values))
    VAD = w @ (D2 @ b2 - M) ** 2
    return M, VG, VA, VAD - VA, VG - VAD


def main():
    cfg = json.loads((HERE / "data" / "ex10_17_scale.json").read_text(encoding="utf-8"))
    loci = cfg["loci"]; L = len(loci); mu0 = cfg["baseline"]
    X = np.array(list(product([0, 1, 2], repeat=L)), float)
    f = np.ones(len(X))
    for l, lc in enumerate(loci):
        p = lc["p"]; fl = np.array([(1 - p) ** 2, 2 * p * (1 - p), p * p]); f *= fl[X[:, l].astype(int)]
    gm = mu0 * np.prod([(1 + lc["effect"]) ** X[:, l] for l, lc in enumerate(loci)], axis=0)
    M, VG, VA, VD, VI = decompose(gm, f, X)
    print(f"原始尺度遗传值：均值 {M:.3f}，V_G = {VG:.4f}，V_A = {VA:.4f}（{VA/VG*100:.2f}%），V_D = {VD:.4f}，V_I = {VI:.4f}")
    Ml, VGl, VAl, VDl, VIl = decompose(np.log(gm), f, X)
    print(f"对数尺度遗传值：V_G = {VGl:.5f}，V_A = {VAl:.5f}（{VAl/VGl*100:.2f}%），V_D = {VDl:.2e}，V_I = {VIl:.2e}")
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n_sim"]
    idx = rng.choice(len(X), size=n, p=f / f.sum()); eps = rng.normal(0, cfg["env_cv"], n)
    y = gm[idx] * np.exp(eps); out = {"raw": {"M": M, "VG": VG, "VA": VA, "VD": VD, "VI": VI}, "log": {"VG": VGl, "VA": VAl, "VD": VDl, "VI": VIl}, "boxcox": {}}
    print(f"{'λ':>5s}{'h²(广义)':>10s}{'V_A/V_G':>9s}{'残差方差与均值相关':>18s}")
    for lam in cfg["box_cox_lambdas"]:
        t = boxcox(y, lam); tg = boxcox(gm, lam)
        _, VGt, VAt, _, _ = decompose(tg, f, X)
        # 环境方差：t 与遗传值变换之差的方差（近似，因变换非线性）
        resid = t - tg[idx]; H2 = np.var(tg[idx]) / np.var(t)
        bins = np.quantile(gm[idx], [0, 0.25, 0.5, 0.75, 1]); grp = np.digitize(gm[idx], bins[1:-1])
        mv = [resid[grp == k].var() for k in range(4)]; mm = [t[grp == k].mean() for k in range(4)]
        corr = float(np.corrcoef(mm, mv)[0, 1])
        out["boxcox"][str(lam)] = {"H2": float(H2), "VA_over_VG": float(VAt / VGt), "meanvar_corr": corr}
        print(f"{lam:5.1f}{H2:10.4f}{VAt/VGt:9.4f}{corr:18.3f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex10_17_scale_transformation.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
