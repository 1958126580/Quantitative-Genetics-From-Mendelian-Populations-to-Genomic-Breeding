#!/usr/bin/env python3
"""习题 10.15  多效性位点如何“合成”遗传协方差：遗传相关的位点数依赖性

L 个独立（连锁平衡）的加性位点，第 l 个位点对两性状的平均效应 (α_1l, α_2l) 来自相关系数 ρ 的二元正态，
频率 p_l ~ U(0.05, 0.5)。遗传协方差矩阵
    G = Σ_l 2 p_l q_l [α_1l, α_2l]ᵀ[α_1l, α_2l]
遗传相关 r_A = G_12 / sqrt(G_11 G_22) 是以 2pq 为权的效应相关。程序对 L = 5…1000 各模拟 2000 次：
    (1) r_A 的均值与标准差（位点少时 r_A 波动极大，可正可负）；
    (2) 验证 E(G_12)/E(G_11) = ρ（效应方差相同时）；
    (3) 说明“r_A ≈ 0 不意味着没有多效性”与“少数大效应位点主导时 r_A 不稳定”的含义。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex10_15_pleiotropy.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); rho = cfg["effect_corr"]; s1, s2 = cfg["effect_sd"]
    C = np.array([[s1 * s1, rho * s1 * s2], [rho * s1 * s2, s2 * s2]]); Lc = np.linalg.cholesky(C); out = []
    print(f"效应相关 ρ = {rho}")
    print(f"{'位点数':>6s}{'r_A 均值':>10s}{'r_A 标准差':>11s}{'r_A<0 比例':>11s}{'E(G12)/E(G11)':>15s}")
    for L in cfg["n_loci_grid"]:
        rs, g12, g11 = [], [], []
        for _ in range(cfg["reps"]):
            al = (Lc @ rng.standard_normal((2, L))).T; p = rng.uniform(*cfg["maf_range"], L); w = 2 * p * (1 - p)
            G = (al * w[:, None]).T @ al
            rs.append(G[0, 1] / np.sqrt(G[0, 0] * G[1, 1])); g12.append(G[0, 1]); g11.append(G[0, 0])
        rs = np.array(rs)
        row = {"L": L, "rA_mean": float(rs.mean()), "rA_sd": float(rs.std()), "frac_negative": float(np.mean(rs < 0)), "ratio": float(np.mean(g12) / np.mean(g11))}
        out.append(row)
        print(f"{L:6d}{row['rA_mean']:10.4f}{row['rA_sd']:11.4f}{row['frac_negative']:11.4f}{row['ratio']:15.4f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex10_15_pleiotropy_correlation.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
