#!/usr/bin/env python3
"""习题 23.20  方差不确定性如何进入育种值与选种决策

沿用习题 23.19 的公畜资料与二维格点后验（先验 flat_var 与 informative 两种）。
对每个格点 (σ_s²,σ_w²)，条件 BLUP ŝ(σ) 与预测误差协方差 PEV(σ) 已知，
后验预测分布为混合：E(s|y)=Σ_w ŝ(σ)，Var(s|y)=Σ_w PEV(σ) + Var_w[ŝ(σ)]（全方差公式）。
比较：
  (a) 插值 REML 点估计的 ŝ 与 PEV（名义误差）；
  (b) 积分方差不确定性后的后验均值与总方差；两者之比给出“方差不确定性的附加误差倍数”；
  (c) 候选公畜 A 优于 B 的概率  P(s_A > s_B | y) = Σ_w Φ(Δŝ(σ)/√PEV_Δ(σ))，与插值法的 Φ(Δŝ/√PEV_Δ) 比较；
  (d) 前 3 名的集合稳定性：按后验均值与按插值估计的差异。
核验：全方差公式与对后验抽样的直接模拟一致。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm
import importlib.util

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("ex19", HERE / "ex23_19_bayes_variance.py")
ex19 = importlib.util.module_from_spec(spec); spec.loader.exec_module(ex19)


def blup_pev(X, Z, y, ss2, sw2):
    p = X.shape[1]; S = Z.shape[1]
    lam = sw2 / ss2
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * np.eye(S)]])
    Ci = np.linalg.inv(C)
    th = Ci @ np.r_[X.T @ y, Z.T @ y]
    return th[p:], sw2 * Ci[p:, p:]


def main():
    d, X, Z, y = ex19.load()
    rng = np.random.default_rng(d["seed"] + 1)
    S = Z.shape[1]
    reml = ex19.reml_estimate(X, Z, y)
    s_hat, pev_mat = blup_pev(X, Z, y, *reml)
    order = np.argsort(-s_hat)
    A, B, Cc = order[0], order[1], order[2]
    n_s = Z.sum(0)
    out = {"reml": reml.tolist(), "priors": {}}
    print("=" * 88)
    print("习题 23.20  方差不确定性与选种决策  REML σ_s²=%.3f σ_w²=%.3f" % tuple(reml))
    print("=" * 88)
    for pname in ("flat_var", "informative"):
        a, b, w, LL = ex19.grid_posterior(X, Z, y, d["priors"][pname], d["grid_s_range"], d["grid_e_range"], 90)
        # 仅保留累计 99.9% 的格点以提速
        idx = np.argwhere(w > 1e-7 * w.max())
        ws = np.array([w[i, j] for i, j in idx]); ws /= ws.sum()
        M = np.empty((len(ws), S)); V = np.empty((len(ws), S, S))
        for k, (i, j) in enumerate(idx):
            M[k], V[k] = blup_pev(X, Z, y, a[i], b[j])
        mean_post = ws @ M
        within = np.einsum("k,kij->ij", ws, V)
        between = (M - mean_post).T @ ((M - mean_post) * ws[:, None])
        var_post = np.diag(within + between)
        var_plug = np.diag(pev_mat)
        ratio = var_post / var_plug
        # 候选比较
        def p_better(i, j):
            dm = M[:, i] - M[:, j]
            dv = V[:, i, i] + V[:, j, j] - 2 * V[:, i, j]
            return float(np.sum(ws * norm.cdf(dm / np.sqrt(dv))))
        plug_dm = s_hat[A] - s_hat[B]; plug_dv = pev_mat[A, A] + pev_mat[B, B] - 2 * pev_mat[A, B]
        pAB_plug = float(norm.cdf(plug_dm / np.sqrt(plug_dv))); pAB_post = p_better(A, B)
        pAC_plug = float(norm.cdf((s_hat[A] - s_hat[Cc]) / np.sqrt(pev_mat[A, A] + pev_mat[Cc, Cc] - 2 * pev_mat[A, Cc]))); pAC_post = p_better(A, Cc)
        top3_plug = set(order[:3].tolist()); top3_post = set(np.argsort(-mean_post)[:3].tolist())
        # 直接模拟核验全方差公式
        k_draw = rng.choice(len(ws), 40000, p=ws)
        sim = np.empty((40000, 2))
        for t_, k in enumerate(k_draw[:40000]):
            pass
        # 向量化：对每个格点抽 s_A 与 s_B 的条件正态
        cnt = np.bincount(k_draw, minlength=len(ws))
        samples = []
        for k in np.nonzero(cnt)[0]:
            Sg = V[k][np.ix_([A, B], [A, B])]
            samples.append(rng.multivariate_normal(M[k][[A, B]], Sg, cnt[k]))
        samples = np.vstack(samples)
        var_sim_A = samples[:, 0].var(); mean_sim_A = samples[:, 0].mean()
        assert abs(var_sim_A - var_post[A]) / var_post[A] < 0.03, (var_sim_A, var_post[A])
        assert abs(mean_sim_A - mean_post[A]) < 0.03
        p_sim = float(np.mean(samples[:, 0] > samples[:, 1]))
        assert abs(p_sim - pAB_post) < 0.01
        print(f"\n先验 {pname}：")
        print(f"  公畜 A={A+1}(n={int(n_s[A])})、B={B+1}(n={int(n_s[B])})、C={Cc+1}(n={int(n_s[Cc])})")
        print(f"  ŝ（插值 REML）A={s_hat[A]:.3f} B={s_hat[B]:.3f}；后验均值 A={mean_post[A]:.3f} B={mean_post[B]:.3f}")
        print(f"  PEV（插值）A={var_plug[A]:.3f}；后验总方差 A={var_post[A]:.3f}（比值 {ratio[A]:.3f}）；平均比值 {ratio.mean():.3f}，最大 {ratio.max():.3f}")
        print(f"  P(A>B)：插值 {pAB_plug:.3f}，后验 {pAB_post:.3f}（模拟 {p_sim:.3f}）；P(A>C)：插值 {pAC_plug:.3f}，后验 {pAC_post:.3f}")
        print(f"  前3名：插值 {sorted(i+1 for i in top3_plug)}，后验均值 {sorted(i+1 for i in top3_post)}")
        print(f"  收缩：后验均值/插值 ŝ 的相关 {np.corrcoef(mean_post, s_hat)[0,1]:.4f}；后验均值平均模长比 {np.abs(mean_post).mean()/np.abs(s_hat).mean():.3f}")
        out["priors"][pname] = dict(A=int(A) + 1, B=int(B) + 1, s_plug_A=float(s_hat[A]), s_post_A=float(mean_post[A]), pev_plug_A=float(var_plug[A]),
                                    var_post_A=float(var_post[A]), ratio_mean=float(ratio.mean()), ratio_max=float(ratio.max()),
                                    pAB_plug=pAB_plug, pAB_post=pAB_post, pAC_plug=pAC_plug, pAC_post=pAC_post,
                                    top3_plug=sorted(int(i) + 1 for i in top3_plug), top3_post=sorted(int(i) + 1 for i in top3_post),
                                    shrink_ratio=float(np.abs(mean_post).mean() / np.abs(s_hat).mean()))
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex23_20_variance_uncertainty_decision.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
