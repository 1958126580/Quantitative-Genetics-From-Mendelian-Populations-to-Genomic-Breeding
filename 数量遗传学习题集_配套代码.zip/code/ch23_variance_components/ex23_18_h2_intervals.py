#!/usr/bin/env python3
"""习题 23.18  遗传力的区间估计：delta 法、轮廓似然与参数自助法的覆盖率

公畜模型（平衡）：y_ij = μ + s_i + w_ij，g 头公畜、每头 n 个后代。σ_s²、σ_w²，
h² = 4σ_s²/(σ_s²+σ_w²) = 4t，t = σ_s²/(σ_s²+σ_w²) 为组内相关。
REML 对数似然只依赖 SSB~θχ²_{g−1}、SSW~σ_w²χ²_{g(n−1)}，θ=σ_w²+nσ_s²。
  - delta 法：用 REML 期望信息逆矩阵和 h² 的梯度，区间 ĥ² ± 1.96 SE；
  - 轮廓似然：固定 t，σ²=σ_s²+σ_w² 的最大化有闭式 u(t)=(SSB/c₁+SSW/c₂)/(gn−1)，c₁=1−t+nt，c₂=1−t，
    区间 {t : 2[ℓ_max − ℓ_p(t)] ≤ χ²_{1,0.95}}；
  - 参数自助法：以 REML 估计作为真值，重新生成 SSB、SSW，取 ĥ² 的 2.5%/97.5% 分位数。
对 (g, n) 的三种设计、600 次重复：覆盖率、平均宽度与区间下端为 0 的频率。
核验：t=0 边界时的行为；资料大时三种方法一致。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent


def reml_t(SSW, SSB, g, n):
    msw = SSW / (g * (n - 1)); msb = SSB / (g - 1)
    ss = np.maximum((msb - msw) / n, 0.0)
    sw = np.where(ss > 0, msw, (SSW + SSB) / (g * n - 1))
    return ss, sw


def prof_ll(t, SSW, SSB, g, n):
    """t：形状 (G,) 的网格；SSW、SSB：标量。返回 ℓ_p(t)。"""
    c1 = 1 - t + n * t; c2 = 1 - t
    u = (SSB / c1 + SSW / c2) / (g * n - 1)
    return -0.5 * ((g - 1) * np.log(c1 * u) + SSB / (c1 * u) + g * (n - 1) * np.log(c2 * u) + SSW / (c2 * u))


def main():
    cfg = json.load(open(HERE / "data" / "ex23_18_ci.json"))
    rng = np.random.default_rng(cfg["seed"])
    t0 = cfg["h2_true"] / 4
    grid = np.linspace(0, 0.25, cfg["grid"])
    crit = stats.chi2.ppf(0.95, 1)
    print("=" * 92)
    print("习题 23.18  h² 的区间估计（真 h²=%.2f，σ_s²+σ_w²=1，%d 次重复）" % (cfg["h2_true"], cfg["n_rep"]))
    print("=" * 92)
    print(f"{'g':>4}{'n':>3} | {'方法':<8}{'覆盖率':>8}{'平均宽度':>9}{'下端=0':>8}{'ĥ² 偏倚':>9}")
    out = []
    for g, n in cfg["designs"]:
        ss, sw = 4 * 0, 0
        res = {m: dict(cov=[], width=[], lo0=[]) for m in ("delta", "profile", "boot")}
        hs = []
        for r in range(cfg["n_rep"]):
            theta = (1 - t0) + n * t0
            SSB = theta * rng.chisquare(g - 1); SSW = (1 - t0) * rng.chisquare(g * (n - 1))
            sa, se = reml_t(SSW, SSB, g, n)
            t_hat = sa / (sa + se); h2 = 4 * t_hat; hs.append(h2)
            # delta
            th = se + n * sa
            I = 0.5 * np.array([[(g - 1) * n ** 2 / th ** 2, (g - 1) * n / th ** 2],
                                [(g - 1) * n / th ** 2, (g - 1) / th ** 2 + g * (n - 1) / se ** 2]])
            grad = 4 * np.array([se, -sa]) / (sa + se) ** 2
            se_h = float(np.sqrt(grad @ np.linalg.solve(I, grad)))
            lo, hi = max(h2 - 1.96 * se_h, 0.0), min(h2 + 1.96 * se_h, 1.0)
            res["delta"]["cov"].append(lo <= cfg["h2_true"] <= hi); res["delta"]["width"].append(hi - lo); res["delta"]["lo0"].append(lo <= 1e-12)
            # profile
            ll = prof_ll(grid, SSW, SSB, g, n)
            ok = 2 * (ll.max() - ll) <= crit
            plo, phi = 4 * grid[ok].min(), 4 * grid[ok].max()
            res["profile"]["cov"].append(plo <= cfg["h2_true"] <= phi); res["profile"]["width"].append(phi - plo); res["profile"]["lo0"].append(plo <= 1e-12)
            # bootstrap
            sB = (se + n * sa) * rng.chisquare(g - 1, cfg["n_boot"]); sW = se * rng.chisquare(g * (n - 1), cfg["n_boot"])
            a_b, e_b = reml_t(sW, sB, g, n)
            hb = 4 * a_b / (a_b + e_b)
            blo, bhi = np.quantile(hb, [0.025, 0.975])
            res["boot"]["cov"].append(blo <= cfg["h2_true"] <= bhi); res["boot"]["width"].append(bhi - blo); res["boot"]["lo0"].append(blo <= 1e-12)
        bias = float(np.mean(hs) - cfg["h2_true"])
        for m, nm in (("delta", "delta 法"), ("profile", "轮廓似然"), ("boot", "自助法")):
            c, w, z = np.mean(res[m]["cov"]), np.mean(res[m]["width"]), np.mean(res[m]["lo0"])
            print(f"{g:4d}{n:3d} | {nm:<8}{c:8.3f}{w:9.3f}{z:8.3f}{bias:9.3f}")
            out.append(dict(g=g, n=n, method=m, coverage=float(c), width=float(w), lo_zero=float(z), bias=bias))
    # 核验：大样本时三种覆盖率接近名义
    big = [o for o in out if o["g"] == cfg["designs"][-1][0]]
    for o in big:
        assert abs(o["coverage"] - 0.95) < 0.04, o
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex23_18_h2_intervals.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
