# 第23章　方差组分、限制似然与贝叶斯推断——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex23_15_ml_vs_reml.py
python3 ex23_16_ai_reml.py
python3 ex23_17_boundary_lrt.py
python3 ex23_18_h2_intervals.py
python3 ex23_19_bayes_variance.py
python3 ex23_20_variance_uncertainty_decision.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex23_15_ml_vs_reml.py | 23.15 | ML 与 REML：固定效应的“自由度代价”和方差组分估计的偏倚 |
| ex23_16_ai_reml.py | 23.16 | 动物模型 REML：EM、Fisher 得分与平均信息（AI）算法的收敛比较 |
| ex23_17_boundary_lrt.py | 23.17 | 方差为零的似然比检验：边界使零分布成为 ½χ²₀ + ½χ²₁ 的混合 |
| ex23_18_h2_intervals.py | 23.18 | 遗传力的区间估计：delta 法、轮廓似然与参数自助法的覆盖率 |
| ex23_19_bayes_variance.py | 23.19 | 公畜模型的贝叶斯方差推断：Gibbs 采样、先验敏感性与格点积分核验 |
| ex23_20_variance_uncertainty_decision.py | 23.20 | 方差不确定性如何进入育种值与选种决策 |
