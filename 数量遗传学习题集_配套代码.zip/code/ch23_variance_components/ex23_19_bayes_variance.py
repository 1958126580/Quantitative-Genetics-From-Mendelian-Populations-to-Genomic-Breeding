#!/usr/bin/env python3
"""习题 23.19  公畜模型的贝叶斯方差推断：Gibbs 采样、先验敏感性与格点积分核验

y = Xb + Zs + e，s~N(0,σ_s²I)，e~N(0,σ_w²I)，b 取平坦先验。方差先验为尺度化逆卡方 χ⁻²(ν,S²)：
  flat_sd（ν=−1：σ 平坦）、flat_var（ν=−2：σ² 平坦）、jeffreys（ν=0：1/σ²，对 σ_s² 后验不正常）、ig_001（IG(0.001,0.001)）、informative（ν=8）。
Gibbs：一步整块抽取 (b,s)|σ² ~ N(C⁻¹r, σ_w²C⁻¹)，再抽 σ_s²|s、σ_w²|e。
核验：对 flat_sd、flat_var、ig_001 与 informative 先验，用 (σ_s²,σ_w²) 二维格点对 REML 边缘似然×先验积分得到的
后验均值/分位数，与 Gibbs 样本的均值/分位数一致（允许 MC 误差）。
报告：σ_s²、h²=4σ_s²/(σ_s²+σ_w²) 的后验均值、中位数、95%可信区间、有效样本量、P(h²<0.05)，以及 REML 点估计。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def load():
    d = json.load(open(HERE / "data" / "ex23_19_sire_data.json"))
    rec = d["records"]; N = len(rec); H, S = d["n_herd"], d["n_sire"]
    X = np.zeros((N, H)); Z = np.zeros((N, S)); y = np.zeros(N)
    for r, (h, s, v) in enumerate(rec):
        X[r, h] = 1; Z[r, s] = 1; y[r] = v
    return d, X, Z, y


def mme_solve(X, Z, y, lam):
    H, S = X.shape[1], Z.shape[1]
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * np.eye(S)]])
    r = np.r_[X.T @ y, Z.T @ y]
    L = np.linalg.cholesky(C)
    th = np.linalg.solve(L.T, np.linalg.solve(L, r))
    return C, L, th


def log_reml(X, Z, y, ss2, sw2, XtX=None, XtZ=None, ZtZ=None, Xty=None, Zty=None, yty=None):
    """−½ 的 REML 对数似然（常数略）：ℓ = −½[(N−p−S)log σ_w² + S log σ_s² + log|C| + (y'y − θ̂'r)/σ_w²]."""
    N, p = X.shape; S = Z.shape[1]
    lam = sw2 / ss2
    C = np.block([[XtX, XtZ], [XtZ.T, ZtZ + lam * np.eye(S)]])
    r = np.r_[Xty, Zty]
    L = np.linalg.cholesky(C)
    th = np.linalg.solve(L.T, np.linalg.solve(L, r))
    ldC = 2 * np.log(np.diag(L)).sum()
    return -0.5 * ((N - p - S) * np.log(sw2) + S * np.log(ss2) + ldC + (yty - th @ r) / sw2)


def sums(X, Z, y):
    return dict(XtX=X.T @ X, XtZ=X.T @ Z, ZtZ=Z.T @ Z, Xty=X.T @ y, Zty=Z.T @ y, yty=y @ y)


def grid_posterior(X, Z, y, prior, gs, ge, n):
    """二维格点：σ_s²∈gs 范围（对数网格），σ_w²∈ge 范围；先验尺度化逆卡方的密度 ∝ (σ²)^{-(ν/2+1)}exp(−νS²/(2σ²))。
    返回 (ss2网格, sw2网格, 权重矩阵 w[i,j])；权重含对数网格的 Jacobian（σ² dlogσ²）。"""
    sm = sums(X, Z, y)
    a = np.exp(np.linspace(np.log(gs[0]), np.log(gs[1]), n)); b = np.exp(np.linspace(np.log(ge[0]), np.log(ge[1]), n))
    LL = np.empty((n, n))
    for i, s2 in enumerate(a):
        for j, w2 in enumerate(b):
            LL[i, j] = log_reml(X, Z, y, s2, w2, **sm)

    def lprior(v, nu, S2):
        return -(nu / 2 + 1) * np.log(v) - nu * S2 / (2 * v)
    lp = lprior(a, prior["nu_s"], prior["S2_s"])[:, None] + lprior(b, prior["nu_e"], prior["S2_e"])[None, :]
    lw = LL + lp + np.log(a)[:, None] + np.log(b)[None, :]       # dσ² = σ² dlogσ²
    lw -= lw.max()
    w = np.exp(lw); w /= w.sum()
    return a, b, w, LL


def gibbs(X, Z, y, prior, n_iter, burn, rng, start=(1.0, 10.0)):
    N, p = X.shape; S = Z.shape[1]
    ss2, sw2 = start
    out = np.empty((n_iter, 2))
    W = np.hstack([X, Z]); WtW = W.T @ W; Wty = W.T @ y
    for it in range(n_iter):
        lam = sw2 / ss2
        P = WtW.copy(); P[p:, p:] += lam * np.eye(S)
        L = np.linalg.cholesky(P)
        mean = np.linalg.solve(L.T, np.linalg.solve(L, Wty))
        th = mean + np.sqrt(sw2) * np.linalg.solve(L.T, rng.standard_normal(p + S))
        s = th[p:]; e = y - W @ th
        ss2 = (prior["nu_s"] * prior["S2_s"] + s @ s) / rng.chisquare(S + prior["nu_s"])
        sw2 = (prior["nu_e"] * prior["S2_e"] + e @ e) / rng.chisquare(N + prior["nu_e"])
        out[it] = (ss2, sw2)
    return out[burn:]


def ess(x):
    x = np.asarray(x) - np.mean(x); n = len(x)
    f = np.fft.rfft(x, 2 * n); ac = np.fft.irfft(f * np.conj(f))[:n]; ac /= ac[0]
    s = 0.0
    for k in range(1, n):
        if ac[k] < 0.05: break
        s += ac[k]
    return n / (1 + 2 * s)


def reml_estimate(X, Z, y):
    from scipy.optimize import minimize
    sm = sums(X, Z, y)
    f = lambda p: -log_reml(X, Z, y, np.exp(p[0]), np.exp(p[1]), **sm)
    r = minimize(f, [0.0, np.log(10.0)], method="Nelder-Mead", options={"xatol": 1e-8, "fatol": 1e-10})
    return np.exp(r.x)


def main():
    d, X, Z, y = load()
    rng = np.random.default_rng(d["seed"])
    N = len(y)
    reml = reml_estimate(X, Z, y)
    h2_reml = 4 * reml[0] / reml.sum()
    print("=" * 96)
    print("习题 23.19  贝叶斯方差推断  N=%d, 公畜 %d, 真值 σ_s²=%.1f σ_w²=%.1f (h²=%.3f)" % (N, Z.shape[1], d["true"]["sigma_s2"], d["true"]["sigma_w2"], 4 * d["true"]["sigma_s2"] / (d["true"]["sigma_s2"] + d["true"]["sigma_w2"])))
    print("REML：σ_s²=%.4f σ_w²=%.4f  h²=%.4f" % (reml[0], reml[1], h2_reml))
    print("=" * 96)
    print(f"{'先验':<14}{'σ_s² 均值':>10}{'σ_s² 中位':>10}{'σ_s² 95%CI':>18}{'h² 均值':>9}{'h² 中位':>9}{'h² 95%CI':>16}{'ESS(σ_s²)':>10}{'P(h²<.05)':>10}")
    res = {}; samples = {}
    for name, pr in d["priors"].items():
        chains = [gibbs(X, Z, y, pr, d["n_iter"], d["burn"], rng, start=(1.0 + 3 * c, 8.0 + 2 * c)) for c in range(d["n_chain"])]
        # 收敛：Gelman–Rubin R̂
        m = np.array([c[:, 0].mean() for c in chains]); v = np.array([c[:, 0].var(ddof=1) for c in chains]); n = len(chains[0])
        Wv = v.mean(); Bv = n * m.var(ddof=1); Rhat = np.sqrt(((n - 1) / n * Wv + Bv / n) / Wv)
        smp = np.vstack(chains); samples[name] = smp
        h2 = 4 * smp[:, 0] / smp.sum(1)
        q = np.quantile(smp[:, 0], [0.025, 0.5, 0.975]); qh = np.quantile(h2, [0.025, 0.5, 0.975])
        e = ess(chains[0][:, 0])
        print(f"{name:<14}{smp[:,0].mean():10.3f}{q[1]:10.3f}   [{q[0]:6.3f},{q[2]:7.3f}]{h2.mean():9.3f}{qh[1]:9.3f}  [{qh[0]:5.3f},{qh[2]:5.3f}]{e:10.0f}{np.mean(h2<0.05):10.3f}  R̂={Rhat:.3f}")
        assert Rhat < 1.05 or name == "jeffreys"
        res[name] = dict(ss_mean=float(smp[:, 0].mean()), ss_q=q.tolist(), h2_mean=float(h2.mean()), h2_q=qh.tolist(), ess=float(e), p_h2_lt_005=float(np.mean(h2 < .05)), Rhat=float(Rhat))
    # 格点核验
    print("\n格点积分核验（二维 REML 边缘似然 × 先验）：")
    print(f"{'先验':<14}{'格点 σ_s² 均值':>14}{'Gibbs':>9}{'格点 h² 均值':>13}{'Gibbs':>9}{'格点 P(h²<.05)':>14}{'Gibbs':>8}")
    for name in ("flat_sd", "flat_var", "informative", "ig_001"):
        a, b, w, LL = grid_posterior(X, Z, y, d["priors"][name], d["grid_s_range"], d["grid_e_range"], d["grid_n"])
        ms = float((w.sum(1) * a).sum())
        hh = 4 * a[:, None] / (a[:, None] + b[None, :])
        mh = float((w * hh).sum()); p05 = float((w * (hh < 0.05)).sum())
        g_ss = samples[name][:, 0].mean(); g_h = (4 * samples[name][:, 0] / samples[name].sum(1)).mean(); g_p = np.mean(4 * samples[name][:, 0] / samples[name].sum(1) < .05)
        print(f"{name:<14}{ms:14.3f}{g_ss:9.3f}{mh:13.3f}{g_h:9.3f}{p05:14.3f}{g_p:8.3f}")
        # 格点范围截断了 σ_s²>10 的尾部：对 flat_var 允许略低于 Gibbs
        assert abs(ms - g_ss) < 0.06 * max(1.0, g_ss), (name, ms, g_ss)
        assert abs(mh - g_h) < 0.03, (name, mh, g_h)
        res[name]["grid"] = dict(ss_mean=ms, h2_mean=mh, p_h2_lt_005=p05)
    res["reml"] = dict(sigma_s2=float(reml[0]), sigma_w2=float(reml[1]), h2=float(h2_reml))
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(res, open(HERE / "results" / "ex23_19_bayes_variance.json", "w"), ensure_ascii=False, indent=1)
    try:
        from _plot import get_pyplot
        plt = get_pyplot()
        if plt:
            fig, ax = plt.subplots(figsize=(6.5, 3.6))
            for name in samples:
                ax.hist(4 * samples[name][:, 0] / samples[name].sum(1), bins=60, histtype="step", density=True, label=name)
            ax.axvline(h2_reml, color="k", ls="--"); ax.set_xlabel("h²"); ax.legend(); fig.tight_layout()
            fig.savefig(HERE / "results" / "ex23_19_bayes_variance.png"); plt.close(fig)
    except Exception:
        pass


if __name__ == "__main__":
    main()
