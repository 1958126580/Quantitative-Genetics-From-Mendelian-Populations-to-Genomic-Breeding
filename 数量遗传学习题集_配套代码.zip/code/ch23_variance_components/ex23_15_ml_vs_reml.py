#!/usr/bin/env python3
"""习题 23.15  ML 与 REML：固定效应的“自由度代价”和方差组分估计的偏倚

A. 回归模型 y = Xβ + e：σ̂²_ML = RSS/N（偏倚 −pσ²/N），σ̂²_REML = RSS/(N−p)（无偏）。
B. 平衡单向随机模型 y_ij = μ + a_i + e_ij：g 组、每组 n 条记录。
   方差分析：MSW=SSW/[g(n−1)]，MSB=SSB/(g−1)。
   REML（无约束）：σ̂_e²=MSW，σ̂_a²=(MSB−MSW)/n（与 ANOVA 一致）；
   ML（无约束）：σ̂_e²=MSW，σ̂_a²=[ (g−1)MSB/g − MSW ]/n（组间自由度用 g 而不是 g−1）。
   边界处理：估计值为负时取 0（并重新优化 σ_e²），统计偏倚与非负截断偏倚。
   以直接最大化似然（scipy 数值优化）核验闭式解。报告：σ_a² 的偏倚、均方误差、遗传力 h²=σ_a²/(σ_a²+σ_e²)
   的偏倚及估计到边界（σ̂_a²=0）的比例。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent


def one_way_stats(y):
    g, n = y.shape
    gm = y.mean(1); m = y.mean()
    ssw = ((y - gm[:, None]) ** 2).sum(1)
    ssb = n * ((gm - m) ** 2).sum(1) if y.ndim == 3 else n * ((gm - m) ** 2).sum()
    return ssw.sum(), ssb


def est_closed(SSW, SSB, g, n, method):
    """返回 (σ_a², σ_e²)，含边界处理：σ_a²<0 时设 0，σ_e²=(SSW+SSB)/(去自由度)."""
    dfw = g * (n - 1); dfb = g - 1 if method == "REML" else g
    msw = SSW / dfw
    ssb_adj = SSB if method == "REML" else SSB
    msb = SSB / (g - 1) if method == "REML" else SSB / g
    sa2 = (msb - msw) / n
    if sa2 >= 0:
        return sa2, msw
    # 边界：σ_a²=0，模型为独立同分布 → σ_e² = (SSW + SSB)/(df)
    df = (g * n - 1) if method == "REML" else g * n
    return 0.0, (SSW + SSB) / df


def neg_loglik(par, SSW, SSB, g, n, method):
    """基于充分统计量的（限制）对数似然：SSB~(σ_e²+nσ_a²)χ²_{g−1}，SSW~σ_e²χ²_{g(n−1)}；
    ML 额外包含样本均值的信息项（μ 的轮廓）。"""
    sa2, se2 = par
    if se2 <= 1e-9 or sa2 < 0:
        return 1e10
    th = se2 + n * sa2
    ll = -0.5 * ((g - 1) * np.log(th) + SSB / th + g * (n - 1) * np.log(se2) + SSW / se2)
    if method == "ML":
        ll += -0.5 * np.log(th)       # 总均值（μ 轮廓）对 y 的似然贡献：均值方差 θ/(gn) 对数项消去后的 log θ
    return -ll


def main():
    cfg = json.load(open(HERE / "data" / "ex23_15_ml_reml.json"))
    rng = np.random.default_rng(cfg["seed"])
    R = cfg["n_rep"]
    out = {"regression": [], "one_way": []}
    print("=" * 78)
    print("习题 23.15  ML 与 REML")
    print("=" * 78)
    rg = cfg["regression"]; N = rg["N"]; s2 = rg["sigma2"]
    print("A. 回归（N=%d, σ²=%.1f）：" % (N, s2))
    print(f"{'p':>4}{'ML 均值':>10}{'理论 (N−p)σ²/N':>16}{'REML 均值':>11}{'ML 偏倚%':>10}")
    for p in rg["p_list"]:
        X = np.column_stack([np.ones(N)] + [rng.normal(size=N) for _ in range(p - 1)])
        H = X @ np.linalg.solve(X.T @ X, X.T)
        M = np.eye(N) - H
        e = rng.normal(0, np.sqrt(s2), (R, N))
        rss = np.einsum("ij,jk,ik->i", e, M, e)
        ml, reml = rss.mean() / N, rss.mean() / (N - p)
        th = (N - p) * s2 / N
        assert abs(ml - th) / th < 0.01 and abs(reml - s2) / s2 < 0.01
        print(f"{p:4d}{ml:10.3f}{th:16.3f}{reml:11.3f}{(ml/s2-1)*100:10.1f}")
        out["regression"].append(dict(p=p, ml=float(ml), reml=float(reml), theory_ml=th))
    ow = cfg["one_way"]; n = ow["n_per_group"]; sa, se = ow["sigma_a2"], ow["sigma_e2"]
    h2t = sa / (sa + se)
    print("\nB. 平衡单向随机模型（σ_a²=%.1f, σ_e²=%.1f, n=%d, h²=%.3f）：" % (sa, se, n, h2t))
    print(f"{'g':>4}{'方法':>6}{'σ_a² 均值':>10}{'偏倚':>8}{'RMSE':>8}{'h² 均值':>9}{'σ̂_a²=0 占比':>12}")
    for g in ow["groups"]:
        a = rng.normal(0, np.sqrt(sa), (R, g))
        y = a[:, :, None] + rng.normal(0, np.sqrt(se), (R, g, n))
        gm = y.mean(2); m = y.mean((1, 2))
        SSW = ((y - gm[:, :, None]) ** 2).sum((1, 2)); SSB = n * ((gm - m[:, None]) ** 2).sum(1)
        for method in ("REML", "ML"):
            est = np.array([est_closed(SSW[i], SSB[i], g, n, method) for i in range(R)])
            sa_h, se_h = est[:, 0], est[:, 1]
            h2 = sa_h / (sa_h + se_h)
            bias = sa_h.mean() - sa
            print(f"{g:4d}{method:>6}{sa_h.mean():10.3f}{bias:8.3f}{np.sqrt(np.mean((sa_h-sa)**2)):8.3f}{h2.mean():9.3f}{np.mean(sa_h==0):12.3f}")
            out["one_way"].append(dict(g=g, method=method, mean_sa=float(sa_h.mean()), bias=float(bias), rmse=float(np.sqrt(np.mean((sa_h - sa) ** 2))),
                                       mean_h2=float(h2.mean()), frac_zero=float(np.mean(sa_h == 0))))
        # 无截断的 ANOVA 无偏性
        raw = (SSB / (g - 1) - SSW / (g * (n - 1))) / n
        assert abs(raw.mean() - sa) < 5 * raw.std() / np.sqrt(R), "ANOVA 估计应无偏"
        # 数值核验：直接最大化（REML 和 ML）与闭式一致
        for method in ("REML", "ML"):
            for i in range(min(cfg["numeric_check_reps"], 50)):
                cs = est_closed(SSW[i], SSB[i], g, n, method)
                r = minimize(neg_loglik, x0=[max(cs[0], 0.3), cs[1]], args=(SSW[i], SSB[i], g, n, method), method="Nelder-Mead",
                             options={"xatol": 1e-9, "fatol": 1e-12, "maxiter": 4000})
                if cs[0] > 1e-6:       # 内点解
                    assert abs(r.x[0] - cs[0]) < 1e-3 * max(1, cs[0]) and abs(r.x[1] - cs[1]) < 1e-3 * cs[1], (method, g, i, r.x, cs)
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex23_15_ml_vs_reml.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
