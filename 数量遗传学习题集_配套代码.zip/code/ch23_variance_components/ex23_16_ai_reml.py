#!/usr/bin/env python3
"""习题 23.16  动物模型 REML：EM、Fisher 得分与平均信息（AI）算法的收敛比较

模型 y = Xβ + Zα + Wp + e，α~N(0, Aσ_a²)，p~N(0, Iσ_pe²)（永久环境，重复记录），e~N(0, Iσ_e²)。
V = ZAZ'σ_a² + WW'σ_pe² + Iσ_e²，P = V⁻¹ − V⁻¹X(X'V⁻¹X)⁻¹X'V⁻¹。
REML 对数似然  ℓ = −½[log|V| + log|X'V⁻¹X| + y'Py]。
对 V_k=∂V/∂σ_k²：
  得分 s_k = −½[tr(PV_k) − y'PV_kPy]；期望信息 E_kl = ½tr(PV_kPV_l)；平均信息 AI_kl = ½y'PV_kPV_lPy；
  EM：σ_k² ← [σ_k⁴y'PV_kPy + tr(σ_k²I − σ_k⁴ PV_k)]/n_k 的 ‘一般形式’ 可写成 σ_k²+ (2σ_k⁴/n_k)s_k·(−1)…（本程序用该等价形式）。
核验：解析得分与对数似然的数值梯度一致；AI 与期望信息、观测信息的关系（E[AI]=期望信息）；
三种算法收敛到同一估计；标准误用 AI/期望信息逆矩阵并与数值 Hessian 比较。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    nf, G, npg, rec = cfg["n_founders"], cfg["n_gen"], cfg["n_per_gen"], cfg["records_per_animal"]
    t = cfg["true"]
    n = nf + G * npg
    sire = -np.ones(n, int); dam = -np.ones(n, int); gen = np.zeros(n, int)
    A = np.zeros((n, n)); a = np.zeros(n); F = np.zeros(n)
    A[:nf, :nf] = np.eye(nf); a[:nf] = rng.normal(0, np.sqrt(t["sigma_a2"]), nf)
    start = 0; prev = np.arange(nf)
    idx = nf
    for g in range(1, G + 1):
        cur = []
        for _ in range(npg):
            s, d = rng.choice(prev, 2, replace=False)
            row = 0.5 * (A[s, :idx] + A[d, :idx]); A[idx, :idx] = row; A[:idx, idx] = row
            F[idx] = 0.5 * A[s, d]; A[idx, idx] = 1 + F[idx]
            sd = np.sqrt(t["sigma_a2"] * max(0.5 - 0.25 * (F[s] + F[d]), 1e-9))
            a[idx] = 0.5 * (a[s] + a[d]) + rng.normal(0, sd)
            sire[idx], dam[idx], gen[idx] = s, d, g
            cur.append(idx); idx += 1
        prev = np.array(cur)
    # 记录：除第 0 代外，每个动物 rec 条记录
    animals = np.where(gen >= 1)[0]
    ani = np.repeat(animals, rec); N = len(ani)
    herd = rng.integers(0, cfg["herd_levels"], N)
    X = np.zeros((N, cfg["herd_levels"])); X[np.arange(N), herd] = 1
    Z = np.zeros((N, n)); Z[np.arange(N), ani] = 1
    W = np.zeros((N, len(animals))); pos = {a_: i for i, a_ in enumerate(animals)}
    W[np.arange(N), [pos[a_] for a_ in ani]] = 1
    pe = rng.normal(0, np.sqrt(t["sigma_pe2"]), len(animals))
    y = 20 + X @ np.arange(cfg["herd_levels"]) * 1.5 + Z @ a + W @ pe + rng.normal(0, np.sqrt(t["sigma_e2"]), N)
    return y, X, Z, W, A


class Reml:
    def __init__(self, y, X, Z, W, A):
        self.y, self.X = y, X
        N = len(y); self.N = N
        self.K = [Z @ A @ Z.T, W @ W.T, np.eye(N)]          # V_k
        self.rankX = np.linalg.matrix_rank(X)

    def V(self, th):
        return sum(t * K for t, K in zip(th, self.K))

    def parts(self, th):
        V = self.V(th)
        L = np.linalg.cholesky(V)
        Vi = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(self.N)))
        XtViX = self.X.T @ Vi @ self.X
        P = Vi - Vi @ self.X @ np.linalg.solve(XtViX, self.X.T @ Vi)
        ldV = 2 * np.log(np.diag(L)).sum()
        sign, ldX = np.linalg.slogdet(XtViX)
        return P, ldV, ldX

    def loglik(self, th):
        P, ldV, ldX = self.parts(th)
        return -0.5 * (ldV + ldX + self.y @ P @ self.y)

    def score_info(self, th):
        P, ldV, ldX = self.parts(th)
        Py = P @ self.y
        PK = [P @ K for K in self.K]
        s = np.array([-0.5 * (np.trace(pk) - Py @ K @ Py) for pk, K in zip(PK, self.K)])
        E = np.array([[0.5 * np.trace(pk @ pl) for pl in PK] for pk in PK])
        KPy = [K @ Py for K in self.K]
        AI = np.array([[0.5 * KPy[i] @ P @ KPy[j] for j in range(3)] for i in range(3)])
        return s, E, AI, Py, PK


def run(model, th0, method, max_iter, tol):
    th = np.array(th0, float); trace = []
    for it in range(1, max_iter + 1):
        s, E, AI, Py, PK = model.score_info(th)
        if method == "EM":
            nk = np.array([model.K[0].shape[0]] * 3, float)
            # EM（对 ν_k = tr(K_k^{-1}…)）：对 σ_a² 用 q=Z 的列数、σ_pe² 用 p 数、σ_e² 用 N；此处用等价的“期望得分”形式
            q = np.array([model.nA, model.nP, model.N], float)
            Kpy = [K @ Py for K in model.K]
            quad = np.array([Py @ model.K[i] @ Py for i in range(3)])
            new = np.array([(th[i] ** 2 * quad[i] + th[i] * q[i] - th[i] ** 2 * np.trace(PK[i])) / q[i] for i in range(3)])
            step = new - th
            th_new = new
        else:
            info = AI if method == "AI" else E
            step = np.linalg.solve(info, s)
            lam = 1.0
            th_new = th + step
            while np.any(th_new <= 1e-6) or model.loglik(th_new) < model.loglik(th) - 1e-10:
                lam *= 0.5; th_new = th + lam * step
                if lam < 1e-6: break
        ll = model.loglik(th_new)
        trace.append((it, ll, th_new.copy(), np.max(np.abs(s))))
        if np.max(np.abs(th_new - th)) < tol * max(1, th.max()):
            th = th_new; break
        th = th_new
    return th, trace


def main():
    cfg = json.load(open(HERE / "data" / "ex23_16_animal_model.json"))
    rng = np.random.default_rng(cfg["seed"])
    y, X, Z, W, A = simulate(cfg, rng)
    model = Reml(y, X, Z, W, A)
    model.nA = int(np.sum(np.diag(np.linalg.inv(A)) > 0)) if False else A.shape[0]
    # EM 公式需要 tr(A⁻¹ ...)；这里 q 取 A 的维数与 W 列数
    model.nP = W.shape[1]
    # 数值梯度核验
    th0 = np.array(cfg["start"], float)
    s_an = model.score_info(th0)[0]
    eps = 1e-5; s_num = np.zeros(3)
    for k in range(3):
        d = np.zeros(3); d[k] = eps
        s_num[k] = (model.loglik(th0 + d) - model.loglik(th0 - d)) / (2 * eps)
    assert np.allclose(s_an, s_num, rtol=1e-5, atol=1e-6), (s_an, s_num)
    print("=" * 76)
    print("习题 23.16  动物模型 REML  N=%d 条记录，%d 头动物，真值 σ_a²=%.1f σ_pe²=%.1f σ_e²=%.1f" % (len(y), A.shape[0], *cfg["true"].values()))
    print("=" * 76)
    print("起点得分：解析 =", np.round(s_an, 5), " 数值 =", np.round(s_num, 5))
    res = {}
    for method, mi in (("AI", 50), ("FS", 50), ("EM", cfg["max_iter_em"])):
        th, tr = run(model, th0, method, mi, cfg["tol"])
        res[method] = (th, tr)
        print(f"{method:>3}: 迭代 {len(tr):4d} 次，估计 σ_a²={th[0]:.4f} σ_pe²={th[1]:.4f} σ_e²={th[2]:.4f}，ℓ={tr[-1][1]:.6f}，|得分|max={tr[-1][3]:.2e}")
    # 一致性
    assert np.allclose(res["AI"][0], res["FS"][0], rtol=1e-4, atol=1e-4)
    lls = [t[1] for t in res["EM"][1]]
    assert all(b >= a - 1e-9 for a, b in zip(lls, lls[1:])), "EM 对数似然应单调不减"
    assert lls[-1] <= res["AI"][1][-1][1] + 1e-6
    th = res["AI"][0]
    s, E, AI, *_ = model.score_info(th)
    # 数值 Hessian（观测信息）
    H = np.zeros((3, 3)); e = 1e-3
    for i in range(3):
        for j in range(3):
            di = np.zeros(3); dj = np.zeros(3); di[i] = e; dj[j] = e
            H[i, j] = (model.loglik(th + di + dj) - model.loglik(th + di - dj) - model.loglik(th - di + dj) + model.loglik(th - di - dj)) / (4 * e * e)
    Iobs = -H
    se_E = np.sqrt(np.diag(np.linalg.inv(E))); se_AI = np.sqrt(np.diag(np.linalg.inv(AI))); se_obs = np.sqrt(np.diag(np.linalg.inv(Iobs)))
    print("\n标准误：          σ_a²     σ_pe²    σ_e²")
    print("  期望信息逆   ", np.round(se_E, 3)); print("  AI 逆        ", np.round(se_AI, 3)); print("  数值观测信息 ", np.round(se_obs, 3))
    h2 = th[0] / th.sum()
    g = np.array([(th[1] + th[2]) / th.sum() ** 2, -th[0] / th.sum() ** 2, -th[0] / th.sum() ** 2])
    se_h2 = float(np.sqrt(g @ np.linalg.inv(E) @ g))
    print(f"h² = {h2:.4f}（delta 法 SE = {se_h2:.4f}），真值 {cfg['true']['sigma_a2']/sum(cfg['true'].values()):.4f}")
    # 迭代轨迹摘要
    print("\n对数似然（相对终值）随迭代：")
    for m in ("AI", "FS", "EM"):
        tr = res[m][1]; fin = tr[-1][1]
        pick = [1, 2, 3, 5, 10, 30, 100, 200]
        print(f"  {m:>2}: " + "  ".join(f"it{i}:{fin - tr[i-1][1]:.2e}" for i in pick if i <= len(tr)))
    out = dict(estimate=th.tolist(), iters={m: len(res[m][1]) for m in res}, se_expected=se_E.tolist(), se_ai=se_AI.tolist(), se_obs=se_obs.tolist(),
               h2=float(h2), se_h2=se_h2)
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex23_16_ai_reml.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
