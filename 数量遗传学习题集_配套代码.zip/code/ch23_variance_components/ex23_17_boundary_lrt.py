#!/usr/bin/env python3
"""习题 23.17  方差为零的似然比检验：边界使零分布成为 ½χ²₀ + ½χ²₁ 的混合

平衡单向随机模型，REML 对数似然（只依赖 SSB~(σ_e²+nσ_a²)χ²_{g−1}、SSW~σ_e²χ²_{g(n−1)}）：
  ℓ(σ_a², σ_e²) = −½[(g−1)log θ + SSB/θ + g(n−1)log σ_e² + SSW/σ_e²]，θ = σ_e²+nσ_a²。
H0：σ_a²=0（一个参数在边界）。LRT = 2[ℓ(σ̂_a²,σ̂_e²) − ℓ(0,σ̂_e²|H0)] ≥ 0。
  - H0 下 σ̂_a²=0 的概率 ≈ 1/2（g 大时），此时 LRT=0；否则近似 χ²₁，故 P(LRT>c) ≈ ½P(χ²₁>c)；
  - 用 χ²₁ 的 5% 临界值（3.841）检验，实际水平 ≈ 2.5%（保守）；正确的 5% 临界值为 χ²₁ 的 90% 分位数 2.706；
  - 小 g 时的有限样本偏离。
并给出在不同真实遗传力（h²=σ_a²/(σ_a²+σ_e²)）下用混合分布临界值的检验功效。
核验：模拟的 H0 下 P(LRT=0) 与 ½ 的偏离，及 χ²₁/混合分布两种临界值下的实际 I 类错误率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent


def lrt(SSW, SSB, g, n):
    msw = SSW / (g * (n - 1)); msb = SSB / (g - 1)
    sa2 = np.maximum((msb - msw) / n, 0.0)
    # 全模型
    th = np.where(sa2 > 0, msb, 0)
    se2_full = np.where(sa2 > 0, msw, (SSW + SSB) / (g * n - 1))
    th_full = se2_full + n * sa2
    ll1 = -0.5 * ((g - 1) * np.log(th_full) + SSB / th_full + g * (n - 1) * np.log(se2_full) + SSW / se2_full)
    # H0：σ_a²=0 → θ=σ_e²，σ̂_e²=(SSW+SSB)/(gn−1)
    se2_0 = (SSW + SSB) / (g * n - 1)
    ll0 = -0.5 * ((g - 1) * np.log(se2_0) + SSB / se2_0 + g * (n - 1) * np.log(se2_0) + SSW / se2_0)
    return np.maximum(2 * (ll1 - ll0), 0.0), sa2


def sample(g, n, sa2, se2, R, rng):
    SSB = (se2 + n * sa2) * rng.chisquare(g - 1, R)
    SSW = se2 * rng.chisquare(g * (n - 1), R)
    return SSW, SSB


def main():
    cfg = json.load(open(HERE / "data" / "ex23_17_boundary.json"))
    rng = np.random.default_rng(cfg["seed"])
    n, se2, R = cfg["n_per_group"], cfg["sigma_e2"], cfg["n_rep"]
    c_chi, c_mix = stats.chi2.ppf(0.95, 1), stats.chi2.ppf(0.90, 1)
    print("=" * 80)
    print("习题 23.17  σ_a²=0 的 LRT（n=%d, σ_e²=%.1f, %d 次重复）  χ²₁ 5%%临界 %.3f；混合分布 5%%临界 %.3f" % (n, se2, R, c_chi, c_mix))
    print("=" * 80)
    print(f"{'g':>4}{'P(σ̂_a²=0)':>12}{'水平(χ²₁临界)':>14}{'水平(混合临界)':>14}{'LRT 95%分位':>12}{'LRT 90%分位':>12}")
    out = {"null": [], "power": []}
    for g in cfg["groups"]:
        SSW, SSB = sample(g, n, 0.0, se2, R, rng)
        L, sa2 = lrt(SSW, SSB, g, n)
        p0 = float(np.mean(sa2 == 0)); a1 = float(np.mean(L > c_chi)); a2 = float(np.mean(L > c_mix))
        q95, q90 = float(np.quantile(L, 0.95)), float(np.quantile(L, 0.90))
        print(f"{g:4d}{p0:12.3f}{a1:14.4f}{a2:14.4f}{q95:12.3f}{q90:12.3f}")
        out["null"].append(dict(g=g, p_zero=p0, size_chi2=a1, size_mix=a2, q95=q95, q90=q90))
        if g == 40:
            assert abs(p0 - 0.5) < 0.03 and abs(a1 - 0.025) < 0.01 and abs(a2 - 0.05) < 0.012
    print("\n功效（混合分布 5%% 临界值 %.3f vs χ²₁ 5%% 临界值 %.3f）：" % (c_mix, c_chi))
    print(f"{'g':>4}{'h²':>6}" + f"{'功效(混合)':>12}{'功效(χ²₁)':>12}")
    for g in cfg["groups"]:
        for h2 in cfg["power_h2"]:
            sa2 = se2 * h2 / (1 - h2)
            SSW, SSB = sample(g, n, sa2, se2, R, rng)
            L, _ = lrt(SSW, SSB, g, n)
            pm, pc = float(np.mean(L > c_mix)), float(np.mean(L > c_chi))
            print(f"{g:4d}{h2:6.2f}{pm:12.3f}{pc:12.3f}")
            out["power"].append(dict(g=g, h2=h2, power_mix=pm, power_chi2=pc))
    # 与精确 F 检验比较：LRT>0 ⇔ F>1；精确 F 检验的 5% 水平
    g = 10
    SSW, SSB = sample(g, n, 0.0, se2, R, rng)
    F = (SSB / (g - 1)) / (SSW / (g * (n - 1)))
    Fc = stats.f.ppf(0.95, g - 1, g * (n - 1))
    L, _ = lrt(SSW, SSB, g, n)
    print(f"\n对照 g=10：F 检验 5% 水平 = {np.mean(F > Fc):.4f}（精确）；LRT 用混合临界值的水平 = {np.mean(L > c_mix):.4f}；用 χ²₁ 的水平 = {np.mean(L > c_chi):.4f}")
    assert abs(np.mean(F > Fc) - 0.05) < 0.012
    out["F_test_size"] = float(np.mean(F > Fc))
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex23_17_boundary_lrt.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
