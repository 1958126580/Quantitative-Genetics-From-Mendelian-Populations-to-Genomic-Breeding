# 第4章　单基因座群体模型与等位基因频率的演变——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex04_15_hwe_exact.py
python3 ex04_16_marker_information.py
python3 ex04_17_selection_dynamics.py
python3 ex04_18_wright_fisher.py
python3 ex04_19_coalescent.py
python3 ex04_20_multilocus_F.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex04_15_hwe_exact.py | 4.15 | Hardy–Weinberg 平衡的精确检验（Wigginton 等 2005 递推）与卡方检验比较 |
| ex04_16_marker_information.py | 4.16 | 多等位基因标记的信息量：杂合度、PIC 与亲子排除概率 |
| ex04_17_selection_dynamics.py | 4.17 | 不同显性程度下有利等位基因的选择动态 |
| ex04_18_wright_fisher.py | 4.18 | Wright–Fisher 漂变：杂合度衰减、固定概率与固定时间 |
| ex04_19_coalescent.py | 4.19 | 溯祖模拟：最近共同祖先时间、总枝长与 Watterson 估计量 |
| ex04_20_multilocus_F.py | 4.20 | 由多位点基因型计数估计群体近交系数：比值的平均与平均的比值 |
