#!/usr/bin/env python3
"""习题 4.20  由多位点基因型计数估计群体近交系数：比值的平均与平均的比值

单位点估计 F̂_j = 1 − H_obs,j / H_exp,j。多位点合并有两种方式：
    (a) 简单平均  F̄ = mean_j F̂_j  —— 低杂合度位点的估计极不稳定，平均会被少数位点主导；
    (b) 比值合并  F̂_R = 1 − Σ H_obs,j / Σ H_exp,j  —— 以期望杂合度加权，等价于方差加权。
另用 (p_j, F) 的联合最大似然（各位点频率各自估计，F 共享）作为参照，并用按位点自助法求 SE。
H_exp 使用小样本无偏校正 2n/(2n−1)·2p̂q̂。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent


def per_locus(c):
    c = np.asarray(c, float); n = c.sum(); p = (2 * c[0] + c[1]) / (2 * n)
    hexp = 2 * p * (1 - p) * 2 * n / (2 * n - 1); hobs = c[1] / n
    return hobs, hexp, p


def negll(par, C):
    F = par[0]; ll = 0.0
    for j, c in enumerate(C):
        q = 1 / (1 + np.exp(-par[1 + j]))
        pr = np.array([q * q + F * q * (1 - q), 2 * q * (1 - q) * (1 - F), (1 - q) ** 2 + F * q * (1 - q)])
        if np.any(pr <= 0): return 1e10
        ll += np.sum(np.asarray(c) * np.log(pr))
    return -ll


def estimates(C):
    hs = np.array([per_locus(c) for c in C])
    Fj = 1 - hs[:, 0] / hs[:, 1]
    return Fj, float(Fj.mean()), float(1 - hs[:, 0].sum() / hs[:, 1].sum()), hs


def main():
    cfg = json.loads((HERE / "data" / "ex04_20_counts.json").read_text(encoding="utf-8"))
    C = cfg["counts_AA_Aa_aa"]
    Fj, Fmean, Fratio, hs = estimates(C)
    p0 = hs[:, 2]
    x0 = np.concatenate([[0.1], np.log(p0 / (1 - p0))])
    fit = minimize(negll, x0, args=(C,), method="Nelder-Mead", options={"maxiter": 40000, "xatol": 1e-8, "fatol": 1e-10})
    Fml = float(fit.x[0])
    rng = np.random.default_rng(4200); B = 2000; bm, br = [], []
    for _ in range(B):
        idx = rng.integers(0, len(C), len(C)); _, m_, r_, _ = estimates([C[i] for i in idx]); bm.append(m_); br.append(r_)
    print(f"{'位点':>4s}{'p̂':>7s}{'H_obs':>8s}{'H_exp':>8s}{'F̂_j':>8s}")
    for j, c in enumerate(C):
        print(f"{j+1:4d}{hs[j,2]:7.3f}{hs[j,0]:8.3f}{hs[j,1]:8.3f}{Fj[j]:8.3f}")
    print(f"简单平均 F̄ = {Fmean:.4f}（按位点自助 SE {np.std(bm, ddof=1):.4f}）")
    print(f"比值合并 F̂_R = {Fratio:.4f}（按位点自助 SE {np.std(br, ddof=1):.4f}）")
    print(f"联合最大似然 F̂_ML = {Fml:.4f}；真值 {cfg['true_F']}")
    out = {"F_locus": Fj.round(4).tolist(), "F_mean": Fmean, "F_ratio": Fratio, "F_ml": Fml,
           "se_mean_boot": float(np.std(bm, ddof=1)), "se_ratio_boot": float(np.std(br, ddof=1))}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex04_20_multilocus_F.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
