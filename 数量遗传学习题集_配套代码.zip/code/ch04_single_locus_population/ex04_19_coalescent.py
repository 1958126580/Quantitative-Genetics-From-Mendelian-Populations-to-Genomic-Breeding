#!/usr/bin/env python3
"""习题 4.19  溯祖模拟：最近共同祖先时间、总枝长与 Watterson 估计量

二倍体群体大小 N（2N 个基因拷贝）。样本 n 个基因拷贝，k 个谱系时合并等待时间
    T_k ~ Exp(rate = C(k,2)/(2N))，  E(T_k) = 4N / [k(k−1)]
    E(T_MRCA) = 4N(1 − 1/n)，E(总枝长 L) = 4N Σ_{i=1}^{n−1} 1/i
无限位点模型下分离位点数 S | L ~ Poisson(μL)，θ = 4Nμ，
    Watterson 估计 θ_W = S / a_n，a_n = Σ_{i=1}^{n−1} 1/i，E(θ_W) = θ
    Var(S) = θ a_n + θ² b_n，b_n = Σ 1/i²
程序模拟 2 万个独立位点并核对上述期望与方差。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex04_19_coalescent.json").read_text(encoding="utf-8"))
    n, N, mu, R = cfg["n_sample"], cfg["N"], cfg["mu_per_locus"], cfg["reps"]
    rng = np.random.default_rng(cfg["seed"])
    k = np.arange(n, 1, -1)
    rates = k * (k - 1) / 2 / (2 * N)
    T = rng.exponential(1 / rates, size=(R, len(k)))   # 每列为 k 个谱系阶段的等待时间
    tmrca = T.sum(1); L = (T * k).sum(1)
    S = rng.poisson(mu * L)
    a_n = np.sum(1 / np.arange(1, n)); b_n = np.sum(1 / np.arange(1, n) ** 2); theta = 4 * N * mu
    thW = S / a_n
    th = {"E_TMRCA": 4 * N * (1 - 1 / n), "E_L": 4 * N * a_n, "E_S": theta * a_n, "Var_S": theta * a_n + theta ** 2 * b_n, "E_thetaW": theta}
    sm = {"E_TMRCA": tmrca.mean(), "E_L": L.mean(), "E_S": S.mean(), "Var_S": S.var(ddof=1), "E_thetaW": thW.mean()}
    print(f"n = {n}，N = {N}，θ = 4Nμ = {theta}，a_n = {a_n:.4f}，b_n = {b_n:.4f}")
    for key in th:
        print(f"  {key:<9s} 理论 {th[key]:10.4f}  模拟 {sm[key]:10.4f}")
        assert abs(sm[key] - th[key]) / th[key] < 0.03
    share = (T[:, -1].mean()) / tmrca.mean()
    print(f"最后两个谱系合并阶段占 T_MRCA 的平均比例 = {share:.4f}（理论 E(T_2)/E(T_MRCA) = 2N/[4N(1−1/n)] = {1/(2*(1-1/n)):.4f}）")
    out = {"theory": th, "simulated": {k: float(v) for k, v in sm.items()}, "last_stage_share": float(share)}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex04_19_coalescent.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
