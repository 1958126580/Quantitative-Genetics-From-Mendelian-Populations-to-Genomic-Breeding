#!/usr/bin/env python3
"""习题 4.17  不同显性程度下有利等位基因的选择动态

有利等位基因 A2 的频率 q，适合度 w11 = 1, w12 = 1 + hs, w22 = 1 + s。
    Δq = pq[q(w22 − w12) + p(w12 − w11)] / w̄
比较 h = 0.5（加性）、1（A2 显性）、0（A2 隐性）从 q = 0.01 升至 0.99 所需代数：
显性有利基因“起步快、收尾慢”，隐性有利基因“起步极慢、收尾快”。
另以超显性 (w11 = 1−s1, w12 = 1, w22 = 1−s2) 验证稳定平衡点 q̂ = s1/(s1+s2) 与平衡时平均适合度。
程序同时以连续时间近似 dq/dt ≈ s q(1−q)[h + (1−2h)q] 的积分解核对加性情形。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent


def step(q, s, h):
    p = 1 - q; w11, w12, w22 = 1.0, 1 + h * s, 1 + s
    wbar = p * p * w11 + 2 * p * q * w12 + q * q * w22
    return q + p * q * (q * (w22 - w12) + p * (w12 - w11)) / wbar


def trajectory(q0, q_end, s, h, tmax=200000):
    q = q0; traj = [q]
    while q < q_end and len(traj) < tmax:
        q = step(q, s, h); traj.append(q)
    return np.array(traj)


def main():
    cfg = json.loads((HERE / "data" / "ex04_17_selection.json").read_text(encoding="utf-8"))
    s, q0, q1 = cfg["s"], cfg["q0"], cfg["q_end"]; out = {}; trajs = {}
    for name, h in cfg["schemes"].items():
        tr = trajectory(q0, q1, s, h); trajs[name] = tr
        t_mid = int(np.argmax(tr >= 0.5)); t_end = len(tr) - 1
        out[name] = {"h": h, "generations_to_0.5": t_mid, "generations_to_0.99": t_end}
        print(f"{name:<14s} 0.01→0.5 需 {t_mid:6d} 代，0.01→0.99 需 {t_end:6d} 代")
    # 加性情形的 logistic 近似：t ≈ (2/s) ln[q1(1−q0)/(q0(1−q1))]
    approx = 2 / s * np.log(q1 * (1 - q0) / (q0 * (1 - q1)))
    print(f"加性情形连续时间近似 = {approx:.1f} 代")
    out["additive_logistic_approx"] = approx
    od = cfg["overdominance"]; s1, s2 = od["s1"], od["s2"]; qhat = s1 / (s1 + s2)
    q = od["q0"]
    for _ in range(2000):
        p = 1 - q; wbar = p * p * (1 - s1) + 2 * p * q + q * q * (1 - s2)
        q = q + p * q * (q * ((1 - s2) - 1) + p * (1 - (1 - s1))) / wbar
    wbar_eq = 1 - s1 * s2 / (s1 + s2)
    print(f"超显性：理论平衡 q̂ = {qhat:.4f}，迭代 2000 代后 q = {q:.4f}，平衡平均适合度 = {wbar_eq:.4f}（遗传负荷 {1-wbar_eq:.4f}）")
    assert abs(q - qhat) < 1e-6
    out["overdominance"] = {"q_hat": qhat, "q_iter": q, "wbar_eq": wbar_eq, "load": 1 - wbar_eq}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex04_17_selection_dynamics.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    plt = get_pyplot()
    if plt:
        fig, ax = plt.subplots(figsize=(6.4, 3.8))
        for name, tr in trajs.items():
            ax.plot(tr, label=name)
        ax.set_xscale("log"); ax.set_xlabel("世代"); ax.set_ylabel("有利等位基因频率 q"); ax.legend(fontsize=8)
        fig.tight_layout(); fig.savefig(HERE / "results" / "ex04_17_trajectories.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    main()
