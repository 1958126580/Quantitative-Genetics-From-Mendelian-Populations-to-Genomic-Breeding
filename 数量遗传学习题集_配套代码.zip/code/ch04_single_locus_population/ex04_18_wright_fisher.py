#!/usr/bin/env python3
"""习题 4.18  Wright–Fisher 漂变：杂合度衰减、固定概率与固定时间

二倍体理想群体 N 个个体（2N 个基因拷贝），每代二项抽样：
    E(q_{t+1} | q_t) = q_t，Var = q_t(1−q_t)/(2N)
    期望杂合度 H_t = H_0 (1 − 1/2N)^t
    中性固定概率 = q0；条件固定时间（Kimura–Ohta）t̄₁(q0) = −4N(1−q0) ln(1−q0)/q0
有选择（加性：杂合子 1+s/2，纯合子 1+s，即每个等位基因拷贝的优势 s/2）时 Kimura 扩散近似：
    u(q0) = [1 − exp(−4N(s/2) q0)] / [1 − exp(−4N(s/2))] = [1 − e^{−2Nsq0}] / [1 − e^{−2Ns}]（Ne = N）
注意参数化：若写成杂合子 1+s、纯合子 1+2s，则指数为 4Ns。
程序以 2 万次独立模拟核对上述公式。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(N, q0, s, reps, rng, tmax=100000, track=0):
    q = np.full(reps, q0); t_fix = np.full(reps, -1); fixed = np.zeros(reps, bool); H = []
    alive = np.ones(reps, bool); t = 0
    while alive.any() and t < tmax:
        if s != 0:
            p = 1 - q; wbar = p * p + 2 * p * q * (1 + s / 2) + q * q * (1 + s)
            qsel = (q * q * (1 + s) + p * q * (1 + s / 2)) / wbar
        else:
            qsel = q
        q = np.where(alive, rng.binomial(2 * N, qsel) / (2 * N), q)
        t += 1
        if t <= track: H.append(float(np.mean(2 * q * (1 - q))))
        done = alive & ((q == 0) | (q == 1))
        fixed[done & (q == 1)] = True; t_fix[done] = t; alive &= ~done
    return fixed, t_fix, H


def kimura(N, q0, s):
    if s == 0: return q0
    return (1 - np.exp(-2 * N * s * q0)) / (1 - np.exp(-2 * N * s))


def main():
    cfg = json.loads((HERE / "data" / "ex04_18_wf.json").read_text(encoding="utf-8"))
    N, q0, R = cfg["N"], cfg["q0"], cfg["reps"]; rng = np.random.default_rng(cfg["seed"]); out = {}
    fixed, tf, H = simulate(N, q0, 0.0, R, rng, track=cfg["generations_H"])
    H0 = 2 * q0 * (1 - q0)
    for t in (10, 30, 60):
        th = H0 * (1 - 1 / (2 * N)) ** t
        print(f"第 {t:2d} 代杂合度：模拟 {H[t-1]:.4f}，理论 {th:.4f}")
        assert abs(H[t - 1] - th) < 0.004
    t1 = -4 * N * (1 - q0) * np.log(1 - q0) / q0
    t0 = -4 * N * q0 * np.log(q0) / (1 - q0)
    print(f"中性：固定概率 模拟 {fixed.mean():.4f}，理论 {q0}；条件固定时间 模拟 {tf[fixed].mean():.1f}，理论 {t1:.1f}；"
          f"条件丢失时间 模拟 {tf[~fixed].mean():.1f}，理论 {t0:.1f}")
    out["neutral"] = {"H_sim": H, "p_fix": float(fixed.mean()), "t_fix": float(tf[fixed].mean()), "t_fix_theory": t1,
                      "t_loss": float(tf[~fixed].mean()), "t_loss_theory": t0}
    out["selection"] = {}
    print(f"{'s':>6s}{'2Ns':>6s}{'模拟u':>9s}{'Kimura u':>10s}{'MC标准误':>9s}")
    for s in cfg["s_values"]:
        f, _, _ = simulate(N, q0, s, R, rng)
        k = kimura(N, q0, s)
        out["selection"][str(s)] = {"sim": float(f.mean()), "kimura": float(k)}
        se = np.sqrt(k * (1 - k) / R)
        print(f"{s:6.3f}{2*N*s:6.1f}{f.mean():9.4f}{k:10.4f}{se:9.4f}")
        assert abs(f.mean() - k) < 5 * se + 0.01
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex04_18_wright_fisher.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
