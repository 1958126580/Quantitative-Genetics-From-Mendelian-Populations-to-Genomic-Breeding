#!/usr/bin/env python3
"""习题 4.15  Hardy–Weinberg 平衡的精确检验（Wigginton 等 2005 递推）与卡方检验比较

给定等位基因拷贝数 n_A（小等位基因）与样本数 N，杂合子数 n_AB 的条件分布为
    P(n_AB | N, n_A) = N! / (n_AA! n_AB! n_BB!) · 2^{n_AB} · n_A! n_B! / (2N)!
可由相邻项比值递推（数值稳定，不必计算大阶乘）：
    P(h−2)/P(h) = h(h−1) / [4 (n_AA + 1)(n_BB + 1)]
双侧精确 p 值 = 所有概率 ≤ 观察概率的杂合子数之概率和；另给出杂合子缺乏/过剩的单侧 p 值。
与皮尔逊卡方（1 自由度）比较：稀有等位基因、小样本时卡方近似失真。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import chi2

HERE = Path(__file__).resolve().parent


def hwe_exact(n_aa, n_ab, n_bb):
    """返回 (双侧 p, 杂合子缺乏单侧 p, 杂合子过剩单侧 p, 条件分布)。n_aa 为稀有纯合子。"""
    if 2 * n_aa + n_ab > 2 * n_bb + n_ab:      # 保证 A 为稀有等位基因
        n_aa, n_bb = n_bb, n_aa
    N = n_aa + n_ab + n_bb; nA = 2 * n_aa + n_ab
    probs = np.zeros(nA + 1)
    mid = int(nA * (2 * N - nA) / (2 * N))
    if (nA - mid) % 2: mid += 1                 # 杂合子数与 nA 同奇偶
    probs[mid] = 1.0
    h = mid; aa = (nA - mid) // 2; bb = N - aa - mid
    while h >= 2:                               # 向下递推
        probs[h - 2] = probs[h] * h * (h - 1) / (4.0 * (aa + 1) * (bb + 1))
        h -= 2; aa += 1; bb += 1
    h = mid; aa = (nA - mid) // 2; bb = N - aa - mid
    while h <= nA - 2:                          # 向上递推
        probs[h + 2] = probs[h] * 4.0 * aa * bb / ((h + 2) * (h + 1))
        h += 2; aa -= 1; bb -= 1
    probs /= probs.sum()
    p_obs = probs[n_ab]
    two = float(probs[probs <= p_obs * (1 + 1e-7)].sum())
    low = float(probs[:n_ab + 1].sum()); high = float(probs[n_ab:].sum())
    return min(two, 1.0), low, high, probs


def chisq(n_aa, n_ab, n_bb):
    N = n_aa + n_ab + n_bb; p = (2 * n_aa + n_ab) / (2 * N); q = 1 - p
    exp = np.array([N * p * p, 2 * N * p * q, N * q * q]); obs = np.array([n_aa, n_ab, n_bb])
    X2 = float(np.sum((obs - exp) ** 2 / exp)); F = 1 - n_ab / exp[1]
    return X2, float(chi2.sf(X2, 1)), F, exp


def main():
    cfg = json.loads((HERE / "data" / "ex04_15_hwe.json").read_text(encoding="utf-8"))
    out = {}
    for name, (a, b, c) in cfg["samples"].items():
        two, low, high, probs = hwe_exact(a, b, c)
        X2, pchi, F, exp = chisq(a, b, c)
        N = a + b + c
        assert np.isclose(X2, N * F * F), "卡方应等于 N·F²"
        print(f"{name}：观察 {a}/{b}/{c}，期望 {np.round(exp,2)}，F̂ = {F:.4f}")
        print(f"   卡方 = {X2:.4f}，p = {pchi:.3g}；精确双侧 p = {two:.3g}，缺乏单侧 p = {low:.3g}，过剩单侧 p = {high:.3g}")
        out[name] = {"counts": [a, b, c], "expected": exp.round(4).tolist(), "F": F, "chisq": X2, "p_chisq": pchi,
                     "p_exact_two_sided": two, "p_deficit": low, "p_excess": high}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex04_15_hwe_exact.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
