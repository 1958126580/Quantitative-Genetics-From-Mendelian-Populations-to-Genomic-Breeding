#!/usr/bin/env python3
"""习题 4.16  多等位基因标记的信息量：杂合度、PIC 与亲子排除概率

对每个位点（等位基因频率 p_i）：
    期望杂合度 H = 1 − Σp_i²
    多态信息含量 PIC = 1 − Σp_i² − Σ_{i<j} 2 p_i² p_j²            (Botstein 1980)
    单亲已知时的排除概率（Jamieson & Taylor 1997）：
        P_ex = 1 − 2Σp_i² + Σp_i³ + 2Σp_i⁴ − 3Σp_i⁵ − 2(Σp_i²)² + 3Σp_i²Σp_i³
多位点组合（独立位点）：P_comb = 1 − Π(1 − P_ex,k)。
程序给出各位点指标、组合排除概率，并求达到 0.999 所需的 SNP（MAF=0.4）数目；
同时用模拟的“错误父亲”核对单位点排除概率公式。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def metrics(p):
    p = np.asarray(p, float); s2, s3, s4, s5 = (np.sum(p ** k) for k in (2, 3, 4, 5))
    H = 1 - s2
    pic = H - sum(2 * p[i] ** 2 * p[j] ** 2 for i in range(len(p)) for j in range(i + 1, len(p)))
    pex = 1 - 2 * s2 + s3 + 2 * s4 - 3 * s5 - 2 * s2 ** 2 + 3 * s2 * s3
    return H, pic, pex


def simulate_exclusion(p, reps, rng):
    """母亲已知：抽母亲、真父亲产生后代；另抽一个无关雄性，判断其能否被排除。"""
    k = len(p); a = lambda size: rng.choice(k, size=size, p=p)
    m = a((reps, 2)); f = a((reps, 2)); x = a((reps, 2))
    mat = m[np.arange(reps), rng.integers(0, 2, reps)]; pat = f[np.arange(reps), rng.integers(0, 2, reps)]
    child = np.column_stack([mat, pat])
    excl = np.zeros(reps, bool)
    for r in range(reps):
        # 后代中可能来自父亲的等位基因：去掉一个与母亲相容的等位基因后剩余者
        c0, c1 = child[r]; mo = set(m[r])
        cand = set()
        if c0 in mo: cand.add(c1)
        if c1 in mo: cand.add(c0)
        excl[r] = not (cand & set(x[r]))
    return excl.mean()


def main():
    cfg = json.loads((HERE / "data" / "ex04_16_markers.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(416); rows = {}; prod = 1.0
    print(f"{'位点':<6s}{'等位基因数':>8s}{'H':>8s}{'PIC':>8s}{'P_ex':>8s}{'模拟P_ex':>10s}")
    for name, p in cfg["loci"].items():
        H, pic, pex = metrics(p)
        sim = simulate_exclusion(np.array(p), 40000, rng)
        assert abs(sim - pex) < 0.012, f"{name} 排除概率模拟核对失败"
        rows[name] = {"k": len(p), "H": round(H, 4), "PIC": round(pic, 4), "P_ex": round(pex, 4), "P_ex_sim": round(float(sim), 4)}
        if name != "SNP": prod *= (1 - pex)
        print(f"{name:<6s}{len(p):8d}{H:8.4f}{pic:8.4f}{pex:8.4f}{sim:10.4f}")
    comb = 1 - prod
    q = cfg["snp_maf_for_panel"]; _, _, pex_snp = metrics([q, 1 - q])
    need = int(np.ceil(np.log(1 - cfg["target_exclusion"]) / np.log(1 - pex_snp)))
    print(f"5 个微卫星的组合排除概率 = {comb:.5f}")
    print(f"MAF = {q} 的 SNP 单位点排除概率 = {pex_snp:.4f}；达到 {cfg['target_exclusion']} 需要 {need} 个独立 SNP")
    out = {"loci": rows, "combined_microsatellites": comb, "snp_pex": pex_snp, "snp_needed": need}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex04_16_marker_information.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
