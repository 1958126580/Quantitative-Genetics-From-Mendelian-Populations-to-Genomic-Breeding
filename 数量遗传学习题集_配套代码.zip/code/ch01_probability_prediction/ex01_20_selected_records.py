#!/usr/bin/env python3
"""习题 1.20  只有第一次记录优秀者才有第二次记录：选择对回归、相关与均值的影响

两次标准化记录 (y1, y2) 服从相关为 t（重复力）的二元正态。仅 y1 位于上侧比例 p 的
个体保留第二次记录（选择只依赖已观察的 y1，属“随机缺失 MAR”）。
截断理论（Pearson–Aitken）：x = Φ⁻¹(1-p)，i = φ(x)/p，k = i(i-x)
    E(y1|S)=i,           Var(y1|S)=1-k
    E(y2|S)=t·i,         Var(y2|S)=1-t²k,  Cov=t(1-k)
    回归 b(y2|y1, S) = t                  （不受选择影响）
    相关 r(y1,y2|S) = t√[(1-k)/(1-t²k)]   （被选择压低）
程序比较解析值与模拟值，并说明“用被选样本的相关估计重复力”会低估多少。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def analytic(t, p):
    x = norm.isf(p); i = norm.pdf(x) / p; k = i * (i - x)
    return dict(x=x, i=i, k=k, mean_y1=i, mean_y2=t * i, var_y1=1 - k, var_y2=1 - t * t * k,
                cov=t * (1 - k), slope=t, corr=t * np.sqrt((1 - k) / (1 - t * t * k)))


def main():
    cfg = json.loads((HERE / "data" / "ex01_20_selected_records.json").read_text(encoding="utf-8"))
    t, p, N = cfg["repeatability"], cfg["selected_fraction"], cfg["n_animals"]
    rng = np.random.default_rng(cfg["seed"])
    z = rng.multivariate_normal([0, 0], [[1, t], [t, 1]], size=N)
    a = analytic(t, p)
    sel = z[:, 0] > a["x"]
    y1, y2 = z[sel, 0], z[sel, 1]
    sim = dict(mean_y1=y1.mean(), mean_y2=y2.mean(), var_y1=y1.var(ddof=1), var_y2=y2.var(ddof=1),
               cov=np.cov(y1, y2)[0, 1], slope=np.polyfit(y1, y2, 1)[0], corr=np.corrcoef(y1, y2)[0, 1])
    print(f"截断点 x={a['x']:.4f}, 选择强度 i={a['i']:.4f}, k={a['k']:.4f}")
    print(f"{'量':<10s}{'解析':>10s}{'模拟':>10s}")
    for key in sim:
        print(f"{key:<10s}{a[key]:10.4f}{sim[key]:10.4f}")
        assert abs(a[key] - sim[key]) < 0.01, key
    print(f"以被选样本相关估计重复力：{a['corr']:.4f}（真实 {t}），相对低估 {(1-a['corr']/t)*100:.1f}%")
    out = {"analytic": {k: round(float(v), 5) for k, v in a.items()}, "simulated": {k: round(float(v), 5) for k, v in sim.items()}}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex01_20_selected_records.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
