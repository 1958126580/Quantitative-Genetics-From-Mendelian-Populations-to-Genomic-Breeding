#!/usr/bin/env python3
"""习题 1.16  自身、母亲与父系半同胞三种信息的最佳线性预测

模型（无共同环境、母羊之间无亲缘、公羊与母羊无亲缘）
    y1 = 候选个体自身记录, y2 = 母亲记录, y3 = n 只父系半同胞(不含自身)的平均记录
    目标 u = 候选个体加性育种值。
    c  = Cov(y, u)  = σA² (1, 1/2, 1/4)ᵀ
    P  = Var(y)：对角 σP², σP², σP²[1+(n-1)t]/n，t = h²/4；
         Cov(y1,y2)=σA²/2, Cov(y1,y3)=σA²/4, Cov(y2,y3)=0
    b = P⁻¹c,  û = bᵀy,  r² = cᵀP⁻¹c / σA²,  PEV = σA² - cᵀP⁻¹c

本程序
    1. Cholesky 分解求解指数方程，并与直接求解核对；
    2. 比较单一信息、两两组合与三者组合的可靠度（信息的“边际价值”）；
    3. 按孟德尔传递规律模拟 4000 个公羊家系，用经验回归独立核对理论权重。
"""
from __future__ import annotations
import json
from itertools import combinations
from pathlib import Path
import numpy as np
from scipy.linalg import cho_factor, cho_solve

HERE = Path(__file__).resolve().parent
NAMES = ["own", "dam", "halfsib_mean"]
LABEL = {"own": "自身", "dam": "母亲", "halfsib_mean": "半同胞均值"}


def build(s2p: float, h2: float, n: int):
    s2a = h2 * s2p
    t = h2 / 4.0
    c = s2a * np.array([1.0, 0.5, 0.25])
    P = np.array([[s2p, s2a / 2, s2a / 4],
                  [s2a / 2, s2p, 0.0],
                  [s2a / 4, 0.0, s2p * (1 + (n - 1) * t) / n]])
    return s2a, c, P


def index_stats(c, P, s2a, idx):
    idx = list(idx)
    Pi, ci = P[np.ix_(idx, idx)], c[idx]
    b = cho_solve(cho_factor(Pi), ci)
    assert np.allclose(b, np.linalg.solve(Pi, ci))
    gain = float(ci @ b)
    return b, gain / s2a, s2a - gain


def simulate(s2p, h2, n, fam, seed):
    """模拟：每个家系 1 只公羊、n+1 只半同胞后代（第 0 只为候选者），每只后代有各自的母亲。"""
    rng = np.random.default_rng(seed)
    s2a = h2 * s2p; s2e = s2p - s2a
    us = rng.normal(0, np.sqrt(s2a), fam)
    ud = rng.normal(0, np.sqrt(s2a), (fam, n + 1))
    ms = rng.normal(0, np.sqrt(s2a / 2), (fam, n + 1))            # 孟德尔抽样
    uo = 0.5 * us[:, None] + 0.5 * ud + ms
    yo = uo + rng.normal(0, np.sqrt(s2e), (fam, n + 1))
    ydam = ud[:, 0] + rng.normal(0, np.sqrt(s2e), fam)
    X = np.column_stack([yo[:, 0], ydam, yo[:, 1:].mean(axis=1)])
    target = uo[:, 0]
    Xc = X - X.mean(0)
    b_hat = np.linalg.lstsq(Xc, target - target.mean(), rcond=None)[0]
    return b_hat


def main():
    cfg = json.loads((HERE / "data" / "ex01_16_three_sources.json").read_text(encoding="utf-8"))
    s2p, h2, n = cfg["sigma2_P"], cfg["h2"], cfg["n_halfsibs"]
    s2a, c, P = build(s2p, h2, n)
    y = np.array([cfg["deviations"][k] for k in NAMES])
    assert np.all(np.linalg.eigvalsh(P) > 0), "协方差矩阵非正定"
    print(f"σA²={s2a}, 半同胞均值方差={P[2,2]:.4f}")
    table = []
    for k in (1, 2, 3):
        for idx in combinations(range(3), k):
            b, rel, pev = index_stats(c, P, s2a, idx)
            pred = float(b @ y[list(idx)])
            row = {"sources": [LABEL[NAMES[i]] for i in idx], "weights": b.round(5).tolist(),
                   "reliability": round(rel, 5), "accuracy": round(rel ** 0.5, 5), "PEV": round(pev, 4), "EBV": round(pred, 4)}
            table.append(row)
            print(f"{'+'.join(row['sources']):<16s} b={np.round(b,4)}  r²={rel:.4f}  r={rel**0.5:.4f}  PEV={pev:.3f}  EBV={pred:.3f}")
    b_full = index_stats(c, P, s2a, range(3))[0]
    sim = simulate(s2p, h2, n, cfg["simulation"]["n_families"] * 10, cfg["simulation"]["seed"])
    print("理论权重:", np.round(b_full, 4), " 模拟回归权重:", np.round(sim, 4))
    assert np.allclose(sim, b_full, atol=0.02), "模拟与理论差异过大"
    out = {"sigma2_A": s2a, "P": P.round(5).tolist(), "c": c.tolist(), "combinations": table,
           "simulated_weights": sim.round(4).tolist()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex01_16_three_sources.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
