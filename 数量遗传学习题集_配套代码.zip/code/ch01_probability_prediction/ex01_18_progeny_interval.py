#!/usr/bin/env python3
"""习题 1.18  公羊未来后代均值的预测区间

设公羊育种值的条件分布为 u_s | 信息 ~ N(û, PEV)，与随机、无亲缘母羊交配，
每只后代  y = μ + u_s/2 + u_d/2 + φ + e，其中 Var(u_d)=σA²，孟德尔抽样 Var(φ)=σA²/2，
环境 Var(e)=σE²，各后代的母羊、φ、e 相互独立。
n 只未来后代均值相对 μ 的预测：   E = û/2
预测误差方差：                  V(n) = PEV/4 + (3σA²/4 + σE²)/n
当 n→∞ 时 V → PEV/4，即“后代越多，区间越窄，但永远窄不过公羊自身育种值的不确定性”。
程序给出解析区间，并用分层蒙特卡洛模拟核对覆盖率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def interval(ebv, pev, s2a, s2e, n, cov):
    m = ebv / 2
    v = pev / 4 + (0.75 * s2a + s2e) / n
    z = norm.ppf(0.5 + cov / 2)
    return m, v, (m - z * np.sqrt(v), m + z * np.sqrt(v))


def mc_coverage(ebv, pev, s2a, s2e, n, cov, reps, rng):
    us = rng.normal(ebv, np.sqrt(pev), reps)                 # 从条件分布抽取公羊真值
    noise_sd = np.sqrt((0.75 * s2a + s2e) / n)                # n 只后代的独立部分之均值
    ybar = us / 2 + rng.normal(0, noise_sd, reps)
    m, v, (lo, hi) = interval(ebv, pev, s2a, s2e, n, cov)
    return float(np.mean((ybar >= lo) & (ybar <= hi)))


def main():
    cfg = json.loads((HERE / "data" / "ex01_18_progeny_interval.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    rows = []
    print(f"{'n':>6s} {'预测均值':>8s} {'误差方差':>10s} {'标准差':>8s} {'95%区间':>22s} {'MC覆盖率':>8s}")
    for n in cfg["n_values"]:
        m, v, (lo, hi) = interval(cfg["ebv"], cfg["pev"], cfg["sigma2_A"], cfg["sigma2_E"], n, cfg["coverage"])
        cv = mc_coverage(cfg["ebv"], cfg["pev"], cfg["sigma2_A"], cfg["sigma2_E"], n, cfg["coverage"], cfg["mc_reps"], rng)
        assert abs(cv - cfg["coverage"]) < 0.005
        rows.append({"n": n, "mean": m, "var": round(v, 5), "sd": round(v ** 0.5, 5), "lower": round(lo, 4), "upper": round(hi, 4), "mc_coverage": round(cv, 4)})
        print(f"{n:6d} {m:8.3f} {v:10.4f} {v**0.5:8.4f}   ({lo:8.3f}, {hi:8.3f}) {cv:8.4f}")
    lim = cfg["pev"] / 4
    print(f"n→∞ 的极限误差方差 = PEV/4 = {lim}，标准差 = {lim**0.5:.4f}")
    out = {"rows": rows, "limit_var": lim}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex01_18_progeny_interval.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
