# 第1章　概率、期望与遗传预测问题——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex01_15_progeny_test.py
python3 ex01_16_three_sources.py
python3 ex01_18_progeny_interval.py
python3 ex01_19_calibration.py
python3 ex01_20_selected_records.py
python3 ex01_22_value_of_information.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex01_15_progeny_test.py | 1.15 | 隐性缺陷携带者的后裔测验：贝叶斯后验与所需后代数 |
| ex01_16_three_sources.py | 1.16 | 自身、母亲与父系半同胞三种信息的最佳线性预测 |
| ex01_18_progeny_interval.py | 1.18 | 公羊未来后代均值的预测区间 |
| ex01_19_calibration.py | 1.19 | 遗传力设定错误时：相关不变，校准与均方误差改变 |
| ex01_20_selected_records.py | 1.20 | 只有第一次记录优秀者才有第二次记录：选择对回归、相关与均值的影响 |
| ex01_22_value_of_information.py | 1.22 | 留种决策中的信息价值：何时值得再测定一次？ |
