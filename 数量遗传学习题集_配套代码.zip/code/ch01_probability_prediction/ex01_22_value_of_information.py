#!/usr/bin/env python3
"""习题 1.22  留种决策中的信息价值：何时值得再测定一次？

决策：保留公羊的收益为 (u - T)×单价，淘汰收益为 0（T 为留种阈值）。
当前 u ~ N(m, s²)。若先做一次测定，测定后条件均值 m* ~ N(m, s² - v1)，v1 为测定后 PEV。
信息价值（每只公羊、性状单位）：
    VOI = E[max(m* - T, 0)] - max(m - T, 0)
        = σ*·[φ(z) - z(1-Φ(z))] + (m-T)⁺ 修正，  σ* = √(s² - v1)，z = (T - m)/σ*  （m<T 时）
一般式：E[max(X - T, 0)] = (m - T)Φ(-z) + σ*φ(z)，X ~ N(m, σ*²)。
程序给出解析值、蒙特卡洛核对，并扫描测定可靠度求盈亏平衡点。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent


def expected_positive_part(m, sd, T):
    if sd == 0:
        return max(m - T, 0.0)
    z = (T - m) / sd
    return (m - T) * norm.sf(z) + sd * norm.pdf(z)


def voi(m, s2, v1, T):
    return expected_positive_part(m, np.sqrt(max(s2 - v1, 0.0)), T) - max(m - T, 0.0)


def main():
    cfg = json.loads((HERE / "data" / "ex01_22_value_of_information.json").read_text(encoding="utf-8"))
    m, s2, T, v1 = cfg["prior_mean"], cfg["prior_var"], cfg["threshold"], cfg["posterior_var_after_test"]
    price, cost = cfg["value_per_unit"], cfg["test_cost"]
    val = voi(m, s2, v1, T)
    rng = np.random.default_rng(cfg["seed"])
    u = rng.normal(m, np.sqrt(s2), cfg["reps"])                  # 真值
    # 测定提供信号 x = u + ε，使后验方差为 v1：Var(ε) = s2*v1/(s2-v1)
    x = u + rng.normal(0, np.sqrt(s2 * v1 / (s2 - v1)), cfg["reps"])
    mstar = m + (s2 - v1) / s2 * (x - m)
    gain_mc = np.mean(np.where(mstar > T, u - T, 0.0)) - max(m - T, 0.0)
    print(f"σ* = {np.sqrt(s2-v1):.4f}, z = {(T-m)/np.sqrt(s2-v1):.4f}")
    print(f"信息价值（性状单位）解析 = {val:.4f}，蒙特卡洛 = {gain_mc:.4f}")
    assert abs(val - gain_mc) < 0.01
    print(f"折合金额 = {val*price:.2f}，测定成本 = {cost}，净值 = {val*price-cost:.2f}")
    # 扫描：测定把 PEV 从 s2 降到 v1 的不同程度
    grid = np.linspace(0.0, s2, 41)
    curve = [voi(m, s2, v, T) * price for v in grid]
    be = brentq(lambda v: voi(m, s2, v, T) * price - cost, 1e-9, s2 - 1e-9)
    print(f"盈亏平衡：测定后 PEV 需不大于 {be:.4f}（相当于测定把可靠度从 0 提高到 {1-be/s2:.4f}）")
    out = {"voi_units": round(val, 5), "voi_mc": round(float(gain_mc), 5), "voi_money": round(val * price, 3),
           "net": round(val * price - cost, 3), "break_even_pev": round(be, 5),
           "scan": [{"pev_after": round(float(v), 3), "voi_money": round(float(c), 3)} for v, c in zip(grid, curve)]}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex01_22_value_of_information.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    plt = get_pyplot()
    if plt is not None:
        fig, ax = plt.subplots(figsize=(6, 3.8))
        ax.plot(grid, curve, lw=2); ax.axhline(cost, ls="--", c="gray", label="测定成本")
        ax.axvline(be, ls=":", c="k"); ax.set_xlabel("测定后的 PEV"); ax.set_ylabel("信息价值（元/只）"); ax.legend()
        fig.tight_layout(); fig.savefig(HERE / "results" / "ex01_22_value_of_information.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    main()
