#!/usr/bin/env python3
"""习题 1.15  隐性缺陷携带者的后裔测验：贝叶斯后验与所需后代数

问题
    一只候选公羊依系谱携带隐性缺陷等位基因的先验概率为 π0。让它与某类母羊
    交配，若公羊是携带者，每只后代患病的概率为 θ（取决于母羊类型）；若不是
    携带者，后代不会患病。观察到 n 只后代全部正常后，公羊为携带者的后验概率
        P(C | n 正常) = π0 (1-θ*)^n / [π0 (1-θ*)^n + (1-π0)],
    其中 θ* = θ·Se 为“患病且被正确诊断”的概率，Se 为诊断灵敏度。

本程序
    1. 对三种交配设计计算 n = 0..N 的后验概率；
    2. 求后验概率降到目标值以下所需的最少后代数（解析对数解与逐项搜索互相核对）；
    3. 用蒙特卡洛模拟独立复核后验概率；
    4. 输出 results/ex01_15_progeny_test.json 与后验曲线图。
"""
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent
DATA = HERE / "data" / "ex01_15_progeny_test.json"
OUT = HERE / "results"


def posterior_carrier(prior: float, theta: float, n: np.ndarray | int) -> np.ndarray:
    """n 只后代全部(被诊断为)正常时公羊为携带者的后验概率。"""
    like_c = (1.0 - theta) ** np.asarray(n, dtype=float)
    return prior * like_c / (prior * like_c + (1.0 - prior))


def min_progeny_analytic(prior: float, theta: float, target: float) -> int:
    """解 prior (1-θ)^n / [prior (1-θ)^n + 1 - prior] <= target 的最小整数 n。"""
    if prior <= target:
        return 0
    ratio = target * (1 - prior) / ((1 - target) * prior)   # 需要 (1-θ)^n <= ratio
    return int(math.ceil(math.log(ratio) / math.log(1 - theta) - 1e-12))


def monte_carlo(prior: float, theta: float, n: int, reps: int, rng: np.random.Generator) -> float:
    """模拟“先抽公羊身份、再抽 n 只后代”，以全部正常的样本估计后验概率。"""
    carrier = rng.random(reps) < prior
    affected = rng.binomial(n, theta, size=reps)
    affected[~carrier] = 0
    keep = affected == 0
    return float(carrier[keep].mean())


def main() -> None:
    cfg = json.loads(DATA.read_text(encoding="utf-8"))
    prior, target, nmax, se = cfg["prior_carrier"], cfg["target_posterior"], cfg["max_progeny"], cfg["diagnostic_sensitivity"]
    rng = np.random.default_rng(2026)
    n = np.arange(nmax + 1)
    results = {"prior_carrier": prior, "target_posterior": target, "designs": {}}
    print(f"先验携带概率 π0 = {prior}, 目标后验 ≤ {target}\n")
    for name, theta in cfg["designs"].items():
        out = {}
        for label, th in (("完全诊断", theta), (f"灵敏度{se}", theta * se)):
            post = posterior_carrier(prior, th, n)
            n_ana = min_progeny_analytic(prior, th, target)
            n_scan = int(np.argmax(post <= target)) if np.any(post <= target) else None
            n_far = n_ana if n_ana <= 200 else None
            if n_scan is not None:
                assert n_scan == n_ana, "解析解与逐项搜索不一致"
            mc = monte_carlo(prior, th, 8, 400_000, rng)
            assert abs(mc - posterior_carrier(prior, th, 8)) < 0.01, "蒙特卡洛复核失败"
            out[label] = {"theta_effective": th, "posterior_by_n": post.round(6).tolist(),
                          "min_progeny": n_far, "posterior_at_8_MC": round(mc, 4)}
            print(f"{name:<20s}{label:<10s} θ*={th:.4f}  n=5 后验={post[5]:.4f}  "
                  f"n=10 后验={post[10]:.4f}  所需后代数={n_ana}")
        results["designs"][name] = out
    OUT.mkdir(exist_ok=True)
    (OUT / "ex01_15_progeny_test.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    plt = get_pyplot()
    if plt is not None:
        fig, ax = plt.subplots(figsize=(6.4, 4))
        for name, theta in cfg["designs"].items():
            ax.plot(n, posterior_carrier(prior, theta, n), marker="o", ms=3, label=name)
        ax.axhline(target, ls="--", c="gray"); ax.set_yscale("log")
        ax.set_xlabel("全部正常的后代数 n"); ax.set_ylabel("公羊为携带者的后验概率"); ax.legend(fontsize=8)
        fig.tight_layout(); fig.savefig(OUT / "ex01_15_progeny_test.png", dpi=160); plt.close(fig)

if __name__ == "__main__":
    main()
