#!/usr/bin/env python3
"""习题 1.19  遗传力设定错误时：相关不变，校准与均方误差改变

真实模型：y = u + e，Var(u)=σA²，h² 为真实遗传力。
评定者用假设遗传力 h̃² 计算 û = h̃² y（单记录，均值已知）。
理论：
    相关 r(u, û) = √h²（与 h̃² 无关）
    校准斜率 b(u|û) = Cov(u,û)/Var(û) = h²/h̃²
    MSE = σA² - 2h̃²σA² + h̃⁴σA²/h²
Murphy 分解：MSE = (E u - E û)² + σu²(1-ρ²) + (ρσu - σû)²
              = 偏差² + 不可约误差(该信息下) + 离散度失配
本程序用 20 万只模拟动物逐项核对上述解析式。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def theory(h2, h2a, s2a):
    corr = np.sqrt(h2)
    slope = h2 / h2a
    mse = s2a - 2 * h2a * s2a + h2a ** 2 * s2a / h2
    irreducible = s2a * (1 - h2)
    dispersion = (corr * np.sqrt(s2a) - h2a * np.sqrt(s2a / h2)) ** 2
    return dict(corr=corr, slope=slope, mse=mse, irreducible=irreducible, dispersion=dispersion)


def main():
    cfg = json.loads((HERE / "data" / "ex01_19_calibration.json").read_text(encoding="utf-8"))
    h2, s2a, N = cfg["true_h2"], cfg["sigma2_A"], cfg["n_animals"]
    rng = np.random.default_rng(cfg["seed"])
    u = rng.normal(0, np.sqrt(s2a), N)
    y = u + rng.normal(0, np.sqrt(s2a * (1 - h2) / h2), N)
    rows = []
    print(f"{'假设h²':>6s} {'相关':>7s} {'斜率(理论)':>10s} {'斜率(模拟)':>10s} {'MSE(理论)':>9s} {'MSE(模拟)':>9s} {'离散失配':>8s}")
    for h2a in cfg["assumed_h2"]:
        uh = h2a * y
        corr = np.corrcoef(u, uh)[0, 1]
        slope = np.cov(u, uh)[0, 1] / np.var(uh, ddof=1)
        mse = np.mean((u - uh) ** 2)
        bias2 = (u.mean() - uh.mean()) ** 2
        su, sh = u.std(ddof=0), uh.std(ddof=0)
        decomp = bias2 + su ** 2 * (1 - corr ** 2) + (corr * su - sh) ** 2
        assert np.isclose(decomp, mse, rtol=1e-10), "Murphy 分解恒等式不成立"
        th = theory(h2, h2a, s2a)
        assert abs(slope - th["slope"]) < 0.02 * th["slope"] + 0.01 and abs(mse - th["mse"]) < 0.02
        rows.append({"assumed_h2": h2a, "corr_sim": round(corr, 4), "slope_theory": round(th["slope"], 4), "slope_sim": round(slope, 4),
                     "mse_theory": round(th["mse"], 4), "mse_sim": round(mse, 4), "dispersion_theory": round(th["dispersion"], 4),
                     "irreducible": round(th["irreducible"], 4)})
        print(f"{h2a:6.2f} {corr:7.4f} {th['slope']:10.4f} {slope:10.4f} {th['mse']:9.4f} {mse:9.4f} {th['dispersion']:8.4f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex01_19_calibration.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
