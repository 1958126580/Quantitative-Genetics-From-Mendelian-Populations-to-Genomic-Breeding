"""绘图辅助：自动选择本机可用的中文字体（仅供本文件夹中的程序调用）。"""
import warnings


def get_pyplot():
    """返回已配置中文字体的 matplotlib.pyplot；未安装 matplotlib 时返回 None。"""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib import font_manager
    except ImportError:
        return None
    warnings.filterwarnings("ignore", category=UserWarning, module="matplotlib")
    names = {f.name for f in font_manager.fontManager.ttflist}
    for cand in ("Noto Sans CJK SC", "Source Han Sans SC", "Microsoft YaHei", "SimHei",
                 "PingFang SC", "Heiti SC", "WenQuanYi Zen Hei", "Arial Unicode MS"):
        if cand in names:
            matplotlib.rcParams["font.family"] = [cand, "DejaVu Sans"]
            break
    matplotlib.rcParams["axes.unicode_minus"] = False
    matplotlib.rcParams["figure.dpi"] = 110
    return plt
