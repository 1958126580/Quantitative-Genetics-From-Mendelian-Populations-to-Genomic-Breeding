#!/usr/bin/env python3
"""习题 7.16  全基因组扫描的置换阈值（Churchill–Doerge 1994）与 Lander–Botstein 理论近似

回交 200 个体，5 条 100 cM 染色体、每 10 cM 一个标记、每 2 cM 检测一次（Haley–Knott 回归，
BC 中检测位置的 QTL 条件概率仅由两侧标记决定，可写成闭式）。
零假设资料（无 QTL）上做 1000 次表型置换，记录每次全基因组最大 LOD，取其分位数作为阈值。
Lander–Botstein (1989) 稠密图近似（回交 ρ = 1，G 为总长度摩尔根，C 为染色体数）：
    P(max LOD > T) ≈ (C + 2ρ G Z²)·[1 − Φ(Z)]，  Z² = 2 ln(10) T
程序比较两种阈值与单点名义阈值（χ²₁ 的 α 分位数换算为 LOD）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm, chi2
from scipy.optimize import brentq

HERE = Path(__file__).resolve().parent
hal = lambda d: 0.5 * (1 - np.exp(-2 * np.abs(d) / 100))


def bc_genoprob(M, mpos, x):
    """BC 中位置 x 处 QTL 为杂合子(1)的概率，只依赖两侧标记。"""
    j = np.searchsorted(mpos, x, side="right") - 1
    if j >= len(mpos) - 1 or np.isclose(x, mpos[j]):
        jj = min(j, len(mpos) - 1); return M[:, jj].astype(float)
    r1, r2, r = hal(x - mpos[j]), hal(mpos[j + 1] - x), hal(mpos[j + 1] - mpos[j])
    L, R = M[:, j], M[:, j + 1]
    p11 = (1 - r1) * (1 - r2) / (1 - r); p10 = (1 - r1) * r2 / r; p01 = r1 * (1 - r2) / r; p00 = r1 * r2 / (1 - r)
    return np.where((L == 1) & (R == 1), p11, np.where((L == 1) & (R == 0), p10, np.where((L == 0) & (R == 1), p01, p00)))


def scan_max(Ps, Y):
    """Ps: 所有检测位置的条件概率列（n×K），Y: n×B 表型矩阵 → 每列的最大 LOD。"""
    n = Y.shape[0]; Yc = Y - Y.mean(0); rss0 = np.sum(Yc ** 2, 0)
    Pc = Ps - Ps.mean(0); ss = np.sum(Pc ** 2, 0)
    cov = Pc.T @ Yc                                   # K×B
    rss1 = rss0[None, :] - cov ** 2 / ss[:, None]
    return (n / 2 * np.log10(rss0[None, :] / rss1)).max(0)


def main():
    cfg = json.loads((HERE / "data" / "ex07_16_scan.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n"]
    mpos = np.arange(0, cfg["chrom_cM"] + 1e-9, cfg["marker_spacing_cM"]); grid = np.arange(0, cfg["chrom_cM"] + 1e-9, cfg["step_cM"])
    cols = []
    for _ in range(cfg["n_chrom"]):
        M = np.zeros((n, len(mpos)), int); M[:, 0] = rng.integers(0, 2, n)
        for j in range(1, len(mpos)): M[:, j] = np.where(rng.random(n) < hal(mpos[j] - mpos[j - 1]), 1 - M[:, j - 1], M[:, j - 1])
        cols += [bc_genoprob(M, mpos, x) for x in grid]
    Ps = np.column_stack(cols)
    y = rng.normal(0, 1, n)
    Y = np.column_stack([rng.permutation(y) for _ in range(cfg["n_perm"])])
    mx = scan_max(Ps, Y)
    G = cfg["n_chrom"] * cfg["chrom_cM"] / 100; C = cfg["n_chrom"]
    def lb(T): Z = np.sqrt(2 * np.log(10) * T); return (C + 2 * G * Z * Z) * norm.sf(Z)
    out = {"G_Morgan": G, "thresholds": {}}
    print(f"总长 G = {G} M，C = {C}，检测位置 {Ps.shape[1]} 个，置换 {cfg['n_perm']} 次")
    print(f"{'α':>6s}{'置换阈值':>10s}{'Lander–Botstein':>16s}{'单点名义':>10s}")
    for a in cfg["alpha"]:
        perm = float(np.quantile(mx, 1 - a)); theo = brentq(lambda T: lb(T) - a, 0.5, 10)
        point = chi2.isf(a, 1) / (2 * np.log(10))
        out["thresholds"][str(a)] = {"permutation": perm, "lander_botstein": theo, "pointwise": point}
        print(f"{a:6.2f}{perm:10.3f}{theo:16.3f}{point:10.3f}")
    est_tests = np.log(0.95) / np.log(1 - chi2.sf(out["thresholds"]["0.05"]["permutation"] * 2 * np.log(10), 1))
    print(f"相当于约 {est_tests:.0f} 个独立检验（按 5% 阈值反推）")
    out["effective_tests"] = est_tests
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex07_16_permutation_threshold.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
