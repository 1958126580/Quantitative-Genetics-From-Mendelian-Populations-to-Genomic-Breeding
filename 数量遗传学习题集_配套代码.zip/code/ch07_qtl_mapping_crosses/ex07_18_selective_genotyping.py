#!/usr/bin/env python3
"""习题 7.18  选择性基因分型：功效、偏差与基于全部表型的似然校正

回交群体 1000 个体全部测表型，QTL 位于标记处（BC 中两类基因型差 a = 0.25σe）。只对表型两尾各 p/2 的个体分型。
比较三种分析（重复 1000 次）：
    (a) 全部分型的 t 检验；
    (b) 仅分型个体、朴素 t 检验：效应估计被放大（尾部选择抬高组间差）；
    (c) 似然校正：把未分型个体当作基因型缺失的混合正态，用全部表型的似然估计 a（EM）。
报告各方案的功效（α = 0.001）、效应估计均值，以及“每个分型个体的信息效率”。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent


def em_mixture(y, g, iters=200):
    """g: 0/1 已分型，−1 未分型（先验 1/2）。模型 y ~ N(μ + a·g, σ²)。"""
    obs = g >= 0; mu, a, s = y.mean(), 0.0, y.std()
    for _ in range(iters):
        f1 = stats.norm.pdf(y, mu + a, s); f0 = stats.norm.pdf(y, mu, s)
        w = np.where(obs, g.astype(float), f1 / (f1 + f0))
        X = np.column_stack([np.ones_like(y), w]); W1 = w; W0 = 1 - w
        # 加权最小二乘：期望完全数据充分统计量
        mu = np.sum(W0 * y) / W0.sum(); a = np.sum(W1 * y) / W1.sum() - mu
        s = np.sqrt((np.sum(W0 * (y - mu) ** 2) + np.sum(W1 * (y - mu - a) ** 2)) / len(y))
    return a


def main():
    cfg = json.loads((HERE / "data" / "ex07_18_selective.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n, a, R, al = cfg["n_phenotyped"], cfg["a_bc"], cfg["reps"], cfg["alpha"]
    out = {}
    print(f"{'分型比例':>8s}{'分型数':>7s}{'功效':>8s}{'朴素â均值':>11s}{'似然â均值':>11s}{'每分型个体的χ²':>14s}")
    for p in cfg["tail_fractions"]:
        hits, naive, mle, chis = 0, [], [], []
        for _ in range(R):
            g = rng.integers(0, 2, n); y = a * g + rng.normal(0, cfg["sigma_e"], n)
            if p < 1:
                lo, hi = np.quantile(y, [p / 2, 1 - p / 2]); sel = (y <= lo) | (y >= hi)
            else:
                sel = np.ones(n, bool)
            t = stats.ttest_ind(y[sel & (g == 1)], y[sel & (g == 0)]); hits += t.pvalue < al; chis.append(t.statistic ** 2)
            naive.append(y[sel & (g == 1)].mean() - y[sel & (g == 0)].mean())
            if p < 1 and len(mle) < 100:
                gg = np.where(sel, g, -1); mle.append(em_mixture(y, gg))
        k = int(round(n * p)); row = {"fraction": p, "n_genotyped": k, "power": hits / R, "naive_a_mean": float(np.mean(naive)),
                                      "mle_a_mean": float(np.mean(mle)) if mle else float(np.mean(naive)), "chisq_per_genotyped": float(np.mean(chis)) / k}
        out[str(p)] = row
        print(f"{p:8.2f}{k:7d}{row['power']:8.3f}{row['naive_a_mean']:11.4f}{row['mle_a_mean']:11.4f}{row['chisq_per_genotyped']:14.5f}")
    print(f"真值 a = {a}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex07_18_selective_genotyping.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
