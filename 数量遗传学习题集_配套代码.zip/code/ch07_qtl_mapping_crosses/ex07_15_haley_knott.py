#!/usr/bin/env python3
"""习题 7.15  F2 群体的 Haley–Knott 回归区间作图与单标记分析比较

模拟 300 个 F2、11 个共显性标记（每 10 cM），47 cM 处 QTL：a = 0.6, d = 0.3, σe = 1。
Haley–Knott (1992)：在每个检测位置 x，用 HMM（F2 的三状态马尔可夫链，Haldane 无干涉）计算
QTL 基因型条件概率 P(QQ|M), P(Qq|M), P(qq|M)，回归
    y = μ + a·[P(QQ) − P(qq)] + d·P(Qq) + e，
LOD(x) = (n/2) log10(RSS0 / RSS1)。另做单标记 2 自由度回归作对照。
输出 LOD 曲线、峰位置、a、d 估计、1.5-LOD 支持区间及 QTL 解释的表型方差比例。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent
hal = lambda d: 0.5 * (1 - np.exp(-2 * np.abs(d) / 100))


def f2_transition(c):
    """F2 基因型 (0=qq,1=Qq,2=QQ) 沿染色体的转移矩阵（两条独立配子各自以 c 切换）。"""
    r, s = c, 1 - c
    return np.array([[s * s, 2 * r * s, r * r], [r * s, s * s + r * r, r * s], [r * r, 2 * r * s, s * s]])


def simulate(cfg, rng):
    pos = sorted(cfg["marker_cM"] + [cfg["qtl_cM"]]); n = cfg["n"]
    gam = np.zeros((n, 2, len(pos)), int); gam[:, :, 0] = rng.integers(0, 2, (n, 2))
    for j in range(1, len(pos)):
        c = hal(pos[j] - pos[j - 1]); flip = rng.random((n, 2)) < c
        gam[:, :, j] = np.where(flip, 1 - gam[:, :, j - 1], gam[:, :, j - 1])
    G = gam.sum(1); k = pos.index(cfg["qtl_cM"])
    q = G[:, k]; y = cfg["a"] * (q - 1) + cfg["d"] * (q == 1) + rng.normal(0, cfg["sigma_e"], n)
    M = np.delete(G, k, axis=1)
    return M, y, q


def genoprob(M, mpos, x):
    """给定全部标记，计算位置 x 处 QTL 基因型后验（前向—后向，三状态）。"""
    allpos = np.array(mpos, float); n, m = M.shape
    # 在 x 处插入一个无观测的伪标记
    j = np.searchsorted(allpos, x); pos = np.insert(allpos, j, x)
    obs = np.insert(M.astype(float), j, np.nan, axis=1)
    prior = np.array([0.25, 0.5, 0.25]); out = np.zeros((n, 3))
    Ts = [f2_transition(hal(pos[i + 1] - pos[i])) for i in range(len(pos) - 1)]
    for r in range(n):
        e = np.ones((len(pos), 3)); ok = ~np.isnan(obs[r])
        for t in np.where(ok)[0]:
            e[t] = 0; e[t, int(obs[r, t])] = 1
        a = prior * e[0]; A = [a / a.sum()]
        for t in range(1, len(pos)):
            a = (A[-1] @ Ts[t - 1]) * e[t]; A.append(a / a.sum())
        b = np.ones(3); B = [b]
        for t in range(len(pos) - 2, -1, -1):
            b = Ts[t] @ (e[t + 1] * b); b /= b.sum(); B.insert(0, b)
        p = A[j] * B[j]; out[r] = p / p.sum()
    return out


def lod_hk(y, P):
    X = np.column_stack([np.ones(len(y)), P[:, 2] - P[:, 0], P[:, 1]])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None); rss1 = np.sum((y - X @ beta) ** 2); rss0 = np.sum((y - y.mean()) ** 2)
    return len(y) / 2 * np.log10(rss0 / rss1), beta


def main():
    cfg = json.loads((HERE / "data" / "ex07_15_f2.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); M, y, q = simulate(cfg, rng); mpos = cfg["marker_cM"]
    np.savetxt(HERE / "data" / "ex07_15_markers.csv", M, fmt="%d", delimiter=","); np.savetxt(HERE / "data" / "ex07_15_phenotype.csv", y, fmt="%.4f")
    grid = np.arange(0, 100 + 1e-9, cfg["step_cM"]); lods, betas = [], []
    for x in grid:
        l, b = lod_hk(y, genoprob(M, mpos, x)); lods.append(l); betas.append(b)
    lods = np.array(lods); k = int(np.argmax(lods)); peak = grid[k]
    sup = grid[lods >= lods[k] - 1.5]
    single = []
    for j in range(M.shape[1]):
        X = np.column_stack([np.ones(len(y)), M[:, j] - 1, (M[:, j] == 1).astype(float)])
        bb, *_ = np.linalg.lstsq(X, y, rcond=None); rss1 = np.sum((y - X @ bb) ** 2)
        single.append(len(y) / 2 * np.log10(np.sum((y - y.mean()) ** 2) / rss1))
    VQ = cfg["a"] ** 2 / 2 + cfg["d"] ** 2 / 4; h2q = VQ / (VQ + cfg["sigma_e"] ** 2)
    a_hat, d_hat = betas[k][1], betas[k][2]
    print(f"峰位置 {peak:.0f} cM（真值 {cfg['qtl_cM']}），LOD = {lods[k]:.2f}，1.5-LOD 区间 [{sup.min():.0f}, {sup.max():.0f}] cM")
    print(f"â = {a_hat:.3f}（真值 {cfg['a']}），d̂ = {d_hat:.3f}（真值 {cfg['d']}）；理论 QTL 方差比例 = {h2q:.3f}")
    print("单标记 LOD：", np.round(single, 2))
    out = {"peak_cM": float(peak), "lod_peak": float(lods[k]), "support_1.5": [float(sup.min()), float(sup.max())], "a_hat": float(a_hat), "d_hat": float(d_hat),
           "true_prop_var": h2q, "single_marker_lod": [float(v) for v in single], "lod_profile": lods.round(3).tolist()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex07_15_haley_knott.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    plt = get_pyplot()
    if plt:
        fig, ax = plt.subplots(figsize=(6.4, 3.6)); ax.plot(grid, lods, label="Haley–Knott")
        ax.plot(mpos, single, "o", label="单标记"); ax.axvline(cfg["qtl_cM"], ls=":", c="k")
        ax.set_xlabel("位置 (cM)"); ax.set_ylabel("LOD"); ax.legend(); fig.tight_layout()
        fig.savefig(HERE / "results" / "ex07_15_lod_profile.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    main()
