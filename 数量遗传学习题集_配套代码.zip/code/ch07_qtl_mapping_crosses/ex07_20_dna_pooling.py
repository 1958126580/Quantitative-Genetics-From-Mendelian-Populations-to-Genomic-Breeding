#!/usr/bin/env python3
"""习题 7.20  DNA 混池（选择性分型的混池版）：抽样误差与技术误差的功效权衡

高、低两个表型尾部各取 n 只个体的等量 DNA 混合，测定混池的等位基因频率。检验 H0: p_H = p_L。
混池频率估计方差 = 抽样方差 p(1−p)/(2n) + 技术误差方差 σ_t²/k（k 次重复测定）。
    z = (p̂_H − p̂_L) / sqrt(Var_H + Var_L)
技术误差不随 n 减小，因此当 n 很大时混池功效趋于由 σ_t 决定的上限。程序给出解析功效并以模拟核对。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex07_20_pooling.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); pH, pL, k = cfg["freq_high"], cfg["freq_low"], cfg["n_replicate_assays"]
    z = norm.isf(cfg["alpha"] / 2); pbar = (pH + pL) / 2; out = []
    print(f"p_H = {pH}, p_L = {pL}，每池重复测定 {k} 次，α = {cfg['alpha']}")
    print(f"{'n/池':>6s}" + "".join(f"{'σt='+str(s):>16s}" for s in cfg["pool_error_sd"]))
    for n in cfg["n_per_pool"]:
        row = {"n": n}; txt = f"{n:6d}"
        for st in cfg["pool_error_sd"]:
            v = 2 * (pbar * (1 - pbar) / (2 * n) + st ** 2 / k); lam = (pH - pL) / np.sqrt(v)
            pw = norm.sf(z - lam) + norm.cdf(-z - lam)
            xh = rng.binomial(2 * n, pH, cfg["reps"]) / (2 * n) + rng.normal(0, st, (k, cfg["reps"])).mean(0)
            xl = rng.binomial(2 * n, pL, cfg["reps"]) / (2 * n) + rng.normal(0, st, (k, cfg["reps"])).mean(0)
            sim = float(np.mean(np.abs(xh - xl) / np.sqrt(v) > z))
            row[f"sigma_t={st}"] = {"power": float(pw), "sim": sim}; txt += f"{pw:9.3f}({sim:.3f})"
        out.append(row); print(txt)
    lim = (pH - pL) / np.sqrt(2 * 0.04 ** 2 / k)
    print(f"σt = 0.04 时 n→∞ 的极限非中心参数 = {lim:.2f}，极限功效 = {norm.sf(z-lim)+norm.cdf(-z-lim):.3f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex07_20_dna_pooling.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
