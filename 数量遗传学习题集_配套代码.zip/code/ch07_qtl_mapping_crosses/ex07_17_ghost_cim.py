#!/usr/bin/env python3
"""习题 7.17  相斥连锁的两个 QTL：简单区间作图的“抵消/幽灵”与复合区间作图的恢复

回交 400 个体，同一染色体 25 cM 与 65 cM 处两个 QTL，效应 +0.5 与 −0.5（相斥：增效等位基因分处两条亲本染色体）。
    简单区间作图（SIM，Haley–Knott）：两个效应相互抵消，峰值降低、位置偏移，可能在中间出现“幽灵”峰；
    复合区间作图（CIM, Zeng 1994）：在检测位置 x 的回归中加入窗口（±10 cM）之外的标记作为协因子，
吸收另一个 QTL 的效应，恢复两个峰。另以 2-QTL 模型在网格上联合搜索作参照。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent
hal = lambda d: 0.5 * (1 - np.exp(-2 * np.abs(d) / 100))


def bc_prob(M, mpos, x):
    j = np.searchsorted(mpos, x, side="right") - 1
    if j >= len(mpos) - 1 or np.isclose(x, mpos[j]): return M[:, min(j, len(mpos) - 1)].astype(float)
    r1, r2, r = hal(x - mpos[j]), hal(mpos[j + 1] - x), hal(mpos[j + 1] - mpos[j]); L, R = M[:, j], M[:, j + 1]
    return np.select([(L == 1) & (R == 1), (L == 1) & (R == 0), (L == 0) & (R == 1)],
                     [(1 - r1) * (1 - r2) / (1 - r), (1 - r1) * r2 / r, r1 * (1 - r2) / r], r1 * r2 / (1 - r))


def lod(y, X0, X1):
    rss = lambda X: np.sum((y - X @ np.linalg.lstsq(X, y, rcond=None)[0]) ** 2)
    return len(y) / 2 * np.log10(rss(X0) / rss(X1))


def main():
    cfg = json.loads((HERE / "data" / "ex07_17_ghost.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n"]; mpos = np.array(cfg["marker_cM"], float)
    qpos = [q["pos"] for q in cfg["qtl"]]; allpos = np.sort(np.concatenate([mpos, qpos]))
    G = np.zeros((n, len(allpos)), int); G[:, 0] = rng.integers(0, 2, n)
    for j in range(1, len(allpos)): G[:, j] = np.where(rng.random(n) < hal(allpos[j] - allpos[j - 1]), 1 - G[:, j - 1], G[:, j - 1])
    y = rng.normal(0, cfg["sigma_e"], n)
    for q in cfg["qtl"]: y += q["a"] * G[:, list(allpos).index(q["pos"])]
    M = G[:, [list(allpos).index(p) for p in mpos]]
    grid = np.arange(0, 100.0 + 1e-9, cfg["step_cM"]); one = np.ones((n, 1)); sim, cim = [], []
    for x in grid:
        p = bc_prob(M, mpos, x)[:, None]
        sim.append(lod(y, one, np.hstack([one, p])))
        cof = [j for j, mp in enumerate(mpos) if abs(mp - x) > cfg["window_cM"]]
        Xc = np.hstack([one, M[:, cof]]); cim.append(lod(y, Xc, np.hstack([Xc, p])))
    sim, cim = np.array(sim), np.array(cim)
    def peaks(prof):
        idx = [i for i in range(1, len(prof) - 1) if prof[i] >= prof[i - 1] and prof[i] >= prof[i + 1] and prof[i] > 1.5]
        return [(float(grid[i]), float(prof[i])) for i in idx]
    best = (-1, None)
    for i, x1 in enumerate(grid):
        for x2 in grid[i + 10:]:
            X = np.column_stack([one, bc_prob(M, mpos, x1), bc_prob(M, mpos, x2)]); l = lod(y, one, X)
            if l > best[0]: best = (l, (float(x1), float(x2)), np.linalg.lstsq(X, y, rcond=None)[0][1:])
    print(f"真实 QTL：{[(q['pos'], q['a']) for q in cfg['qtl']]}")
    print(f"SIM 局部峰（LOD>1.5）：{[(round(a), round(b,2)) for a, b in peaks(sim)]}；最大 LOD = {sim.max():.2f} @ {grid[sim.argmax()]:.0f} cM")
    print(f"CIM 局部峰（LOD>1.5）：{[(round(a), round(b,2)) for a, b in peaks(cim)]}")
    print(f"2-QTL 联合搜索：位置 {best[1]}，效应 {np.round(best[2],3)}，LOD = {best[0]:.2f}")
    out = {"sim_profile": sim.round(3).tolist(), "cim_profile": cim.round(3).tolist(), "sim_peaks": peaks(sim), "cim_peaks": peaks(cim),
           "two_qtl": {"pos": best[1], "effects": best[2].tolist(), "lod": best[0]}}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex07_17_ghost_cim.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    plt = get_pyplot()
    if plt:
        fig, ax = plt.subplots(figsize=(6.4, 3.6)); ax.plot(grid, sim, label="简单区间作图"); ax.plot(grid, cim, label="复合区间作图")
        for p in qpos: ax.axvline(p, ls=":", c="k")
        ax.set_xlabel("位置 (cM)"); ax.set_ylabel("LOD"); ax.legend(); fig.tight_layout(); fig.savefig(HERE / "results" / "ex07_17_ghost_cim.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    main()
