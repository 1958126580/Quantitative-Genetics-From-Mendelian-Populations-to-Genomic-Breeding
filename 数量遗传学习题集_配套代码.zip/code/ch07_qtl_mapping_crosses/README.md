# 第7章　杂交群体的数量性状位点定位——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex07_15_haley_knott.py
python3 ex07_16_permutation_threshold.py
python3 ex07_17_ghost_cim.py
python3 ex07_18_selective_genotyping.py
python3 ex07_19_beavis_effect.py
python3 ex07_20_dna_pooling.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex07_15_haley_knott.py | 7.15 | F2 群体的 Haley–Knott 回归区间作图与单标记分析比较 |
| ex07_16_permutation_threshold.py | 7.16 | 全基因组扫描的置换阈值（Churchill–Doerge 1994）与 Lander–Botstein 理论近似 |
| ex07_17_ghost_cim.py | 7.17 | 相斥连锁的两个 QTL：简单区间作图的“抵消/幽灵”与复合区间作图的恢复 |
| ex07_18_selective_genotyping.py | 7.18 | 选择性基因分型：功效、偏差与基于全部表型的似然校正 |
| ex07_19_beavis_effect.py | 7.19 | Beavis 效应：低功效时“显著 QTL”的效应被系统性高估 |
| ex07_20_dna_pooling.py | 7.20 | DNA 混池（选择性分型的混池版）：抽样误差与技术误差的功效权衡 |
