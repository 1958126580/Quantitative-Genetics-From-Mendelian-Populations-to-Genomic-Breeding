#!/usr/bin/env python3
"""习题 7.19  Beavis 效应：低功效时“显著 QTL”的效应被系统性高估

单个 QTL 解释真实表型方差比例 R² = 3%（回交、标记即 QTL）。对 n = 100…1600 各模拟 2 万次：
    检验 H0: a = 0（α = 0.001），只保留显著结果，统计其估计 R² 的平均值。
理论：估计效应 β̂ ~ N(β, SE²)，条件于 |β̂/SE| > z，E(β̂ | 显著) 由截断正态给出：
    E = β + SE·[φ(z − λ) − φ(−z − λ)] / [1 − Φ(z − λ) + Φ(−z − λ)]，λ = β/SE。
程序比较模拟与理论，并说明为何高估程度与功效负相关。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex07_19_beavis.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); R2 = cfg["true_r2"]; z = norm.isf(cfg["alpha"] / 2); out = []
    a = 2 * np.sqrt(R2 / (1 - R2))          # BC：两类等频，表型方差中 QTL 部分 a²/4，残差 1
    print(f"真实 R² = {R2}，a = {a:.4f}σe，双侧 α = {cfg['alpha']}（|z| > {z:.3f}）")
    print(f"{'n':>6s}{'功效(模拟)':>11s}{'功效(理论)':>11s}{'显著者R²均值':>13s}{'显著者â/a(模拟)':>16s}{'理论':>8s}")
    for n in cfg["n_values"]:
        se = 2 / np.sqrt(n)                  # Var(â) ≈ σe²(1/(n/2) + 1/(n/2)) = 4/n
        bh = rng.normal(a, se, cfg["reps"]); sig = np.abs(bh / se) > z
        lam = a / se; pw = norm.sf(z - lam) + norm.cdf(-z - lam)
        cond = a + se * (norm.pdf(z - lam) - norm.pdf(-z - lam)) / pw
        r2s = (bh[sig] ** 2 / 4) / (bh[sig] ** 2 / 4 + 1)
        out.append({"n": n, "power_sim": float(sig.mean()), "power_theory": float(pw), "mean_r2_sig": float(r2s.mean()),
                    "ratio_sim": float(bh[sig].mean() / a), "ratio_theory": float(cond / a)})
        print(f"{n:6d}{sig.mean():11.3f}{pw:11.3f}{r2s.mean():13.4f}{bh[sig].mean()/a:16.3f}{cond/a:8.3f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex07_19_beavis_effect.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
