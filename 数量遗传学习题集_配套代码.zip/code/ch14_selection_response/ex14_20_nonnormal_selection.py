#!/usr/bin/env python3
"""习题 14.20  非正态表型下的育种者方程：线性回归假设何时失效

表型 y = a + e，a ~ N(0, V_A) 为育种值；环境偏差 e 为中心化、方差 V_E 的伽玛分布（形状 κ，κ→∞ 趋于正态，
κ 越小偏斜越重）。对前 p 比例截断选择，比较
    真实反应 R_true = E[a | 入选]，
    线性预测   R_lin  = h² S，S = E[y | 入选] − E[y]，
    正态理论   R_norm = i h² σ_P。
同时报告偏度与 E(a | y) 的非线性程度（对 y 分箱的条件均值与线性回归的最大偏离）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats
HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex14_20_nonnormal.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); n, p, h2 = cfg["n"], cfg["p"], cfg["h2"]
    VA, VE = h2, 1 - h2
    a = rng.normal(0, np.sqrt(VA), n)
    x = stats.norm.isf(p); i_norm = stats.norm.pdf(x) / p
    print(f"h² = {h2}，p = {p}，正态理论 i = {i_norm:.3f}")
    print(f"{'κ':>6s}{'偏度(e)':>9s}{'S':>8s}{'R真实':>8s}{'h²S':>8s}{'R正态':>8s}{'真实/h²S':>10s}{'最大非线性偏离':>14s}")
    rows = []
    for kappa in cfg["shapes"]:
        e = (rng.gamma(kappa, 1.0, n) - kappa) / np.sqrt(kappa) * np.sqrt(VE)       # 中心化、方差 VE
        y = a + e; sd = y.std()
        sel = y >= np.quantile(y, 1 - p)
        S = y[sel].mean() - y.mean(); Rt = a[sel].mean() - a.mean(); Rl = h2 * S; Rn = i_norm * h2 * sd
        # 非线性：y 分 20 个分位箱，E[a|y] 与线性回归线的差
        edges = np.quantile(y, np.linspace(0, 1, 21)); idx = np.clip(np.searchsorted(edges, y, side="right") - 1, 0, 19)
        cm = np.array([a[idx == b].mean() for b in range(20)]); ym = np.array([y[idx == b].mean() for b in range(20)])
        lin = h2 * (ym - y.mean()); dev = np.abs(cm - lin).max() / np.sqrt(VA)
        sk = 2 / np.sqrt(kappa)
        rows.append(dict(kappa=kappa, skew=sk, S=S, R_true=Rt, R_lin=Rl, R_norm=Rn, dev=dev))
        print(f"{kappa:6d}{sk:9.2f}{S:8.3f}{Rt:8.3f}{Rl:8.3f}{Rn:8.3f}{Rt / Rl:10.3f}{dev:14.3f}")
        if kappa >= 1000: assert abs(Rt - Rl) < 0.02
    print("\n解读：右偏的环境分布使右尾入选的个体更多来自极端环境偏差，育种值的回归斜率在右尾变平，真实反应小于 h²S。")
    (HERE / "results" / "ex14_20_nonnormal.json").write_text(json.dumps(rows, indent=1, default=float))


if __name__ == "__main__":
    main()
