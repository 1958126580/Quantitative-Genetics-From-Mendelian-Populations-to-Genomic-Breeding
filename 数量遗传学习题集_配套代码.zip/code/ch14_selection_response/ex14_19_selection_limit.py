#!/usr/bin/env python3
"""习题 14.19  有限群体的选择极限：与 Robertson 2·N_e·R₁ 的对照

L 个加性等效应双等位基因座（初始频率 p0）与 L' 个中性座，群体 N 个个体，每代按表型截断选留 n_sel 个，
随机交配（不含自交）产生 N 个后代。随机交配中性座的杂合度衰减 H_t = H_0(1 − 1/(2N_e))^t 用来估计 N_e。
模拟 reps 个重复，记录平均累积反应、有利等位基因固定比例；比较
    R_∞(模拟) 与 2 N_e R₁（Robertson 1960，R₁ 为第一代反应），并观察反应半衰期。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    R, N, L, Ln, T, n = cfg["reps"], cfg["N"], cfg["L_qtl"], cfg["L_neutral"], cfg["generations"], cfg["n_sel"]
    p0 = cfg["p0"]
    # 个体双单倍型：形状 (R, N, L+Ln, 2)
    G = (rng.random((R, N, L + Ln, 2)) < p0).astype(np.int8)
    var_g0 = 2 * p0 * (1 - p0) * L                     # 每座效应 a=1 时的初始加性方差
    a = np.sqrt(cfg["h2_init"] / (1 - cfg["h2_init"]) * cfg["VE"] / var_g0)   # 使初始 h² = h2_init
    ar = np.arange(R)[:, None]
    mean_g = np.zeros((R, T + 1)); fixed = np.zeros((R, T + 1)); Hn = np.zeros((R, T + 1)); VA = np.zeros((R, T + 1))
    for t in range(T + 1):
        g = a * G[:, :, :L, :].sum(axis=(2, 3))                       # (R, N)
        y = g + rng.normal(0, np.sqrt(cfg["VE"]), (R, N))
        mean_g[:, t] = g.mean(1); VA[:, t] = g.var(1)
        fq = G[:, :, :L, :].mean(axis=(1, 3)); fixed[:, t] = (fq == 1).mean(1)
        fn = G[:, :, L:, :].mean(axis=(1, 3)); Hn[:, t] = (2 * fn * (1 - fn)).mean(1)
        if t == T: break
        sel = np.argsort(-y, axis=1)[:, :n]                            # (R, n)
        # 随机配对（无自交）
        pa = rng.integers(0, n, (R, N)); pb = (pa + rng.integers(1, n, (R, N))) % n
        ia, ib = sel[ar, pa], sel[ar, pb]
        hap_a = rng.integers(0, 2, (R, N, L + Ln)); hap_b = rng.integers(0, 2, (R, N, L + Ln))
        # 无连锁：各座独立取配子
        ga = np.take_along_axis(G[ar, ia], hap_a[..., None], axis=3)[..., 0]
        gb = np.take_along_axis(G[ar, ib], hap_b[..., None], axis=3)[..., 0]
        G = np.stack([ga, gb], axis=3)
    return mean_g, fixed, Hn, VA, a


def main():
    cfg = json.loads((HERE / "data" / "ex14_19_limit.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); T = cfg["generations"]
    mg, fx, Hn, VA, a = simulate(cfg, rng)
    resp = mg.mean(0) - mg[:, 0].mean()
    H = Hn.mean(0); t = np.arange(T + 1)
    slope = np.polyfit(t[: min(30, T)], np.log(H[: min(30, T)]), 1)[0]    # ln H_t = ln H_0 + t ln(1−1/2Ne)
    Ne = 1 / (2 * (1 - np.exp(slope)))
    R1 = resp[1]; lim_rob = 2 * Ne * R1
    plateau = resp[-10:].mean()
    full = a * 2 * cfg["L_qtl"] * (1 - cfg["p0"])         # 全部有利等位基因固定时的总反应
    half_gen = int(np.argmax(resp >= 0.5 * plateau))
    print(f"N = {cfg['N']}，留种 {cfg['n_sel']}，{cfg['reps']} 个重复，初始 V_A = {VA[:, 0].mean():.3f}，初始 h² = {VA[:, 0].mean() / (VA[:, 0].mean() + cfg['VE']):.3f}")
    print(f"中性座杂合度衰减估计 N_e = {Ne:.2f}（理想群体按留种数 n = {cfg['n_sel']}）")
    print(f"第一代反应 R₁ = {R1:.3f}；Robertson 极限 2N_eR₁ = {lim_rob:.3f}；")
    print(f"模拟末期平台（最后10代均值）= {plateau:.3f}；理论上限（全部有利等位基因固定）= {full:.3f}")
    print(f"平台/Robertson 极限 = {plateau / lim_rob:.2f}；平台/上限 = {plateau / full:.2f}；半衰期 ≈ {half_gen} 代")
    print("世代  累积反应  V_A  有利等位基因固定比例  中性杂合度")
    for g in (0, 1, 2, 5, 10, 20, 30, 40, 50):
        if g <= T:
            print(f"{g:4d}{resp[g]:10.3f}{VA[:, g].mean():8.3f}{fx[:, g].mean():14.3f}{H[g]:12.3f}")
    assert 0.3 * cfg["n_sel"] < Ne < 1.6 * cfg["n_sel"] and 0.4 < plateau / lim_rob < 1.6
    (HERE / "results" / "ex14_19_limit.json").write_text(json.dumps(dict(Ne=Ne, R1=R1, robertson=lim_rob, plateau=plateau, upper=full, half=half_gen, resp=resp.tolist(), VA=VA.mean(0).tolist()), indent=1))


if __name__ == "__main__":
    main()
