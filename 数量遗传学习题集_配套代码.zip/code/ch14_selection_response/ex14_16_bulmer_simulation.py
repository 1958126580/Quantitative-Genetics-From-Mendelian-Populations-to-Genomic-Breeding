#!/usr/bin/env python3
"""习题 14.16  Bulmer 效应：个体水平的有限位点无限模型模拟与递推公式对照

模型：育种值 a = (a_父 + a_母)/2 + 孟德尔抽样（方差 V0/2），表型 y = a + e。
截断选择使被选个体育种值方差缩至 V_A(1 − k h²)，连锁不平衡项 d_t 递推
    d_{t+1} = d_t/2 − (1/2) k h_t² V_{A,t},   V_{A,t} = V0 + d_t,   h_t² = V_{A,t}/(V_{A,t}+V_E)。
每代以大群体（N 个后代）直接模拟，核对 V_A、h² 与反应 R_t = h_t² S_t，并求渐近值。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats
HERE = Path(__file__).resolve().parent


def recursion(V0, VE, p, T):
    x = stats.norm.isf(p); i = stats.norm.pdf(x) / p; k = i * (i - x)
    d, out = 0.0, []
    for t in range(T + 1):
        VA = V0 + d; h2 = VA / (VA + VE)
        out.append((t, VA, h2, i * h2 * np.sqrt(VA + VE)))
        d = d / 2 - 0.5 * k * h2 * VA
    return out, k


def simulate(V0, VE, p, T, N, rng):
    a = rng.normal(0, np.sqrt(V0), N); res = []
    for t in range(T + 1):
        y = a + rng.normal(0, np.sqrt(VE), N)
        sel = np.argsort(y)[-int(round(p * N)):]
        res.append((t, a.var(), a.var() / y.var(), a[sel].mean() - a.mean()))
        pa = rng.choice(sel, N); pb = rng.choice(sel, N)
        a = 0.5 * (a[pa] + a[pb]) + rng.normal(0, np.sqrt(V0 / 2), N)
    return res


def main():
    cfg = json.loads((HERE / "data" / "ex14_16_bulmer.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); V0, VE, T = cfg["VA0"], cfg["VE"], cfg["generations"]
    allres = {}
    for p in cfg["proportions"]:
        rec, k = recursion(V0, VE, p, T); sim = simulate(V0, VE, p, T, cfg["N"], rng)
        print(f"\n入选比例 p = {p}（k = {k:.3f}）   V0 = {V0}, V_E = {VE}")
        print(f"{'t':>3s}{'V_A 递推':>10s}{'V_A 模拟':>10s}{'h² 递推':>9s}{'h² 模拟':>9s}{'R 递推':>9s}{'R 模拟':>9s}")
        for (t, va, h2, r), (_, vs, hs, rs) in zip(rec, sim):
            print(f"{t:3d}{va:10.2f}{vs:10.2f}{h2:9.3f}{hs:9.3f}{r:9.3f}{rs:9.3f}")
            assert abs(va - vs) < 0.6 and abs(r - rs) < 0.12
        d_inf = None
        # 渐近：解 d = d/2 − ½ k h² (V0 + d) 的不动点
        from scipy.optimize import brentq
        f = lambda d: d / 2 - 0.5 * k * ((V0 + d) / (V0 + d + VE)) * (V0 + d) - d
        d_inf = brentq(f, -V0 * 0.99, 0.0)
        print(f"渐近 V_A = {V0 + d_inf:.3f}（相对 V0 缩减 {100 * -d_inf / V0:.1f}%），渐近 h² = {(V0 + d_inf) / (V0 + d_inf + VE):.3f}")
        allres[str(p)] = dict(k=k, rec=rec, sim=sim, VA_inf=V0 + d_inf)
    plt = None
    try:
        from _plot import get_pyplot; plt = get_pyplot()
    except Exception:
        pass
    if plt:
        fig, ax = plt.subplots(figsize=(6, 4))
        for p, r in allres.items():
            ax.plot([x[0] for x in r["rec"]], [x[1] for x in r["rec"]], label=f"p={p}")
            ax.plot([x[0] for x in r["sim"]], [x[1] for x in r["sim"]], "k.", ms=3)
        ax.set_xlabel("世代"); ax.set_ylabel("加性方差 V_A"); ax.legend(); fig.tight_layout()
        fig.savefig(HERE / "results" / "ex14_16_bulmer.png", dpi=150)
    (HERE / "results" / "ex14_16_bulmer.json").write_text(json.dumps(allres, indent=1, default=float))


if __name__ == "__main__":
    main()
