# 第14章　选择反应的数量遗传理论——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex14_15_truncation_intensity.py
python3 ex14_16_bulmer_simulation.py
python3 ex14_17_correlated_response.py
python3 ex14_18_realized_heritability.py
python3 ex14_19_selection_limit.py
python3 ex14_20_nonnormal_selection.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex14_15_truncation_intensity.py | 14.15 | 截断选择的强度、方差缩减与有限群体校正 |
| ex14_16_bulmer_simulation.py | 14.16 | Bulmer 效应：个体水平的有限位点无限模型模拟与递推公式对照 |
| ex14_17_correlated_response.py | 14.17 | 相关选择反应：间接选择何时优于直接选择 |
| ex14_18_realized_heritability.py | 14.18 | 双向选择试验与实现遗传力 |
| ex14_19_selection_limit.py | 14.19 | 有限群体的选择极限：与 Robertson 2·N_e·R₁ 的对照 |
| ex14_20_nonnormal_selection.py | 14.20 | 非正态表型下的育种者方程：线性回归假设何时失效 |
