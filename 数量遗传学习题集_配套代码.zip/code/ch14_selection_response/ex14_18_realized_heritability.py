#!/usr/bin/env python3
"""习题 14.18  双向选择试验与实现遗传力

无限位点模型 + 有限群体：个体育种值 a = (a_父 + a_母)/2 + m，m ~ N(0, V0(1 − (F_父+F_母)/2)/2)，
近交系数 F 由完整系谱以表格法递推。每个选择方向（高、低）有若干重复系，每代 cand_per_sex 雌雄候选，
分性别按表型截断。实现遗传力 h²_R = 累积反应 / 累积选择差（过原点回归，高低系差值）。
抽样方差来自漂变（重复系间）；用重复系间的离散给出 SE，并以大量独立试验核对 SE 的合理性与偏倚。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


class Line:
    def __init__(self, V0, VE, ns, nf, nm_sel, nf_sel, direction, rng):
        self.V0, self.VE, self.ns, self.nf = V0, VE, ns, nf
        self.sm, self.sf, self.dir, self.rng = nm_sel, nf_sel, direction, rng
        n = ns + nf
        self.A = np.eye(n)                     # 基础群体：无亲缘、非近交
        self.a = rng.normal(0, np.sqrt(V0), n)
        self.sex = np.array([0] * ns + [1] * nf)
        self.hist = []

    def step(self):
        rng = self.rng; y = self.a + rng.normal(0, np.sqrt(self.VE), len(self.a))
        # 只在最新一代内选择
        last = np.arange(len(self.a) - (self.ns + self.nf), len(self.a)); ylast = y[last] * self.dir
        males = last[self.sex[last] == 0]; females = last[self.sex[last] == 1]
        sm = males[np.argsort(ylast[self.sex[last] == 0])[-self.sm:]]
        sf = females[np.argsort(ylast[self.sex[last] == 1])[-self.sf:]]
        S = (y[np.r_[sm, sf]].mean() - y[last].mean()) * self.dir   # 两性平均选择差（按选择方向取正）
        self.hist.append((self.a[last].mean(), S))
        n_old = len(self.a); n_new = self.ns + self.nf
        sires = rng.choice(sm, n_new); dams = rng.choice(sf, n_new)
        # 扩展 A
        Anew = np.zeros((n_old + n_new, n_old + n_new)); Anew[:n_old, :n_old] = self.A
        for j in range(n_new):
            row = 0.5 * (self.A[sires[j]] + self.A[dams[j]])
            Anew[n_old + j, :n_old] = row; Anew[:n_old, n_old + j] = row
        F = 0.5 * self.A[sires, dams]
        for j in range(n_new):
            Anew[n_old + j, n_old + j] = 1 + F[j]
        # 同代个体间的亲缘：a_j 与 a_l 的亲本之间的平均亲缘
        for j in range(n_new):
            for l in range(j):
                v = 0.25 * (self.A[sires[j], sires[l]] + self.A[sires[j], dams[l]] + self.A[dams[j], sires[l]] + self.A[dams[j], dams[l]])
                Anew[n_old + j, n_old + l] = Anew[n_old + l, n_old + j] = v
        self.A = Anew
        mvar = self.V0 * (1 - 0.5 * ((self.A[sires, sires] - 1) + (self.A[dams, dams] - 1))) / 2
        newa = 0.5 * (self.a[sires] + self.a[dams]) + rng.normal(0, 1, n_new) * np.sqrt(mvar)
        self.a = np.r_[self.a, newa]
        self.sex = np.r_[self.sex, np.array([0] * self.ns + [1] * self.nf)]

    def run(self, T):
        for _ in range(T): self.step()
        last = np.arange(len(self.a) - (self.ns + self.nf), len(self.a)); self.hist.append((self.a[last].mean(), 0.0))
        m0 = self.hist[0][0]
        resp = np.array([h[0] - m0 for h in self.hist[1:]]) * self.dir
        sd = np.array([h[1] for h in self.hist[:-1]])
        return np.cumsum(sd), resp                    # 累积选择差，累积反应（均已按方向取正）


def experiment(cfg, rng, reps):
    V0 = cfg["h2"] * cfg["VP"]; VE = cfg["VP"] - V0; T = cfg["generations"]
    CS, CR = [], []
    for d in (+1, -1):
        for _ in range(reps):
            ln = Line(V0, VE, cfg["cand_per_sex"], cfg["cand_per_sex"], cfg["sel_males"], cfg["sel_females"], d, rng)
            cs, cr = ln.run(T); CS.append(cs); CR.append(cr)
    return np.array(CS), np.array(CR)


def h2_real(CS, CR):
    """各系过原点回归后合并；返回合并估计与各系估计。"""
    per = (CS * CR).sum(1) / (CS * CS).sum(1)
    return (CS * CR).sum() / (CS * CS).sum(), per


def main():
    cfg = json.loads((HERE / "data" / "ex14_18_realized_h2.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); R = cfg["replicates"]
    CS, CR = experiment(cfg, rng, R)
    est, per = h2_real(CS, CR)
    se = per.std(ddof=1) / np.sqrt(len(per))
    print(f"真 h² = {cfg['h2']}，选择 {2 * R} 个系（高低各 {R} 重复），{cfg['generations']} 代")
    print("各系的实现遗传力：", np.round(per, 3))
    print(f"合并实现遗传力 = {est:.3f}，重复系间 SE = {se:.3f}")
    print(f"\n每代累积选择差与累积反应（高系平均）：")
    for t in range(cfg["generations"]):
        print(f"  t={t + 1:2d}  ΣS={CS[:R, t].mean():7.3f}  ΣR={CR[:R, t].mean():7.3f}  低系 ΣR={CR[R:, t].mean():7.3f}")
    # 多次独立试验：估计量的均值、SD、SE 的覆盖
    ests, ses = [], []
    for _ in range(cfg["mc_experiments"]):
        cs, cr = experiment(cfg, rng, R); e, p = h2_real(cs, cr); ests.append(e); ses.append(p.std(ddof=1) / np.sqrt(len(p)))
    ests, ses = np.array(ests), np.array(ses)
    cover = np.mean(np.abs(ests - cfg["h2"]) < 1.96 * ses)
    print(f"\n{cfg['mc_experiments']} 次独立试验：均值 {ests.mean():.3f}，实际 SD {ests.std(ddof=1):.3f}，平均报告 SE {ses.mean():.3f}，名义 95% 区间覆盖 {cover:.2f}")
    assert abs(ests.mean() - cfg["h2"]) < 0.06
    (HERE / "results" / "ex14_18_realized_h2.json").write_text(json.dumps(dict(est=est, se=se, per_line=per.tolist(), mc_mean=ests.mean(), mc_sd=ests.std(ddof=1), mc_se=ses.mean(), cover=cover), indent=1))


if __name__ == "__main__":
    main()
