#!/usr/bin/env python3
"""习题 14.17  相关选择反应：间接选择何时优于直接选择

对性状 Y 的直接选择反应 R_Y = i·r_{A_Y,I_Y}·σ_{A_Y}；经 X 间接选择 CR_Y = i·r_{A_X,I_X}·r_A·σ_{A_Y}。
准确度 r_{A,I} = Cov(A,I)/(σ_A σ_I)，由协方差直接计算：自身记录 Cov = V_A；
半同胞均值：Cov(A,Ī) = V_A/4，Var Ī = V_P[(1+(n−1)t)/n]，t = h²/4；全同胞均值：Cov = V_A/2，t = h²/2（忽略共同环境）。
蒙特卡洛：用双变量正态育种值与独立环境，实际截断选择，核对解析比值。
"""
from __future__ import annotations
import json
import re
from pathlib import Path
import numpy as np
from scipy import stats
HERE = Path(__file__).resolve().parent


def family_stats(h2: float, info: str):
    """返回 (Cov(A, I), Var(I))，以 σ_A² = 1 为单位。"""
    if info == "own":
        return 1.0, 1.0 / h2
    m = re.fullmatch(r"(halfsib|fullsib)(\d+)", info)
    f = 0.25 if m.group(1) == "halfsib" else 0.5; k = int(m.group(2)); t = h2 * f
    return f, (1 + (k - 1) * t) / k / h2


def accuracy(h2: float, info: str) -> float:
    cov, var = family_stats(h2, info)
    return cov / np.sqrt(var)


def mc_check(c, n, rng):
    """模拟育种值（σ_A = 1）与两个性状的信息源，返回 (I_X, I_Y, A_Y)。"""
    r = c["rA"]
    ax = rng.standard_normal(n); ay = r * ax + np.sqrt(1 - r ** 2) * rng.standard_normal(n)
    def info(a, h2, kind):
        cov, var = family_stats(h2, kind)
        return cov * a + np.sqrt(var - cov ** 2) * rng.standard_normal(n)
    return info(ax, c["hx2"], c["info_x"]), info(ay, c["hy2"], c["info_y"]), ay


def main():
    cfg = json.loads((HERE / "data" / "ex14_17_correlated.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); i = cfg["i"]
    print(f"i = {i}（p ≈ 0.10）")
    print(f"{'情形':<14s}{'r_X':>7s}{'r_Y':>7s}{'直接 R_Y':>10s}{'间接 CR_Y':>11s}{'比值':>7s}{'MC 比值':>9s}")
    out = []
    for c in cfg["cases"]:
        rx, ry = accuracy(c["hx2"], c["info_x"]), accuracy(c["hy2"], c["info_y"])
        R, CR = i * ry, i * rx * c["rA"]
        Ix, Iy, ay = mc_check(c, cfg["n_mc"], rng)
        thr = lambda I: I >= np.quantile(I, 0.9)
        Rmc, CRmc = ay[thr(Iy)].mean(), ay[thr(Ix)].mean()
        out.append(dict(case=c["name"], rx=rx, ry=ry, R=R, CR=CR, ratio=CR / R, mc=CRmc / Rmc))
        print(f"{c['name']:<14s}{rx:7.3f}{ry:7.3f}{R:10.3f}{CR:11.3f}{CR / R:7.2f}{CRmc / Rmc:9.2f}")
        assert abs(Rmc - R) < 0.03 and abs(CRmc - CR) < 0.03
    (HERE / "results" / "ex14_17_correlated.json").write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float))


if __name__ == "__main__":
    main()
