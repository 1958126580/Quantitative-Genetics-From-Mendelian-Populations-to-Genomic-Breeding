#!/usr/bin/env python3
"""习题 14.15  截断选择的强度、方差缩减与有限群体校正

标准正态截断：入选比例 p，阈值 x = Φ⁻¹(1−p)，强度 i = φ(x)/p，
被选个体方差 1 − k，k = i(i − x)。有限群体中从 N 头选 n 头的平均强度用
Burrows 近似 i_{n,N} ≈ i_p − (1−p)/(2p(N+1)·i_p)，p = n/N，并以顺序统计量期望的精确数值积分核对。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import integrate, stats
HERE = Path(__file__).resolve().parent


def intensity(p: float):
    x = stats.norm.isf(p)
    i = stats.norm.pdf(x) / p
    return x, i, i * (i - x)


def exact_finite(N: int, n: int) -> float:
    """从 N 个标准正态样本中取最大的 n 个，其平均值的精确期望（顺序统计量积分）。"""
    tot = 0.0
    for r in range(N - n + 1, N + 1):          # 第 r 小的顺序统计量
        logc = (np.log(np.arange(1, N + 1)).sum()
                - np.log(np.arange(1, r)).sum() - np.log(np.arange(1, N - r + 1)).sum())
        f = lambda z: z * np.exp(logc + (r - 1) * stats.norm.logcdf(z) + (N - r) * stats.norm.logsf(z)
                                   + stats.norm.logpdf(z))
        tot += integrate.quad(f, -8, 8, limit=200)[0]
    return tot / n


def main():
    cfg = json.loads((HERE / "data" / "ex14_15_truncation.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); z = rng.standard_normal(cfg["n_mc"])
    rows = []
    print(f"{'p':>6s}{'x':>8s}{'i':>8s}{'k':>8s}{'MC i':>8s}{'MC 方差':>9s}{'1-k':>8s}")
    for p in cfg["proportions"]:
        x, i, k = intensity(p); sel = z[z > x]
        mi, mv = sel.mean(), sel.var()
        assert abs(mi - i) < 0.02 and abs(mv - (1 - k)) < 0.02
        rows.append(dict(p=p, x=x, i=i, k=k, mc_i=mi, mc_var=mv))
        print(f"{p:6.2f}{x:8.3f}{i:8.3f}{k:8.3f}{mi:8.3f}{mv:9.3f}{1-k:8.3f}")
    print("\n有限群体：从 N 选 n")
    fin = []
    print(f"{'N':>5s}{'n':>5s}{'无限 i':>9s}{'Burrows':>9s}{'精确':>9s}{'相对误差%':>10s}")
    for N, n in cfg["finite"]:
        p = n / N; _, i, _ = intensity(p)
        b = i - (1 - p) / (2 * p * (N + 1) * i); e = exact_finite(N, n)
        assert abs(b - e) < 0.05
        fin.append(dict(N=N, n=n, i_inf=i, burrows=b, exact=e))
        print(f"{N:5d}{n:5d}{i:9.3f}{b:9.3f}{e:9.3f}{100*(b-e)/e:10.2f}")
    (HERE / "results" / "ex14_15_truncation.json").write_text(json.dumps(dict(infinite=rows, finite=fin), indent=1))


if __name__ == "__main__":
    main()
