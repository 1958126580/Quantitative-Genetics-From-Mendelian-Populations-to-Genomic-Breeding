#!/usr/bin/env python3
"""习题 29.17  校准斜率、选择后的条件解释与范围限制

对同一批测试动物（候选，n_test）用 GBLUP 预测。收缩强度 λ 取"过强/正确/不足"三种：
  - 校准斜率 b = cov(g, ĝ)/var(ĝ)（真实育种值对预测值回归；<1 表示过度分散，>1 表示过度收缩）；
  - 用训练集内部交叉验证估计 b̂ 并作"事后校准" ĝ* = b̂ ĝ，比较校准前后的 MSE(ĝ, g)；
  - 选择后：取预测值前 f 的动物，比较 mean(ĝ)（预测的选择差）与 mean(g)（真实选择差），
    及选择子集内的相关与 Thorndike 范围限制修正 r' = r_s·u / √(1 − r_s² + r_s² u²)（u = σ_全/σ_选择，反推全群相关）。
断言：正确 λ 下斜率≈1，且选择差的预测值与真实值之比≈1/b 的相反方向（过度分散时预测选择差偏大）；
事后校准降低 MSE；选择子集内相关随 f 减小而下降，Thorndike 修正后接近全群相关。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(rng, cfg):
    n = cfg["n_train"] + cfg["n_test"]; m = cfg["m"]; h2 = cfg["h2"]
    p = rng.uniform(0.1, 0.5, m)
    Z = (rng.binomial(2, p, (n, m)) - 2 * p) / np.sqrt(2 * p * (1 - p))
    b = np.zeros(m); b[rng.choice(m, cfg["n_qtl"], replace=False)] = rng.normal(0, 1, cfg["n_qtl"])
    g = Z @ b; g = (g - g.mean()) / g.std() * np.sqrt(h2)
    y = g + rng.normal(0, np.sqrt(1 - h2), n)
    return Z, g, y


def ridge_beta(Z, y, lam):
    """ridge 的 SNP 效应（对偶形式，n<m 时更快）：β̂ = Zᵀ(ZZᵀ+mλI)⁻¹(y−ȳ)。"""
    m = Z.shape[1]
    a = np.linalg.solve(Z @ Z.T + m * lam * np.eye(len(y)), y - y.mean())
    return Z.T @ a


def cv_slope(Z, y, lam, K=5, rng=None):
    """训练集内部 K 折：留出折预测 ĝ，对其表型回归求斜率（表型对预测的回归斜率=校准斜率的可观测版本）。"""
    n = len(y); idx = rng.permutation(n); pred = np.zeros(n)
    for te in np.array_split(idx, K):
        tr = np.setdiff1d(np.arange(n), te)
        pred[te] = Z[te] @ ridge_beta(Z[tr], y[tr], lam)
    return np.cov(y, pred)[0, 1] / pred.var(ddof=1)


def main():
    cfg = json.loads((HERE / "data" / "ex29_17_config.json").read_text(encoding="utf-8"))
    h2 = cfg["h2"]; lam0 = (1 - h2) / h2
    res = {}
    for fac in cfg["lambda_factors"]:
        rows = []
        for r in range(cfg["reps"]):
            rng = np.random.default_rng(cfg["seed"] + r)
            Z, g, y = simulate(rng, cfg)
            ntr = cfg["n_train"]
            beta = ridge_beta(Z[:ntr], y[:ntr], lam0 * fac)
            gh = Z[ntr:] @ beta; gt = g[ntr:]
            b_true = np.cov(gt, gh)[0, 1] / gh.var(ddof=1)
            b_cv = cv_slope(Z[:ntr], y[:ntr], lam0 * fac, rng=rng)       # 表型对预测的斜率（期望=b_true）
            mse0 = np.mean((gh - gh.mean() - (gt - gt.mean())) ** 2)
            gstar = gh.mean() + b_cv * (gh - gh.mean())
            mse1 = np.mean((gstar - gstar.mean() - (gt - gt.mean())) ** 2)
            r_all = np.corrcoef(gh, gt)[0, 1]
            row = dict(b_true=b_true, b_cv=b_cv, mse0=mse0, mse1=mse1, r_all=r_all)
            order = np.argsort(-gh)
            for f in cfg["top_fractions"]:
                k = int(f * len(gh)); s = order[:k]
                row[f"sel_pred_{f}"] = gh[s].mean() - gh.mean()
                row[f"sel_true_{f}"] = gt[s].mean() - gt.mean()
                rs = np.corrcoef(gh[s], gt[s])[0, 1] if k > 20 else np.nan
                u = gh.std() / gh[s].std()
                row[f"r_sel_{f}"] = rs
                row[f"r_thorn_{f}"] = rs * u / np.sqrt(1 - rs ** 2 + rs ** 2 * u ** 2)
            rows.append(row)
        res[str(fac)] = {k: float(np.nanmean([x[k] for x in rows])) for k in rows[0]}
    print(f"h²={h2}，训练 {cfg['n_train']}，候选 {cfg['n_test']}，重复 {cfg['reps']}")
    print(f"{'λ倍数':>6}{'真实斜率':>10}{'CV斜率':>9}{'MSE前':>9}{'MSE后':>9}{'全群r':>8}")
    for fac, d in res.items():
        print(f"{float(fac):>6.2f}{d['b_true']:>10.3f}{d['b_cv']:>9.3f}{d['mse0']:>9.4f}{d['mse1']:>9.4f}{d['r_all']:>8.3f}")
    print("\n选择后（前 f 比例）的选择差（单位：遗传标准差 σ_g=%.3f 的原尺度）" % np.sqrt(h2))
    for fac, d in res.items():
        print(f"λ×{float(fac):.2f}: " + "；".join(
            f"f={f}: 预测{d[f'sel_pred_{f}']:.3f}/真实{d[f'sel_true_{f}']:.3f}" for f in cfg["top_fractions"][1:]))
    print("\n选择子集内相关（原始 → Thorndike 修正），λ 正确：")
    d = res["1.0"]
    for f in cfg["top_fractions"][1:]:
        print(f"  f={f}: r_sel={d[f'r_sel_{f}']:.3f} → {d[f'r_thorn_{f}']:.3f}（全群 {d['r_all']:.3f}）")
    ok = res["1.0"]
    assert abs(ok["b_true"] - 1) < 0.12 and abs(ok["b_cv"] - ok["b_true"]) < 0.15
    assert res["0.2"]["b_true"] < 0.8 < 1.1 < res["4.0"]["b_true"]
    assert res["0.2"]["mse1"] < res["0.2"]["mse0"] and res["4.0"]["mse1"] < res["4.0"]["mse0"]
    # 选择差：过度分散（λ 小）时预测选择差大于真实选择差；正确 λ 时二者接近
    f0 = cfg["top_fractions"][3]
    assert res["0.2"][f"sel_pred_{f0}"] > res["0.2"][f"sel_true_{f0}"] * 1.2
    assert abs(ok[f"sel_pred_{f0}"] / ok[f"sel_true_{f0}"] - 1) < 0.15
    rs = [ok[f"r_sel_{f}"] for f in cfg["top_fractions"][1:]]
    assert all(rs[i] > rs[i + 1] for i in range(len(rs) - 1))
    for f in cfg["top_fractions"][1:]:
        assert abs(ok[f"r_thorn_{f}"] - ok["r_all"]) < 0.08
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex29_17_calibration_selection.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
