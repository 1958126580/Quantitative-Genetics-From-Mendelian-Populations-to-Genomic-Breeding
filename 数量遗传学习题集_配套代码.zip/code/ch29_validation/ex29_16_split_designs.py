#!/usr/bin/env python3
"""习题 29.16  随机、整家系、时间划分与信息泄漏：同一个模型，四个"准确性"

群体：n_sires 头父亲 × dams_per_sire 头母亲 × kids_per_dam 个后代（半同胞/全同胞家系），
父母代为上一世代；基因型按孟德尔分离（各位点自由重组）下传，GBLUP（ridge）预测。
四种评价：
  (1) 随机 K 折（同家系动物分在训练与测试两侧，亲缘近）；
  (2) 整父系家系留出 K 折（测试家系的全同胞/半同胞全部不在训练集）；
  (3) 时间划分：父母代训练 → 后代测试（真实"向前预测"）；
  (4) 泄漏：在划分之前用全部数据按边际相关筛 SNP（含测试动物表型），再做随机 K 折。
报告 cor(ĝ,y)/h 与对真实育种值的相关 cor(ĝ,g)；断言：随机 > 家系留出，且泄漏使表观准确性虚高。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def build_population(rng, cfg):
    m, h2 = cfg["m"], cfg["h2"]
    ns, dps, kpd = cfg["n_sires"], cfg["dams_per_sire"], cfg["kids_per_dam"]
    p = rng.uniform(0.15, 0.5, m)
    nd = ns * dps
    hs = rng.random((ns, 2, m)) < p; hd = rng.random((nd, 2, m)) < p
    par = np.concatenate([hs.sum(1), hd.sum(1)]).astype(float)           # 父母代基因型
    kids, fam = [], []
    for s in range(ns):
        for j in range(dps):
            d = s * dps + j
            for _ in range(kpd):
                gs = np.where(rng.random(m) < .5, hs[s, 0], hs[s, 1])
                gd = np.where(rng.random(m) < .5, hd[d, 0], hd[d, 1])
                kids.append(gs.astype(float) + gd); fam.append(s)
    X = np.vstack([par, np.array(kids)]); fam = np.concatenate([-np.ones(ns + nd, int), fam])
    Z = (X - 2 * p) / np.sqrt(2 * p * (1 - p))
    q = rng.choice(m, cfg["n_qtl"], replace=False)
    b = np.zeros(m); b[q] = rng.normal(0, 1, cfg["n_qtl"])
    g = Z @ b; g = (g - g.mean()) / g.std() * np.sqrt(h2)
    y = g + rng.normal(0, np.sqrt(1 - h2), len(g))
    return Z, g, y, fam, ns + nd


def ridge_pred(Ztr, ytr, Zte, lam):
    mu = ytr.mean()
    A = Ztr @ Ztr.T / Ztr.shape[1]
    a = np.linalg.solve(A + lam * np.eye(len(ytr)), ytr - mu)
    return mu + Zte @ Ztr.T @ a / Ztr.shape[1]


def cv(Z, y, g, folds, lam, h):
    pred = np.zeros(len(y)); gh = np.zeros(len(y))
    for te in folds:
        tr = np.setdiff1d(np.arange(len(y)), te)
        pred[te] = ridge_pred(Z[tr], y[tr], Z[te], lam)
    return np.corrcoef(pred, y)[0, 1] / h, np.corrcoef(pred, g)[0, 1]


def main():
    cfg = json.loads((HERE / "data" / "ex29_16_config.json").read_text(encoding="utf-8"))
    h = np.sqrt(cfg["h2"]); lam = (1 - cfg["h2"]) / cfg["h2"]
    rng = np.random.default_rng(cfg["seed"]); K = cfg["n_folds"]
    names = ["随机K折", "整家系留出", "时间划分", "泄漏(先筛SNP)", "折内筛SNP"]
    store = {k: [] for k in names}
    for _ in range(cfg["reps"]):
        Z, g, y, fam, npar = build_population(rng, cfg)
        kid = np.arange(npar, len(y)); nk = len(kid)
        perm = rng.permutation(kid); rand_folds = np.array_split(perm, K)
        sires = rng.permutation(cfg["n_sires"]); fam_folds = [kid[np.isin(fam[kid], s)] for s in np.array_split(sires, K)]
        # 仅在后代内部做 CV（父母代恒在训练集），突出"同家系/新家系"之差
        def cv_kids(folds, Zs=Z):
            pred = np.zeros(len(y))
            for te in folds:
                tr = np.setdiff1d(np.arange(len(y)), te)
                pred[te] = ridge_pred(Zs[tr], y[tr], Zs[te], lam)
            return np.corrcoef(pred[kid], y[kid])[0, 1] / h, np.corrcoef(pred[kid], g[kid])[0, 1]
        store[names[0]].append(cv_kids(rand_folds))
        store[names[1]].append(cv_kids(fam_folds))
        tr = np.arange(npar)
        pr = ridge_pred(Z[tr], y[tr], Z[kid], lam)
        store[names[2]].append((np.corrcoef(pr, y[kid])[0, 1] / h, np.corrcoef(pr, g[kid])[0, 1]))
        # 泄漏：用全部后代（含将来的测试集）的表型筛选 SNP
        r = np.abs([np.corrcoef(Z[kid, j], y[kid])[0, 1] for j in range(Z.shape[1])])
        keep = np.argsort(-r)[:cfg["screen_top"]]
        Zs = Z[:, keep] * np.sqrt(Z.shape[1] / len(keep))
        store[names[3]].append(cv_kids(rand_folds, Zs))
        # 诚实做法：筛选只在每个训练折内部完成
        pred = np.zeros(len(y))
        for te in rand_folds:
            trk = np.setdiff1d(kid, te); trall = np.setdiff1d(np.arange(len(y)), te)
            Zc = Z[trk] - Z[trk].mean(0)
            rr = np.abs(Zc.T @ (y[trk] - y[trk].mean()))
            kp = np.argsort(-rr)[:cfg["screen_top"]]
            Zs2 = Z[:, kp] * np.sqrt(Z.shape[1] / len(kp))
            pred[te] = ridge_pred(Zs2[trall], y[trall], Zs2[te], lam)
        store[names[4]].append((np.corrcoef(pred[kid], y[kid])[0, 1] / h, np.corrcoef(pred[kid], g[kid])[0, 1]))
    res = {}
    print(f"h²={cfg['h2']}，{cfg['n_sires']} 个父系家系 × {cfg['dams_per_sire']*cfg['kids_per_dam']} 个后代，重复 {cfg['reps']} 次")
    print(f"{'方案':<14}{'cor(ĝ,y)/h':>12}{'cor(ĝ,g)':>12}")
    for k in names:
        a = np.array(store[k]); res[k] = {"acc_phen": float(a[:, 0].mean()), "acc_true": float(a[:, 1].mean()),
                                          "sd_phen": float(a[:, 0].std(ddof=1))}
        print(f"{k:<14}{res[k]['acc_phen']:>12.3f}{res[k]['acc_true']:>12.3f}")
    a, b, c, d, e = (res[k]["acc_true"] for k in names)
    assert a > b + 0.04 > 0.04 and b > c, "随机 > 整家系留出 > 时间划分"
    assert res[names[3]]["acc_phen"] > res[names[4]]["acc_phen"] + 0.08, "泄漏应使表观准确性高于折内筛选"
    assert abs(res[names[3]]["acc_true"] - res[names[4]]["acc_true"]) < 0.08      # 真实预测力并未因泄漏而提高
    # 泄漏下 y-相关 与 真实 g-相关 之间的缺口
    gap_leak = res[names[3]]["acc_phen"] - res[names[3]]["acc_true"]
    gap_ok = res[names[4]]["acc_phen"] - res[names[4]]["acc_true"]
    print(f"\n表观（对表型）与真实（对育种值）之差：折内筛选 {gap_ok:+.3f}；泄漏 {gap_leak:+.3f}")
    assert gap_leak > gap_ok + 0.08
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex29_16_split_designs.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
