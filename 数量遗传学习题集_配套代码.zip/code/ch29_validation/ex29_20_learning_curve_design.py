#!/usr/bin/env python3
"""习题 29.20  学习曲线与参考群体建设：Daetwyler 期望、有效染色体片段数与边际收益

群体：Ne 头个体的 Wright–Fisher 随机交配 generations 代（位点自由重组，漂变产生 LD），
最后一代扩繁到 N_pop 头并留出 n_test 头做测试。对训练规模 N ∈ train_sizes 做 GBLUP，
测量对真实育种值的准确性 r(N)。
Daetwyler 近似：r² = N h² / (N h² + M_e)。拟合 M_e（线性化 1/r² = 1 + M_e/(h² N)），
报告：(1) 拟合有效染色体片段数 M_e；(2) 外推预测与实测之差；(3) 边际收益 Δr/ΔN 递减；
(4) "多一千头"在不同起点的价值；(5) 准确性对表型遗传力的依赖（h² 较低时需要更多个体）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def drift_population(rng, cfg):
    Ne, m = cfg["Ne"], cfg["m"]
    p0 = rng.uniform(0.2, 0.5, m)
    H = (rng.random((Ne, 2, m)) < p0).astype(np.int8)
    for _ in range(cfg["generations"]):
        mom = rng.integers(0, Ne, Ne); dad = rng.integers(0, Ne, Ne)
        new = np.empty_like(H)
        for k, par in enumerate((mom, dad)):
            pick = rng.integers(0, 2, (Ne, m))
            new[:, k] = np.where(pick == 0, H[par, 0], H[par, 1])
        H = new
    return H


def expand(rng, H, N):
    Ne, _, m = H.shape
    mom = rng.integers(0, Ne, N); dad = rng.integers(0, Ne, N)
    X = np.zeros((N, m))
    for par in (mom, dad):
        pick = rng.integers(0, 2, (N, m))
        X += np.where(pick == 0, H[par, 0], H[par, 1])
    return X


def fit_acc(Z, g, y, n_tr, n_te, lam):
    tr = np.arange(n_tr); te = np.arange(Z.shape[0] - n_te, Z.shape[0])
    a = np.linalg.solve(Z[tr] @ Z[tr].T + lam * np.eye(n_tr), y[tr] - y[tr].mean())
    pred = Z[te] @ (Z[tr].T @ a)
    return np.corrcoef(pred, g[te])[0, 1]


def main():
    cfg = json.loads((HERE / "data" / "ex29_20_config.json").read_text(encoding="utf-8"))
    sizes = cfg["train_sizes"]; m = cfg["m"]; N = cfg["N_pop"]; nte = cfg["n_test"]
    accs = {h2: {n: [] for n in sizes} for h2 in (cfg["h2"], 0.2)}
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        H = drift_population(rng, cfg); X = expand(rng, H, N)
        p = X.mean(0) / 2; keep = (p > 0.03) & (p < 0.97)
        Z = (X[:, keep] - 2 * p[keep]) / np.sqrt(2 * p[keep] * (1 - p[keep]))
        mk = Z.shape[1]
        b = np.zeros(mk); b[rng.choice(mk, cfg["n_qtl"], replace=False)] = rng.normal(0, 1, cfg["n_qtl"])
        g0 = Z @ b; g0 = (g0 - g0.mean()) / g0.std()
        for h2 in accs:
            g = g0 * np.sqrt(h2); y = g + rng.normal(0, np.sqrt(1 - h2), N)
            for n in sizes:
                accs[h2][n].append(fit_acc(Z, g, y, n, nte, mk * (1 - h2) / h2))
    out = {}
    for h2, d in accs.items():
        out[str(h2)] = {str(n): float(np.mean(v)) for n, v in d.items()}
    h2 = cfg["h2"]; r = np.array([out[str(h2)][str(n)] for n in sizes]); Ns = np.array(sizes, float)
    # 线性化拟合：1/r² − 1 = M_e/(h² N)
    yy = 1 / r ** 2 - 1; x = 1 / (h2 * Ns)
    Me = float(np.sum(x * yy) / np.sum(x * x))      # 过原点
    pred = np.sqrt(Ns * h2 / (Ns * h2 + Me))
    print(f"Ne={cfg['Ne']}，h²={h2}，有效 SNP 数 {m}，测试 {nte}，重复 {cfg['reps']}")
    print(f"{'N':>6}{'实测 r':>9}{'Daetwyler':>11}{'Δr/1000头':>11}")
    prev = None
    for i, n in enumerate(sizes):
        slope = (r[i] - r[i - 1]) / (n - sizes[i - 1]) * 1000 if i else float("nan")
        print(f"{n:>6}{r[i]:>9.3f}{pred[i]:>11.3f}{slope:>11.3f}")
    print(f"拟合 M_e = {Me:.0f}（染色体片段数的有效量级；位点数 {m}）")
    # 外推：用前 3 个点拟合，预测后 2 个点
    x3, y3 = x[:3], yy[:3]; Me3 = float(np.sum(x3 * y3) / np.sum(x3 * x3))
    ext = np.sqrt(Ns[3:] * h2 / (Ns[3:] * h2 + Me3))
    print(f"用前 3 点拟合 M_e={Me3:.0f}，外推 N={sizes[3]},{sizes[4]}：预测 {ext.round(3).tolist()}，实测 {r[3:].round(3).tolist()}")
    # 边际收益：再增加 budget 头
    B = cfg["marginal_budget"]
    gains = [(n, np.sqrt((n + B) * h2 / ((n + B) * h2 + Me)) - np.sqrt(n * h2 / (n * h2 + Me))) for n in (500, 1000, 2000, 4000)]
    print("再增加 %d 头的预测收益：" % B + "；".join(f"N={n}: +{d:.3f}" for n, d in gains))
    # 低遗传力
    r2 = np.array([out["0.2"][str(n)] for n in sizes])
    n80 = [n for n, a in zip(sizes, r) if a >= 0.7]; n80b = [n for n, a in zip(sizes, r2) if a >= 0.7]
    print(f"h²=0.2 的实测 r：{r2.round(3).tolist()}（h²=0.5：{r.round(3).tolist()}）")
    # 断言
    assert np.all(np.diff(r) > 0) and np.all(np.diff(r2) > 0)
    assert np.all(r > r2)
    sl = np.diff(r) / np.diff(Ns)
    assert np.all(np.diff(sl) < 0)                              # 边际收益递减
    assert np.max(np.abs(pred - r)) < 0.08                       # Daetwyler 形状拟合
    assert np.max(np.abs(ext - r[3:])) < 0.12
    gs = [d for _, d in gains]; assert all(gs[i] > gs[i + 1] for i in range(3))
    out["Me"] = Me; out["Me_first3"] = Me3; out["pred"] = pred.tolist(); out["extrap"] = ext.tolist()
    out["gains"] = {str(n): float(d) for n, d in gains}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex29_20_learning_curve_design.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
