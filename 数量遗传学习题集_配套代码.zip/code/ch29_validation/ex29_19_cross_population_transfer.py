#!/usr/bin/env python3
"""习题 29.19  跨群体迁移：直接迁移、校准适配、源偏移＋本地残差、仅本地重训的学习曲线

两个品种共有 L=n_blocks×block 个位点，群体 A（源，大参考群）与 B（目标）的等位基因频率有漂变差异，
块内 LD 强度不同（A: 0.5，B: 0.2；高斯 copula 产生）。每块第一个位点为因果位点（不在 SNP 芯片中），
芯片 SNP 为其余位点；因果效应在两品种间的相关为 r_g（候选值 0.9/0.5/0.1）。
对目标品种训练集大小 n_T ∈ target_sizes，比较在 600 头目标测试动物上的 cor(ĝ,g_B)：
  S 直接迁移：只用源模型；  C 校准：在目标训练集上拟合 y ≈ a + b·ĝ_S；
  O 源偏移＋本地残差：ĝ = b·ĝ_S + 本地 ridge 拟合残差；  T 仅本地 ridge（目标训练集）。
断言：r_g 高时 S 已有可观准确性、C 提高斜率；r_g 低时直接迁移几乎无用，T 在较大 n_T 超过 S；
O 在小 n_T 不低于 T，在 r_g 很低且 n_T 大时与 T 接近（不出现严重负迁移）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def make_geno(rng, n, p, nb, bs, rho):
    """块内高斯 copula：潜变量相关 rho，再按各位点频率二分（每个单倍型），两单倍型相加。"""
    from scipy.stats import norm
    thr = norm.ppf(1 - p).reshape(nb, bs)
    X = np.zeros((n, nb * bs))
    for _ in range(2):
        common = rng.normal(size=(n, nb, 1)); own = rng.normal(size=(n, nb, bs))
        lat = np.sqrt(rho) * common + np.sqrt(1 - rho) * own
        X += (lat > thr).reshape(n, nb * bs)
    return X


def ridge_fit(Z, y, lam):
    a = np.linalg.solve(Z @ Z.T + lam * np.eye(len(y)), y - y.mean())
    return Z.T @ a, y.mean()


def main():
    cfg = json.loads((HERE / "data" / "ex29_19_config.json").read_text(encoding="utf-8"))
    nb, bs, h2 = cfg["n_blocks"], cfg["block"], cfg["h2"]
    L = nb * bs; caus = np.arange(0, L, bs); chip = np.setdiff1d(np.arange(L), caus)
    res = {}
    for rg in cfg["rg_list"]:
        acc = {k: {n: [] for n in cfg["target_sizes"]} for k in "SCOT"}
        cal = {k: {n: [] for n in cfg["target_sizes"]} for k in ("slopeS", "slopeC", "mseS", "mseC")}
        for r in range(cfg["reps"]):
            rng = np.random.default_rng(cfg["seed"] + 100 * r)
            pA = rng.uniform(0.15, 0.5, L)
            pB = np.clip(pA + rng.normal(0, cfg["freq_shift"], L), 0.05, 0.95)
            nT = max(cfg["target_sizes"]) + cfg["n_test"]
            XA = make_geno(rng, cfg["n_source"], pA.reshape(nb, bs), nb, bs, cfg["rho_A"])
            XB = make_geno(rng, nT, pB.reshape(nb, bs), nb, bs, cfg["rho_B"])
            bA = rng.normal(0, 1, len(caus)); bB = rg * bA + np.sqrt(1 - rg ** 2) * rng.normal(0, 1, len(caus))
            gA = XA[:, caus] @ bA; gB = XB[:, caus] @ bB
            sA, sB = gA.std(), gB.std()
            yA = gA / sA * np.sqrt(h2) + rng.normal(0, np.sqrt(1 - h2), len(gA))
            gB = gB / sB * np.sqrt(h2); yB = gB + rng.normal(0, np.sqrt(1 - h2), nT)
            # 芯片标准化（各品种用本品种频率）
            ZA = (XA[:, chip] - XA[:, chip].mean(0)) / (XA[:, chip].std(0) + 1e-9)
            ZB = (XB[:, chip] - XB[:, chip].mean(0)) / (XB[:, chip].std(0) + 1e-9)
            mchip = len(chip)
            beta_S, _ = ridge_fit(ZA, yA, mchip * (1 - h2) / h2)
            te = np.arange(nT - cfg["n_test"], nT)
            for n in cfg["target_sizes"]:
                tr = np.arange(n)
                gS = ZB @ beta_S
                acc["S"][n].append(np.corrcoef(gS[te], gB[te])[0, 1])
                # 校准
                b = np.cov(yB[tr], gS[tr])[0, 1] / gS[tr].var(ddof=1)
                gC = b * gS
                acc["C"][n].append(np.corrcoef(gC[te], gB[te])[0, 1])
                for tag, gg in (("S", gS), ("C", gC)):
                    cal["slope" + tag][n].append(np.cov(gB[te], gg[te])[0, 1] / gg[te].var(ddof=1))
                    cal["mse" + tag][n].append(np.mean(((gg[te] - gg[te].mean()) - (gB[te] - gB[te].mean())) ** 2))
                # 源偏移＋本地残差
                res_y = yB[tr] - yB[tr].mean() - b * (gS[tr] - gS[tr].mean())
                bet, _ = ridge_fit(ZB[tr], res_y, mchip * 3.0)
                gO = gC + ZB @ bet
                acc["O"][n].append(np.corrcoef(gO[te], gB[te])[0, 1])
                bet, _ = ridge_fit(ZB[tr], yB[tr], mchip * (1 - h2) / h2)
                acc["T"][n].append(np.corrcoef((ZB @ bet)[te], gB[te])[0, 1])
        res[str(rg)] = {k: {str(n): float(np.mean(v)) for n, v in d.items()} for k, d in acc.items()}
        res[str(rg)]["cal"] = {k: {str(n): float(np.mean(v)) for n, v in d.items()} for k, d in cal.items()}
    names = {"S": "直接迁移", "C": "校准", "O": "偏移+残差", "T": "仅本地"}
    for rg, d in res.items():
        d = dict(d); cal_d = d.pop("cal") if False else d["cal"]
        print(f"\nr_g={rg}（源 n={cfg['n_source']}，测试 {cfg['n_test']}，重复 {cfg['reps']}）")
        print(f"{'n_T':>6}" + "".join(f"{names[k]:>12}" for k in "SCOT"))
        for n in cfg["target_sizes"]:
            print(f"{n:>6}" + "".join(f"{d[k][str(n)]:>12.3f}" for k in "SCOT"))
        n2 = str(cfg["target_sizes"][2])
        print(f"  校准的作用（n_T={n2}）：g 对 ĝ 的斜率 直接迁移 {cal_d['slopeS'][n2]:.2f} → 校准 {cal_d['slopeC'][n2]:.2f}；"
              f"MSE {cal_d['mseS'][n2]:.3f} → {cal_d['mseC'][n2]:.3f}")
    sizes = [str(n) for n in cfg["target_sizes"]]
    hi, lo = res["0.9"], res["0.1"]
    assert hi["S"][sizes[0]] > 0.25 and lo["S"][sizes[0]] < 0.15
    assert lo["T"][sizes[-1]] > lo["S"][sizes[-1]] + 0.1
    assert hi["O"][sizes[0]] >= hi["T"][sizes[0]] - 0.01 and hi["O"][sizes[0]] > hi["T"][sizes[0]] + 0.05
    assert lo["O"][sizes[-1]] > lo["T"][sizes[-1]] - 0.06           # 无严重负迁移
    assert hi["T"][sizes[-1]] > hi["T"][sizes[0]]                  # 学习曲线上升
    # 交叉点：目标仅本地重训超过直接迁移所需的 n_T
    cross = {}
    for rg, d in res.items():
        c = next((int(n) for n in sizes if d["T"][n] > d["S"][n]), None); cross[rg] = c
    n2 = sizes[2]
    assert res["0.5"]["cal"]["mseC"][n2] < res["0.5"]["cal"]["mseS"][n2] and abs(res["0.5"]["cal"]["slopeC"][n2] - 1) < abs(res["0.5"]["cal"]["slopeS"][n2] - 1)
    print("\n本地重训首次超过直接迁移的 n_T：", cross)
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex29_19_cross_population_transfer.json").write_text(json.dumps({"acc": res, "cross": cross}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
