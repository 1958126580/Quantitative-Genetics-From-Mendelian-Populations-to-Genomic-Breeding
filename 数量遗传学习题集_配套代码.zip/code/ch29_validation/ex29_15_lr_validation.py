#!/usr/bin/env python3
"""习题 29.15  LR 验证（部分—整体评定）：偏差、斜率与准确性，对照真实育种值

设计：n 头动物（其中 n_young 头为"焦点动物"），GBLUP 评定两次——部分评定 û_p 只用老动物的表型，
整体评定 û_w 使用全部表型。LR（Legarra–Reverter）统计量：
    偏差  Δ = mean(û_w) − mean(û_p)         （部分评定对焦点动物的平均偏差，应≈0）
    斜率  b = cov(û_w, û_p)/var(û_p)         （应≈1；<1 表示 û_p 过度分散）
    准确性 ρ̂² = cov(û_p, û_w)/σ_g²           （σ_g² 为遗传方差）
程序同时模拟"真值已知"，对比：LR 估计、真实相关 cor(û_p,g)、以及用校正表型的 cor(û_p,y)/h。
再把部分评定故意做错（遗传力过大、收缩不足），验证 LR 斜率能把膨胀识别出来。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(rng, n, m, n_qtl, h2):
    p = rng.uniform(0.1, 0.5, m)
    X = rng.binomial(2, p, size=(n, m)).astype(float)
    Z = (X - 2 * p) / np.sqrt(2 * p * (1 - p))
    q = rng.choice(m, n_qtl, replace=False)
    b = np.zeros(m); b[q] = rng.normal(0, 1, n_qtl)
    g = Z @ b
    g = (g - g.mean()) / g.std() * np.sqrt(h2)
    y = g + rng.normal(0, np.sqrt(1 - h2), n)
    return Z, g, y


def gblup(Z, y, train, lam):
    """返回全部动物的 û = Z Zᵀ/m (K+λ)⁻¹(y−ȳ) 形式（ridge 等价）。"""
    m = Z.shape[1]
    G = Z @ Z.T / m
    Kt = G[np.ix_(train, train)]
    a = np.linalg.solve(Kt + lam * np.eye(len(train)), y[train] - y[train].mean())
    return G[:, train] @ a


def one_rep(rng, cfg, lam_factor):
    n, m, h2 = cfg["n"], cfg["m"], cfg["h2"]
    Z, g, y = simulate(rng, n, m, cfg["n_qtl"], h2)
    young = np.arange(n - cfg["n_young"], n)
    old = np.arange(n - cfg["n_young"])
    lam_true = (1 - h2) / h2
    u_p = gblup(Z, y, old, lam_true * lam_factor)[young]       # 部分评定：只用老动物表型
    u_w = gblup(Z, y, np.arange(n), lam_true)[young]           # 整体评定：全部表型（正确 λ）
    s2g = h2
    cov = np.cov(u_p, u_w)[0, 1]
    return dict(delta=u_w.mean() - u_p.mean(), slope=cov / u_p.var(ddof=1),
                acc_lr=np.sqrt(max(cov, 0) / s2g), acc_true=np.corrcoef(u_p, g[young])[0, 1],
                acc_phen=np.corrcoef(u_p, y[young])[0, 1] / np.sqrt(h2),
                true_slope=np.cov(g[young], u_p)[0, 1] / u_p.var(ddof=1))


def main():
    cfg = json.loads((HERE / "data" / "ex29_15_config.json").read_text(encoding="utf-8"))
    out = {}
    print("LR 验证：部分评定（缺焦点动物表型）与整体评定对照，重复 %d 次，h²=%.2f" % (cfg["reps"], cfg["h2"]))
    for f in cfg["lambda_wrong_factors"]:
        rng = np.random.default_rng(cfg["seed"])
        rows = [one_rep(rng, cfg, f) for _ in range(cfg["reps"])]
        mean = {k: float(np.mean([r[k] for r in rows])) for k in rows[0]}
        sd = {k: float(np.std([r[k] for r in rows], ddof=1)) for k in rows[0]}
        out[str(f)] = {"mean": mean, "sd": sd}
        tag = "λ 正确" if f == 1.0 else "λ 缩小为 %.2f 倍（收缩不足）" % f
        print(f"\n[{tag}]")
        print(f"  LR 偏差 Δ={mean['delta']:+.4f}（sd {sd['delta']:.4f}）  LR 斜率 b={mean['slope']:.3f}（sd {sd['slope']:.3f}）")
        print(f"  准确性：LR 估计 {mean['acc_lr']:.3f}；真实 cor(û_p,g) {mean['acc_true']:.3f}；cor(û_p,y)/h {mean['acc_phen']:.3f}")
        print(f"  真实斜率（g 对 û_p 回归）{mean['true_slope']:.3f}")
    ok = out["1.0"]["mean"]
    assert abs(ok["slope"] - 1) < 0.12 and abs(ok["delta"]) < 0.05
    assert abs(ok["acc_lr"] - ok["acc_true"]) < 0.06 and abs(ok["acc_phen"] - ok["acc_true"]) < 0.06
    ks = list(out)
    slopes = [out[k]["mean"]["slope"] for k in ks]
    assert slopes[0] > slopes[1] > slopes[2] and slopes[2] < 0.85      # 收缩不足 → 斜率下降
    assert out[ks[2]]["mean"]["acc_true"] < out[ks[0]]["mean"]["acc_true"]
    print("\n核验通过：正确模型的 LR 斜率≈1、LR 准确性≈真实相关；收缩不足使斜率单调下降。")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex29_15_lr_validation.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
