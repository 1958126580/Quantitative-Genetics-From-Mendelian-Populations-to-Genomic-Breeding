#!/usr/bin/env python3
"""习题 29.18  相关动物验证中的不确定性：设计效应、整家系自助法与配对损失差

(1) 误差均值：50 个家系 × 20 头，组内相关 ρ=0.10；比较三种 95% 区间的覆盖率：
    独立（i.i.d.）标准误、设计效应修正（DEFF=1+(m̄−1)ρ̂）、整家系自助法（cluster bootstrap）；
(2) 总动物数固定时，每家系动物越多，设计效应越大，有效样本量 ≈ N/DEFF 越小；
(3) 配对损失差 d_i = L_A(i) − L_B(i)：两种模型的真实表现无差别（效应=0），但误差在家系内正相关，
    独立 t 检验的假阳性率远高于 5%，整家系自助法接近名义水平；
(4) 相关系数 r 的自助法：独立自助法低估 r 的标准误。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def sim_errors(rng, nfam, size, icc):
    fam = np.repeat(np.arange(nfam), size)
    return fam, rng.normal(0, np.sqrt(icc), nfam)[fam] + rng.normal(0, np.sqrt(1 - icc), nfam * size)


def anova_icc(x, fam, nfam):
    k = len(x) / nfam
    gm = x.mean(); fm = np.array([x[fam == f].mean() for f in range(nfam)])
    msb = k * np.sum((fm - gm) ** 2) / (nfam - 1)
    msw = np.sum((x - fm[fam]) ** 2) / (len(x) - nfam)
    return max((msb - msw) / (msb + (k - 1) * msw), 0.0)


def cluster_boot_se(x, fam, nfam, B, rng, stat=np.mean):
    groups = [np.flatnonzero(fam == f) for f in range(nfam)]
    vals = np.empty(B)
    for b in range(B):
        pick = rng.integers(0, nfam, nfam)
        vals[b] = stat(x[np.concatenate([groups[i] for i in pick])])
    return vals.std(ddof=1)


def main():
    cfg = json.loads((HERE / "data" / "ex29_18_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); nf, sz, icc = cfg["n_fam"], cfg["fam_size"], cfg["icc"]
    N = nf * sz; z = 1.96
    cover = {"独立": 0, "DEFF": 0, "整家系自助": 0}; width = {k: [] for k in cover}
    for _ in range(cfg["reps"]):
        fam, x = sim_errors(rng, nf, sz, icc)
        m = x.mean(); s_iid = x.std(ddof=1) / np.sqrt(N)
        rho = anova_icc(x, fam, nf); deff = 1 + (sz - 1) * rho
        s_def = s_iid * np.sqrt(deff)
        s_cb = cluster_boot_se(x, fam, nf, cfg["boot"], rng)
        for k, s in (("独立", s_iid), ("DEFF", s_def), ("整家系自助", s_cb)):
            cover[k] += abs(m) <= z * s; width[k].append(2 * z * s)
    true_se = np.sqrt((1 + (sz - 1) * icc) / N)
    deff0 = 1 + (sz - 1) * icc
    print(f"(1) {nf}家系×{sz}头，ρ={icc}：理论 DEFF={deff0:.2f}，有效样本量 {N/deff0:.1f}，真实标准误 {true_se:.4f}")
    for k in cover:
        print(f"    {k:<8} 覆盖率 {cover[k]/cfg['reps']:.3f}  平均区间宽度 {np.mean(width[k]):.4f}")
    # (2) 不同家系大小
    print("\n(2) 家系大小对设计效应的影响（总动物数固定 1000）：")
    eff = {}
    for s in cfg["unequal_sizes"]:
        d = 1 + (s - 1) * icc; eff[s] = (d, 1000 / d)
        print(f"    每家 {s:>2} 头 → DEFF={d:.2f}，有效样本量 {1000/d:.0f}")
    # (3) 配对损失差
    rej = {"独立t": 0, "整家系自助": 0}
    for _ in range(cfg["reps"]):
        fam = np.repeat(np.arange(nf), sz)
        fe = rng.normal(0, np.sqrt(cfg["paired_rho_family"]), nf)[fam]
        d = cfg["paired_effect"] + fe + rng.normal(0, np.sqrt(1 - cfg["paired_rho_family"]), N)
        t = d.mean() / (d.std(ddof=1) / np.sqrt(N))
        rej["独立t"] += abs(t) > z
        se = cluster_boot_se(d, fam, nf, 200, rng)
        rej["整家系自助"] += abs(d.mean() / se) > z
    print("\n(3) 两模型无真实差异时的假阳性率（名义 5%）：")
    for k, v in rej.items():
        print(f"    {k:<8} {v/cfg['reps']:.3f}")
    # (4) 相关系数
    fam, _ = sim_errors(rng, nf, sz, icc)
    reps_r = 300; rs = []
    for _ in range(reps_r):
        fe1 = rng.normal(0, np.sqrt(0.3), nf)[fam]; fe2 = 0.5 * fe1 + rng.normal(0, np.sqrt(0.3), nf)[fam]
        a = fe1 + rng.normal(0, np.sqrt(0.7), N); b = 0.4 * a + fe2 + rng.normal(0, np.sqrt(0.7), N)
        rs.append(np.corrcoef(a, b)[0, 1])
    sd_true = np.std(rs, ddof=1)
    a = fe1 + rng.normal(0, np.sqrt(0.7), N); b = 0.4 * a + fe2 + rng.normal(0, np.sqrt(0.7), N)
    idx = np.arange(N); iid = np.std([np.corrcoef(a[i], b[i])[0, 1] for i in (rng.integers(0, N, N) for _ in range(300))], ddof=1)
    groups = [np.flatnonzero(fam == f) for f in range(nf)]
    cl = []
    for _ in range(300):
        i = np.concatenate([groups[j] for j in rng.integers(0, nf, nf)]); cl.append(np.corrcoef(a[i], b[i])[0, 1])
    print(f"\n(4) 相关系数标准误：重复模拟的真实 sd={sd_true:.4f}；独立自助 {iid:.4f}；整家系自助 {np.std(cl, ddof=1):.4f}")
    cov_iid = cover["独立"] / cfg["reps"]; cov_def = cover["DEFF"] / cfg["reps"]; cov_cb = cover["整家系自助"] / cfg["reps"]
    assert cov_iid < 0.85 and cov_def > 0.92 and cov_cb > 0.90
    assert rej["独立t"] / cfg["reps"] > 0.25 and rej["整家系自助"] / cfg["reps"] < 0.10
    assert iid < sd_true * 0.8 and np.std(cl, ddof=1) > iid
    out = {"coverage": {k: v / cfg["reps"] for k, v in cover.items()}, "type1": {k: v / cfg["reps"] for k, v in rej.items()},
           "deff": deff0, "n_eff": N / deff0, "r_se": {"true": sd_true, "iid_boot": iid, "cluster_boot": float(np.std(cl, ddof=1))},
           "deff_by_size": {str(k): v for k, v in eff.items()}}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex29_18_clustered_uncertainty.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
