# 第29章　验证设计、准确性、校准与跨群体迁移——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex29_15_lr_validation.py
python3 ex29_16_split_designs.py
python3 ex29_17_calibration_selection.py
python3 ex29_18_clustered_uncertainty.py
python3 ex29_19_cross_population_transfer.py
python3 ex29_20_learning_curve_design.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex29_15_lr_validation.py | 29.15 | LR 验证（部分—整体评定）：偏差、斜率与准确性，对照真实育种值 |
| ex29_16_split_designs.py | 29.16 | 随机、整家系、时间划分与信息泄漏：同一个模型，四个"准确性" |
| ex29_17_calibration_selection.py | 29.17 | 校准斜率、选择后的条件解释与范围限制 |
| ex29_18_clustered_uncertainty.py | 29.18 | 相关动物验证中的不确定性：设计效应、整家系自助法与配对损失差 |
| ex29_19_cross_population_transfer.py | 29.19 | 跨群体迁移：直接迁移、校准适配、源偏移＋本地残差、仅本地重训的学习曲线 |
| ex29_20_learning_curve_design.py | 29.20 | 学习曲线与参考群体建设：Daetwyler 期望、有效染色体片段数与边际收益 |
