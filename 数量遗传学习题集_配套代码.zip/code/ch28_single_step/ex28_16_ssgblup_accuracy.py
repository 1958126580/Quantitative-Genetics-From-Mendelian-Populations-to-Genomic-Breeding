#!/usr/bin/env python3
"""习题 28.16  单步 GBLUP 与系谱 BLUP、只用分型动物的 GBLUP：准确性与离散度比较

模拟 5 世代闭锁群体（基因下落 + 300 个 QTL），h² = 0.30。第 0—4 代动物有表型，
第 5 代 200 头幼龄候选只有基因型；另从第 3—4 代随机分型 300 头（有表型）。
比较四种评定：
    PBLUP      ：K⁻¹ = A⁻¹；
    GBLUP      ：只用 500 头分型动物（其中 300 头有表型），K⁻¹ = Gw⁻¹；
    ssGBLUP    ：K⁻¹ = H⁻¹，G 先按 A22 调整均值与尺度再与 A22 以 0.95 : 0.05 混合；
    ssGBLUP-raw：H⁻¹ 中直接使用未调整的 G（只混合 5% A22）。
混合模型方程 [[X'X, X'Z], [Z'X, Z'Z + λK⁻¹]]，λ = σe²/σa²，固定效应为 20 个场年。
评价：候选（分型、无表型）与未分型有表型动物的准确性 corr(u, û)、离散度斜率 b(u|û)、
    以及平均偏差 mean(û − u)（以遗传标准差为单位）。
独立核验：(1) ssGBLUP 的 MME 解与 û = H Z'V⁻¹(y − Xβ̂) 的 GLS 形式一致；
          (2) MME 残差范数接近机器精度。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.linalg import cho_factor, cho_solve

HERE = Path(__file__).resolve().parent


def simulate_population(cfg: dict, rng: np.random.Generator):
    nf, ngen, noff = cfg["founders"], cfg["generations"], cfg["offspring_per_gen"]
    sire = [-1] * nf; dam = [-1] * nf; gen = [0] * nf
    males = list(range(0, nf, 2)); females = list(range(1, nf, 2))
    for g in range(1, ngen + 1):
        sires = rng.choice(males, cfg["sires_per_gen"], replace=False)
        dams = rng.choice(females, min(cfg["dams_per_gen"], len(females)), replace=False)
        new_m, new_f = [], []
        for _ in range(noff):
            i = len(sire); sire.append(int(rng.choice(sires))); dam.append(int(rng.choice(dams))); gen.append(g)
            (new_m if rng.random() < 0.5 else new_f).append(i)
        males, females = new_m, new_f
    n = len(sire); m_chr, n_chr = cfg["loci_per_chr"], cfg["n_chr"]
    pos = np.sort(rng.uniform(0, 1, (n_chr, m_chr)), axis=1)
    p0 = rng.uniform(0.05, 0.95, n_chr * m_chr)
    hap = np.zeros((n, 2, p0.size), dtype=np.int8)
    for i in range(nf):
        hap[i] = (rng.random((2, p0.size)) < p0).astype(np.int8)
    for i in range(nf, n):
        for k, par in enumerate((sire[i], dam[i])):
            for c in range(n_chr):
                sl = slice(c * m_chr, (c + 1) * m_chr)
                cuts = np.sort(rng.uniform(0, 1, rng.poisson(1.0)))
                strand = (int(rng.integers(2)) + np.searchsorted(cuts, pos[c])) % 2
                hap[i, k, sl] = np.where(strand == 0, hap[par, 0, sl], hap[par, 1, sl])
    return np.array(sire), np.array(dam), np.array(gen), hap, p0


def tabular_A(sire, dam):
    n = sire.size; A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]; row = np.zeros(i)
        if s >= 0: row += 0.5 * A[s, :i]
        if d >= 0: row += 0.5 * A[d, :i]
        A[i, :i] = row; A[:i, i] = row
        A[i, i] = 1.0 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0.0)
    return A


def henderson_Ainv(sire, dam, F):
    n = sire.size; Ai = np.zeros((n, n))
    for i in range(n):
        par = [p for p in (sire[i], dam[i]) if p >= 0]
        b = 1.0 - 0.25 * len(par) - 0.25 * sum(F[p] for p in par)
        idx = [i] + par; w = np.array([1.0] + [-0.5] * len(par))
        Ai[np.ix_(idx, idx)] += np.outer(w, w) / b
    return Ai


def vanraden_G(M):
    p = M.mean(axis=0) / 2; keep = (p > 0.01) & (p < 0.99)
    Z = M[:, keep] - 2 * p[keep]
    return Z @ Z.T / (2 * np.sum(p[keep] * (1 - p[keep])))


def tune(G, A22):
    Mx = np.array([[np.mean(np.diag(G)), 1.0], [np.mean(G), 1.0]])
    beta, alpha = np.linalg.solve(Mx, [np.mean(np.diag(A22)), np.mean(A22)])
    return beta * G + alpha


def solve_mme(X, Z, y, Kinv, lam):
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * Kinv]])
    rhs = np.concatenate([X.T @ y, Z.T @ y])
    sol = cho_solve(cho_factor(C), rhs)
    resid = float(np.linalg.norm(rhs - C @ sol) / np.linalg.norm(rhs))
    return sol[:X.shape[1]], sol[X.shape[1]:], resid


def metrics(u, uh, idx, sd_a):
    a, b = u[idx], uh[idx]
    return {"acc": float(np.corrcoef(a, b)[0, 1]), "slope": float(np.cov(a, b)[0, 1] / np.var(b, ddof=1)),
            "bias_sd": float(np.mean(b - a) / sd_a)}


def one_replicate(cfg, rng, check=False):
    sire, dam, gen, hap, p0 = simulate_population(cfg, rng)
    n = sire.size; nl = p0.size
    qtl = np.sort(rng.choice(nl, cfg["n_qtl"], replace=False)); mk = np.setdiff1d(np.arange(nl), qtl)
    geno = hap.sum(axis=1).astype(float)
    a = rng.normal(0, 1, qtl.size)
    a *= np.sqrt(cfg["var_a"] / np.sum(2 * p0[qtl] * (1 - p0[qtl]) * a ** 2))
    u = (geno[:, qtl] - 2 * p0[qtl]) @ a
    var_e = cfg["var_a"] * (1 - cfg["h2"]) / cfg["h2"]
    rec = np.where(gen <= cfg["last_recorded_gen"])[0]
    hy = rng.integers(0, cfg["n_hy"], rec.size)
    hy_eff = rng.normal(0, np.sqrt(cfg["var_hy"]), cfg["n_hy"])
    y = 100 + hy_eff[hy] + u[rec] + rng.normal(0, np.sqrt(var_e), rec.size)
    X = np.zeros((rec.size, cfg["n_hy"])); X[np.arange(rec.size), hy] = 1
    Z = np.zeros((rec.size, n)); Z[np.arange(rec.size), rec] = 1
    lam = var_e / cfg["var_a"]

    cand = np.where(gen == cfg["generations"])[0]
    pool = np.where((gen >= 3) & (gen <= cfg["last_recorded_gen"]))[0]
    g2 = np.sort(np.concatenate([cand, rng.choice(pool, cfg["n_genotyped_old"], replace=False)]))
    g1 = np.setdiff1d(np.arange(n), g2)
    A = tabular_A(sire, dam); F = np.diag(A) - 1; Ainv = henderson_Ainv(sire, dam, F)
    A22 = A[np.ix_(g2, g2)]; A22inv = np.linalg.inv(A22)
    G = vanraden_G(geno[np.ix_(g2, mk)])
    w = cfg["blend_w"]
    Gw = (1 - w) * tune(G, A22) + w * A22
    Graw = (1 - w) * G + w * A22

    sols = {}
    _, sols["PBLUP"], r1 = solve_mme(X, Z, y, Ainv, lam)
    for name, GG in (("ssGBLUP", Gw), ("ssGBLUP-raw", Graw)):
        Hinv = Ainv.copy(); Hinv[np.ix_(g2, g2)] += np.linalg.inv(GG) - A22inv
        b_hat, sols[name], r2 = solve_mme(X, Z, y, Hinv, lam)
        assert r2 < 1e-10, r2
        if check and name == "ssGBLUP":
            H = np.linalg.inv(Hinv); ZH = Z @ H
            V = ZH @ Z.T * cfg["var_a"] + var_e * np.eye(rec.size)
            Vc = cho_factor(V)
            b_gls = np.linalg.solve(X.T @ cho_solve(Vc, X), X.T @ cho_solve(Vc, y))
            u_gls = cfg["var_a"] * ZH.T @ cho_solve(Vc, y - X @ b_gls)
            gls_diff = float(np.max(np.abs(u_gls - sols[name])))
            assert gls_diff < 1e-6, gls_diff
    # GBLUP 只用分型动物
    recg = np.isin(rec, g2); Xg = X[recg]; keep_cols = Xg.sum(axis=0) > 0; Xg = Xg[:, keep_cols]
    pos_in_g2 = {a_: k for k, a_ in enumerate(g2)}
    Zg = np.zeros((recg.sum(), g2.size)); Zg[np.arange(recg.sum()), [pos_in_g2[a_] for a_ in rec[recg]]] = 1
    _, ug, _ = solve_mme(Xg, Zg, y[recg], np.linalg.inv(Gw), lam)
    u_gblup = np.full(n, np.nan); u_gblup[g2] = ug; sols["GBLUP"] = u_gblup

    sd_a = np.sqrt(cfg["var_a"])
    ungeno_rec = np.intersect1d(g1, np.where(gen == cfg["last_recorded_gen"])[0])
    out = {}
    for name, uh in sols.items():
        out[name] = {"candidates": metrics(u, uh, cand, sd_a)}
        if name != "GBLUP":
            out[name]["ungenotyped_recorded"] = metrics(u, uh, ungeno_rec, sd_a)
    out["_check"] = {"gls_max_abs": gls_diff if check else None}
    return out


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex28_16_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    reps = [one_replicate(cfg, rng, check=(r == 0)) for r in range(cfg["replicates"])]
    print(f"重复 {cfg['replicates']} 次；h² = {cfg['h2']}；候选为第 {cfg['generations']} 代分型、无表型动物")
    print(f"首个重复中 MME 解与 GLS 形式最大差 {reps[0]['_check']['gls_max_abs']:.2e}")
    summary = {}
    print(f"{'模型':<12s}{'候选准确性':>12s}{'候选斜率':>10s}{'候选偏差/σa':>12s}{'未分型准确性':>13s}{'未分型斜率':>11s}")
    for name in ("PBLUP", "GBLUP", "ssGBLUP-raw", "ssGBLUP"):
        row = {}
        for grp in ("candidates", "ungenotyped_recorded"):
            if grp not in reps[0][name]: continue
            for k in ("acc", "slope", "bias_sd"):
                v = np.array([r[name][grp][k] for r in reps])
                row[f"{grp}_{k}"] = {"mean": float(v.mean()), "sd": float(v.std(ddof=1))}
        summary[name] = row
        ua = row.get("ungenotyped_recorded_acc", {"mean": np.nan}); us = row.get("ungenotyped_recorded_slope", {"mean": np.nan})
        print(f"{name:<12s}{row['candidates_acc']['mean']:12.3f}{row['candidates_slope']['mean']:10.3f}"
              f"{row['candidates_bias_sd']['mean']:12.3f}{ua['mean']:13.3f}{us['mean']:11.3f}")
    # 核验：单步评定对候选的准确性高于系谱 BLUP 与仅分型 GBLUP；对未分型有表型动物不低于 PBLUP；斜率在 0.8–1.3 内
    c = {k: summary[k]["candidates_acc"]["mean"] for k in summary}
    assert c["ssGBLUP"] > c["PBLUP"] + 0.05 and c["ssGBLUP"] > c["GBLUP"] + 0.02, c
    assert summary["ssGBLUP"]["ungenotyped_recorded_acc"]["mean"] >= summary["PBLUP"]["ungenotyped_recorded_acc"]["mean"] - 0.02
    for k in summary:
        assert 0.8 < summary[k]["candidates_slope"]["mean"] < 1.3, (k, summary[k]["candidates_slope"])
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex28_16_ssgblup_accuracy.json").write_text(
        json.dumps({"summary": summary, "replicates": reps}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
