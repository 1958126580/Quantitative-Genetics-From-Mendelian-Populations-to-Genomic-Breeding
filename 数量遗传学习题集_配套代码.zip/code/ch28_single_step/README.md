# 第28章　单步基因组评定——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex28_15_h_matrix.py
python3 ex28_16_ssgblup_accuracy.py
python3 ex28_17_apy_core.py
python3 ex28_18_pcg_solver.py
python3 ex28_19_metafounder.py
python3 ex28_20_reliability.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex28_15_h_matrix.py | 28.15 | 单步关系矩阵 H：条件构造、逆矩阵公式、G 的尺度调整与常见实现错误 |
| ex28_16_ssgblup_accuracy.py | 28.16 | 单步 GBLUP 与系谱 BLUP、只用分型动物的 GBLUP：准确性与离散度比较 |
| ex28_17_apy_core.py | 28.17 | APY 近似：核心规模、核心定义与条件相关诊断 |
| ex28_18_pcg_solver.py | 28.18 | 单步方程的预条件共轭梯度：收敛、停止规则、目标误差与热启动 |
| ex28_19_metafounder.py | 28.19 | 元基础群体 Γ：定义、合法性、A_Γ 的构造与基因下落蒙特卡罗核验 |
| ex28_20_reliability.py | 28.20 | 单步评定的可靠度：个体、差值与群体对比，以及随机化对角估计 |
