#!/usr/bin/env python3
"""习题 28.17  APY 近似：核心规模、核心定义与条件相关诊断

把已分型动物分为核心 c 与非核心 n：
    T = G_nc G_cc⁻¹，S = G_nn − G_nc G_cc⁻¹ G_cn（给定核心后的条件协方差），
    APY 以 D = diag(S) 代替 S，相应
        G_APY⁻¹ = [[G_cc⁻¹ + Tᵀ D⁻¹ T, −Tᵀ D⁻¹], [−D⁻¹ T, D⁻¹]]。
诊断：标准化条件相关 C = D^{-1/2} S D^{-1/2}，被忽略的信息量（相对熵）KL = −½ log|C|；
    近似矩阵与 G 的最大元素差；GBLUP 候选育种值与精确解的相关、回归斜率、
    最大绝对差（以精确解标准差为单位）与前 10% 名单重合率。
核心定义：随机抽取；按出生先后（最老的动物）；按条件方差迹减少量 ‖S_:k‖²/S_kk 贪心选择。
另给出 G 的特征值累计解释 90%、95%、98%、99% 所需的方向数，作为核心规模参考。
独立核验：(1) 公式 G_APY⁻¹ 与直接构造 G_APY 后求逆一致；
          (2) 只有一个非核心动物时 APY 精确（G_APY = G）。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.linalg import cho_factor, cho_solve

HERE = Path(__file__).resolve().parent


def simulate_population(cfg, rng):
    nf, ngen, noff = cfg["founders"], cfg["generations"], cfg["offspring_per_gen"]
    sire = [-1] * nf; dam = [-1] * nf; gen = [0] * nf
    males = list(range(0, nf, 2)); females = list(range(1, nf, 2))
    for g in range(1, ngen + 1):
        sires = rng.choice(males, cfg["sires_per_gen"], replace=False)
        dams = rng.choice(females, min(cfg["dams_per_gen"], len(females)), replace=False)
        new_m, new_f = [], []
        for _ in range(noff):
            i = len(sire); sire.append(int(rng.choice(sires))); dam.append(int(rng.choice(dams))); gen.append(g)
            (new_m if rng.random() < 0.5 else new_f).append(i)
        males, females = new_m, new_f
    n = len(sire); m_chr, n_chr = cfg["loci_per_chr"], cfg["n_chr"]
    pos = np.sort(rng.uniform(0, 1, (n_chr, m_chr)), axis=1)
    p0 = rng.uniform(0.05, 0.95, n_chr * m_chr)
    hap = np.zeros((n, 2, p0.size), dtype=np.int8)
    for i in range(nf):
        hap[i] = (rng.random((2, p0.size)) < p0).astype(np.int8)
    for i in range(nf, n):
        for k, par in enumerate((sire[i], dam[i])):
            for c in range(n_chr):
                sl = slice(c * m_chr, (c + 1) * m_chr)
                cuts = np.sort(rng.uniform(0, 1, rng.poisson(1.0)))
                strand = (int(rng.integers(2)) + np.searchsorted(cuts, pos[c])) % 2
                hap[i, k, sl] = np.where(strand == 0, hap[par, 0, sl], hap[par, 1, sl])
    return np.array(sire), np.array(dam), np.array(gen), hap, p0


def tabular_A(sire, dam):
    n = sire.size; A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]; row = np.zeros(i)
        if s >= 0: row += 0.5 * A[s, :i]
        if d >= 0: row += 0.5 * A[d, :i]
        A[i, :i] = row; A[:i, i] = row
        A[i, i] = 1.0 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0.0)
    return A


def apy_inverse(G: np.ndarray, core: np.ndarray):
    """返回按原动物顺序排列的 G_APY⁻¹、G_APY、条件协方差 S 与非核心索引。"""
    n = G.shape[0]; non = np.setdiff1d(np.arange(n), core)
    Gcc = G[np.ix_(core, core)]; Gnc = G[np.ix_(non, core)]
    cf = cho_factor(Gcc)
    T = cho_solve(cf, Gnc.T).T
    S = G[np.ix_(non, non)] - T @ Gnc.T
    d = np.diag(S).copy()
    assert np.all(d > 0), "非核心条件方差必须为正"
    Gcc_inv = cho_solve(cf, np.eye(core.size))
    Ginv = np.zeros_like(G)
    Ginv[np.ix_(core, core)] = Gcc_inv + T.T @ (T / d[:, None])
    Ginv[np.ix_(core, non)] = -(T / d[:, None]).T
    Ginv[np.ix_(non, core)] = -(T / d[:, None])
    Ginv[np.ix_(non, non)] = np.diag(1 / d)
    Gapy = G.copy(); Gapy[np.ix_(non, non)] = T @ Gcc @ T.T + np.diag(d)
    return Ginv, Gapy, S, non


def greedy_trace_core(G: np.ndarray, k: int) -> np.ndarray:
    S = G.copy(); chosen = []
    for _ in range(k):
        dg = np.diag(S).copy(); dg[chosen] = np.inf
        gain = np.einsum("ij,ij->j", S, S) / dg
        gain[chosen] = -np.inf
        j = int(np.argmax(gain)); chosen.append(j)
        S -= np.outer(S[:, j], S[j, :]) / S[j, j]
    return np.array(sorted(chosen))


def gblup(G_inv, rec, y, lam, n):
    """y = μ + u + e；返回所有分型动物的 û。"""
    X = np.ones((rec.size, 1)); Z = np.zeros((rec.size, n)); Z[np.arange(rec.size), rec] = 1
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * G_inv]])
    sol = cho_solve(cho_factor(C), np.concatenate([X.T @ y, Z.T @ y]))
    return sol[1:]


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex28_17_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    sire, dam, gen, hap, p0 = simulate_population(cfg, rng)
    nl = p0.size; qtl = np.sort(rng.choice(nl, cfg["n_qtl"], replace=False)); mk = np.setdiff1d(np.arange(nl), qtl)
    geno_all = hap.sum(axis=1).astype(float)
    a = rng.normal(0, 1, qtl.size); a *= np.sqrt(cfg["var_a"] / np.sum(2 * p0[qtl] * (1 - p0[qtl]) * a ** 2))
    u_all = (geno_all[:, qtl] - 2 * p0[qtl]) @ a
    gidx = np.sort(rng.choice(np.where(gen >= 1)[0], cfg["n_genotyped"], replace=False))
    A22 = tabular_A(sire, dam)[np.ix_(gidx, gidx)]
    M = geno_all[np.ix_(gidx, mk)]; p = M.mean(0) / 2; keep = (p > 0.01) & (p < 0.99)
    Zc = M[:, keep] - 2 * p[keep]; G0 = Zc @ Zc.T / (2 * np.sum(p[keep] * (1 - p[keep])))
    G = (1 - cfg["blend_w"]) * G0 + cfg["blend_w"] * A22
    n = G.shape[0]; ggen = gen[gidx]; u = u_all[gidx]
    cand = np.where(ggen == cfg["generations"])[0]; rec = np.where(ggen < cfg["generations"])[0]
    var_e = cfg["var_a"] * (1 - cfg["h2"]) / cfg["h2"]; lam = var_e / cfg["var_a"]
    y = 50 + u[rec] + rng.normal(0, np.sqrt(var_e), rec.size)

    # 核验
    core_t = np.sort(rng.choice(n, 60, replace=False))
    Ginv_t, Gapy_t, _, _ = apy_inverse(G, core_t)
    err_formula = float(np.max(np.abs(Ginv_t - np.linalg.inv(Gapy_t))) / np.max(np.abs(Ginv_t)))
    assert err_formula < 1e-8, err_formula
    _, Gapy1, _, _ = apy_inverse(G, np.arange(n - 1))
    assert np.allclose(Gapy1, G, atol=1e-10), "单个非核心动物时 APY 应精确"

    ev = np.sort(np.linalg.eigvalsh(G))[::-1]; cum = np.cumsum(ev) / ev.sum()
    n_eig = {str(q): int(np.searchsorted(cum, q) + 1) for q in (0.90, 0.95, 0.98, 0.99)}
    u_exact = gblup(np.linalg.inv(G), rec, y, lam, n)
    acc_exact = float(np.corrcoef(u[cand], u_exact[cand])[0, 1])
    sd_ex = float(np.std(u_exact[cand])); ktop = max(1, int(0.1 * cand.size))
    top_exact = set(cand[np.argsort(-u_exact[cand])[:ktop]])

    order_old = np.argsort(ggen, kind="stable")
    rows = []
    print(f"分型动物 {n} 头（候选 {cand.size} 头无表型）；精确 GBLUP 候选准确性 {acc_exact:.3f}")
    print("G 特征值累计解释比例所需方向数：" + "，".join(f"{k}: {v}" for k, v in n_eig.items()))
    print(f"{'核心定义':<8s}{'规模':>5s}{'KL':>9s}{'max|ΔG|':>9s}{'相关':>8s}{'斜率':>7s}{'max|Δû|/sd':>11s}{'前10%重合':>9s}{'准确性':>8s}")
    for size in cfg["core_sizes"]:
        cores = {"随机": np.sort(rng.choice(n, size, replace=False)),
                 "最老": np.sort(order_old[:size]),
                 "迹贪心": greedy_trace_core(G, size)}
        for name, core in cores.items():
            Ginv, Gapy, S, non = apy_inverse(G, core)
            dS = np.sqrt(np.diag(S)); Cc = S / np.outer(dS, dS)
            sign, logdet = np.linalg.slogdet(Cc); assert sign > 0
            kl = float(-0.5 * logdet)
            ua = gblup(Ginv, rec, y, lam, n)
            r = float(np.corrcoef(u_exact[cand], ua[cand])[0, 1])
            slope = float(np.cov(u_exact[cand], ua[cand])[0, 1] / np.var(ua[cand], ddof=1))
            mx = float(np.max(np.abs(ua[cand] - u_exact[cand])) / sd_ex)
            top = set(cand[np.argsort(-ua[cand])[:ktop]]); ov = len(top & top_exact) / ktop
            acc = float(np.corrcoef(u[cand], ua[cand])[0, 1])
            row = {"core": name, "size": size, "KL": kl, "max_abs_dG": float(np.max(np.abs(Gapy - G))),
                   "corr_exact": r, "slope_exact_on_apy": slope, "maxdiff_sd": mx, "top10_overlap": ov, "acc_tbv": acc}
            rows.append(row)
            print(f"{name:<8s}{size:5d}{kl:9.2f}{row['max_abs_dG']:9.4f}{r:8.4f}{slope:7.3f}{mx:11.3f}{ov:9.2f}{acc:8.3f}")
    res = {"n_genotyped": n, "n_candidates": int(cand.size), "acc_exact": acc_exact, "n_eig": n_eig,
           "formula_rel_err": err_formula, "rows": rows}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex28_17_apy_core.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    from _plot import get_pyplot
    plt = get_pyplot()
    if plt is not None:
        fig, ax = plt.subplots(1, 2, figsize=(9, 3.6))
        for name, mk_ in (("随机", "o-"), ("最老", "s-"), ("迹贪心", "^-")):
            rr = [r_ for r_ in rows if r_["core"] == name]
            ax[0].plot([r_["size"] for r_ in rr], [r_["KL"] for r_ in rr], mk_, label=name)
            ax[1].plot([r_["size"] for r_ in rr], [1 - r_["corr_exact"] for r_ in rr], mk_, label=name)
        ax[0].set_xlabel("核心规模"); ax[0].set_ylabel("KL = −½log|C|")
        ax[1].set_xlabel("核心规模"); ax[1].set_ylabel("1 − corr(精确, APY)"); ax[1].set_yscale("log")
        ax[0].legend(); fig.tight_layout(); fig.savefig(HERE / "results" / "ex28_17_apy_core.png"); plt.close(fig)


if __name__ == "__main__":
    main()
