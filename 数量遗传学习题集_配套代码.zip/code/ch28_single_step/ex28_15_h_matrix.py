#!/usr/bin/env python3
"""习题 28.15  单步关系矩阵 H：条件构造、逆矩阵公式、G 的尺度调整与常见实现错误

模型：把动物分为未分型组 1 与已分型组 2，系谱关系 A 分块为 A11, A12, A22。
    条件回归  B = A12 A22⁻¹，条件方差 S1 = A11 − A12 A22⁻¹ A21；
    把 u2 的边际协方差换成相容的基因组矩阵 Gw，得
        H = [[S1 + B Gw Bᵀ, B Gw], [Gw Bᵀ, Gw]]，
        H⁻¹ = A⁻¹ + [[0, 0], [0, Gw⁻¹ − A22⁻¹]]。
G 的构造：VanRaden 第一法 G = ZZᵀ/(2Σp(1−p))；按 Christensen 等（2012）的思路
    G* = βG + α，使 G* 的平均对角元与全体平均元素分别等于 A22 的对应量；
    Gw = (1 − w)G* + wA22（w = 0.05），保证正定并保留少量系谱方向。
程序用基因下落模拟一个 5 世代群体，验证：
    (1) 两条路线得到的 H⁻¹ 完全一致；(2) Gw = A22 时 H 退化为 A；
    (3) A22⁻¹ ≠ (A⁻¹)22，二者之差等于舒尔补修正 F21 F11⁻¹ F12；
    (4) 只替换右下角而不更新其余分块的“拼接矩阵”与条件模型的差别。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


# ---------------------------------------------------------------- 模拟
def simulate_population(cfg: dict, rng: np.random.Generator):
    """随机交配闭锁群体 + 基因下落；返回系谱 (sire, dam)、世代、单倍型。"""
    nf, ngen, noff = cfg["founders"], cfg["generations"], cfg["offspring_per_gen"]
    sire = [-1] * nf; dam = [-1] * nf; gen = [0] * nf
    sex = np.array([i % 2 for i in range(nf)])            # 0 公 1 母
    males = [i for i in range(nf) if sex[i] == 0]; females = [i for i in range(nf) if sex[i] == 1]
    for g in range(1, ngen + 1):
        sires = rng.choice(males, cfg["sires_per_gen"], replace=False)
        dams = rng.choice(females, min(cfg["dams_per_gen"], len(females)), replace=False)
        new_m, new_f = [], []
        for _ in range(noff):
            i = len(sire); sire.append(int(rng.choice(sires))); dam.append(int(rng.choice(dams))); gen.append(g)
            s = int(rng.integers(2)); sex = np.append(sex, s)
            (new_m if s == 0 else new_f).append(i)
        males, females = new_m, new_f
    n = len(sire)
    # 基因组：n_chr 条染色体，每条长 1 M，位点位置均匀
    m_chr, n_chr = cfg["loci_per_chr"], cfg["n_chr"]
    pos = np.sort(rng.uniform(0, 1, (n_chr, m_chr)), axis=1)
    p0 = rng.uniform(0.05, 0.95, n_chr * m_chr)
    hap = np.zeros((n, 2, n_chr * m_chr), dtype=np.int8)
    for i in range(nf):
        hap[i] = (rng.random((2, p0.size)) < p0).astype(np.int8)
    for i in range(nf, n):
        for k, par in enumerate((sire[i], dam[i])):
            for c in range(n_chr):
                sl = slice(c * m_chr, (c + 1) * m_chr)
                cuts = np.sort(rng.uniform(0, 1, rng.poisson(1.0)))
                strand = (int(rng.integers(2)) + np.searchsorted(cuts, pos[c])) % 2
                hap[i, k, sl] = np.where(strand == 0, hap[par, 0, sl], hap[par, 1, sl])
    return np.array(sire), np.array(dam), np.array(gen), hap


# ---------------------------------------------------------------- 关系矩阵
def tabular_A(sire: np.ndarray, dam: np.ndarray) -> np.ndarray:
    n = sire.size; A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        row = np.zeros(i)
        if s >= 0: row += 0.5 * A[s, :i]
        if d >= 0: row += 0.5 * A[d, :i]
        A[i, :i] = row; A[:i, i] = row
        A[i, i] = 1.0 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0.0)
    return A


def henderson_Ainv(sire: np.ndarray, dam: np.ndarray, F: np.ndarray) -> np.ndarray:
    n = sire.size; Ai = np.zeros((n, n))
    for i in range(n):
        par = [p for p in (sire[i], dam[i]) if p >= 0]
        b = 1.0 - 0.25 * len(par) - 0.25 * sum(F[p] for p in par)   # 1, 3/4 − F/4, 1/2 − (Fs+Fd)/4
        w = np.zeros(n); w[i] = 1.0
        for p in par: w[p] -= 0.5
        idx = [i] + par
        Ai[np.ix_(idx, idx)] += np.outer(w[idx], w[idx]) / b
    return Ai


def vanraden_G(M: np.ndarray):
    p = M.mean(axis=0) / 2
    keep = (p > 0.01) & (p < 0.99)
    Z = M[:, keep] - 2 * p[keep]
    return Z @ Z.T / (2 * np.sum(p[keep] * (1 - p[keep]))), int(keep.sum())


def tune_to_A22(G: np.ndarray, A22: np.ndarray):
    """求 α, β 使 mean(diag(βG+α)) = mean(diag A22)，mean(βG+α) = mean(A22)。"""
    M = np.array([[np.mean(np.diag(G)), 1.0], [np.mean(G), 1.0]])
    beta, alpha = np.linalg.solve(M, np.array([np.mean(np.diag(A22)), np.mean(A22)]))
    return beta * G + alpha, float(alpha), float(beta)


def conditional_H(A: np.ndarray, g2: np.ndarray, Gw: np.ndarray) -> np.ndarray:
    n = A.shape[0]; g1 = np.setdiff1d(np.arange(n), g2)
    A11, A12, A22 = A[np.ix_(g1, g1)], A[np.ix_(g1, g2)], A[np.ix_(g2, g2)]
    B = np.linalg.solve(A22, A12.T).T                     # A12 A22⁻¹（A22 对称）
    S1 = A11 - B @ A12.T
    H = np.empty_like(A)
    H[np.ix_(g1, g1)] = S1 + B @ Gw @ B.T
    H[np.ix_(g1, g2)] = B @ Gw; H[np.ix_(g2, g1)] = (B @ Gw).T
    H[np.ix_(g2, g2)] = Gw
    return H


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex28_15_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    sire, dam, gen, hap = simulate_population(cfg, rng)
    n = sire.size
    A = tabular_A(sire, dam); F = np.diag(A) - 1
    Ainv = henderson_Ainv(sire, dam, F)
    assert np.allclose(A @ Ainv, np.eye(n), atol=1e-8), "Henderson A⁻¹ 与表格法 A 不互逆"

    cand = np.where(gen >= cfg["genotype_from_gen"])[0]
    g2 = np.sort(rng.choice(cand, cfg["n_genotyped"], replace=False)); g1 = np.setdiff1d(np.arange(n), g2)
    M = hap[g2].sum(axis=1).astype(float)
    G, n_snp = vanraden_G(M)
    A22 = A[np.ix_(g2, g2)]
    Gt, alpha, beta = tune_to_A22(G, A22)
    w = cfg["blend_w"]; Gw = (1 - w) * Gt + w * A22

    # (1) 条件构造与逆公式
    H = conditional_H(A, g2, Gw)
    A22inv = np.linalg.inv(A22)
    Hinv = Ainv.copy(); Hinv[np.ix_(g2, g2)] += np.linalg.inv(Gw) - A22inv
    err_inv = float(np.max(np.abs(H @ Hinv - np.eye(n))))
    assert err_inv < 1e-7, err_inv
    # (2) Gw = A22 ⇒ H = A
    assert np.allclose(conditional_H(A, g2, A22), A, atol=1e-10)
    # (3) A22⁻¹ 与 (A⁻¹)22：舒尔补
    F11, F12, F22 = Ainv[np.ix_(g1, g1)], Ainv[np.ix_(g1, g2)], Ainv[np.ix_(g2, g2)]
    schur = F22 - F12.T @ np.linalg.solve(F11, F12)
    assert np.allclose(schur, A22inv, atol=1e-8), "舒尔补恒等式不成立"
    diff_sub = float(np.max(np.abs(F22 - A22inv)))
    # (4) 只替换右下角的拼接矩阵
    Hnaive = A.copy(); Hnaive[np.ix_(g2, g2)] = Gw
    eig_naive = float(np.linalg.eigvalsh(Hnaive)[0]); eig_H = float(np.linalg.eigvalsh(H)[0])
    eig_corr = float(np.linalg.eigvalsh(np.linalg.inv(Gw) - A22inv)[0])

    off = ~np.eye(len(g2), dtype=bool)
    slope_off = float(np.polyfit(A22[off], G[off], 1)[0])
    dH11 = np.diag(H)[g1] - np.diag(A)[g1]
    lin = H[np.ix_(g1, g2)] - A[np.ix_(g1, g2)]
    res = {
        "n_animals": int(n), "n_genotyped": int(g2.size), "n_snp_used": n_snp,
        "mean_F_all": float(F.mean()), "mean_F_genotyped": float(F[g2].mean()),
        "G_raw": {"mean_diag": float(np.mean(np.diag(G))), "mean_offdiag": float(G[off].mean())},
        "A22": {"mean_diag": float(np.mean(np.diag(A22))), "mean_offdiag": float(A22[off].mean())},
        "tuning": {"alpha": alpha, "beta": beta,
                   "Gt_mean_diag": float(np.mean(np.diag(Gt))), "Gt_mean_all": float(Gt.mean())},
        "slope_Goff_on_A22off": slope_off,
        "max_abs_HHinv_minus_I": err_inv,
        "max_abs_Ainv22_minus_A22inv": diff_sub,
        "min_eig_H": eig_H, "min_eig_naive_splice": eig_naive, "min_eig_Gwinv_minus_A22inv": eig_corr,
        "ungenotyped_diag_change": {"mean": float(dH11.mean()), "min": float(dH11.min()), "max": float(dH11.max())},
        "cross_block_change_max_abs": float(np.max(np.abs(lin))),
        "frac_ungenotyped_rows_changed": float(np.mean(np.max(np.abs(H[np.ix_(g1, g1)] - A[np.ix_(g1, g1)]), axis=1) > 1e-6)),
        "naive_vs_H_max_abs": float(np.max(np.abs(Hnaive - H))),
    }
    print(f"动物 {n} 头，分型 {g2.size} 头，使用 SNP {n_snp} 个；平均近交 {F.mean():.4f}（分型动物 {F[g2].mean():.4f}）")
    print(f"原始 G：对角均值 {res['G_raw']['mean_diag']:.4f}，非对角均值 {res['G_raw']['mean_offdiag']:.4f}")
    print(f"A22  ：对角均值 {res['A22']['mean_diag']:.4f}，非对角均值 {res['A22']['mean_offdiag']:.4f}")
    print(f"调整 G* = βG + α：β = {beta:.4f}，α = {alpha:.4f}；G 非对角对 A22 非对角回归斜率 {slope_off:.3f}")
    print(f"max|H·H⁻¹ − I| = {err_inv:.2e}；max|(A⁻¹)22 − A22⁻¹| = {diff_sub:.4f}（舒尔补核验通过）")
    print(f"最小特征值：H {eig_H:.4f}，只换右下角的拼接矩阵 {eig_naive:.4f}，修正块 Gw⁻¹ − A22⁻¹ {eig_corr:.4f}")
    print(f"未分型动物对角元变化：均值 {dH11.mean():+.4f}，范围 [{dH11.min():+.4f}, {dH11.max():+.4f}]；"
          f"{100*res['frac_ungenotyped_rows_changed']:.1f}% 的未分型动物关系被更新")
    print(f"拼接矩阵与正确 H 的最大绝对差 {res['naive_vs_H_max_abs']:.4f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex28_15_h_matrix.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
