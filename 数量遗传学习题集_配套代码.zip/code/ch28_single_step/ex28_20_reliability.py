#!/usr/bin/env python3
"""习题 28.20  单步评定的可靠度：个体、差值与群体对比，以及随机化对角估计

模型：单步 GBLUP 混合模型方程 Lθ = d（沿用习题 28.18 的系统），L⁻¹ 的动物块为 Cᵘᵘ。
    PEV(cᵀû) = cᵀCᵘᵘc·σ_e²，先验方差 Var(cᵀu) = cᵀHc·σ_a²（H = (H⁻¹)⁻¹），
    可靠度 R(c) = 1 − PEV/Var = 1 − λ·cᵀCᵘᵘc / cᵀHc。
(1) 个体可靠度（对角元）；(2) 候选两个半同胞组平均值的差：先验方差、PEV 与可靠度，
    并与“两组个体可靠度的平均”比较；(3) 随机两头候选差值：包含与忽略误差协方差的差别；
(4) Hutchinson 型随机化对角估计：diag(C) ≈ (1/K)Σ z_k∘(C z_k)，z 为 ±1 向量，
    每个探针只需解一次方程组；理论标准误 √(Σ_{j≠i}C_ij²/K)，程序核验经验误差与之相符，
    并用预条件共轭梯度（容差 1e-8）核验与精确分解的一致性。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.linalg import cho_factor, cho_solve

from ex28_18_pcg_solver import build_system, mme, pcg

HERE = Path(__file__).resolve().parent


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex28_20_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    S = build_system(cfg, rng)
    full = np.ones(S["rec"].size, bool)
    L, d = mme(S, full); nf = S["nf"]; dim = d.size; lam = S["lam"]; va = cfg["var_a"]
    cf = cho_factor(L)
    C = cho_solve(cf, np.eye(dim)); Cuu = C[nf:, nf:]
    H = np.linalg.inv(S["Hinv"])
    cand = S["cand"]
    assert np.allclose(L @ C, np.eye(dim), atol=1e-8)
    # (1) 个体可靠度
    Ri = 1 - lam * np.diag(Cuu)[cand] / np.diag(H)[cand]
    print(f"方程维数 {dim}；候选 {cand.size} 头；λ = σe²/σa² = {lam:.3f}")
    print(f"候选个体可靠度：均值 {Ri.mean():.3f}，范围 [{Ri.min():.3f}, {Ri.max():.3f}]")
    # (2) 两个半同胞组
    cand_sire = None
    sire_of = {}
    # 以候选在 H⁻¹ 中的最近父本代理：用候选间 H 相关最高的聚类难以复现，直接用模拟中的父本需重新生成，
    # 这里改用“对基因组关系的两个主成分符号”划分，得到遗传上差异较大的两组
    Hc = H[np.ix_(cand, cand)]
    w, V = np.linalg.eigh(Hc); pc = V[:, -2]
    grpA = cand[pc > np.quantile(pc, 0.7)]; grpB = cand[pc < np.quantile(pc, 0.3)]
    def contrast(ga, gb):
        c = np.zeros(dim - nf); c[ga] = 1 / ga.size; c[gb] -= 1 / gb.size
        return c
    c = contrast(grpA, grpB)
    prior = c @ H @ c * va
    pev = lam * (c @ Cuu @ c) * va            # σe² = λσa²，Cᵘᵘ 以 σe² 标准化
    pev = float(c @ Cuu @ c * lam * va)
    Rc = 1 - pev / prior
    print(f"\n两组各 {grpA.size}、{grpB.size} 头（按 H 的第二主成分两端划分）")
    print(f"组平均差：先验方差 {prior:.3f}，PEV {pev:.3f}，可靠度 {Rc:.3f}；两组个体可靠度均值 {Ri[np.isin(cand,np.r_[grpA,grpB])].mean():.3f}")
    # 把组平均看成“个体”：只用对角元
    diag_only = (c ** 2) @ np.diag(Cuu) * lam * va
    print(f"若忽略误差协方差，只用对角元的 PEV = {diag_only:.3f}（偏差 {100*(diag_only/pev-1):+.1f}%）")
    # (3) 随机候选对
    pairs = rng.choice(cand, (200, 2))
    pairs = pairs[pairs[:, 0] != pairs[:, 1]]
    pv_exact, pv_diag, pr_prior, Rp = [], [], [], []
    for i, j in pairs:
        e = np.zeros(dim - nf); e[i] = 1; e[j] = -1
        pv = lam * va * (e @ Cuu @ e); pvd = lam * va * (Cuu[i, i] + Cuu[j, j])
        pr = va * (e @ H @ e)
        pv_exact.append(pv); pv_diag.append(pvd); pr_prior.append(pr); Rp.append(1 - pv / pr)
    pv_exact, pv_diag, Rp = map(np.array, (pv_exact, pv_diag, Rp))
    print(f"\n随机候选对 {pv_exact.size} 对：差值可靠度均值 {Rp.mean():.3f}，范围 [{Rp.min():.3f}, {Rp.max():.3f}]")
    print(f"忽略误差协方差的 PEV 相对偏差：均值 {100*np.mean(pv_diag/pv_exact-1):+.1f}%，最大 {100*np.max(pv_diag/pv_exact-1):+.1f}%")
    # (4) Hutchinson 对角估计
    diag_true = np.diag(Cuu)[cand]
    off2 = (Cuu[np.ix_(cand, np.arange(dim - nf))] ** 2).sum(1) - diag_true ** 2
    # 对 Cθθ 的全向量探针：z 取动物块 ±1，固定效应块 0 即只探测动物块；Cz 的动物块用于估计动物块对角元
    rows = []
    print(f"\n{'探针数K':>8s}{'经验RMSE':>11s}{'理论RMSE':>11s}{'平均相对误差':>13s}{'与真值相关':>11s}{'可靠度最大偏差':>14s}")
    for K in cfg["probe_counts"]:
        errs = []
        for _ in range(cfg["probe_reps"]):
            Z = rng.choice([-1.0, 1.0], size=(dim, K)); Z[:nf] = 0.0
            Y = cho_solve(cf, Z)
            est = (Z[nf:] * Y[nf:]).mean(axis=1)[cand]
            errs.append(est - diag_true)
        errs = np.array(errs)
        rmse = float(np.sqrt((errs ** 2).mean())); th = float(np.sqrt((off2 / K).mean()))
        est_mean = diag_true + errs.mean(0)
        relerr = float(np.mean(np.abs(errs)) / diag_true.mean())
        corr = float(np.corrcoef(est, diag_true)[0, 1])
        Rhat = 1 - lam * est / np.diag(H)[cand]
        rbias = float(np.max(np.abs(Rhat - Ri)))
        rows.append({"K": K, "rmse": rmse, "theory_rmse": th, "rel_err": relerr, "corr": corr, "max_R_dev": rbias})
        print(f"{K:8d}{rmse:11.4f}{th:11.4f}{relerr:13.3f}{corr:11.3f}{rbias:14.3f}")
        assert 0.8 < rmse / th < 1.25
        assert abs(errs.mean()) < 0.1 * rmse + 0.02       # 无偏
    assert rows[-1]["rmse"] < rows[0]["rmse"] / 4
    # PCG 与精确分解一致
    Z = rng.choice([-1.0, 1.0], size=dim); Z[:nf] = 0.0
    diagL = np.diag(L).copy(); x, k = pcg(L, Z, lambda r: r / diagL, cfg["tol"])
    err = np.max(np.abs(x - cho_solve(cf, Z)))
    print(f"\nPCG（容差 {cfg['tol']:.0e}，{k} 次迭代）与 Cholesky 解的最大差 {err:.2e}")
    assert err < 1e-5
    out = {"R_ind_mean": float(Ri.mean()), "R_contrast": float(Rc), "pev_contrast": pev, "prior_contrast": float(prior),
           "diag_only_pev": float(diag_only), "pairs_R_mean": float(Rp.mean()), "pairs_diag_bias_mean_pct": float(100 * np.mean(pv_diag / pv_exact - 1)),
           "hutchinson": rows, "pcg_iters": k, "pcg_err": float(err)}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex28_20_reliability.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
