#!/usr/bin/env python3
"""习题 28.19  元基础群体 Γ：定义、合法性、A_Γ 的构造与基因下落蒙特卡罗核验

模型：两个基础群体 A、B 的等位基因频率向量分别为 p_A、p_B（m 个位点）。以所有位点频率 0.5
的概念群体为参照，行向量 w_b = 2p_b − 1，元基础群体关系矩阵
    Γ_{bb'} = (2/m) Σ_k w_{bk} w_{b'k}，
自关系 Γ_bb 即同一基础群体中两个不同个体的期望关系，对参考等位基因的同步翻转不变。
未知亲本以元基础群体 b 代替；把 b 视为系谱中的“虚拟个体”，其与自身的关系为 Γ_bb，则
    A_Γ(i,j) = ½[A_Γ(j,s_i) + A_Γ(j,d_i)]，A_Γ(i,i) = 1 + ½A_Γ(s_i,d_i)。
等价地 A_Γ⁻¹ = (I−P)ᵀ D⁻¹ (I−P) 的元基础群体块为 Γ⁻¹ 的修正（本程序以显式矩阵验证）。
程序完成：(1) Γ 的计算与特征值；(2) 翻转不变性；(3) 非法 Γ（逐元素在 [−1,1] 内但非半正定）的识别；
(4) 8 头动物系谱的 A_Γ，与“Γ=0 的无关基础群体”A 对比；(5) 基因下落蒙特卡罗：用 m 个位点的
中心化 (x−1) 交叉乘积 (2/m)(x−1)(x−1)ᵀ 的平均核验 A_Γ；(6) 逆矩阵的稀疏恒等式。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def make_gamma(pA: np.ndarray, pB: np.ndarray) -> np.ndarray:
    W = np.vstack([2 * pA - 1, 2 * pB - 1])
    return 2.0 / W.shape[1] * W @ W.T


def a_gamma(sire, dam, mf_s, mf_d, Gam):
    """sire/dam 为 0 基索引（-1 表示未知，改用元基础群体 mf_*，取值 0..nb-1）。
    返回含元基础群体的 (nb+n) 阶矩阵，前 nb 行列为元基础群体。"""
    nb, n = Gam.shape[0], len(sire)
    N = nb + n
    A = np.zeros((N, N)); A[:nb, :nb] = Gam
    for i in range(n):
        r = nb + i
        s = nb + sire[i] if sire[i] >= 0 else mf_s[i]
        d = nb + dam[i] if dam[i] >= 0 else mf_d[i]
        row = 0.5 * (A[s, :r] + A[d, :r])
        A[r, :r] = row; A[:r, r] = row
        A[r, r] = 1.0 + 0.5 * A[s, d]
    return A


def ainv_gamma(sire, dam, mf_s, mf_d, Gam):
    """用 (I−P) 与对角 D 显式构造 A_Γ 的逆（对动物＋元基础群体）。"""
    nb, n = Gam.shape[0], len(sire); N = nb + n
    IP = np.eye(N); D = np.zeros(N)
    for i in range(n):
        r = nb + i
        s = nb + sire[i] if sire[i] >= 0 else mf_s[i]
        d = nb + dam[i] if dam[i] >= 0 else mf_d[i]
        IP[r, s] -= 0.5; IP[r, d] -= 0.5
    Ag = a_gamma(sire, dam, mf_s, mf_d, Gam)
    # Mendelian sampling variance b_i = 1 - 0.25(A_ss + A_dd) 在 A_Γ 尺度下
    for i in range(n):
        r = nb + i
        s = nb + sire[i] if sire[i] >= 0 else mf_s[i]
        d = nb + dam[i] if dam[i] >= 0 else mf_d[i]
        D[r] = Ag[r, r] - 0.25 * (Ag[s, s] + Ag[d, d] + 2 * Ag[s, d])
    D[:nb] = 1.0
    Dinv = np.diag(1.0 / D)
    # 元基础群体块单独以 Γ⁻¹ 表示
    Dinv[:nb, :nb] = np.linalg.inv(Gam)
    return IP.T @ Dinv @ IP, D


def gene_drop(rng, sire, dam, mf_s, mf_d, p_by_pop):
    """沿系谱基因下落一次，返回 n×m 基因型（0/1/2）。创始者按所属元基础群体的频率抽单倍型。"""
    n = len(sire); m = p_by_pop.shape[1]
    hap = np.zeros((n, 2, m), dtype=np.int8)
    for i in range(n):
        for k, (par, mf) in enumerate(((sire[i], mf_s[i]), (dam[i], mf_d[i]))):
            if par < 0:
                hap[i, k] = (rng.random(m) < p_by_pop[mf]).astype(np.int8)
            else:
                pick = rng.integers(0, 2, m)
                hap[i, k] = np.where(pick == 0, hap[par, 0], hap[par, 1])
    return hap.sum(axis=1).astype(float)


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex28_19_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); m = cfg["m_loci"]
    pA = rng.beta(cfg["freq_beta"]["a"], cfg["freq_beta"]["b"], m)
    pB = np.clip(pA + rng.normal(0, cfg["freq_shift_B"], m), 0.02, 0.98)
    Gam = make_gamma(pA, pB)
    ev = np.linalg.eigvalsh(Gam)
    print(f"位点数 {m}；Γ = [[{Gam[0,0]:.4f}, {Gam[0,1]:.4f}], [{Gam[1,0]:.4f}, {Gam[1,1]:.4f}]]")
    print(f"Γ 特征值 {ev[0]:.4f}, {ev[1]:.4f}（半正定）；Γ_AB² ≤ Γ_AA·Γ_BB：{Gam[0,1]**2:.4f} ≤ {Gam[0,0]*Gam[1,1]:.4f}")
    assert ev[0] > -1e-12 and Gam[0, 1] ** 2 <= Gam[0, 0] * Gam[1, 1]
    # 参考等位基因翻转不变
    flip = rng.random(m) < 0.5
    pA2, pB2 = np.where(flip, 1 - pA, pA), np.where(flip, 1 - pB, pB)
    assert np.allclose(make_gamma(pA2, pB2), Gam, atol=1e-12)
    print("随机翻转一半位点的参考等位基因后 Γ 不变（最大差 %.1e）" % np.max(np.abs(make_gamma(pA2, pB2) - Gam)))
    # 教学例（本章两位点）
    G2 = make_gamma(np.array([0.2, 0.7]), np.array([0.3, 0.8]))
    print("教学例 Γ =", np.round(G2, 4).tolist(), " 特征值", np.round(np.linalg.eigvalsh(G2), 4).tolist())
    # 非法矩阵
    bad = np.array(cfg["invalid_gamma"]); evb = np.linalg.eigvalsh(bad)
    print(f"非法 Γ（元素均在 [−1,1]）特征值 {np.round(evb,3).tolist()}；最小特征值 < 0，不是协方差矩阵")
    assert evb[0] < 0 and np.all(np.abs(bad) <= 1)

    ped = cfg["pedigree"]
    sire = np.array(ped["sire"]) - 1; dam = np.array(ped["dam"]) - 1   # 0 → -1
    mf_s = np.array(ped["mf_sire"]) - 1; mf_d = np.array(ped["mf_dam"]) - 1
    # 前 3 头为基础动物（来自 A、A、B），1,2→A(0)，3→B(1)
    mf_s = np.where(mf_s >= 0, mf_s, 0); mf_d = np.where(mf_d >= 0, mf_d, 0)
    sire = np.where(sire >= 0, sire, -1); dam = np.where(dam >= 0, dam, -1)
    A = a_gamma(sire, dam, mf_s, mf_d, Gam); nb = 2
    Aan = A[nb:, nb:]
    A0 = a_gamma(sire, dam, mf_s, mf_d, np.zeros((2, 2)))[nb:, nb:]       # Γ=0：传统无关基础群体
    print("\nA_Γ（动物）对角：", np.round(np.diag(Aan), 3).tolist())
    print("传统 A 对角：    ", np.round(np.diag(A0), 3).tolist())
    print("A_Γ − A 的最小/最大元素：%.3f / %.3f" % ((Aan - A0).min(), (Aan - A0).max()))
    # 逆矩阵核验
    Ai, D = ainv_gamma(sire, dam, mf_s, mf_d, Gam)
    err = np.max(np.abs(Ai @ A - np.eye(A.shape[0])))
    print(f"A_Γ⁻¹ A_Γ = I 的最大偏差 {err:.2e}；孟德尔抽样方差 D(动物) = {np.round(D[nb:],3).tolist()}")
    assert err < 1e-9
    nz = int(np.sum(np.abs(Ai) > 1e-12)); print(f"逆矩阵非零元 {nz}/{Ai.size}（含元基础群体行列）")

    # 蒙特卡罗：用 (2/m)(x−1)(x−1)ᵀ 的平均核验
    n = len(sire); acc = np.zeros((n, n)); p_by = np.vstack([pA, pB])
    reps = cfg["mc_reps"]
    for _ in range(reps):
        x = gene_drop(rng, sire, dam, mf_s, mf_d, p_by)
        z = x - 1.0
        acc += 2.0 / m * z @ z.T
    acc /= reps
    dev = acc - Aan
    print(f"\n基因下落 {reps} 次 × {m} 位点：蒙特卡罗均值与 A_Γ 的最大绝对差 {np.max(np.abs(dev)):.4f}，平均绝对差 {np.mean(np.abs(dev)):.4f}")
    print(f"对传统 A（Γ=0）的最大绝对差 {np.max(np.abs(acc - A0)):.4f}")
    assert np.max(np.abs(dev)) < 0.06 and np.max(np.abs(dev)) < 0.5 * np.max(np.abs(acc - A0))
    # 个体近交系数：元基础群体尺度下 F_i = ½A_Γ(s,d)
    out = {"Gamma": Gam.tolist(), "eig": ev.tolist(), "A_gamma_diag": np.diag(Aan).tolist(), "A_diag": np.diag(A0).tolist(),
           "mc_max_dev": float(np.max(np.abs(dev))), "mc_mean_dev": float(np.mean(np.abs(dev))),
           "mc_max_dev_vs_A": float(np.max(np.abs(acc - A0))), "inverse_err": float(err), "teaching_gamma": G2.tolist(),
           "invalid_eig": evb.tolist()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex28_19_metafounder.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
