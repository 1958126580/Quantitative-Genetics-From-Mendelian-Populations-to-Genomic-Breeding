#!/usr/bin/env python3
"""习题 28.18  单步方程的预条件共轭梯度：收敛、停止规则、目标误差与热启动

对单步 GBLUP 混合模型方程 Lθ = d（20 个场年固定效应 + 全部动物效应）比较三种预条件：
    无预条件 M = I；对角（Jacobi）M = diag(L)；块对角 M = blkdiag(X'X, diag(动物块))。
报告：预条件后系统的谱条件数 κ = λmax/λmin（广义特征值 L v = λ M v）、
    达到相对残差 ‖d − Lθ_k‖/‖d‖ ≤ 10⁻⁴、10⁻⁸、10⁻¹² 所需迭代数，以及对应的解误差。
目标误差：对候选差值 t = cᵀθ，对偶解 Lz = c 给出精确恒等式 t − cᵀθ_k = zᵀ r_k，
    并满足能量界 |t − cᵀθ_k| ≤ √(cᵀL⁻¹c) √(r_kᵀL⁻¹r_k)。程序逐次核验。
停止容差与决策：不同容差下候选前 10% 名单与精确解的重合率、最大绝对误差（σa 单位）。
热启动：先用 90% 记录求解，再加入其余记录重新求解；比较零初值、按动物身份映射的旧解、
    按位置错位一行复制的旧解三种初值的迭代数——三者最终都收敛到同一解，
    错位初值只是浪费迭代，但若停止规则只看相邻迭代变化，就可能在错误位置提前停止。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.linalg import cho_factor, cho_solve, eigh

HERE = Path(__file__).resolve().parent


def simulate_population(cfg, rng):
    nf, ngen, noff = cfg["founders"], cfg["generations"], cfg["offspring_per_gen"]
    sire = [-1] * nf; dam = [-1] * nf; gen = [0] * nf
    males = list(range(0, nf, 2)); females = list(range(1, nf, 2))
    for g in range(1, ngen + 1):
        sires = rng.choice(males, cfg["sires_per_gen"], replace=False)
        dams = rng.choice(females, min(cfg["dams_per_gen"], len(females)), replace=False)
        new_m, new_f = [], []
        for _ in range(noff):
            i = len(sire); sire.append(int(rng.choice(sires))); dam.append(int(rng.choice(dams))); gen.append(g)
            (new_m if rng.random() < 0.5 else new_f).append(i)
        males, females = new_m, new_f
    n = len(sire); m_chr, n_chr = cfg["loci_per_chr"], cfg["n_chr"]
    pos = np.sort(rng.uniform(0, 1, (n_chr, m_chr)), axis=1)
    p0 = rng.uniform(0.05, 0.95, n_chr * m_chr)
    hap = np.zeros((n, 2, p0.size), dtype=np.int8)
    for i in range(nf):
        hap[i] = (rng.random((2, p0.size)) < p0).astype(np.int8)
    for i in range(nf, n):
        for k, par in enumerate((sire[i], dam[i])):
            for c in range(n_chr):
                sl = slice(c * m_chr, (c + 1) * m_chr)
                cuts = np.sort(rng.uniform(0, 1, rng.poisson(1.0)))
                strand = (int(rng.integers(2)) + np.searchsorted(cuts, pos[c])) % 2
                hap[i, k, sl] = np.where(strand == 0, hap[par, 0, sl], hap[par, 1, sl])
    return np.array(sire), np.array(dam), np.array(gen), hap, p0


def tabular_A(sire, dam):
    n = sire.size; A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]; row = np.zeros(i)
        if s >= 0: row += 0.5 * A[s, :i]
        if d >= 0: row += 0.5 * A[d, :i]
        A[i, :i] = row; A[:i, i] = row
        A[i, i] = 1.0 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0.0)
    return A


def henderson_Ainv(sire, dam, F):
    n = sire.size; Ai = np.zeros((n, n))
    for i in range(n):
        par = [p for p in (sire[i], dam[i]) if p >= 0]
        b = 1.0 - 0.25 * len(par) - 0.25 * sum(F[p] for p in par)
        idx = [i] + par; w = np.array([1.0] + [-0.5] * len(par))
        Ai[np.ix_(idx, idx)] += np.outer(w, w) / b
    return Ai


def build_system(cfg, rng):
    sire, dam, gen, hap, p0 = simulate_population(cfg, rng)
    n = sire.size; nl = p0.size
    qtl = np.sort(rng.choice(nl, cfg["n_qtl"], replace=False)); mk = np.setdiff1d(np.arange(nl), qtl)
    geno = hap.sum(axis=1).astype(float)
    a = rng.normal(0, 1, qtl.size); a *= np.sqrt(cfg["var_a"] / np.sum(2 * p0[qtl] * (1 - p0[qtl]) * a ** 2))
    u = (geno[:, qtl] - 2 * p0[qtl]) @ a
    var_e = cfg["var_a"] * (1 - cfg["h2"]) / cfg["h2"]; lam = var_e / cfg["var_a"]
    rec = np.where(gen < cfg["generations"])[0]
    hy = rng.integers(0, cfg["n_hy"], rec.size)
    y = 500 + rng.normal(0, np.sqrt(cfg["var_hy"]), cfg["n_hy"])[hy] + u[rec] + rng.normal(0, np.sqrt(var_e), rec.size)
    cand = np.where(gen == cfg["generations"])[0]
    pool = np.where((gen >= 3) & (gen < cfg["generations"]))[0]
    g2 = np.sort(np.concatenate([cand, rng.choice(pool, cfg["n_genotyped_old"], replace=False)]))
    A = tabular_A(sire, dam); Ainv = henderson_Ainv(sire, dam, np.diag(A) - 1)
    A22 = A[np.ix_(g2, g2)]
    M = geno[np.ix_(g2, mk)]; p = M.mean(0) / 2; keep = (p > 0.01) & (p < 0.99)
    Zc = M[:, keep] - 2 * p[keep]; G = Zc @ Zc.T / (2 * np.sum(p[keep] * (1 - p[keep])))
    Gw = (1 - cfg["blend_w"]) * G + cfg["blend_w"] * A22
    Hinv = Ainv.copy(); Hinv[np.ix_(g2, g2)] += np.linalg.inv(Gw) - np.linalg.inv(A22)
    return dict(n=n, rec=rec, hy=hy, y=y, Hinv=Hinv, lam=lam, cand=cand, nf=cfg["n_hy"], sd_a=np.sqrt(cfg["var_a"]))


def mme(sys_: dict, mask: np.ndarray):
    rec, hy, y = sys_["rec"][mask], sys_["hy"][mask], sys_["y"][mask]
    nf, n = sys_["nf"], sys_["n"]
    X = np.zeros((rec.size, nf)); X[np.arange(rec.size), hy] = 1
    Z = np.zeros((rec.size, n)); Z[np.arange(rec.size), rec] = 1
    L = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + sys_["lam"] * sys_["Hinv"]]])
    return L, np.concatenate([X.T @ y, Z.T @ y])


def pcg(L, d, Minv, tol, maxit=20000, x0=None, callback=None):
    x = np.zeros_like(d) if x0 is None else x0.copy()
    r = d - L @ x; z = Minv(r); p = z.copy(); rz = r @ z; nd = np.linalg.norm(d)
    for k in range(1, maxit + 1):
        Lp = L @ p; alpha = rz / (p @ Lp)
        x += alpha * p; r -= alpha * Lp
        if k % 50 == 0:                       # 定期用完整方程重算残差，防止递推残差漂移
            r = d - L @ x
        if callback is not None: callback(k, x, r)
        if np.linalg.norm(r) / nd <= tol:
            r_true = d - L @ x
            if np.linalg.norm(r_true) / nd <= tol:
                return x, k
            r = r_true
        z = Minv(r); rz_new = r @ z; p = z + (rz_new / rz) * p; rz = rz_new
    return x, -1


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex28_18_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    S = build_system(cfg, rng)
    full = np.ones(S["rec"].size, bool)
    L, d = mme(S, full); nf = S["nf"]; dim = d.size
    cf = cho_factor(L); theta = cho_solve(cf, d)
    diagL = np.diag(L).copy()
    Fblk = np.linalg.inv(L[:nf, :nf])
    precs = {
        "无预条件": (lambda r: r, np.eye(dim)),
        "对角": (lambda r: r / diagL, np.diag(diagL)),
        "块对角": (lambda r: np.concatenate([Fblk @ r[:nf], r[nf:] / diagL[nf:]]),
                 np.block([[L[:nf, :nf], np.zeros((nf, dim - nf))], [np.zeros((dim - nf, nf)), np.diag(diagL[nf:])]])),
    }
    res = {"dim": int(dim), "preconditioners": {}}
    print(f"方程维数 {dim}（固定效应 {nf}，动物 {S['n']}，记录 {S['rec'].size}）")
    print(f"{'预条件':<6s}{'κ':>12s}{'it(1e-4)':>9s}{'it(1e-8)':>9s}{'it(1e-12)':>10s}{'max|θ−θ̂|(1e-8)':>16s}")
    for name, (Minv, Mmat) in precs.items():
        ev = eigh(L, Mmat, eigvals_only=True); kappa = float(ev[-1] / ev[0])
        its, errs = [], []
        for tol in (1e-4, 1e-8, 1e-12):
            x, k = pcg(L, d, Minv, tol); its.append(k); errs.append(float(np.max(np.abs(x - theta))))
        res["preconditioners"][name] = {"kappa": kappa, "iters": its, "max_err": errs}
        print(f"{name:<6s}{kappa:12.3e}{its[0]:9d}{its[1]:9d}{its[2]:10d}{errs[1]:16.2e}")

    # 目标误差的对偶恒等式
    Minv = precs["对角"][0]
    cand = S["cand"]; uc = theta[nf + cand]; top2 = cand[np.argsort(-uc)[:2]]
    c = np.zeros(dim); c[nf + top2[0]] = 1; c[nf + top2[1]] = -1
    zdual = cho_solve(cf, c); cLc = float(c @ zdual)
    trace = []

    def cb(k, x, r):
        if k in (5, 10, 20, 40, 80, 160):
            r_true = d - L @ x
            err = float(c @ (theta - x)); dual = float(zdual @ r_true)
            bound = float(np.sqrt(cLc) * np.sqrt(r_true @ cho_solve(cf, r_true)))
            assert abs(err - dual) < 1e-8 * max(1.0, abs(err)) and abs(err) <= bound * (1 + 1e-9)
            trace.append({"iter": k, "rel_resid": float(np.linalg.norm(r_true) / np.linalg.norm(d)),
                          "target_err": err, "dual_zr": dual, "energy_bound": bound})
    pcg(L, d, Minv, 1e-12, callback=cb)
    res["dual_trace"] = trace
    print(f"\n候选差值目标 t = û({top2[0]}) − û({top2[1]}) = {c @ theta:.4f}；对偶恒等式逐次核验通过")
    for t in trace:
        print(f"  第{t['iter']:4d}次：相对残差 {t['rel_resid']:.2e}，目标误差 {t['target_err']:+.2e}，"
              f"zᵀr = {t['dual_zr']:+.2e}，能量界 {t['energy_bound']:.2e}")

    # 容差与决策
    ktop = int(0.1 * cand.size); top_exact = set(cand[np.argsort(-uc)[:ktop]]); tol_rows = []
    print(f"\n{'容差':>8s}{'迭代':>6s}{'前10%重合':>10s}{'max|Δû|/σa':>12s}")
    for tol in (1e-2, 1e-3, 1e-4, 1e-6, 1e-8):
        x, k = pcg(L, d, Minv, tol); ux = x[nf + cand]
        ov = len(set(cand[np.argsort(-ux)[:ktop]]) & top_exact) / ktop
        mx = float(np.max(np.abs(ux - uc)) / S["sd_a"])
        tol_rows.append({"tol": tol, "iters": k, "top10_overlap": ov, "max_abs_err_sd": mx})
        print(f"{tol:8.0e}{k:6d}{ov:10.2f}{mx:12.2e}")
    res["tolerance"] = tol_rows

    # 热启动
    m_old = rng.random(S["rec"].size) < 0.9
    L0, d0 = mme(S, m_old); th_old = cho_solve(cho_factor(L0), d0)
    starts = {"零初值": None, "身份映射旧解": th_old, "错位一行的旧解": np.concatenate([th_old[:nf], np.roll(th_old[nf:], 1)])}
    warm = {}
    print("\n加入其余 10% 记录后重新求解（对角预条件，容差 1e-10）：")
    for name, x0 in starts.items():
        x, k = pcg(L, d, Minv, 1e-10, x0=x0)
        r0 = float(np.linalg.norm(d - L @ (np.zeros(dim) if x0 is None else x0)) / np.linalg.norm(d))
        warm[name] = {"iters": k, "init_rel_resid": r0, "final_max_err": float(np.max(np.abs(x - theta)))}
        print(f"  {name:<10s} 初始相对残差 {r0:.2e}，迭代 {k:4d}，最终 max|θ−θ̂| = {warm[name]['final_max_err']:.1e}")
    res["warm_start"] = warm
    # 核验：容差越小迭代越多、名单重合率越高，宽松容差（1e-2）名单明显错误；热启动用对身份映射的旧解迭代最少；所有初值收敛到同一解
    its = [r["iters"] for r in tol_rows]
    assert all(its[i] < its[i + 1] for i in range(len(its) - 1)), its
    assert tol_rows[0]["top10_overlap"] < 0.6 and tol_rows[-1]["top10_overlap"] == 1.0
    assert warm["身份映射旧解"]["iters"] < warm["零初值"]["iters"] and warm["身份映射旧解"]["iters"] <= warm["错位一行的旧解"]["iters"]
    assert max(w["final_max_err"] for w in warm.values()) < 1e-5
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex28_18_pcg_solver.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
