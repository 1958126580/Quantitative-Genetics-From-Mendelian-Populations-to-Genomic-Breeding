#!/usr/bin/env python3
"""习题 16.15  目标性状与记录性状不同的多性状选择指数（肉羊胴体目标）

模型：目标 H = aᵀu，u = (胴体瘦肉重, 胴体脂肪重) 的加性育种值；
记录 y = (自身 120 日龄体重, 超声背膘, 超声眼肌深, n 只父系半同胞胴体瘦肉重均值)。
    P = Var(y)（m×m），C = Cov(y, u)（m×q），b = P⁻¹Ca（用 Cholesky 求解，不显式求逆）
    σ_I² = bᵀPb，σ_H² = aᵀΣ_u a，r_IH = σ_I/σ_H，Δu = i·Cᵀb/σ_I，ΔH = aᵀΔu
半同胞均值：Var = σ²_A/4 + (σ²_P − σ²_A/4)/n，Cov(自身记录 j, 半同胞均值) = σ_A(j,ℓ)/4，
Cov(半同胞均值, u_k) = σ_A(ℓ,k)/4（父系半同胞，无共同环境）。
独立核验：bᵀPb = bᵀCa；随机权重的标准化响应不超过柯西界 √(gᵀP⁻¹g)；
记录单位变换 y* = Dy 后指数分数不变；逐一删去信息源比较 r_IH（信息价值）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def cov_from(sd: np.ndarray, corr: np.ndarray) -> np.ndarray:
    return corr * np.outer(sd, sd)


def build(cfg: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
    sdA = np.array(cfg["genetic_sd"]); h2 = np.array(cfg["h2"])
    sdE = sdA * np.sqrt((1 - h2) / h2)
    G = cov_from(sdA, np.array(cfg["genetic_corr"])); R = cov_from(sdE, np.array(cfg["residual_corr"]))
    Pall = G + R
    own, tg, hs, n = cfg["own_records"], cfg["targets"], cfg["halfsib_trait"], cfg["halfsib_n"]
    m = len(own) + 1
    P = np.zeros((m, m)); C = np.zeros((m, len(tg)))
    P[:len(own), :len(own)] = Pall[np.ix_(own, own)]
    P[-1, -1] = G[hs, hs] / 4 + (Pall[hs, hs] - G[hs, hs] / 4) / n
    P[:len(own), -1] = P[-1, :len(own)] = G[own, hs] / 4
    C[:len(own), :] = G[np.ix_(own, tg)]
    C[-1, :] = G[hs, tg] / 4
    Su = G[np.ix_(tg, tg)]
    names = [cfg["traits"][j] for j in own] + [f"HS{n}_{cfg['traits'][hs]}"]
    return P, C, Su, names


def index_stats(P: np.ndarray, C: np.ndarray, Su: np.ndarray, a: np.ndarray, i: float) -> dict:
    g = C @ a
    b = cho_solve(cho_factor(P), g)
    sI = float(np.sqrt(b @ P @ b)); sH = float(np.sqrt(a @ Su @ a))
    du = i * (C.T @ b) / sI
    return {"b": b, "sigma_I": sI, "sigma_H": sH, "r_IH": sI / sH, "du": du, "dH": float(a @ du)}


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex16_15_sheep_index.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    P, C, Su, names = build(cfg)
    a = np.array(cfg["economic_weights"]); p = cfg["proportion_selected"]
    z = norm.isf(p); i = float(norm.pdf(z) / p)
    np.linalg.cholesky(P)                                   # P 必须正定
    full = index_stats(P, C, Su, a, i)
    b = full["b"]; g = C @ a

    # 核验 1：bᵀPb = bᵀg（最优指数的性质）
    assert np.isclose(b @ P @ b, b @ g)
    # 核验 2：柯西界——任意权重的标准化目标协方差不超过 √(gᵀP⁻¹g)
    bound = np.sqrt(g @ cho_solve(cho_factor(P), g))
    rand = rng.normal(size=(20000, len(b)))
    ratios = (rand @ g) / np.sqrt(np.einsum("ij,jk,ik->i", rand, P, rand))
    assert ratios.max() <= bound + 1e-12 and np.isclose(full["sigma_I"], bound)
    # 核验 3：记录单位变换不改变指数分数
    D = np.diag([1000.0, 0.1, 0.1, 1.0])                    # kg→g, mm→cm
    bD = cho_solve(cho_factor(D @ P @ D), D @ C @ a)
    y = rng.multivariate_normal(np.zeros(len(b)), P, size=5)
    assert np.allclose((y @ D) @ bD, y @ b)

    print(f"保留比例 {p:.2f}，选择强度 i = {i:.4f}")
    print("指数权重 b：" + "，".join(f"{nm} {v:.4f}" for nm, v in zip(names, b)))
    print(f"σ_I = {full['sigma_I']:.4f}，σ_H = {full['sigma_H']:.4f}，r_IH = {full['r_IH']:.4f}")
    print(f"每代预期响应：瘦肉重 {full['du'][0]:+.4f} kg，脂肪重 {full['du'][1]:+.4f} kg，ΔH = {full['dH']:.3f}")
    # 记录性状的相关响应：Cov(记录的遗传部分, I)
    sdA = np.array(cfg["genetic_sd"]); Gall = cov_from(sdA, np.array(cfg["genetic_corr"]))
    own, hs = cfg["own_records"], cfg["halfsib_trait"]
    CovGI = np.zeros((len(cfg["traits"]), len(b)))
    CovGI[:, :len(own)] = Gall[:, own]; CovGI[:, -1] = Gall[:, hs] / 4
    corr_resp = i * (CovGI @ b) / full["sigma_I"]
    print("各性状遗传均值响应：" + "，".join(f"{t} {v:+.4f}" for t, v in zip(cfg["traits"], corr_resp)))

    # 信息价值：逐一删去信息源
    rows = []
    for k in range(len(b)):
        keep = [j for j in range(len(b)) if j != k]
        st = index_stats(P[np.ix_(keep, keep)], C[keep], Su, a, i)
        rows.append({"dropped": names[k], "r_IH": st["r_IH"], "dH": st["dH"], "loss_pct": 100 * (1 - st["dH"] / full["dH"])})
    print(f"{'删去的信息源':<16s}{'r_IH':>8s}{'ΔH':>9s}{'损失%':>8s}")
    for r in rows:
        print(f"{r['dropped']:<16s}{r['r_IH']:8.4f}{r['dH']:9.3f}{r['loss_pct']:8.2f}")
    # 错误做法：把经济权重直接套到“看起来对应”的记录上（体重→瘦肉、背膘→脂肪）
    naive = np.array([a[0], a[1], 0.0, 0.0])
    sN = np.sqrt(naive @ P @ naive); dH_naive = i * float(a @ (C.T @ naive)) / sN
    print(f"直接给记录套经济权重的指数：ΔH = {dH_naive:.3f}（最优的 {100*dH_naive/full['dH']:.1f}%）")

    out = {"i": i, "names": names, "b": b.tolist(), "sigma_I": full["sigma_I"], "sigma_H": full["sigma_H"],
           "r_IH": full["r_IH"], "du_targets": full["du"].tolist(), "dH": full["dH"],
           "correlated_responses": dict(zip(cfg["traits"], corr_resp.tolist())),
           "drop_one": rows, "naive_dH": dH_naive}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex16_15_indicator_index.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
