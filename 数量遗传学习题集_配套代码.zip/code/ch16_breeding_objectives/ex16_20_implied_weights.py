#!/usr/bin/env python3
"""习题 16.20  经验积分的隐含经济权重、目标方差分解与指数版本变化的来源分解

(1) 逆问题：若经验权重 b0 是某线性目标的最优指数，则 Pb0 = Ca，a = C⁻¹Pb0（只确定到正比例）。
(2) 目标方差 σ²_H = Σ a_j²σ_j² + Σ_{j≠k} a_j a_k σ_jk；比较“对角比例”“协方差均分”“标准化强调 |a_j|σ_j/Σ”。
(3) 版本变化：旧信息（WW, YW）× 旧权重 → 新信息（加 IMF）× 新权重；
    以新目标评价 ΔH，按两种顺序分解信息与权重的贡献并取平均（Shapley 分解）；
    模拟候选群，比较各版本入选名单的重合率。
核验：隐含权重代回得到 b0；经验指数在隐含目标下效率为 1；Shapley 两项之和等于总变化。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def cov(sd, corr):
    return np.array(corr) * np.outer(sd, sd)


def index(P, C, a, rec):
    Pr, Cr = P[np.ix_(rec, rec)], C[rec]
    return np.linalg.solve(Pr, Cr @ a)


def dH(P, C, b, rec, a_eval, i):
    Pr, Cr = P[np.ix_(rec, rec)], C[rec]
    return float(i * a_eval @ (Cr.T @ b) / np.sqrt(b @ Pr @ b))


def main() -> None:
    c = json.loads((HERE / "data" / "ex16_20_beef.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(c["seed"]); T = c["traits"]
    sdA = np.array(c["genetic_sd"]); h2 = np.array(c["h2"]); sdE = sdA * np.sqrt((1 - h2) / h2)
    G = cov(sdA, c["genetic_corr"]); R = cov(sdE, c["residual_corr"]); P = G + R; C = G
    p = c["proportion_selected"]; i = float(norm.pdf(norm.isf(p)) / p); allr = [0, 1, 2]
    # (1) 隐含权重
    b0 = np.array(c["empirical_points"]); a_imp = np.linalg.solve(C, P @ b0)
    emph_imp = a_imp * sdA / np.sum(np.abs(a_imp) * sdA)
    assert np.allclose(index(P, C, a_imp, allr), b0)
    a_bio = np.array(c["bioeconomic_weights"])
    eff_emp = dH(P, C, b0, allr, a_bio, i) / dH(P, C, index(P, C, a_bio, allr), allr, a_bio, i)
    assert np.isclose(dH(P, C, b0, allr, a_imp, i), dH(P, C, index(P, C, a_imp, allr), allr, a_imp, i))
    print("经验积分 b0 = " + "，".join(f"{t} {x}" for t, x in zip(T, b0)))
    print("隐含经济权重 a = C⁻¹Pb0：" + "，".join(f"{t} {x:.4f}" for t, x in zip(T, a_imp)))
    print("隐含权重的带符号标准化强调 a_jσ_j/Σ|a_jσ_j|：" + "，".join(f"{t} {x:+.3f}" for t, x in zip(T, emph_imp)))
    print(f"以生物经济目标评价，经验积分效率 = {eff_emp:.4f}")
    resp_emp = i * C.T @ b0 / np.sqrt(b0 @ P @ b0); bb = index(P, C, a_bio, allr); resp_bio = i * C.T @ bb / np.sqrt(bb @ P @ bb)
    print("每代响应  经验：" + "，".join(f"{t} {x:+.3f}" for t, x in zip(T, resp_emp)) +
          "；生物经济：" + "，".join(f"{t} {x:+.3f}" for t, x in zip(T, resp_bio)))
    # (2) 方差分解
    a = a_bio; tot = float(a @ G @ a); diag = a ** 2 * np.diag(G)
    half = np.array([a[j] * (G[j] @ a) for j in range(3)])          # 协方差项均分给两性状
    emph = np.abs(a) * sdA / np.sum(np.abs(a) * sdA)
    assert np.isclose(half.sum(), tot)
    print(f"目标方差 σ²_H = {tot:.2f}；对角项合计 {diag.sum():.2f}（比例和 {diag.sum()/tot:.3f}），交叉项 {tot-diag.sum():.2f}")
    print(f"{'性状':<8s}{'对角比例':>9s}{'均分比例':>9s}{'标准化强调':>11s}")
    for t, d1, d2, e in zip(T, diag / tot, half / tot, emph):
        print(f"{t:<8s}{d1:9.3f}{d2:9.3f}{e:11.3f}")
    # (3) 版本分解（以新目标评价）
    ov, nv = c["old_version"], c["new_version"]; aN = np.array(nv["weights"]); aO = np.array(ov["weights"])
    def val(rec, w):
        return dH(P, C, index(P, C, w, rec), rec, aN, i)
    v00, v01, v10, v11 = val(ov["records"], aO), val(ov["records"], aN), val(nv["records"], aO), val(nv["records"], aN)
    info = 0.5 * ((v10 - v00) + (v11 - v01)); wt = 0.5 * ((v01 - v00) + (v11 - v10))
    assert np.isclose(info + wt, v11 - v00)
    print(f"以新目标评价 ΔH：旧信息旧权重 {v00:.3f}，旧信息新权重 {v01:.3f}，新信息旧权重 {v10:.3f}，新信息新权重 {v11:.3f}")
    print(f"Shapley 分解：信息贡献 {info:.3f}，权重贡献 {wt:.3f}，合计 {v11-v00:.3f}")
    # 模拟候选群的入选名单
    n = c["n_candidates"]; u = rng.multivariate_normal(np.zeros(3), G, n); y = u + rng.multivariate_normal(np.zeros(3), R, n)
    k = int(round(p * n)); sel = {}
    for nm, rec, w in [("旧旧", ov["records"], aO), ("旧新", ov["records"], aN), ("新旧", nv["records"], aO), ("新新", nv["records"], aN)]:
        s = y[:, rec] @ index(P, C, w, rec); sel[nm] = set(np.argsort(-s)[:k])
    Htrue = u @ aN
    overlap = {f"{x}-新新": len(sel[x] & sel["新新"]) / k for x in sel}
    realized = {x: float(Htrue[list(sel[x])].mean() - Htrue.mean()) for x in sel}
    print("入选名单与“新新”版本重合率：" + "，".join(f"{x} {v:.3f}" for x, v in overlap.items()))
    print("模拟中入选者新目标真实均值优势：" + "，".join(f"{x} {v:.2f}" for x, v in realized.items()))
    out = {"i": i, "implied_weights": dict(zip(T, a_imp.tolist())), "implied_emphasis": emph_imp.tolist(), "efficiency_empirical": eff_emp,
           "resp_empirical": resp_emp.tolist(), "resp_bio": resp_bio.tolist(),
           "variance": {"total": tot, "diag_share": (diag / tot).tolist(), "half_split_share": (half / tot).tolist(), "emphasis": emph.tolist()},
           "versions": {"v00": v00, "v01": v01, "v10": v10, "v11": v11, "info": info, "weights": wt},
           "overlap": overlap, "realized": realized}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex16_20_implied_weights.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
