#!/usr/bin/env python3
"""习题 16.18  阈值性状的尺度转换：潜在责任度上的经济权重随发病率变化

责任度 ℓ ~ N(μ, 1)（残差标准化），发病当 ℓ > t₀，p = 1 − Φ(t₀ − μ)。
每例损失 L，期望损失 Lp，责任度均值的局部经济权重 a_μ = −Lφ(t₀ − μ)。
观察尺度（概率单位）的权重恒为 −L；二者通过 dp/dμ = φ(t₀ − μ) 转换。
每潜在遗传标准差 σ_ℓ = √h²_ℓ 的价值 = a_μ·σ_ℓ；Dempster–Lerner：h²_obs = h²_ℓ φ(t)²/[p(1−p)]。
核验：解析导数与差分；蒙特卡洛发病率与 Φ 一致；连续选择下“固定初始权重”与准确收益的偏离。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent


def incidence(mu: float, t0: float) -> float:
    return float(norm.sf(t0 - mu))


def main() -> None:
    c = json.loads((HERE / "data" / "ex16_18_disease.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(c["seed"]); L = c["loss_per_case"]; sl = np.sqrt(c["liability_h2"])
    rows = []
    print(f"{'发病率':>6s}{'阈值t₀':>9s}{'φ(t₀)':>9s}{'a_μ':>10s}{'每σ_ℓ价值':>11s}{'h²_obs':>8s}")
    for p in c["incidences"]:
        t0 = float(norm.isf(p)); a = -L * norm.pdf(t0)
        h = 1e-6; num = -L * (incidence(h, t0) - incidence(-h, t0)) / (2 * h)
        assert np.isclose(a, num, rtol=1e-6)
        h2o = c["liability_h2"] * norm.pdf(t0) ** 2 / (p * (1 - p))
        fin = {}
        for d in c["finite_changes"]:
            fin[str(d)] = {"exact": -L * (incidence(d, t0) - p), "linear": a * d}
        rows.append({"p": p, "t0": t0, "phi": float(norm.pdf(t0)), "a_mu": a, "per_sd": a * sl, "h2_obs": h2o, "finite": fin})
        print(f"{p:6.2f}{t0:9.4f}{norm.pdf(t0):9.4f}{a:10.2f}{a*sl:11.2f}{h2o:8.4f}")
    # 蒙特卡洛核验一个情形
    p = 0.10; t0 = norm.isf(p); x = rng.normal(0.3, 1.0, c["mc_n"])
    mc = float((x > t0).mean()); th = incidence(0.3, t0); se = np.sqrt(th * (1 - th) / c["mc_n"])
    assert abs(mc - th) < 4 * se
    print(f"蒙特卡洛：基线 10%、μ+0.3 后发病率 {mc:.4f}（理论 {th:.4f}）")
    print("有限改变（基线 10%）每头牛期望价值变化（正值为损失减少）：")
    for d, v in rows[2]["finite"].items():
        print(f"  Δμ = {float(d):+.1f}：准确 {v['exact']:9.2f}，线性 {v['linear']:9.2f}")
    # 连续选择：每代责任度改变 g，比较按初始权重线性累计与准确收益
    t0 = float(norm.isf(c["start_incidence"])); g = c["liability_gain_per_gen"]; a0 = -L * norm.pdf(t0)
    traj = []
    for k in range(c["generations"] + 1):
        mu = k * g; pk = incidence(mu, t0)
        traj.append({"gen": k, "incidence": pk, "exact_saving": L * (c["start_incidence"] - pk),
                     "linear_saving": a0 * mu,            # a0 < 0、μ < 0，乘积为正的节省
                     "current_weight": -L * norm.pdf(t0 - mu)})
    assert all(r["exact_saving"] <= r["linear_saving"] + 1e-9 for r in traj)   # 凸性：线性外推高估节省
    print(f"从发病率 {c['start_incidence']:.2f} 起每代责任度 {g:+.2f}：")
    for row in traj[::5]:
        print(f"  第{row['gen']:2d}代 发病率 {row['incidence']:.4f}，准确节省 {row['exact_saving']:8.2f}，"
              f"按初始权重线性 {row['linear_saving']:8.2f}，当期权重 {row['current_weight']:8.2f}")
    (HERE / "results").mkdir(exist_ok=True)
    plt = get_pyplot()
    if plt is not None:
        ps = np.linspace(0.005, 0.6, 200); ts = norm.isf(ps)
        fig, ax = plt.subplots(figsize=(6, 3.6))
        ax.plot(ps * 100, -L * norm.pdf(ts) * sl, color="#14284B")
        ax.set_xlabel("基线发病率 (%)"); ax.set_ylabel("每潜在遗传标准差的经济价值")
        ax.grid(alpha=0.3); fig.tight_layout(); fig.savefig(HERE / "results" / "ex16_18_weight_vs_incidence.png", dpi=150)
        plt.close(fig)
    out = {"by_incidence": rows, "mc_check": {"mc": mc, "theory": th}, "selection_trajectory": traj}
    (HERE / "results" / "ex16_18_liability_weight.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
