#!/usr/bin/env python3
"""习题 16.16  母羊生物经济模型：固定羊群与固定饲草两种系统边界下的经济权重

每只母羊年饲料（kg 干物质）：f(μ) = k_m·M^0.75 + n·s·k_l·W。
边界 A（羊群 N₀ 固定，饲料按价 p_f 购买）：
    Π_A = N₀·[ n s (pW − c_l − p_f k_l W) − c_e − p_f k_m M^0.75 ]
边界 B（饲草总量 R = N₀·f(μ₀) 固定，饲草无现金成本但限制母羊数 N）：
    平衡方程 F(N, μ) = N·f(μ) − R = 0，Π_B = N·[ n s (pW − c_l) − c_e ]
    隐函数公式 a = Π_μ − F_μᵀ F_N⁻ᵀ Π_N（伴随形式：F_N λ = Π_N，a = Π_μ − λF_μ）
经济权重以“每只基线母羊”为单位（除以 N₀），并用重新满足平衡的中心差分独立核验。
核验：边界 B 的权重恰等于把饲料按影子价格 λ 计价时边界 A 的权重。
另报告每遗传标准差经济价值与有限改变的准确收益和一阶近似之差。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
TR = ["n", "s", "W", "M"]


def feed(mu: dict, c: dict) -> float:
    return c["feed_per_metabolic_kg"] * mu["M"] ** 0.75 + mu["n"] * mu["s"] * c["feed_per_kg_lamb"] * mu["W"]


def margin_cash(mu: dict, c: dict) -> float:
    """不含饲料成本的每只母羊净收益。"""
    return mu["n"] * mu["s"] * (c["price_per_kg"] * mu["W"] - c["cost_per_lamb"]) - c["cost_per_ewe"]


def profit_A(mu: dict, c: dict) -> float:
    return c["flock_size"] * (margin_cash(mu, c) - c["feed_price"] * feed(mu, c))


def profit_B(mu: dict, c: dict, R: float) -> tuple[float, float]:
    N = R / feed(mu, c)                       # 解平衡方程
    return N * margin_cash(mu, c), N


def analytic(mu: dict, c: dict, R: float) -> tuple[np.ndarray, np.ndarray, float]:
    n, s, W, M = (mu[k] for k in TR)
    p, cl, pf, km, kl = c["price_per_kg"], c["cost_per_lamb"], c["feed_price"], c["feed_per_metabolic_kg"], c["feed_per_kg_lamb"]
    # 边界 A：直接偏导（除以 N₀）
    aA = np.array([s * (p * W - cl - pf * kl * W), n * (p * W - cl - pf * kl * W), n * s * (p - pf * kl),
                   -pf * km * 0.75 * M ** -0.25])
    # 边界 B：隐函数
    N = R / feed(mu, c); m0 = margin_cash(mu, c)
    Pi_mu = N * np.array([s * (p * W - cl), n * (p * W - cl), n * s * p, 0.0])
    f_mu = np.array([s * kl * W, n * kl * W, n * s * kl, km * 0.75 * M ** -0.25])
    F_mu = N * f_mu; F_N = feed(mu, c); Pi_N = m0
    lam = Pi_N / F_N                            # 伴随方程（标量）
    aB = (Pi_mu - lam * F_mu) / c["flock_size"]
    return aA, aB, lam


def numeric(mu: dict, c: dict, R: float, which: str, h: float = 1e-5) -> np.ndarray:
    out = []
    for k in TR:
        up, dn = dict(mu), dict(mu); step = h * max(1.0, abs(mu[k])); up[k] += step; dn[k] -= step
        f = (lambda m: profit_A(m, c)) if which == "A" else (lambda m: profit_B(m, c, R)[0])
        out.append((f(up) - f(dn)) / (2 * step) / c["flock_size"])
    return np.array(out)


def main() -> None:
    c = json.loads((HERE / "data" / "ex16_16_ewe_system.json").read_text(encoding="utf-8"))
    mu = c["baseline"]; N0 = c["flock_size"]; R = N0 * feed(mu, c)
    aA, aB, lam = analytic(mu, c, R)
    nA, nB = numeric(mu, c, R, "A"), numeric(mu, c, R, "B")
    assert np.allclose(aA, nA, rtol=1e-6, atol=1e-6) and np.allclose(aB, nB, rtol=1e-6, atol=1e-6)
    # 核验：固定饲草边界的权重 = 以影子价格 λ 给饲料计价的固定羊群权重
    c_shadow = dict(c); c_shadow["feed_price"] = lam
    assert np.allclose(analytic(mu, c_shadow, R)[0], aB)
    PiA, PiB = profit_A(mu, c), profit_B(mu, c, R)[0]
    print(f"基线：每只母羊饲料 {feed(mu, c):.1f} kg DM，饲草总量 R = {R:.0f}，N₀ = {N0}")
    print(f"基线利润：边界A {PiA:.1f}，边界B {PiB:.1f}（B 不扣饲料现金成本，饲草影子价格 λ = {lam:.4f}/kg）")
    sd = np.array([c["genetic_sd"][k] for k in TR])
    print(f"{'性状':<4s}{'a_A':>10s}{'a_B':>10s}{'a_A·σ_A':>10s}{'a_B·σ_A':>10s}")
    for k, x, y, s_ in zip(TR, aA, aB, sd):
        print(f"{k:<4s}{x:10.3f}{y:10.3f}{x*s_:10.3f}{y*s_:10.3f}")
    # 有限改变：准确变化与一阶近似
    fin = []
    for k in TR:
        d = c["finite_change"][k]; mu2 = dict(mu); mu2[k] += d
        exA = (profit_A(mu2, c) - PiA) / N0; exB = (profit_B(mu2, c, R)[0] - PiB) / N0
        fin.append({"trait": k, "delta": d, "exact_A": exA, "linear_A": aA[TR.index(k)] * d,
                    "exact_B": exB, "linear_B": aB[TR.index(k)] * d})
    mu_all = {k: mu[k] + c["finite_change"][k] for k in TR}
    jointA = (profit_A(mu_all, c) - PiA) / N0; jointB = (profit_B(mu_all, c, R)[0] - PiB) / N0
    linA = float(aA @ np.array([c["finite_change"][k] for k in TR])); linB = float(aB @ np.array([c["finite_change"][k] for k in TR]))
    print("有限改变（每只基线母羊）：")
    for r in fin:
        print(f"  {r['trait']} +{r['delta']}: A 准确 {r['exact_A']:8.3f} 线性 {r['linear_A']:8.3f}；B 准确 {r['exact_B']:8.3f} 线性 {r['linear_B']:8.3f}")
    print(f"  四性状同时改变：A 准确 {jointA:.3f} 线性 {linA:.3f}；B 准确 {jointB:.3f} 线性 {linB:.3f}")
    # 母羊数变化（边界 B）：成年体重 +4 kg
    mu3 = dict(mu); mu3["M"] += c["finite_change"]["M"]
    print(f"边界 B 下成年体重 +{c['finite_change']['M']} kg 时可养母羊数：{profit_B(mu3, c, R)[1]:.2f}（原 {N0}）")
    out = {"R": R, "lambda_feed": lam, "a_fixed_flock": dict(zip(TR, aA.tolist())), "a_fixed_feed": dict(zip(TR, aB.tolist())),
           "per_genetic_sd_A": dict(zip(TR, (aA * sd).tolist())), "per_genetic_sd_B": dict(zip(TR, (aB * sd).tolist())),
           "finite": fin, "joint": {"exact_A": jointA, "linear_A": linA, "exact_B": jointB, "linear_B": linB}}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex16_16_bioeconomic_weights.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
