#!/usr/bin/env python3
"""习题 16.17  胎次状态转移矩阵与折现终生价值：功能性存活与产量的经济权重

暂态转移矩阵 T：T[k,k+1] = s_k（k<5），T[5,5] = s_5；行和 < 1 的缺口为淘汰退出。
每期净收益 r，折现因子 δ = 1/(1+d)。价值向量 v = (I − δT)⁻¹ r，终生价值 V = αᵀv。
功能性存活育种值 μ 作用于潜在尺度：s_k(μ) = Φ(t_k + μ)，t_k = Φ⁻¹(s_k)，
    ∂v/∂μ = (I − δT)⁻¹ δ T_μ v，T_μ 的非零元为 φ(t_k)。
产量性状：每期净收益按 r(1+θ) 改变，∂V/∂θ = αᵀ(I − δT)⁻¹ r。
核验：矩阵解与逐期级数求和一致；解析导数与中心差分一致；有限期尾项 (δT)^L v；
期望生产期 αᵀ(I − T)⁻¹1 与年更新率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def transition(s: np.ndarray) -> np.ndarray:
    k = len(s); T = np.zeros((k, k))
    for j in range(k - 1):
        T[j, j + 1] = s[j]
    T[-1, -1] = s[-1]
    return T


def values(s: np.ndarray, r: np.ndarray, delta: float) -> np.ndarray:
    return np.linalg.solve(np.eye(len(r)) - delta * transition(s), r)


def main() -> None:
    c = json.loads((HERE / "data" / "ex16_17_parity_states.json").read_text(encoding="utf-8"))
    r = np.array(c["net_margin"]); s = np.array(c["survival"]); al = np.array(c["initial"])
    delta = 1 / (1 + c["discount_rate"]); T = transition(s); I = np.eye(len(r))
    assert max(abs(np.linalg.eigvals(delta * T))) < 1
    v = values(s, r, delta); V = float(al @ v)
    # 核验：级数求和
    acc, M = np.zeros_like(r), np.eye(len(r))
    for _ in range(2000):
        acc += M @ r; M = delta * T @ M
    assert np.allclose(acc, v)
    life = float(al @ np.linalg.solve(I - T, np.ones(len(r))))
    print(f"折现因子 δ = {delta:.6f}；各状态价值 v = " + "，".join(f"{x:.2f}" for x in v))
    print(f"初产牛终生折现价值 V = {V:.2f}；期望泌乳期数 {life:.4f}，稳态年更新率约 {1/life:.4f}")

    # 功能性存活（潜在尺度）权重
    t = norm.ppf(s); Tmu = transition(norm.pdf(t))
    dv = np.linalg.solve(I - delta * T, delta * Tmu @ v); a_surv = float(al @ dv)
    h = 1e-6
    num = (al @ values(norm.cdf(t + h), r, delta) - al @ values(norm.cdf(t - h), r, delta)) / (2 * h)
    assert np.isclose(a_surv, num, rtol=1e-6)
    # 只提高某一胎次存活一个概率单位（逐项分解）
    per = []
    for k in range(len(s)):
        E = np.zeros_like(T)
        if k < len(s) - 1: E[k, k + 1] = 1.0
        else: E[k, k] = 1.0
        per.append(float(al @ np.linalg.solve(I - delta * T, delta * E @ v)))
    # 产量权重：每期净收益增加 1%
    a_yield = float(al @ np.linalg.solve(I - delta * T, r)) * 0.01
    print(f"功能性存活潜在尺度 +1 单位的权重：{a_surv:.2f}（中心差分 {num:.2f}）；+0.1 单位约 {0.1*a_surv:.2f}")
    print("某一胎次存活率 +1 个概率单位的价值：" + "，".join(f"{st} {x:.2f}" for st, x in zip(c["states"], per)))
    print(f"每期净收益 +1% 的价值：{a_yield:.2f}")
    # 有限改变 0.3 潜在单位
    ex = float(al @ values(norm.cdf(t + 0.3), r, delta)) - V
    print(f"潜在尺度 +0.3：准确 {ex:.2f}，线性 {0.3*a_surv:.2f}")
    # 有限期限与尾项
    hz = []
    for L in c["horizons"]:
        vL = sum(np.linalg.matrix_power(delta * T, k) @ r for k in range(L))
        tail = np.linalg.matrix_power(delta * T, L) @ v
        assert np.allclose(v - vL, tail)
        hz.append({"L": L, "V_L": float(al @ vL), "tail": float(al @ tail)})
    print("有限期限：" + "；".join(f"L={x['L']} V={x['V_L']:.1f} 尾项 {x['tail']:.1f}" for x in hz))
    # 不折现时
    v0 = np.linalg.solve(I - T, r)
    print(f"不折现的终生净收益 {al @ v0:.2f}（折现降低 {100*(1 - V/(al @ v0)):.1f}%）")
    out = {"delta": delta, "v": v.tolist(), "V": V, "expected_lactations": life, "replacement_rate": 1 / life,
           "a_survival_liability": a_surv, "a_survival_by_parity": dict(zip(c["states"], per)),
           "a_yield_1pct": a_yield, "finite_0.3": ex, "horizons": hz, "undiscounted": float(al @ v0)}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex16_17_lifetime_value.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
