#!/usr/bin/env python3
"""习题 16.19  经济权重误设与遗传参数不确定性：响应损失、Jacobian 与方向稳健性

记录为候选自身三性状表型，C = Σ_u = G，P = G + R，B = CᵀP⁻¹C。
用权重 ã 构造指数、以真实 a 评价：R(a, ã) = i·aᵀBã/√(ãᵀBã)，效率 = B 度量下夹角余弦。
小误差的二阶损失：R(a,a) − R(a,a+ε) ≈ i/(2s)·ε⊥ᵀBε⊥，s² = aᵀBa，ε⊥ = ε − a(aᵀBε)/s²。
各性状响应 Δu = iBa/s，Jacobian ∂Δu/∂aᵀ = i[B/s − (Ba)(Ba)ᵀ/s³]，满足 J·a = 0。
价格情景：采食权重按对数正态（CV 30%）波动，统计效率分布。
参数情景：G 与 R 由 Wishart 抽样（保证正定），在固定指数下计算采食响应为正的概率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import wishart

HERE = Path(__file__).resolve().parent


def cov(sd, corr):
    return np.array(corr) * np.outer(sd, sd)


def resp(B: np.ndarray, a_eval: np.ndarray, a_used: np.ndarray, i: float) -> float:
    return float(i * a_eval @ B @ a_used / np.sqrt(a_used @ B @ a_used))


def main() -> None:
    c = json.loads((HERE / "data" / "ex16_19_pig.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(c["seed"]); i = c["i"]
    sdA = np.array(c["genetic_sd"]); h2 = np.array(c["h2"]); sdE = sdA * np.sqrt((1 - h2) / h2)
    G = cov(sdA, c["genetic_corr"]); R = cov(sdE, c["residual_corr"]); P = G + R
    B = G @ np.linalg.solve(P, G); a = np.array(c["economic_weights"]); s = np.sqrt(a @ B @ a)
    du = i * B @ a / s
    print("真实权重下各性状响应：" + "，".join(f"{t} {x:+.4f}" for t, x in zip(c["traits"], du)) + f"；ΔH = {i*s:.4f}")
    # Jacobian 解析与数值
    J = i * (B / s - np.outer(B @ a, B @ a) / s ** 3)
    Jn = np.zeros((3, 3)); h = 1e-6
    for k in range(3):
        e = np.zeros(3); e[k] = h * max(1, abs(a[k]))
        f = lambda w: i * B @ w / np.sqrt(w @ B @ w)
        Jn[:, k] = (f(a + e) - f(a - e)) / (2 * e[k])
    assert np.allclose(J, Jn, rtol=1e-5, atol=1e-8) and np.allclose(J @ a, 0, atol=1e-8)
    print("Jacobian ∂Δu/∂aᵀ：")
    for t, row in zip(c["traits"], J):
        print(f"  {t:<7s}" + "".join(f"{x:12.5f}" for x in row))
    # 典型误设情景
    scen = {"采食价格低估30%": a * np.array([1, 1, 0.7]), "采食价格高估30%": a * np.array([1, 1, 1.3]),
            "忽略采食": a * np.array([1, 1, 0]), "背膘符号错": a * np.array([1, -1, 1]), "整体×10": a * 10}
    rows = []
    print(f"{'情景':<12s}{'效率':>8s}{'二阶近似效率':>12s}" + "".join(f"{t:>10s}" for t in c["traits"]))
    for nm, at in scen.items():
        eff = resp(B, a, at, i) / (i * s)
        eps = at - a; ep = eps - a * (a @ B @ eps) / s ** 2
        approx = 1 - (i / (2 * s) * ep @ B @ ep) / (i * s)
        d = i * B @ at / np.sqrt(at @ B @ at)
        rows.append({"scenario": nm, "efficiency": eff, "second_order": approx, "du": d.tolist()})
        print(f"{nm:<12s}{eff:8.4f}{approx:12.4f}" + "".join(f"{x:10.4f}" for x in d))
    assert np.isclose(rows[-1]["efficiency"], 1.0)
    # 小扰动下二阶近似的精度
    eps = np.array([0.0, 0.0, -0.05 * a[2]]); exact = i * s - resp(B, a, a + eps, i)
    ep = eps - a * (a @ B @ eps) / s ** 2; approx = i / (2 * s) * ep @ B @ ep
    assert abs(exact - approx) / approx < 0.1
    print(f"采食权重 5% 误差：准确损失 {exact:.6f}，二阶近似 {approx:.6f}")
    # 价格情景
    k = c["feed_weight_index"]; cv = c["feed_price_scenarios_cv"]; sig = np.sqrt(np.log(1 + cv ** 2))
    mult = rng.lognormal(-sig ** 2 / 2, sig, c["n_price_draws"])
    effs = []; fresp = []
    for m in mult:
        ap = a.copy(); ap[k] *= m
        effs.append(resp(B, ap, a, i) / (i * np.sqrt(ap @ B @ ap)))   # 固定用 a，真实价格为 ap
    effs = np.array(effs)
    print(f"价格情景（真实采食权重 ~ 对数正态 CV {cv:.0%}）：固定指数效率 均值 {effs.mean():.4f}，5%分位 {np.quantile(effs, 0.05):.4f}，最小 {effs.min():.4f}")
    # 参数不确定：Wishart 抽样
    nu = c["wishart_df"]; pos = 0; dfi = []
    b_fixed = np.linalg.solve(P, G @ a)
    for _ in range(c["n_param_draws"]):
        Gs = wishart.rvs(df=nu, scale=G / nu, random_state=rng); Rs = wishart.rvs(df=nu, scale=R / nu, random_state=rng)
        Ps = Gs + Rs; d = i * Gs @ b_fixed / np.sqrt(b_fixed @ Ps @ b_fixed); dfi.append(d[k]); pos += d[k] > 0
    dfi = np.array(dfi)
    print(f"参数情景（Wishart 自由度 {nu}）：采食响应均值 {dfi.mean():+.5f}，90%区间 [{np.quantile(dfi,0.05):+.5f}, {np.quantile(dfi,0.95):+.5f}]，P(采食上升) = {pos/len(dfi):.3f}")
    out = {"du_true": du.tolist(), "dH_opt": float(i * s), "jacobian": J.tolist(), "scenarios": rows,
           "small_error": {"exact": exact, "approx": approx},
           "price_uncertainty": {"mean_eff": float(effs.mean()), "q05": float(np.quantile(effs, 0.05)), "min": float(effs.min())},
           "param_uncertainty": {"mean_dfi": float(dfi.mean()), "q05": float(np.quantile(dfi, 0.05)), "q95": float(np.quantile(dfi, 0.95)), "p_increase": pos / len(dfi)}}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex16_19_weight_sensitivity.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
