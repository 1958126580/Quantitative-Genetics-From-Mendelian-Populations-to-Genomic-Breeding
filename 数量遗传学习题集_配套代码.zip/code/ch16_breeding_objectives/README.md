# 第16章　多性状育种目标与经济权重——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex16_15_indicator_index.py
python3 ex16_16_bioeconomic_weights.py
python3 ex16_17_lifetime_value.py
python3 ex16_18_liability_weight.py
python3 ex16_19_weight_sensitivity.py
python3 ex16_20_implied_weights.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 | 主要输出 |
|:--|:--|:--|:--|
| ex16_15_indicator_index.py | 16.15 | 目标性状（胴体瘦肉、脂肪）与记录性状（体重、超声、半同胞均值）不同的选择指数；信息源价值；直接套用经济权重的损失 | b、r_IH、各性状响应、逐一删去信息源的损失 |
| ex16_16_bioeconomic_weights.py | 16.16 | 母羊生物经济模型；固定羊群与固定饲草两种边界；隐函数与伴随公式；中心差分核验；有限改变 | 两套经济权重、每遗传标准差价值、饲草影子价格 |
| ex16_17_lifetime_value.py | 16.17 | 奶牛胎次状态转移矩阵；折现终生价值；功能性存活（潜在尺度）与产量权重；有限期尾项 | v、V、存活权重、分胎次价值、尾项 |
| ex16_18_liability_weight.py | 16.18 | 阈值性状经济权重随发病率变化；有限改变的非线性；连续选择下固定权重的偏差 | 各发病率下 a_μ、选择轨迹、权重曲线图 |
| ex16_19_weight_sensitivity.py | 16.19 | 经济权重误设的效率损失（B 度量夹角）、二阶近似、Jacobian、价格情景与 Wishart 参数情景 | 效率表、P(采食上升) |
| ex16_20_implied_weights.py | 16.20 | 经验积分的隐含经济权重；目标方差的三种“贡献”约定；指数版本变化的 Shapley 分解与入选重合率 | 隐含权重、方差分解、版本分解 |
