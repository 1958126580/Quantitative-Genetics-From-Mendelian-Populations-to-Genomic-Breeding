#!/usr/bin/env python3
"""习题 18.18  多世代模拟：截断选择与最优贡献选择的遗传进展、近交与方差

群体：每代 30 雄 + 30 雌；无限位点模型：a = ½(a_父 + a_母) + m，m ~ N(0, V₀(1 − (F_父 + F_母)/2)/2)；
表型 y = a + e；每世代用全部历史记录的系谱 BLUP：â = V_A A (V_A A + V_E I)⁻¹ (y − ȳ)（A 为累积系谱关系矩阵，单记录）。
策略：
  T  截断：留 8 雄、16 雌（EBV 最高者），等贡献，随机配对；
  O  最优贡献：每代最大化 cᵀâ，约束 ½cᵀAc ≤ θ_max(t) = 1 − (1 − ΔF*)^{t+1}（A 为全系谱关系，基础群体为参照），
     雌雄贡献各 1/2 且每头母畜至多 4 个后代；贡献按最大余数法取整，雄与雌槽位随机配对。
报告：第 T 代的平均真实育种值（相对基础）、平均近交系数、每代近交增量 ΔF、加性方差，重复 reps 次的均值。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import optimize
HERE = Path(__file__).resolve().parent


class Pop:
    def __init__(self, n0, V0, VE, rng):
        self.V0, self.VE, self.rng = V0, VE, rng
        self.A = np.eye(n0); self.a = rng.normal(0, np.sqrt(V0), n0); self.y = self.a + rng.normal(0, np.sqrt(VE), n0)
        self.sex = rng.permutation(np.r_[np.zeros(n0 // 2, int), np.ones(n0 - n0 // 2, int)])
        self.gen_start = [0]; self.F = np.zeros(n0)

    def ebv(self):
        n = len(self.a); G = self.V0 * self.A
        return G @ np.linalg.solve(G + self.VE * np.eye(n), self.y - self.y.mean())

    def reproduce(self, S, D):
        """S, D：下一代每个个体的父、母索引（全局）。"""
        n_old, m = len(self.a), len(S); A = self.A
        Anew = np.zeros((n_old + m, n_old + m)); Anew[:n_old, :n_old] = A
        rows = 0.5 * (A[S] + A[D]); Anew[n_old:, :n_old] = rows; Anew[:n_old, n_old:] = rows.T
        blk = 0.25 * (A[np.ix_(S, S)] + A[np.ix_(S, D)] + A[np.ix_(D, S)] + A[np.ix_(D, D)])
        Fn = 0.5 * A[S, D]; blk[np.diag_indices(m)] = 1 + Fn; Anew[n_old:, n_old:] = blk
        mv = self.V0 * (1 - 0.5 * (self.F[S] + self.F[D])) / 2
        an = 0.5 * (self.a[S] + self.a[D]) + self.rng.standard_normal(m) * np.sqrt(mv)
        self.A, self.F = Anew, np.r_[self.F, Fn]
        self.a = np.r_[self.a, an]; self.y = np.r_[self.y, an + self.rng.normal(0, np.sqrt(self.VE), m)]
        self.sex = np.r_[self.sex, self.rng.permutation(np.r_[np.zeros(m // 2, int), np.ones(m - m // 2, int)])]
        self.gen_start.append(n_old)


def largest_remainder(c, N):
    x = c / c.sum() * N; b = np.floor(x).astype(int); b[np.argsort(-(x - b))[:N - b.sum()]] += 1; return b


def contributions_oc(A, ebv, sex, theta_max, nper, c0):
    n = len(ebv); ub = np.where(sex == 0, 0.5, 4 / (2 * nper))
    cons = [{"type": "eq", "fun": lambda c: c[sex == 0].sum() - 0.5}, {"type": "eq", "fun": lambda c: c[sex == 1].sum() - 0.5},
            {"type": "ineq", "fun": lambda c: theta_max - 0.5 * c @ A @ c, "jac": lambda c: -(A @ c)}]
    for ftol in (1e-12, 1e-10, 1e-8):
        r = optimize.minimize(lambda c: -c @ ebv, c0, jac=lambda c: -ebv, bounds=[(0, u) for u in ub], constraints=cons, method="SLSQP", options=dict(ftol=ftol, maxiter=500))
        if r.success and 0.5 * r.x @ A @ r.x <= theta_max + 1e-6: return np.clip(r.x, 0, None)
    return None


def run(cfg, strategy, seed):
    rng = np.random.default_rng(seed); N = 2 * cfg["N_per_sex"]; V0 = cfg["h2"] * cfg["VP"]; VE = cfg["VP"] - V0
    pop = Pop(N, V0, VE, rng); g0 = pop.a.mean(); hist = []
    for t in range(cfg["generations"]):
        cur = np.arange(pop.gen_start[-1], len(pop.a)); eb = pop.ebv()[cur]; sx = pop.sex[cur]; Ac = pop.A[np.ix_(cur, cur)]
        if strategy == "T":
            c = np.zeros(len(cur))
            for s, k in ((0, cfg["trunc"]["males"]), (1, cfg["trunc"]["females"])):
                idx = np.where(sx == s)[0]; top = idx[np.argsort(-eb[idx])[:k]]; c[top] = 0.5 / k
        else:
            th = 1 - (1 - cfg["dF_target"]) ** (t + 1); c0 = np.where(sx == 0, 0.5 / (sx == 0).sum(), 0.5 / (sx == 1).sum())
            c = contributions_oc(Ac, eb, sx, th, cfg["N_per_sex"], c0)
            if c is None:                       # 约束不可行时放宽到等贡献
                c = c0
        ns = largest_remainder(c[sx == 0], N); nd = largest_remainder(c[sx == 1], N)
        S = rng.permutation(np.repeat(cur[sx == 0], ns)); D = rng.permutation(np.repeat(cur[sx == 1], nd))
        pop.reproduce(S, D)
        last = np.arange(pop.gen_start[-1], len(pop.a)); hist.append((pop.a[last].mean() - g0, pop.F[last].mean(), pop.a[last].var()))
    return np.array(hist)


def main():
    cfg = json.loads((HERE / "data" / "ex18_18_multigen.json").read_text()); T = cfg["generations"]
    res = {k: np.mean([run(cfg, k, cfg["seed"] + r) for r in range(cfg["reps"])], axis=0) for k in ("T", "O")}
    print(f"每代 {2 * cfg['N_per_sex']} 头，h² = {cfg['h2']}，截断留 {cfg['trunc']['males']}♂{cfg['trunc']['females']}♀；OCS 目标 ΔF = {cfg['dF_target']}；重复 {cfg['reps']} 次的均值")
    print(f"{'世代':>4s} | {'截断 ΔG':>8s}{'F':>8s}{'V_A':>7s} | {'OCS ΔG':>8s}{'F':>8s}{'V_A':>7s}")
    for t in range(T):
        print(f"{t + 1:4d} | {res['T'][t, 0]:8.3f}{res['T'][t, 1]:8.4f}{res['T'][t, 2]:7.3f} | {res['O'][t, 0]:8.3f}{res['O'][t, 1]:8.4f}{res['O'][t, 2]:7.3f}")
    dF = {k: 1 - (1 - res[k][-1, 1]) ** (1 / T) for k in res}
    print(f"\n{T} 代后：截断 ΔG = {res['T'][-1, 0]:.3f}，F = {res['T'][-1, 1]:.4f}，等效每代 ΔF = {dF['T']:.4f}；OCS ΔG = {res['O'][-1, 0]:.3f}，F = {res['O'][-1, 1]:.4f}，等效 ΔF = {dF['O']:.4f}")
    print(f"相同进展下近交：OCS 以 {100 * (res['O'][-1, 0] / res['T'][-1, 0] - 1):+.1f}% 的进展换来 ΔF 比截断低 {100 * (1 - dF['O'] / dF['T']):.0f}%")
    (HERE / "results" / "ex18_18_multigeneration_ocs.json").write_text(json.dumps({k: v.tolist() for k, v in res.items()}, indent=1))


if __name__ == "__main__":
    main()
