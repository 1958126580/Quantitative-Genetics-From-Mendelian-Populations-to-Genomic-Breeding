#!/usr/bin/env python3
"""习题 18.20  青年公牛与后裔测定公牛：准确度不确定、近交代价下的盈亏平衡分析

年进展 ΔG = (i_S r_S + i_D r_D)σ_A/(L_S + L_D)（习题 18.15）。近交速率（每年）由公畜与母畜的有效数量近似：
    ΔF_代 = 1/(8 N_m) + 1/(8 N_f)，ΔF_年 = ΔF_代/[(L_S + L_D)/2]；
近交衰退以 δ（每单位 F 的损失，σ_A 计）折算为年净进展  ΔG_net = ΔG − δ·ΔF_年。
(1) 青年公牛策略的盈亏平衡准确度 r*（扣除近交代价前后）；
(2) 对 r_young ~ N(r_mean, r_sd²) 的不确定性做蒙特卡洛：P(青年策略年净进展 > 后裔测定策略)、净进展分布；
(3) 对 L_S（青年公牛使用年龄）与 r 的二维网格，给出青年策略占优的区域边界。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
HERE = Path(__file__).resolve().parent


def dG(iS, rS, LS, dam, sA=1.0):
    return (iS * rS + dam["i"] * dam["r"]) * sA / (LS + dam["L"])


def dF_year(n_m, n_f, LS, LD):
    return (1 / (8 * n_m) + 1 / (8 * n_f)) / ((LS + LD) / 2)


def main():
    cfg = json.loads((HERE / "data" / "ex18_20_breakeven.json").read_text()); P, Y = cfg["progeny"], cfg["young"]
    delta, nf = cfg["delta_per_F"], cfg["females"]["n"]
    gP = dG(P["i_sire"], P["r_sire"], P["L_sire"], P["dam"]); fP = dF_year(P["n_sires_used"], nf, P["L_sire"], P["dam"]["L"])
    fY = dF_year(Y["n_sires_used"], nf, Y["L_sire"], Y["dam"]["L"]); netP = gP - delta * fP
    print(f"后裔测定：ΔG = {gP:.4f}/年，ΔF = {fP:.5f}/年，净进展 = {netP:.4f}")
    gY = dG(Y["i_sire"], Y["r_mean"], Y["L_sire"], Y["dam"]); netY = gY - delta * fY
    print(f"青年公牛（r={Y['r_mean']}）：ΔG = {gY:.4f}/年，ΔF = {fY:.5f}/年，净进展 = {netY:.4f}")
    r1 = brentq(lambda r: dG(Y["i_sire"], r, Y["L_sire"], Y["dam"]) - gP, 0.05, 0.99)
    r2 = brentq(lambda r: dG(Y["i_sire"], r, Y["L_sire"], Y["dam"]) - delta * fY - netP, 0.05, 2.0)
    print(f"盈亏平衡准确度：不计近交 r* = {r1:.3f}；计近交代价 r* = {r2:.3f}")
    rng = np.random.default_rng(cfg["seed"]); r = np.clip(rng.normal(Y["r_mean"], Y["r_sd"], cfg["n_mc"]), 0.05, 0.99)
    netYs = dG(Y["i_sire"], r, Y["L_sire"], Y["dam"]) - delta * fY
    win_g = (dG(Y["i_sire"], r, Y["L_sire"], Y["dam"]) > gP).mean(); win_n = (netYs > netP).mean()
    print(f"r ~ N({Y['r_mean']}, {Y['r_sd']}²)：P(年进展更大) = {win_g:.3f}；P(年净进展更大) = {win_n:.3f}；青年策略净进展均值 {netYs.mean():.4f}（SD {netYs.std():.4f}）")
    assert win_g >= win_n - 1e-9
    print(f"\n网格：青年公牛使用年龄 L_S 与准确度 r 下，净进展超过后裔测定的最小 r")
    print(f"{'L_S':>5s}{'r* (不计近交)':>14s}{'r* (计近交)':>12s}")
    grid = []
    for LS in (2.0, 2.6, 3.0, 3.5, 4.0, 5.0):
        fY2 = dF_year(Y["n_sires_used"], nf, LS, Y["dam"]["L"])
        a = brentq(lambda r: dG(Y["i_sire"], r, LS, Y["dam"]) - gP, 0.01, 3.0)
        b = brentq(lambda r: dG(Y["i_sire"], r, LS, Y["dam"]) - delta * fY2 - netP, 0.01, 3.0)
        grid.append(dict(LS=LS, r_noF=a, r_F=b)); print(f"{LS:5.1f}{a:14.3f}{b:12.3f}")
    (HERE / "results" / "ex18_20_young_vs_proven.json").write_text(json.dumps(dict(gP=gP, netP=netP, gY=gY, netY=netY, r_star=r1, r_star_F=r2, p_win=win_n, grid=grid), indent=1))


if __name__ == "__main__":
    main()
