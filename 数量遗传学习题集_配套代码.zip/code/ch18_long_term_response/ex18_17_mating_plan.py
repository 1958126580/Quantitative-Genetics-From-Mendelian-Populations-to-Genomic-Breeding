#!/usr/bin/env python3
"""习题 18.17  由最优贡献到配种计划：最小化后代近交的指派问题

输入：习题 18.16 的最优贡献 c（θ_max 取截断选择的 θ）。步骤：
  0. 加繁殖力上限：每头母畜至多 6 个后代；
  1. 以 N = 100 个后代，把贡献取整为每头亲本的交配次数（最大余数法，每性别之和 = N）；
  2. 公畜“槽位”与母畜“槽位”各 N 个，代价矩阵为 A[公, 母]（后代近交系数 F = ½A_sd）；
  3. 用 Hungarian 算法（scipy.optimize.linear_sum_assignment）求总近交最小的配对；
  4. 与随机配对（500 次排列的均值）和“最相似配对”（最大化 A_sd 的指派）比较：后代平均 F、最大 F、
     F > 0.0625 的后代比例、重复配对（全同胞/同一对亲本多次交配）数。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import linear_sum_assignment
from ex18_16_optimum_contribution import solve_oc, truncation
HERE = Path(__file__).resolve().parent


def largest_remainder(c_sex, N):
    x = c_sex / c_sex.sum() * N; base = np.floor(x).astype(int); rem = N - base.sum()
    base[np.argsort(-(x - base))[:rem]] += 1
    return base


def main():
    d = json.loads((HERE / "data" / "ex18_16_candidates.json").read_text())
    A = np.array(d["A"]); ebv = np.array(d["ebv"]); sex = np.array(d["sex"]); N = 100
    ct = truncation(ebv, sex, d["n_male_trunc"], d["n_female_trunc"]); th_t = 0.5 * ct @ A @ ct
    ub = np.where(sex == 0, 0.5, 0.03)                                # 每头母畜至多 6 个后代（c ≤ 6/(2N)）
    c = solve_oc(A, ebv, sex, th_t, ct, ub)
    sires = np.where(sex == 0)[0]; dams = np.where(sex == 1)[0]
    ns = largest_remainder(c[sires], N); nd = largest_remainder(c[dams], N)
    S = np.repeat(sires, ns); D = np.repeat(dams, nd)
    assert len(S) == len(D) == N
    cost = A[np.ix_(S, D)]                                          # 后代 F = A_sd / 2
    r, cidx = linear_sum_assignment(cost); Fmin = 0.5 * cost[r, cidx]
    r2, c2 = linear_sum_assignment(-cost); Fmax = 0.5 * cost[r2, c2]
    rng = np.random.default_rng(18); Frand = np.array([0.5 * cost[np.arange(N), rng.permutation(N)].mean() for _ in range(500)])
    pairs = lambda cc: len({(int(S[i]), int(D[cc[i]])) for i in range(N)})
    print(f"后代数 N = {N}：入选公畜 {len(sires[ns > 0])} 头（交配次数 {sorted(ns[ns > 0].tolist(), reverse=True)}），母畜 {len(dams[nd > 0])} 头")
    print(f"{'方案':<14s}{'平均F':>8s}{'最大F':>8s}{'F>0.0625 比例':>14s}{'不同亲本对数':>12s}")
    rows = {}
    for name, F, cc in (("最小近交配对", Fmin, cidx), ("随机配对(均值)", None, None), ("最相似配对", Fmax, c2)):
        if F is None:
            print(f"{name:<14s}{Frand.mean():8.4f}{'—':>8s}{'—':>14s}{'—':>12s}   （500 次排列的 SD = {Frand.std():.4f}）")
            rows[name] = dict(mean=float(Frand.mean()), sd=float(Frand.std()))
        else:
            print(f"{name:<14s}{F.mean():8.4f}{F.max():8.4f}{(F > 0.0625).mean():14.2f}{pairs(cc):12d}")
            rows[name] = dict(mean=float(F.mean()), max=float(F.max()), frac=float((F > 0.0625).mean()), pairs=pairs(cc))
    assert Fmin.mean() <= Frand.mean() <= Fmax.mean()
    # 理论核对：随机配对期望 = ½ Σ_i Σ_j (n_i/N)(m_j/N) A_ij
    exp_rand = 0.5 * (ns / N) @ A[np.ix_(sires, dams)] @ (nd / N)
    print(f"随机配对期望 F（解析）= {exp_rand:.4f}，与排列均值差 {abs(exp_rand - Frand.mean()):.4f}")
    assert abs(exp_rand - Frand.mean()) < 3e-3
    (HERE / "results" / "ex18_17_mating_plan.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
