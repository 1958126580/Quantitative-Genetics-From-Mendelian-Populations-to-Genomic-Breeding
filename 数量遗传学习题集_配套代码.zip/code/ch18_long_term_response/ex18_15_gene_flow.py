#!/usr/bin/env python3
"""习题 18.15  重叠世代与基因流：年遗传进展的 Rendel–Robertson 公式及其数值核对

两条选择路径（公畜、母畜亲本），每条路径内按父母年龄 a 的使用比例 w_a、选择差（以 σ_A 计）s = i·r。
子代平均育种值的递推（亲本年龄为 a 的子代出生于 t，亲本出生于 t − a）：
    G_t = ½ Σ_a w^S_a (G_{t−a} + s^S) + ½ Σ_a w^D_a (G_{t−a} + s^D)，
渐近年进展  ΔG = (s̄_S + s̄_D)/(L_S + L_D)，L = Σ w_a·a（亲本平均年龄）。
程序先用递推逐年迭代，估计末期斜率，与解析式对照；再比较四种策略的“每代进展”与“每年进展”，
给出每个策略的 L 与年进展的排序（每代进展大者未必年进展大）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


def simulate(strategy, years):
    S, D = strategy["sire"], strategy["dam"]
    maxa = max(max(S["ages"]), max(D["ages"]))
    G = np.zeros(years + maxa + 1)                                # 下标 = 出生年 + maxa（前史为 0）
    sS, sD = S["i"] * S["r"], D["i"] * D["r"]
    for t in range(maxa, years + maxa + 1):
        G[t] = 0.5 * sum(w * (G[t - a] + sS) for a, w in zip(S["ages"], S["w"])) \
             + 0.5 * sum(w * (G[t - a] + sD) for a, w in zip(D["ages"], D["w"]))
    return G[maxa:]


def analytic(strategy):
    S, D = strategy["sire"], strategy["dam"]
    LS = float(np.dot(S["ages"], S["w"])); LD = float(np.dot(D["ages"], D["w"]))
    return (S["i"] * S["r"] + D["i"] * D["r"]) / (LS + LD), LS, LD


def main():
    cfg = json.loads((HERE / "data" / "ex18_15_gene_flow.json").read_text())
    Y = cfg["years"]; print(f"{'策略':<16s}{'L_公':>6s}{'L_母':>6s}{'每代进展':>9s}{'年进展(解析)':>12s}{'年进展(递推)':>12s}{'相对仅表型':>10s}")
    rows = {}
    base = None
    for name, st in cfg["strategies"].items():
        G = simulate(st, Y); slope = np.polyfit(np.arange(Y - 20, Y + 1), G[Y - 20: Y + 1], 1)[0]
        a, LS, LD = analytic(st); gen = (st["sire"]["i"] * st["sire"]["r"] + st["dam"]["i"] * st["dam"]["r"]) / 2
        assert abs(a - slope) < 2e-3, (name, a, slope)
        rows[name] = dict(L_sire=LS, L_dam=LD, per_generation=gen, per_year=a, per_year_sim=slope)
    base = rows["仅表型选择"]["per_year"]
    for name, r in rows.items():
        print(f"{name:<14s}{r['L_sire']:6.2f}{r['L_dam']:6.2f}{r['per_generation']:9.3f}{r['per_year']:12.4f}{r['per_year_sim']:12.4f}{r['per_year'] / base:10.2f}")
    # 敏感性：青年公牛策略的准确度需要多高才能与后裔测定公牛持平
    young, prog = cfg["strategies"]["基因组青年公牛"], cfg["strategies"]["后裔测定公牛"]
    from scipy.optimize import brentq
    f = lambda r: analytic({"sire": {**young["sire"], "r": r}, "dam": young["dam"]})[0] - rows["后裔测定公牛"]["per_year"]
    r_star = brentq(f, 0.2, 0.99)
    print(f"\n青年公牛策略要与后裔测定策略年进展持平，所需的准确度 r* = {r_star:.3f}（假设强度 i = {young['sire']['i']}）")
    rows["breakeven_r"] = r_star
    (HERE / "results" / "ex18_15_gene_flow.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
