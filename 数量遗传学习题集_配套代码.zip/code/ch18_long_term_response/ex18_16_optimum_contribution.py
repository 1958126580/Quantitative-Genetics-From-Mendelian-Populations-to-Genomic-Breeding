#!/usr/bin/env python3
"""习题 18.16  最优贡献选择：在共祖约束下最大化遗传进展

候选 80 头（40 雄、40 雌），加性关系矩阵 A（候选间）与育种值估计 EBV 见数据文件。
决策变量：各候选对下一代的遗传贡献 c_j ≥ 0，雄性贡献之和 = 雌性贡献之和 = 1/2。
目标：max cᵀ EBV；约束：群体平均共祖 θ(c) = ½ cᵀ A c ≤ θ_max。
(1) 常规截断选择（取前 n_m 雄、前 n_f 雌，等贡献）的 θ 与进展；
(2) 在与截断选择相同的 θ 下的最优贡献解，以及一组 θ_max 的效率前沿；
(3) KKT 核对：对 c_j>0 的候选 EBV_j − λ_sex(j) − μ (Ac)_j = 0；对 c_j=0 的候选左端 ≤ 0。（μ 为约束 ½cᵀAc ≤ θ_max 的乘数）
用 scipy SLSQP 求解（80 个变量，初值取截断解）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import optimize
HERE = Path(__file__).resolve().parent


def truncation(ebv, sex, nm, nf):
    c = np.zeros(len(ebv))
    for s, n in ((0, nm), (1, nf)):
        idx = np.where(sex == s)[0]; top = idx[np.argsort(-ebv[idx])[:n]]; c[top] = 0.5 / n
    return c


def solve_oc(A, ebv, sex, theta_max, c0, ub=None):
    n = len(ebv); ub = np.ones(n) if ub is None else ub
    cons = [{"type": "eq", "fun": lambda c: c[sex == 0].sum() - 0.5}, {"type": "eq", "fun": lambda c: c[sex == 1].sum() - 0.5},
            {"type": "ineq", "fun": lambda c: theta_max - 0.5 * c @ A @ c, "jac": lambda c: -(A @ c)}]
    for ftol in (1e-13, 1e-11, 1e-9):                      # 逐步放宽收敛容差
        r = optimize.minimize(lambda c: -c @ ebv, c0, jac=lambda c: -ebv, bounds=[(0, u) for u in ub], constraints=cons,
                              method="SLSQP", options=dict(ftol=ftol, maxiter=1000))
        if r.success: break
    assert r.success, r.message
    return np.clip(r.x, 0, None)


def main():
    d = json.loads((HERE / "data" / "ex18_16_candidates.json").read_text())
    A = np.array(d["A"]); ebv = np.array(d["ebv"]); sex = np.array(d["sex"])
    ct = truncation(ebv, sex, d["n_male_trunc"], d["n_female_trunc"])
    th_t, g_t = 0.5 * ct @ A @ ct, ct @ ebv
    print(f"截断选择（{d['n_male_trunc']} 雄、{d['n_female_trunc']} 雌）：平均共祖 θ = {th_t:.4f}，进展（平均 EBV）= {g_t:.4f}")
    # 与截断选择相同 θ 的最优贡献
    c = solve_oc(A, ebv, sex, th_t, ct); th, g = 0.5 * c @ A @ c, c @ ebv
    print(f"最优贡献（θ_max = {th_t:.4f}）：θ = {th:.4f}，进展 = {g:.4f}（相对截断 +{100 * (g / g_t - 1):.1f}%），入选 {int((c > 1e-4).sum())} 头（雄 {int((c[sex == 0] > 1e-4).sum())}，雌 {int((c[sex == 1] > 1e-4).sum())}）")
    assert g >= g_t - 1e-8
    # KKT 核对
    Ac = A @ c; act = c > 1e-6
    # 估计乘数 λ_0, λ_1, μ：对活跃候选 EBV_j = λ_s + μ (Ac)_j（最小二乘）
    X = np.column_stack([(sex[act] == 0).astype(float), (sex[act] == 1).astype(float), Ac[act]])
    sol = np.linalg.lstsq(X, ebv[act], rcond=None)[0]; resid = np.abs(X @ sol - ebv[act]).max()
    lam0, lam1, mu = sol
    slack = ebv[~act] - np.where(sex[~act] == 0, lam0, lam1) - mu * Ac[~act]
    print(f"KKT：μ = {mu:.4f}（共祖影子价格），λ_雄 = {lam0:.4f}，λ_雌 = {lam1:.4f}；活跃候选平稳性最大残差 {resid:.2e}；非入选候选最大 EBV−λ−μ(Ac) = {slack.max():.4f}（应 ≤ 0）")
    assert resid < 1e-3 and slack.max() < 1e-3 and mu > 0
    # 前沿
    c_eq = np.where(sex == 0, 0.5 / (sex == 0).sum(), 0.5 / (sex == 1).sum())
    print(f"\n参照：全部候选等贡献（不选择）θ = {0.5 * c_eq @ A @ c_eq:.4f}，进展 = {c_eq @ ebv:.4f}")
    print(f"{'θ_max':>8s}{'进展':>9s}{'入选数':>7s}")
    front = []
    for th_max in np.linspace(th_t * 0.6, th_t * 1.8, d["n_grid"]):
        try:
            cc = solve_oc(A, ebv, sex, th_max, ct)
        except AssertionError:
            continue
        front.append(dict(theta=float(th_max), gain=float(cc @ ebv), n=int((cc > 1e-4).sum())))
        print(f"{th_max:8.4f}{cc @ ebv:9.4f}{(cc > 1e-4).sum():7d}")
    plt = None
    try:
        from _plot import get_pyplot; plt = get_pyplot()
    except Exception:
        pass
    if plt and front:
        fig, ax = plt.subplots(figsize=(5.2, 3.6))
        ax.plot([f["theta"] for f in front], [f["gain"] for f in front], "o-", label="最优贡献前沿")
        ax.plot([th_t], [g_t], "rs", label="截断选择"); ax.set_xlabel("平均共祖 θ"); ax.set_ylabel("平均 EBV"); ax.legend(); fig.tight_layout()
        fig.savefig(HERE / "results" / "ex18_16_frontier.png", dpi=150)
    (HERE / "results" / "ex18_16_optimum_contribution.json").write_text(json.dumps(dict(trunc=dict(theta=th_t, gain=g_t), oc=dict(theta=th, gain=g, mu=mu), frontier=front), indent=1))


if __name__ == "__main__":
    main()
