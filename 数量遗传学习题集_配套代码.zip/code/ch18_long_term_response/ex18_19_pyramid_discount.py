#!/usr/bin/env python3
"""习题 18.19  多层育种金字塔：基因流滞后与折现表达

核心群每年进展 g（以 σ_A 计），经扩繁群（滞后 L₁ 年）传到商品群（再滞后 L₂ 年）；商品群动物表达基因价值的
表达年数为 T_c 年（T_c 取不小于规划期的值即“遗传改良永久表达”，现值在规划期 H 处截断）。核心群第 s 年的遗传改良一个单位，到商品群时刻 t（t ≥ s + L）开始每年产生 v 单位价值，
共 T_c 年，折现因子 q = 1/(1+d)。
  折现表达  PV(s; L) = v Σ_{u=s+L}^{s+L+T_c−1, u ≤ H} q^u  （截断于规划期 H）
每个方案按“每年改良 g”持续 H 年，总现值 = Σ_{s=0}^{H−1} g·PV(s; L_tier + 额外滞后)·，扣除年成本的现值。
程序用封闭式（几何级数）与逐项求和互相核对，并比较三个方案在不同折现率下的净现值与排序。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


def pv_unit(s, lag, Tc, H, q, v=1.0):
    """逐项求和。"""
    return v * sum(q ** u for u in range(int(np.ceil(s + lag)), int(np.ceil(s + lag)) + Tc) if u <= H)


def pv_unit_closed(s, lag, Tc, H, q, v=1.0):
    a = int(np.ceil(s + lag)); b = min(a + Tc - 1, H)
    if b < a: return 0.0
    if abs(q - 1) < 1e-12: return v * (b - a + 1)
    return v * (q ** a - q ** (b + 1)) / (1 - q)


def program_value(g, lag, Tc, H, q, v, cost, ) :
    gain = sum(g * pv_unit_closed(s, lag, Tc, H, q, v) for s in range(H))
    return gain, sum(cost * q ** s for s in range(H))


def main():
    cfg = json.loads((HERE / "data" / "ex18_19_pyramid.json").read_text())
    H, Tc, v = cfg["horizon"], cfg["commercial_life"], cfg["value_per_unit"]
    lag_base = sum(t["lag"] for t in cfg["tiers"].values())
    print(f"规划期 H = {H} 年；金字塔总滞后（核心→商品）= {lag_base} 年；商品群表达 {Tc} 年；价值 {v}/单位")
    for s in (0, 5):
        for d in cfg["rates"]:
            q = 1 / (1 + d)
            assert abs(pv_unit(s, lag_base, Tc, H, q) - pv_unit_closed(s, lag_base, Tc, H, q)) < 1e-9
    print("\n折现表达（核心群第 0 年的 1 单位改良）：")
    print(f"{'折现率':>6s}" + "".join(f"{'滞后 %d 年' % L:>10s}" for L in (2, 4, 6, 8)))
    for d in cfg["rates"]:
        q = 1 / (1 + d); print(f"{d:6.2f}" + "".join(f"{pv_unit_closed(0, L, Tc, H, q, v):10.3f}" for L in (2, 4, 6, 8)))
    out = {}
    print(f"\n{'折现率':>6s}{'方案':<22s}{'现值收益':>10s}{'成本现值':>10s}{'净现值':>10s}")
    for d in cfg["rates"]:
        q = 1 / (1 + d); rows = []
        for name, p in cfg["plans"].items():
            gain, cost = program_value(p["gain_per_year"], lag_base + p["extra_lag"], Tc, H, q, v, cfg["annual_cost"][name])
            rows.append((name, gain, cost, gain - cost)); print(f"{d:6.2f}  {name:<20s}{gain:10.2f}{cost:10.2f}{gain - cost:10.2f}")
        out[str(d)] = [dict(plan=r[0], gain=r[1], cost=r[2], npv=r[3]) for r in rows]
    # 滞后的价值：每多一年滞后损失的比例
    q = 1 / (1 + 0.05); base = pv_unit_closed(0, lag_base, Tc, H, q, v); one = pv_unit_closed(0, lag_base + 1, Tc, H, q, v)
    print(f"\n5% 折现率下，金字塔每多1年滞后，单位改良的折现表达下降 {100 * (1 - one / base):.1f}%")
    (HERE / "results" / "ex18_19_pyramid_discount.json").write_text(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
