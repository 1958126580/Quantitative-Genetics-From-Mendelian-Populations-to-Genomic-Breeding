# 第18章　选择反应、世代间隔与长期遗传进展——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex18_15_gene_flow.py
python3 ex18_16_optimum_contribution.py
python3 ex18_17_mating_plan.py
python3 ex18_18_multigeneration_ocs.py
python3 ex18_19_pyramid_discount.py
python3 ex18_20_young_vs_proven.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex18_15_gene_flow.py | 18.15 | 重叠世代与基因流：年遗传进展的 Rendel–Robertson 公式及其数值核对 |
| ex18_16_optimum_contribution.py | 18.16 | 最优贡献选择：在共祖约束下最大化遗传进展 |
| ex18_17_mating_plan.py | 18.17 | 由最优贡献到配种计划：最小化后代近交的指派问题 |
| ex18_18_multigeneration_ocs.py | 18.18 | 多世代模拟：截断选择与最优贡献选择的遗传进展、近交与方差 |
| ex18_19_pyramid_discount.py | 18.19 | 多层育种金字塔：基因流滞后与折现表达 |
| ex18_20_young_vs_proven.py | 18.20 | 青年公牛与后裔测定公牛：准确度不确定、近交代价下的盈亏平衡分析 |
