#!/usr/bin/env python3
"""习题 5.20  由不同距离标记对的平均 r² 推断有效群体大小的历史

Sved 关系 E(r²) ≈ 1/(1 + 4N_e c) + 1/n（n 为样本个体数，1/n 为有限样本偏差）。
解出  N_e(c) = [1/(r̄² − 1/n) − 1] / (4c)，c 用 Haldane 函数由图距换算。
距离为 c 的 LD 主要反映约 t ≈ 1/(2c) 代以前的群体大小（Hayes 等 2003）。
程序给出各距离组的 N_e 估计及对应“世代”，并展示若忽略 1/n 校正会怎样系统性低估远距离 N_e。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def haldane_c(d_cM):
    return 0.5 * (1 - np.exp(-2 * d_cM / 100))


def main():
    cfg = json.loads((HERE / "data" / "ex05_20_ld_bins.json").read_text(encoding="utf-8"))
    n = cfg["sample_size_n"]; rows = []
    print(f"样本量 n = {n}，样本偏差 1/n = {1/n:.4f}")
    print(f"{'图距cM':>7s}{'c':>9s}{'r̄²':>8s}{'Ne(校正)':>10s}{'Ne(未校正)':>11s}{'≈世代前':>9s}")
    for b in cfg["bins"]:
        c = float(haldane_c(b["dist_cM"])); r2 = b["mean_r2"]
        ne_c = (1 / (r2 - 1 / n) - 1) / (4 * c) if r2 > 1 / n else float("inf")
        ne_u = (1 / r2 - 1) / (4 * c)
        t = 1 / (2 * c)
        rows.append({"dist_cM": b["dist_cM"], "c": c, "r2": r2, "Ne_corrected": ne_c, "Ne_uncorrected": ne_u, "generations_ago": t})
        print(f"{b['dist_cM']:7.2f}{c:9.5f}{r2:8.4f}{ne_c:10.0f}{ne_u:11.0f}{t:9.0f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex05_20_ne_from_ld.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
