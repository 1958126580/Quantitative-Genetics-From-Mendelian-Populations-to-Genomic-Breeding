# 第5章　多基因座单倍型、连锁不平衡与重组——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex05_15_haplotype_em.py
python3 ex05_16_ld_drift_recombination.py
python3 ex05_17_tag_snp.py
python3 ex05_18_haplotype_tagging.py
python3 ex05_19_admixture_ld.py
python3 ex05_20_ne_from_ld.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex05_15_haplotype_em.py | 5.15 | 由无序基因型估计单倍型频率：EM 算法、似然比检验与复合 LD |
| ex05_16_ld_drift_recombination.py | 5.16 | 漂变与重组的平衡：模拟 E(r²) 并比较 Sved 与 Ohta–Kimura 近似 |
| ex05_17_tag_snp.py | 5.17 | 单倍型块与标签 SNP 的贪婪选择 |
| ex05_18_haplotype_tagging.py | 5.18 | 单倍型为何能比单个 SNP 更好地标记致因变异 |
| ex05_19_admixture_ld.py | 5.19 | 品种混合产生的连锁不平衡及其衰减 |
| ex05_20_ne_from_ld.py | 5.20 | 由不同距离标记对的平均 r² 推断有效群体大小的历史 |
