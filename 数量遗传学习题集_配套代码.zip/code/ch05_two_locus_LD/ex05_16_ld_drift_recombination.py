#!/usr/bin/env python3
"""习题 5.16  漂变与重组的平衡：模拟 E(r²) 并比较 Sved 与 Ohta–Kimura 近似

两位点 Wright–Fisher 模拟：N 个二倍体（2N 条单倍型），每代随机交配；每个配子以概率 c 发生重组。
初始两位点均为 p = 0.5、处于连锁平衡；运行 300 代（> N），在仍多态的重复中计算
    σ_d² = E(D²) / E(p_A q_A p_B q_B)        （比值的期望，标准的 LD 理论量）
理论近似（ρ = 4Nc）：
    Sved (1971)：         E(r²) ≈ 1/(1 + ρ)
    Ohta–Kimura (1971)：  σ_d² ≈ (10 + ρ)/(22 + 13ρ + ρ²)
二者在 ρ 大时一致（≈1/ρ），在 ρ 小时 Sved 趋于 1，而 Ohta–Kimura 趋于 10/22 ≈ 0.45。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent


def simulate(N, c, R, T, rng):
    H = 2 * N
    A = rng.random((R, H)) < 0.5; B = rng.random((R, H)) < 0.5
    rows = np.arange(R)[:, None]
    for _ in range(T):
        # 选父母个体，再在个体内选两条单倍型之一；以概率 c 重组（B 位点取自另一条）
        par = rng.integers(0, N, (R, H))
        h1 = 2 * par + rng.integers(0, 2, (R, H)); h2 = h1 ^ 1
        rec = rng.random((R, H)) < c
        A_new = A[rows, h1]; B_new = np.where(rec, B[rows, h2], B[rows, h1])
        A, B = A_new, B_new
    pA, pB = A.mean(1), B.mean(1); pAB = (A & B).mean(1)
    D = pAB - pA * pB; den = pA * (1 - pA) * pB * (1 - pB)
    keep = (np.minimum(pA, 1 - pA) > 0.05) & (np.minimum(pB, 1 - pB) > 0.05)
    return float(np.mean(D[keep] ** 2) / np.mean(den[keep])), float(np.mean(D[keep] ** 2 / den[keep])), int(keep.sum())


def main():
    cfg = json.loads((HERE / "data" / "ex05_16_ld_drift.json").read_text(encoding="utf-8"))
    N, R, T = cfg["N"], cfg["reps"], cfg["generations"]; rng = np.random.default_rng(cfg["seed"]); rows = []
    print(f"N = {N}，{T} 代后（MAF>0.05 的重复）")
    print(f"{'c':>7s}{'ρ=4Nc':>7s}{'σd²模拟':>9s}{'E(r²)模拟':>10s}{'Sved':>8s}{'Ohta-Kimura':>12s}{'有效重复':>8s}")
    for c in cfg["c_values"]:
        sd2, r2, k = simulate(N, c, R, T, rng); rho = 4 * N * c
        sved = 1 / (1 + rho); ok = (10 + rho) / (22 + 13 * rho + rho ** 2)
        rows.append({"c": c, "rho": rho, "sigma_d2_sim": sd2, "r2_sim": r2, "sved": sved, "ohta_kimura": ok, "n_poly": k})
        print(f"{c:7.4f}{rho:7.1f}{sd2:9.4f}{r2:10.4f}{sved:8.4f}{ok:12.4f}{k:8d}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex05_16_ld_drift_recombination.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    plt = get_pyplot()
    if plt:
        rho = np.array([r["rho"] for r in rows]); grid = np.logspace(-1.5, 1.7, 100)
        fig, ax = plt.subplots(figsize=(6, 3.8))
        ax.plot(rho, [r["sigma_d2_sim"] for r in rows], "o", label="模拟 σd²")
        ax.plot(grid, 1 / (1 + grid), label="Sved 1/(1+ρ)")
        ax.plot(grid, (10 + grid) / (22 + 13 * grid + grid ** 2), label="Ohta–Kimura")
        ax.set_xscale("log"); ax.set_xlabel("ρ = 4Nc"); ax.set_ylabel("LD"); ax.legend(); fig.tight_layout()
        fig.savefig(HERE / "results" / "ex05_16_ld_decay.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    main()
