#!/usr/bin/env python3
"""习题 5.19  品种混合产生的连锁不平衡及其衰减

两个各自处于连锁平衡的群体以 m : (1−m) 混合（两位点不论是否连锁）：
    D_0 = m(1−m)(p_A1 − p_A2)(p_B1 − p_B2)
此后随机交配，D_t = (1−c)^t D_0；不连锁（c = 0.5）时每代减半，连锁时衰减很慢。
注意：混合后第一代合子由“两个混合配子”结合；本程序在配子层面模拟，严格对应 D_t = (1−c)^t D_0。
程序同时用有限群体（N 个二倍体）模拟核对，并说明“混合 LD”可以被关联分析误认为连锁信号。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex05_19_admixture.json").read_text(encoding="utf-8"))
    m = cfg["m"]; a1, b1 = cfg["pop1"]["pA"], cfg["pop1"]["pB"]; a2, b2 = cfg["pop2"]["pA"], cfg["pop2"]["pB"]
    D0 = m * (1 - m) * (a1 - a2) * (b1 - b2)
    pA = m * a1 + (1 - m) * a2; pB = m * b1 + (1 - m) * b2
    r2_0 = D0 ** 2 / (pA * (1 - pA) * pB * (1 - pB))
    print(f"混合后 p_A = {pA:.3f}, p_B = {pB:.3f}, D_0 = {D0:.4f}, r²_0 = {r2_0:.4f}")
    rng = np.random.default_rng(cfg["seed"]); N = cfg["N_sim"]; T = cfg["generations"]; out = {"D0": D0, "r2_0": r2_0, "c": {}}
    for c in cfg["c_values"]:
        theo = [D0 * (1 - c) ** t for t in range(T + 1)]
        sims = np.zeros(T + 1)
        for _ in range(cfg["reps"] // 20):
            n1 = int(round(2 * N * m))
            A = np.concatenate([rng.random(n1) < a1, rng.random(2 * N - n1) < a2])
            B = np.concatenate([rng.random(n1) < b1, rng.random(2 * N - n1) < b2])
            perm = rng.permutation(2 * N); A, B = A[perm], B[perm]      # 混合配子随机结合成个体
            for t in range(T + 1):
                sims[t] += np.mean(A & B) - A.mean() * B.mean()
                par = rng.integers(0, N, 2 * N); h1 = 2 * par + rng.integers(0, 2, 2 * N); h2 = h1 ^ 1
                rec = rng.random(2 * N) < c
                A, B = A[h1], np.where(rec, B[h2], B[h1])
        sims /= cfg["reps"] // 20
        half = np.log(0.5) / np.log(1 - c)
        out["c"][str(c)] = {"theory": theo, "sim": sims.tolist(), "half_life": half}
        print(f"c = {c:5.2f}：D_5 理论 {theo[5]:.4f} 模拟 {sims[5]:.4f}；D_20 理论 {theo[20]:.4f} 模拟 {sims[20]:.4f}；半衰期 {half:.1f} 代")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex05_19_admixture_ld.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
