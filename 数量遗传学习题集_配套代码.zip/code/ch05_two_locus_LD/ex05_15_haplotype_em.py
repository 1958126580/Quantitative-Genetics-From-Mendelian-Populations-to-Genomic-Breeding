#!/usr/bin/env python3
"""习题 5.15  由无序基因型估计单倍型频率：EM 算法、似然比检验与复合 LD

九种两位点基因型中，只有双杂合子 AaBb 的相位未知：可能是 AB/ab（相引）或 Ab/aB（相斥）。
E 步：P(相引 | AaBb) = p_AB p_ab / (p_AB p_ab + p_Ab p_aB)
M 步：单倍型频率 = (确定计数 + 期望计数) / 2N
输出：单倍型频率、D、D′、r²，检验 D = 0 的似然比统计量（1 自由度）；
并与 Weir 复合连锁不平衡 Δ_AB（不需 HWE、不需相位）比较。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import chi2

HERE = Path(__file__).resolve().parent
# 每种基因型 (iA, iB) 中确定的单倍型贡献：iA,iB ∈ {0: 纯合大写, 1: 杂合, 2: 纯合小写}
# 单倍型顺序 AB, Ab, aB, ab


def fixed_counts(n):
    h = np.zeros(4)
    hapA = {0: ["A", "A"], 2: ["a", "a"]}; hapB = {0: ["B", "B"], 2: ["b", "b"]}
    idx = {"AB": 0, "Ab": 1, "aB": 2, "ab": 3}
    for i in range(3):
        for j in range(3):
            c = n[i][j]
            if i == 1 and j == 1: continue
            if i != 1 and j != 1:
                for a, b in zip(hapA[i], hapB[j]): h[idx[a + b]] += c
            elif i == 1:   # Aa 且 B 纯合
                b = hapB[j][0]; h[idx["A" + b]] += c; h[idx["a" + b]] += c
            else:          # A 纯合且 Bb
                a = hapA[i][0]; h[idx[a + "B"]] += c; h[idx[a + "b"]] += c
    return h


def loglik(f, n):
    pAB, pAb, paB, pab = f
    pA = {0: None}
    # 基因型概率（HWE 下两条单倍型独立）
    hap = {"AB": pAB, "Ab": pAb, "aB": paB, "ab": pab}
    def g(i, j):
        As = {0: "AA", 1: "Aa", 2: "aa"}[i]; Bs = {0: "BB", 1: "Bb", 2: "bb"}[j]
        tot = 0.0
        for h1 in hap:
            for h2 in hap:
                if sorted(h1[0] + h2[0]) == sorted(As) and sorted(h1[1] + h2[1]) == sorted(Bs):
                    tot += hap[h1] * hap[h2]
        return tot
    return float(sum(n[i][j] * np.log(g(i, j)) for i in range(3) for j in range(3) if n[i][j] > 0))


def em(n, tol=1e-12):
    N = np.sum(n); h0 = fixed_counts(n); dh = n[1][1]
    f = np.full(4, 0.25)
    for it in range(10000):
        w = f[0] * f[3] / (f[0] * f[3] + f[1] * f[2])
        new = (h0 + dh * np.array([w, 1 - w, 1 - w, w])) / (2 * N)
        if np.max(np.abs(new - f)) < tol: f = new; break
        f = new
    return f, w, it + 1


def ld_stats(f):
    pA, pB = f[0] + f[1], f[0] + f[2]; D = f[0] * f[3] - f[1] * f[2]
    Dmax = min(pA * (1 - pB), (1 - pA) * pB) if D > 0 else min(pA * pB, (1 - pA) * (1 - pB))
    return pA, pB, D, D / Dmax, D * D / (pA * (1 - pA) * pB * (1 - pB))


def composite(n):
    """Weir 复合 LD：用剂量协方差（AA=2…）计算 Δ = Cov(x_A, x_B)/2 的样本估计。"""
    xs, ys, w = [], [], []
    for i in range(3):
        for j in range(3):
            xs.append(2 - i); ys.append(2 - j); w.append(n[i][j])
    xs, ys, w = map(np.asarray, (xs, ys, w)); N = w.sum()
    mx, my = (w * xs).sum() / N, (w * ys).sum() / N
    return float((w * (xs - mx) * (ys - my)).sum() / N / 2 * N / (N - 1))


def main():
    cfg = json.loads((HERE / "data" / "ex05_15_genotypes.json").read_text(encoding="utf-8"))
    n = cfg["counts"]; N = int(np.sum(n))
    f, w, it = em(n)
    pA, pB, D, Dp, r2 = ld_stats(f)
    f0 = np.array([pA * pB, pA * (1 - pB), (1 - pA) * pB, (1 - pA) * (1 - pB)])
    lrt = 2 * (loglik(f, n) - loglik(f0, n))
    delta = composite(n)
    print(f"N = {N}，双杂合子 {n[1][1]} 只；EM 迭代 {it} 次，P(相引|AaBb) = {w:.4f}")
    print("单倍型频率 AB, Ab, aB, ab =", np.round(f, 4))
    print(f"p_A = {pA:.4f}, p_B = {pB:.4f}, D = {D:.4f}, D′ = {Dp:.4f}, r² = {r2:.4f}")
    print(f"检验 D = 0（无序基因型）：LRT = {lrt:.3f}，p = {chi2.sf(lrt,1):.2e}")
    print(f"对照：若 2N = {2*N} 个配子相位已知，χ² ≈ 2N·r² = {2*N*r2:.3f}；无序基因型约为 N·r² = {N*r2:.3f}")
    # D = 0 处每只个体的 Fisher 信息：相位已知 vs 无序基因型（数值微分）
    def info(D):
        e = 1e-6
        def probs(d):
            fh = np.array([pA*pB+d, pA*(1-pB)-d, (1-pA)*pB-d, (1-pA)*(1-pB)+d]); names = ["AB","Ab","aB","ab"]; P = {}
            for i, h1 in enumerate(names):
                for j, h2 in enumerate(names):
                    g = ("".join(sorted(h1[0]+h2[0])), "".join(sorted(h1[1]+h2[1]))); P[g] = P.get(g, 0) + fh[i]*fh[j]
            return fh, P
        f1, P1 = probs(D+e); f0, P0 = probs(D-e); fm, Pm = probs(D)
        Ig = 2*np.sum(((f1-f0)/(2*e))**2/fm); Igen = sum(((P1[k]-P0[k])/(2*e))**2/Pm[k] for k in Pm)
        return Ig, Igen
    I0 = info(0.0); I1 = info(D)
    print(f"每只个体关于 D 的 Fisher 信息：D=0 处 相位已知 {I0[0]:.2f}，无序基因型 {I0[1]:.2f}（比值 {I0[1]/I0[0]:.3f}）；"
          f"D=D̂ 处比值 {I1[1]/I1[0]:.3f}")
    print(f"复合 LD Δ_AB = {delta:.4f}（HWE 下应接近 D）")
    out = {"hap_freq": f.tolist(), "w_coupling": w, "pA": pA, "pB": pB, "D": D, "Dprime": Dp, "r2": r2, "lrt": lrt, "composite_delta": delta,
           "info_ratio_D0": I0[1] / I0[0], "info_ratio_Dhat": I1[1] / I1[0]}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex05_15_haplotype_em.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
