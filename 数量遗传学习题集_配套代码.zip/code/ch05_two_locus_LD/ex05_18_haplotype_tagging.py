#!/usr/bin/env python3
"""习题 5.18  单倍型为何能比单个 SNP 更好地标记致因变异

给定祖先单倍型及频率（致因变异 Q 只出现在单倍型 101 上），计算：
    1. 每个单标记与 Q 的 D、r²；
    2. 两标记组合单倍型、三标记单倍型指示变量与 Q 的 r²；
    3. 用全部单倍型指示变量对 Q 做最佳线性预测时解释的 Q 方差比例（= 多元 R²）；
    4. 若 Q 的加性效应为 a，各种标记方案在配子水平可解释的加性方差 r² · a² p_Q q_Q。
"""
from __future__ import annotations
import json
from itertools import combinations
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def r2_binary(x, q, w):
    px = w @ x; pq = w @ q; pxq = w @ (x * q)
    D = pxq - px * pq
    return float(D ** 2 / (px * (1 - px) * pq * (1 - pq))) if 0 < px < 1 else 0.0, float(D)


def main():
    cfg = json.loads((HERE / "data" / "ex05_18_haplotypes.json").read_text(encoding="utf-8"))
    M = np.array([h["M"] for h in cfg["haplotypes"]]); Q = np.array([h["Q"] for h in cfg["haplotypes"]], float)
    w = np.array([h["freq"] for h in cfg["haplotypes"]]); assert np.isclose(w.sum(), 1)
    a = cfg["qtl_effect_a"]; pQ = w @ Q; VQ = a * a * pQ * (1 - pQ)
    out = {"pQ": pQ, "single": {}, "pairs": {}, "triple": None}
    print(f"致因变异频率 p_Q = {pQ:.3f}；配子水平 Q 方差 a²pq = {VQ:.4f}")
    for j in range(3):
        r2, D = r2_binary(M[:, j].astype(float), Q, w)
        out["single"][f"M{j+1}"] = {"freq": float(w @ M[:, j]), "D": D, "r2": r2}
        print(f"  单标记 M{j+1}：频率 {w @ M[:, j]:.2f}，D = {D:+.4f}，r² = {r2:.4f}")
    for j, k in combinations(range(3), 2):
        best = (0, None)
        for pat in ((0, 0), (0, 1), (1, 0), (1, 1)):
            x = ((M[:, j] == pat[0]) & (M[:, k] == pat[1])).astype(float)
            r2, _ = r2_binary(x, Q, w)
            if r2 > best[0]: best = (r2, pat)
        out["pairs"][f"M{j+1}M{k+1}"] = {"best_haplotype": "".join(map(str, best[1])), "r2": best[0]}
        print(f"  双标记 M{j+1}M{k+1}：最佳单倍型 {''.join(map(str, best[1]))}，r² = {best[0]:.4f}")
    x = np.all(M == [1, 0, 1], axis=1).astype(float); r2t, _ = r2_binary(x, Q, w)
    out["triple"] = r2t; print(f"  三标记单倍型 101 指示变量：r² = {r2t:.4f}")
    # 加性回归在三个单标记上的多元 R²
    X = np.column_stack([np.ones(len(w)), M]); W = np.diag(w)
    beta = np.linalg.solve(X.T @ W @ X, X.T @ W @ Q); fit = X @ beta
    R2 = float(w @ (fit - pQ) ** 2 / (pQ * (1 - pQ)))
    print(f"  三个单标记的加性多元回归 R² = {R2:.4f}（单倍型不是标记的线性函数时，加性回归也无法完全捕获）")
    out["multi_snp_additive_R2"] = R2
    print("可解释的配子水平加性方差：", {k: round(float(v["r2"] * VQ), 4) for k, v in out["single"].items()}, "单倍型:", round(float(r2t * VQ), 4))
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex05_18_haplotype_tagging.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
