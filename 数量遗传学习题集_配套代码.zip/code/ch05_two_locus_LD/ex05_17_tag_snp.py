#!/usr/bin/env python3
"""习题 5.17  单倍型块与标签 SNP 的贪婪选择

资料：200 条单倍型 × 18 个 SNP（三个单倍型块，块内由少数祖先单倍型构成，另有 2% 噪声）。
    1. 计算全部 SNP 对的 r² 矩阵与 |D′| 矩阵，观察块状结构；
    2. 贪婪算法（Carlson 等 2004）：每次选能“覆盖”（r² ≥ 阈值）最多尚未覆盖 SNP 的位点；
    3. 比较阈值 0.8 与 0.5 下的标签数，及每个 SNP 被最佳标签捕获的最大 r²。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def ld_matrices(H):
    p = H.mean(0); m = H.shape[1]
    P11 = (H.T @ H) / H.shape[0]
    D = P11 - np.outer(p, p)
    r2 = D ** 2 / np.outer(p * (1 - p), p * (1 - p))
    Dmax = np.where(D > 0, np.minimum(np.outer(p, 1 - p), np.outer(1 - p, p)), np.minimum(np.outer(p, p), np.outer(1 - p, 1 - p)))
    Dp = np.abs(D) / Dmax
    np.fill_diagonal(Dp, 1.0)
    return r2, Dp


def greedy_tags(r2, thr):
    m = r2.shape[0]; uncovered = set(range(m)); tags = []
    while uncovered:
        best = max(range(m), key=lambda j: (sum(r2[j, k] >= thr for k in uncovered), -j))
        tags.append(best); uncovered -= {k for k in uncovered if r2[best, k] >= thr}
    return tags


def main():
    H = np.loadtxt(HERE / "data" / "ex05_17_haplotypes.csv", delimiter=",", skiprows=1).astype(int)
    r2, Dp = ld_matrices(H)
    print("r² 矩阵（×100，取整）：")
    for row in (r2 * 100).round().astype(int): print(" ".join(f"{v:3d}" for v in row))
    out = {"r2": r2.round(4).tolist(), "Dprime": Dp.round(4).tolist()}
    for thr in (0.8, 0.5):
        tags = greedy_tags(r2, thr)
        cover = r2[np.ix_(tags, range(r2.shape[0]))].max(0)
        print(f"阈值 r² ≥ {thr}：标签 SNP = {[f'S{t+1}' for t in tags]}（{len(tags)} 个 / 18）；平均最大 r² = {cover.mean():.3f}，最小 = {cover.min():.3f}")
        out[f"tags_{thr}"] = {"tags": [int(t) + 1 for t in tags], "mean_max_r2": float(cover.mean()), "min_max_r2": float(cover.min())}
    # 块间 vs 块内 LD
    blocks = [range(0, 6), range(6, 13), range(13, 18)]
    within = np.mean([r2[i, j] for b in blocks for i in b for j in b if i < j])
    between = np.mean([r2[i, j] for a in range(3) for b in range(a + 1, 3) for i in blocks[a] for j in blocks[b]])
    print(f"块内平均 r² = {within:.3f}，块间平均 r² = {between:.3f}")
    out.update({"within_block_r2": within, "between_block_r2": between})
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex05_17_tag_snp.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
