# 《数量遗传学习题集》配套程序

梅步俊 著。本目录是习题集全部程序题的配套代码：共 223 个 Python 3 程序，按章分文件夹，与书稿分离。

## 目录结构

```
code/
├── README.md            本文件
├── requirements.txt     依赖（numpy、scipy、matplotlib）
├── run_all.py           一键运行全部程序并报告结果
├── ch01_.../            每章一个文件夹
│   ├── README.md        本章程序说明
│   ├── _plot.py         绘图辅助
│   ├── data/            输入数据（json）
│   ├── results/         程序输出（json、png）
│   └── exNN_kk_*.py     程序，NN 为章号，kk 为习题号
```

## 使用方法

```
pip install -r requirements.txt
python3 run_all.py            # 运行全部（约十余分钟）
python3 run_all.py 5 12      # 只运行第 5、12 章
python3 run_all.py -j 2      # 并行
```

也可以进入某章文件夹，直接运行单个程序，例如：

```
cd ch12_relationship_inbreeding
python3 ex12_16_*.py
```

## 约定

- 每个程序的文档字符串第一行形如“习题 N.k 标题”，对应书中同号习题。
- 随机数种子固定，结果可复现；每个程序运行时间不超过一分钟。
- 程序读取同章 `data/` 中的数据，输出中文报告，并把结果写入 `results/`。
- 每个程序含独立的 assert 核验（解析值对模拟值、恒等式、界等），失败时中止。
- 数据均为教学构造，不代表任何真实群体的参数。

## 章目录

| 章 | 文件夹 | 章名 |
|:--:|:--|:--|
| 1 | ch01_probability_prediction | 概率、期望与遗传预测问题 |
| 2 | ch02_matrix_computation | 矩阵方法与稳定计算 |
| 3 | ch03_statistical_inference | 统计推断、似然与数量遗传学方法 |
| 4 | ch04_single_locus_population | 单基因座群体模型与等位基因频率的演变 |
| 5 | ch05_two_locus_LD | 多基因座单倍型、连锁不平衡与重组 |
| 6 | ch06_linkage_maps | 遗传连锁与连锁图谱的构建 |
| 7 | ch07_qtl_mapping_crosses | 杂交群体的数量性状位点定位 |
| 8 | ch08_outbred_mapping_gwas | 远交群体的连锁分析、关联定位与全基因组关联研究 |
| 9 | ch09_genetic_values_variance | 数量遗传与群体依赖性 |
| 10 | ch10_variance_components | 遗传方差组分、重复力与性状间相关 |
| 11 | ch11_resemblance_relatives | 亲属间的相似性与遗传协方差 |
| 12 | ch12_relationship_inbreeding | 系谱亲缘、近交与遗传连接 |
| 13 | ch13_parameter_estimation | 遗传参数的经典估计方法与试验设计 |
| 14 | ch14_selection_response | 选择反应的数量遗传理论 |
| 15 | ch15_selection_index | 单性状选择指数与信息融合 |
| 16 | ch16_breeding_objectives | 多性状育种目标与经济权重 |
| 17 | ch17_restricted_index | 限制指数、非线性目标与稳健决策 |
| 18 | ch18_long_term_response | 选择反应、世代间隔与长期遗传进展 |
| 19 | ch19_drift_ne_inbreeding | 遗传漂变、有效群体大小与近交 |
| 20 | ch20_heterosis_crossbreeding | 杂种优势、配合力与杂交育种体系 |
| 21 | ch21_blup | 从最小二乘到最佳线性无偏预测 |
| 22 | ch22_animal_model | 动物模型与复杂遗传效应 |
| 23 | ch23_variance_components | 方差组分、限制似然与贝叶斯推断 |
| 24 | ch24_multitrait_threshold_survival | 多性状、阈值、生存与纵向遗传模型 |
| 25 | ch25_genomic_heritability | 基因组时代的遗传力 |
| 26 | ch26_qc_grm | 基因型质量控制与基因组关系矩阵 |
| 27 | ch27_genomic_prediction_models | GBLUP、岭回归、贝叶斯与核方法 |
| 28 | ch28_single_step | 单步基因组评定 |
| 29 | ch29_validation | 验证设计、准确性、校准与跨群体迁移 |
| 30 | ch30_sequence_sv_rare | 全基因组序列、泛基因组、结构变异与稀有变异 |
| 31 | ch31_multiomics_causal | 多组学、功能先验与因果推断 |
| 32 | ch32_gxe_resilience | 基因型×环境、韧性与可持续育种 |
| 33 | ch33_deep_foundation | 深度学习与基因组基础模型 |
| 34 | ch34_reproducible_evaluation | 数据字典到可重复评定 |
| 35 | ch35_blup_gblup_lab | 从系谱 BLUP 到 GBLUP：一个可复算的肉羊教学实验 |
| 36 | ch36_multitrait_mating | 多性状目标与约束配种的完整决策算例 |
| 37 | ch37_diagnostics_design | 模型诊断、失败分析与可检验的研究设计 |
