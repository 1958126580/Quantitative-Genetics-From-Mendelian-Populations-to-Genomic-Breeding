# 第36章　多性状目标与约束配种的完整决策算例——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex36_15_economic_scenarios.py
python3 ex36_16_optimal_contribution.py
python3 ex36_17_mating_transport.py
python3 ex36_18_integer_rounding.py
python3 ex36_19_uncertainty_risk.py
python3 ex36_20_forbidden_feasibility.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex36_15_economic_scenarios.py | 36.15 | 经济权重情景：同一批 EBV，不同目标给出不同的亲本集合与各性状响应 |
| ex36_16_optimal_contribution.py | 36.16 | 最优贡献选择：同一群体共祖下，比"等份额截留"多得多少遗传进展 |
| ex36_17_mating_transport.py | 36.17 | 配种分配是运输问题：把整数后代数分配到公母配对，使后代的期望近交最小 |
| ex36_18_integer_rounding.py | 36.18 | 整数后代数怎样改变连续贡献前沿：取整的收益损失与约束违反随 N 的变化 |
| ex36_19_uncertainty_risk.py | 36.19 | EBV 的不确定性与均值—方差权衡：下尾风险、机会约束 |
| ex36_20_forbidden_feasibility.py | 36.20 | 禁配网络的可行性与运输问题的对偶证据 |
