#!/usr/bin/env python3
"""习题 36.15  经济权重情景：同一批 EBV，不同目标给出不同的亲本集合与各性状响应

200 个随机候选群体（16 只，6 公 10 母，三性状，多性状 BLUP）。对"生长优先 / 繁殖优先 / 均衡"三套经济权重，
计算综合指数 I=wᵀEBV，截留选择（前 3 公、前 5 母，等份额）；用已知的真实育种值核验各性状的实现响应
（亲本均值，公母各占一半）与 EBV 预测的响应，并报告：
(1) 各情景的预测与实现响应；(2) 所选亲本集合的重叠（Jaccard）与指数排名的 Spearman 相关；
(3) 综合目标 H=wᵀu 的实现值；(4) 单位检验：把性状 1 的单位乘 10、权重除以 10，选择结果不变；权重整体乘常数，选择不变。
断言：各情景的预测响应与实现响应的差（均值）小于 0.05（BLUP 无偏）；生长优先的生长响应 > 繁殖优先的生长响应；
繁殖优先的繁殖响应 > 生长优先的繁殖响应；各情景在 H 上自评最高（本情景权重下 H 实现值最高）；单位检验 200 次全部一致。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _oc import load_pop, make_candidates, truncation

HERE = Path(__file__).resolve().parent


def rank_corr(a, b):
    return np.corrcoef(np.argsort(np.argsort(a)), np.argsort(np.argsort(b)))[0, 1]


def main():
    pop = load_pop(); cfg = json.loads((HERE / "data" / "ex36_15_config.json").read_text(encoding="utf-8"))
    sc = pop["scenarios"]; names = list(sc); tn = pop["trait_names"]
    pred = {s: [] for s in names}; real = {s: [] for s in names}; H = {s: {t: [] for t in names} for s in names}
    jac = {}; sp = {}; unit_ok = 0
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = make_candidates(rng, pop); sel = {}
        for s in names:
            w = np.array(sc[s]); g = d["ebv"] @ w
            c = truncation(g, d["sex"], cfg["n_sel_m"], cfg["n_sel_f"]); sel[s] = c > 0
            pred[s].append(c @ d["ebv"]); real[s].append(c @ d["u"])
            for t in names:
                H[s][t].append(c @ (d["u"] @ np.array(sc[t])))
        for i, a in enumerate(names):
            for b in names[i + 1:]:
                jac.setdefault((a, b), []).append((sel[a] & sel[b]).sum() / (sel[a] | sel[b]).sum())
                sp.setdefault((a, b), []).append(rank_corr(d["ebv"] @ np.array(sc[a]), d["ebv"] @ np.array(sc[b])))
        # 单位检验
        w = np.array(sc["均衡"]); scl = np.array(cfg["unit_scale"])
        c1 = truncation(d["ebv"] @ w, d["sex"], cfg["n_sel_m"], cfg["n_sel_f"])
        c2 = truncation((d["ebv"] * scl) @ (w / scl), d["sex"], cfg["n_sel_m"], cfg["n_sel_f"])
        c3 = truncation(d["ebv"] @ (7.3 * w), d["sex"], cfg["n_sel_m"], cfg["n_sel_f"])
        unit_ok += int(np.allclose(c1, c2) and np.allclose(c1, c3))
    print(f"重复 {cfg['reps']} 次；每次截留：前 {cfg['n_sel_m']} 公 + 前 {cfg['n_sel_f']} 母，等份额")
    print(f"{'情景':<8}" + "".join(f"{t}预测 {t}实现 " for t in tn))
    out = {}
    for s in names:
        P = np.mean(pred[s], 0); R = np.mean(real[s], 0)
        print(f"{s:<8}" + "".join(f"{P[k]:>7.3f}{R[k]:>8.3f}  " for k in range(3)))
        out[s] = dict(pred=P.tolist(), real=R.tolist(), H={t: float(np.mean(H[s][t])) for t in names})
    print("\n综合目标 H=wᵀu 的实现值（行=所用选择情景，列=评价所用权重）")
    print(f"{'':<8}" + "".join(f"{t:>8}" for t in names))
    for s in names:
        print(f"{s:<8}" + "".join(f"{np.mean(H[s][t]):>8.3f}" for t in names))
    print("\n情景间亲本集合 Jaccard 重叠与指数排名 Spearman 相关：")
    for k in jac:
        print(f"  {k[0]} vs {k[1]}：重叠 {np.mean(jac[k]):.3f}，排名相关 {np.mean(sp[k]):.3f}")
    print(f"\n单位与整体缩放检验：{unit_ok}/{cfg['reps']} 次选择完全一致")
    out["jaccard"] = {f"{a}|{b}": float(np.mean(v)) for (a, b), v in jac.items()}
    out["spearman"] = {f"{a}|{b}": float(np.mean(v)) for (a, b), v in sp.items()}
    for s in names:
        assert np.max(np.abs(np.mean(pred[s], 0) - np.mean(real[s], 0))) < 0.05
        assert all(np.mean(H[s][s]) >= np.mean(H[o][s]) - 0.005 for o in names)
    assert np.mean(real["生长优先"], 0)[0] > np.mean(real["繁殖优先"], 0)[0]
    assert np.mean(real["繁殖优先"], 0)[1] > np.mean(real["生长优先"], 0)[1]
    assert unit_ok == cfg["reps"]
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex36_15_economic_scenarios.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
