#!/usr/bin/env python3
"""习题 36.16  最优贡献选择：同一群体共祖下，比"等份额截留"多得多少遗传进展

问题：max gᵀc，s.t. 公、母份额各 0.5，c≥0，θ=½cᵀAc ≤ θ_max。g 为"均衡"权重下的指数 EBV。
(1) 以等份额截留（前 3 公、前 5 母）的 θ 作为约束上限，求最优贡献，比较 gᵀc（预测）与实现的真实 H（wᵀu）；
(2) KKT 核验：支撑集上 g_i = λ(Ac)_i + μ_sex(i)（最小二乘残差应≈0），零份额个体余量 ≤0；λ≥0；
(3) 随机扰动核验：在可行域内围绕解随机扰动 4000 次，没有一次得到更高的 gᵀc；
(4) 前沿：θ_max 从最小可行值到无约束，gᵀc 单调不降且为凹函数（差分检查）；
(5) 支撑集大小与最大份额。
断言：最优 gᵀc 不低于截留的值（差>0，平均）；KKT 残差 <1e-4 且余量 ≤1e-5；λ>0（约束起作用）；扰动无改进；前沿单调凹。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _oc import load_pop, make_candidates, truncation, theta, solve_oc, kkt_multipliers

HERE = Path(__file__).resolve().parent


def main():
    pop = load_pop(); cfg = json.loads((HERE / "data" / "ex36_16_config.json").read_text(encoding="utf-8"))
    w = np.array(pop["scenarios"][cfg["scenario"]])
    gains = []; gt = []; Hr = []; Ht = []; lam_l = []; kres = []; kslk = []; supp = []; cmax = []; th_t = []; th_o = []
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = make_candidates(rng, pop); g = d["ebv"] @ w; A = d["A"]; sex = d["sex"]
        ct = truncation(g, sex, cfg["n_sel_m"], cfg["n_sel_f"]); tmax = theta(ct, A)
        c, res = solve_oc(g, A, sex, tmax)
        gains.append(g @ c); gt.append(g @ ct)
        Hr.append(c @ (d["u"] @ w)); Ht.append(ct @ (d["u"] @ w)); th_t.append(tmax); th_o.append(theta(c, A))
        lam, mm, mf, kr, slack = kkt_multipliers(g, A, sex, c)
        lam_l.append(lam); kres.append(kr); kslk.append(slack.max() if len(slack) else -1.0)
        supp.append((c > 1e-6).sum()); cmax.append(c.max())
        if r == 0:
            # 扰动核验
            best = g @ c; better = 0
            for _ in range(cfg["perturb_trials"]):
                z = c + rng.normal(0, 0.03, len(c)) * (rng.random(len(c)) < 0.5)
                z = np.clip(z, 0, None)
                for s in (0, 1):
                    m = sex == s
                    if z[m].sum() <= 0: z[m] = 1.0
                    z[m] *= 0.5 / z[m].sum()
                if theta(z, A) <= tmax + 1e-9 and g @ z > best + 1e-9:
                    better += 1
            # 前沿
            lo = theta(truncation(np.zeros_like(g), sex, 6, 10), A)    # 全体等份额的 θ（近似最小）
            ths = np.linspace(lo * 1.001, theta(solve_oc(g, A, sex, 10.0)[0], A), cfg["frontier_points"])
            fr = [g @ solve_oc(g, A, sex, t)[0] for t in ths]
            frontier = (ths.tolist(), fr); perturb_better = better
    M = lambda x: float(np.mean(x))
    print(f"重复 {cfg['reps']} 次；情景“{cfg['scenario']}”，截留 3 公 + 5 母；θ 以截留的值为上限")
    print(f"预测遗传水平 gᵀc：截留 {M(gt):.3f} → 最优贡献 {M(gains):.3f}（+{M(gains)-M(gt):.3f}）")
    print(f"实现的真实 H：截留 {M(Ht):.3f} → 最优贡献 {M(Hr):.3f}")
    print(f"群体共祖 θ：截留 {M(th_t):.4f}，最优 {M(th_o):.4f}")
    print(f"支撑集大小均值 {M(supp):.1f}（截留为 8），最大份额均值 {M(cmax):.3f}；乘子 λ 均值 {M(lam_l):.3f}")
    print(f"KKT：支撑集残差范数最大 {np.max(kres):.2e}，零份额个体余量最大 {np.max(kslk):.2e}")
    print(f"随机扰动核验（第 1 次重复）：{cfg['perturb_trials']} 次可行扰动中改进 {perturb_better} 次")
    print("前沿（θ_max → gᵀc，第 1 次重复）：" + "；".join(f"{a:.4f}→{b:.3f}" for a, b in zip(*frontier)))
    fr = np.array(frontier[1]); ths = np.array(frontier[0])
    assert M(gains) > M(gt) + 0.01
    assert np.max(kres) < 1e-4 and np.max(kslk) < 1e-5
    assert M(lam_l) > 0
    assert perturb_better == 0
    assert np.all(np.diff(fr) >= -1e-9)
    sl = np.diff(fr) / np.diff(ths); assert np.all(np.diff(sl) <= 1e-6 * (1 + np.abs(sl).max()))
    out = dict(g_trunc=M(gt), g_opt=M(gains), H_trunc=M(Ht), H_opt=M(Hr), theta_trunc=M(th_t), theta_opt=M(th_o), support=M(supp), cmax=M(cmax), lam=M(lam_l), frontier=frontier)
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex36_16_optimal_contribution.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
