#!/usr/bin/env python3
"""习题 36.20  禁配网络的可行性与运输问题的对偶证据

在习题 36.17 的运输问题上增加禁配：A_sd ≥ 阈值的公母不得交配（0.5=全同胞，0.25=半同胞及更近）。
(1) 可行性：用最大流判断是否存在满足行列和的配种方案；不可行时由残量网络给出 Hall 违反集合（一组公羊，其需求超过全部可配母羊的容量），并核验不等式；
(2) 可行时的最小成本 LP，及其对偶（u_i, v_j）：互补松弛（x>0 ⇒ u_i+v_j=c_ij），对偶可行（c_ij−u_i−v_j≥0），强对偶；
(3) 影子价格：给公羊 i 与母羊 j 各多 1 个后代，最优成本变化 ≥ u_i+v_j（值函数的凸性，次梯度不等式）；
(4) 解禁价值：对每个被禁配对，约化成本 c_ij−u_i−v_j ≥ 0 时解禁不改变最优成本；<0 时严格降低。
断言：最大流判断与 LP 可行性一致（全部重复）；随机禁配下存在约化成本<0 的被禁配对；Hall 违反集合的不等式成立；互补松弛与对偶可行性成立；强对偶；
次梯度不等式成立；解禁价值与约化成本符号一致；半同胞禁配比全同胞禁配更常不可行。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import maximum_flow
from _oc import load_pop, make_candidates, truncation, theta, solve_oc
from ex36_17_mating_transport import largest_remainder, transport, dual_value

HERE = Path(__file__).resolve().parent


def dual_solution(cost, ns, nd, forbid):
    S, D = cost.shape; A = []; b = []
    for i in range(S):
        for j in range(D):
            if not forbid[i, j]:
                row = np.zeros(S + D); row[i] = 1; row[S + j] = 1; A.append(row); b.append(cost[i, j])
    res = linprog(-np.r_[ns, nd].astype(float), A_ub=np.array(A), b_ub=np.array(b), bounds=[(None, None)] * (S + D), method="highs")
    return res.x[:S], res.x[S:], -res.fun


def maxflow_feasible(ns, nd, forbid):
    S, D = len(ns), len(nd); n = S + D + 2; src, snk = 0, n - 1
    cap = np.zeros((n, n), dtype=np.int32)
    for i in range(S): cap[src, 1 + i] = ns[i]
    for j in range(D): cap[1 + S + j, snk] = nd[j]
    for i in range(S):
        for j in range(D):
            if not forbid[i, j]: cap[1 + i, 1 + S + j] = int(ns.sum())
    res = maximum_flow(csr_matrix(cap), src, snk)
    flow = res.flow.toarray(); resid = cap - flow
    # 残量网络中从源点可达的点
    seen = np.zeros(n, bool); seen[src] = True; stack = [src]
    while stack:
        a = stack.pop()
        for b in range(n):
            if not seen[b] and resid[a, b] > 0:
                seen[b] = True; stack.append(b)
    sires = np.where(seen[1:1 + S])[0]; dams = np.where(~forbid[sires].all(0))[0] if len(sires) else np.array([], int)
    return res.flow_value == ns.sum(), sires, dams


def main():
    pop = load_pop(); cfg = json.loads((HERE / "data" / "ex36_20_config.json").read_text(encoding="utf-8"))
    w = np.array(pop["scenarios"][cfg["scenario"]]); N = cfg["n_progeny"]
    stat = {L["name"]: dict(feas=0, n=0, hall_ok=0, hall_n=0, cs=0, subgrad=0, subg_n=0, relax_ok=0, relax_n=0, gap=0.0, rc_neg=0, rc_pos=0, fix_one=0) for L in cfg["levels"]}
    example = None
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = make_candidates(rng, pop); g = d["ebv"] @ w; A = d["A"]; sex = d["sex"]
        ct = truncation(g, sex, cfg["n_sel_m"], cfg["n_sel_f"]); c, _ = solve_oc(g, A, sex, theta(ct, A))
        m_idx = np.where(sex == 0)[0]; f_idx = np.where(sex == 1)[0]
        ns = largest_remainder(c[m_idx] / c[m_idx].sum(), N); nd = largest_remainder(c[f_idx] / c[f_idx].sum(), N)
        ns_a = ns[ns > 0]; nd_a = nd[nd > 0]; mi = m_idx[ns > 0]; fi = f_idx[nd > 0]
        Asd = A[np.ix_(mi, fi)]; cost = Asd / 2
        for L in cfg["levels"]:
            lv = L["name"]; st = stat[lv]; forbid = (Asd >= L["A"] - 1e-12) | (np.random.default_rng(cfg["seed"] + 7 * r + 3).random(Asd.shape) < L["rand"]); st["n"] += 1
            ok, sires, dams = maxflow_feasible(ns_a, nd_a, forbid)
            res = transport(cost, ns_a, nd_a, forbid)
            assert ok == (res.status == 0)
            if ok:
                st["feas"] += 1
                x = res.x.reshape(cost.shape)
                u, v, dv = dual_solution(cost, ns_a, nd_a, forbid); st["gap"] = max(st["gap"], abs(dv - res.fun))
                rc = cost - u[:, None] - v[None, :]
                allowed = ~forbid
                assert np.all(rc[allowed] >= -1e-8)
                assert np.all(np.abs(rc[(x > 1e-9)]) < 1e-8)
                st["cs"] += 1
                if st["subg_n"] < cfg["dual_checks"] * 10 and r < cfg["dual_checks"]:
                    for i in range(len(ns_a)):
                        for j in range(len(nd_a)):
                            n2 = ns_a.copy(); d2 = nd_a.copy(); n2[i] += 1; d2[j] += 1
                            r2 = transport(cost, n2, d2, forbid)
                            st["subg_n"] += 1
                            if r2.status == 0 and r2.fun - res.fun >= u[i] + v[j] - 1e-8: st["subgrad"] += 1
                            elif r2.status != 0: st["subgrad"] += 1      # 不可行时值函数为 +∞
                    # 解禁价值
                    for i, j in zip(*np.where(forbid)):
                        f2 = forbid.copy(); f2[i, j] = False
                        r2 = transport(cost, ns_a, nd_a, f2); st["relax_n"] += 1
                        if rc[i, j] >= -1e-9:
                            st["rc_pos"] += 1; st["relax_ok"] += int(abs(r2.fun - res.fun) < 1e-8)
                        else:
                            st["rc_neg"] += 1; st["relax_ok"] += int(r2.fun < res.fun - 1e-9)
            else:
                st["hall_n"] += 1
                dem = ns_a[sires].sum(); cap_ = nd_a[dams].sum()
                st["hall_ok"] += int(dem > cap_)
                # 解禁最便宜的一个被禁配对能否恢复可行
                cand = sorted([(cost[i, j], i, j) for i, j in zip(*np.where(forbid))])
                fixed = False
                for _, i, j in cand:
                    f2 = forbid.copy(); f2[i, j] = False
                    if transport(cost, ns_a, nd_a, f2).status == 0:
                        fixed = True; break
                st["fix_one"] += int(fixed)
                if example is None and len(sires) > 0:
                    example = (lv, ns_a[sires].tolist(), nd_a[dams].tolist(), int(dem), int(cap_))
    print(f"重复 {cfg['reps']} 次；后代 N={N}")
    print(f"{'禁配网络':>14}{'可行比例':>10}{'不可行时 Hall 违反成立':>22}{'解禁一对即可行':>14}{'强对偶最大差':>14}")
    out = {}
    for lv in [L["name"] for L in cfg["levels"]]:
        st = stat[lv]
        print(f"{lv:>14}{st['feas']/st['n']:>10.3f}{(str(st['hall_ok'])+'/'+str(st['hall_n'])):>22}{(str(st['fix_one'])+'/'+str(st['hall_n'])):>14}{st['gap']:>14.2e}")
        out[str(lv)] = {k: (float(v) if isinstance(v, float) else v) for k, v in st.items()}
    st = stat[[L["name"] for L in cfg["levels"]][-1]]
    print(f"\n“全同胞+随机40%”禁配下的次梯度不等式：{st['subgrad']}/{st['subg_n']} 成立；解禁价值与约化成本符号一致：{st['relax_ok']}/{st['relax_n']}（其中约化成本<0 的 {st['rc_neg']} 个、≥0 的 {st['rc_pos']} 个）")
    if example:
        print(f"Hall 违反示例（禁配网络“{example[0]}”）：违反集合内公羊的后代需求 {example[3]} 个，其全部可配母羊的容量仅 {example[4]} 个")
    for lv in [L["name"] for L in cfg["levels"]]:
        s = stat[lv]
        assert s["hall_ok"] == s["hall_n"] and s["gap"] < 1e-7
        assert s["subgrad"] == s["subg_n"] and s["relax_ok"] == s["relax_n"]
    assert stat["半同胞"]["feas"] < stat["全同胞"]["feas"]
    assert stat["全同胞+随机40%"]["rc_neg"] > 0
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex36_20_forbidden_feasibility.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
