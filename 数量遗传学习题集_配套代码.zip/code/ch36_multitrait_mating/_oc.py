"""第36章共用：候选群体生成、多性状 BLUP 与最优贡献/配种求解（供本文件夹中的程序导入）。

候选群体：3 只奠基公羊与 8 只奠基母羊（互不相关、非近交），16 只候选羊（6 公 10 母）各自由随机的奠基公、母交配产生，
故候选之间的关系 A（表格法）带有全同胞、半同胞结构。三性状真实育种值 u ~ N(0, G⊗A)；
记录 y = u + e（各性状残差方差独立）；EBV 为多性状 BLUP，PEV 为 Σ − ΣV⁻¹Σ（含性状间协方差）。
综合目标 H = wᵀu，w 为经济权重（每遗传标准差的价值）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent


def load_pop():
    return json.loads((HERE / "data" / "ex36_population.json").read_text(encoding="utf-8"))


def tabular_A(sire, dam):
    n = len(sire); A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        if s >= 0 and d >= 0:
            A[i, :i] = 0.5 * (A[s, :i] + A[d, :i]); A[:i, i] = A[i, :i]; A[i, i] = 1 + 0.5 * A[s, d]
        else:
            A[i, i] = 1.0
    return A


def make_candidates(rng, pop, low_info_frac=0.0, low_info_mult=1.0):
    nF, nD, ns, nd = pop["n_founder_sires"], pop["n_founder_dams"], pop["n_cand_sires"], pop["n_cand_dams"]
    n0, nc = nF + nD, ns + nd
    sire = np.full(n0 + nc, -1); dam = np.full(n0 + nc, -1)
    for i in range(nc):
        sire[n0 + i] = rng.integers(0, nF); dam[n0 + i] = nF + rng.integers(0, nD)
    A = tabular_A(sire, dam)[n0:, n0:]
    sex = np.r_[np.zeros(ns, int), np.ones(nd, int)]
    G = np.array(pop["G"]); Rv = np.array(pop["resid_var"]); k = G.shape[0]
    Sig = np.kron(G, A)
    u = np.linalg.cholesky(Sig + 1e-10 * np.eye(k * nc)) @ rng.normal(size=k * nc)
    scale = np.ones(nc)
    if low_info_frac > 0:                       # 一部分候选的记录较少：残差方差放大 low_info_mult 倍
        scale[rng.choice(nc, int(round(low_info_frac * nc)), replace=False)] = low_info_mult
    Rall = np.kron(Rv, np.ones(nc)) * np.tile(scale, k)
    y = u + np.sqrt(Rall) * rng.normal(size=k * nc)
    V = Sig + np.diag(Rall)
    Vi_S = np.linalg.solve(V, Sig)
    ebv = (Vi_S.T @ y)               # Σ V⁻¹ y（Σ 对称）
    pev = Sig - Sig @ Vi_S
    return dict(A=A, sex=sex, u=u.reshape(k, nc).T, ebv=ebv.reshape(k, nc).T, pev_full=pev, G=G, nc=nc, k=k, info_scale=scale)


def index_pev(pev_full, w, nc):
    out = np.zeros((nc, nc))
    k = len(w)
    for a in range(k):
        for b in range(k):
            out += w[a] * w[b] * pev_full[a * nc:(a + 1) * nc, b * nc:(b + 1) * nc]
    return out


def truncation(g, sex, n_m, n_f):
    c = np.zeros(len(g))
    m_idx = np.where(sex == 0)[0]; f_idx = np.where(sex == 1)[0]
    top_m = m_idx[np.argsort(-g[m_idx])[:n_m]]; top_f = f_idx[np.argsort(-g[f_idx])[:n_f]]
    c[top_m] = 0.5 / n_m; c[top_f] = 0.5 / n_f
    return c


def theta(c, A):
    """群体共祖 θ = cᵀAc/2（c 总和为 1）。"""
    return 0.5 * c @ A @ c


def solve_oc(g, A, sex, theta_max, c0=None, extra_cons=(), ub=None):
    """最大化 gᵀc，约束：公、母各占 0.5，c≥0，½cᵀAc ≤ theta_max。返回 (c, 乘子信息 dict)。"""
    n = len(g)
    if c0 is None:
        c0 = np.where(sex == 0, 0.5 / (sex == 0).sum(), 0.5 / (sex == 1).sum())
    cons = [
        {"type": "eq", "fun": lambda c: c[sex == 0].sum() - 0.5, "jac": lambda c: (sex == 0).astype(float)},
        {"type": "eq", "fun": lambda c: c[sex == 1].sum() - 0.5, "jac": lambda c: (sex == 1).astype(float)},
        {"type": "ineq", "fun": lambda c: theta_max - 0.5 * c @ A @ c, "jac": lambda c: -(A @ c)},
    ] + list(extra_cons)
    bounds = [(0, None if ub is None else ub)] * n
    res = minimize(lambda c: -g @ c, c0, jac=lambda c: -g, bounds=bounds, constraints=cons, method="SLSQP",
                   options={"ftol": 1e-13, "maxiter": 1000})
    c = np.clip(res.x, 0, None)
    return c, res


def kkt_multipliers(g, A, sex, c, tol=1e-6):
    """由解 c 的支撑集反推乘子 (λ, μ_m, μ_f)：在 c_i>0 的 i 上 g_i − λ(Ac)_i − μ_sex(i) = 0（最小二乘）。
    返回 (λ, μm, μf, 残差范数, 零份额个体的 KKT 余量 g_i − λ(Ac)_i − μ_i（应 ≤ 0）)。"""
    act = c > tol
    X = np.column_stack([A @ c, (sex == 0).astype(float), (sex == 1).astype(float)])
    sol, *_ = np.linalg.lstsq(X[act], g[act], rcond=None)
    lam, mm, mf = sol
    resid = g[act] - X[act] @ sol
    slack = g[~act] - X[~act] @ sol
    return lam, mm, mf, float(np.linalg.norm(resid)), slack
