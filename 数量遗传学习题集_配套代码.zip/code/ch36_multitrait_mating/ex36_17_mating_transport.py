#!/usr/bin/env python3
"""习题 36.17  配种分配是运输问题：把整数后代数分配到公母配对，使后代的期望近交最小

给定最优贡献 c（习题 36.16），N=40 个后代按最大余数法分配为公羊 n_s（合计 N）与母羊 n_d（合计 N）。
决策变量 x_sd≥0（整数）为公 s×母 d 的配对数，行和=n_s，列和=n_d，成本 F_sd=A_sd/2（后代近交系数的期望），
禁配：A_sd≥forbid_A（如全同胞）。求最小总成本，并与随机（按份额）配种和贪心配种比较。
独立核验：(1) LP 解为整数（全单模）；行/列和精确成立；(2) 与对偶问题的目标值相等（强对偶，独立求解对偶 LP）；
(3) 贪心不优于 LP；随机配种的期望成本 = Σ n_s n_d F_sd / N。
断言：LP 解整数；行列和成立；原始-对偶差 <1e-7；LP 成本 ≤ 贪心 ≤ 随机×(1+1e-9)；全部可行重复中，LP 成本平均低于随机至少 20%。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from _oc import load_pop, make_candidates, truncation, theta, solve_oc

HERE = Path(__file__).resolve().parent


def largest_remainder(shares, total):
    raw = shares * total; base = np.floor(raw + 1e-12).astype(int)
    rest = total - base.sum(); order = np.argsort(-(raw - base))
    base[order[:rest]] += 1
    return base


def transport(cost, ns, nd, forbid):
    S, D = cost.shape
    c = cost.ravel().copy()
    bounds = [(0, 0) if forbid[i, j] else (0, None) for i in range(S) for j in range(D)]
    Aeq = []; beq = []
    for i in range(S):
        row = np.zeros((S, D)); row[i, :] = 1; Aeq.append(row.ravel()); beq.append(ns[i])
    for j in range(D):
        col = np.zeros((S, D)); col[:, j] = 1; Aeq.append(col.ravel()); beq.append(nd[j])
    res = linprog(c, A_eq=np.array(Aeq), b_eq=np.array(beq), bounds=bounds, method="highs")
    return res


def dual_value(cost, ns, nd, forbid):
    """对偶：max Σ ns_i u_i + Σ nd_j v_j，s.t. u_i+v_j ≤ cost_ij（未禁配的 (i,j)），u,v 自由。"""
    S, D = cost.shape
    A = []; b = []
    for i in range(S):
        for j in range(D):
            if not forbid[i, j]:
                row = np.zeros(S + D); row[i] = 1; row[S + j] = 1; A.append(row); b.append(cost[i, j])
    obj = -np.r_[ns, nd].astype(float)
    res = linprog(obj, A_ub=np.array(A), b_ub=np.array(b), bounds=[(None, None)] * (S + D), method="highs")
    return -res.fun if res.status == 0 else np.nan


def greedy(cost, ns, nd, forbid):
    ns = ns.copy(); nd = nd.copy(); x = np.zeros(cost.shape, int)
    order = sorted([(cost[i, j], i, j) for i in range(cost.shape[0]) for j in range(cost.shape[1]) if not forbid[i, j]])
    for _, i, j in order:
        k = min(ns[i], nd[j]); x[i, j] += k; ns[i] -= k; nd[j] -= k
    return x, (ns.sum() == 0 and nd.sum() == 0)


def main():
    pop = load_pop(); cfg = json.loads((HERE / "data" / "ex36_17_config.json").read_text(encoding="utf-8"))
    w = np.array(pop["scenarios"][cfg["scenario"]]); N = cfg["n_progeny"]
    rec = dict(lp=[], gr=[], rd=[], hs_lp=[], hs_gr=[], hs_rd=[], gap=[], feas=0, integral=True, greedy_ok=0)
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = make_candidates(rng, pop); g = d["ebv"] @ w; A = d["A"]; sex = d["sex"]
        ct = truncation(g, sex, cfg["n_sel_m"], cfg["n_sel_f"]); c, _ = solve_oc(g, A, sex, theta(ct, A))
        m_idx = np.where(sex == 0)[0]; f_idx = np.where(sex == 1)[0]
        ns = largest_remainder(c[m_idx] / c[m_idx].sum(), N); nd = largest_remainder(c[f_idx] / c[f_idx].sum(), N)
        ns_a = ns[ns > 0]; nd_a = nd[nd > 0]; mi = m_idx[ns > 0]; fi = f_idx[nd > 0]
        Asd = A[np.ix_(mi, fi)]; cost = Asd / 2; forbid = Asd >= cfg["forbid_A"] - 1e-12
        res = transport(cost, ns_a, nd_a, forbid)
        if res.status != 0:
            continue
        rec["feas"] += 1
        x = res.x.reshape(cost.shape)
        assert np.all(np.abs(x - np.round(x)) < 1e-7) and np.allclose(x.sum(1), ns_a) and np.allclose(x.sum(0), nd_a)
        dv = dual_value(cost, ns_a, nd_a, forbid); assert abs(dv - res.fun) < 1e-7
        xg, ok = greedy(cost, ns_a, nd_a, forbid)
        rd_cost = (np.outer(ns_a, nd_a) * cost).sum() / N ** 2
        rec["lp"].append(res.fun / N); rec["rd"].append(rd_cost)
        if ok:
            rec["gr"].append((xg * cost).sum() / N); rec["greedy_ok"] += 1
            assert (xg * cost).sum() >= res.fun - 1e-9
        else:
            rec["gr"].append(np.nan)
        rec["hs_lp"].append((x * (Asd >= 0.25 - 1e-12)).sum() / N)
        rec["hs_rd"].append((np.outer(ns_a, nd_a) * (Asd >= 0.25 - 1e-12)).sum() / N ** 2)
        rec["gap"].append(abs(dv - res.fun))
    M = lambda k: float(np.nanmean(rec[k]))
    print(f"重复 {cfg['reps']} 次；后代 N={N}；禁配 A≥{cfg['forbid_A']}（全同胞）；可行的重复 {rec['feas']} 次，贪心可行 {rec['greedy_ok']} 次")
    print(f"后代期望近交系数 F̄：随机配种 {M('rd'):.4f}；贪心 {M('gr'):.4f}；运输 LP {M('lp'):.4f}")
    print(f"相对随机配种的降低：LP {1-M('lp')/M('rd'):.1%}，贪心 {1-M('gr')/M('rd'):.1%}")
    print(f"半同胞及更近配对的后代占比：随机 {M('hs_rd'):.3f}，LP {M('hs_lp'):.3f}")
    print(f"LP 解整数、行列和成立；原始-对偶目标差最大 {np.max(rec['gap']):.2e}")
    assert rec["feas"] >= 0.5 * cfg["reps"]
    assert 1 - M("lp") / M("rd") > 0.2
    assert M("lp") <= M("gr") + 1e-12 <= M("rd") + 1e-9
    out = {k: (M(k) if k in ("lp", "gr", "rd", "hs_lp", "hs_rd") else None) for k in ("lp", "gr", "rd", "hs_lp", "hs_rd")}
    out.update(feasible=rec["feas"], greedy_feasible=rec["greedy_ok"], max_gap=float(np.max(rec["gap"])))
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex36_17_mating_transport.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
