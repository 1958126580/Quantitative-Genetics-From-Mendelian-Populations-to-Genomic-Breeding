#!/usr/bin/env python3
"""习题 36.19  EBV 的不确定性与均值—方差权衡：下尾风险、机会约束

给定 EBV 与指数 PEV 矩阵 P（含性状间与个体间的误差协方差），后验为 u|y ~ N(EBV, PEV)，故综合目标 H=c'(u@w) 的
预测分布为 N(gᵀc, cᵀPc)。策略：max gᵀc − κ√(cᵀPc)，约束同习题 36.16（θ≤θ_max，公母各 ½，c≥0），κ∈{0,0.5,1.2816}。
κ=1.2816 即最大化"10% 分位数"（风险价值）。报告：预测均值与标准差、预测的 P(H<floor)、实现的 H（用已知真值）的均值、
下 10% 分位数与 H<floor 的频率；预测概率的校准（均值与观测频率）；±1.645 sd 的覆盖率；支撑集大小与最大份额。
结论（诚实的小效应）：在 θ 约束起作用、EBV 已按可靠度收缩时，风险项只能小幅降低预测标准差（约 0—10%），代价同样很小；
不确定性的大头来自未被信息分辨的孟德尔抽样，重新分配贡献改变不了它。
断言：κ 增大时预测均值不增、预测标准差不增；κ=1.2816 的预测 10% 分位数 ≥ κ=0 的；
实现的 H<floor 的频率随 κ 增大不增（容差 0.01）；预测的 P(H<floor) 的平均值与观测频率相差 <0.04；
90% 区间覆盖率 0.9±0.04；κ=0 的实现均值 ≥ κ=1.2816 的实现均值（容差 0.01）；
信息不均时 κ=1.2816 的预测 sd 在 κ=0 的 80%—100% 之间，预测均值变化 <0.02。
"""
from __future__ import annotations
import json
from math import erf, sqrt
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from _oc import load_pop, make_candidates, truncation, theta, solve_oc, index_pev

HERE = Path(__file__).resolve().parent
Phi = lambda x: 0.5 * (1 + erf(x / sqrt(2)))


def solve_mv(g, P, A, sex, tmax, kappa, c0):
    n = len(g)
    cons = [
        {"type": "eq", "fun": lambda c: c[sex == 0].sum() - 0.5, "jac": lambda c: (sex == 0).astype(float)},
        {"type": "eq", "fun": lambda c: c[sex == 1].sum() - 0.5, "jac": lambda c: (sex == 1).astype(float)},
        {"type": "ineq", "fun": lambda c: tmax - 0.5 * c @ A @ c, "jac": lambda c: -(A @ c)},
    ]
    def f(c):
        return -(g @ c - kappa * np.sqrt(c @ P @ c + 1e-14))
    def jac(c):
        return -(g - kappa * (P @ c) / np.sqrt(c @ P @ c + 1e-14))
    r = minimize(f, c0, jac=jac, bounds=[(0, None)] * n, constraints=cons, method="SLSQP", options={"ftol": 1e-13, "maxiter": 1000})
    return np.clip(r.x, 0, None)


def main():
    pop = load_pop(); cfg = json.loads((HERE / "data" / "ex36_19_config.json").read_text(encoding="utf-8"))
    w = np.array(pop["scenarios"][cfg["scenario"]]); ks = cfg["kappas"]; fl = cfg["floor"]
    keys = ["g", "sd", "q10", "pshort", "Hreal", "short", "cover", "supp", "cmax"]
    allM = {}
    for st in cfg["settings"]:
        acc = {k: {m: [] for m in keys} for k in ks}
        for r in range(cfg["reps"]):
            rng = np.random.default_rng(cfg["seed"] + r)
            d = make_candidates(rng, pop, st["frac"], st["mult"]); g = d["ebv"] @ w; A = d["A"]; sex = d["sex"]
            P = index_pev(d["pev_full"], w, d["nc"]); h = d["u"] @ w
            ct = truncation(g, sex, cfg["n_sel_m"], cfg["n_sel_f"]); tmax = theta(ct, A)
            c0, _ = solve_oc(g, A, sex, tmax)
            for k in ks:
                c = c0 if k == 0 else solve_mv(g, P, A, sex, tmax, k, c0)
                gm = g @ c; sd = np.sqrt(c @ P @ c); Hr = c @ h
                a = acc[k]; a["g"].append(gm); a["sd"].append(sd); a["q10"].append(gm - cfg["z90"] * sd)
                a["pshort"].append(Phi((fl - gm) / sd)); a["Hreal"].append(Hr); a["short"].append(Hr < fl)
                a["cover"].append(abs(Hr - gm) <= 1.6449 * sd); a["supp"].append((c > 1e-6).sum()); a["cmax"].append(c.max())
        M = {k: {m: float(np.mean(v)) for m, v in acc[k].items()} for k in ks}; allM[st["name"]] = M
        print(f"\n【{st['name']}】低信息候选比例 {st['frac']}，残差方差放大 {st['mult']} 倍；重复 {cfg['reps']} 次；floor={fl}；κ=0 即习题 36.16 的最优贡献")
        print(f"{'κ':>7}{'预测均值':>9}{'预测sd':>8}{'预测q10':>9}{'预测P(H<0)':>12}{'实现均值':>9}{'实现H<0':>9}{'±1.645sd覆盖':>13}{'支撑集':>7}{'最大份额':>9}")
        for k in ks:
            q = M[k]
            print(f"{k:>7}{q['g']:>9.3f}{q['sd']:>8.3f}{q['q10']:>9.3f}{q['pshort']:>12.3f}{q['Hreal']:>9.3f}{q['short']:>9.3f}{q['cover']:>13.3f}{q['supp']:>7.1f}{q['cmax']:>9.3f}")
        for i in range(len(ks) - 1):
            a, b = M[ks[i]], M[ks[i + 1]]
            assert b["g"] <= a["g"] + 1e-9 and b["sd"] <= a["sd"] + 1e-9
            assert b["short"] <= a["short"] + 0.01
        assert M[ks[-1]]["q10"] >= M[ks[0]]["q10"]
        for k in ks:
            assert abs(M[k]["pshort"] - M[k]["short"]) < 0.04
            assert abs(M[k]["cover"] - 0.9) < 0.04
        assert M[ks[0]]["Hreal"] >= M[ks[-1]]["Hreal"] - 0.01
    U = allM[cfg["settings"][1]["name"]]
    print(f"\n信息不均时 κ=1.2816 相对 κ=0：预测 sd 变化 {U[ks[-1]]['sd']/U[ks[0]]['sd']-1:+.1%}，预测均值变化 {U[ks[-1]]['g']-U[ks[0]]['g']:+.3f}，实现 H<0 频率变化 {U[ks[-1]]['short']-U[ks[0]]['short']:+.3f}")
    assert 0.80 * U[ks[0]]["sd"] < U[ks[-1]]["sd"] < U[ks[0]]["sd"] and abs(U[ks[-1]]["g"] - U[ks[0]]["g"]) < 0.02
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex36_19_uncertainty_risk.json").write_text(json.dumps(allM, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
