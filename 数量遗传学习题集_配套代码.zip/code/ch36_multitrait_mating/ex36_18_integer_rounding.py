#!/usr/bin/env python3
"""习题 36.18  整数后代数怎样改变连续贡献前沿：取整的收益损失与约束违反随 N 的变化

连续最优贡献 c*（习题 36.16）要变成每只公、母羊的整数后代数（总数 N，公母各 N 个"份额"，即 c_i=n_i/N 的两性各 ½ 归一）。
比较：(a) 四舍五入后用最大份额个体吸收余数；(b) 最大余数法；(c) 带约束的局部搜索：从 (b) 出发，在同性别个体间每次移动 1 个后代，
最大化 gᵀc − M·max(0, θ−θ_max)，直到无改进。指标：|gᵀc − g*|（一阶量）、θ 的超出量（约束违反，一阶量）、拉格朗日损失 g* − [gᵀc − λ(θ−θ_max)]（二阶量，≥0）、可行比例。
断言：(b) 的 θ 超出量随 N 下降；|Δg| 的对数-对数斜率在 (−1.4, −0.6)；拉格朗日损失非负，斜率在 (−2.6, −1.4)（二阶）；
(c) 在 N≥40 时可行比例 ≥0.95；(c) 的最终目标不低于 (b) 的惩罚目标（局部搜索只改进不恶化）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _oc import load_pop, make_candidates, truncation, theta, solve_oc, kkt_multipliers

HERE = Path(__file__).resolve().parent


def lr(shares, total):
    raw = shares * total; base = np.floor(raw + 1e-12).astype(int); rest = total - base.sum()
    base[np.argsort(-(raw - base))[:rest]] += 1
    return base


def to_c(counts_m, counts_f, m_idx, f_idx, n, N):
    c = np.zeros(n); c[m_idx] = 0.5 * counts_m / N; c[f_idx] = 0.5 * counts_f / N
    return c


def local_search(c0, g, A, sex, N, tmax, M, max_iter=5000):
    cnt = np.rint(2 * N * c0).astype(int)          # 每性别总计 N
    def obj(cn):
        c = cn / (2.0 * N); return g @ c - M * max(0.0, theta(c, A) - tmax)
    cur = obj(cnt)
    for _ in range(max_iter):
        best = (0, None)
        for s in (0, 1):
            idx = np.where(sex == s)[0]
            for i in idx:
                if cnt[i] == 0: continue
                for j in idx:
                    if i == j: continue
                    cnt[i] -= 1; cnt[j] += 1
                    v = obj(cnt) - cur
                    cnt[i] += 1; cnt[j] -= 1
                    if v > best[0] + 1e-12: best = (v, (i, j))
        if best[1] is None: break
        i, j = best[1]; cnt[i] -= 1; cnt[j] += 1; cur += best[0]
    return cnt / (2.0 * N), cur


def main():
    pop = load_pop(); cfg = json.loads((HERE / "data" / "ex36_18_config.json").read_text(encoding="utf-8"))
    w = np.array(pop["scenarios"][cfg["scenario"]]); Ns = cfg["N_list"]
    R = {N: {k + t: [] for k in ('d', 'e', 'l', 'f') for t in 'abc'} | dict(objb=[], objc=[]) for N in Ns}
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = make_candidates(rng, pop); g = d["ebv"] @ w; A = d["A"]; sex = d["sex"]; n = len(g)
        ct = truncation(g, sex, cfg["n_sel_m"], cfg["n_sel_f"]); tmax = theta(ct, A)
        c, _ = solve_oc(g, A, sex, tmax); gstar = g @ c
        lam = kkt_multipliers(g, A, sex, c)[0]
        m_idx = np.where(sex == 0)[0]; f_idx = np.where(sex == 1)[0]
        for N in Ns:
            # (a) 四舍五入，余数由最大份额个体吸收
            cm = np.rint(c[m_idx] * 2 * N).astype(int); cf = np.rint(c[f_idx] * 2 * N).astype(int)
            cm[np.argmax(cm)] += N - cm.sum(); cf[np.argmax(cf)] += N - cf.sum()
            ca = to_c(cm, cf, m_idx, f_idx, n, N)
            cb = to_c(lr(c[m_idx] / c[m_idx].sum(), N), lr(c[f_idx] / c[f_idx].sum(), N), m_idx, f_idx, n, N)
            cc, objc = local_search(cb, g, A, sex, N, tmax, cfg["penalty"]) if N <= 100 else (cb, None)
            for key, cx in (("a", ca), ("b", cb), ("c", cc)):
                R[N]["d" + key].append(abs(g @ cx - gstar))
                R[N]["l" + key].append(gstar - (g @ cx - lam * (theta(cx, A) - tmax)))
                R[N]["e" + key].append(max(0.0, theta(cx, A) - tmax))
                R[N]["f" + key].append(theta(cx, A) <= tmax + 1e-12)
            if objc is not None:
                R[N]["objb"].append(g @ cb - cfg["penalty"] * max(0.0, theta(cb, A) - tmax)); R[N]["objc"].append(objc)
    print(f"重复 {cfg['reps']} 次；连续最优为参照；N 为每性别的后代总数（局部搜索只在 N≤100 时运行）")
    print(f"{'N':>5} |{'方法':>4}{'|Δg|':>9}{'θ超出':>10}{'拉格朗日损失':>13}{'可行':>6}")
    out = {}; dg_b = []; ll_b = []
    for N in Ns:
        q = {k: float(np.mean(v)) for k, v in R[N].items() if len(v)}
        out[str(N)] = q; dg_b.append(q["db"]); ll_b.append(q["lb"])
        for t, nm in (("a", "取整"), ("b", "余数"), ("c", "搜索")):
            if t == "c" and N > 100: continue
            print(f"{N:>5} |{nm:>4}{q['d'+t]:>9.4f}{q['e'+t]:>10.5f}{q['l'+t]:>13.6f}{q['f'+t]:>6.2f}")
    s1 = np.polyfit(np.log(Ns), np.log(dg_b), 1)[0]; s2 = np.polyfit(np.log(Ns), np.log(ll_b), 1)[0]
    print(f"\n最大余数法：|Δg| 对 N 的对数-对数斜率 {s1:.2f}（一阶，约 −1）；拉格朗日损失斜率 {s2:.2f}（二阶，约 −2）")
    eb = [out[str(N)]["eb"] for N in Ns]
    assert all(eb[i + 1] <= eb[i] + 1e-6 for i in range(len(eb) - 1))
    assert -1.4 < s1 < -0.6 and -2.6 < s2 < -1.4
    for N in Ns:
        assert min(R[N]["la"] + R[N]["lb"] + R[N]["lc"]) > -1e-6
        if 40 <= N <= 100: assert out[str(N)]["fc"] >= 0.95
        if N <= 100: assert np.all(np.array(R[N]["objc"]) >= np.array(R[N]["objb"]) - 1e-9)
    out["slope_dg"] = float(s1); out["slope_lagr"] = float(s2)
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex36_18_integer_rounding.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
