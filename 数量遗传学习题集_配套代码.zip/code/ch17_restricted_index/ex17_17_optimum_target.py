#!/usr/bin/env python3
"""习题 17.17  存在最适值的目标：预测均值之外还要看不确定性

目标性状（如乳脂率、出生重）的“价值”在最适值 θ 处最大：U(g) = −(g − θ)²。
给定育种值预测 m 与预测误差方差 v：  E[U | m, v] = −[(m − θ)² + v]。
候选个体的可靠度 r²（取自混合分布）决定  m ~ N(μ₀, r² V_A)、v = V_A(1 − r²)。
比较三种选择规则（保留比例 keep）：
  (1) 按预测均值 m 最大（线性目标的惯例）；
  (2) 按 −|m − θ|（只看均值与最适值的距离）；
  (3) 按期望效用 −[(m − θ)² + v]（贝叶斯最优）。
评价：入选个体的真实平均效用、真实 (g − θ)² 以及入选个体的可靠度构成。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex17_17_optimum.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); N, VA, mu0 = cfg["n"], cfg["VA"], cfg["mu0"]
    lev = np.array(cfg["accuracy_levels"]); pr = np.array(cfg["accuracy_probs"])
    r = rng.choice(lev, N, p=pr); r2 = r ** 2
    m = mu0 + r * np.sqrt(VA) * rng.standard_normal(N)
    g = m + np.sqrt(VA * (1 - r2)) * rng.standard_normal(N)       # g | m ~ N(m, V_A(1 − r²))
    v = VA * (1 - r2); k = int(cfg["keep"] * N); res = {}
    for theta in cfg["theta"]:
        print(f"\n最适值 θ = {theta}（以 σ_A 为单位；群体均值 {mu0}）")
        print(f"{'规则':<22s}{'真实平均效用':>12s}{'真实均方偏差':>12s}{'平均可靠度':>10s}{'平均 m':>8s}")
        rules = {"(1) 预测均值最大": m, "(2) 距最适值最近": -np.abs(m - theta), "(3) 期望效用最大": -((m - theta) ** 2 + v)}
        res[theta] = {}
        for name, s in rules.items():
            sel = np.argsort(s)[-k:]; msd = ((g[sel] - theta) ** 2).mean()
            res[theta][name] = dict(utility=-msd, msd=msd, rel=float((r2[sel]).mean()), m=float(m[sel].mean()))
            print(f"{name:<20s}{-msd:12.4f}{msd:12.4f}{r2[sel].mean():10.3f}{m[sel].mean():8.3f}")
        best = max(res[theta], key=lambda n: res[theta][n]["utility"])
        assert best.startswith("(3)") or res[theta][best]["utility"] - res[theta]["(3) 期望效用最大"]["utility"] < 0.01
    (HERE / "results" / "ex17_17_optimum_target.json").write_text(json.dumps(res, ensure_ascii=False, indent=1, default=float))


if __name__ == "__main__":
    main()
