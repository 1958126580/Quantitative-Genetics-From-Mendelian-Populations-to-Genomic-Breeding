#!/usr/bin/env python3
"""习题 17.16  不等式限制、活跃集合与最优性证书

在习题 17.15 的 4 性状模型上，把“不能恶化”写成不等式：某些性状的遗传响应 ≥ 下界或 ≤ 上界。
标准化 σ_I = 1，决策变量为权重 b（bᵀPb ≤ 1），响应 Δ = i G b，目标 max aᵀΔ。
这是二阶锥规划；程序用 SLSQP（多个随机起点）求解，并给出：
  · 活跃集合（取等号的约束）；
  · 由平稳性条件  i G a − 2ν P b + i Σ_j μ_j s_j G e_j = 0 （s_j = +1 对应下界 ≥，写成 −Δ_j ≤ −下界）
    最小二乘求得的乘数 ν、μ_j，检查 μ_j ≥ 0（互补松弛）与残差（最优性证书）；
  · 与等式限制的闭式解（习题 17.15 公式的推广）对照：当约束恰好取等且在可行域边界时，解一致。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import optimize, stats
from ex17_15_restricted_index import setup
HERE = Path(__file__).resolve().parent


def solve(G, P, a, i, lower, upper, starts, rng):
    cons = [{"type": "ineq", "fun": lambda b: 1 - b @ P @ b}]
    for j, lo in lower.items():
        j = int(j); cons.append({"type": "ineq", "fun": lambda b, j=j, lo=lo: i * G[j] @ b - lo})
    for j, up in upper.items():
        j = int(j); cons.append({"type": "ineq", "fun": lambda b, j=j, up=up: up - i * G[j] @ b})
    best = None
    for _ in range(starts):
        b0 = rng.standard_normal(len(a)); b0 /= np.sqrt(b0 @ P @ b0)
        r = optimize.minimize(lambda b: -i * a @ G @ b, b0, constraints=cons, method="SLSQP", options=dict(ftol=1e-14, maxiter=500))
        if r.success and all(c["fun"](r.x) >= -1e-7 for c in cons) and (best is None or r.fun < best.fun): best = r
    return best


def main():
    cfg = json.loads((HERE / "data" / "ex17_16_inequality.json").read_text())
    pcfg = json.loads((HERE / "data" / "ex17_15_pig.json").read_text())
    G, P, a = setup(pcfg); names = pcfg["traits"]; p = cfg["p"]; rng = np.random.default_rng(cfg["seed"])
    x = stats.norm.isf(p); i = stats.norm.pdf(x) / p
    b0 = np.linalg.solve(P, G @ a); b0 /= np.sqrt(b0 @ P @ b0); d0 = i * G @ b0; H0 = a @ d0
    print("无限制：" + "，".join(f"{n} {v:+.3f}" for n, v in zip(names, d0)) + f"；ΔH = {H0:.3f}")
    out = {}
    for sc in cfg["scenarios"]:
        r = solve(G, P, a, i, sc["lower"], sc["upper"], cfg["starts"], rng); b = r.x; d = i * G @ b; H = a @ d
        # 活跃约束与乘数
        act = []; cols = []
        for j, lo in sc["lower"].items():
            if abs(d[int(j)] - lo) < 1e-5: act.append((f"{names[int(j)]} ≥ {lo:+.2f}", -1)); cols.append(-1 * i * G[int(j)])   # 约束 −Δ ≤ −lo
        for j, up in sc["upper"].items():
            if abs(d[int(j)] - up) < 1e-5: act.append((f"{names[int(j)]} ≤ {up:+.2f}", +1)); cols.append(+1 * i * G[int(j)])
        # 平稳性：∇(−ΔH) + ν∇(bᵀPb) + Σ μ_j ∇g_j = 0，g_j = s_j Δ_j − s_j bound ≤ 0
        grad_obj = -i * G @ a
        Amat = np.column_stack([2 * P @ b] + cols); sol, res, *_ = np.linalg.lstsq(Amat, -grad_obj, rcond=None)
        resid = np.linalg.norm(Amat @ sol + grad_obj)
        nu, mu = sol[0], sol[1:]
        ok = (nu >= -1e-6) and np.all(mu >= -1e-6) and resid < 1e-4
        print(f"\n【{sc['name']}】ΔH = {H:.3f}（损失 {100 * (1 - H / H0):.1f}%），响应：" + "，".join(f"{v:+.3f}" for v in d))
        print(f"  活跃约束：{[t[0] for t in act]}；乘数 ν = {nu:.4f}，μ = {np.round(mu, 4)}；平稳性残差 {resid:.1e}；KKT 证书 {'通过' if ok else '未通过'}")
        assert ok
        out[sc["name"]] = dict(H=H, gain=d.tolist(), active=[t[0] for t in act], nu=float(nu), mu=mu.tolist(), resid=float(resid))
    (HERE / "results" / "ex17_16_inequality_constraints.json").write_text(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
