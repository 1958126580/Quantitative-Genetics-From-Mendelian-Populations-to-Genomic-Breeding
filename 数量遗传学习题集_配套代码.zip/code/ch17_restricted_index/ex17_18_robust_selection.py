#!/usr/bin/env python3
"""习题 17.18  经济权重不确定时的稳健选择：期望、最坏情形与条件风险价值

60 头候选种公猪的 4 性状育种值预测 EBV（数据文件）；经济权重 a 不确定：a ~ N(a₀, Σ_a)（Σ_a 由各权重标准差与等相关 ρ 构成）。
选 k 头，群体平均育种值在情景 s 下的收益  V_s(x) = (1/k) Σ_j x_j (EBV_j · a_s)，x_j ∈ {0,1}，Σx = k。
四种选择规则：
  (E) 期望最优：按 EBV·E[a] 取前 k；
  (M) 最坏情形最优（对拟合情景集的 max-min，线性规划松弛 + 取整）；
  (C) CVaR_α 最优（Rockafellar–Uryasev 线性规划，最大化最差 α 比例情景的平均收益）；
  (V) 均值−λ·标准差（由 EBV 的情景协方差，取前 k 的贪婪法）。
线性规划用 scipy.optimize.linprog（HiGHS）。在独立的测试情景中比较均值、5% 分位数、CVaR 与最大后悔（相对该情景下的最优选择）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
HERE = Path(__file__).resolve().parent


def scenarios(cfg, n, rng):
    sd = np.array(cfg["a_sd"]); rho = cfg["a_corr"]
    S = np.outer(sd, sd) * (rho + (1 - rho) * np.eye(len(sd)))
    return np.array(cfg["a0"]) + rng.standard_normal((n, len(sd))) @ np.linalg.cholesky(S).T


def lp_select(U, k, mode, alpha=0.2):
    """U: (S, n) 情景×候选的单头价值。返回被选下标。mode='cvar' 或 'maxmin'。"""
    S, n = U.shape
    if mode == "maxmin":      # 变量 x(n), t ；最大化 t，  t ≤ (1/k) U_s x
        c = np.r_[np.zeros(n), -1.0]
        A_ub = np.hstack([-U / k, np.ones((S, 1))]); b_ub = np.zeros(S)
        A_eq = np.r_[np.ones(n), 0.0][None, :]; b_eq = [k]
        bounds = [(0, 1)] * n + [(None, None)]
    else:                     # 变量 x(n), η, z(S)：max η − (1/(αS)) Σ z_s，  z_s ≥ η − (1/k)U_s x，z ≥ 0
        c = np.r_[np.zeros(n), -1.0, np.ones(S) / (alpha * S)]
        A_ub = np.hstack([-U / k, np.ones((S, 1)), -np.eye(S)]); b_ub = np.zeros(S)
        A_eq = np.r_[np.ones(n), 0.0, np.zeros(S)][None, :]; b_eq = [k]
        bounds = [(0, 1)] * n + [(None, None)] + [(0, None)] * S
    r = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method="highs")
    assert r.status == 0
    return np.argsort(r.x[:n])[-k:]


def stats_for(sel, EBV, A_test):
    V = (EBV[sel] @ A_test.T).mean(0)                                 # 每个测试情景的收益
    best = np.sort(EBV @ A_test.T, axis=0)[-len(sel):].mean(0)         # 该情景的最优
    q5 = np.quantile(V, 0.05); cvar = V[V <= q5].mean()
    return dict(mean=V.mean(), q5=q5, cvar5=cvar, max_regret=(best - V).max(), mean_regret=(best - V).mean())


def main():
    cfg = json.loads((HERE / "data" / "ex17_18_robust.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); EBV = np.array(cfg["ebv"]); k = cfg["k"]
    A_fit = scenarios(cfg, cfg["n_scen_fit"], rng); A_test = scenarios(cfg, cfg["n_scen_test"], rng)
    U = A_fit @ EBV.T                                                  # (S, n)
    rules = {}
    rules["(E) 期望最优"] = np.argsort(EBV @ np.array(cfg["a0"]))[-k:]
    rules["(M) 最坏情形"] = lp_select(U, k, "maxmin")
    rules["(C) CVaR 20%"] = lp_select(U, k, "cvar", cfg["alpha"])
    # (V) 均值−λ·SD：对每头计算单头价值的情景均值与标准差，贪婪（组合标准差用协方差，逐步加入）
    mu = U.mean(0); C = np.cov(U.T); chosen = []
    for _ in range(k):
        best, bj = -1e18, None
        for j in range(EBV.shape[0]):
            if j in chosen: continue
            idx = chosen + [j]; w = np.ones(len(idx)) / k
            val = mu[idx].sum() / k - cfg["lam"] * np.sqrt(w @ C[np.ix_(idx, idx)] @ w)
            if val > best: best, bj = val, j
        chosen.append(bj)
    rules["(V) 均值−λ·SD"] = np.array(chosen)
    print(f"{'规则':<16s}{'测试均值':>9s}{'5%分位':>9s}{'CVaR5%':>9s}{'平均后悔':>9s}{'最大后悔':>9s}  入选个数与期望最优重合")
    out = {}
    E = set(rules["(E) 期望最优"].tolist())
    for name, sel in rules.items():
        st = stats_for(sel, EBV, A_test); out[name] = dict(sel=sorted(map(int, sel)), **st)
        print(f"{name:<14s}{st['mean']:9.3f}{st['q5']:9.3f}{st['cvar5']:9.3f}{st['mean_regret']:9.3f}{st['max_regret']:9.3f}  {len(E & set(sel.tolist()))}/{k}")
    assert out["(E) 期望最优"]["mean"] >= max(v["mean"] for v in out.values()) - 1e-9
    assert out["(C) CVaR 20%"]["cvar5"] >= out["(E) 期望最优"]["cvar5"] - 0.02
    (HERE / "results" / "ex17_18_robust_selection.json").write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float))


if __name__ == "__main__":
    main()
