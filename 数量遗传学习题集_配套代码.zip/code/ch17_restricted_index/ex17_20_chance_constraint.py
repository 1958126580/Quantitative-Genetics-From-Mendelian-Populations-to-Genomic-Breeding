#!/usr/bin/env python3
"""习题 17.20  概率约束：遗传参数不确定时如何“兑现”不恶化承诺

沿用习题 17.15 的 4 性状模型（名义参数）。目标：采食量（性状 2，下标 1）的响应 Δ₁ ≤ 0 的概率不低于 conf。
令指数满足名义响应 Δ₁(b) = −c（c ≥ 0 为“安全边际”），在此约束下最大化 aᵀΔ（SLSQP，σ_I 标准化）。
参数不确定：遗传相关经 Fisher z 加噪声（SD = z_sd），遗传力加噪声（SD = h2_sd），再投影到最近的正定矩阵；
真实响应 Δ_true = i G_d b / √(bᵀ P_d b)（权重 b 固定，参数为抽样）。
对每个 c 计算 P(Δ₁ ≤ 0)（抽样）、响应的均值与 SD，并与两种解析近似比较：
    正态近似 Φ(−μ/σ) 与 Cantelli 单侧界（只用均值与方差）：P(Δ > 0) ≤ σ²/(σ² + μ²)，μ < 0。
输出达到 conf 所需的最小 c，以及相对无限制最优的 ΔH 代价。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import optimize, stats
from ex17_15_restricted_index import setup
HERE = Path(__file__).resolve().parent


def nearest_pd(M, eps=1e-6):
    w, V = np.linalg.eigh((M + M.T) / 2); return (V * np.maximum(w, eps)) @ V.T


def draw_params(cfg_pig, zsd, hsd, rng):
    RA = np.array(cfg_pig["rA"]); h2 = np.array(cfg_pig["h2"]); RE = np.array(cfg_pig["rE"]); sdA = np.array(cfg_pig["sdA"])
    n = len(h2); Z = np.arctanh(np.clip(RA, -0.999, 0.999)); Zn = Z + np.triu(rng.normal(0, zsd, (n, n)), 1)
    Zn = np.triu(Zn, 1); Zn = Zn + Zn.T; R = np.tanh(Zn); np.fill_diagonal(R, 1.0)
    h = np.clip(h2 + rng.normal(0, hsd, n), 0.05, 0.9)
    G = nearest_pd(np.outer(sdA, sdA) * R); sdE = sdA * np.sqrt((1 - h) / h)
    E = np.outer(sdE, sdE) * RE
    return G, G + nearest_pd(E)


def solve_b(G, P, a, i, j, c):
    cons = [{"type": "ineq", "fun": lambda b: 1 - b @ P @ b}, {"type": "eq", "fun": lambda b: i * G[j] @ b + c}]
    best = None
    for s in range(6):
        b0 = np.random.default_rng(s).standard_normal(len(a)); b0 /= np.sqrt(b0 @ P @ b0)
        r = optimize.minimize(lambda b: -i * a @ G @ b, b0, constraints=cons, method="SLSQP", options=dict(ftol=1e-14, maxiter=500))
        if r.success and (best is None or r.fun < best.fun): best = r
    return best.x


def main():
    cfg = json.loads((HERE / "data" / "ex17_20_chance.json").read_text())
    pig = json.loads((HERE / "data" / "ex17_15_pig.json").read_text())
    G0, P0, a = setup(pig); j = cfg["bad_trait"]; rng = np.random.default_rng(cfg["seed"])
    x = stats.norm.isf(cfg["p"]); i = stats.norm.pdf(x) / cfg["p"]
    draws = [draw_params(pig, cfg["z_sd"], cfg["h2_sd"], rng) for _ in range(cfg["n_draw"])]
    bad = pig["traits"][j]
    print(f"性状『{bad}』名义响应 = −c；confidence = {cfg['conf']}；参数抽样 {cfg['n_draw']} 次")
    print(f"{'c':>5s}{'名义ΔH':>9s}{'真实响应均值':>12s}{'SD':>7s}{'P(Δ≤0) 抽样':>12s}{'正态':>7s}{'Cantelli下界':>13s}")
    rows = []
    for c in cfg["cgrid"]:
        b = solve_b(G0, P0, a, i, j, c); H = a @ (i * G0 @ b)
        D = np.array([i * Gd[j] @ b / np.sqrt(b @ Pd @ b) for Gd, Pd in draws])
        mu, sd = D.mean(), D.std(); p_mc = (D <= 0).mean(); p_n = stats.norm.cdf(-mu / sd)
        p_c = 1 - sd ** 2 / (sd ** 2 + mu ** 2) if mu < 0 else 0.0
        rows.append(dict(c=c, H=H, mu=mu, sd=sd, p_mc=p_mc, p_norm=p_n, p_cantelli=p_c))
        print(f"{c:5.2f}{H:9.3f}{mu:12.4f}{sd:7.4f}{p_mc:12.3f}{p_n:7.3f}{p_c:13.3f}")
        assert abs(p_mc - p_n) < 0.05
        assert p_mc >= p_c - 0.01
    ok = [r for r in rows if r["p_mc"] >= cfg["conf"]]
    b_un = np.linalg.solve(P0, G0 @ a); H0 = a @ (i * G0 @ b_un / np.sqrt(b_un @ P0 @ b_un))     # 无限制最优
    if ok:
        r = ok[0]; print(f"\n抽样意义下满足 {cfg['conf']:.0%} 概率约束的最小 c = {r['c']}，ΔH = {r['H']:.3f}（相对无限制最优 {H0:.3f} 损失 {100 * (1 - r['H'] / H0):.1f}%）")
    ok2 = [r for r in rows if r["p_cantelli"] >= cfg["conf"]]
    print("Cantelli 保障下界达到 {:.0%} 的最小 c：{}".format(cfg["conf"], ok2[0]["c"] if ok2 else "网格内不可达"))
    (HERE / "results" / "ex17_20_chance_constraint.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
