#!/usr/bin/env python3
"""习题 17.15  零响应限制指数：把“不能恶化”写成约束并计算代价

4 个性状（日增重、采食量、背膘厚、瘦肉率），候选的信息为自身全部 4 条记录。
G = D_A R_A D_A，P = G + E（E 由 h² 与 R_E 构成），经济权重 a。
无限制指数 b₀ = P⁻¹ G a；预期遗传响应 Δ = i G b/σ_I，σ_I = √(bᵀPb)，总进展 ΔH = aᵀΔ。
零响应限制 K'Δ = 0（K 的列为被限制性状的单位向量）的 Kempthorne–Nordskog 解
    b_r = P⁻¹ G [ a − K (Kᵀ G P⁻¹ G K)⁻¹ Kᵀ G P⁻¹ G a ]。
输出：各性状响应、ΔH、效率损失、拉格朗日乘数（限制的影子价格）及蒙特卡洛核对。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats
HERE = Path(__file__).resolve().parent


def setup(cfg):
    sdA = np.array(cfg["sdA"]); RA = np.array(cfg["rA"]); h2 = np.array(cfg["h2"]); RE = np.array(cfg["rE"])
    G = np.outer(sdA, sdA) * RA
    sdE = sdA * np.sqrt((1 - h2) / h2)
    E = np.outer(sdE, sdE) * RE
    return G, G + E, np.array(cfg["a"], float)


def gains(b, G, P, i):
    sI = np.sqrt(b @ P @ b); return i * (G @ b) / sI, sI


def restricted_weights(G, P, a, idx):
    Pi_G = np.linalg.solve(P, G)                       # P⁻¹G
    K = np.eye(len(a))[:, idx]
    M = K.T @ G @ Pi_G @ K                               # Kᵀ G P⁻¹ G K
    lam = np.linalg.solve(M, K.T @ G @ Pi_G @ a)        # 拉格朗日乘数
    return Pi_G @ (a - K @ lam), lam


def main():
    cfg = json.loads((HERE / "data" / "ex17_15_pig.json").read_text())
    G, P, a = setup(cfg); names = cfg["traits"]; p = cfg["p"]
    x = stats.norm.isf(p); i = stats.norm.pdf(x) / p
    b0 = np.linalg.solve(P, G @ a); d0, s0 = gains(b0, G, P, i); H0 = a @ d0
    print(f"选择强度 i = {i:.3f}；无限制：" + "，".join(f"{n} {v:+.3f}" for n, v in zip(names, d0)) + f"；ΔH = {H0:.3f}")
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n_mc"]
    L = np.linalg.cholesky(G); A_true = rng.standard_normal((n, 4)) @ L.T
    Eres = rng.standard_normal((n, 4)) @ np.linalg.cholesky(P - G).T; Y = A_true + Eres
    out = {"unrestricted": dict(b=b0.tolist(), gain=d0.tolist(), H=H0)}
    for label, cols in cfg["constraints"].items():
        b, lam = restricted_weights(G, P, a, cols); d, s = gains(b, G, P, i); H = a @ d
        assert np.allclose(d[cols], 0, atol=1e-9) and H <= H0 + 1e-9
        I = Y @ b; sel = I >= np.quantile(I, 1 - p); dmc = A_true[sel].mean(0)
        assert np.allclose(dmc, d, atol=0.02), (dmc, d)
        print(f"\n【{label}】权重 b = {np.round(b, 3)}；λ = {np.round(lam, 3)}")
        print("  响应：" + "，".join(f"{nm} {v:+.3f}" for nm, v in zip(names, d)) + f"；ΔH = {H:.3f}，损失 {100 * (1 - H / H0):.1f}%")
        print("  MC 响应：" + "，".join(f"{v:+.3f}" for v in dmc))
        out[label] = dict(b=b.tolist(), gain=d.tolist(), H=H, loss=1 - H / H0, lam=lam.tolist(), mc=dmc.tolist())
    # 限制越多越不利：二者的嵌套关系
    assert out["采食量与背膘不变"]["H"] <= out["采食量不变"]["H"] + 1e-9
    (HERE / "results" / "ex17_15_restricted_index.json").write_text(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
