#!/usr/bin/env python3
"""习题 17.19  联合预测误差与组合风险：同一家系的候选共担误差

30 头候选来自 6 个家系（每家系 5 头），EBV 的预测误差方差均为 PEV，家系内误差相关 ρ，家系间独立。
真实育种值 g = EBV + e，e ~ N(0, Σ)。选 k 头，群体平均真实育种值  ḡ = (1/k)Σ_{j∈S} g_j ，
其期望 m(S) = (1/k)Σ EBV_j，方差 v(S) = (1/k²) 1ᵀΣ_S 1。
风险调整选择：最大化 m(S) − λ √v(S)（贪婪法 + 交换改进）；λ = 0 即按 EBV 取前 k。
指标：期望均值、标准差、ḡ 低于阈值的概率（抽样与解析 Φ 对照）、入选家系数。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats
HERE = Path(__file__).resolve().parent


def build_sigma(fam, pev, rho):
    S = np.where(fam[:, None] == fam[None, :], rho * pev, 0.0); np.fill_diagonal(S, pev); return S


def score(S, ebv, Sigma, lam, k):
    idx = list(S); m = ebv[idx].mean(); v = Sigma[np.ix_(idx, idx)].sum() / k ** 2
    return m - lam * np.sqrt(v), m, v


def select(ebv, Sigma, lam, k):
    chosen = []
    for _ in range(k):
        best = max((j for j in range(len(ebv)) if j not in chosen), key=lambda j: score(chosen + [j], ebv, Sigma, lam, len(chosen) + 1)[0])
        chosen.append(best)
    improved = True                                              # 交换改进
    while improved:
        improved = False; cur = score(chosen, ebv, Sigma, lam, k)[0]
        for a_i, a in enumerate(chosen):
            for b in range(len(ebv)):
                if b in chosen: continue
                trial = chosen.copy(); trial[a_i] = b
                if score(trial, ebv, Sigma, lam, k)[0] > cur + 1e-12:
                    chosen, improved = trial, True; break
            if improved: break
    return chosen


def main():
    cfg = json.loads((HERE / "data" / "ex17_19_combination.json").read_text())
    fam = np.array(cfg["family"]); ebv = np.array(cfg["ebv"]); k = cfg["k"]; thr = cfg["threshold"]
    Sigma = build_sigma(fam, cfg["pev"], cfg["rho_within"])
    rng = np.random.default_rng(cfg["seed"]); L = np.linalg.cholesky(Sigma)
    E = rng.standard_normal((cfg["n_draw"], len(ebv))) @ L.T
    print(f"PEV = {cfg['pev']}，家系内误差相关 ρ = {cfg['rho_within']}，选 k = {k}，阈值 {thr}")
    print(f"{'λ':>4s}{'期望均值':>9s}{'SD(ḡ)':>8s}{'SD 采样':>9s}{'P(ḡ<阈值) 解析':>16s}{'采样':>7s}{'家系数':>6s}  入选家系计数")
    out = []
    for lam in cfg["lams"]:
        S = select(ebv, Sigma, lam, k); sc, m, v = score(S, ebv, Sigma, lam, k)
        gbar = (ebv[S] + E[:, S]).mean(1)
        p_th = stats.norm.cdf((thr - m) / np.sqrt(v)); p_mc = (gbar < thr).mean()
        assert abs(gbar.std() - np.sqrt(v)) < 0.01 and abs(p_th - p_mc) < 0.01
        cnt = np.bincount(fam[S], minlength=fam.max() + 1).tolist()
        out.append(dict(lam=lam, mean=m, sd=np.sqrt(v), p_below=p_th, families=int((np.array(cnt) > 0).sum()), counts=cnt, sel=S))
        print(f"{lam:4.1f}{m:9.3f}{np.sqrt(v):8.3f}{gbar.std():9.3f}{p_th:16.4f}{p_mc:7.3f}{(np.array(cnt) > 0).sum():6d}  {cnt}")
    (HERE / "results" / "ex17_19_combination_risk.json").write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float))


if __name__ == "__main__":
    main()
