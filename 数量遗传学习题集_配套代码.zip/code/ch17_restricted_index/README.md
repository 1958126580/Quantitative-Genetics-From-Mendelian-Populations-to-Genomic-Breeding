# 第17章　限制指数、非线性目标与稳健决策——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex17_15_restricted_index.py
python3 ex17_16_inequality_constraints.py
python3 ex17_17_optimum_target.py
python3 ex17_18_robust_selection.py
python3 ex17_19_combination_risk.py
python3 ex17_20_chance_constraint.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex17_15_restricted_index.py | 17.15 | 零响应限制指数：把“不能恶化”写成约束并计算代价 |
| ex17_16_inequality_constraints.py | 17.16 | 不等式限制、活跃集合与最优性证书 |
| ex17_17_optimum_target.py | 17.17 | 存在最适值的目标：预测均值之外还要看不确定性 |
| ex17_18_robust_selection.py | 17.18 | 经济权重不确定时的稳健选择：期望、最坏情形与条件风险价值 |
| ex17_19_combination_risk.py | 17.19 | 联合预测误差与组合风险：同一家系的候选共担误差 |
| ex17_20_chance_constraint.py | 17.20 | 概率约束：遗传参数不确定时如何“兑现”不恶化承诺 |
