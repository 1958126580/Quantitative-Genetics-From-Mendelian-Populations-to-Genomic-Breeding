#!/usr/bin/env python3
"""习题 19.16  漂变下遗传方差在系内与系间的再分配：精确的 Wright–Fisher 转移矩阵计算

由同一基础群体建立无穷多个有效大小为 N_e 的小系（系内随机交配）。第 t 代各系等位基因频率的分布
由 2N_e+1 状态的 Wright–Fisher 转移矩阵精确给出（二项抽样），不需要随机模拟。对每个系：
    基因型值 +a（A1A1）、d（A1A2）、−a（A2A2）；p 为 A1 频率；
    系均值      M = a(p − q) + 2pqd；
    系内加性方差 V_A = 2pq α²，α = a + d(q − p)；系内显性方差 V_D = (2pqd)²。
跨系求期望得：系内平均 V_A、V_D，系间方差 Var(M)，平均近交衰退 E(M) − M0。
理论核验：
    (1) 无显性时 E(V_A,w) = (1 − F)V_A0、Var(M) = 2F V_A0（式 19.1 表）；
    (2) 任何显性下 E(M) = M0 − 2p0q0 d F（近交衰退对 F 线性）；
    (3) E(p) = p0（漂变不改变期望频率）。
其中 F_t = 1 − (1 − 1/2N_e)^t。完全隐性且隐性等位基因低频时，系内加性方差在中等 F 时暂时上升。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import binom

HERE = Path(__file__).resolve().parent


def wf_matrix(two_n: int) -> np.ndarray:
    """T[i, j] = P(下一代 j 个 A1 | 本代 i 个 A1)。"""
    i = np.arange(two_n + 1)
    return binom.pmf(i[None, :], two_n, (i / two_n)[:, None])


def line_moments(dist: np.ndarray, two_n: int, a: float, d: float) -> dict:
    p = np.arange(two_n + 1) / two_n; q = 1 - p
    M = a * (p - q) + 2 * p * q * d
    alpha = a + d * (q - p)
    VA = 2 * p * q * alpha ** 2; VD = (2 * p * q * d) ** 2
    EM = dist @ M
    return {"Ep": float(dist @ p), "EM": float(EM), "VA_w": float(dist @ VA), "VD_w": float(dist @ VD),
            "V_between": float(dist @ (M - EM) ** 2)}


def main():
    cfg = json.loads((HERE / "data" / "ex19_16_variance_drift.json").read_text(encoding="utf-8"))
    Ne = cfg["Ne"]; two_n = 2 * Ne
    T = wf_matrix(two_n)
    assert np.allclose(T.sum(1), 1.0)
    gens = cfg["generations"]; tmax = max(gens)
    results = []
    print(f"N_e = {Ne}，精确转移矩阵 {two_n + 1}×{two_n + 1}；方差以基础群体 V_A0 为单位")
    for case in cfg["cases"]:
        a, d, q0 = case["a"], case["d"], case["q0"]; p0 = 1 - q0
        i0 = int(round(p0 * two_n)); assert abs(i0 / two_n - p0) < 1e-12, "p0 须为 1/2N_e 的整数倍"
        dist = np.zeros(two_n + 1); dist[i0] = 1.0
        base = line_moments(dist, two_n, a, d); VA0 = base["VA_w"]; M0 = base["EM"]
        rows = []
        print(f"\n【{case['name']}】a={a}, d={d}：V_A0 = {VA0:.4f}，V_D0 = {base['VD_w']:.4f}，M0 = {M0:.4f}")
        print(f"{'t':>4s}{'F':>8s}{'系内V_A':>9s}{'系内V_D':>9s}{'系间方差':>9s}{'合计':>8s}{'衰退':>9s}{'理论衰退':>9s}")
        for t in range(tmax + 1):
            if t in gens:
                F = 1 - (1 - 1 / two_n) ** t
                m = line_moments(dist, two_n, a, d)
                dep_th = -2 * p0 * q0 * d * F
                # 理论核验
                assert abs(m["Ep"] - p0) < 1e-10
                assert abs((m["EM"] - M0) - dep_th) < 1e-10
                if d == 0:
                    assert abs(m["VA_w"] - (1 - F) * VA0) < 1e-10 and abs(m["V_between"] - 2 * F * VA0) < 1e-10
                r = {"t": t, "F": F, "VA_within": m["VA_w"] / VA0, "VD_within": m["VD_w"] / VA0,
                     "V_between": m["V_between"] / VA0, "depression": m["EM"] - M0}
                r["total"] = r["VA_within"] + r["VD_within"] + r["V_between"]
                rows.append(r)
                print(f"{t:4d}{F:8.3f}{r['VA_within']:9.3f}{r['VD_within']:9.3f}{r['V_between']:9.3f}"
                      f"{r['total']:8.3f}{r['depression']:9.4f}{dep_th:9.4f}")
            dist = dist @ T
        peak = max(rows, key=lambda r: r["VA_within"])
        results.append({"case": case, "VA0": VA0, "VD0": base["VD_w"], "rows": rows,
                        "peak_VA_within": peak["VA_within"], "peak_F": peak["F"]})
        print(f"  系内加性方差最大值 {peak['VA_within']:.3f} V_A0（F = {peak['F']:.3f}）")
    rec_low = [r for r in results if r["case"]["q0"] == 0.1][0]
    assert rec_low["peak_VA_within"] > 1.0, "低频隐性时系内 V_A 应暂时超过基础值"
    print("\n核验通过：E(p)=p0；衰退 = −2p0q0dF；无显性时系内 (1−F)V_A0、系间 2F V_A0（精确到 1e-10）。")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex19_16_variance_redistribution.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    from _plot import get_pyplot
    plt = get_pyplot()
    if plt is not None:
        fig, ax = plt.subplots(figsize=(6, 4))
        for r in results:
            ax.plot([x["F"] for x in r["rows"]], [x["VA_within"] for x in r["rows"]], marker="o", ms=3, label=r["case"]["name"])
        ax.plot([0, 1], [1, 0], "k--", lw=1, label="(1−F)V_A0")
        ax.set_xlabel("近交系数 F"); ax.set_ylabel("系内加性方差 / V_A0"); ax.legend(fontsize=8); ax.grid(alpha=.3)
        fig.tight_layout(); fig.savefig(HERE / "results" / "ex19_16_variance_redistribution.png"); plt.close(fig)


if __name__ == "__main__":
    main()
