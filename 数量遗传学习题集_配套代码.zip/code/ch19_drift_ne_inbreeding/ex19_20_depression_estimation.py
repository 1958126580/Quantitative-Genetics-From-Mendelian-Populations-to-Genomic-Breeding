#!/usr/bin/env python3
"""习题 19.20  近交衰退的估计：系谱深度、家系相关与标准误

闭锁群体：创始者 6 公 18 母（无关、非近交），每代 96 个后代，随机选 6 公 18 母为下一代亲本，共 G 代。
表型 y = μ + b·F + a + e，a 为育种值（V_A0，含 Mendelian 抽样与近交），e ~ N(0, V_e)，b 为近交衰退（b < 0）。
只对最后三代（第 G−2…G 代）有记录。比较四种估计：
  OLS-完整   ：y 对完整系谱的 F 作普通最小二乘；
  OLS-浅系谱 ：y 对仅从第 s 代起已知的系谱 F 作 OLS（更早世代的亲本当作未知）；
  GLS-完整   ：y = μ + bF + a + e，V = V_A A + V_e I（A 为完整系谱关系阵，方差已知）的广义最小二乘；
  GLS-浅系谱 ：同上但用浅系谱的 F 与 A。
报告：b 的均值（偏倚）、跨重复 SD、模型报告的平均标准误、名义 95% 区间覆盖率。
结论：浅系谱引入测量误差（衰减偏倚）；忽略家系相关使 OLS 的标准误偏小，覆盖率不足。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


def build_pop(cfg, rng):
    nm, nf, ncand, G = cfg["keep_male"], cfg["keep_female"], cfg["candidates_per_gen"], cfg["generations"]
    VA = cfg["VA0"]; n0 = nm + nf
    gen = [np.zeros(n0, int)]; sire = [-np.ones(n0, int)]; dam = [-np.ones(n0, int)]
    a = rng.normal(0, np.sqrt(VA), n0); F = np.zeros(n0)
    A = np.eye(n0); par_m = np.arange(nm); par_f = np.arange(nm, n0)
    for g in range(1, G + 1):
        S = rng.choice(par_m, ncand); D = rng.choice(par_f, ncand)
        n = len(a); rows = 0.5 * (A[S] + A[D])
        Anew = np.zeros((n + ncand, n + ncand)); Anew[:n, :n] = A; Anew[n:, :n] = rows; Anew[:n, n:] = rows.T
        blk = 0.25 * (A[np.ix_(S, S)] + A[np.ix_(S, D)] + A[np.ix_(D, S)] + A[np.ix_(D, D)])
        Fn = 0.5 * A[S, D]; blk[np.diag_indices(ncand)] = 1 + Fn; Anew[n:, n:] = blk; A = Anew
        mv = VA * (1 - 0.5 * (F[S] + F[D])) / 2
        a = np.r_[a, 0.5 * (a[S] + a[D]) + rng.standard_normal(ncand) * np.sqrt(mv)]; F = np.r_[F, Fn]
        gen.append(np.full(ncand, g)); sire.append(S); dam.append(D)
        idx = np.arange(n, n + ncand); sex = rng.permutation(np.r_[np.zeros(ncand // 2, int), np.ones(ncand - ncand // 2, int)])
        par_m = rng.choice(idx[sex == 0], nm, replace=False); par_f = rng.choice(idx[sex == 1], nf, replace=False)
    return np.concatenate(gen), np.concatenate(sire), np.concatenate(dam), a, F, A


def shallow_A(gen, sire, dam, s):
    """仅从第 s 代起已知系谱：第 ≤ s 代个体视为无关创始者。返回 (A, F)。"""
    n = len(gen); A = np.zeros((n, n)); F = np.zeros(n)
    for i in range(n):
        if gen[i] <= s:
            A[i, :i] = 0; A[:i, i] = 0; A[i, i] = 1; continue
        S, D = sire[i], dam[i]
        row = 0.5 * (A[S, :i] + A[D, :i]); A[i, :i] = row; A[:i, i] = row; F[i] = 0.5 * A[S, D]; A[i, i] = 1 + F[i]
    return A, F


def ols(y, x):
    X = np.column_stack([np.ones(len(y)), x]); XtX = np.linalg.inv(X.T @ X); beta = XtX @ X.T @ y
    r = y - X @ beta; s2 = r @ r / (len(y) - 2); return beta[1], np.sqrt(s2 * XtX[1, 1])


def gls(y, x, A, VA, Ve):
    X = np.column_stack([np.ones(len(y)), x]); V = VA * A + Ve * np.eye(len(y))
    Li = np.linalg.cholesky(V); Z = np.linalg.solve(Li, X); w = np.linalg.solve(Li, y)
    C = np.linalg.inv(Z.T @ Z); beta = C @ Z.T @ w; return beta[1], np.sqrt(C[1, 1])


def main():
    cfg = json.loads((HERE / "data" / "ex19_20_depression.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); G, s = cfg["generations"], cfg["shallow_from_generation"]
    VA, Ve, b0, mu = cfg["VA0"], cfg["Ve"], cfg["b_true"], cfg["mu"]
    names = ["OLS-完整", "OLS-浅系谱", "GLS-完整", "GLS-浅系谱"]; est = {k: [] for k in names}; se = {k: [] for k in names}
    corr_shallow, mF = [], []
    for rep in range(cfg["reps"]):
        gen, sire, dam, a, F, A = build_pop(cfg, rng)
        As, Fs = shallow_A(gen, sire, dam, s); rec = np.where(gen >= G - 2)[0]
        y = mu + b0 * F[rec] + a[rec] + rng.normal(0, np.sqrt(Ve), len(rec))
        Ar, Asr = A[np.ix_(rec, rec)], As[np.ix_(rec, rec)]
        for k, (x, M, f) in {"OLS-完整": (F[rec], None, ols), "OLS-浅系谱": (Fs[rec], None, ols),
                             "GLS-完整": (F[rec], Ar, gls), "GLS-浅系谱": (Fs[rec], Asr, gls)}.items():
            r = f(y, x) if M is None else f(y, x, M, VA, Ve); est[k].append(r[0]); se[k].append(r[1])
        corr_shallow.append(np.corrcoef(F[rec], Fs[rec])[0, 1]); mF.append((F[rec].mean(), Fs[rec].mean()))
    print(f"真实 b = {b0}；记录 = 最后三代；浅系谱：第 ≤ {s} 代视为无关创始者；{cfg['reps']} 次重复")
    mf = np.mean(mF, axis=0); print(f"平均 F：完整 {mf[0]:.3f}，浅系谱 {mf[1]:.3f}；F 与 F_浅 的平均相关 {np.mean(corr_shallow):.3f}")
    print(f"{'方法':<12s}{'b̂ 均值':>9s}{'偏倚':>8s}{'SD':>7s}{'平均SE':>8s}{'覆盖率':>8s}")
    out = {}
    for k in names:
        e, s_ = np.array(est[k]), np.array(se[k]); cov = np.mean(np.abs(e - b0) < 1.96 * s_)
        out[k] = dict(mean=e.mean(), sd=e.std(ddof=1), se=s_.mean(), cover=cov)
        print(f"{k:<12s}{e.mean():9.3f}{e.mean() - b0:8.3f}{e.std(ddof=1):7.3f}{s_.mean():8.3f}{cov:8.2f}")
    assert out["GLS-完整"]["mean"] < 0 and abs(out["GLS-完整"]["mean"] - b0) < 3 * out["GLS-完整"]["se"] / np.sqrt(cfg["reps"]) + 0.25
    assert abs(out["OLS-浅系谱"]["mean"]) < abs(out["OLS-完整"]["mean"]) + 0.3
    (HERE / "results" / "ex19_20_depression_estimation.json").write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float))


if __name__ == "__main__":
    main()
