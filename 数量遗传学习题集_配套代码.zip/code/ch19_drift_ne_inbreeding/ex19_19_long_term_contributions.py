#!/usr/bin/env python3
"""习题 19.19  长期遗传贡献：同时预测近交速率与遗传进展（Woolliams–Bijma 理论）

无穷小模型：a_i = (a_s + a_d)/2 + m_i，m_i ~ N(0, ½[1 − (F_s+F_d)/2]V_A0)；y = a + e，h² = 0.3。
每代 10 公 40 母，每公配 4 母、每母 4 个后代（2 公 2 母，构成全同胞家系），从 80 公 80 母候选中选留。
三种选留：random（随机）、phenotype（个体表型）、family_index（Lush 家系指数：
    I = b_w(y − ȳ_FS) + b_f ȳ_FS，b_w = h²(1−r)/(1−t)，b_f = h²[1+(n−1)r]/[1+(n−1)t]，r = ½，t = ½h²）。
对第 t0 代候选个体，计算它们在 t0 + L 代全部候选中的平均基因比例 r_i（长期贡献），并核验
    Σ r_i = 1，雄性 Σ r_i = 1/2；
    预测近交速率 ΔF ≈ ¼ Σ r_i²（随机配种，α = 0）——与由系谱递推得到的实现 ΔF 比较；
    预测遗传进展 ΔG ≈ Σ r_i m_i（m_i 为该队列的孟德尔抽样项）——与真实育种值均值的世代回归比较。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def index_values(y, fam, h2, n):
    r, t = 0.5, 0.5 * h2
    bw = h2 * (1 - r) / (1 - t); bf = h2 * (1 + (n - 1) * r) / (1 + (n - 1) * t)
    fam_mean = np.bincount(fam, weights=y) / np.bincount(fam)
    return bw * (y - fam_mean[fam]) + bf * (fam_mean[fam] - y.mean())


def run(scheme, cfg, rng):
    nm, nf, k = cfg["males"], cfg["females"], cfg["offspring_per_dam"]
    h2, VA0 = cfg["h2"], cfg["VA0"]; Ve = VA0 * (1 - h2) / h2; G = cfg["generations"]
    a_par = rng.normal(0, np.sqrt(VA0), nm + nf); A_par = np.eye(nm + nf)
    meanF, meanA = [], []
    cohorts = {t0: None for t0 in cfg["cohorts"]}       # t0 → 当前代候选对 t0 队列的基因比例矩阵
    cohort_info, contrib = {}, {}
    for t in range(1, G + 1):
        dams_per_sire = nf // nm
        sire_of_dam = rng.permutation(np.repeat(np.arange(nm), dams_per_sire))
        dam = np.repeat(np.arange(nf), k); sire = sire_of_dam[dam]
        sex = np.tile(np.array([0, 0, 1, 1])[:k], nf)       # 每窝 2 公 2 母
        si, di = sire, nm + dam                             # 亲本行号
        n = len(dam)
        P = np.zeros((n, nm + nf)); P[np.arange(n), si] += 0.5; P[np.arange(n), di] += 0.5
        A = P @ A_par @ P.T
        Fi = 0.5 * A_par[si, di]; np.fill_diagonal(A, 1 + Fi)
        Fpar = np.diag(A_par) - 1
        ms = rng.normal(0, np.sqrt(0.5 * (1 - 0.5 * (Fpar[si] + Fpar[di])) * VA0))
        a = 0.5 * (a_par[si] + a_par[di]) + ms
        y = a + rng.normal(0, np.sqrt(Ve), n)
        meanF.append(Fi.mean()); meanA.append(a.mean())
        # 基因比例：当前候选对各队列个体的贡献
        for t0 in cohorts:
            if t == t0:
                cohorts[t0] = np.eye(n); cohort_info[t0] = {"sex": sex.copy(), "ms": ms.copy()}
            elif cohorts[t0] is not None:
                cohorts[t0] = P @ cohorts[t0]
            if cohorts[t0] is not None and t == t0 + cfg["horizon"]:
                contrib[t0] = cohorts[t0].mean(0); cohorts[t0] = None   # 取完即释放
        # 选留
        if scheme == "random":
            crit = rng.random(n)
        elif scheme == "phenotype":
            crit = y
        else:
            crit = index_values(y, dam, h2, k)
        males = np.flatnonzero(sex == 0); females = np.flatnonzero(sex == 1)
        sm = males[np.argsort(-crit[males])[:nm]]; sf = females[np.argsort(-crit[females])[:nf]]
        sel = np.concatenate([sm, sf])
        for t0 in cohorts:                                  # 只把被选个体的行带到下一代
            if cohorts[t0] is not None and t < t0 + cfg["horizon"]:
                cohorts[t0] = cohorts[t0][sel]
        a_par, A_par = a[sel], A[np.ix_(sel, sel)]
    return np.array(meanF), np.array(meanA), contrib, cohort_info


def main():
    cfg = json.loads((HERE / "data" / "ex19_19_contributions.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); t0f = cfg["fit_from"]
    summary = {}
    print(f"每代 {cfg['males']} 公 {cfg['females']} 母，h² = {cfg['h2']}，{cfg['generations']} 代 × {cfg['reps']} 次重复；"
          f"长期贡献取 L = {cfg['horizon']} 代后的基因比例")
    print(f"{'方案':<13s}{'实现ΔF':>8s}{'¼Σr²':>8s}{'实现ΔG':>8s}{'Σr·m':>8s}{'Σr²/随机':>9s}{'有贡献者':>8s}")
    for sc in cfg["schemes"]:
        dF_real, dF_pred, dG_real, dG_pred, sum_r2, ncontrib = [], [], [], [], [], []
        for _ in range(cfg["reps"]):
            F, Am, contrib, info = run(sc, cfg, rng)
            t = np.arange(1, len(F) + 1)[t0f - 1:]
            dF_real.append(1 - np.exp(np.polyfit(t, np.log(1 - F[t0f - 1:]), 1)[0]))
            dG_real.append(np.polyfit(t, Am[t0f - 1:], 1)[0])
            for t0, r in contrib.items():
                assert abs(r.sum() - 1) < 1e-10 and abs(r[info[t0]["sex"] == 0].sum() - 0.5) < 1e-10
                dF_pred.append(0.25 * np.sum(r ** 2)); dG_pred.append(r @ info[t0]["ms"])
                sum_r2.append(np.sum(r ** 2)); ncontrib.append(int((r > 1e-12).sum()))
        s = {"dF_real": float(np.mean(dF_real)), "dF_pred": float(np.mean(dF_pred)),
             "dG_real": float(np.mean(dG_real)), "dG_pred": float(np.mean(dG_pred)),
             "sum_r2": float(np.mean(sum_r2)), "n_contributors": float(np.mean(ncontrib))}
        summary[sc] = s
    for sc, s in summary.items():
        print(f"{sc:<13s}{s['dF_real']:8.4f}{s['dF_pred']:8.4f}{s['dG_real']:8.3f}{s['dG_pred']:8.3f}"
              f"{s['sum_r2'] / summary['random']['sum_r2']:9.2f}{s['n_contributors']:8.1f}")
    Ne_sr = 4 * cfg["males"] * cfg["females"] / (cfg["males"] + cfg["females"])
    print(f"性别比公式：N_e = {Ne_sr:.1f}，ΔF = {1 / (2 * Ne_sr):.4f}")
    for sc, s in summary.items():
        assert abs(s["dF_pred"] / s["dF_real"] - 1) < 0.35, f"{sc}: ¼Σr² 与实现 ΔF 相差过大"
        if sc != "random":
            assert abs(s["dG_pred"] / s["dG_real"] - 1) < 0.3, f"{sc}: Σr·m 与实现 ΔG 相差过大"
    assert summary["family_index"]["dF_real"] > summary["phenotype"]["dF_real"] > summary["random"]["dF_real"] * 0.9
    print("核验通过：Σr = 1、雄性 Σr = 1/2；¼Σr² 与实现 ΔF、Σr·m 与实现 ΔG 的偏差均 < 35%。")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex19_19_long_term_contributions.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
