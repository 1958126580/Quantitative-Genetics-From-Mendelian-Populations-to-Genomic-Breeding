#!/usr/bin/env python3
"""习题 19.18  系谱近交、实现近交与基因组近交（F_ROH、F_HOM、F_GRM、F_UNI）及近交衰退估计

模拟闭锁小群体（每代 5 公 15 母随机交配，8 代），基因组为 4 条 1 摩尔根的常染色体、各 1500 个等距 SNP；
减数分裂时交叉数 ~ Poisson(染色体长度)，位置均匀（无干涉）。每个创始者单倍型带唯一“祖先标签”，
可直接得到真实的同祖同源（IBD）片段，从而得到实现近交 F_true。对末代 300 个个体计算：
    F_PED ：表格法 A 的对角元 − 1；
    F_ROH ：长度 ≥ 1 cM 与 ≥ 4 cM 的纯合片段总长 / 基因组长度；
    F_HOM ：(O − E)/(M − E)，E = Σ(1 − 2p_jq_j)；
    F_GRM ：VanRaden G 的对角元 − 1（分别用当代样本频率与创始者真实频率）；
    F_UNI ：Yang 等 (2011) 的 [x² − (1+2p)x + 2p²]/(2pq) 的平均。
再以 y = μ + βF_true + e 产生表型，分别用各近交指标回归估计近交衰退，说明测量误差带来的衰减偏倚
b_x = β·Cov(F_true, x)/Var(x) + Cov(e, x)/Var(x)（代数恒等式，程序核验）。
其他核验：F_true 的两种算法（标签逐位点比较、IBD 片段长度求和）一致；E(F_true) ≈ E(F_PED)。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


class Genome:
    def __init__(self, cfg, rng):
        self.nc, self.m, self.L = cfg["chromosomes"], cfg["snps_per_chrom"], cfg["chrom_length_M"]
        self.pos = (np.arange(self.m) + 0.5) * self.L / self.m        # 每条染色体内的遗传位置（摩尔根）
        self.spacing_cM = 100 * self.L / self.m
        self.rng = rng

    def gamete(self, hap: np.ndarray) -> np.ndarray:
        out = np.empty(hap.shape[1], dtype=hap.dtype)
        for c in range(self.nc):
            sl = slice(c * self.m, (c + 1) * self.m)
            xo = np.sort(self.rng.uniform(0, self.L, self.rng.poisson(self.L)))
            strand = (self.rng.integers(0, 2) + np.searchsorted(xo, self.pos)) % 2
            out[sl] = np.where(strand == 0, hap[0, sl], hap[1, sl])
        return out


def simulate(cfg, rng):
    gen = Genome(cfg, rng)
    n_snp = gen.nc * gen.m
    nfd = cfg["founders_male"] + cfg["founders_female"]
    base_p = rng.uniform(0.05, 0.95, n_snp)
    allele = (rng.random((2 * nfd, n_snp)) < base_p).astype(np.int8)   # 创始单倍型的 SNP 等位基因
    haps = [np.array([np.full(n_snp, 2 * i, np.int16), np.full(n_snp, 2 * i + 1, np.int16)]) for i in range(nfd)]
    ped = [(-1, -1)] * nfd
    males = list(range(cfg["founders_male"])); females = list(range(cfg["founders_male"], nfd))
    for g in range(cfg["generations"] + 1):
        n_off = cfg["final_offspring"] if g == cfg["generations"] else cfg["offspring_per_gen"]
        new = []
        for k in range(n_off):
            s, d = int(rng.choice(males)), int(rng.choice(females))
            haps.append(np.array([gen.gamete(haps[s]), gen.gamete(haps[d])])); ped.append((s, d)); new.append(len(ped) - 1)
        if g < cfg["generations"]:
            half = n_off // 2
            males = list(rng.choice(new[:half], cfg["males"], replace=False))
            females = list(rng.choice(new[half:], cfg["females"], replace=False))
    final = np.array(new)
    return gen, ped, haps, allele, base_p, final


def pedigree_F(ped) -> np.ndarray:
    n = len(ped); A = np.zeros((n, n))
    for i, (s, d) in enumerate(ped):
        if s >= 0:
            A[i, :i] = 0.5 * (A[s, :i] + A[d, :i]); A[:i, i] = A[i, :i]
            A[i, i] = 1 + 0.5 * A[s, d]
        else:
            A[i, i] = 1.0
    return np.diag(A) - 1


def runs(mask: np.ndarray):
    """返回布尔数组中连续 True 段的 (起点, 终点+1)。"""
    m = np.concatenate([[False], mask, [False]]).astype(np.int8)
    d = np.diff(m)
    return np.flatnonzero(d == 1), np.flatnonzero(d == -1)


def segments_cM(mask_all: np.ndarray, gen: Genome):
    seg = []
    for c in range(gen.nc):
        a, b = runs(mask_all[c * gen.m:(c + 1) * gen.m])
        seg.extend(((b - a) * gen.spacing_cM).tolist())
    return np.array(seg)


def main():
    cfg = json.loads((HERE / "data" / "ex19_18_genomic_F.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    gen, ped, haps, allele, base_p, final = simulate(cfg, rng)
    genome_cM = 100 * gen.nc * gen.L
    Fped = pedigree_F(ped)[final]
    H = np.array([haps[i] for i in final])                                # (n, 2, M)
    n, _, M = H.shape
    snp = np.arange(M)
    X = allele[H[:, 0], snp] + allele[H[:, 1], snp]                      # 0/1/2
    ibd = H[:, 0] == H[:, 1]
    F_true = ibd.mean(1)
    # 第二种算法：IBD 片段长度求和
    seg_ibd = [segments_cM(ibd[i], gen) for i in range(n)]
    F_true2 = np.array([s.sum() / genome_cM for s in seg_ibd])
    assert np.allclose(F_true, F_true2), "两种实现近交算法不一致"
    hom = X != 1
    F_roh = {}
    seg_roh = [segments_cM(hom[i], gen) for i in range(n)]
    for thr in cfg["roh_min_cM"]:
        F_roh[thr] = np.array([s[s >= thr].sum() / genome_cM for s in seg_roh])
    p = X.mean(0) / 2
    keep = (p > 0) & (p < 1)
    Xk, pk, pb = X[:, keep], p[keep], base_p[keep]
    E = np.sum(1 - 2 * pk * (1 - pk)); O = (Xk != 1).sum(1)
    F_hom = (O - E) / (keep.sum() - E)

    def grm_diag(freq):
        Z = Xk - 2 * freq
        return (Z ** 2).sum(1) / (2 * np.sum(freq * (1 - freq))) - 1

    F_grm, F_grm_base = grm_diag(pk), grm_diag(pb)
    F_uni = np.mean((Xk ** 2 - (1 + 2 * pk) * Xk + 2 * pk ** 2) / (2 * pk * (1 - pk)), axis=1)
    measures = {"F_PED": Fped, "F_true": F_true, f"F_ROH≥{cfg['roh_min_cM'][0]:g}cM": F_roh[cfg["roh_min_cM"][0]],
                f"F_ROH≥{cfg['roh_min_cM'][1]:g}cM": F_roh[cfg["roh_min_cM"][1]], "F_HOM": F_hom,
                "F_GRM(样本频率)": F_grm, "F_GRM(创始频率)": F_grm_base, "F_UNI": F_uni}
    assert abs(F_true.mean() - Fped.mean()) < 0.03, "实现近交的平均应接近系谱期望"

    # 近交衰退
    beta, sd = cfg["depression_per_unit_F"], cfg["residual_sd"]
    e = rng.normal(0, sd, n); y = 100 + beta * F_true + e
    table = []
    print(f"末代 {n} 个个体；基因组 {genome_cM:.0f} cM、{M} 个 SNP（多态 {keep.sum()} 个）")
    print(f"{'指标':<16s}{'均值':>8s}{'标准差':>8s}{'与F_true相关':>12s}{'衰退估计b':>11s}{'SE':>7s}{'衰减系数λ':>10s}")
    for name, x in measures.items():
        xc = x - x.mean(); vx = xc @ xc / (n - 1)
        b = (xc @ (y - y.mean())) / (n - 1) / vx
        res = y - y.mean() - b * xc; se = np.sqrt(res @ res / (n - 2) / (vx * (n - 1)))
        lam = (xc @ (F_true - F_true.mean())) / (n - 1) / vx
        assert np.isclose(b, beta * lam + (xc @ e) / (n - 1) / vx), "衰减恒等式不成立"
        r = float(np.corrcoef(x, F_true)[0, 1])
        table.append({"measure": name, "mean": float(x.mean()), "sd": float(x.std(ddof=1)), "cor_true": r,
                      "b": float(b), "se": float(se), "lambda": float(lam)})
        print(f"{name:<16s}{x.mean():8.4f}{x.std(ddof=1):8.4f}{r:12.3f}{b:11.2f}{se:7.2f}{lam:10.3f}")
    bt = [t for t in table if t["measure"] == "F_true"][0]
    assert abs(bt["b"] - beta) < 3.5 * bt["se"], "以 F_true 回归应无偏地估计 β"

    # 片段长度分层
    cls = cfg["roh_classes_cM"]
    all_ibd = np.concatenate(seg_ibd); all_roh = np.concatenate(seg_roh)
    strat = []
    print(f"\n片段长度分层（每个体平均贡献的 F）：")
    print(f"{'长度区间(cM)':<14s}{'真实IBD':>9s}{'ROH':>9s}{'理论来源代数≈100/(2L)':>22s}")
    for lo, hi in zip(cls[:-1], cls[1:]):
        fi = all_ibd[(all_ibd >= lo) & (all_ibd < hi)].sum() / genome_cM / n
        fr = all_roh[(all_roh >= lo) & (all_roh < hi)].sum() / genome_cM / n
        mid = np.sqrt(lo * min(hi, 100.0))
        strat.append({"lo": lo, "hi": hi, "F_ibd": float(fi), "F_roh": float(fr), "approx_gen": float(100 / (2 * mid))})
        lab = f"[{lo},{hi})" if hi < 1000 else f"≥{lo}"
        print(f"{lab:<14s}{fi:9.4f}{fr:9.4f}{100 / (2 * mid):22.1f}")
    print(f"\n系谱期望与实现近交：E(F_PED) = {Fped.mean():.4f}，E(F_true) = {F_true.mean():.4f}；"
          f"SD(F_true − F_PED) = {np.std(F_true - Fped, ddof=1):.4f}")
    print("核验通过：两种 F_true 算法一致；E(F_true) ≈ E(F_PED)；衰减恒等式成立；以 F_true 回归无偏。")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex19_18_genomic_inbreeding.json").write_text(json.dumps(
        {"table": table, "length_classes": strat, "sd_true_minus_ped": float(np.std(F_true - Fped, ddof=1))},
        ensure_ascii=False, indent=2), encoding="utf-8")
    from _plot import get_pyplot
    plt = get_pyplot()
    if plt is not None:
        fig, axs = plt.subplots(1, 2, figsize=(9, 3.8))
        axs[0].scatter(Fped, F_true, s=8, alpha=.6); lim = [0, max(F_true.max(), Fped.max()) * 1.05]
        axs[0].plot(lim, lim, "k--", lw=1); axs[0].set_xlabel("系谱近交 F_PED"); axs[0].set_ylabel("实现近交 F_true")
        axs[1].scatter(F_true, F_roh[cfg["roh_min_cM"][0]], s=8, alpha=.6, label="F_ROH≥1cM")
        axs[1].scatter(F_true, F_grm, s=8, alpha=.6, label="F_GRM(样本)")
        axs[1].plot(lim, lim, "k--", lw=1); axs[1].set_xlabel("实现近交 F_true"); axs[1].set_ylabel("基因组指标"); axs[1].legend(fontsize=8)
        fig.tight_layout(); fig.savefig(HERE / "results" / "ex19_18_genomic_inbreeding.png"); plt.close(fig)


if __name__ == "__main__":
    main()
