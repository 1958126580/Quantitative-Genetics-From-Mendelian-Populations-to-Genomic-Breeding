#!/usr/bin/env python3
"""习题 19.15  家系大小方差与有效群体大小：泊松留种、等量留种与偏斜留种

群体每代 N_m = N_f = N/2 个亲本，离散世代，群体大小恒定。三种留种方式：
    poisson：每个后代的父、母分别从雄、雌亲本中等概率有放回抽取（理想群体，V_k ≈ 2）；
    equal  ：随机配成 N/2 对，每对恰好留下一公一母（V_k = 0）；
    skewed ：亲本被抽中的概率与 Gamma(形状参数 κ) 权重成正比（模拟优秀家系多留种，V_k > 2）。
k 为一个亲本留下的、成为下一代亲本的后代数，均值为 2。预测
    N_e ≈ 4N/(V_k + 2)，ΔF = 1/(2N_e)。
实现近交：用加性关系矩阵逐代递推 A_off = P A_par Pᵀ（P 每行在父、母列上为 1/2），
对角元另行置为 1 + A_sd/2；由 ln(1 − F̄_t) 对 t 的回归斜率得 ΔF。
核验：equal 方案 V_k 恰为 0；递推的平均近交等于上一代亲本平均亲缘系数的期望（逐代比较）；
泊松方案的实现 N_e 与 N 一致。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def choose_parents(scheme: str, nm: int, nf: int, rng: np.random.Generator, kappa: float):
    """返回每个后代的 (父, 母) 索引（父 0..nm-1，母 0..nf-1），前 nm 个后代为雄性。"""
    n_off = nm + nf
    if scheme == "poisson":
        return rng.integers(0, nm, n_off), rng.integers(0, nf, n_off)
    if scheme == "equal":
        assert nm == nf, "等量留种要求两性数目相等"
        dams = rng.permutation(nf)                      # 第 i 头公畜与 dams[i] 配对
        sires = np.arange(nm)
        # 每对一个儿子（前 nm 个后代）一个女儿（后 nf 个后代）
        return np.concatenate([sires, sires]), np.concatenate([dams, dams])
    if scheme == "skewed":
        wm = rng.gamma(kappa, size=nm); wf = rng.gamma(kappa, size=nf)
        return rng.choice(nm, n_off, p=wm / wm.sum()), rng.choice(nf, n_off, p=wf / wf.sum())
    raise ValueError(scheme)


def run(scheme: str, cfg: dict, rng: np.random.Generator):
    nm, nf, G = cfg["males"], cfg["females"], cfg["generations"]
    n = nm + nf
    A = np.eye(n)                                       # 基础群体：彼此无亲缘、非近交
    Fbar, Cbar, Vk = [0.0], [A.mean() / 2], []
    for _ in range(G):
        s, d = choose_parents(scheme, nm, nf, rng, cfg["skew_gamma_shape"])
        s_idx, d_idx = s, nm + d                       # 亲本在 A 中的行号
        P = np.zeros((n, n))
        P[np.arange(n), s_idx] += 0.5
        P[np.arange(n), d_idx] += 0.5
        A_new = P @ A @ P.T
        Fi = 0.5 * A[s_idx, d_idx]
        np.fill_diagonal(A_new, 1.0 + Fi)
        k = np.concatenate([np.bincount(s, minlength=nm), np.bincount(d, minlength=nf)])
        Vk.append(k.var())
        A = A_new
        Fbar.append(Fi.mean()); Cbar.append(A.mean() / 2)
    return np.array(Fbar), np.array(Cbar), float(np.mean(Vk))


def fit_dF(Fbar: np.ndarray, t0: int) -> float:
    t = np.arange(len(Fbar))[t0:]
    slope = np.polyfit(t, np.log(1 - Fbar[t0:]), 1)[0]
    return float(1 - np.exp(slope))


def main():
    cfg = json.loads((HERE / "data" / "ex19_15_family_size.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    N = cfg["males"] + cfg["females"]
    out, curves = {}, {}
    print(f"群体：每代 {cfg['males']} 公 + {cfg['females']} 母（N = {N}），{cfg['generations']} 代，重复 {cfg['reps']} 次")
    print(f"{'方案':>8s}{'平均V_k':>9s}{'预测N_e':>9s}{'实现ΔF':>9s}{'实现N_e':>9s}{'N_e/N':>8s}{'末代F':>8s}")
    for sc in cfg["schemes"]:
        Fs, Cs, vks = [], [], []
        for _ in range(cfg["reps"]):
            F, C, vk = run(sc, cfg, rng)
            Fs.append(F); Cs.append(C); vks.append(vk)
            # 核验：每代后代的平均近交 = 亲本间（非自身）配对亲缘的平均，故 F_{t+1} ≤ 1 且单调不减（期望意义）
            assert np.all((F >= -1e-12) & (F <= 1 + 1e-12))
        Fm = np.mean(Fs, axis=0); Cm = np.mean(Cs, axis=0); vk = float(np.mean(vks))
        Ne_pred = 4 * N / (vk + 2)
        dF = fit_dF(Fm, cfg["fit_from"]); Ne_real = 1 / (2 * dF)
        out[sc] = {"Vk": vk, "Ne_pred": Ne_pred, "dF_real": dF, "Ne_real": Ne_real, "F_final": float(Fm[-1])}
        curves[sc] = Fm.tolist()
        print(f"{sc:>8s}{vk:9.3f}{Ne_pred:9.1f}{dF:9.4f}{Ne_real:9.1f}{Ne_real / N:8.2f}{Fm[-1]:8.3f}")
        # 核验：平均亲缘（含自身亲缘）在 t 代为 C_t，下一代平均近交的期望约为 C_t（随机交配时）
        if sc == "poisson":
            assert np.allclose(Fm[1:], Cm[:-1], atol=0.02), "泊松方案中后代近交应≈亲本平均亲缘"
    assert out["equal"]["Vk"] == 0.0
    assert abs(out["poisson"]["Ne_real"] / N - 1) < 0.2, "理想群体的 N_e 应接近 N"
    assert out["equal"]["Ne_real"] > 1.5 * N and out["skewed"]["Ne_real"] < 0.8 * N
    for sc in cfg["schemes"]:
        assert abs(out[sc]["Ne_real"] / out[sc]["Ne_pred"] - 1) < 0.3, f"{sc}: 公式与实现相差过大"
    print("核验通过：等量留种 V_k = 0；泊松方案 N_e ≈ N；三种方案公式 4N/(V_k+2) 与实现值的偏差均 < 30%。")

    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex19_15_family_size_ne.json").write_text(
        json.dumps({"summary": out, "mean_F_by_generation": curves}, ensure_ascii=False, indent=2), encoding="utf-8")
    from _plot import get_pyplot
    plt = get_pyplot()
    if plt is not None:
        fig, ax = plt.subplots(figsize=(6, 4))
        lab = {"poisson": "泊松留种", "equal": "等量留种", "skewed": "偏斜留种"}
        for sc, F in curves.items():
            ax.plot(F, marker="o", ms=3, label=f"{lab[sc]}（实现 N_e≈{out[sc]['Ne_real']:.0f}）")
        ax.set_xlabel("世代"); ax.set_ylabel("平均近交系数"); ax.legend(); ax.grid(alpha=.3)
        fig.tight_layout(); fig.savefig(HERE / "results" / "ex19_15_family_size_ne.png"); plt.close(fig)


if __name__ == "__main__":
    main()
