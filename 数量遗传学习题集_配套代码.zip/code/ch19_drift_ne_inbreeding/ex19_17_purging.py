#!/usr/bin/env python3
"""习题 19.17  清除（purging）：个体模拟与“清除近交系数” g 的预测

雌雄同体、允许自交的理想群体（ΔF = 1/2N），每代先产生 c·N 个候选合子，按存活适合度做生存选择，
取前 N 个存活者作为下一代亲本（种群大小恒定）。两类无连锁的有害位点：
    适合度 1、1 − hs、1 − s（多位点相乘）；初始频率 q0，Hardy–Weinberg 抽样建立基础群体。
为使“清除”不与非平衡选择混杂，有选择的群体加入单向突变 u = hs·q0(1−q0)（大群体中 q0 近似为突变—选择平衡）。
记录每代候选合子的平均适合度 W_t（选择前；第 t 代候选合子的期望近交为 F_{t+1}），与三种预测比较：
    (1) 不清除：W_t = Π_l [1 − 2p0q0hs(1−F_t) − s(q0² + p0q0F_t)]（频率不变，仅近交改变基因型频率）；
    (2) 清除近交系数（García-Dorado 2012）：
        g_t = [(1 − 1/2N) g_{t−1} + 1/2N](1 − 2d F_{t−1})，d = s(1 − 2h)/2，
        ln W_t ≈ ln W_0 − Σ_类 δ_类 g_t,类，δ = Σ_l s(1−2h)p0q0 为该类的近交负荷（致死当量）。
    (3) 无选择对照组的观察值应与 (1) 一致——这是对模拟器的独立核验。
比较快速近交（小 N）与缓慢近交（大 N）在相同 F 下的适合度与致死等位基因频率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def build_classes(cfg):
    s = np.concatenate([[c["s"]] * c["loci"] for c in cfg["classes"]])
    h = np.concatenate([[c["h"]] * c["loci"] for c in cfg["classes"]])
    q0 = np.concatenate([[c["q0"]] * c["loci"] for c in cfg["classes"]])
    cls = np.concatenate([[k] * c["loci"] for k, c in enumerate(cfg["classes"])])
    return s, h, q0, cls


def log_fitness(geno_sum: np.ndarray, s, h) -> np.ndarray:
    """geno_sum：(..., L) 有害等位基因个数 0/1/2。"""
    w = np.where(geno_sum == 0, 1.0, np.where(geno_sum == 1, 1 - h * s, 1 - s))
    with np.errstate(divide="ignore"):
        return np.log(w).sum(-1)


def simulate(N, selection, cfg, s, h, q0, rng):
    u = h * s * q0 * (1 - q0) if selection else np.zeros_like(s)   # 使大群体中 q0 近似为突变—选择平衡
    R, G, L = cfg["reps"], cfg["generations"], len(s)
    M = cfg["candidates_per_N"] * N
    pop = (rng.random((R, N, 2, L)) < q0).astype(np.uint8)
    nc = len(cfg["classes"])
    W, Wse, qlet, extinct = np.zeros(G + 1), np.zeros(G + 1), np.zeros((G + 1, nc)), 0
    hom, hom_se = np.zeros((G + 1, nc)), np.zeros((G + 1, nc))
    _, _, _, cls = build_classes(cfg)
    rr = np.arange(R)[:, None, None]; ll = np.arange(L)[None, None, :]
    for t in range(G + 1):
        # 产生候选合子：两个亲本（有放回、允许自交），每个位点独立取一条
        par = rng.integers(0, N, (R, M, 2))
        g1 = pop[rr, par[:, :, :1], rng.integers(0, 2, (R, M, L)), ll]
        g2 = pop[rr, par[:, :, 1:], rng.integers(0, 2, (R, M, L)), ll]
        cand = np.stack([g1, g2], axis=2)                     # (R, M, 2, L)
        cand |= (rng.random(cand.shape) < u).astype(np.uint8)  # 正常→有害的单向突变
        lw = log_fitness(cand.sum(2), s, h)                   # (R, M)
        w_rep = np.exp(lw).mean(1)
        W[t] = w_rep.mean(); Wse[t] = w_rep.std(ddof=1) / np.sqrt(R)
        for k in range(nc):
            qlet[t, k] = pop[..., cls == k].mean()
            hr = (cand[..., cls == k].sum(2) == 2).mean(axis=(1, 2))   # 每个重复的有害纯合子频率
            hom[t, k] = hr.mean(); hom_se[t, k] = hr.std(ddof=1) / np.sqrt(R)
        if t == G:
            break
        if selection:
            surv = rng.random((R, M)) < np.exp(lw)
        else:
            surv = np.ones((R, M), bool)
        key = np.where(surv, np.arange(M)[None, :], M + np.arange(M)[None, :])
        order = np.argsort(key, axis=1)[:, :N]                # 前 N 个存活者（不足时以未存活者补齐）
        extinct += int((surv.sum(1) < N).sum())
        pop = cand[np.arange(R)[:, None], order]
    return W, Wse, qlet, extinct, hom, hom_se


def predictions(N, cfg, s, h, q0, cls, G):
    p0 = 1 - q0
    F = 1 - (1 - 1 / (2 * N)) ** np.arange(G + 2)    # F[t]：第 t 代亲本所产合子为 F[t+1]
    W_np = np.array([np.prod(1 - 2 * p0 * q0 * h * s * (1 - f) - s * (q0 ** 2 + p0 * q0 * f)) for f in F])
    W0 = W_np[0]
    lnW_pg = np.full(G + 2, np.log(W0))
    for k, c in enumerate(cfg["classes"]):
        idx = cls == k
        delta = float(np.sum(s[idx] * (1 - 2 * h[idx]) * p0[idx] * q0[idx]))
        dcoef = c["s"] * (1 - 2 * c["h"]) / 2
        g = np.zeros(G + 2)
        for t in range(1, G + 2):
            g[t] = ((1 - 1 / (2 * N)) * g[t - 1] + 1 / (2 * N)) * (1 - 2 * dcoef * F[t - 1])
        lnW_pg -= delta * g
    return F[1:], W_np[1:], np.exp(lnW_pg)[1:]      # 对齐到“候选合子”的世代


def main():
    cfg = json.loads((HERE / "data" / "ex19_17_purging.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    s, h, q0, cls = build_classes(cfg)
    G = cfg["generations"]
    for k, c in enumerate(cfg["classes"]):
        idx = cls == k
        print(f"{c['name']}：{c['loci']} 个位点，q0 = {c['q0']}，s = {c['s']}，h = {c['h']}，"
              f"近交负荷 δ = {np.sum(s[idx]*(1-2*h[idx])*q0[idx]*(1-q0[idx])):.3f}，清除系数 d = {c['s']*(1-2*c['h'])/2:.3f}")
    res = {}
    for pdef in cfg["populations"]:
        N = pdef["N"]
        W, Wse, ql, ext, hom, hom_se = simulate(N, pdef["selection"], cfg, s, h, q0, rng)
        F, W_np, W_pg = predictions(N, cfg, s, h, q0, cls, G)
        res[pdef["label"]] = {"N": N, "selection": pdef["selection"], "F": F.tolist(), "W_sim": W.tolist(),
                              "W_nopurge": W_np.tolist(), "W_purged_g": W_pg.tolist(),
                              "q_classes": ql.tolist(), "short_of_survivors": ext}
        print(f"\n【{pdef['label']}】（重复 {cfg['reps']} 次；候选不足 N 个存活者的次数 {ext}）")
        print(f"{'t':>4s}{'F':>7s}{'W模拟':>9s}{'不清除':>9s}{'g预测':>9s}{'近致死q':>9s}{'轻度q':>8s}")
        for t in range(0, G + 1, 3):
            print(f"{t:4d}{F[t]:7.3f}{W[t]:9.4f}{W_np[t]:9.4f}{W_pg[t]:9.4f}{ql[t,0]:9.4f}{ql[t,1]:8.4f}")
        if not pdef["selection"]:
            # 精确核验：每个位点有害纯合子的期望频率 q0² + p0q0F（与选择无关、与位点间相关无关）
            for k, c in enumerate(cfg["classes"]):
                exp_h = c["q0"] ** 2 + c["q0"] * (1 - c["q0"]) * F
                z = np.abs(hom[:, k] - exp_h) / hom_se[:, k]
                assert z.max() < 4.5, f"{c['name']} 纯合子频率与 q0²+p0q0F 不符（{z.max():.2f} SE）"
                print(f"  核验：{c['name']}纯合子频率与 q0²+p0q0F 之差最大 {z.max():.2f} 个标准误")
            excess = float(np.mean(W[1:] / W_np[1:] - 1))
            res[pdef["label"]]["mean_excess_over_product"] = excess
            print(f"  无选择时模拟 W 平均高于“逐位点相乘”预测 {excess:.1%}：个体实现近交有变异（同一性不平衡），"
                  f"E[exp(−δF_i)] > exp(−δE F_i)")
    # 在相同 F 下比较快、慢近交
    fast, slow = res[cfg["populations"][0]["label"]], res[cfg["populations"][1]["label"]]
    cmp = []
    print("\n相同近交系数下的比较（线性插值）：")
    for f in cfg["F_compare"]:
        row = {"F": f}
        for name, r in (("fast", fast), ("slow", slow)):
            row[name + "_W"] = float(np.interp(f, r["F"], r["W_sim"]))
            row[name + "_W_nopurge"] = float(np.interp(f, r["F"], r["W_nopurge"]))
            row[name + "_q_lethal"] = float(np.interp(f, r["F"], np.array(r["q_classes"])[:, 0]))
            row[name + "_q_mild"] = float(np.interp(f, r["F"], np.array(r["q_classes"])[:, 1]))
        cmp.append(row)
        print(f"  F = {f:.2f}：快速近交 W = {row['fast_W']:.3f}（不清除 {row['fast_W_nopurge']:.3f}，致死 q = {row['fast_q_lethal']:.4f}）；"
              f"缓慢近交 W = {row['slow_W']:.3f}（致死 q = {row['slow_q_lethal']:.4f}）")
    assert cmp[-1]["slow_W"] > cmp[-1]["fast_W"], "缓慢近交在相同 F 下应保留更高适合度"
    assert cmp[-1]["slow_q_lethal"] < cmp[-1]["fast_q_lethal"]
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex19_17_purging.json").write_text(json.dumps({"populations": res, "same_F": cmp}, ensure_ascii=False, indent=2), encoding="utf-8")
    from _plot import get_pyplot
    plt = get_pyplot()
    if plt is not None:
        fig, ax = plt.subplots(figsize=(6.4, 4))
        for lab, r in res.items():
            l, = ax.plot(r["F"], r["W_sim"], marker="o", ms=3, label=f"{lab} 模拟")
            if r["selection"]:
                ax.plot(r["F"], r["W_purged_g"], ls="--", color=l.get_color(), label=f"{lab} g 预测")
        ax.plot(fast["F"], fast["W_nopurge"], "k:", label="不清除")
        ax.set_xlabel("近交系数 F"); ax.set_ylabel("平均适合度 W"); ax.legend(fontsize=7); ax.grid(alpha=.3)
        fig.tight_layout(); fig.savefig(HERE / "results" / "ex19_17_purging.png"); plt.close(fig)


if __name__ == "__main__":
    main()
