# 第19章　遗传漂变、有效群体大小与近交——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex19_15_family_size_ne.py
python3 ex19_16_variance_redistribution.py
python3 ex19_17_purging.py
python3 ex19_18_genomic_inbreeding.py
python3 ex19_19_long_term_contributions.py
python3 ex19_20_depression_estimation.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex19_15_family_size_ne.py | 19.15 | 家系大小方差与有效群体大小：泊松留种、等量留种与偏斜留种 |
| ex19_16_variance_redistribution.py | 19.16 | 漂变下遗传方差在系内与系间的再分配：精确的 Wright–Fisher 转移矩阵计算 |
| ex19_17_purging.py | 19.17 | 清除（purging）：个体模拟与“清除近交系数” g 的预测 |
| ex19_18_genomic_inbreeding.py | 19.18 | 系谱近交、实现近交与基因组近交（F_ROH、F_HOM、F_GRM、F_UNI）及近交衰退估计 |
| ex19_19_long_term_contributions.py | 19.19 | 长期遗传贡献：同时预测近交速率与遗传进展（Woolliams–Bijma 理论） |
| ex19_20_depression_estimation.py | 19.20 | 近交衰退的估计：系谱深度、家系相关与标准误 |
