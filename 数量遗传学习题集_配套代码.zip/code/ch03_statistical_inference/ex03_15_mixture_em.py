#!/usr/bin/env python3
"""习题 3.15  主基因分离的混合正态模型：EM 算法、似然比与参数自助法检验

回交群体中若存在一个主效基因，表型服从两成分混合正态：
    f(y) = π N(μ1, σ²) + (1−π) N(μ2, σ²)，回交理论 π = 1/2。
EM：E 步计算后验 w_i = P(携带 | y_i)；M 步加权更新 π, μ1, μ2, σ²。
检验 H0：单一正态 vs H1：两成分混合。由于 H0 位于参数空间边界且 μ1−μ2 在 π=0 时不可识别，
LRT 不服从常规 χ²，程序用参数自助法（在 H0 下模拟）求经验 p 值。
另报告：EM 的似然单调性、观测信息（数值 Hessian）给出的标准误、固定 π=0.5 的受限模型。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm
from scipy.optimize import approx_fprime

HERE = Path(__file__).resolve().parent


_C = 1.0 / np.sqrt(2 * np.pi)


def npdf(y, m, s):
    """正态密度（与 scipy.stats.norm.pdf 同值，但在 EM 内循环中快得多）。"""
    z = (y - m) / s
    return _C / s * np.exp(-0.5 * z * z)


def loglik(y, pi, m1, m2, s):
    return float(np.sum(np.log(pi * npdf(y, m1, s) + (1 - pi) * npdf(y, m2, s))))


def em(y, pi=0.5, m1=None, m2=None, s=None, fix_pi=False, tol=1e-10, maxit=5000):
    m1 = np.quantile(y, 0.75) if m1 is None else m1
    m2 = np.quantile(y, 0.25) if m2 is None else m2
    s = y.std() if s is None else s
    path = [loglik(y, pi, m1, m2, s)]
    for _ in range(maxit):
        a = pi * npdf(y, m1, s); b = (1 - pi) * npdf(y, m2, s)
        w = a / (a + b)
        if not fix_pi: pi = w.mean()
        m1 = np.sum(w * y) / w.sum(); m2 = np.sum((1 - w) * y) / (1 - w).sum()
        s = np.sqrt(np.sum(w * (y - m1) ** 2 + (1 - w) * (y - m2) ** 2) / len(y))
        path.append(loglik(y, pi, m1, m2, s))
        assert path[-1] >= path[-2] - 1e-9, "EM 似然下降：实现错误"
        if path[-1] - path[-2] < tol: break
    return dict(pi=pi, m1=m1, m2=m2, s=s, ll=path[-1], iters=len(path) - 1)


def fit_h1(y, tol=1e-10):
    """多起点 EM，避免局部极值。"""
    best = None
    for q1, q2 in ((0.75, 0.25), (0.9, 0.1), (0.6, 0.4), (0.95, 0.5)):
        r = em(y, m1=np.quantile(y, q1), m2=np.quantile(y, q2), tol=tol)
        if best is None or r["ll"] > best["ll"]: best = r
    return best


def main():
    y = np.loadtxt(HERE / "data" / "ex03_15_phenotypes.csv", skiprows=1)
    n = len(y)
    ll0 = float(np.sum(norm.logpdf(y, y.mean(), y.std())))
    h1 = fit_h1(y); hb = em(y, pi=0.5, fix_pi=True)
    lrt = 2 * (h1["ll"] - ll0)
    # 观测信息矩阵（数值二阶导）→ 标准误
    th = np.array([h1["pi"], h1["m1"], h1["m2"], np.log(h1["s"])])
    f = lambda t: loglik(y, t[0], t[1], t[2], np.exp(t[3]))
    eps = 1e-4
    H = np.zeros((4, 4))
    for i in range(4):
        e = np.zeros(4); e[i] = eps
        H[i] = (approx_fprime(th + e, f, 1e-6) - approx_fprime(th - e, f, 1e-6)) / (2 * eps)
    cov = np.linalg.inv(-(H + H.T) / 2); se = np.sqrt(np.diag(cov))
    rng = np.random.default_rng(3150); B = 200; null_lrt = []
    for _ in range(B):
        ys = rng.normal(y.mean(), y.std(), n)
        l0 = float(np.sum(norm.logpdf(ys, ys.mean(), ys.std())))
        null_lrt.append(2 * (fit_h1(ys, tol=1e-7)["ll"] - l0))  # 自助法内层放宽收敛阈值以控制用时
    null_lrt = np.array(null_lrt); p_boot = float((1 + np.sum(null_lrt >= lrt)) / (B + 1))
    print(f"n = {n}，单一正态 logL = {ll0:.3f}")
    print(f"混合模型：π = {h1['pi']:.4f}(SE {se[0]:.4f})，μ1 = {h1['m1']:.3f}(SE {se[1]:.3f})，μ2 = {h1['m2']:.3f}(SE {se[2]:.3f})，σ = {h1['s']:.3f}，logL = {h1['ll']:.3f}，迭代 {h1['iters']}")
    print(f"固定 π=0.5：μ1 = {hb['m1']:.3f}，μ2 = {hb['m2']:.3f}，σ = {hb['s']:.3f}，logL = {hb['ll']:.3f}")
    print(f"LRT(混合 vs 单一) = {lrt:.3f}；自助法零分布 95% 分位数 = {np.quantile(null_lrt,0.95):.3f}；自助法 p ≈ {p_boot:.4f}")
    print(f"LRT(π自由 vs π=0.5) = {2*(h1['ll']-hb['ll']):.3f}")
    from scipy.stats import chi2
    lrt_fixed = 2 * (hb["ll"] - ll0)
    print(f"利用回交理论固定 π=0.5 时检验 μ1=μ2：LRT = {lrt_fixed:.3f}，χ²₁ p = {chi2.sf(lrt_fixed,1):.4f}")
    out = {"lrt_pi_fixed_vs_single": lrt_fixed, "p_pi_fixed": float(chi2.sf(lrt_fixed, 1)), "n": n, "ll_single": ll0, "mixture": {k: float(v) for k, v in h1.items()}, "se": se.tolist(),
           "mixture_pi_fixed": {k: float(v) for k, v in hb.items()}, "lrt": lrt,
           "bootstrap_null_q95": float(np.quantile(null_lrt, 0.95)), "p_bootstrap": p_boot}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex03_15_mixture_em.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
