#!/usr/bin/env python3
"""习题 3.17  半同胞设计检测公畜方差的功效与最优家系大小

单因素随机模型 y_ij = μ + s_i + e_ij，s 个公畜、每公畜 n 个后代，组内相关 t = h²/4。
在 H1 下  F = MSB/MSW ~ (1 + n t /(1 − t)) · F(s−1, s(n−1))，
故功效 = P[F(s−1, s(n−1)) > F_crit / (1 + n t/(1−t))]。
固定总后代数 N = s·n，比较不同 n 的功效，并与 Robertson 估计精度最优 n ≈ 1/t 对照：
“检测是否存在遗传方差”与“精确估计遗传力”的最优设计并不相同。
最后以蒙特卡洛模拟核对一个设计点的功效。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import f

HERE = Path(__file__).resolve().parent


def power(s, n, t, alpha):
    d1, d2 = s - 1, s * (n - 1)
    crit = f.isf(alpha, d1, d2)
    lam = 1 + n * t / (1 - t)
    return float(f.sf(crit / lam, d1, d2))


def se_h2(s, n, t):
    """组内相关估计的近似标准误 (Fisher/Robertson)，h² = 4t。"""
    N = s * n
    var_t = 2 * (1 - t) ** 2 * (1 + (n - 1) * t) ** 2 / (n * (n - 1) * (s - 1))
    return 4 * np.sqrt(var_t)


def main():
    cfg = json.loads((HERE / "data" / "ex03_17_power.json").read_text(encoding="utf-8"))
    N, a = cfg["total_offspring"], cfg["alpha"]
    out = {}
    for h2 in cfg["h2_values"]:
        t = h2 / 4; rows = []
        print(f"\nh² = {h2}（t = {t}），总后代数 N = {N}")
        print(f"{'n':>5s}{'公畜数s':>8s}{'功效':>8s}{'SE(ĥ²)':>9s}")
        for n in cfg["n_per_sire_grid"]:
            s = N // n
            if s < 3: continue
            pw, se = power(s, n, t, a), se_h2(s, n, t)
            rows.append({"n": n, "s": s, "power": round(pw, 4), "se_h2": round(float(se), 4)})
            print(f"{n:5d}{s:8d}{pw:8.4f}{se:9.4f}")
        best_pw = max(rows, key=lambda r: r["power"]); best_se = min(rows, key=lambda r: r["se_h2"])
        print(f"功效最大：n = {best_pw['n']}；SE 最小：n = {best_se['n']}（Robertson 近似 1/t = {1/t:.0f}）")
        out[str(h2)] = {"rows": rows, "n_max_power": best_pw["n"], "n_min_se": best_se["n"]}
    mc = cfg["mc_check"]; rng = np.random.default_rng(mc["seed"])
    t = mc["h2"] / 4; n = mc["n"]; s = N // n; crit = f.isf(a, s - 1, s * (n - 1)); hits = 0
    for _ in range(mc["reps"]):
        y = rng.normal(0, np.sqrt(t), (s, 1)) + rng.normal(0, np.sqrt(1 - t), (s, n))
        msb = n * np.var(y.mean(1), ddof=1); msw = np.sum((y - y.mean(1, keepdims=True)) ** 2) / (s * (n - 1))
        hits += msb / msw > crit
    pmc = hits / mc["reps"]; pth = power(s, n, t, a)
    print(f"\n蒙特卡洛核对（h²={mc['h2']}, n={n}, s={s}）：模拟功效 {pmc:.4f}，理论功效 {pth:.4f}")
    assert abs(pmc - pth) < 0.015
    out["mc_check"] = {"sim": pmc, "theory": pth}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex03_17_halfsib_power.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
