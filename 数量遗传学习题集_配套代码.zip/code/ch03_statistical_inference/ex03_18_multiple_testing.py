#!/usr/bin/env python3
"""习题 3.18  一万次检验中的错误控制：Bonferroni、Holm、BH 与 Storey q 值

情景：m = 10000 个独立 z 检验，其中 m1 = 100 个为真效应（均值 z = 4），其余为零假设。
每种程序在 α = 0.05 下判定显著，重复 300 次，估计
    FWER  = P(至少一个假阳性)
    FDR   = E[V / max(R, 1)]
    功效  = E[真阳性数 / m1]
理论：Bonferroni/Holm 控制 FWER ≤ α；BH 在独立时控制 FDR ≤ π0 α；Storey 方法用 π̂0 放宽 BH 获得更高功效。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def bonferroni(p, a): return p <= a / len(p)


def holm(p, a):
    m = len(p); o = np.argsort(p); rej = np.zeros(m, bool)
    for k, i in enumerate(o):
        if p[i] <= a / (m - k): rej[i] = True
        else: break
    return rej


def bh(p, a, pi0=1.0):
    m = len(p); o = np.argsort(p); ps = p[o]
    ok = ps <= (np.arange(1, m + 1) / m) * a / pi0
    rej = np.zeros(m, bool)
    if ok.any():
        k = np.max(np.where(ok)[0]); rej[o[:k + 1]] = True
    return rej


def storey(p, a, lam):
    pi0 = min(1.0, np.mean(p > lam) / (1 - lam))
    return bh(p, a, pi0), pi0


def main():
    cfg = json.loads((HERE / "data" / "ex03_18_multitest.json").read_text(encoding="utf-8"))
    m, m1, a = cfg["m"], cfg["m1"], cfg["alpha"]; rng = np.random.default_rng(cfg["seed"])
    truth = np.zeros(m, bool); truth[:m1] = True
    stats = {k: {"fwer": [], "fdp": [], "power": [], "R": []} for k in ("Bonferroni", "Holm", "BH", "Storey")}
    pi0s = []
    for _ in range(cfg["reps"]):
        z = rng.standard_normal(m); z[truth] += cfg["effect_z"]
        p = 2 * norm.sf(np.abs(z))
        st_rej, pi0 = storey(p, a, cfg["lambda_storey"]); pi0s.append(pi0)
        for k, rej in (("Bonferroni", bonferroni(p, a)), ("Holm", holm(p, a)), ("BH", bh(p, a)), ("Storey", st_rej)):
            V = np.sum(rej & ~truth); R = rej.sum(); S = np.sum(rej & truth)
            stats[k]["fwer"].append(V > 0); stats[k]["fdp"].append(V / max(R, 1)); stats[k]["power"].append(S / m1); stats[k]["R"].append(R)
    print(f"m={m}, m1={m1}, 真效应 z={cfg['effect_z']}, α={a}，重复 {cfg['reps']} 次；平均 π̂0 = {np.mean(pi0s):.4f}（真值 {1-m1/m}）")
    print(f"{'方法':<12s}{'FWER':>8s}{'FDR':>8s}{'功效':>8s}{'平均显著数':>10s}")
    out = {"pi0_hat": float(np.mean(pi0s))}
    for k, d in stats.items():
        r = {q: float(np.mean(v)) for q, v in d.items()}
        out[k] = r
        print(f"{k:<12s}{r['fwer']:8.3f}{r['fdp']:8.4f}{r['power']:8.3f}{r['R']:10.1f}")
    print(f"Bonferroni 阈值 p ≤ {a/m:.1e}，即 |z| ≥ {norm.isf(a/m/2):.3f}；单个真效应被检出的理论概率 = {norm.sf(norm.isf(a/m/2)-cfg['effect_z']):.4f}")
    assert out["Bonferroni"]["fwer"] <= 0.09 and out["BH"]["fdp"] <= 0.07
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex03_18_multiple_testing.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
