#!/usr/bin/env python3
"""习题 3.19  群体结构下的置换检验：全样本置换与层内置换

两个亚群（各 150 只）的某 SNP 频率分别为 0.2 与 0.7；该 SNP 对性状无效应，但两亚群表型均值相差 1 个标准差。
统计量：表型对基因型剂量的回归斜率（等价于相关）。
    (a) 全样本置换：打乱所有个体的表型，破坏了“亚群—表型”联系，零分布错误 → 假阳性率膨胀；
    (b) 层内置换：只在亚群内部打乱表型，保留亚群结构 → 第一类错误恢复到名义水平；
    (c) 回归中加入亚群固定效应后的 t 检验作为参照。
程序在零假设下重复 300 次数据集，统计各方法在 α=0.05 的拒绝率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent


def slope(x, y):
    xc = x - x.mean(); return float(xc @ (y - y.mean()) / (xc @ xc))


def within_slope(x, y, g):
    xr = x.copy().astype(float); yr = y.copy()
    for k in np.unique(g):
        m = g == k; xr[m] -= xr[m].mean(); yr[m] -= yr[m].mean()
    return float(xr @ yr / (xr @ xr)), xr, yr


def main():
    cfg = json.loads((HERE / "data" / "ex03_19_perm.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n_per"]; P = cfg["n_perm"]
    g = np.repeat(np.arange(cfg["n_strata"]), n)
    rej = {"全样本置换": 0, "层内置换": 0, "朴素t检验": 0, "含亚群效应t检验": 0}
    for _ in range(cfg["reps"]):
        x = np.concatenate([rng.binomial(2, f, n) for f in cfg["freq"]]).astype(float)
        y = np.concatenate([rng.normal(m, 1, n) for m in cfg["mean_shift"]])
        b0 = slope(x, y)
        perm_all = np.array([slope(x, rng.permutation(y)) for _ in range(P)])
        rej["全样本置换"] += (1 + np.sum(np.abs(perm_all) >= abs(b0))) / (P + 1) <= 0.05
        bw, xr, yr = within_slope(x, y, g)
        perm_w = []
        for _ in range(P):
            yp = y.copy()
            for k in np.unique(g):
                m = g == k; yp[m] = rng.permutation(y[m])
            perm_w.append(within_slope(x, yp, g)[0])
        rej["层内置换"] += (1 + np.sum(np.abs(perm_w) >= abs(bw))) / (P + 1) <= 0.05
        rej["朴素t检验"] += stats.linregress(x, y).pvalue <= 0.05
        X = np.column_stack([np.ones_like(x), x, g]); bet, res, *_ = np.linalg.lstsq(X, y, rcond=None)
        e = y - X @ bet; s2 = e @ e / (len(y) - 3); se = np.sqrt(s2 * np.linalg.inv(X.T @ X)[1, 1])
        rej["含亚群效应t检验"] += 2 * stats.t.sf(abs(bet[1] / se), len(y) - 3) <= 0.05
    R = cfg["reps"]; mcse = np.sqrt(0.05 * 0.95 / R)
    print(f"零假设下（SNP 无效应）{R} 个数据集的拒绝率（名义 0.05，蒙特卡洛标准误约 {mcse:.3f}）")
    out = {}
    for k, v in rej.items():
        out[k] = v / R; print(f"  {k:<14s}{v/R:.3f}")
    assert out["层内置换"] < 0.1 and out["全样本置换"] > 0.5
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex03_19_permutation_structure.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
