#!/usr/bin/env python3
"""习题 3.16  小样本比例的区间估计：Wald、Wilson、似然比（轮廓）与 Clopper–Pearson

某检测在 40 只羊中发现 3 只携带者。比较四种 95% 区间：
    Wald：        p̂ ± z√(p̂(1−p̂)/n)
    Wilson（得分）：解 (p̂−p)² = z² p(1−p)/n
    似然比：       {p : 2[ℓ(p̂) − ℓ(p)] ≤ χ²₁,0.95}
    Clopper–Pearson：Beta 分位数构成的“精确”区间
并以精确二项概率（非模拟）计算各方法在不同 (n, p) 下的真实覆盖率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm, beta, binom, chi2
from scipy.optimize import brentq

HERE = Path(__file__).resolve().parent


def wald(x, n, z):
    p = x / n; h = z * np.sqrt(p * (1 - p) / n); return max(0.0, p - h), min(1.0, p + h)


def wilson(x, n, z):
    p = x / n; c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n); return c - h, c + h


def lr(x, n, level):
    crit = chi2.ppf(level, 1)
    def ll(p):
        return (x * np.log(p) if x > 0 else 0.0) + ((n - x) * np.log(1 - p) if n > x else 0.0)
    ph = x / n; lmax = ll(min(max(ph, 1e-12), 1 - 1e-12))
    g = lambda p: 2 * (lmax - ll(p)) - crit
    lo = 0.0 if x == 0 else brentq(g, 1e-12, ph)
    hi = 1.0 if x == n else brentq(g, ph, 1 - 1e-12)
    return lo, hi


def clopper(x, n, level):
    a = 1 - level
    lo = 0.0 if x == 0 else beta.ppf(a / 2, x, n - x + 1)
    hi = 1.0 if x == n else beta.ppf(1 - a / 2, x + 1, n - x)
    return lo, hi


def coverage(method, n, p, level):
    z = norm.ppf(0.5 + level / 2); tot = 0.0
    for x in range(n + 1):
        lo, hi = method(x, n, z) if method in (wald, wilson) else method(x, n, level)
        if lo <= p <= hi: tot += binom.pmf(x, n, p)
    return tot


def main():
    cfg = json.loads((HERE / "data" / "ex03_16_ci.json").read_text(encoding="utf-8"))
    x, n, lev = cfg["observed"]["x"], cfg["observed"]["n"], cfg["level"]; z = norm.ppf(0.5 + lev / 2)
    ints = {"Wald": wald(x, n, z), "Wilson": wilson(x, n, z), "似然比": lr(x, n, lev), "Clopper-Pearson": clopper(x, n, lev)}
    print(f"x = {x}, n = {n}, p̂ = {x/n:.4f}")
    for k, (lo, hi) in ints.items():
        print(f"  {k:<16s} ({lo:.4f}, {hi:.4f})  宽度 {hi-lo:.4f}")
    cov = {}
    print("\n真实覆盖率（精确计算）")
    print(f"{'n':>4s}{'p':>6s}" + "".join(f"{k:>16s}" for k in ints))
    for nn in cfg["n_grid"]:
        for p in cfg["coverage_grid_p"]:
            row = {k: coverage(m, nn, p, lev) for k, m in (("Wald", wald), ("Wilson", wilson), ("似然比", lr), ("Clopper-Pearson", clopper))}
            cov[f"n={nn},p={p}"] = {k: round(v, 4) for k, v in row.items()}
            print(f"{nn:4d}{p:6.2f}" + "".join(f"{row[k]:16.4f}" for k in ints))
    out = {"intervals": {k: [round(a, 5), round(b, 5)] for k, (a, b) in ints.items()}, "coverage": cov}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex03_16_binomial_intervals.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
