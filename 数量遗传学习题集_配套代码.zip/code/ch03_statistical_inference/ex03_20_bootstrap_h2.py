#!/usr/bin/env python3
"""习题 3.20  半同胞遗传力的标准误：Delta 方法与两种自助法

资料：40 头公畜 × 12 个后代（模拟，真值 h² = 0.36）。ANOVA 估计：
    σ̂s² = (MSB − MSW)/n，  t̂ = σ̂s²/(σ̂s² + MSW)，  ĥ² = 4 t̂。
标准误三种算法：
    (1) Delta/Fisher 近似：Var(t̂) ≈ 2(1−t)²[1+(n−1)t]² / [n(n−1)(s−1)]；
    (2) 按公畜（家系）整体重抽样的自助法——尊重家系内相关；
    (3) 按个体重抽样的自助法——破坏家系结构，通常严重低估不确定性（甚至估计本身有偏）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def h2_anova(Y):
    s, n = Y.shape
    msb = n * np.var(Y.mean(1), ddof=1)
    msw = np.sum((Y - Y.mean(1, keepdims=True)) ** 2) / (s * (n - 1))
    s2s = (msb - msw) / n
    return 4 * s2s / (s2s + msw), msb, msw


def main():
    cfg = json.loads((HERE / "data" / "ex03_20_boot.json").read_text(encoding="utf-8"))
    s, n, h2 = cfg["n_sires"], cfg["n_per_sire"], cfg["h2"]; rng = np.random.default_rng(cfg["seed"])
    t = h2 / 4
    Y = rng.normal(0, np.sqrt(t), (s, 1)) + rng.normal(0, np.sqrt(1 - t), (s, n))
    np.savetxt(HERE / "data" / "ex03_20_halfsib_records.csv", Y.round(4), delimiter=",", fmt="%.4f")
    est, msb, msw = h2_anova(Y); th = est / 4
    se_delta = 4 * np.sqrt(2 * (1 - th) ** 2 * (1 + (n - 1) * th) ** 2 / (n * (n - 1) * (s - 1)))
    B = cfg["B"]; bs_sire, bs_ind = [], []
    flat = Y.ravel(); sire_id = np.repeat(np.arange(s), n)
    for _ in range(B):
        idx = rng.integers(0, s, s); bs_sire.append(h2_anova(Y[idx])[0])
        # 个体重抽样：在各自公畜“标签”下随机抽取个体，相当于把家系内与家系间信息混合
        pick = rng.integers(0, s * n, s * n); Yb = flat[pick].reshape(s, n)
        bs_ind.append(h2_anova(Yb)[0])
    bs_sire, bs_ind = np.array(bs_sire), np.array(bs_ind)
    print(f"ANOVA：MSB = {msb:.4f}，MSW = {msw:.4f}，ĥ² = {est:.4f}")
    print(f"Delta 法 SE = {se_delta:.4f}")
    print(f"公畜重抽样自助法 SE = {bs_sire.std(ddof=1):.4f}，百分位 95% 区间 = ({np.quantile(bs_sire,0.025):.4f}, {np.quantile(bs_sire,0.975):.4f})")
    print(f"个体重抽样自助法 SE = {bs_ind.std(ddof=1):.4f}，自助均值 = {bs_ind.mean():.4f}（家系结构被打乱，估计向 0 收缩）")
    out = {"h2_hat": est, "msb": msb, "msw": msw, "se_delta": se_delta, "se_boot_sire": float(bs_sire.std(ddof=1)),
           "ci_boot_sire": [float(np.quantile(bs_sire, 0.025)), float(np.quantile(bs_sire, 0.975))],
           "se_boot_individual": float(bs_ind.std(ddof=1)), "mean_boot_individual": float(bs_ind.mean())}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex03_20_bootstrap_h2.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
