# 第3章　统计推断、似然与数量遗传学方法——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex03_15_mixture_em.py
python3 ex03_16_binomial_intervals.py
python3 ex03_17_halfsib_power.py
python3 ex03_18_multiple_testing.py
python3 ex03_19_permutation_structure.py
python3 ex03_20_bootstrap_h2.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex03_15_mixture_em.py | 3.15 | 主基因分离的混合正态模型：EM 算法、似然比与参数自助法检验 |
| ex03_16_binomial_intervals.py | 3.16 | 小样本比例的区间估计：Wald、Wilson、似然比（轮廓）与 Clopper–Pearson |
| ex03_17_halfsib_power.py | 3.17 | 半同胞设计检测公畜方差的功效与最优家系大小 |
| ex03_18_multiple_testing.py | 3.18 | 一万次检验中的错误控制：Bonferroni、Holm、BH 与 Storey q 值 |
| ex03_19_permutation_structure.py | 3.19 | 群体结构下的置换检验：全样本置换与层内置换 |
| ex03_20_bootstrap_h2.py | 3.20 | 半同胞遗传力的标准误：Delta 方法与两种自助法 |
