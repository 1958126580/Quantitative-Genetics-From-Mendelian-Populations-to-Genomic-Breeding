#!/usr/bin/env python3
"""习题 27.20  交叉验证的设计：留组误差的精确恒等式，以及随机折与按家系折对“新家系”准确度的估计

(1) 恒等式：对含截距的 GBLUP（方差比 λ 固定），预测 ŷ = Hy。留出一组 B（一个家系）后，对 B 的残差满足
        e_{−B} = (I − H_BB)⁻¹ e_B，    e = y − Hy。
    程序对每个家系与显式“去掉该家系重新拟合”的结果比较（1e-8）。
(2) 估计量的差异：群体含 n_fam 个全同胞家系（每家 fam_size 头），目标是预测“新家系”（新亲本的子代）的育种值。
    A 随机 5 折（同胞散布在训练与验证中）；B 按家系分折（同一家系整体留出）；
    “真值”：在另外 n_new_fam 个新家系（全新亲本）上用全部训练数据预测并计算与真遗传值的相关。
核验：(a) 恒等式 1e-8；(b) fam_size=8 时随机折的相关高于“真值”至少 0.08（乐观）；
      (c) 按家系折低于“真值”（训练集少 20%，略悲观），其偏差小于随机折偏差的一半，或至少小于随机折的偏差；
      (d) 对 fam_size = 4、8、16：随机折都比“真值”高 0.05 以上，且比家系折高 0.1 以上。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def make_families(rng, F, fs, p):
    m = len(p)
    par = (rng.random((2 * F, 2, m)) < p).astype(np.int8)
    X = np.empty((F * fs, m)); fam = np.repeat(np.arange(F), fs)
    for f in range(F):
        s_, d_ = par[2 * f], par[2 * f + 1]
        for k in range(fs):
            h1 = np.where(rng.integers(0, 2, m) == 0, s_[0], s_[1]); h2 = np.where(rng.integers(0, 2, m) == 0, d_[0], d_[1])
            X[f * fs + k] = h1 + h2
    return X, fam


def gblup_hat(G, lam):
    n = G.shape[0]; Vi = np.linalg.inv(G + lam * np.eye(n)); one = np.ones(n)
    S = np.outer(one, one @ Vi) / (one @ Vi @ one)
    return S + G @ Vi @ (np.eye(n) - S)


def fit_predict(G, y, tr, te, lam):
    Vi = np.linalg.inv(G[np.ix_(tr, tr)] + lam * np.eye(len(tr))); one = np.ones(len(tr))
    mu = (one @ Vi @ y[tr]) / (one @ Vi @ one)
    return mu + G[np.ix_(te, tr)] @ (Vi @ (y[tr] - mu))


def corr(a, b):
    return float(np.corrcoef(a, b)[0, 1])


def one_rep(cfg, rng, fs):
    F, m = cfg["n_fam"], cfg["m"]
    p = rng.uniform(0.1, 0.5, m)
    X, fam = make_families(rng, F, fs, p)
    Xn, famn = make_families(rng, cfg["n_new_fam"], fs, p)
    XX = np.vstack([X, Xn]); n, nn = len(X), len(Xn)
    Z = (XX - XX.mean(0)) / np.sqrt(2 * p * (1 - p))
    G = Z @ Z.T / m
    q = rng.choice(m, cfg["n_qtl"], replace=False)
    g = Z[:, q] @ rng.standard_normal(cfg["n_qtl"]); g *= np.sqrt(cfg["h2"] / g.var())
    y = g + rng.standard_normal(n + nn) * np.sqrt(1 - cfg["h2"])
    tr_all = np.arange(n); new = np.arange(n, n + nn)
    lam = cfg["lam"]
    # 真值
    truth = corr(fit_predict(G, y, tr_all, new, lam), g[new])
    # A 随机折
    perm = rng.permutation(n); folds = np.array_split(perm, cfg["folds"]); pr = np.zeros(n)
    for fo in folds:
        pr[fo] = fit_predict(G, y, np.setdiff1d(tr_all, fo), fo, lam)
    rand_cv = corr(pr, g[:n])
    # B 按家系折
    fperm = rng.permutation(F); fgroups = np.array_split(fperm, cfg["folds"]); pr2 = np.zeros(n)
    for grp in fgroups:
        te_ = np.where(np.isin(fam, grp))[0]
        pr2[te_] = fit_predict(G, y, np.setdiff1d(tr_all, te_), te_, lam)
    grp_cv = corr(pr2, g[:n])
    return truth, rand_cv, grp_cv, G[:n, :n], y[:n], fam


def main():
    cfg = json.load(open(HERE / "data" / "ex27_20_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    # (1) 恒等式（用第一个数据集）
    truth0, r0, g0, G, y, fam = one_rep(cfg, np.random.default_rng(cfg["seed"] + 1), cfg["fam_size"])
    lam = cfg["lam"]; n = len(y)
    H = gblup_hat(G, lam); e = y - H @ y
    maxdiff = 0.0
    for f in np.unique(fam)[:20]:
        B = np.where(fam == f)[0]; tr = np.setdiff1d(np.arange(n), B)
        e_slow = y[B] - fit_predict(G, y, tr, B, lam)
        e_fast = np.linalg.solve(np.eye(len(B)) - H[np.ix_(B, B)], e[B])
        maxdiff = max(maxdiff, float(np.abs(e_slow - e_fast).max()))
    print("=" * 84)
    print(f"习题 27.20  CV 设计：{cfg['n_fam']} 个家系 × {cfg['fam_size']}，新家系 {cfg['n_new_fam']} 个；{cfg['n_rep']} 次重复")
    print("=" * 84)
    print(f"(1) 留一家系恒等式 e_(-B) = (I−H_BB)⁻¹ e_B：20 个家系的最大差 {maxdiff:.2e}")
    assert maxdiff < 1e-8, maxdiff
    print(f"{'家系大小':>8} {'随机折':>8} {'家系折':>8} {'新家系真值':>10} {'随机−真值':>9} {'家系−真值':>9}")
    res = {}
    for fs in (4, 8, 16):
        T, R, Gp = [], [], []
        for r in range(cfg["n_rep"]):
            t, rc, gc, _, _, _ = one_rep(cfg, np.random.default_rng(cfg["seed"] + 10 * fs + r), fs)
            T.append(t); R.append(rc); Gp.append(gc)
        res[fs] = (float(np.mean(R)), float(np.mean(Gp)), float(np.mean(T)))
        print(f"{fs:>8} {res[fs][0]:>8.3f} {res[fs][1]:>8.3f} {res[fs][2]:>10.3f} {res[fs][0] - res[fs][2]:>+9.3f} {res[fs][1] - res[fs][2]:>+9.3f}")
    R8, G8, T8 = res[8]
    assert R8 - T8 > 0.08, (R8, T8)                                   # 随机折乐观
    assert G8 < T8 and abs(G8 - T8) < 0.5 * (R8 - T8) + 0.0 or abs(G8 - T8) < (R8 - T8), (G8, T8, R8)   # 家系折偏悲观（训练集少 20%），但偏差小于随机折
    for fs in (4, 8, 16):
        assert res[fs][0] > res[fs][2] + 0.05 and res[fs][1] < res[fs][0] - 0.1, (fs, res[fs])
    json.dump(dict(block_identity_max_diff=maxdiff, results={str(k): dict(random_cv=v[0], family_cv=v[1], truth=v[2]) for k, v in res.items()}),
              open(HERE / "results" / "ex27_20_cv_design_block_identity.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
