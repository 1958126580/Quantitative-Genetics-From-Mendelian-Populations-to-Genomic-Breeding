#!/usr/bin/env python3
"""习题 27.18  超参数选择的“赢家诅咒”：单一测试集挑选、真准确度与嵌套交叉验证

设置：m=500 个 SNP，100 个 QTL，h²=0.5；n_train=200。候选“模型”为 60 种随机的 150-SNP 子集（岭回归，λ 固定），
彼此交换（真准确度仅因所含 QTL 数的偶然差异而不同）。
三种流程：
  (A) 朴素：在 100 头的小测试集上对 60 个模型评估预测相关，报告最大者及其相关（既选又报）；
  (B) 诚实重估：对 A 选出的模型在 3000 头的新测试集上重新评估，即其“真准确度”；
  (C) 嵌套交叉验证：外层 5 折，内层 4 折选模型，外层折上评估所选模型，平均即为选择流程本身的准确度估计。
核验：(1) A 的报告值高于 B 的真准确度（平均偏高 > 0.03），且偏高量小于“60 个独立估计的期望最大值”上限 ≈ 2.3σ（占其 15%–100%；候选之间的估计误差正相关）；
      (2) 随机选一个模型的真准确度 ≤ A 选出的真准确度 + 0.01（选择确有一点真信号，但远小于报告的优势）；
      (3) C 的估计与 B 的真准确度之差的绝对值 < A 的偏差的一半；
      (4) 测试集越小偏差越大（n_test = 50, 100, 400 的偏差单调递减）。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def ridge_fit_predict(Ztr, ytr, Zte, lam):
    mu = ytr.mean()
    K = Ztr @ Ztr.T / Ztr.shape[1]
    alpha = np.linalg.solve(K + lam * np.eye(len(ytr)), ytr - mu)
    return Zte @ (Ztr.T @ alpha) / Ztr.shape[1]


def corr(a, b):
    a = a - a.mean(); b = b - b.mean()
    return float(a @ b / np.sqrt((a @ a) * (b @ b)))


def simulate(cfg, rng):
    m = cfg["m"]
    p = rng.uniform(0.1, 0.5, m)
    ntot = cfg["n_train"] + cfg["n_test_big"] + 400
    X = (rng.random((ntot, m)) < p).astype(float) + (rng.random((ntot, m)) < p).astype(float)
    Z = (X - 2 * p) / np.sqrt(2 * p * (1 - p))
    q = rng.choice(m, cfg["n_qtl"], replace=False)
    g = Z[:, q] @ rng.standard_normal(cfg["n_qtl"]); g *= np.sqrt(cfg["h2"] / g.var())
    y = g + rng.standard_normal(ntot) * np.sqrt(1 - cfg["h2"])
    return Z, g, y


def main():
    cfg = json.load(open(HERE / "data" / "ex27_18_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    ntr, nsm, nbig = cfg["n_train"], cfg["n_test_small"], cfg["n_test_big"]
    C, S, lam = cfg["n_configs"], cfg["subset"], cfg["lam"]
    A_rep, B_true, rand_true, sig, B_g = [], [], [], [], []
    by_size = {50: [], 100: [], 400: []}
    for r in range(cfg["n_rep"]):
        Z, g, y = simulate(cfg, rng)
        tr = np.arange(ntr); big = np.arange(ntr, ntr + nbig); small_pool = np.arange(ntr + nbig, ntr + nbig + 400)
        subsets = [rng.choice(cfg["m"], S, replace=False) for _ in range(C)]
        preds_big = [ridge_fit_predict(Z[tr][:, s], y[tr], Z[big][:, s], lam) for s in subsets]
        true_acc = np.array([corr(p_, y[big]) for p_ in preds_big])          # 对表型的相关（与选择时所用量同尺度）
        true_g = np.array([corr(p_, g[big]) for p_ in preds_big])
        preds_pool = [ridge_fit_predict(Z[tr][:, s], y[tr], Z[small_pool][:, s], lam) for s in subsets]
        for nt in by_size:
            idx = np.arange(nt)
            # 测试的“表型相关”用于选择（真实流程只有表型）
            accs = np.array([corr(p_[idx], y[small_pool][idx]) for p_ in preds_pool])
            k = int(np.argmax(accs))
            by_size[nt].append(accs[k] - true_acc[k])
            if nt == nsm:
                A_rep.append(accs[k]); B_true.append(true_acc[k]); rand_true.append(true_acc.mean()); B_g.append(true_g[k])
                sig.append(np.std(accs))
    # 嵌套 CV
    nest_est, nest_true = [], []
    for r in range(cfg["n_rep_nested"]):
        Z, g, y = simulate(cfg, np.random.default_rng(cfg["seed"] + 100 + r))
        tr = np.arange(ntr); big = np.arange(ntr, ntr + nbig)
        rr = np.random.default_rng(cfg["seed"] + 200 + r)
        subsets = [rr.choice(cfg["m"], S, replace=False) for _ in range(C)]
        folds = np.array_split(rr.permutation(ntr), cfg["outer"])
        outer_pred = np.zeros(ntr); sel_models = []
        for fo in folds:
            tr_o = np.setdiff1d(tr, fo)
            inner = np.array_split(rr.permutation(tr_o), cfg["inner"])
            score = np.zeros(C)
            for fi in inner:
                tr_i = np.setdiff1d(tr_o, fi)
                for c_, s in enumerate(subsets):
                    score[c_] += corr(ridge_fit_predict(Z[tr_i][:, s], y[tr_i], Z[fi][:, s], lam), y[fi])
            c_best = int(np.argmax(score)); sel_models.append(c_best)
            outer_pred[fo] = ridge_fit_predict(Z[tr_o][:, subsets[c_best]], y[tr_o], Z[fo][:, subsets[c_best]], lam)
        # 外层折上的汇总相关（对表型）→ 转换为对真遗传值的可比量：用与表型相关除以 √h²（大样本近似），这里直接比较“对表型”的相关
        est = corr(outer_pred, y[tr])
        # 流程的“真值”：用全部训练数据+内层 CV 选出的模型，在 3000 个新个体上对表型的相关
        score = np.zeros(C); inner = np.array_split(rr.permutation(tr), cfg["outer"])
        for fi in inner:
            tr_i = np.setdiff1d(tr, fi)
            for c_, s in enumerate(subsets):
                score[c_] += corr(ridge_fit_predict(Z[tr_i][:, s], y[tr_i], Z[fi][:, s], lam), y[fi])
        cb = int(np.argmax(score)); pr = ridge_fit_predict(Z[tr][:, subsets[cb]], y[tr], Z[big][:, subsets[cb]], lam)
        nest_est.append(est); nest_true.append(corr(pr, y[big]))
    A_rep, B_true, rand_true, sig, B_g = map(np.array, (A_rep, B_true, rand_true, sig, B_g))
    bias = float(np.mean(A_rep - B_true))
    # 小测试集选择使用的是对表型的相关，故对比同一尺度：把 B 换算到“对表型”的真相关用 √h² 近似
    rho_bar = float(B_true.mean()); sig_s = (1 - rho_bar ** 2) / np.sqrt(nsm - 1)
    emax = np.sqrt(2 * np.log(C)) - (np.log(np.log(C)) + np.log(4 * np.pi)) / (2 * np.sqrt(2 * np.log(C)))          # C 个独立标准正态的期望最大值的近似
    theory = float(sig_s * emax)           # 若 60 个模型的估计误差独立，偏差的上限；共享训练集/测试集使误差正相关，实际偏差更小
    print("=" * 88)
    print(f"习题 27.18  赢家诅咒：{C} 个候选模型，训练 {ntr}，小测试集 {nsm}；{cfg['n_rep']} 次重复（嵌套 CV {cfg['n_rep_nested']} 次）")
    print("=" * 88)
    print(f"A 朴素报告的最大相关（对表型）：{A_rep.mean():.3f}；该模型在 3000 头新个体上对表型的真相关：{B_true.mean():.3f}（对遗传值 {B_g.mean():.3f}）；随机一个模型的真相关：{rand_true.mean():.3f}")
    print(f"A 的平均偏高 {bias:+.3f}；单个相关估计的抽样标准误 σ={sig_s:.3f}，若 {C} 个估计误差独立则偏差上限 ≈ {emax:.2f}σ = {theory:.3f}（实际更小：误差正相关）")
    print("偏差随小测试集规模：" + "，".join(f"n={k}: {np.mean(v):+.3f}" for k, v in by_size.items()))
    print(f"嵌套 CV 的估计（对表型的相关）{np.mean(nest_est):.3f}；同一流程在 3000 头新个体上的真相关（对表型）{np.mean(nest_true):.3f}；差 {np.mean(nest_est) - np.mean(nest_true):+.3f}")
    assert bias > 0.03, bias
    assert 0.15 < bias / theory < 1.0, (bias, theory)
    assert rand_true.mean() <= B_true.mean() + 0.01
    sizes = [np.mean(by_size[k]) for k in (50, 100, 400)]
    assert sizes[0] > sizes[1] > sizes[2], sizes
    assert abs(np.mean(nest_est) - np.mean(nest_true)) < 0.5 * bias, (np.mean(nest_est), np.mean(nest_true), bias)
    json.dump(dict(naive_report=float(A_rep.mean()), true_selected=float(B_true.mean()), true_random=float(rand_true.mean()), bias=bias, theory_max=theory,
                   bias_by_test_size={str(k): float(np.mean(v)) for k, v in by_size.items()}, nested_est=float(np.mean(nest_est)), nested_true=float(np.mean(nest_true))),
              open(HERE / "results" / "ex27_18_winners_curse_nested_cv.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
