#!/usr/bin/env python3
"""习题 27.16  GBLUP 与 BayesCπ：遗传结构决定贝叶斯方法能否胜出

模型：y = μ + Zβ + e，Z 为中心化 SNP 基因型。
GBLUP：β_j ~ N(0,σ_β²) 全部位点同方差（REML 估计方差，特征分解的一维剖面）。
BayesCπ：β_j = δ_j b_j，δ_j ~ Bernoulli(1−π)，b_j ~ N(0,σ_b²)；π ~ Beta(1,1) 先验；σ_b²、σ_e² 为尺度化逆卡方；单位点 Gibbs 更新（残差向量在线更新）。
两种遗传结构：
  (A) 多基因：400 个 QTL、效应 N(0,1)；(B) 稀疏：15 个 QTL，效应 t₃ 分布（含少数大效应）。
在 300 个训练个体上拟合，在 1000 个独立测试个体上评估 EBV 与真遗传值的相关。
输出：两方法的预测相关、BayesCπ 的 π̂（包含概率后验均值）与 PIP 分析（稀疏结构下真 QTL 被检出个数 / 假阳性个数）。
核验：(1) 稀疏结构下 BayesCπ 的相关高于 GBLUP 至少 0.02；(2) 多基因结构下 GBLUP 不低于 BayesCπ 超过 0.03；
      (3) 稀疏结构下的 π̂（包含概率）显著低于多基因结构；(4) Gibbs 迹的前后半段 σ_e² 均值差 < 25%（粗收敛检查）。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def genotypes(rng, n, m, blocks, rho, p):
    L = m // blocks; tot = np.zeros((n, m))
    for _ in range(2):
        e = rng.standard_normal((n, m)); z = e.copy()
        for b in range(blocks):
            j0 = b * L
            for j in range(1, L):
                z[:, j0 + j] = rho * z[:, j0 + j - 1] + np.sqrt(1 - rho ** 2) * e[:, j0 + j]
        tot += (z > norm.ppf(1 - p)).astype(float)
    return tot


def gblup(Z, y, Zt):
    n = len(y); G = Z @ Z.T; sc = np.mean(np.diag(G)); G /= sc
    d, U = np.linalg.eigh(G); yt = U.T @ y; xt = U.T @ np.ones(n)

    def nll(h2):
        dd = h2 * d + (1 - h2)
        xvx = np.sum(xt * xt / dd); b = np.sum(xt * yt / dd) / xvx
        r = yt - xt * b
        return 0.5 * (np.sum(np.log(dd)) + np.log(xvx) + (n - 1) * np.log(np.sum(r * r / dd)))
    h2 = float(minimize_scalar(nll, bounds=(1e-3, 0.999), method="bounded").x)
    dd = h2 * d + (1 - h2); xvx = np.sum(xt * xt / dd); mu = np.sum(xt * yt / dd) / xvx
    lam = (1 - h2) / h2
    alpha = np.linalg.solve(G + lam * np.eye(n), y - mu)
    return Zt @ (Z.T @ alpha) / sc, h2


def bayes_cpi(Z, y, Zt, cfg, rng):
    n, m = Z.shape
    xx = np.sum(Z * Z, axis=0)
    mu = y.mean(); e = y - mu
    b = np.zeros(m); pi_in = 0.2
    vy = y.var()
    nu_b, nu_e = cfg["nu_b"], cfg["nu_e"]
    S2b = 0.5 * vy / (m * pi_in * xx.mean() / n)
    S2e = 0.4 * vy
    sb2, se2 = S2b, 0.5 * vy
    nit, burn = cfg["n_iter"], cfg["burn"]
    bs = np.zeros(m); pip = np.zeros(m); pis = []; se_tr = []; K = 0
    for it in range(nit):
        # 均值
        mu_new = mu + (e.sum() / n) + rng.standard_normal() * np.sqrt(se2 / n)
        e -= (mu_new - mu); mu = mu_new
        logit_prior = np.log(pi_in / (1 - pi_in))
        z_u = rng.random(m); z_n = rng.standard_normal(m)
        nin = 0
        for j in range(m):
            zj = Z[:, j]
            rj = zj @ e + xx[j] * b[j]
            v = 1.0 / (xx[j] / se2 + 1.0 / sb2)
            mj = v * rj / se2
            logBF = 0.5 * np.log(v / sb2) + 0.5 * mj * mj / v
            pj = 1.0 / (1.0 + np.exp(-(logit_prior + logBF)))
            bj_new = (mj + np.sqrt(v) * z_n[j]) if z_u[j] < pj else 0.0
            if bj_new != b[j]:
                e += zj * (b[j] - bj_new)
                b[j] = bj_new
            nin += bj_new != 0.0
            if it >= burn:
                pip[j] += pj
        pi_in = rng.beta(1 + nin, 1 + m - nin)
        pi_in = min(max(pi_in, 1e-3), 0.999)
        sb2 = (nu_b * S2b + b @ b) / rng.chisquare(nu_b + max(nin, 1))
        se2 = (nu_e * S2e + e @ e) / rng.chisquare(nu_e + n)
        if it >= burn:
            bs += b; K += 1; pis.append(pi_in); se_tr.append(se2)
    bh = bs / K
    return Zt @ bh, pip / K, np.array(pis), np.array(se_tr)


def main():
    cfg = json.load(open(HERE / "data" / "ex27_16_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    ntr, nte, m = cfg["n_train"], cfg["n_test"], cfg["m"]
    p = rng.uniform(0.1, 0.5, m)
    X = genotypes(rng, ntr + nte, m, cfg["ld_blocks"], cfg["ld_rho"], p)
    Zall = X - X[:ntr].mean(0); Z, Zt = Zall[:ntr], Zall[ntr:]
    out = {}
    print("=" * 84)
    print(f"习题 27.16  GBLUP 与 BayesCπ：训练 {ntr}，测试 {nte}，m={m}，h²={cfg['h2']}，迭代 {cfg['n_iter']}（烧入 {cfg['burn']}）")
    print("=" * 84)
    for name, nq, heavy in (("A 多基因", cfg["poly_qtl"], False), ("B 稀疏", cfg["sparse_qtl"], True)):
        qtl = rng.choice(m, nq, replace=False)
        beta = np.zeros(m)
        beta[qtl] = rng.standard_t(3, nq) if heavy else rng.standard_normal(nq)
        g_all = Zall @ beta
        g_all *= np.sqrt(cfg["h2"] / g_all[:ntr].var())
        y_all = g_all + rng.standard_normal(ntr + nte) * np.sqrt(1 - cfg["h2"])
        y, gt = y_all[:ntr], g_all[ntr:]
        pg, h2g = gblup(Z, y, Zt)
        pb, pip, pis, setr = bayes_cpi(Z, y, Zt, cfg, rng)
        rg, rb = float(np.corrcoef(pg, gt)[0, 1]), float(np.corrcoef(pb, gt)[0, 1])
        half = len(setr) // 2
        drift = abs(setr[:half].mean() - setr[half:].mean()) / setr.mean()
        pi_hat = float(pis.mean())
        det = int(np.sum(pip[qtl] > 0.5)); fp = int(np.sum(np.delete(pip, qtl) > 0.5))
        top_share = float(np.sort(np.abs(beta[qtl]))[-3:].sum() / np.abs(beta[qtl]).sum())
        print(f"\n结构 {name}（{nq} 个 QTL，最大 3 个效应占绝对效应和 {top_share:.2f}）")
        print(f"  GBLUP：ĥ²={h2g:.3f}，与真遗传值相关 {rg:.3f}")
        print(f"  BayesCπ：包含概率 π̂（后验均值）= {pi_hat:.3f}，相关 {rb:.3f}；σ_e² 前后半段相对差 {drift:.1%}")
        print(f"  PIP>0.5 的位点：真 QTL {det}/{nq}，其他 {fp}")
        out[name] = dict(n_qtl=nq, gblup=rg, bayes=rb, h2_gblup=h2g, pi_in=pi_hat, detected=det, false_pos=fp, drift=float(drift))
        assert drift < 0.25, drift
    A, B = out["A 多基因"], out["B 稀疏"]
    assert B["bayes"] > B["gblup"] + 0.02, B
    assert A["gblup"] > A["bayes"] - 0.03, A
    assert B["pi_in"] < A["pi_in"] - 0.15, (A["pi_in"], B["pi_in"])
    json.dump(out, open(HERE / "results" / "ex27_16_bayes_alphabet.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
