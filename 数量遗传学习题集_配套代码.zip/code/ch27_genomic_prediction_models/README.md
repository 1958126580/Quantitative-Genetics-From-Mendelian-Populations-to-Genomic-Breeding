# 第27章　GBLUP、岭回归、贝叶斯与核方法——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex27_15_ridge_gblup_spectral.py
python3 ex27_16_bayes_alphabet.py
python3 ex27_17_kernel_epistasis.py
python3 ex27_18_winners_curse_nested_cv.py
python3 ex27_19_proxy_weights.py
python3 ex27_20_cv_design_block_identity.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex27_15_ridge_gblup_spectral.py | 27.15 | SNP-BLUP（岭回归）与 GBLUP 的等价性、谱收缩与有效自由度、留一恒等式 |
| ex27_16_bayes_alphabet.py | 27.16 | GBLUP 与 BayesCπ：遗传结构决定贝叶斯方法能否胜出 |
| ex27_17_kernel_epistasis.py | 27.17 | 核方法（RKHS）与多核 REML：上位性存在时，核预测改善了什么 |
| ex27_18_winners_curse_nested_cv.py | 27.18 | 超参数选择的“赢家诅咒”：单一测试集挑选、真准确度与嵌套交叉验证 |
| ex27_19_proxy_weights.py | 27.19 | 代理表型（DYD/去回归育种值）的权重：不等精度记录下的 GBLUP 与验证相关的“可靠度修正” |
| ex27_20_cv_design_block_identity.py | 27.20 | 交叉验证的设计：留组误差的精确恒等式，以及随机折与按家系折对“新家系”准确度的估计 |
