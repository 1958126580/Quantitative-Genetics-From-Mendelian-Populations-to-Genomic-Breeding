#!/usr/bin/env python3
"""习题 27.17  核方法（RKHS）与多核 REML：上位性存在时，核预测改善了什么

性状：y = a + g_aa + e，a 为加性（QTL 线性效应），g_aa ~ N(0, σ²_aa·G#G)（Henderson 加加上位性核）。
群体：全同胞家系（上位性方差只有在有亲属时才可与加性方差区分：G#G 的非对角元为 G 的逐元平方）。
情形 (1) 纯加性（h²=0.5）；(2) 加性 + 上位性（加性 0.25、上位性 0.25、残差 0.5）。
方法：
  GBLUP：线性核 G = ZZᵀ/m；
  Gaussian 核：K_θ = exp(−θ d²_{ij}/median(d²))，对 θ 网格用单核 REML 的剖面边际似然选带宽；
  多核：y = μ + a + k + e，a~N(0,σ_a² G)，k~N(0,σ_aa² G#G)，e~N(0,σ_e² I)（AI-REML，自写）。
评价：对测试个体预测 (i) 总遗传值 g_total 的相关，(ii) 加性值 a（育种值）的相关。
要点：核预测通过表示定理 f̂(x*) = Σ_i α_i k(x*, x_i)，新个体只需核向量（不需要把测试个体加入训练核矩阵）。
核验：(1) 纯加性：G+G#G 与 GBLUP 对总遗传值的相关相差 < 0.02；
      (2) 加性+上位性：估计的上位性占遗传方差之比比纯加性情形高 0.1 以上；G+G#G 对总遗传值的相关不低于 GBLUP − 0.005，增益 < 0.05（上位性方差可识别 ≠ 预测大幅改善）；
      (3) 加性+上位性时，G+G#G 对育种值 a 的相关不高于 GBLUP + 0.01（用核模型选育种值没有收益）；
      (4) 表示定理：测试个体的预测等于 K_{*,tr} α，与“把测试个体并入核矩阵再解混合模型”结果完全相同（1e-8）。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar

HERE = Path(__file__).resolve().parent


def reml1(y, K):
    n = len(y); d, U = np.linalg.eigh(K); d = np.maximum(d, 0)
    yt = U.T @ y; xt = U.T @ np.ones(n)

    def parts(h):
        dd = h * d + (1 - h); xvx = np.sum(xt * xt / dd); b = np.sum(xt * yt / dd) / xvx
        r = yt - xt * b; ypy = np.sum(r * r / dd)
        return dd, xvx, b, ypy

    def nll(h):
        dd, xvx, _, ypy = parts(h)
        return 0.5 * (np.sum(np.log(dd)) + np.log(xvx) + (n - 1) * np.log(ypy))
    r = minimize_scalar(nll, bounds=(1e-4, 0.9999), method="bounded", options={"xatol": 1e-8})
    h = float(r.x); dd, xvx, b, ypy = parts(h)
    sp = ypy / (n - 1)
    ll = -0.5 * (np.sum(np.log(dd)) + np.log(xvx) + (n - 1) * np.log(sp))     # 剖面 REML 对数似然，跨 K 可比
    return h, sp, float(ll)


def ai_reml(y, Ks, iters=60):
    """分量 [K_1..K_r, I]；返回 σ²。"""
    n = len(y); Vk = list(Ks) + [np.eye(n)]; r = len(Vk)
    s2 = np.full(r, np.var(y) / r); X = np.ones((n, 1))
    for _ in range(iters):
        V = sum(a * M for a, M in zip(s2, Vk)); Vi = np.linalg.inv(V)
        XVX = X.T @ Vi @ X; P = Vi - Vi @ X @ np.linalg.solve(XVX, X.T @ Vi)
        Py = P @ y
        VPy = [M @ Py for M in Vk]
        score = np.array([-0.5 * (np.trace(P @ M) - Py @ v) for M, v in zip(Vk, VPy)])
        AI = np.empty((r, r))
        for a in range(r):
            PVa = P @ VPy[a]
            for b in range(a, r):
                AI[a, b] = AI[b, a] = 0.5 * VPy[b] @ PVa
        step = np.linalg.solve(AI, score); t = 1.0; new = s2 + step
        while np.any(new < 1e-8) and t > 1e-4:
            t *= 0.5; new = s2 + t * step
        s2 = np.maximum(new, 1e-8)
        if np.max(np.abs(score)) < 1e-6:
            break
    return s2


def blup_pred(y, Ks_tr, Ks_te, s2):
    n = len(y); V = sum(a * M for a, M in zip(s2[:-1], Ks_tr)) + s2[-1] * np.eye(n)
    Vi = np.linalg.inv(V); one = np.ones(n); mu = (one @ Vi @ y) / (one @ Vi @ one)
    alpha = Vi @ (y - mu)
    return sum(a * Kt @ alpha for a, Kt in zip(s2[:-1], Ks_te)), mu


def gauss_kernel(Za, Zb, theta, med):
    d2 = (Za ** 2).sum(1)[:, None] + (Zb ** 2).sum(1)[None, :] - 2 * Za @ Zb.T
    return np.exp(-theta * np.maximum(d2, 0) / med)


def simulate(cfg, rng, mix):
    """全同胞家系：F 个家系 × 每家系 fam_size 个子代；双亲为无亲缘的起始个体；位点独立。
    加性值 a = Zβ（QTL 线性）；上位性 aa ~ N(0, σ²_aa·G#G/c)（G#G 为 Henderson 的加加上位性核，逐元平方）。"""
    F, fs, m = cfg["n_fam"], cfg["fam_size"], cfg["m"]
    n = F * fs
    p = rng.uniform(0.1, 0.5, m)
    par = (rng.random((2 * F, 2, m)) < p).astype(np.int8)                 # 每个双亲两条单倍型
    X = np.empty((n, m))
    for f in range(F):
        s_, d_ = par[2 * f], par[2 * f + 1]
        for k in range(fs):
            h1 = np.where(rng.integers(0, 2, m) == 0, s_[0], s_[1]); h2 = np.where(rng.integers(0, 2, m) == 0, d_[0], d_[1])
            X[f * fs + k] = h1 + h2
    perm = rng.permutation(n)                                              # 打乱次序以便随机划分训练/测试（家系成员散布）
    X = X[perm]; fam = (np.arange(n) // fs)[perm]
    Z = (X - X.mean(0)) / np.sqrt(2 * p * (1 - p))
    q = rng.choice(m, cfg["n_qtl"], replace=False)
    a = Z[:, q] @ rng.standard_normal(cfg["n_qtl"])
    G = Z @ Z.T / m
    GG = G * G; GG /= np.mean(np.diag(GG))
    va, vaa = (cfg["var_a_mix"], cfg["var_aa_mix"]) if mix else (cfg["var_a_add"], 0.0)
    a = (a - a.mean()) * np.sqrt(va / a.var())
    if mix:
        L = np.linalg.cholesky(GG + 1e-6 * np.eye(n))
        aa = L @ rng.standard_normal(n); aa = (aa - aa.mean()) * np.sqrt(vaa / aa.var())
    else:
        aa = np.zeros(n)
    ve = 1 - va - vaa
    y = a + aa + rng.standard_normal(n) * np.sqrt(ve)
    return Z, a, aa, y, (va, vaa, ve), fam


def main():
    cfg = json.load(open(HERE / "data" / "ex27_17_config.json"))
    rng = np.random.default_rng(cfg["seed"]); ntr = cfg["n_train"]
    res = {}
    print("=" * 100)
    print(f"习题 27.17  核方法与上位性：{cfg['n_fam']} 个全同胞家系 × {cfg['fam_size']}，随机划分训练 {ntr}/测试 {cfg['n_fam'] * cfg['fam_size'] - ntr}，m={cfg['m']}，{cfg['n_rep']} 次重复")
    print("=" * 100)
    for mix, label in ((False, "(1) 纯加性"), (True, "(2) 加性+上位性")):
        keys = ["gb_tot", "gb_a", "gk_tot", "gk_a", "mk_tot", "mk_a", "theta", "frac_aa", "s2a", "s2aa"]
        stats = {k: [] for k in keys}
        for r in range(cfg["n_rep"]):
            Z, a, aa, y, var, fam = simulate(cfg, rng, mix)
            n = Z.shape[0]; tr = np.arange(ntr); te = np.arange(ntr, n)
            m = Z.shape[1]
            G = Z @ Z.T / m; GG = G * G; GG /= np.mean(np.diag(GG[np.ix_(tr, tr)]))
            ytr = y[tr]
            # GBLUP
            h, sp, _ = reml1(ytr, G[np.ix_(tr, tr)])
            pg, _ = blup_pred(ytr, [G[np.ix_(tr, tr)]], [G[np.ix_(te, tr)]], np.array([h * sp, (1 - h) * sp]))
            # Gaussian
            d2 = (Z ** 2).sum(1)[:, None] + (Z ** 2).sum(1)[None, :] - 2 * Z @ Z.T
            med = np.median(d2[np.ix_(tr, tr)][np.triu_indices(ntr, 1)])
            lls = [reml1(ytr, np.exp(-th * np.maximum(d2[np.ix_(tr, tr)], 0) / med))[2] for th in cfg["thetas"]]
            th = cfg["thetas"][int(np.argmax(lls))]
            Kall = np.exp(-th * np.maximum(d2, 0) / med)
            hk, spk, _ = reml1(ytr, Kall[np.ix_(tr, tr)])
            pk, _ = blup_pred(ytr, [Kall[np.ix_(tr, tr)]], [Kall[np.ix_(te, tr)]], np.array([hk * spk, (1 - hk) * spk]))
            # 多核：G + G#G
            s2 = ai_reml(ytr, [G[np.ix_(tr, tr)], GG[np.ix_(tr, tr)]])
            pm, _ = blup_pred(ytr, [G[np.ix_(tr, tr)], GG[np.ix_(tr, tr)]], [G[np.ix_(te, tr)], GG[np.ix_(te, tr)]], s2)
            tot = (a + aa)[te]; add = a[te]
            c = lambda p_, t_: float(np.corrcoef(p_, t_)[0, 1])
            for k_, v_ in (("gb_tot", c(pg, tot)), ("gb_a", c(pg, add)), ("gk_tot", c(pk, tot)), ("gk_a", c(pk, add)), ("mk_tot", c(pm, tot)), ("mk_a", c(pm, add)),
                           ("theta", th), ("frac_aa", float(s2[1] / (s2[0] + s2[1] + 1e-12))), ("s2a", float(s2[0])), ("s2aa", float(s2[1]))):
                stats[k_].append(v_)
            if r == 0:   # (4) 表示定理：把测试个体并入核矩阵、联合求解，与仅用核向量一致
                V = s2[0] * G + s2[1] * GG + s2[2] * np.eye(n)
                Vtr = V[np.ix_(tr, tr)]; Vi = np.linalg.inv(Vtr); one = np.ones(ntr); mu = (one @ Vi @ ytr) / (one @ Vi @ one)
                u_te = (s2[0] * G[np.ix_(te, tr)] + s2[1] * GG[np.ix_(te, tr)]) @ (Vi @ (ytr - mu))
                rep_diff = float(np.abs(u_te - pm).max())
        mm = {k: float(np.mean(v)) for k, v in stats.items()}
        res[label] = dict(**mm, representer_diff=rep_diff, var_true=list(var))
        print(f"\n{label}（真方差：加性 {var[0]:.2f}，上位性 {var[1]:.2f}，残差 {var[2]:.2f}）")
        print(f"  {'方法':<12}{'对总遗传值相关':>14}{'对育种值 a 相关':>16}")
        print(f"  {'GBLUP':<12}{mm['gb_tot']:>14.3f}{mm['gb_a']:>16.3f}")
        print(f"  {'Gaussian 核':<10}{mm['gk_tot']:>14.3f}{mm['gk_a']:>16.3f}   （选出带宽 θ 均值 {mm['theta']:.2f}）")
        print(f"  {'G + G#G':<12}{mm['mk_tot']:>14.3f}{mm['mk_a']:>16.3f}   （σ̂_a²={mm['s2a']:.3f}，σ̂_aa²={mm['s2aa']:.3f}，上位性占遗传方差 {mm['frac_aa']:.2f}）")
        print(f"  表示定理核验：并入测试个体与仅用核向量的预测最大差 {rep_diff:.2e}")
        assert rep_diff < 1e-8, rep_diff
    a1, a2 = res["(1) 纯加性"], res["(2) 加性+上位性"]
    assert abs(a1["mk_tot"] - a1["gb_tot"]) < 0.02, (a1["mk_tot"], a1["gb_tot"])
    assert a2["mk_tot"] >= a2["gb_tot"] - 0.005 and a2["mk_tot"] - a2["gb_tot"] < 0.05, (a2["mk_tot"], a2["gb_tot"])      # 总遗传值：不降，增益有限
    assert a2["frac_aa"] > a1["frac_aa"] + 0.1, (a1["frac_aa"], a2["frac_aa"])
    assert a2["mk_a"] < a2["gb_a"] + 0.01, (a2["mk_a"], a2["gb_a"])                                                      # 育种值：核没有带来收益
    json.dump(res, open(HERE / "results" / "ex27_17_kernel_epistasis.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
