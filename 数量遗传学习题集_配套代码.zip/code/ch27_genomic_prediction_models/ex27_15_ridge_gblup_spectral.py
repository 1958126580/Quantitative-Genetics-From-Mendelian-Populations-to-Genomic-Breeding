#!/usr/bin/env python3
"""习题 27.15  SNP-BLUP（岭回归）与 GBLUP 的等价性、谱收缩与有效自由度、留一恒等式

模型：y = 1μ + Zβ + e，β ~ N(0, σ_β² I)，Z 为中心化基因型，G = ZZᵀ/s（s = tr 常数，使 G 的平均对角为 1）。
(1) 等价：SNP-BLUP 的 β̂ = Zᵀ(ZZᵀ + λ'I)⁻¹(y−μ)，预测 ZZᵀ(...)⁻¹ ... 与 GBLUP ĝ = G(G+λI)⁻¹(y−μ) 当 λ' = λs 时相同；
    测试个体的预测 Z_t β̂ 与 G_{tr}(G+λI)⁻¹(y−μ) 完全相同（1e-8）。
(2) 谱收缩：G = U diag(d_k) Uᵀ，GBLUP 对第 k 个特征方向的收缩因子 d_k/(d_k+λ)；有效自由度 df(λ)=Σ d_k/(d_k+λ)。
    基因型含 LD 块（块内 AR(1) 相关），使特征值快速衰减。
(3) 样本外误差随 λ 的 U 形曲线：训练 n=300、测试 300；真遗传力 0.5 对应的“名义”λ=(1−h²)/h²=1（因 G 的平均对角元为 1，但 LD 与 QTL 数使最优 λ 略有偏离）。
(4) 留一恒等式：对岭回归（含截距的投影），LOO 残差 e_i^{(-i)} = e_i/(1−H_ii)，H = G(G+λI)⁻¹ 加上截距校正；
    与显式留一（n 次重拟合）逐元一致（1e-8），并与广义交叉验证（GCV）选择的 λ 比较。
核验：(a) 预测一致 1e-8；(b) df(λ) 单调递减，λ→0 趋于 rank，λ→∞ 趋于 0；(c) 测试 MSE 在 λ 网格上呈先降后升（最小值不在两端）；
      (d) LOO 恒等式 1e-8；(e) 以 LOO-PRESS 选 λ 的测试相关与测试集最优相差 < 0.03。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def genotypes(rng, n, m, blocks, rho, p):
    """块内 AR(1) 潜变量阈值化的单倍型 → 基因型。"""
    L = m // blocks
    out = np.empty((n, m))
    for h in range(2):
        z = rng.standard_normal((n, m)); e = z.copy()
        for b in range(blocks):
            j0 = b * L
            for j in range(1, L):
                z[:, j0 + j] = rho * z[:, j0 + j - 1] + np.sqrt(1 - rho ** 2) * e[:, j0 + j]
        from scipy.stats import norm
        hap = (z > norm.ppf(1 - p)).astype(float)
        out = hap if h == 0 else out + hap
    return out


def main():
    cfg = json.load(open(HERE / "data" / "ex27_15_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    n, m, nt = cfg["n"], cfg["m"], cfg["n_test"]
    p = rng.uniform(0.1, 0.5, m)
    Xall = genotypes(rng, n + nt, m, cfg["ld_blocks"], cfg["ld_rho"], p)
    pm = Xall[:n].mean(0) / 2
    Z_all = Xall - 2 * pm
    s = np.mean(np.sum(Z_all[:n] ** 2, axis=1))            # 使训练个体平均对角元 = 1
    Z, Zt = Z_all[:n], Z_all[n:]
    G = Z @ Z.T / s; Gt = Zt @ Z.T / s
    # 性状：随机选 n_qtl 个 QTL
    qtl = rng.choice(m, cfg["n_qtl"], replace=False)
    beta_true = np.zeros(m); beta_true[qtl] = rng.standard_normal(cfg["n_qtl"])
    g_all = Z_all @ beta_true
    g_all *= np.sqrt(cfg["h2"] / g_all[:n].var())
    y_all = g_all + rng.standard_normal(n + nt) * np.sqrt(1 - cfg["h2"])
    y, yt, gt = y_all[:n], y_all[n:], g_all[n:]
    gtc = gt - gt.mean()
    # (1) 等价
    lam = (1 - cfg["h2"]) / cfg["h2"]
    mu = y.mean()
    beta_hat = Z.T @ np.linalg.solve(Z @ Z.T + lam * s * np.eye(n), y - mu)
    pred_snp = Zt @ beta_hat
    pred_gb = Gt @ np.linalg.solve(G + lam * np.eye(n), y - mu)
    eq = float(np.abs(pred_snp - pred_gb).max())
    # (2) 谱
    d, U = np.linalg.eigh(G); d = d[::-1]; U = U[:, ::-1]
    d = np.maximum(d, 0)
    def df(l): return float(np.sum(d / (d + l)))
    dfs = [df(l) for l in cfg["lambdas"]]
    top = [float(d[:k].sum() / d.sum()) for k in (1, 5, 20, 50)]
    # (3) 测试误差：y 的中心化版本；以 mu 为训练均值
    rows = []
    for l in cfg["lambdas"]:
        pr = Gt @ np.linalg.solve(G + l * np.eye(n), y - mu)
        rows.append(dict(lam=l, df=df(l), mse_g=float(np.mean((pr - gtc) ** 2)), corr=float(np.corrcoef(pr, gt)[0, 1]), corr_y=float(np.corrcoef(pr, yt)[0, 1])))
    # 简化：MSE 对 (pr − gt_centered)，gt 去均值
    # (4) LOO 恒等式（含截距：用中心化对称化的帽子矩阵）
    one = np.ones(n)
    def loo_explicit(l):
        res = np.empty(n)
        for i in range(n):
            idx = np.delete(np.arange(n), i)
            Gi = G[np.ix_(idx, idx)]; yi = y[idx]
            # 含截距的 BLUP：GLS 均值
            V = Gi + l * np.eye(n - 1); Vi = np.linalg.inv(V); o = np.ones(n - 1)
            mui = (o @ Vi @ yi) / (o @ Vi @ o)
            res[i] = y[i] - (mui + G[i, idx] @ (Vi @ (yi - mui)))
        return res
    def hat(l):
        V = G + l * np.eye(n); Vi = np.linalg.inv(V)
        # ŷ = μ̂ + G Vi (y − μ̂ 1)，μ̂ = 1ᵀViy/(1ᵀVi1)
        Pm = np.eye(n) - np.outer(one, one @ Vi) / (one @ Vi @ one)       # y → y − μ̂1
        return np.outer(one, one @ Vi) / (one @ Vi @ one) + G @ Vi @ Pm, Vi
    lam_test = 2.0
    H, Vi = hat(lam_test)
    e = y - H @ y
    loo_fast = e / (1 - np.diag(H))
    loo_slow = loo_explicit(lam_test)
    ident = float(np.abs(loo_fast - loo_slow).max())
    # PRESS / GCV 选 λ
    press = {}; gcv = {}
    for l in cfg["lambdas"]:
        H_, _ = hat(l); e_ = y - H_ @ y
        press[l] = float(np.sum((e_ / (1 - np.diag(H_))) ** 2)); gcv[l] = float(n * np.sum(e_ ** 2) / (n - np.trace(H_)) ** 2)
    lam_press = min(press, key=press.get); lam_gcv = min(gcv, key=gcv.get)
    best = max(rows, key=lambda r: r["corr"]); sel = next(r for r in rows if r["lam"] == lam_press)
    print("=" * 92)
    print(f"习题 27.15  SNP-BLUP 与 GBLUP：n={n}，m={m}，LD 块 {cfg['ld_blocks']}（ρ={cfg['ld_rho']}），真 h²={cfg['h2']}")
    print("=" * 92)
    print(f"(1) 测试个体预测：SNP-BLUP 与 GBLUP 的最大绝对差 {eq:.2e}（预测 SD {pred_gb.std():.3f}）")
    print(f"(2) 前 1/5/20/50 个特征值占 G 迹的比例：{', '.join(f'{t:.3f}' for t in top)}")
    print(f"{'λ':>7} {'df':>8} {'测试MSE(对真遗传值)':>16} {'相关(真值)':>11} {'相关(表型)':>11} {'PRESS':>10} {'GCV':>9}")
    for r in rows:
        print(f"{r['lam']:>7.2f} {r['df']:>8.1f} {r['mse_g']:>16.4f} {r['corr']:>11.4f} {r['corr_y']:>11.4f} {press[r['lam']]:>10.1f} {gcv[r['lam']]:>9.3f}")
    print(f"(4) 留一恒等式（λ={lam_test}）：快速公式与显式留一的最大差 {ident:.2e}")
    print(f"    PRESS 选 λ={lam_press}、GCV 选 λ={lam_gcv}；测试相关：最优 λ={best['lam']} 为 {best['corr']:.4f}，PRESS 选的为 {sel['corr']:.4f}")
    assert eq < 1e-8, eq
    assert all(dfs[i] > dfs[i + 1] for i in range(len(dfs) - 1))
    assert dfs[0] > 200 and dfs[-1] < 1                           # λ→0 时 df→秩（此处 ≈ n−1），λ→∞ 时 df→0
    assert dfs[-1] < dfs[0] * 0.2
    mses = [r["mse_g"] for r in rows]
    assert 0 < int(np.argmin(mses)) < len(mses) - 1, mses
    assert ident < 1e-8, ident
    assert best["corr"] - sel["corr"] < 0.03
    json.dump(dict(equivalence_max_diff=eq, top_eigen_fraction=top, rows=rows, loo_identity_max_diff=ident, lam_press=lam_press, lam_gcv=lam_gcv,
                   corr_best=best["corr"], corr_press=sel["corr"]), open(HERE / "results" / "ex27_15_ridge_gblup_spectral.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
