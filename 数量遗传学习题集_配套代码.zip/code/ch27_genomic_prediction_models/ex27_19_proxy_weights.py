#!/usr/bin/env python3
"""习题 27.19  代理表型（DYD/去回归育种值）的权重：不等精度记录下的 GBLUP 与验证相关的“可靠度修正”

模型：公牛 i 的代理表型 y_i = a_i + e_i，Var(a)=σ_a²G（σ_a²=1），Var(e_i)=k σ_a²/n_i（n_i 为女儿数，k=σ_e²/σ_a² 的比值=20），
可靠度 r_i² = n_i/(n_i+k)（n_i 在 5–300 之间对数均匀分布）。
方法（训练 400，验证 200）：
  U  未加权 GBLUP（残差方差取平均值 σ̄_e²，所有公牛等权）；
  W  正确加权（V = σ_a²G + diag(kσ_a²/n_i)）；
  R  可靠度权重 w_i = r_i²/(1−r_i²) = n_i/k（与 W 等价，核验）；
  S  错误的“平方根”权重 w_i ∝ √n_i。
评价：(i) 对验证公牛“真”育种值 a 的相关（模拟已知）；(ii) 对验证公牛代理表型 y 的相关 ρ_y；(iii) 修正后的估计 ρ_y/√r̄_v，其中 r̄_v 为验证公牛的平均可靠度（把 y 看作 a 的带噪测量）；
      以及按 r² 加权的相关修正。
核验：(1) W 与 R 的预测差 < 1e-10；(2) W 的对 a 的相关高于 U（25 次平均至少 +0.01），高于 S；
      (3) ρ_y 明显低于真相关（低估），而 ρ_y/√r̄_v 与真相关相差 < 0.06；
      (4) 报告：在验证公牛中按 r_i² 加权的相关经修正后的值。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def weighted_gblup(G, y, resid_var, tr, te, sa2=1.0):
    Gtt = G[np.ix_(tr, tr)]
    V = sa2 * Gtt + np.diag(resid_var[tr])
    Vi = np.linalg.inv(V); one = np.ones(len(tr)); mu = (one @ Vi @ y[tr]) / (one @ Vi @ one)
    return sa2 * G[np.ix_(te, tr)] @ (Vi @ (y[tr] - mu))


def wcorr(x, y, w):
    mx, my = np.average(x, weights=w), np.average(y, weights=w)
    return float(np.sum(w * (x - mx) * (y - my)) / np.sqrt(np.sum(w * (x - mx) ** 2) * np.sum(w * (y - my) ** 2)))


def main():
    cfg = json.load(open(HERE / "data" / "ex27_19_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    ntr, nv, m, k = cfg["n_train"], cfg["n_val"], cfg["m"], cfg["k"]
    n = ntr + nv; tr = np.arange(ntr); te = np.arange(ntr, n)
    rec = {k_: [] for k_ in ["U", "W", "S", "rho_y", "rho_y_corr", "rho_wcorr", "Wdiff"]}
    for r in range(cfg["n_rep"]):
        p = rng.uniform(0.1, 0.5, m)
        X = (rng.random((n, m)) < p).astype(float) + (rng.random((n, m)) < p).astype(float)
        Z = X - X.mean(0); Z /= np.sqrt(2 * p * (1 - p))
        G = Z @ Z.T / m
        q = rng.choice(m, cfg["n_qtl"], replace=False)
        a = Z[:, q] @ rng.standard_normal(cfg["n_qtl"]); a = (a - a.mean()) / a.std()
        nd = np.exp(rng.uniform(np.log(cfg["n_lo"]), np.log(cfg["n_hi"]), n)).round().clip(cfg["n_lo"])
        rel = nd / (nd + k)
        ev = k / nd                                              # Var(e_i) / σ_a²
        y = a + rng.standard_normal(n) * np.sqrt(ev)
        pu = weighted_gblup(G, y, np.full(n, ev[tr].mean()), tr, te)
        pw = weighted_gblup(G, y, ev, tr, te)
        pr = weighted_gblup(G, y, 1.0 / (rel / (1 - rel)), tr, te)       # 权 w=r²/(1−r²) → 残差方差 1/w=(1−r²)/r²=k/n
        ps = weighted_gblup(G, y, ev[tr].mean() * np.sqrt(nd[tr].mean() / nd), tr, te)
        c = lambda a_, b_: float(np.corrcoef(a_, b_)[0, 1])
        true_c = c(pw, a[te])
        rho_y = c(pw, y[te])
        rbar = float(np.mean(rel[te]))
        rec["U"].append(c(pu, a[te])); rec["W"].append(true_c); rec["S"].append(c(ps, a[te]))
        rec["rho_y"].append(rho_y); rec["rho_y_corr"].append(rho_y / np.sqrt(rbar))
        rec["rho_wcorr"].append(wcorr(pw, y[te], rel[te]) / np.sqrt(np.average(rel[te], weights=rel[te])))
        rec["Wdiff"].append(float(np.abs(pw - pr).max()))
    m_ = {k_: float(np.mean(v)) for k_, v in rec.items()}
    print("=" * 84)
    print(f"习题 27.19  代理表型权重：训练 {ntr}，验证 {nv}，k={k}，女儿数 {cfg['n_lo']}–{cfg['n_hi']}，{cfg['n_rep']} 次重复")
    print("=" * 84)
    print(f"对真育种值的相关：未加权 U {m_['U']:.3f}；正确加权 W {m_['W']:.3f}；平方根权 S {m_['S']:.3f}")
    print(f"W 与 R（w=r²/(1−r²)）的预测最大差 {max(rec['Wdiff']):.2e}")
    print(f"对验证公牛代理表型 y 的相关 ρ_y = {m_['rho_y']:.3f}（低估）；ρ_y/√r̄ = {m_['rho_y_corr']:.3f}；按 r² 加权后修正 {m_['rho_wcorr']:.3f}；真相关 {m_['W']:.3f}")
    assert max(rec["Wdiff"]) < 1e-10
    assert m_["W"] >= m_["U"] + 0.01 and m_["W"] >= m_["S"] - 1e-9, m_
    assert m_["rho_y"] < m_["W"] - 0.1
    assert abs(m_["rho_y_corr"] - m_["W"]) < 0.06, (m_["rho_y_corr"], m_["W"])
    json.dump(m_, open(HERE / "results" / "ex27_19_proxy_weights.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
