#!/usr/bin/env python3
"""习题 30.18  结构变异（缺失）的读深度分型：发现 ≠ 可靠分型

模型：一个二等位缺失，频率 f，HWE。个体 i 在该区间的归一化读深度 x_i ≈ s_i·(2−g_i)/2 + ε：
s_i 是个体的整体覆盖度（对数正态，变异系数 sample_cv，由全基因组深度估计并已部分校正，剩余噪声为 noise_cv），
g 为缺失拷贝数（0/1/2）。区间的泊松计数噪声随平均深度 λ 增大而相对变小：CV_poisson = 1/√(λ·(2−g)/2)。
分型方法：三成分高斯混合（均值固定在 1, 0.5, 0 倍，方差各自估计，EM，权重服从 HWE 约束的初值），
输出后验概率与最大后验基因型。指标：
  (1) 分型准确率（逐基因型）与杂合子召回率，对深度；
  (2) 对 HWE 的偏离：杂合子比例与期望 2f(1−f) 之比（误判造成的缺口）；
  (3) 用估计出的缺失剂量做 GWAS，真实效应 effect_sd 下的检验功效（α=1e-5）与效应衰减
      （估计斜率/真实斜率），并与"完美分型"和"完美标签 SNP（r²=tag_r²）"比较。
断言：准确率随深度提高；低深度时杂合子召回低于纯合；衰减系数随深度提高而趋近 1；
深度足够时 SV 直接分型的功效不低于 r²=0.64 的标签 SNP。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def make_depth(rng, g, lam, cfg):
    n = len(g)
    s = np.exp(rng.normal(0, cfg["sample_cv"], n) - cfg["sample_cv"] ** 2 / 2)
    s_hat = s * np.exp(rng.normal(0, cfg["noise_cv"], n))       # 全基因组估计后的残余尺度误差
    cn = (2 - g) / 2.0
    cnt = rng.poisson(lam * s * np.maximum(cn, 0))
    x = cnt / (lam * s_hat)
    return x


def em_mixture(x, f0, iters=200):
    mu = np.array([1.0, 0.5, 0.0])
    w = np.array([(1 - f0) ** 2, 2 * f0 * (1 - f0), f0 ** 2])
    sd = np.array([0.15, 0.15, 0.1])
    for _ in range(iters):
        dens = np.stack([w[k] * norm.pdf(x, mu[k], sd[k]) for k in range(3)], axis=1) + 1e-300
        r = dens / dens.sum(1, keepdims=True)
        w = r.mean(0)
        sd = np.sqrt((r * (x[:, None] - mu) ** 2).sum(0) / r.sum(0)).clip(0.03, 0.8)
    return r, w, sd


def power_assoc(dose, y, alpha):
    n = len(y)
    r = np.corrcoef(dose, y)[0, 1]
    z = r * np.sqrt((n - 2) / (1 - r ** 2))
    return abs(z) > norm.isf(alpha / 2), np.cov(dose, y)[0, 1] / dose.var(ddof=1)


def main():
    cfg = json.loads((HERE / "data" / "ex30_18_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n, f = cfg["n"], cfg["freq"]
    res = {}
    print(f"n={n}，缺失频率 {f}，样本尺度 CV {cfg['sample_cv']}，残余尺度误差 {cfg['noise_cv']}")
    print(f"{'深度':>5}{'准确率':>8}{'杂合召回':>9}{'纯合召回':>9}{'Het/HWE':>9}{'斜率衰减':>9}{'功效':>7}")
    for lam in cfg["depths"]:
        acc, rh, rc, ratio, slope, pw = [], [], [], [], [], []
        for _ in range(cfg["reps"]):
            g = rng.binomial(2, f, n)
            x = make_depth(rng, g, lam, cfg)
            post, w, sd = em_mixture(x, f)
            call = post.argmax(1)                                   # 0=无缺失(拷贝2),1=杂合,2=纯缺失
            # 映射：成分 0,1,2 对应缺失拷贝数 0,1,2
            acc.append(np.mean(call == g))
            rh.append(np.mean(call[g == 1] == 1)); rc.append(np.mean(call[g == 0] == 0))
            ratio.append(np.mean(call == 1) / (2 * f * (1 - f)))
            dose = post @ np.array([0, 1, 2.0])
            y = g * cfg["effect_sd"] + rng.normal(0, 1, n)
            sig, b = power_assoc(dose, y, cfg["alpha"]); pw.append(sig)
            slope.append(b / cfg["effect_sd"])
        res[str(lam)] = dict(acc=float(np.mean(acc)), het_recall=float(np.mean(rh)), hom_recall=float(np.mean(rc)),
                             het_ratio=float(np.mean(ratio)), slope_atten=float(np.mean(slope)), power=float(np.mean(pw)))
        r = res[str(lam)]
        print(f"{lam:>5}{r['acc']:>8.3f}{r['het_recall']:>9.3f}{r['hom_recall']:>9.3f}{r['het_ratio']:>9.3f}{r['slope_atten']:>9.3f}{r['power']:>7.2f}")
    # 参照：完美分型与 r²=tag_r² 的标签 SNP
    pw_perfect, pw_tag = [], []
    for _ in range(cfg["reps"]):
        g = rng.binomial(2, f, n); y = g * cfg["effect_sd"] + rng.normal(0, 1, n)
        pw_perfect.append(power_assoc(g.astype(float), y, cfg["alpha"])[0])
        # 标签：与 g 的相关 r=√tag_r²，边缘分布同 g
        z = np.sqrt(cfg["tag_r2"]) * (g - g.mean()) / g.std() + np.sqrt(1 - cfg["tag_r2"]) * rng.normal(0, 1, n)
        pw_tag.append(power_assoc(z, y, cfg["alpha"])[0])
    res["reference"] = dict(perfect=float(np.mean(pw_perfect)), tag=float(np.mean(pw_tag)))
    print(f"\n参考功效：完美分型 {res['reference']['perfect']:.2f}；r²={cfg['tag_r2']} 的标签 SNP {res['reference']['tag']:.2f}")
    ds = [res[str(l)] for l in cfg["depths"]]
    assert all(ds[i]["acc"] < ds[i + 1]["acc"] + 0.01 for i in range(len(ds) - 1)) and ds[-1]["acc"] > ds[0]["acc"] + 0.1
    assert ds[0]["het_recall"] < ds[0]["hom_recall"]
    assert ds[0]["slope_atten"] < ds[-1]["slope_atten"] and ds[-1]["slope_atten"] > 0.9
    assert ds[-1]["power"] >= res["reference"]["tag"] - 0.05
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex30_18_sv_genotyping.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
