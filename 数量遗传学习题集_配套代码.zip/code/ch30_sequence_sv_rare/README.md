# 第30章　全基因组序列、泛基因组、结构变异与稀有变异——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex30_15_genotype_likelihood.py
python3 ex30_16_imputation_hmm.py
python3 ex30_17_rare_variant_tests.py
python3 ex30_18_sv_genotyping.py
python3 ex30_19_panel_coverage.py
python3 ex30_20_carrier_decision.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex30_15_genotype_likelihood.py | 30.15 | 从读段到基因型：似然、先验、后验剂量与低深度的系统性偏差 |
| ex30_16_imputation_hmm.py | 30.16 | 低覆盖测序 + 单倍型参考面板插补（Li–Stephens 隐马尔可夫模型） |
| ex30_17_rare_variant_tests.py | 30.17 | 稀有变异集合检验：单变异、Burden 与 SKAT 的第一类错误与功效 |
| ex30_18_sv_genotyping.py | 30.18 | 结构变异（缺失）的读深度分型：发现 ≠ 可靠分型 |
| ex30_19_panel_coverage.py | 30.19 | 参考面板设计：单倍型覆盖概率、贪心选择与边际收益 |
| ex30_20_carrier_decision.py | 30.20 | 由后验概率到配种风险：隐性有害等位基因携带者的检测与决策价值 |
