#!/usr/bin/env python3
"""习题 30.19  参考面板设计：单倍型覆盖概率、贪心选择与边际收益

群体：n_founders 个祖先个体（2·n_founders 个祖先等位基因标签），gens 代、每代 n_per_gen 头，
每代仅 n_sires 头公畜（有限的父系）、母畜随机，位点自由重组；沿系谱基因下落，记录每个后代每个位点上
两条单倍型所携带的"祖先等位基因标签"。
面板 P 的覆盖度：目标世代个体的单倍型位点（个体×2×位点）中，其祖先标签在面板个体同位点出现过的比例，
即序列信息"至少有一条面板单倍型可拷贝"的概率 coverage(P)。
在候选池（pool_gens 世代的个体）中选 n_P 头构成面板，比较：
  random（随机）、most_offspring（后代数最多）、greedy（贪心最大化覆盖，覆盖函数次模，≥(1−1/e) 最优）。
断言：贪心 ≥ 其它两种；覆盖度随面板规模单调上升且边际收益递减；贪心在小面板下的优势最大。
另报告：贪心边际收益（相邻规模之间每头动物新增的覆盖）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate_pedigree(rng, cfg):
    F, G, N, S, L = cfg["n_founders"], cfg["gens"], cfg["n_per_gen"], cfg["n_sires"], cfg["n_loci"]
    hap = [np.stack([np.arange(F) * 2, np.arange(F) * 2 + 1], axis=1)[:, :, None].repeat(L, 2)]   # (F,2,L) 标签
    parents = [None]
    for g in range(1, G + 1):
        prev = hap[-1]; n_prev = prev.shape[0]
        sire_pool = rng.choice(n_prev, size=min(S, n_prev), replace=False)
        sires = rng.choice(sire_pool, N); dams = rng.integers(0, n_prev, N)
        new = np.empty((N, 2, L), dtype=np.int32)
        for k, par in enumerate((sires, dams)):
            pick = rng.integers(0, 2, (N, L))
            new[:, k] = np.where(pick == 0, prev[par, 0], prev[par, 1])
        hap.append(new); parents.append((sires, dams))
    return hap, parents


def coverage(panel_haps, target_haps):
    """panel_haps: (P,2,L) 标签；target_haps: (T,2,L)。返回覆盖比例。"""
    L = target_haps.shape[2]
    covered = 0; total = 0
    for l in range(L):
        s = set(panel_haps[:, :, l].ravel().tolist())
        t = target_haps[:, :, l].ravel()
        covered += np.isin(t, list(s)).sum(); total += t.size
    return covered / total


def greedy_select(pool, target, k):
    """pool:(C,2,L)；返回选中的索引序列。用布尔矩阵增量计算覆盖。"""
    C, _, L = pool.shape
    labels = int(max(pool.max(), target.max())) + 1
    tgt_count = np.zeros((L, labels))
    for l in range(L):
        tgt_count[l] = np.bincount(target[:, :, l].ravel(), minlength=labels)
    have = np.zeros((L, labels), dtype=bool); chosen = []
    Lidx = np.arange(L)[None, :]
    lab0, lab1 = pool[:, 0, :], pool[:, 1, :]
    dup = lab0 == lab1                                     # 同一个体两条单倍型标签相同时只计一次
    taken = np.zeros(C, dtype=bool)
    for _ in range(k):
        w0 = tgt_count[Lidx, lab0] * ~have[Lidx, lab0]
        w1 = tgt_count[Lidx, lab1] * ~have[Lidx, lab1] * ~dup
        gain = (w0 + w1).sum(1)
        gain[taken] = -1
        bi = int(np.argmax(gain)); taken[bi] = True; chosen.append(bi)
        l_all = np.arange(L)
        have[l_all, lab0[bi]] = True; have[l_all, lab1[bi]] = True
    return chosen


def main():
    cfg = json.loads((HERE / "data" / "ex30_19_config.json").read_text(encoding="utf-8"))
    sizes = cfg["panel_sizes"]; res = {m: {s: [] for s in sizes} for m in ("random", "most_offspring", "greedy")}
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        hap, parents = simulate_pedigree(rng, cfg)
        pool_idx = [(g, i) for g in cfg["pool_gens"] for i in range(hap[g].shape[0])]
        pool = np.stack([hap[g][i] for g, i in pool_idx])
        target = hap[cfg["target_gen"]]
        # 后代数：对 pool 个体统计其在下一代的出现次数
        cnt = np.zeros(len(pool_idx))
        for j, (g, i) in enumerate(pool_idx):
            sires, dams = parents[g + 1]
            cnt[j] = np.sum(sires == i) + np.sum(dams == i)
        kmax = max(sizes)
        gsel = greedy_select(pool, target, kmax)       # 贪心的前缀即各规模的解
        order_mo = np.argsort(-cnt, kind="stable")
        perm = rng.permutation(len(pool_idx))
        for s in sizes:
            res["random"][s].append(coverage(pool[perm[:s]], target))
            res["most_offspring"][s].append(coverage(pool[order_mo[:s]], target))
            res["greedy"][s].append(coverage(pool[gsel[:s]], target))
    tab = {m: {str(s): float(np.mean(v)) for s, v in d.items()} for m, d in res.items()}
    print(f"祖先 {cfg['n_founders']} 人，{cfg['gens']} 代，每代 {cfg['n_per_gen']} 头，公畜 {cfg['n_sires']} 头/代，{cfg['n_loci']} 个位点，重复 {cfg['reps']} 次")
    print(f"{'面板规模':>8}{'随机':>9}{'后代最多':>10}{'贪心':>9}")
    for s in sizes:
        print(f"{s:>8}{tab['random'][str(s)]:>9.3f}{tab['most_offspring'][str(s)]:>10.3f}{tab['greedy'][str(s)]:>9.3f}")
    g = [tab["greedy"][str(s)] for s in sizes]
    marg = [(g[i] - g[i - 1]) / (sizes[i] - sizes[i - 1]) for i in range(1, len(sizes))]
    print("贪心的边际收益（每头动物新增覆盖）：", [round(x, 4) for x in marg])
    for s in sizes:
        assert tab["greedy"][str(s)] >= tab["random"][str(s)] - 1e-9
        assert tab["greedy"][str(s)] >= tab["most_offspring"][str(s)] - 1e-9
    assert all(g[i] < g[i + 1] for i in range(len(g) - 1))
    assert all(marg[i] > marg[i + 1] for i in range(len(marg) - 1))
    adv = [tab["greedy"][str(s)] - tab["random"][str(s)] for s in sizes]
    assert adv[0] > adv[-1]
    print("贪心相对随机的优势：", [round(x, 3) for x in adv])
    tab["marginal"] = marg
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex30_19_panel_coverage.json").write_text(json.dumps(tab, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
