#!/usr/bin/env python3
"""习题 30.16  低覆盖测序 + 单倍型参考面板插补（Li–Stephens 隐马尔可夫模型）

群体：n_founder_hap 条祖先单倍型，面板与目标个体的单倍型都是祖先单倍型的镶嵌体（沿染色体以概率
switch_per_site 切换来源），并有突变噪声 mut_rate，因而存在强 LD。面板为 n_panel 条已定相单倍型。
目标个体为二倍体，位点 k 的读段计数 (d, a)（Poisson 深度，错误率 ε）。
Li–Stephens 二倍体模型：隐状态 (a,b) 为所拷贝的面板单倍型对，转移 α'=TαTᵀ，T=(1−ρ)I+(ρ/H)11ᵀ，
发射 P(读段 | 基因型 = 拷贝等位基因之和)。前向—后向给出每个位点的后验基因型概率与剂量。
对比：（A）无插补的后验剂量（HWE 先验，习题30.15）；（B）HMM 插补剂量；评价指标为剂量与真值的 r²，
按 MAF 分箱与测序深度报告。
断言：插补 r² 在所有深度高于无插补；低深度时增益最大；稀有位点的 r² 低于常见位点。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import binom

HERE = Path(__file__).resolve().parent


def mosaic(rng, founders, n, switch, mut):
    F, L = founders.shape
    out = np.empty((n, L), dtype=np.int8)
    for i in range(n):
        src = rng.integers(F); h = np.empty(L, dtype=np.int8)
        for k in range(L):
            if k > 0 and rng.random() < switch:
                src = rng.integers(F)
            h[k] = founders[src, k]
        flip = rng.random(L) < mut
        out[i] = np.where(flip, 1 - h, h)
    return out


def emission(d, a, eps):
    """返回 (L,3)：P(读段 | g)，g=0,1,2。"""
    qs = np.array([eps, 0.5, 1 - eps])
    return np.stack([binom.pmf(a, d, q) for q in qs], axis=-1)


def forward_backward(panel, em, rho):
    """panel: (H,L) 0/1；em: (L,3)；返回 (L,3) 后验基因型概率。"""
    H, L = panel.shape
    T = (1 - rho) * np.eye(H) + rho / H * np.ones((H, H))
    # 状态发射矩阵 E_k(a,b)=em[k, panel[a,k]+panel[b,k]]
    def E(k):
        s = panel[:, k][:, None] + panel[:, k][None, :]
        return em[k][s]
    alpha = np.empty((L, H, H)); a0 = E(0) / (H * H); alpha[0] = a0 / a0.sum()
    for k in range(1, L):
        x = T @ alpha[k - 1] @ T.T * E(k)
        alpha[k] = x / x.sum()
    beta = np.ones((H, H)); post = np.empty((L, 3))
    for k in range(L - 1, -1, -1):
        w = alpha[k] * beta
        w /= w.sum()
        s = panel[:, k][:, None] + panel[:, k][None, :]
        for g in range(3):
            post[k, g] = w[s == g].sum()
        beta = T @ (beta * E(k)) @ T.T if k > 0 else beta
        beta /= beta.sum()
    return post


def main():
    cfg = json.loads((HERE / "data" / "ex30_16_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); L = cfg["n_sites"]
    founders = (rng.random((cfg["n_founder_hap"], L)) < rng.uniform(0.1, 0.5, L)).astype(np.int8)
    panel = mosaic(rng, founders, cfg["n_panel"], cfg["switch_per_site"], cfg["mut_rate"])
    tgt_h = mosaic(rng, founders, 2 * cfg["n_target"], cfg["switch_per_site"], cfg["mut_rate"])
    g = (tgt_h[0::2] + tgt_h[1::2]).astype(int)               # (n_target, L)
    p = np.clip(panel.mean(0), 0.02, 0.98); maf = np.minimum(p, 1 - p)
    prior = np.stack([(1 - p) ** 2, 2 * p * (1 - p), p ** 2], axis=-1)
    bins = cfg["maf_bins"]
    res = {}
    print(f"面板 {cfg['n_panel']} 条单倍型，目标 {cfg['n_target']} 个体，{L} 个位点，ρ={cfg['rho_hmm']}")
    print(f"{'深度':>5}{'无插补r²':>10}{'HMM r²':>9}" + "".join(f"{'MAF≤'+str(b):>12}" for b in bins))
    for lam in cfg["depths"]:
        dose0 = np.zeros_like(g, dtype=float); dose1 = np.zeros_like(g, dtype=float)
        for i in range(cfg["n_target"]):
            d = rng.poisson(lam, L); q = (g[i] / 2) * (1 - cfg["eps"]) + (1 - g[i] / 2) * cfg["eps"]
            a = rng.binomial(d, q)
            em = emission(d, a, cfg["eps"])
            post0 = em * prior; post0 /= post0.sum(-1, keepdims=True)
            dose0[i] = post0 @ np.array([0, 1, 2.0])
            post1 = forward_backward(panel, em, cfg["rho_hmm"])
            dose1[i] = post1 @ np.array([0, 1, 2.0])
        r2_0 = np.corrcoef(dose0.ravel(), g.ravel())[0, 1] ** 2
        r2_1 = np.corrcoef(dose1.ravel(), g.ravel())[0, 1] ** 2
        by = {}
        for lo, hi in zip([0] + bins[:-1], bins):
            sel = (maf > lo) & (maf <= hi)
            if sel.sum() > 5 and np.var(g[:, sel]) > 0:
                by[f"{hi}"] = float(np.corrcoef(dose1[:, sel].ravel(), g[:, sel].ravel())[0, 1] ** 2)
        res[str(lam)] = dict(r2_noimp=float(r2_0), r2_hmm=float(r2_1), by_maf=by)
        print(f"{lam:>5}{r2_0:>10.3f}{r2_1:>9.3f}" + "".join(f"{by.get(str(b), float('nan')):>12.3f}" for b in bins))
    ds = [res[str(l)] for l in cfg["depths"]]
    assert all(x["r2_hmm"] > x["r2_noimp"] + 0.02 for x in ds)
    gains = [x["r2_hmm"] - x["r2_noimp"] for x in ds]
    assert gains[0] > gains[-1]
    keys = list(ds[1]["by_maf"].keys())
    assert ds[1]["by_maf"][keys[0]] <= ds[1]["by_maf"][keys[-1]] + 0.05
    assert all(ds[i]["r2_hmm"] < ds[i + 1]["r2_hmm"] for i in range(len(ds) - 1))
    print("\n插补带来的 r² 增益（HMM − 无插补）：", [round(x, 3) for x in gains])
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex30_16_imputation_hmm.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
