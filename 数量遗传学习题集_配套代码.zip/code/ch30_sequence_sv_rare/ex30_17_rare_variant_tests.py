#!/usr/bin/env python3
"""习题 30.17  稀有变异集合检验：单变异、Burden 与 SKAT 的第一类错误与功效

一个"基因"含 n_var 个稀有变异（MAF∈maf_range），n 个个体，数量性状 y=Gβ+ε。
检验（零模型无协变量，σ² 由残差估计）：
  单变异：每个变异的得分检验 Z_j=Σ G_ij r_i/(σ√ΣG_ij²)，Bonferroni（n_var 次）；
  Burden：把加权基因型相加 B_i=Σ w_j G_ij，对 B 的得分检验（w_j 为 Beta(1,25) 密度，MAF 越低权重越大）；
  SKAT：Q=Σ_j w_j² (Σ_i G_ij r_i)²/σ²，在 H0 下 Q~Σ λ_k χ²_1，λ 为 W Gᵀ(I−11ᵀ/n)G W 的特征值，
        用 Satterthwaite 两矩近似 aχ²_d 求 p 值。
场景：全部同向致病、一半变异保护（方向相反）、仅 20% 变异致病；每种场景 reps 次，
在 α=0.001 下估计功效；同时在 β=0 下检验第一类错误。
断言：零假设下三种检验的第一类错误（在 α=0.01 下估计）不超过 0.03；同向时 Burden 功效最高；方向混合时 SKAT 功效高于 Burden；
任何场景下集合检验都比 Bonferroni 单变异检验有更高功效。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import beta as beta_dist, chi2, norm

HERE = Path(__file__).resolve().parent


def tests(G, y, w):
    n = len(y)
    r = y - y.mean(); s2 = r @ r / (n - 1)
    Gc = G - G.mean(0)
    score = Gc.T @ r                                   # (m,)
    var_j = (Gc ** 2).sum(0) * s2
    ok = var_j > 0
    z = np.zeros(G.shape[1]); z[ok] = score[ok] / np.sqrt(var_j[ok])
    p_single = 2 * norm.sf(np.abs(z[ok])).min() * ok.sum() if ok.any() else 1.0
    p_single = min(p_single, 1.0)
    # Burden
    B = Gc @ w
    sb = B @ r / np.sqrt((B @ B) * s2) if B @ B > 0 else 0.0
    p_burden = 2 * norm.sf(abs(sb))
    # SKAT
    Q = np.sum((w * score) ** 2) / s2
    K = (Gc * w)
    lam = np.linalg.eigvalsh(K.T @ K)
    lam = lam[lam > 1e-12]
    if len(lam) == 0:
        return p_single, p_burden, 1.0
    a = (lam ** 2).sum() / lam.sum(); d = lam.sum() ** 2 / (lam ** 2).sum()
    p_skat = chi2.sf(Q / a, d)
    return p_single, p_burden, p_skat


def simulate(rng, cfg, frac_causal, frac_prot, beta_eff):
    n, m = cfg["n"], cfg["n_var"]
    maf = rng.uniform(*cfg["maf_range"], m)
    G = rng.binomial(2, maf, size=(n, m)).astype(float)
    eff = np.zeros(m)
    k = int(round(frac_causal * m)); idx = rng.permutation(m)[:k]
    eff[idx] = beta_eff
    kp = int(round(frac_prot * k))
    eff[idx[:kp]] *= -1
    y = G @ eff + rng.normal(0, 1, n)
    w = beta_dist.pdf(maf, *cfg["weight_beta"])
    return G, y, w


def main():
    cfg = json.loads((HERE / "data" / "ex30_17_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); a = cfg["alpha"]; R = cfg["reps"]
    out = {}
    def run(frac_c, frac_p, beff):
        ps = np.array([tests(*(lambda G, y, w: (G, y, w))(*simulate(rng, cfg, frac_c, frac_p, beff))) for _ in range(R)])
        return ps
    # 第一类错误：用较宽松的 α'=0.01 以便在 300 次中可估计
    a_null = 0.01
    ps0 = run(1.0, 0.0, 0.0)
    t1 = (ps0 < a_null).mean(0)
    print(f"第一类错误（α={a_null}，β=0，{R}次）：单变异(Bonferroni) {t1[0]:.3f}，Burden {t1[1]:.3f}，SKAT {t1[2]:.3f}")
    out["type1"] = {"single": float(t1[0]), "burden": float(t1[1]), "skat": float(t1[2]), "alpha": a_null}
    print(f"\n功效（α={a}，n={cfg['n']}，{cfg['n_var']} 个变异，单个效应 {cfg['beta_effect']}σ，MAF {cfg['maf_range']}）")
    print(f"{'场景':<14}{'单变异':>9}{'Burden':>9}{'SKAT':>9}")
    for name, sc in cfg["scenarios"].items():
        ps = run(sc["frac_causal"], sc["frac_protective"], cfg["beta_effect"])
        pw = (ps < a).mean(0)
        out[name] = {"single": float(pw[0]), "burden": float(pw[1]), "skat": float(pw[2])}
        print(f"{name:<14}{pw[0]:>9.3f}{pw[1]:>9.3f}{pw[2]:>9.3f}")
    assert max(t1) < 0.03
    s1, s2, s3 = (out[k] for k in cfg["scenarios"])
    assert s1["burden"] >= s1["skat"] - 0.05 and s1["burden"] > s1["single"]
    assert s2["skat"] > s2["burden"] + 0.2
    for s in (s1, s2, s3):
        assert max(s["burden"], s["skat"]) > s["single"]
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex30_17_rare_variant_tests.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
