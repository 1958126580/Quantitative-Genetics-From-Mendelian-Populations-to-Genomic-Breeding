#!/usr/bin/env python3
"""习题 30.20  由后验概率到配种风险：隐性有害等位基因携带者的检测与决策价值

设定：某隐性致死/致病等位基因，携带者频率 q=carrier_freq（杂合），假定纯合已被淘汰。
公畜经低覆盖测序得到后验携带者概率 π_i（先验 q，二项似然，深度 Poisson(λ)）。
每头公畜配 dams_per_sire 头母畜，母畜携带者概率 q_d。
发病后代期望数：配对风险 r = π_s·q_d/4 每头后代。决策：后验 π_i 超过阈值 τ 的公畜淘汰（损失 cost_discard），
其余使用；发病后代损失 cost_affected。总期望成本 = 发病损失 + 淘汰损失 + 检测费。
比较：（A）不检测（不淘汰）；（B）完美检测（知道真实携带状态）；（C）各深度下的最优阈值 τ*；
同时检查后验校准（π 的分箱 vs 实际携带比例）以及"碰巧不被读到"的假阴性（漏检携带者占比）。
断言：后验校准良好；各深度的最优成本介于完美检测与不检测之间且随深度下降；
最优阈值落在贝叶斯阈值 τ_B=C_dis/(C_aff·E) 附近（与深度无关，深度只改变误淘汰/漏检的数量）；高深度接近完美检测。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import binom

HERE = Path(__file__).resolve().parent


def posterior_carrier(d, a, q, eps):
    l0 = binom.pmf(a, d, eps)            # 非携带者：读到 ALT 概率 ε
    l1 = binom.pmf(a, d, 0.5)            # 携带者：杂合
    return q * l1 / (q * l1 + (1 - q) * l0)


def main():
    cfg = json.loads((HERE / "data" / "ex30_20_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n_sires"]; q = cfg["carrier_freq"]; qd = cfg["dam_carrier_freq"]
    C_aff, C_dis, C_test, D = cfg["cost_affected"], cfg["cost_discard"], cfg["cost_test_per_sire"], cfg["dams_per_sire"]
    carrier = rng.random(n) < q
    # 每头公畜的期望发病后代数（数学期望，避免抽样噪声）：D 头母畜 × 每头后代 q_d/4 × 是否携带
    aff_if_used = D * qd / 4.0
    cost_none = carrier.sum() * aff_if_used * C_aff / n
    cost_perfect = (carrier.sum() * C_dis + C_test * n) / n
    out = {"none": float(cost_none), "perfect": float(cost_perfect)}
    print(f"携带者频率 {q}，公畜 {n}，每头配 {D} 头母畜（母畜携带者频率 {qd}）：每头携带公畜使用的期望发病数 {aff_if_used:.2f}")
    print(f"每头公畜平均成本：不检测 {cost_none:.2f}；完美检测 {cost_perfect:.2f}（淘汰全部携带者+检测费）")
    print(f"\n{'深度':>5}{'漏检携带':>9}{'校准误差':>9}{'τ*':>7}{'成本(τ*)':>10}{'淘汰率':>8}{'非携带误淘汰':>12}")
    best = {}
    for lam in cfg["depths"]:
        d = rng.poisson(lam, n)
        a = rng.binomial(d, np.where(carrier, 0.5, cfg["eps"]))
        pi = posterior_carrier(d, a, q, cfg["eps"])
        # 校准
        edges = [0, 0.02, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0001]
        idx = np.digitize(pi, edges) - 1
        cal = max(abs(pi[idx == b].mean() - carrier[idx == b].mean()) for b in range(len(edges) - 1) if np.sum(idx == b) >= 150)
        costs = {}
        for tau in cfg["thresholds"]:
            disc = pi > tau
            aff = np.sum(carrier & ~disc) * aff_if_used * C_aff / n      # 未被淘汰的携带者造成发病
            costs[tau] = (aff + disc.mean() * C_dis + C_test)            # 淘汰损失按淘汰比例计
        tau_star = min(costs, key=costs.get)
        disc = pi > tau_star
        miss = np.mean(~disc[carrier])
        wrong = np.mean(disc[~carrier])
        best[lam] = dict(tau=tau_star, cost=float(costs[tau_star]), calib=float(cal), miss=float(miss), discard=float(disc.mean()), wrong=float(wrong))
        print(f"{lam:>5}{miss:>9.3f}{cal:>9.3f}{tau_star:>7.2f}{costs[tau_star]:>10.2f}{disc.mean():>8.3f}{wrong:>12.4f}")
    out["by_depth"] = {str(k): v for k, v in best.items()}
    # 检测价值（相对不检测）与相对完美检测的差距
    v = {k: cost_none - b["cost"] for k, b in best.items()}
    print(f"\n检测价值（相对不检测，每头公畜）：" + "；".join(f"{k}x: {x:.2f}" for k, x in v.items()))
    print(f"完美检测的价值：{cost_none - cost_perfect:.2f}")
    ds = [best[l] for l in cfg["depths"]]
    assert max(b["calib"] for b in ds) < 0.06
    assert all(cost_perfect <= b["cost"] <= cost_none + C_test for b in ds)
    assert all(ds[i]["cost"] >= ds[i + 1]["cost"] - 0.3 for i in range(len(ds) - 1))
    tau_bayes = C_dis / (C_aff * aff_if_used)           # 贝叶斯规则：π·(C_aff·E) > C_dis 时淘汰
    print(f"贝叶斯阈值 τ_B = C_dis/(C_aff·E) = {tau_bayes:.3f}；网格上的最优阈值 {[b['tau'] for b in ds]}")
    assert all(0.1 <= b["tau"] <= 0.6 for b in ds) and 0.1 < tau_bayes < 0.6
    assert ds[-1]["cost"] - cost_perfect < 0.6 * (cost_none - cost_perfect)
    out["value"] = {str(k): float(x) for k, x in v.items()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex30_20_carrier_decision.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
