#!/usr/bin/env python3
"""习题 30.15  从读段到基因型：似然、先验、后验剂量与低深度的系统性偏差

模型：个体 i、位点 k 的真实基因型 g∈{0,1,2}（HWE，频率 p_k）；测序深度 d_ik ~ Poisson(λ)（λ 为平均深度）；
每条读段从两个单倍型中等概率抽取，以错误率 ε 读错：P(读到 ALT | g) = (g/2)(1−ε) + (1−g/2)ε。
给定 d 条读段中有 a 条 ALT，似然 L(g)=C(d,a)·q_g^a (1−q_g)^{d−a}。
对每个深度计算：硬判（取最大似然）与后验均值剂量 E[g | 读段, p]（用真实频率作先验）；
指标：硬判错误率、杂合子漏判（读为纯合）比例、剂量与真值的相关 r²、后验方差（不确定性）、
后验校准（后验概率分箱 vs 实际频率），并按 MAF 分箱报告。
断言：深度越高 r² 越高；后验剂量 r² 不低于硬判；低深度硬判系统性漏判杂合子；后验校准误差小。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import binom

HERE = Path(__file__).resolve().parent


def reads(rng, g, lam, eps):
    d = rng.poisson(lam, size=g.shape)
    q = (g / 2) * (1 - eps) + (1 - g / 2) * eps
    a = rng.binomial(d, q)
    return d, a


def posterior(d, a, p, eps):
    """返回 (n,m,3) 后验概率与似然；先验 HWE。"""
    prior = np.stack([(1 - p) ** 2, 2 * p * (1 - p), p ** 2], axis=-1)       # (m,3)
    qs = np.array([eps, 0.5, 1 - eps])
    lik = np.stack([binom.pmf(a, d, q) for q in qs], axis=-1)                  # (n,m,3)
    post = lik * prior[None]
    return post / post.sum(-1, keepdims=True), lik


def main():
    cfg = json.loads((HERE / "data" / "ex30_15_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n, m, eps = cfg["n_ind"], cfg["m"], cfg["error_rate"]
    p = np.clip(rng.beta(*cfg["prior_freq_beta"], m), 0.01, 0.5)
    g = rng.binomial(2, p, size=(n, m))
    bins = cfg["maf_bins"]; res = {}
    print(f"n={n}, m={m}, ε={eps}；先验 HWE 用真实频率；MAF 分箱 {bins}")
    print(f"{'深度':>5}{'硬判错误':>9}{'杂合漏判':>9}{'硬判r²':>8}{'剂量r²':>8}{'后验sd':>8}{'校准误差':>9}")
    for lam in cfg["depths"]:
        d, a = reads(rng, g.astype(float), lam, eps)
        post, lik = posterior(d, a, p, eps)
        # 硬判：最大似然；无读段时取先验众数
        hard = np.where(d == 0, np.round(2 * p)[None].astype(int), lik.argmax(-1))
        dose = post @ np.array([0, 1, 2.0])
        var = post @ np.array([0, 1, 4.0]) - dose ** 2
        err = np.mean(hard != g)
        het = g == 1
        het_miss = np.mean(hard[het] != 1)
        r2h = np.corrcoef(hard.ravel(), g.ravel())[0, 1] ** 2
        r2d = np.corrcoef(dose.ravel(), g.ravel())[0, 1] ** 2
        # 校准：把 P(g=1) 分 10 箱
        p1 = post[..., 1].ravel(); h1 = (g == 1).ravel()
        edges = np.linspace(0, 1, 11); idx = np.clip(np.digitize(p1, edges) - 1, 0, 9)
        cal = max(abs(p1[idx == b].mean() - h1[idx == b].mean()) for b in range(10) if np.sum(idx == b) > 2000)
        res[str(lam)] = dict(hard_err=float(err), het_miss=float(het_miss), r2_hard=float(r2h), r2_dose=float(r2d),
                             post_sd=float(np.sqrt(var.mean())), calib=float(cal))
        maf = np.minimum(p, 1 - p); by = {}
        for lo, hi in zip([0] + bins[:-1], bins):
            sel = (maf > lo) & (maf <= hi)
            if sel.sum() > 5:
                by[f"{lo}-{hi}"] = float(np.corrcoef(dose[:, sel].ravel(), g[:, sel].ravel())[0, 1] ** 2)
        res[str(lam)]["r2_dose_by_maf"] = by
        print(f"{lam:>5}{err:>9.3f}{het_miss:>9.3f}{r2h:>8.3f}{r2d:>8.3f}{np.sqrt(var.mean()):>8.3f}{cal:>9.3f}")
    print("\n按 MAF 分箱的剂量 r²（行：深度）")
    keys = list(res[str(cfg["depths"][0])]["r2_dose_by_maf"].keys())
    print(f"{'深度':>5}" + "".join(f"{k:>12}" for k in keys))
    for lam in cfg["depths"]:
        print(f"{lam:>5}" + "".join(f"{res[str(lam)]['r2_dose_by_maf'][k]:>12.3f}" for k in keys))
    ds = [res[str(l)] for l in cfg["depths"]]
    assert all(ds[i]["r2_dose"] < ds[i + 1]["r2_dose"] for i in range(len(ds) - 1))
    assert all(x["r2_dose"] >= x["r2_hard"] - 1e-9 for x in ds)
    assert ds[1]["het_miss"] > 0.4 and ds[-1]["het_miss"] < 0.05
    assert max(x["calib"] for x in ds) < 0.05
    assert ds[0]["post_sd"] > ds[-1]["post_sd"]
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex30_15_genotype_likelihood.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
