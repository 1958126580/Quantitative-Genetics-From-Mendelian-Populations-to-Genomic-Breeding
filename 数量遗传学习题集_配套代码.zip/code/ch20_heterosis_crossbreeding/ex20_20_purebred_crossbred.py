#!/usr/bin/env python3
"""习题 20.20  纯种与杂种表现的遗传相关 r_pc，以及纯种选择、杂种后裔测验与合并选择的准确度

位点效应：纯种 A 群体中等位基因替代效应 α^P_k = a + d(q_A − p_A)；与 B 品种配子交配后 α^C_k = a + d(q_B − p_B)。
A 群体个体加性遗传值 BV_P = Σ α^P (x − 2p_A)，对杂种表现的育种值 BV_C = Σ α^C (x − 2p_A)。
遗传相关 r_g = cov/√(V_P V_C)，再乘环境（场间 G×E）相关 ρ 得 r_pc。
准确度：候选个体信息 y_P（纯种本身记录）与 n 个杂种后裔均值 ȳ_C，目标 BV_C，用选择指数求准确度，并用
n_cand 个候选个体的基因型—表型模拟检验。
并给出 r_g 随品种分化 F_ST 的变化。
核验：理论 r_g 与个体水平经验相关一致；指数准确度的理论值与模拟值一致。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def make_pop(cfg, fst, rng):
    L = cfg["n_loci"]
    a = rng.normal(0, cfg["a_sd"], L)
    d = rng.normal(cfg["d_mean"], cfg["d_sd"], L)
    p0 = rng.beta(cfg["p_alpha"], cfg["p_beta"], L)
    k = (1 - fst) / fst
    pA = np.clip(rng.beta(p0 * k, (1 - p0) * k), 0.02, 0.98)
    pB = np.clip(rng.beta(p0 * k, (1 - p0) * k), 0.02, 0.98)
    return a, d, pA, pB


def theory(a, d, pA, pB):
    qA, qB = 1 - pA, 1 - pB
    aP = a + d * (qA - pA)
    aC = a + d * (qB - pB)
    w = 2 * pA * qA
    VP, VC, cov = (w * aP ** 2).sum(), (w * aC ** 2).sum(), (w * aP * aC).sum()
    return aP, aC, VP, VC, cov


def index_accuracy(VP, VC, cov, h2P, sd2P, sd2C, n):
    """信息：y_P（方差 sd2P，含 V_P=h2P·sd2P 的加性部分——此处直接以 V_P 与 sd2P 计）；ȳ_C（n 个杂种后裔均值）。"""
    # y_P 与 BV_C 的协方差 cov；ȳ_C 与 BV_C 的协方差 ½V_C；y_P 与 ȳ_C 协方差 ½cov
    if n == 0:
        P = np.array([[sd2P]]); c = np.array([cov])
    else:
        vC = 0.25 * VC + (sd2C - 0.25 * VC) / n
        P = np.array([[sd2P, 0.5 * cov], [0.5 * cov, vC]]); c = np.array([cov, 0.5 * VC])
    b = np.linalg.solve(P, c)
    return float(np.sqrt(c @ b / VC)), b


def simulate(a, d, pA, pB, cfg, n, rng, sd2P, sd2C, VP, VC):
    """个体水平：候选 n_cand 只 A 个体（HWE），产生 n 个杂种后裔（B 配子随机、环境随机），
    返回 y_P、ȳ_C、真 BV_C 的经验相关与指数准确度。"""
    N, L = cfg["n_cand"], len(a)
    x = (rng.random((N, L)) < pA).astype(np.int8) + (rng.random((N, L)) < pA).astype(np.int8)
    aP = a + d * ((1 - pA) - pA); aC = a + d * ((1 - pB) - pB)
    bvP = (x - 2 * pA) @ aP; bvC = (x - 2 * pA) @ aC
    # 纯种表现：BV_P + 其余（显性偏差+环境）使总方差 sd2P
    res_sd = np.sqrt(max(sd2P - VP, 1e-9))
    yP = bvP + rng.normal(0, res_sd, N)
    if n == 0:
        idx = yP; return float(np.corrcoef(idx, bvC)[0, 1]), None
    # 杂种后裔：从 A 亲本传给后裔一个等位基因（随机取亲本两条之一，等价于频率 x/2），B 配子频率 pB
    val = np.empty((N, n))
    step = max(1, 4_000_000 // (n * L))
    for s0 in range(0, N, step):
        sl = slice(s0, min(N, s0 + step))
        m = sl.stop - sl.start
        gA = rng.random((m, n, L)) < (x[sl, None, :] / 2.0)
        gB = rng.random((m, n, L)) < pB
        xc = gA.astype(np.int8) + gB.astype(np.int8)
        val[sl] = np.where(xc == 2, a, np.where(xc == 1, d, -a)).sum(axis=2)
    val = val - val.mean()
    # 加残差使后裔表现方差 ≈ sd2C
    resid_sd = np.sqrt(max(sd2C - val.var(), 1e-9))
    yc = val + rng.normal(0, resid_sd, val.shape)
    ycbar = yc.mean(axis=1)
    X = np.c_[yP, ycbar]; Xc = X - X.mean(0)
    cv = np.cov(Xc.T); cT = np.array([np.cov(Xc[:, 0], bvC)[0, 1], np.cov(Xc[:, 1], bvC)[0, 1]])
    b = np.linalg.solve(cv, cT)
    I = Xc @ b
    return float(np.corrcoef(I, bvC)[0, 1]), b


def main():
    cfg = json.load(open(HERE / "data" / "ex20_20_purecross.json"))
    rng = np.random.default_rng(cfg["seed"])
    out = {"fst_curve": [], "accuracy": []}
    print("=" * 72)
    print("习题 20.20  纯种—杂种表现的遗传相关")
    print("=" * 72)
    # 1. r_g 随 F_ST
    print("F_ST    r_g(理论)  r_g(个体水平)   r_pc(×ρ)")
    for fst in cfg["fst_list"]:
        a, d, pA, pB = make_pop(cfg, fst, rng)
        aP, aC, VP, VC, cov = theory(a, d, pA, pB)
        rg = cov / np.sqrt(VP * VC)
        x = (rng.random((20000, len(a))) < pA).astype(np.int8) + (rng.random((20000, len(a))) < pA).astype(np.int8)
        emp = np.corrcoef((x - 2 * pA) @ aP, (x - 2 * pA) @ aC)[0, 1]
        assert abs(rg - emp) < 0.01, (rg, emp)
        print(f"{fst:5.2f}   {rg:8.4f}    {emp:8.4f}      {rg*cfg['env_genetic_corr']:8.4f}")
        out["fst_curve"].append(dict(fst=fst, rg=float(rg), emp=float(emp)))
    # 2. 指数准确度（F_ST = 0.2）
    fst = 0.2
    a, d, pA, pB = make_pop(cfg, fst, rng)
    aP, aC, VP, VC, cov = theory(a, d, pA, pB)
    rg = cov / np.sqrt(VP * VC)
    # 缩放使纯种加性方差占表型方差 h2_pure
    sc = cfg["h2_pure"] * cfg["var_pheno_pure"] / VP
    VP, VC, cov = VP * sc, VC * sc, cov * sc
    a, d = a * np.sqrt(sc), d * np.sqrt(sc)
    sd2P, sd2C = cfg["var_pheno_pure"], cfg["var_pheno_cross"]
    rho = cfg["env_genetic_corr"]
    print(f"\n缩放后 V_P={VP:.3f}, V_C={VC:.3f}, cov={cov:.3f}, r_g={cov/np.sqrt(VP*VC):.3f}；杂种性状遗传力 h²_C={VC/sd2C:.3f}")
    print("n(杂种后裔数)  准确度(理论)  准确度(模拟)  指数权重(模拟，y_P, ȳ_C)")
    for n in cfg["n_progeny_list"]:
        acc_th, bth = index_accuracy(VP, VC, cov, cfg["h2_pure"], sd2P, sd2C, n)
        acc_sim, bsim = simulate(a, d, pA, pB, cfg, n, rng, sd2P, sd2C, VP, VC)
        assert abs(acc_th - acc_sim) < 0.03, (n, acc_th, acc_sim)
        wtxt = "—" if bsim is None else f"{bsim[0]:.3f}, {bsim[1]:.3f}"
        print(f"{n:6d}          {acc_th:8.4f}     {acc_sim:8.4f}     {wtxt}")
        out["accuracy"].append(dict(n=n, theory=acc_th, sim=acc_sim))
    # 3. 当 r_g=1 时的纯种选择准确度对比
    acc0 = np.sqrt(cfg["h2_pure"])
    print(f"若 r_g=1 且 V_C=V_P，纯种自身记录的准确度 = h = {acc0:.3f}（上限）")
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex20_20_purebred_crossbred.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
