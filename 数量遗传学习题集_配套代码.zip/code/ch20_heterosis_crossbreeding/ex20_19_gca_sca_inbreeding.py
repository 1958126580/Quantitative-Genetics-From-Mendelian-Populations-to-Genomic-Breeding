#!/usr/bin/env python3
"""习题 20.19  配合力方差随亲本近交程度的变化：σ²_GCA = ½F V_A，σ²_SCA = F² V_D

基础群体（随机交配，频率 p_k）经近交程度 F 的分化得到若干系：系的 A1 配子频率 p_ik 的均值 p_k、
方差 F p_k q_k（Balding–Nichols/Beta 分化）。系 i 与 j 杂交的基因型值（无上位）
   G_ij = Σ_k [ a_k (p_ik + p_jk − 1) + d_k (p_ik q_jk + q_ik p_jk) ]。
对 n_lines 个系的全部组合（含 i<j）做方差分析，估计 σ²_GCA、σ²_SCA，并与理论值比较；
重复多次以平均随机抽样误差。核验：F→1 时 σ²_GCA = V_A/2，σ²_SCA = V_D；
并给出 GCA 方差占 (GCA+SCA) 总方差比例随 F 的变化。
"""
from __future__ import annotations
import itertools
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def make_loci(cfg, rng):
    L = cfg["n_loci"]
    a = rng.normal(0, cfg["a_sd"], L)
    d = rng.normal(cfg["d_mean"], cfg["d_sd"], L)
    p = rng.beta(cfg["p_alpha"], cfg["p_beta"], L)
    return a, d, p


def base_VA_VD(a, d, p):
    q = 1 - p
    alpha = a + d * (q - p)
    return float((2 * p * q * alpha ** 2).sum()), float(((2 * p * q * d) ** 2).sum())


def lines_at_F(p, F, n, rng):
    """系配子频率：F=1 时完全固定（Bernoulli(p)）；否则 Beta 分化。"""
    if F >= 1 - 1e-12:
        return (rng.random((n, len(p))) < p).astype(float)
    k = (1 - F) / F
    return rng.beta(p * k, (1 - p) * k, size=(n, len(p)))


def cross_matrix(a, d, P):
    """所有系对的杂交值矩阵 G（对称，不含对角）。"""
    Q = 1 - P
    n = P.shape[0]
    G = (P @ a)[:, None] + (P @ a)[None, :] - a.sum() + (P * d) @ Q.T + (Q * d) @ P.T
    # (P*d)@Q.T[i,j] = Σ d p_ik q_jk ；(Q*d)@P.T[i,j] = Σ d q_ik p_jk
    np.fill_diagonal(G, np.nan)
    return G


def variance_components(G):
    """无重复的对称双列表：σ²_GCA 与 σ²_SCA（σ²_SCA 含 0 误差）。矩估计（方法 4）。"""
    n = G.shape[0]
    iu = np.triu_indices(n, 1)
    y = G[iu]; N = len(y)
    T = np.nansum(G, axis=1)
    tot = y.sum(); mu = tot / N
    gca = T / (n - 2) - 2 * tot / (n * (n - 2))
    fitted = mu + gca[iu[0]] + gca[iu[1]]
    ss_sca = ((y - fitted) ** 2).sum()
    df_sca = n * (n - 3) / 2
    ms_sca = ss_sca / df_sca
    SSg = (n - 2) * (gca ** 2).sum()
    ms_g = SSg / (n - 1)
    # E[MS_g] = σ_s² + (n−2)σ_g²
    sg2 = (ms_g - ms_sca) / (n - 2)
    return float(sg2), float(ms_sca)


def main():
    cfg = json.load(open(HERE / "data" / "ex20_19_gca_sca_F.json"))
    rng = np.random.default_rng(cfg["seed"])
    a, d, p = make_loci(cfg, rng)
    VA, VD = base_VA_VD(a, d, p)
    print("=" * 70)
    print("习题 20.19  配合力方差与近交程度  V_A=%.3f  V_D=%.3f" % (VA, VD))
    print("=" * 70)
    print(f"{'F':>5}{'σ²_GCA 估计':>13}{'½F·V_A':>10}{'σ²_SCA 估计':>13}{'F²·V_D':>10}{'GCA 占比(估)':>13}{'GCA 占比(理)':>13}")
    rows = []
    for F in cfg["F_grid"]:
        sg, ss = [], []
        for _ in range(30):
            P = lines_at_F(p, F, cfg["n_lines"], rng)
            G = cross_matrix(a, d, P)
            g_, s_ = variance_components(G)
            sg.append(g_); ss.append(s_)
        sg, ss = float(np.mean(sg)), float(np.mean(ss))
        tg, ts = 0.5 * F * VA, F ** 2 * VD
        # 总变异中，GCA 占比（以对 (i,j) 的方差：2σ²_g + σ²_s）
        share_est = 2 * sg / (2 * sg + ss); share_th = 2 * tg / (2 * tg + ts)
        print(f"{F:5.2f}{sg:13.4f}{tg:10.4f}{ss:13.4f}{ts:10.4f}{share_est:13.3f}{share_th:13.3f}")
        assert abs(sg - tg) / tg < 0.06 and abs(ss - ts) / ts < 0.10, (F, sg, tg, ss, ts)
        rows.append(dict(F=F, gca=sg, gca_th=tg, sca=ss, sca_th=ts, share_est=share_est, share_th=share_th))
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(dict(VA=VA, VD=VD, rows=rows), open(HERE / "results" / "ex20_19_gca_sca_inbreeding.json", "w"), ensure_ascii=False, indent=1)
    try:
        from _plot import get_pyplot
        plt = get_pyplot()
        if plt:
            Fs = [r["F"] for r in rows]
            fig, ax = plt.subplots(figsize=(6, 3.8))
            ax.plot(Fs, [r["gca"] for r in rows], "o-", label="σ²_GCA 估计"); ax.plot(Fs, [r["gca_th"] for r in rows], "--", label="½F V_A")
            ax.plot(Fs, [r["sca"] for r in rows], "s-", label="σ²_SCA 估计"); ax.plot(Fs, [r["sca_th"] for r in rows], "--", label="F² V_D")
            ax.set_xlabel("亲本系近交系数 F"); ax.legend(); fig.tight_layout(); fig.savefig(HERE / "results" / "ex20_19_gca_sca_inbreeding.png"); plt.close(fig)
    except Exception:
        pass


if __name__ == "__main__":
    main()
