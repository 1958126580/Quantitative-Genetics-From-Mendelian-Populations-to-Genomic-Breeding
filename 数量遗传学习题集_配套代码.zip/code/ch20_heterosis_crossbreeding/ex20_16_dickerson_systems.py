#!/usr/bin/env python3
"""习题 20.16  迪克森模型：杂交体系比较及参数不确定性

后代期望表现 = Σ p_i g_i^I + Σ p_i^M g_i^M + h^I·c_I + h^M·c_M + r^I·c_R，
  p_i      ：后代品种组成；p_i^M：母亲品种组成；
  c_I = 1 − Σ p_i^S p_i^D        （个体杂种优势系数，S 与 D 为父、母品种组成）；
  c_M = 1 − Σ p_i^{DS} p_i^{DD}  （母体杂种优势系数，即母亲自身的杂合程度）；
  c_R = ½[(1−Σ(p_i^S)²) + (1−Σ(p_i^D)²)]（重组损失系数：双亲配子系统的杂合度平均）。
实现：对每个杂交体系递推出（稳态循环平均）的系数向量，再用点估计得期望表现，
并从参数估计的抽样分布（含 h^I 与 h^M 的相关）抽样，评估各体系“利润最大”的概率与期望遗憾。
核验：两品种轮回稳态 c_I=2/3；三品种轮回 6/7；n 品种合成系 c_I = 1−Σp²。
"""
from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


@dataclass
class Animal:
    comp: np.ndarray   # 品种组成
    ps: np.ndarray     # 其父的品种组成
    pd: np.ndarray     # 其母的品种组成


def pure(i, k=3):
    e = np.zeros(k); e[i] = 1
    return Animal(e, e, e)


def mate(sire: Animal, dam: Animal):
    """返回后代 Animal 与其表现系数向量 [gI(3), gM(3), cI, cM, cR]。"""
    child = Animal(0.5 * (sire.comp + dam.comp), sire.comp, dam.comp)
    cI = 1 - sire.comp @ dam.comp
    cM = 1 - dam.ps @ dam.pd
    cR = 0.5 * ((1 - sire.comp @ sire.comp) + (1 - dam.comp @ dam.comp))
    coef = np.r_[child.comp, dam.comp, cI, cM, cR]
    return child, coef


def rotation(order, n_gen=60):
    """轮回杂交：公畜品种按 order 循环，母畜 = 上一代后代。返回最后一个完整周期的系数平均。"""
    dam = pure(order[0])
    coefs = []
    for t in range(n_gen):
        sire = pure(order[t % len(order)])
        child, c = mate(sire, dam)
        coefs.append(c); dam = child
    return np.mean(coefs[-len(order) * 5:], axis=0), np.array(coefs[-len(order):])


def composite(p):
    p = np.asarray(p, float)
    a = Animal(p, p, p)
    # 随机交配的合成系：父母组成均为 p，母亲的双亲亦为 p
    child, c = mate(a, a)
    return c


def build_systems():
    A, B, C = pure(0), pure(1), pure(2)
    S = {}
    S["纯种A"] = mate(A, A)[1]
    S["纯种C"] = mate(C, C)[1]
    S["终端 C×A"] = mate(C, A)[1]
    f1AB, _ = mate(A, B)
    S["三元 C×(A×B)"] = mate(C, f1AB)[1]
    S["两品种轮回(A,C)"] = rotation([0, 2])[0]
    S["三品种轮回(A,B,C)"] = rotation([0, 1, 2])[0]
    S["三品种合成系"] = composite([1 / 3] * 3)
    return S


def main():
    cfg = json.load(open(HERE / "data" / "ex20_16_dickerson.json"))
    rng = np.random.default_rng(cfg["seed"])
    S = build_systems()
    names = list(S)
    X = np.array([S[n] for n in names])

    # ---- 核验：杂种优势保持率 ----
    assert abs(S["两品种轮回(A,C)"][6] - 2 / 3) < 1e-6
    c3 = S["三品种轮回(A,B,C)"][6]
    assert abs(c3 - 6 / 7) < 1e-3, f"三品种轮回 cI={c3}"
    assert abs(S["三品种合成系"][6] - 2 / 3) < 1e-12
    for coef in X:
        assert abs(coef[:3].sum() - 1) < 1e-9 and abs(coef[3:6].sum() - 1) < 1e-9

    mean = np.r_[cfg["g_direct"], cfg["g_maternal"], cfg["h_ind"], cfg["h_mat"], cfg["r_ind"]]
    sd = np.r_[cfg["g_direct_sd"], cfg["g_maternal_sd"], cfg["h_ind_sd"], cfg["h_mat_sd"], cfg["r_ind_sd"]]
    R = np.eye(9); R[6, 7] = R[7, 6] = cfg["corr_hI_hM"]
    Cov = R * np.outer(sd, sd)
    # 无方差参数（A 品种基准）→ 加极小值以便 Cholesky
    L = np.linalg.cholesky(Cov + 1e-12 * np.eye(9))
    draws = mean + rng.standard_normal((cfg["n_draw"], 9)) @ L.T

    cost = np.array([cfg["cost"][n] for n in names])
    perf0 = X @ mean
    profit0 = perf0 - cost
    perf = draws @ X.T
    profit = perf - cost
    best = profit.argmax(axis=1)
    p_best = np.bincount(best, minlength=len(names)) / len(best)
    regret = (profit.max(axis=1, keepdims=True) - profit).mean(axis=0)
    # 解析标准差核验
    sd_an = np.sqrt(np.einsum("ij,jk,ik->i", X, Cov, X))
    assert np.allclose(perf.std(axis=0), sd_an, rtol=0.05, atol=0.02)

    print("=" * 78)
    print("习题 20.16  迪克森模型杂交体系比较")
    print("=" * 78)
    print(f"{'体系':<16}{'c_I':>6}{'c_M':>6}{'c_R':>6}{'表现':>8}{'成本':>6}{'净值':>8}{'SD':>7}{'最优概率':>9}{'期望遗憾':>9}")
    for i, n in enumerate(names):
        print(f"{n:<16}{X[i,6]:6.3f}{X[i,7]:6.3f}{X[i,8]:6.3f}{perf0[i]:8.3f}{cost[i]:6.1f}{profit0[i]:8.3f}{sd_an[i]:7.3f}{p_best[i]:9.3f}{regret[i]:9.3f}")
    # 两体系之差的不确定性：三元 vs 终端
    i3, i2 = names.index("三元 C×(A×B)"), names.index("终端 C×A")
    diff = profit[:, i3] - profit[:, i2]
    print(f"三元−终端 净值差：均值 {diff.mean():.3f}，SD {diff.std():.3f}，P(>0)={np.mean(diff>0):.3f}")
    out = dict(systems=names, coef=X.tolist(), perf=perf0.tolist(), profit=profit0.tolist(), sd=sd_an.tolist(),
               p_best=p_best.tolist(), regret=regret.tolist(), diff_3way_vs_terminal=dict(mean=float(diff.mean()), sd=float(diff.std()), p_pos=float(np.mean(diff > 0))))
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex20_16_dickerson_systems.json", "w"), ensure_ascii=False, indent=1)
    try:
        from _plot import get_pyplot
        plt = get_pyplot()
        if plt:
            fig, ax = plt.subplots(figsize=(7, 3.8))
            ax.errorbar(range(len(names)), profit0, yerr=1.96 * sd_an, fmt="o", capsize=3)
            ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=30, ha="right"); ax.set_ylabel("净值（表现−成本）")
            fig.tight_layout(); fig.savefig(HERE / "results" / "ex20_16_dickerson_systems.png"); plt.close(fig)
    except Exception:
        pass


if __name__ == "__main__":
    main()
