#!/usr/bin/env python3
"""习题 20.15  多位点杂种优势：H(F1)=Σ d_k y_k²，F2 减半，方向性显性的作用

模型：L 个独立位点，基因型值 A1A1=+a, A1A2=d, A2A2=−a。两个品种由同一基础群体分化，
品种 1 与 2 的 A1 频率为 p_k 与 p_k − y_k（Balding–Nichols 分化，F_ST 给定）。
方法：
  1. 解析：M_P1, M_P2, M_F1, M_F2 及中亲杂种优势 H_F1=Σ d y²，H_F2=H_F1/2；
  2. 模拟：按配子随机组合抽取 n 个 F1 与 F2 个体，经验均值与解析值对照；
  3. 反事实：d_k 的符号随机（无方向性显性）时，H 的期望降为 0 左右；
  4. 单位点验证：a=1.2,d=0.9,p1=0.7,p2=0.1 的手算值。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def mean_pop(a, d, p):
    """随机交配群体均值（逐位点）：a(p−q)+2dpq。"""
    q = 1 - p
    return a * (p - q) + 2 * d * p * q


def mean_f1(a, d, p1, p2):
    """两群体配子随机结合的 F1 均值：a(p1+p2−1)+d(p1q2+q1p2)。"""
    return a * (p1 + p2 - 1) + d * (p1 * (1 - p2) + (1 - p1) * p2)


def mean_f2(a, d, p1, p2):
    pb = 0.5 * (p1 + p2)
    return mean_pop(a, d, pb)


def simulate_mean(a, d, g1, g2, n, rng):
    """g1, g2：两个亲本配子的 A1 频率（逐位点）；返回 n 个个体基因型值的均值。"""
    x = (rng.random((n, len(a))) < g1).astype(int) + (rng.random((n, len(a))) < g2).astype(int)
    val = np.where(x == 2, a, np.where(x == 1, d, -a))
    return val.sum(axis=1)


def main():
    cfg = json.load(open(HERE / "data" / "ex20_15_loci.json"))
    rng = np.random.default_rng(cfg["seed"])
    L = cfg["n_loci"]
    a = np.abs(rng.normal(cfg["a_mean"], cfg["a_sd"], L))
    d = rng.normal(cfg["d_mean"], cfg["d_sd"], L)
    p0 = rng.beta(cfg["p_base_alpha"], cfg["p_base_beta"], L)
    f = cfg["fst"]; k = (1 - f) / f
    p1 = rng.beta(p0 * k, (1 - p0) * k); p2 = rng.beta(p0 * k, (1 - p0) * k)
    y = p1 - p2

    out = {}
    M1, M2 = mean_pop(a, d, p1).sum(), mean_pop(a, d, p2).sum()
    MF1, MF2 = mean_f1(a, d, p1, p2).sum(), mean_f2(a, d, p1, p2).sum()
    H1, H2 = MF1 - 0.5 * (M1 + M2), MF2 - 0.5 * (M1 + M2)
    Hform = float((d * y ** 2).sum())
    assert abs(H1 - Hform) < 1e-9, "H_F1 = Σ d y² 恒等式失败"
    assert abs(H2 - 0.5 * Hform) < 1e-9, "H_F2 = H_F1/2 失败"

    n = cfg["n_f2"]
    sim_f1 = simulate_mean(a, d, p1, p2, n, rng).mean()
    pb = 0.5 * (p1 + p2)
    sim_f2 = simulate_mean(a, d, pb, pb, n, rng).mean()
    se = simulate_mean(a, d, p1, p2, n, rng).std() / np.sqrt(n)
    assert abs(sim_f1 - MF1) < 5 * se and abs(sim_f2 - MF2) < 5 * se

    # 反事实：随机翻转 d 的符号 → 无方向性显性
    Hs = []
    for _ in range(400):
        s = rng.choice([-1, 1], L)
        Hs.append(float((s * d * y ** 2).sum()))
    Hs = np.array(Hs)

    # 同一 d、y 下杂种优势与 F_ST 的关系（|y| 平方的均值）
    sl = cfg["single_locus"]
    a_, d_, q1, q2 = sl["a"], sl["d"], sl["p1"], sl["p2"]
    sm = dict(M1=float(mean_pop(a_, d_, q1)), M2=float(mean_pop(a_, d_, q2)),
              MF1=float(mean_f1(a_, d_, q1, q2)), MF2=float(mean_f2(a_, d_, q1, q2)))
    sm["H1"] = sm["MF1"] - 0.5 * (sm["M1"] + sm["M2"]); sm["H2"] = sm["MF2"] - 0.5 * (sm["M1"] + sm["M2"])
    assert abs(sm["H1"] - d_ * (q1 - q2) ** 2) < 1e-12

    pos = (d > 0).mean()
    print("=" * 66)
    print("习题 20.15  多位点杂种优势  （L=%d, F_ST=%.2f）" % (L, f))
    print("=" * 66)
    print(f"品种1均值 {M1:8.3f}   品种2均值 {M2:8.3f}   中亲值 {0.5*(M1+M2):8.3f}")
    print(f"F1 均值   {MF1:8.3f}   F2 均值   {MF2:8.3f}")
    print(f"H(F1) = {H1:7.4f}（Σ d y² = {Hform:7.4f}）   H(F2) = {H2:7.4f}（= H(F1)/2）")
    print(f"模拟 F1 均值 {sim_f1:8.3f}  F2 均值 {sim_f2:8.3f}  （MC 标准误 {se:.3f}）")
    print(f"d>0 的位点占比 {pos:.2f}；反事实（d 符号随机）H 均值 {Hs.mean():.4f}，SD {Hs.std():.4f}")
    print("单位点 a=1.2,d=0.9,p1=0.7,p2=0.1：", {k_: round(v, 4) for k_, v in sm.items()})
    out = dict(M1=M1, M2=M2, MF1=MF1, MF2=MF2, H_F1=H1, H_F2=H2, sum_d_y2=Hform,
               sim_F1=float(sim_f1), sim_F2=float(sim_f2), mc_se=float(se),
               counterfactual_mean=float(Hs.mean()), counterfactual_sd=float(Hs.std()),
               frac_positive_d=float(pos), single_locus=sm)
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex20_15_heterosis_loci.json", "w"), ensure_ascii=False, indent=1)
    try:
        from _plot import get_pyplot
        plt = get_pyplot()
        if plt:
            fig, ax = plt.subplots(1, 2, figsize=(9, 3.6))
            ax[0].scatter(y ** 2, d, s=8, c=np.where(d > 0, "C0", "C3")); ax[0].set_xlabel("频率差平方 y²"); ax[0].set_ylabel("显性效应 d")
            ax[1].hist(Hs, bins=30, color="C7"); ax[1].axvline(Hform, color="C3"); ax[1].set_xlabel("H（d 符号随机化）")
            fig.tight_layout(); fig.savefig(HERE / "results" / "ex20_15_heterosis_loci.png"); plt.close(fig)
    except Exception:
        pass


if __name__ == "__main__":
    main()
