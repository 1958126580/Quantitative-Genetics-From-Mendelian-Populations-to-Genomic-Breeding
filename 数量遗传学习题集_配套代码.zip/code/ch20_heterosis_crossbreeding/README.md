# 第20章　杂种优势、配合力与杂交育种体系——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex20_15_heterosis_loci.py
python3 ex20_16_dickerson_systems.py
python3 ex20_17_rotation_retention.py
python3 ex20_18_diallel_gca_sca.py
python3 ex20_19_gca_sca_inbreeding.py
python3 ex20_20_purebred_crossbred.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex20_15_heterosis_loci.py | 20.15 | 多位点杂种优势：H(F1)=Σ d_k y_k²，F2 减半，方向性显性的作用 |
| ex20_16_dickerson_systems.py | 20.16 | 迪克森模型：杂交体系比较及参数不确定性 |
| ex20_17_rotation_retention.py | 20.17 | 轮回杂交与合成系中杂种优势的保持：递推、解析与个体水平模拟 |
| ex20_18_diallel_gca_sca.py | 20.18 | 不含自交与反交的双列杂交（Griffing 方法 4）：GCA/SCA 估计与方差分析 |
| ex20_19_gca_sca_inbreeding.py | 20.19 | 配合力方差随亲本近交程度的变化：σ²_GCA = ½F V_A，σ²_SCA = F² V_D |
| ex20_20_purebred_crossbred.py | 20.20 | 纯种与杂种表现的遗传相关 r_pc，以及纯种选择、杂种后裔测验与合并选择的准确度 |
