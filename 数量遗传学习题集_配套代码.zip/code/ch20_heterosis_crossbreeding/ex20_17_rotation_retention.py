#!/usr/bin/env python3
"""习题 20.17  轮回杂交与合成系中杂种优势的保持：递推、解析与个体水平模拟

1. 递推：n 品种轮回杂交中，设第 t 代母畜品种组成向量 x_t（公畜品种循环 1→2→…→n），
   后代组成 x_{t+1} = (e_{s(t)} + x_t)/2，个体杂种优势系数 c_t = 1 − x_t[s(t)]。
   稳态周期平均 c̄ = (2^n − 2)/(2^n − 1)。输出逐代 c_t 曲线与稳态值。
2. 个体水平验证：用 L 个独立位点上的基因来源（品种标记）追踪每个个体的“杂合来源”比例
   （个体两个等位基因来自不同品种的位点比例），逐代随机配种模拟，其均值与递推吻合。
3. 合成系：n 个品种等比例建系，随机交配，杂合来源比例由 1−1/n 起，对 F1 无意义；给出 1−Σp² 与
   个体水平模拟，并给出 F2 与 F∞ 的保持率（F2 为 1−Σp²，之后不再变化）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def rotation_recursion(n, n_gen):
    x = np.zeros(n); x[0] = 1.0   # 初始母畜为品种 1 纯种
    cs, comps = [], []
    for t in range(n_gen):
        s = (t + 1) % n
        c = 1 - x[s]
        e = np.zeros(n); e[s] = 1
        x = 0.5 * (e + x)
        cs.append(c); comps.append(x.copy())
    return np.array(cs), np.array(comps)


def rotation_simulation(n, n_gen, n_an, L, rng):
    """个体水平：每个动物 2×L 个等位基因的品种来源标签；母畜给出的配子 = 随机选一条染色体来源（位点独立），
    公畜为纯种品种 s。"""
    dam = np.zeros((n_an, L, 2), int)  # 初始母畜：品种 0 纯种
    res = []
    for t in range(n_gen):
        s = (t + 1) % n
        # 母畜配子：每个位点独立随机取母本两条中之一
        pick = rng.integers(0, 2, (n_an, L))
        dgam = np.take_along_axis(dam, pick[..., None], axis=2)[..., 0]
        # 随机配母畜（打乱个体，模拟不同母畜）
        dgam = dgam[rng.permutation(n_an)]
        child = np.stack([np.full((n_an, L), s), dgam], axis=2)
        res.append(float(np.mean(child[..., 0] != child[..., 1])))
        # 下一代母畜（雌性占一半，此处视为全部可作母畜以保持样本量）
        dam = child
    return np.array(res)


def synthetic(k, n_an, L, rng, n_gen=6):
    """k 个品种等比例，随机交配 n_gen 代；记录来源杂合度。"""
    base = np.repeat(np.arange(k), n_an // k)
    n = len(base)
    pop = np.stack([np.tile(base[:, None], (1, L)), np.tile(base[:, None], (1, L))], axis=2)
    het = []
    for g in range(n_gen):
        # 配子：随机亲本、随机染色体
        def gam():
            ind = rng.integers(0, n, n)
            pick = rng.integers(0, 2, (n, L))
            return np.take_along_axis(pop[ind], pick[..., None], axis=2)[..., 0]
        pop = np.stack([gam(), gam()], axis=2)
        het.append(float(np.mean(pop[..., 0] != pop[..., 1])))
    return np.array(het)


def main():
    cfg = json.load(open(HERE / "data" / "ex20_17_rotation.json"))
    rng = np.random.default_rng(cfg["seed"])
    out = {"rotation": {}, "synthetic": {}}
    print("=" * 72)
    print("习题 20.17  轮回杂交与合成系的杂种优势保持")
    print("=" * 72)
    print("n  稳态(递推)  理论(2^n−2)/(2^n−1)  模拟最后一周期平均   逐代 c_t（前8代）")
    for n in cfg["n_breeds_list"]:
        cs, comps = rotation_recursion(n, cfg["n_gen"])
        stat = cs[-n:].mean()
        theory = (2 ** n - 2) / (2 ** n - 1)
        sim = rotation_simulation(n, cfg["n_gen"], cfg["n_animals"], cfg["n_loci"], rng)
        simst = sim[-n:].mean()
        assert abs(stat - theory) < 2e-3, (n, stat, theory)
        assert abs(simst - theory) < 0.02, (n, simst, theory)
        assert np.max(np.abs(sim - cs)) < 0.02
        print(f"{n}  {stat:9.4f}   {theory:12.4f}        {simst:10.4f}        " + " ".join(f"{c:.3f}" for c in cs[:8]))
        out["rotation"][str(n)] = dict(stationary=float(stat), theory=theory, simulated=float(simst), c_t=cs.tolist(), sim_t=sim.tolist())
    print("\n合成系：k  理论 1−Σp²  第 1—6 代随机交配的来源杂合度（模拟）")
    for k in cfg["synthetic_k"]:
        n_an = (cfg["n_animals"] // k) * k
        het = synthetic(k, n_an, cfg["n_loci"], rng)
        th = 1 - 1 / k
        # 第 1 代随机交配后：来源杂合度应为 1−1/k，之后保持
        assert abs(het[1:].mean() - th) < 0.015, (k, het)
        print(f"  {k}  {th:.4f}             " + " ".join(f"{h:.3f}" for h in het))
        out["synthetic"][str(k)] = dict(theory=th, sim=het.tolist())
    # 不等比例合成系
    p = np.array([0.5, 0.3, 0.2]); th = 1 - (p ** 2).sum()
    print(f"不等比例合成系 (0.5,0.3,0.2) 的保持率 1−Σp² = {th:.3f}")
    out["unequal_example"] = th
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex20_17_rotation_retention.json", "w"), ensure_ascii=False, indent=1)
    try:
        from _plot import get_pyplot
        plt = get_pyplot()
        if plt:
            fig, ax = plt.subplots(figsize=(6.5, 3.8))
            for n in cfg["n_breeds_list"]:
                ax.plot(range(1, cfg["n_gen"] + 1), out["rotation"][str(n)]["c_t"], marker="o", ms=3, label=f"{n} 品种")
            ax.set_xlabel("世代"); ax.set_ylabel("个体杂种优势系数"); ax.legend(); fig.tight_layout()
            fig.savefig(HERE / "results" / "ex20_17_rotation_retention.png"); plt.close(fig)
    except Exception:
        pass


if __name__ == "__main__":
    main()
