#!/usr/bin/env python3
"""习题 20.18  不含自交与反交的双列杂交（Griffing 方法 4）：GCA/SCA 估计与方差分析

模型  y_ij = μ + g_i + g_j + s_ij + e_ij  （i<j），约束 Σ g = 0，Σ_j s_ij = 0。
1. 对给定 6 系 15 组合观测值：GCA^_i = T_i/(n−2) − 2T/(n(n−2))，SCA^_ij = y_ij − ȳ.. − GCA_i − GCA_j（单次观测）；
   并用一般线性模型最小二乘（设计矩阵+约束）验证与公式解一致；方差分析（GCA 与 SCA 平方和）。
2. 模拟 n=8 系、真实 σ_g=2, σ_s=1.2, σ_e=2：重复 n_rep 次，报告 GCA^ 与真值的相关、
   SCA 的方差分量估计、最优组合是否由 GCA 最高两系组成的概率，及以 GCA 预测组合表现的 R²。
3. 核验：Σ GCA^ = 0；SS 分解相加；对 SCA 的 Σ_j SCA_ij = 0。
"""
from __future__ import annotations
import itertools
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def pairs(n):
    return list(itertools.combinations(range(n), 2))


def gca_sca(n, y, prs):
    """y 对应 prs 的组合观测值；返回 μ^, GCA^, SCA^。"""
    T = np.zeros(n)
    for (i, j), v in zip(prs, y):
        T[i] += v; T[j] += v
    tot = y.sum()
    gca = T / (n - 2) - 2 * tot / (n * (n - 2))
    mu = tot / len(prs)
    sca = np.array([v - mu - gca[i] - gca[j] for (i, j), v in zip(prs, y)])
    return mu, gca, sca


def design(n, prs):
    """加性设计矩阵 X：μ + Σ g_i（g_i 被约束 Σ g=0，用 GLS/最小二乘加约束行实现）。"""
    X = np.zeros((len(prs), n + 1)); X[:, 0] = 1
    for r, (i, j) in enumerate(prs):
        X[r, 1 + i] = 1; X[r, 1 + j] = 1
    return X


def lsq_gca(n, y, prs):
    X = design(n, prs)
    Xc = np.vstack([X, np.r_[0, np.ones(n)] * 1e3])   # 约束 Σ g=0（罚行）
    yc = np.r_[y, 0.0]
    beta = np.linalg.lstsq(Xc, yc, rcond=None)[0]
    return beta[0], beta[1:]


def anova(n, y, prs, mu, gca):
    N = len(prs)
    ss_tot = ((y - mu) ** 2).sum()
    fitted = np.array([mu + gca[i] + gca[j] for i, j in prs])
    ss_gca = ((fitted - mu) ** 2).sum()
    ss_sca = ((y - fitted) ** 2).sum()
    assert abs(ss_tot - ss_gca - ss_sca) < 1e-8
    df_gca, df_sca = n - 1, n * (n - 3) // 2
    return dict(ss_gca=ss_gca, ss_sca=ss_sca, df_gca=df_gca, df_sca=df_sca,
                ms_gca=ss_gca / df_gca, ms_sca=ss_sca / df_sca, F=(ss_gca / df_gca) / (ss_sca / df_sca))


def main():
    cfg = json.load(open(HERE / "data" / "ex20_18_diallel.json"))
    rng = np.random.default_rng(cfg["seed"])
    ex = cfg["observed_example"]; lines = ex["lines"]; n = len(lines)
    prs = pairs(n)
    y = np.array([ex["values"][lines[i] + lines[j]] for i, j in prs])
    mu, gca, sca = gca_sca(n, y, prs)
    mu2, gca2 = lsq_gca(n, y, prs)
    assert abs(gca.sum()) < 1e-9 and np.allclose(gca, gca2, atol=2e-3) and abs(mu - mu2) < 1e-3
    for i in range(n):
        s = sum(sca[r] for r, (a, b) in enumerate(prs) if i in (a, b))
        assert abs(s) < 1e-9, "每系 SCA 之和应为 0"
    an = anova(n, y, prs, mu, gca)
    print("=" * 70)
    print("习题 20.18  双列杂交（方法4）GCA/SCA")
    print("=" * 70)
    print(f"总平均 μ = {mu:.3f}")
    print("GCA：" + "  ".join(f"{lines[i]} {gca[i]:+.3f}" for i in range(n)))
    top = np.argsort(-sca)[:3]
    print("SCA 最大的三个组合：" + "；".join(f"{lines[prs[r][0]]}{lines[prs[r][1]]} {sca[r]:+.2f}" for r in top))
    best = int(np.argmax(y))
    print(f"观测值最高组合 {lines[prs[best][0]]}{lines[prs[best][1]]} = {y[best]:.1f}；GCA 最高两系 {lines[np.argsort(-gca)[0]]},{lines[np.argsort(-gca)[1]]}")
    print(f"方差分析：SS_GCA={an['ss_gca']:.2f}(df {an['df_gca']})  SS_SCA={an['ss_sca']:.2f}(df {an['df_sca']})  F={an['F']:.2f}")

    # ---------- 模拟 ----------
    N = cfg["n_lines"]; prs8 = pairs(N); Rn = cfg["n_rep"]
    rg, rs, hit_best, r2, var_sca_hat, top2 = [], [], [], [], [], []
    for _ in range(Rn):
        g = rng.normal(0, cfg["sd_gca"], N); g -= g.mean()
        s = rng.normal(0, cfg["sd_sca"], len(prs8))
        yy = np.array([cfg["mu"] + g[i] + g[j] + s[r] for r, (i, j) in enumerate(prs8)]) + rng.normal(0, cfg["sd_err"], len(prs8))
        m_, gh, sh = gca_sca(N, yy, prs8)
        rg.append(np.corrcoef(g, gh)[0, 1])
        true_comb = np.array([g[i] + g[j] + s[r] for r, (i, j) in enumerate(prs8)])
        pred = np.array([gh[i] + gh[j] for i, j in prs8])
        r2.append(np.corrcoef(true_comb, pred)[0, 1] ** 2)
        tb = np.argmax(true_comb)
        hit_best.append(prs8[tb] == tuple(sorted(np.argsort(-gh)[:2])))
        top2.append(tb in np.argsort(-pred)[:3])
        a = anova(N, yy, prs8, m_, gh)
        # 方差分量：σ_s²+σ_e² = MS_SCA ，E[MS_GCA]=σ_e²+σ_s²+(N−2)σ_g²
        var_sca_hat.append(a["ms_sca"])
    exp_ms_sca = cfg["sd_sca"] ** 2 + cfg["sd_err"] ** 2
    print("\n模拟 n=%d 系（σ_g=%.1f, σ_s=%.1f, σ_e=%.1f），%d 次重复：" % (N, cfg["sd_gca"], cfg["sd_sca"], cfg["sd_err"], Rn))
    print(f"  GCA^ 与真 GCA 的平均相关 {np.mean(rg):.3f}")
    print(f"  以 GCA 之和预测真实组合值的平均 R² = {np.mean(r2):.3f}")
    print(f"  真最佳组合恰为 GCA^ 最高两系的概率 {np.mean(hit_best):.3f}；在预测前三名内的概率 {np.mean(top2):.3f}")
    print(f"  MS_SCA 平均 {np.mean(var_sca_hat):.3f}（理论 σ_s²+σ_e² = {exp_ms_sca:.3f}）")
    assert abs(np.mean(var_sca_hat) - exp_ms_sca) / exp_ms_sca < 0.05
    out = dict(mu=float(mu), gca=dict(zip(lines, map(float, gca))), anova=an,
               sim=dict(mean_corr_gca=float(np.mean(rg)), mean_r2=float(np.mean(r2)), p_best_is_top2=float(np.mean(hit_best)),
                        p_best_in_top3=float(np.mean(top2)), ms_sca_mean=float(np.mean(var_sca_hat))))
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex20_18_diallel_gca_sca.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
