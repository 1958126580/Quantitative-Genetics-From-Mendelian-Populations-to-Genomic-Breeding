# 第37章　模型诊断、失败分析与可检验的研究设计——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex37_15_residual_dependence.py
python3 ex37_16_high_cor_miscalibrated.py
python3 ex37_17_negative_control_leakage.py
python3 ex37_18_variance_boundary.py
python3 ex37_19_nonnormal_robust.py
python3 ex37_20_power_precision_cluster.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex37_15_residual_dependence.py | 37.15 | 残差经过拟合以后为何不再独立：条件残差的协方差与学生化 |
| ex37_16_high_cor_miscalibrated.py | 37.16 | 相关很高仍可能严重失准：对预测作线性变换，相关不变而校准崩塌 |
| ex37_17_negative_control_leakage.py | 37.17 | 无信号负对照揭示预处理泄漏 |
| ex37_18_variance_boundary.py | 37.18 | 方差分量落在边界：弱信息下的 REML 估计、零估计的频率与后果 |
| ex37_19_nonnormal_robust.py | 37.19 | 非高斯残差与极端值：BLUP 的敏感性与 t 残差（IRLS）稳健化 |
| ex37_20_power_precision_cluster.py | 37.20 | 研究功效、蒙特卡洛精度、等效性与相关验证个体的标准误 |
