#!/usr/bin/env python3
"""习题 37.19  非高斯残差与极端值：BLUP 的敏感性与 t 残差（IRLS）稳健化

GBLUP（80 只候选，训练 200 只）。三种表型残差：高斯；5% 记录被污染（加 ±outlier_mag·σe）；t₃ 残差（方差与高斯相同）。
方法：(a) BLUP（高斯似然）；(b) 学生化残差 |z|>3 的记录先删除再 BLUP；(c) t 似然的 IRLS：
    权重 w_i=(ν+1)/(ν+r_i²/σe²)，残差方差 σe²/w_i，r_i 为条件残差，迭代至收敛（ν=robust_df）。
另：单个异常记录（+single_outlier·σe）对该个体及其同父半同胞 EBV 的影响（BLUP vs t-IRLS）。
断言：高斯数据下 t-IRLS 的相关与 BLUP 相差 <0.01；污染数据下 IRLS 的相关比 BLUP 高 >0.04，RMSE 更低；
t₃ 残差下 IRLS 不低于 BLUP；污染下删除法优于 BLUP 但不优于 IRLS（容差 0.01）；
单个异常使 BLUP 的该个体 EBV 变化 >IRLS 的 2 倍以上。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _sim import simulate, vanraden_G, split

HERE = Path(__file__).resolve().parent


def blup_w(K, train, cand, y, sa2, se_vec):
    Ktt = K[np.ix_(train, train)]; Kct = K[np.ix_(cand, train)]
    V = sa2 * Ktt + np.diag(se_vec); Vi = np.linalg.inv(V); one = np.ones(len(train))
    mu = (one @ Vi @ y[train]) / (one @ Vi @ one)
    return sa2 * Kct @ Vi @ (y[train] - mu), mu


def irls(K, train, cand, y, sa2, se2, nu, iters):
    w = np.ones(len(train))
    for _ in range(iters):
        uh_all, mu = blup_w(K, train, np.arange(K.shape[0]), y, sa2, se2 / w)
        r = y[train] - mu - uh_all[train]
        w_new = (nu + 1) / (nu + r ** 2 / se2)
        if np.max(np.abs(w_new - w)) < 1e-8: w = w_new; break
        w = w_new
    uh, _ = blup_w(K, train, cand, y, sa2, se2 / w)
    return uh, w


def studentized_delete(K, train, cand, y, sa2, se2):
    n = len(train); Ktt = K[np.ix_(train, train)]; V = sa2 * Ktt + se2 * np.eye(n); Vi = np.linalg.inv(V); one = np.ones(n)
    P = Vi - np.outer(Vi @ one, Vi @ one) / (one @ Vi @ one)
    r = se2 * P @ y[train]; h = 1 - se2 * np.diag(P); z = r / np.sqrt(se2 * (1 - h))
    keep = np.abs(z) <= 3
    uh, _ = blup_w(K, train[keep], cand, y, sa2, np.full(keep.sum(), se2))
    return uh, int((~keep).sum())


def main():
    cfg = json.loads((HERE / "data" / "ex37_19_config.json").read_text(encoding="utf-8"))
    names = ["高斯", "5%污染", "t₃"]; ms = ["BLUP", "删除法", "t-IRLS"]
    R = {n: {m: [] for m in ms} for n in names}; E = {n: {m: [] for m in ms} for n in names}; ndel = {n: [] for n in names}; wmin = {n: [] for n in names}
    infl = dict(blup=[], rob=[], blup_sib=[], rob_sib=[])
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
        train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"]); G = vanraden_G(d["Z"], d["p"])
        sa2, se2 = d["sa2"], d["se2"]; u = d["u"][cand]; clean_e = d["y"] - d["u"]
        ys = {"高斯": d["y"]}
        yc = d["y"].copy(); mask = rng.random(len(yc)) < cfg["outlier_frac"]; yc[mask] += rng.choice([-1, 1], mask.sum()) * cfg["outlier_mag"] * np.sqrt(se2); ys["5%污染"] = yc
        te = rng.standard_t(cfg["t_df"], len(yc)) * np.sqrt(se2 * (cfg["t_df"] - 2) / cfg["t_df"]); ys["t₃"] = d["u"] + te
        for n in names:
            y = ys[n]
            uh, _ = blup_w(G, train, cand, y, sa2, np.full(len(train), se2))
            ud, nd = studentized_delete(G, train, cand, y, sa2, se2)
            ur, w = irls(G, train, cand, y, sa2, se2, cfg["robust_df"], cfg["irls_iter"])
            for m, e in zip(ms, (uh, ud, ur)):
                R[n][m].append(np.corrcoef(e, u)[0, 1]); E[n][m].append(np.sqrt(np.mean((e - u) ** 2)))
            ndel[n].append(nd); wmin[n].append(w.min())
        # 单个异常
        j = train[-1]; y1 = d["y"].copy(); y1[j] += cfg["single_outlier"] * np.sqrt(se2)
        a0, _ = blup_w(G, train, train, d["y"], sa2, np.full(len(train), se2)); a1, _ = blup_w(G, train, train, y1, sa2, np.full(len(train), se2))
        sibs = [t for t in train if t != j and d["sire"][t] == d["sire"][j] and d["sire"][j] >= 0]
        pos = {t: i for i, t in enumerate(train)}
        r0, _ = irls(G, train, train, d["y"], sa2, se2, cfg["robust_df"], cfg["irls_iter"]); r1, _ = irls(G, train, train, y1, sa2, se2, cfg["robust_df"], cfg["irls_iter"])
        infl["blup"].append(abs(a1[pos[j]] - a0[pos[j]])); infl["rob"].append(abs(r1[pos[j]] - r0[pos[j]]))
        if sibs:
            infl["blup_sib"].append(np.mean([abs(a1[pos[t]] - a0[pos[t]]) for t in sibs])); infl["rob_sib"].append(np.mean([abs(r1[pos[t]] - r0[pos[t]]) for t in sibs]))
    print(f"重复 {cfg['reps']} 次；GBLUP；ν={cfg['robust_df']}（t-IRLS）")
    print(f"{'残差类型':<8}" + "".join(f"{m+' r':>10}{m+' RMSE':>12}" for m in ms) + f"{'删除数':>8}{'最小权重':>9}")
    out = {}
    for n in names:
        print(f"{n:<8}" + "".join(f"{np.mean(R[n][m]):>10.3f}{np.mean(E[n][m]):>12.3f}" for m in ms) + f"{np.mean(ndel[n]):>8.1f}{np.mean(wmin[n]):>9.3f}")
        out[n] = {m: dict(r=float(np.mean(R[n][m])), rmse=float(np.mean(E[n][m]))) for m in ms}
    print(f"\n单个异常（+{cfg['single_outlier']}σe）使该个体 EBV 变化：BLUP {np.mean(infl['blup']):.3f}，t-IRLS {np.mean(infl['rob']):.3f}；同父半同胞平均变化：BLUP {np.mean(infl['blup_sib']):.3f}，t-IRLS {np.mean(infl['rob_sib']):.3f}")
    out["single"] = {k: float(np.mean(v)) for k, v in infl.items()}
    M = lambda n, m: np.mean(R[n][m])
    assert abs(M("高斯", "t-IRLS") - M("高斯", "BLUP")) < 0.01
    assert M("5%污染", "t-IRLS") > M("5%污染", "BLUP") + 0.04 and np.mean(E["5%污染"]["t-IRLS"]) < np.mean(E["5%污染"]["BLUP"])
    assert M("t₃", "t-IRLS") >= M("t₃", "BLUP") - 1e-9
    assert M("5%污染", "删除法") > M("5%污染", "BLUP") and M("5%污染", "删除法") <= M("5%污染", "t-IRLS") + 0.01
    assert np.mean(infl["blup"]) > 2 * np.mean(infl["rob"])
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex37_19_nonnormal_robust.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
