#!/usr/bin/env python3
"""习题 37.20  研究功效、蒙特卡洛精度、等效性与相关验证个体的标准误

A. 规划（以 G−A 的成对相关差为例）。先用 pilot_reps 次重复估计成对差的标准差 σ_d（习题 35.15 的模拟器）。分别规划：
  (1) 精度：95% 区间半宽 ≤ halfwidth 所需重复数 n₁=⌈(1.96σ_d/halfwidth)²⌉；
  (2) 功效：检出真差 δ（双侧 α，功效 power）：n₂=⌈((z_{1−α/2}+z_{power})σ_d/δ)²⌉；
  (3) 等效：真差为 0，等效边界 ±margin（TOST，α），功效 power：n₃=⌈((z_{1−α}+z_{(1+power)/2})σ_d/margin)²⌉。
  三个数字回答三个不同的问题，不能互相代替。用蒙特卡洛（正态成对差，mc_experiments 次）核验：实现的半宽、功效与 TOST 功效。
B. 相关个体的标准误：以父系半同胞家系为簇，比较验证相关的"朴素标准误"（Fisher z，假设个体独立）、
  按家系的自助法标准误与"真"标准误（独立群体重复间的标准差）。
断言：三个 n 各不相同；小样本时正态近似 n₂ 偏小（精确 n₂' ≥ n₂，且按 n₂ 实施的功效低于按 n₂' 实施的）；MC 实现半宽在目标的 ±15%；
精确 n₂' 的功效 MC 在 [power−0.04, power+0.04]；TOST 功效 MC 在 [power−0.05, power+0.05]；
家系自助法标准误比朴素标准误更接近真值（绝对差更小）。
"""
from __future__ import annotations
import json
from math import ceil
from pathlib import Path
import numpy as np
from scipy import stats
from _sim import simulate, tabular_A, vanraden_G, blup, split

HERE = Path(__file__).resolve().parent


def one_rep(cfg, seed):
    rng = np.random.default_rng(seed)
    d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
    train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"]); u = d["u"][cand]
    uA, _ = blup(tabular_A(d["sire"], d["dam"]), train, cand, d["y"], d["sa2"], d["se2"])
    uG, _ = blup(vanraden_G(d["Z"], d["p"]), train, cand, d["y"], d["sa2"], d["se2"])
    return np.corrcoef(uA, u)[0, 1], np.corrcoef(uG, u)[0, 1], uG, u, d["sire"][cand]


def main():
    cfg = json.loads((HERE / "data" / "ex37_20_config.json").read_text(encoding="utf-8"))
    pil = np.array([one_rep(cfg, cfg["seed"] + i)[:2] for i in range(cfg["pilot_reps"])])
    dif = pil[:, 1] - pil[:, 0]; sd_d = dif.std(ddof=1)
    z = lambda p: stats.norm.ppf(p)
    n1 = ceil((z(0.975) * sd_d / cfg["halfwidth"]) ** 2)
    n2 = ceil(((z(1 - cfg["alpha"] / 2) + z(cfg["power"])) * sd_d / cfg["delta"]) ** 2)
    n3 = ceil(((z(1 - cfg["alpha"]) + z((1 + cfg["power"]) / 2)) * sd_d / cfg["equiv_margin"]) ** 2)
    # 小样本时正态近似偏乐观：用非中心 t 精确搜索（功效）
    n2_t = next(n for n in range(3, 2000) if 1 - stats.nct.cdf(stats.t.ppf(1 - cfg["alpha"] / 2, n - 1), n - 1, cfg["delta"] / sd_d * np.sqrt(n)) + stats.nct.cdf(-stats.t.ppf(1 - cfg["alpha"] / 2, n - 1), n - 1, cfg["delta"] / sd_d * np.sqrt(n)) >= cfg["power"])
    print(f"A. pilot {cfg['pilot_reps']} 次：成对差均值 {dif.mean():.3f}，标准差 σ_d={sd_d:.4f}")
    print(f"  (1) 精度：半宽 ≤{cfg['halfwidth']} → 重复数 n₁={n1}")
    print(f"  (2) 功效：检出 δ={cfg['delta']}（α={cfg['alpha']}，功效 {cfg['power']}）→ 正态近似 n₂={n2}，非中心 t 精确 n₂'={n2_t}")
    print(f"  (3) 等效：边界 ±{cfg['equiv_margin']}（TOST，真差 0，功效 {cfg['power']}）→ n₃={n3}")
    rng = np.random.default_rng(cfg["seed"] + 777); E = cfg["mc_experiments"]
    # 精度
    D = rng.normal(dif.mean(), sd_d, (E, n1)); hw = stats.t.ppf(0.975, n1 - 1) * D.std(1, ddof=1) / np.sqrt(n1)
    # 功效
    D = rng.normal(cfg["delta"], sd_d, (E, n2)); t = D.mean(1) / (D.std(1, ddof=1) / np.sqrt(n2))
    pw_norm = np.mean(np.abs(t) > stats.t.ppf(1 - cfg["alpha"] / 2, n2 - 1))
    D = rng.normal(cfg["delta"], sd_d, (E, n2_t)); t = D.mean(1) / (D.std(1, ddof=1) / np.sqrt(n2_t))
    pw = np.mean(np.abs(t) > stats.t.ppf(1 - cfg["alpha"] / 2, n2_t - 1))
    # TOST
    D = rng.normal(0.0, sd_d, (E, n3)); m = D.mean(1); se = D.std(1, ddof=1) / np.sqrt(n3); tc = stats.t.ppf(1 - cfg["alpha"], n3 - 1)
    tost = np.mean(((m + cfg["equiv_margin"]) / se > tc) & ((cfg["equiv_margin"] - m) / se > tc))
    print(f"  MC 核验（{E} 次）：n₁ 下实现的 95% 半宽均值 {hw.mean():.4f}（目标 {cfg['halfwidth']}）；n₂（正态近似）下功效 {pw_norm:.3f}，n₂'（精确）下功效 {pw:.3f}；n₃ 下 TOST 功效 {tost:.3f}")
    # B. 相关个体的标准误
    rs = []; boot_se = []; naive_se = []
    for i in range(cfg["cluster_reps"]):
        rA, rG, uG, u, sire = one_rep(cfg, cfg["seed"] + 5000 + i)
        rs.append(rG); n = len(u); naive_se.append((1 - rG ** 2) / np.sqrt(n - 2))
        ids = np.unique(sire); idx = {s: np.where(sire == s)[0] for s in ids}; bb = []
        rb = np.random.default_rng(cfg["seed"] + 9000 + i)
        for _ in range(cfg["boot"]):
            pick = rb.choice(ids, len(ids), replace=True); sel = np.concatenate([idx[s] for s in pick])
            bb.append(np.corrcoef(uG[sel], u[sel])[0, 1])
        boot_se.append(np.std(bb, ddof=1))
    true_se = np.std(rs, ddof=1)
    print(f"B. {cfg['cluster_reps']} 个独立群体：验证相关的真标准误（群体间标准差）{true_se:.4f}；朴素（Fisher z，个体独立）平均 {np.mean(naive_se):.4f}；按家系自助法平均 {np.mean(boot_se):.4f}")
    out = dict(sd_d=float(sd_d), n1=n1, n2=n2, n2_t=n2_t, n3=n3, power_norm=float(pw_norm), hw=float(hw.mean()), power=float(pw), tost=float(tost), true_se=float(true_se), naive_se=float(np.mean(naive_se)), boot_se=float(np.mean(boot_se)))
    assert len({n1, n2, n3}) == 3 and n2_t >= n2 and pw_norm < pw
    assert abs(hw.mean() / cfg["halfwidth"] - 1) < 0.15
    assert abs(pw - cfg["power"]) < 0.04 and abs(tost - cfg["power"]) < 0.05
    assert abs(np.mean(boot_se) - true_se) < abs(np.mean(naive_se) - true_se)
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex37_20_power_precision_cluster.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
