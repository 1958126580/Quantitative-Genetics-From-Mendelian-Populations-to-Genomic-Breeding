#!/usr/bin/env python3
"""习题 37.16  相关很高仍可能严重失准：对预测作线性变换，相关不变而校准崩塌

用习题 35.15 的模拟（GBLUP，80 只候选，200 次重复），把正确 EBV û 变换为 û' = a + b·û：
(1) 尺度 b∈{0.5,0.75,1,1.5,2,3}：相关不变，校准斜率 =1/b（总体意义），RMSE 与 90% 覆盖率（沿用原 PEV）变化；
(2) 平移 a=0.8：相关不变，截距 −0.8，RMSE 增大；
(3) 家系水平的偏差：给每个父系半同胞家系加上 N(0, family_bias_sd²) 的偏移，相关略降，校准截距按家系变化；
(4) 检验功效：n=80 只候选时，对"斜率=1"的检验在 b=1.5 时的功效（200 次重复中拒绝比例，t 检验 α=0.05），以及 b=1 时的拒绝比例（名义 0.05，实际因亲缘而偏高）。
断言：相关对 b 与 a 不变（差 <1e-9）；b×校准斜率均值与 1 相差 <0.12（b=1 时斜率均值 ∈[0.9,1.1]）；
b=2 时 RMSE >1.3×b=1 的 RMSE，覆盖率比 b=1 低 0.10 以上；
功效：b=1.5 的拒绝比例 >0.5；b=1 的拒绝比例高于名义 0.05（候选之间有亲缘，误差不独立，朴素检验偏激进）但 <0.25。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats
from _sim import simulate, tabular_A, vanraden_G, blup, split

HERE = Path(__file__).resolve().parent


def slope_test(uhat, u):
    """回归 u 对 û：返回斜率与对 H0:斜率=1 的 t 检验 p 值。"""
    n = len(u); x = uhat - uhat.mean(); b = (x @ (u - u.mean())) / (x @ x)
    res = (u - u.mean()) - b * x; se = np.sqrt(res @ res / (n - 2) / (x @ x))
    return b, 2 * (1 - stats.t.cdf(abs((b - 1) / se), n - 2))


def main():
    cfg = json.loads((HERE / "data" / "ex37_16_config.json").read_text(encoding="utf-8"))
    bs = cfg["scale_b"]; z = cfg["z90"]
    R = {b: dict(r=[], slope=[], rmse=[], cover=[], rej=[]) for b in bs}
    shift_r = []; shift_icpt = []; shift_rmse = []; fam_r = []; fam_ic_sd = []
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
        train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"]); G = vanraden_G(d["Z"], d["p"])
        uh, pev = blup(G, train, cand, d["y"], d["sa2"], d["se2"]); u = d["u"][cand]; sd = np.sqrt(np.diag(pev))
        for b in bs:
            up = b * uh
            bb, p = slope_test(up, u)
            R[b]["r"].append(np.corrcoef(up, u)[0, 1]); R[b]["slope"].append(bb)
            R[b]["rmse"].append(np.sqrt(np.mean((up - u) ** 2))); R[b]["cover"].append(np.mean(np.abs(u - up) <= z * sd)); R[b]["rej"].append(p < 0.05)
        up = uh + cfg["shift"]; shift_r.append(np.corrcoef(up, u)[0, 1]); shift_icpt.append(np.polyfit(up, u, 1)[1]); shift_rmse.append(np.sqrt(np.mean((up - u) ** 2)))
        sires = d["sire"][cand]; bias = {s: rng.normal(0, cfg["family_bias_sd"]) for s in np.unique(sires)}
        upf = uh + np.array([bias[s] for s in sires]); fam_r.append(np.corrcoef(upf, u)[0, 1])
        resid = u - upf; fam_ic_sd.append(np.std([resid[sires == s].mean() for s in np.unique(sires) if (sires == s).sum() >= 3]))
    M = {b: {k: float(np.mean(v)) for k, v in R[b].items()} for b in bs}
    print(f"重复 {cfg['reps']} 次；80 只候选；GBLUP 的 EBV 经线性变换 û' = b·û")
    print(f"{'b':>6}{'相关':>8}{'校准斜率':>10}{'1/b':>8}{'RMSE':>8}{'90%覆盖':>9}{'斜率=1 的检验拒绝率':>20}")
    for b in bs:
        q = M[b]
        print(f"{b:>6}{q['r']:>8.3f}{q['slope']:>10.3f}{1/b:>8.3f}{q['rmse']:>8.3f}{q['cover']:>9.3f}{q['rej']:>20.3f}")
    print(f"\n平移 +{cfg['shift']}：相关 {np.mean(shift_r):.3f}（不变），校准截距 {np.mean(shift_icpt):.3f}，RMSE {np.mean(shift_rmse):.3f}（b=1 时 {M[1.0]['rmse']:.3f}）")
    print(f"家系偏差（sd={cfg['family_bias_sd']}）：相关 {np.mean(fam_r):.3f}（原 {M[1.0]['r']:.3f}），家系平均残差的标准差 {np.mean(fam_ic_sd):.3f}")
    for b in bs:
        assert abs(M[b]["r"] - M[1.0]["r"]) < 1e-9
        assert abs(M[b]["slope"] * b - 1) < 0.12
    assert 0.9 < M[1.0]["slope"] < 1.1
    assert M[2.0]["rmse"] > 1.3 * M[1.0]["rmse"] and M[1.0]["cover"] - M[2.0]["cover"] > 0.10
    assert M[1.5]["rej"] > 0.5 and 0.05 < M[1.0]["rej"] < 0.25
    assert abs(np.mean(shift_r) - M[1.0]["r"]) < 1e-9 and abs(np.mean(shift_icpt) + cfg["shift"]) < 0.02
    out = dict(by_b=M, shift=dict(r=float(np.mean(shift_r)), icpt=float(np.mean(shift_icpt)), rmse=float(np.mean(shift_rmse))), family=dict(r=float(np.mean(fam_r)), sd=float(np.mean(fam_ic_sd))))
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex37_16_high_cor_miscalibrated.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
