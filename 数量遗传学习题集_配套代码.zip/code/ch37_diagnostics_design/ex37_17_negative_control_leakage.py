#!/usr/bin/env python3
"""习题 37.17  无信号负对照揭示预处理泄漏

流程：在 m 个 SNP 中按与表型的相关选前 k 个，再对所选 SNP 做岭回归，在验证集上报告预测相关 r。
正确做法：筛选只用训练个体；泄漏做法：筛选用了全部个体（含验证表型）。
(1) 无信号（表型与基因型独立）：正确流程 r 的均值应≈0，泄漏流程出现明显的正相关；
(2) 有信号（20 个因果位点，h²=0.4）：泄漏使 r 虚高；
(3) 负对照程序：把表型整体置换后重跑完整流程（置换 perm_reps 次，在 perm_datasets 个数据集上），
    若置换后的平均 r 显著大于 0，则判定流程存在泄漏；报告对正确与泄漏流程的判定率。
断言：无信号时正确流程的均值 |r|<0.03，泄漏流程均值 >0.15；有信号时泄漏的 r 比正确的高 >0.05；
置换对照对泄漏流程的判定率 >0.95，对正确流程的假警报率 <0.15。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def pipeline(X, y, tr, va, k, lam, leaky):
    scr = np.arange(len(y)) if leaky else tr
    Xs = X[scr]; ys = y[scr] - y[scr].mean()
    c = np.abs(((Xs - Xs.mean(0)) * ys[:, None]).sum(0)) / (np.sqrt(((Xs - Xs.mean(0)) ** 2).sum(0)) * np.sqrt((ys ** 2).sum()) + 1e-12)
    sel = np.argsort(-c)[:k]
    Xt = X[np.ix_(tr, sel)]; mu = Xt.mean(0); Xt = Xt - mu; yt = y[tr] - y[tr].mean()
    b = np.linalg.solve(Xt.T @ Xt + lam * np.eye(k), Xt.T @ yt)
    pred = (X[np.ix_(va, sel)] - mu) @ b
    return np.corrcoef(pred, y[va])[0, 1]


def make(rng, cfg, signal):
    n, m = cfg["n"], cfg["m"]; p = rng.uniform(0.2, 0.5, m)
    X = rng.binomial(2, p, (n, m)).astype(float)
    X = (X - 2 * p) / np.sqrt(2 * p * (1 - p))
    if signal:
        idx = rng.choice(m, cfg["n_causal"], replace=False); b = np.zeros(m); b[idx] = rng.normal(0, 1, cfg["n_causal"])
        g = X @ b; g *= np.sqrt(cfg["h2"]) / g.std(); y = g + rng.normal(0, np.sqrt(1 - cfg["h2"]), n)
    else:
        y = rng.normal(0, 1, n)
    return X, y


def main():
    cfg = json.loads((HERE / "data" / "ex37_17_config.json").read_text(encoding="utf-8"))
    n, ntr = cfg["n"], cfg["n_train"]; res = {}
    for name, signal in (("无信号", False), ("有信号", True)):
        rc, rl = [], []
        for r in range(cfg["reps"]):
            rng = np.random.default_rng(cfg["seed"] + r + (1000 if signal else 0))
            X, y = make(rng, cfg, signal); perm = rng.permutation(n); tr = np.sort(perm[:ntr]); va = np.sort(perm[ntr:])
            rc.append(pipeline(X, y, tr, va, cfg["k_select"], cfg["ridge"], False)); rl.append(pipeline(X, y, tr, va, cfg["k_select"], cfg["ridge"], True))
        res[name] = (np.array(rc), np.array(rl))
    print(f"n={n}（训练 {ntr}，验证 {n-ntr}），m={cfg['m']}，选 {cfg['k_select']} 个 SNP，岭 λ={cfg['ridge']}；重复 {cfg['reps']} 次")
    print(f"{'情景':<8}{'正确流程 r':>14}{'泄漏流程 r':>14}")
    out = {}
    for name in res:
        a, b = res[name]
        print(f"{name:<8}{a.mean():>9.3f}±{a.std(ddof=1)/np.sqrt(len(a)):.3f}{b.mean():>9.3f}±{b.std(ddof=1)/np.sqrt(len(b)):.3f}   （均值±标准误）")
        out[name] = dict(correct=float(a.mean()), leaky=float(b.mean()))
    # 负对照：置换表型后重跑
    det = {"正确": 0, "泄漏": 0}; means = {"正确": [], "泄漏": []}
    for ds in range(cfg["perm_datasets"]):
        rng = np.random.default_rng(cfg["seed"] + 5000 + ds)
        X, y = make(rng, cfg, True)               # 数据本身有信号；置换会破坏它
        for key, leaky in (("正确", False), ("泄漏", True)):
            rs = []
            for q in range(cfg["perm_reps"]):
                yp = rng.permutation(y); pm = rng.permutation(n); tr = np.sort(pm[:ntr]); va = np.sort(pm[ntr:])
                rs.append(pipeline(X, yp, tr, va, cfg["k_select"], cfg["ridge"], leaky))
            rs = np.array(rs); means[key].append(rs.mean())
            z = rs.mean() / (rs.std(ddof=1) / np.sqrt(len(rs)))
            det[key] += int(z > 3)                # 平均 r 显著大于 0 → 判定泄漏
    print(f"\n负对照（置换表型后重跑流程，{cfg['perm_datasets']} 个数据集 × {cfg['perm_reps']} 次置换）：")
    print(f"  正确流程：置换后平均 r = {np.mean(means['正确']):.3f}，判定为“泄漏”的比例 {det['正确']/cfg['perm_datasets']:.3f}（假警报）")
    print(f"  泄漏流程：置换后平均 r = {np.mean(means['泄漏']):.3f}，判定为“泄漏”的比例 {det['泄漏']/cfg['perm_datasets']:.3f}（检出率）")
    out["perm"] = dict(correct=float(np.mean(means["正确"])), leaky=float(np.mean(means["泄漏"])), false_alarm=det["正确"] / cfg["perm_datasets"], detect=det["泄漏"] / cfg["perm_datasets"])
    a0, b0 = res["无信号"]; a1, b1 = res["有信号"]
    assert abs(a0.mean()) < 0.03 and b0.mean() > 0.15
    assert b1.mean() > a1.mean() + 0.05
    assert out["perm"]["detect"] > 0.95 and out["perm"]["false_alarm"] < 0.15
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex37_17_negative_control_leakage.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
