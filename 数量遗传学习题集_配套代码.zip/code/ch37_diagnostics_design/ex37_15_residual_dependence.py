#!/usr/bin/env python3
"""习题 37.15  残差经过拟合以后为何不再独立：条件残差的协方差与学生化

公畜模型 y_ij = μ + s_i + e_ij（12 头公畜 × 6 个子代，σs²=1，σe²=3）。以真实方差拟合 BLUP，条件残差 r = y − Xb̂ − Zû = σe² P y，
其中 P = V⁻¹ − V⁻¹X(XᵀV⁻¹X)⁻¹XᵀV⁻¹。理论：Var(r)=σe⁴P，杠杆量 h_i=1−σe²P_ii，E(r_i²)=σe²(1−h_i)，同公畜子代的残差相关为负。
(1) 蒙特卡洛核验理论方差与杠杆量；(2) 同公畜子代残差的相关（理论与模拟）；
(3) 朴素标准化 r/σe 的方差 <1（过窄），学生化 r/(σe√(1−h_i)) 的方差 ≈1；
(4) 对一条记录加入 4σe 的异常偏移：用 |标准化|>3 与 |学生化|>3 的检出概率；
(5) ∑h_i = p + ∑（公畜效应的有效自由度）。
断言：模拟的 E(r_i²)/σe² 与 1−h_i 的平均相对误差 <1%（逐记录 <6%）；朴素标准化残差的平均方差 <1 而学生化残差的平均方差在 0.97—1.03；
同公畜残差相关的模拟与理论相差 <0.02 且为负；学生化检出概率高于朴素。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex37_15_config.json").read_text(encoding="utf-8"))
    S, k = cfg["n_sire"], cfg["k_prog"]; n = S * k; ss, se = cfg["sigma_s2"], cfg["sigma_e2"]
    Z = np.kron(np.eye(S), np.ones((k, 1))); X = np.ones((n, 1))
    V = ss * Z @ Z.T + se * np.eye(n); Vi = np.linalg.inv(V)
    P = Vi - Vi @ X @ np.linalg.inv(X.T @ Vi @ X) @ X.T @ Vi
    h = 1 - se * np.diag(P); Vr = se ** 2 * P
    rng = np.random.default_rng(cfg["seed"]); R = cfg["mc_reps"]
    s = rng.normal(0, np.sqrt(ss), (R, S)); y = 5.0 + s @ Z.T + rng.normal(0, np.sqrt(se), (R, n))
    r = se * (y @ P.T)                      # 每行一次重复；P 对称
    emp_var = r.var(0)
    rel = abs(np.mean(emp_var) / Vr.diagonal()[0] - 1)
    rel_max = np.max(np.abs(emp_var / Vr.diagonal() - 1))
    # 同公畜相关
    cor_theory = Vr[0, 1] / np.sqrt(Vr[0, 0] * Vr[1, 1]); cor_emp = np.corrcoef(r[:, 0], r[:, 1])[0, 1]
    cor_diff = Vr[0, k] / np.sqrt(Vr[0, 0] * Vr[k, k]); cor_diff_emp = np.corrcoef(r[:, 0], r[:, k])[0, 1]
    z_naive = r / np.sqrt(se); z_stu = r / np.sqrt(se * (1 - h))
    # 异常检出
    shift = cfg["outlier_shift_sd"] * np.sqrt(se); y2 = y.copy(); y2[:, 0] += shift
    r2 = se * (y2 @ P.T); th = cfg["detect_thresh"]
    det_naive = np.mean(np.abs(r2[:, 0] / np.sqrt(se)) > th); det_stu = np.mean(np.abs(r2[:, 0] / np.sqrt(se * (1 - h[0]))) > th)
    fa_naive = np.mean(np.abs(z_naive) > th); fa_stu = np.mean(np.abs(z_stu) > th)
    print(f"{S} 头公畜×{k} 子代，σs²={ss}，σe²={se}；蒙特卡洛 {R} 次")
    print(f"杠杆量 h_i：{h.min():.4f}（所有记录相同，平衡设计）；∑h_i = {h.sum():.3f}（= 1 + 公畜有效自由度 {h.sum()-1:.3f}）")
    print(f"E(r_i²)/σe²：理论 1−h = {1-h[0]:.4f}，模拟均值 {np.mean(emp_var)/se:.4f}；均值的相对误差 {rel:.3%}，逐记录最大相对误差 {rel_max:.2%}（蒙特卡洛波动）")
    print(f"同公畜子代残差相关：理论 {cor_theory:.4f}，模拟 {cor_emp:.4f}；不同公畜：理论 {cor_diff:.4f}，模拟 {cor_diff_emp:.4f}")
    print(f"标准化残差的方差：朴素 r/σe {np.mean(z_naive.var(0)):.4f}；学生化 {np.mean(z_stu.var(0)):.4f}")
    print(f"无异常时 |z|>{th} 的频率：朴素 {fa_naive:.5f}，学生化 {fa_stu:.5f}")
    print(f"加入 {cfg['outlier_shift_sd']}σe 的异常后检出概率：朴素 {det_naive:.3f}，学生化 {det_stu:.3f}")
    out = dict(leverage=float(h[0]), sum_h=float(h.sum()), rel_err=float(rel), cor=[float(cor_theory), float(cor_emp)], var_naive=float(np.mean(z_naive.var(0))),
               var_stu=float(np.mean(z_stu.var(0))), det=[float(det_naive), float(det_stu)], fa=[float(fa_naive), float(fa_stu)])
    assert rel < 0.01 and rel_max < 0.06
    assert np.mean(z_naive.var(0)) < 1 and 0.97 < np.mean(z_stu.var(0)) < 1.03
    assert cor_theory < 0 and abs(cor_theory - cor_emp) < 0.02
    assert det_stu > det_naive
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex37_15_residual_dependence.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
