#!/usr/bin/env python3
"""习题 37.18  方差分量落在边界：弱信息下的 REML 估计、零估计的频率与后果

平衡公畜模型：s 头公畜 × k 个子代，y_ij = μ + s_i + e_ij，h²=4σs²/(σs²+σe²)。
REML（平衡设计的闭式解）：σ̂e²=MSW，σ̂s²=max(0,(MSB−MSW)/k)（MSB<MSW 时取边界 0）。
理论：F=MSB/MSW ~ (1+kρ)·F(s−1, s(k−1))，ρ=σs²/σe²，故 P(边界)=P(F(s−1,s(k−1)) < 1/(1+kρ))。
报告：(1) 零估计的频率（蒙特卡洛 vs 理论）；(2) σ̂s² 与 ĥ² 的均值（截断带来的正偏）与变异系数；
(3) 以估计方差作 BLUP（缩放因子 σ̂s²/(σ̂s²+σ̂e²/k)）的公畜准确度（边界时 EBV≡0，计相关 0），与已知方差的准确度；
(4) 估计的 h² 的 90% 区间宽度（分位数）。
断言：蒙特卡洛与理论的零估计频率相差 <0.02；零估计频率随 s 增加而下降；s=10、h²=0.1 时零估计频率 >0.3；
σ̂s² 的均值不低于真值（截断正偏，容差 3%）；估计方差的准确度不高于已知方差（容差 0.01）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex37_18_config.json").read_text(encoding="utf-8"))
    k = cfg["k_prog"]; R = cfg["mc_reps"]; out = {}
    print(f"每头公畜 {k} 个子代；蒙特卡洛 {R} 次；σs²+σe²=1")
    print(f"{'h²':>5}{'s':>5}{'零估计 MC':>10}{'理论':>8}{'E(σ̂s²)':>9}{'真值':>7}{'ĥ² 均值':>9}{'ĥ² 90%区间':>14}{'准确度(估计)':>13}{'准确度(已知)':>13}")
    zero = {}
    for h2 in cfg["h2"]:
        ss = h2 / 4; se = 1 - ss; rho = ss / se
        for s in cfg["sires"]:
            rng = np.random.default_rng(cfg["seed"] + s * 7 + int(h2 * 100))
            si = rng.normal(0, np.sqrt(ss), (R, s)); e = rng.normal(0, np.sqrt(se), (R, s, k))
            y = si[:, :, None] + e
            ybar_i = y.mean(2); ybar = ybar_i.mean(1)
            MSB = k * ((ybar_i - ybar[:, None]) ** 2).sum(1) / (s - 1)
            MSW = ((y - ybar_i[:, :, None]) ** 2).sum((1, 2)) / (s * (k - 1))
            ss_hat = np.maximum(0, (MSB - MSW) / k); se_hat = MSW
            h2_hat = 4 * ss_hat / (ss_hat + se_hat)
            p_mc = np.mean(ss_hat == 0); p_th = stats.f.cdf(1 / (1 + k * rho), s - 1, s * (k - 1))
            # 准确度
            shrink_hat = ss_hat / (ss_hat + se_hat / k); shrink_true = ss / (ss + se / k)
            ebv_hat = shrink_hat[:, None] * (ybar_i - ybar[:, None]); ebv_true = shrink_true * (ybar_i - ybar[:, None])
            def rr(a, b):
                a = a - a.mean(1, keepdims=True); b = b - b.mean(1, keepdims=True)
                den = np.sqrt((a ** 2).sum(1) * (b ** 2).sum(1))
                return np.where(den > 0, (a * b).sum(1) / np.where(den > 0, den, 1), 0.0)
            acc_hat = rr(ebv_hat, si).mean(); acc_true = rr(ebv_true, si).mean()
            lo, hi = np.quantile(h2_hat, [0.05, 0.95])
            print(f"{h2:>5}{s:>5}{p_mc:>10.3f}{p_th:>8.3f}{ss_hat.mean():>9.4f}{ss:>7.4f}{h2_hat.mean():>9.3f}{f'[{lo:.2f},{hi:.2f}]':>14}{acc_hat:>13.3f}{acc_true:>13.3f}")
            out[f"{h2}|{s}"] = dict(p_mc=float(p_mc), p_th=float(p_th), mean_ss=float(ss_hat.mean()), mean_h2=float(h2_hat.mean()), lo=float(lo), hi=float(hi), acc_hat=float(acc_hat), acc_true=float(acc_true))
            assert abs(p_mc - p_th) < 0.02
            assert ss_hat.mean() >= ss * 0.97
            assert acc_hat <= acc_true + 0.01
            zero[(h2, s)] = p_mc
    for h2 in cfg["h2"]:
        seq = [zero[(h2, s)] for s in cfg["sires"]]
        assert all(seq[i + 1] <= seq[i] + 0.005 for i in range(len(seq) - 1))
    assert zero[(0.1, 10)] > 0.3
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex37_18_variance_boundary.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
