# 第21章　从最小二乘到最佳线性无偏预测——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex21_15_blup_properties.py
python3 ex21_16_sire_model_mme.py
python3 ex21_17_connectedness.py
python3 ex21_18_selection_bias.py
python3 ex21_19_empirical_blup.py
python3 ex21_20_singular_mixed_target.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex21_15_blup_properties.py | 21.15 | BLUP 的统计性质：收缩、边际无偏、条件偏差与“胜者诅咒” |
| ex21_16_sire_model_mme.py | 21.16 | 不平衡种公畜模型的混合模型方程、V 形式与 PEV |
| ex21_17_connectedness.py | 21.17 | 可估计性与遗传连通：联结公畜数对跨场比较的影响 |
| ex21_18_selection_bias.py | 21.18 | 选择条件下的 BLUP：全系谱全资料无偏，删除被淘汰者记录或忽略系谱则有偏 |
| ex21_19_empirical_blup.py | 21.19 | 经验 BLUP：用估计的方差比代替真值会损失什么 |
| ex21_20_singular_mixed_target.py | 21.20 | 奇异协方差与固定+随机混合目标的最优预测 |
