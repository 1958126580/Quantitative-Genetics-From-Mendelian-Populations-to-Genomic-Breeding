#!/usr/bin/env python3
"""习题 21.19  经验 BLUP：用估计的方差比代替真值会损失什么

公畜模型 y = Xb + Zs + e（场固定，公畜随机）。每次重复：生成数据 → REML 估计 σ_s², σ_e²（对 λ=σ_s²/σ_e² 的
轮廓似然，边界处理）→ 用 λ̂ 与真 λ 分别求 BLUP，比较
  - 预测误差均方（MSEP）与标称 PEV（真参数公式、估计参数公式）；
  - 与真值的相关（准确度）；
  - 名义 95% 预测区间 ŝ ± 1.96·√PEV 的覆盖率；
  - λ̂ 的分布（偏倚、为 0 的比例）。
覆盖四种设计：公畜数 {30,100} × 每公畜后代数 {4,12}。
核验：用真参数的 BLUP 其 MSEP 与 PEV 相对差 < 5%；λ̂→λ 随资料量增大。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar

HERE = Path(__file__).resolve().parent


def make_design(S, H, m):
    sire = np.repeat(np.arange(S), m)
    herd = np.arange(len(sire)) % H
    N = len(sire)
    X = np.zeros((N, H)); X[np.arange(N), herd] = 1
    Z = np.zeros((N, S)); Z[np.arange(N), sire] = 1
    return X, Z


def reml_lambda(y, X, Z, eig=None):
    """λ = σ_s²/σ_e² 的 REML：V = σ_e²(I + λ ZZ')。返回 (λ̂, σ̂_e²)。"""
    N, p = X.shape
    ev, U = eig
    Uy = U.T @ y; UX = U.T @ X

    def negll(loglam):
        lam = np.exp(loglam)
        d = 1 + lam * ev
        w = 1 / d
        XtWX = UX.T @ (UX * w[:, None])
        b = np.linalg.solve(XtWX, UX.T @ (Uy * w))
        r = Uy - UX @ b
        q = np.sum(r * r * w)
        s2 = q / (N - p)
        sign, ld = np.linalg.slogdet(XtWX)
        return 0.5 * ((N - p) * np.log(s2) + np.sum(np.log(d)) + ld)

    res = minimize_scalar(negll, bounds=(-9, 4), method="bounded", options={"xatol": 1e-4})
    l1 = np.exp(res.x)
    if negll(-9) <= res.fun + 1e-9:     # 边界：σ_s²→0
        l1 = 0.0
    lam = max(l1, 1e-9) if l1 > 0 else 0.0
    d = 1 + lam * ev; w = 1 / d
    XtWX = UX.T @ (UX * w[:, None]); b = np.linalg.solve(XtWX, UX.T @ (Uy * w))
    r = Uy - UX @ b
    return lam, float(np.sum(r * r * w) / (N - p))


def blup(y, X, Z, lam):
    """给定 λ（残差方差比）的 BLUP 与 C²² 阵（单位 σ_e²）。λ=0 → 全部收缩为 0。"""
    S = Z.shape[1]
    if lam <= 0:
        return np.zeros(S), None
    k = 1 / lam
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + k * np.eye(S)]])
    sol = np.linalg.solve(C, np.r_[X.T @ y, Z.T @ y])
    Cinv = np.linalg.inv(C)
    return sol[X.shape[1]:], Cinv[X.shape[1]:, X.shape[1]:]


def run_design(S, H, m, cfg, rng):
    X, Z = make_design(S, H, m)
    N = X.shape[0]
    ev, U = np.linalg.eigh(Z @ Z.T)
    vs, ve = cfg["var_sire_true"], cfg["var_e_true"]; lam0 = vs / ve
    msep_t, pev_t, msep_e, pev_e_nom, corr_t, corr_e, cov_e, lam_hat = [], [], [], [], [], [], [], []
    for _ in range(cfg["n_rep"]):
        s = rng.normal(0, np.sqrt(vs), S); hb = rng.normal(0, cfg["herd_sd"], H)
        y = 100 + X @ hb + Z @ s + rng.normal(0, np.sqrt(ve), N)
        sh_t, C22_t = blup(y, X, Z, lam0)
        pev_t_vec = ve * np.diag(C22_t)
        lam, s2e = reml_lambda(y, X, Z, (ev, U))
        sh_e, C22_e = blup(y, X, Z, lam)
        msep_t.append(np.mean((s - sh_t) ** 2)); pev_t.append(pev_t_vec.mean())
        msep_e.append(np.mean((s - sh_e) ** 2))
        if C22_e is None:
            pev_nom = np.zeros(S)
        else:
            pev_nom = s2e * np.diag(C22_e)
        pev_e_nom.append(pev_nom.mean())
        corr_t.append(np.corrcoef(s, sh_t)[0, 1])
        corr_e.append(np.corrcoef(s, sh_e)[0, 1] if np.std(sh_e) > 0 else 0.0)
        # 覆盖率（估计参数下的名义区间）
        cov_e.append(np.mean(np.abs(s - sh_e) <= 1.96 * np.sqrt(np.maximum(pev_nom, 1e-12))) if C22_e is not None else 0.0)
        lam_hat.append(lam)
    lam_hat = np.array(lam_hat)
    return dict(S=S, m=m, lam_true=lam0, lam_mean=float(lam_hat.mean()), lam_sd=float(lam_hat.std()), frac_zero=float(np.mean(lam_hat == 0)),
                msep_true=float(np.mean(msep_t)), pev_true=float(np.mean(pev_t)), msep_est=float(np.mean(msep_e)), pev_est_nominal=float(np.mean(pev_e_nom)),
                corr_true=float(np.mean(corr_t)), corr_est=float(np.mean(corr_e)), coverage_est=float(np.mean(cov_e)))


def main():
    cfg = json.load(open(HERE / "data" / "ex21_19_ebLUP.json"))
    rng = np.random.default_rng(cfg["seed"])
    print("=" * 100)
    print("习题 21.19  经验 BLUP（真 σ_s²=%.1f, σ_e²=%.1f, λ=%.4f，%d 次重复）" % (cfg["var_sire_true"], cfg["var_e_true"], cfg["var_sire_true"] / cfg["var_e_true"], cfg["n_rep"]))
    print("=" * 100)
    print(f"{'S':>4}{'m':>4}{'λ̂均值':>8}{'λ̂SD':>7}{'λ̂=0 占比':>9}{'MSEP(真参)':>11}{'PEV(真参)':>10}{'MSEP(估参)':>11}{'名义PEV(估参)':>13}{'相关(真参)':>10}{'相关(估参)':>10}{'覆盖率':>7}")
    rows = []
    for S, m in cfg["design_list"]:
        r = run_design(S, cfg["n_herd"], m, cfg, rng)
        rows.append(r)
        assert abs(r["msep_true"] - r["pev_true"]) / r["pev_true"] < 0.06, r
        print(f"{S:4d}{m:4d}{r['lam_mean']:8.3f}{r['lam_sd']:7.3f}{r['frac_zero']:9.3f}{r['msep_true']:11.3f}{r['pev_true']:10.3f}{r['msep_est']:11.3f}{r['pev_est_nominal']:13.3f}{r['corr_true']:10.3f}{r['corr_est']:10.3f}{r['coverage_est']:7.3f}")
    # 资料越多，λ̂ 越准，MSEP(估参)−MSEP(真参) 越小
    gaps = [r["msep_est"] - r["msep_true"] for r in rows]
    assert gaps[-1] < gaps[0] + 0.02
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(rows, open(HERE / "results" / "ex21_19_empirical_blup.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
