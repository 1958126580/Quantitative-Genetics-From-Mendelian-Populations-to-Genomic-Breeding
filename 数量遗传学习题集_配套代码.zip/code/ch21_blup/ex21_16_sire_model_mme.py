#!/usr/bin/env python3
"""习题 21.16  不平衡种公畜模型的混合模型方程、V 形式与 PEV

y = X b + Z s + e：b 为场（固定，4 个场），s 为 8 头不相关公畜（随机，方差 σ_s²），e 为残差，共 N 条记录，
各公畜在各场的后代数不平衡且部分公畜只出现在个别场。已知 σ_s²=1.5、σ_e²=9（k = σ_e²/σ_s² = 6）。
内容：
  1. 混合模型方程 [X'X X'Z; Z'X Z'Z+kI][b;s]=[X'y;Z'y] 求解；
  2. V 形式：b̂=(X'V⁻¹X)⁻¹X'V⁻¹y，ŝ=σ_s²Z'V⁻¹(y−Xb̂)，与 MME 解逐元一致；
  3. PEV = σ_e²·C²²（C 为系数阵逆的随机块），与 V 形式 G − G Z'PZ G 一致；
     并展示误把 C²² 当作 PEV（未乘 σ_e²）的可靠度错误；
  4. 与未校正场效应的公畜平均、与固定效应（最小二乘）公畜估计的比较（排名与误差）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import linalg

HERE = Path(__file__).resolve().parent


def build(data):
    rec = data["records"]; N = len(rec)
    H, S = data["n_herd"], data["n_sire"]
    X = np.zeros((N, H)); Z = np.zeros((N, S)); y = np.zeros(N)
    for r, (h, s, v) in enumerate(rec):
        X[r, h] = 1; Z[r, s] = 1; y[r] = v
    return X, Z, y


def main():
    data = json.load(open(HERE / "data" / "ex21_16_sire_data.json"))
    X, Z, y = build(data)
    N, H = X.shape; S = Z.shape[1]
    vs, ve = data["var_sire"], data["var_e"]; k = ve / vs

    # 1. MME
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + k * np.eye(S)]])
    rhs = np.r_[X.T @ y, Z.T @ y]
    sol = linalg.solve(C, rhs, assume_a="sym")
    b_mme, s_mme = sol[:H], sol[H:]
    Cinv = linalg.inv(C)
    C22 = Cinv[H:, H:]

    # 2. V 形式
    V = vs * Z @ Z.T + ve * np.eye(N)
    Vi_X = linalg.solve(V, X, assume_a="pos"); Vi_y = linalg.solve(V, y, assume_a="pos")
    XtViX = X.T @ Vi_X
    b_v = linalg.solve(XtViX, X.T @ Vi_y, assume_a="pos")
    s_v = vs * Z.T @ linalg.solve(V, y - X @ b_v, assume_a="pos")
    assert np.allclose(b_mme, b_v, atol=1e-8) and np.allclose(s_mme, s_v, atol=1e-8)

    # 3. PEV
    pev_mme = ve * np.diag(C22)
    P = np.linalg.inv(V) - Vi_X @ np.linalg.solve(XtViX, Vi_X.T)
    G = vs * np.eye(S)
    PEVm = G - G @ Z.T @ P @ Z @ G
    assert np.allclose(pev_mme, np.diag(PEVm), atol=1e-8)
    assert np.allclose(ve * C22, PEVm, atol=1e-8), "PEV 矩阵不一致"
    rel = 1 - pev_mme / vs
    rel_wrong = 1 - np.diag(C22) / vs

    # 4. 比较
    n_s = Z.sum(0)
    raw_mean = (Z.T @ y) / n_s
    # 固定效应估计（场+公畜；以 S 头和为 0 约束）
    Xf = np.hstack([X, Z[:, 1:]])
    bf = np.linalg.lstsq(Xf, y, rcond=None)[0]
    sf = np.r_[0, bf[H:]]; sf -= sf.mean()
    true = np.array(data["true_sire"]); true_c = true - true.mean()
    print("=" * 74)
    print("习题 21.16  不平衡公畜模型  N=%d, k=%.1f" % (N, k))
    print("=" * 74)
    print("场效应 b̂（MME）：", np.round(b_mme, 3), "  真值 [100, 103, 98, 101.5]")
    print(f"{'公畜':<4}{'n':>3}{'原始均值':>10}{'固定效应LS':>11}{'BLUP ŝ':>9}{'PEV':>7}{'可靠度':>8}{'错误可靠度':>10}{'真值':>8}")
    for i in range(S):
        print(f"{i+1:<4}{int(n_s[i]):3d}{raw_mean[i]:10.2f}{sf[i]:11.3f}{s_mme[i]:9.3f}{pev_mme[i]:7.3f}{rel[i]:8.3f}{rel_wrong[i]:10.3f}{true[i]:8.3f}")
    # 排名相关
    from scipy.stats import spearmanr
    out = dict(b=b_mme.tolist(), s=s_mme.tolist(), pev=pev_mme.tolist(), reliability=rel.tolist(),
               spearman_blup_true=float(spearmanr(s_mme, true)[0]), spearman_raw_true=float(spearmanr(raw_mean, true)[0]),
               spearman_ls_true=float(spearmanr(sf, true)[0]),
               rmse_blup=float(np.sqrt(np.mean((s_mme - true_c) ** 2))), rmse_ls=float(np.sqrt(np.mean((sf - true_c) ** 2))))
    print(f"\n与真值的 Spearman 相关：BLUP {out['spearman_blup_true']:.3f}，固定效应 LS {out['spearman_ls_true']:.3f}，原始均值 {out['spearman_raw_true']:.3f}")
    print(f"RMSE（对真值，居中）：BLUP {out['rmse_blup']:.3f}，LS {out['rmse_ls']:.3f}")
    # 相对于估计效应的误差协方差：公畜 1 与 2 的差异 PEV（含共同误差）
    d = np.zeros(S); d[0], d[1] = 1, -1
    pev_diff = d @ PEVm @ d
    print(f"公畜1−公畜2 的差异 PEV = {pev_diff:.3f}；若当作独立 = {PEVm[0,0]+PEVm[1,1]:.3f}")
    out["pev_diff_12"] = float(pev_diff)
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex21_16_sire_model_mme.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
