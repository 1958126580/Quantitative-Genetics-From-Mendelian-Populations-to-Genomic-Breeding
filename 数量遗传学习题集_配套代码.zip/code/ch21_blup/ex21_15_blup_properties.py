#!/usr/bin/env python3
"""习题 21.15  BLUP 的统计性质：收缩、边际无偏、条件偏差与“胜者诅咒”

模型：y_ij = μ + u_i + e_ij，u_i ~ N(0, V_A)，e ~ N(0, V_e)，动物 i 有 k_i 条记录（均值 ȳ_i），
BLUP û_i = r_i² (ȳ_i − μ)·（…）其中 r_i² = k V_A / (k V_A + V_e)，PEV = V_A (1 − r_i²)。
对 60000 个动物（记录数 1,2,4,8 混合）核对：
  1. 边际无偏：E(û)=0，E(u−û)=0；Cov(u,û)=Var(û)=V_A·E(r²)；PEV 的经验值与理论一致；
  2. 校准：u 对 û 回归斜率 = 1；û 对 u 回归斜率 = r²（条件偏差 E(û|u)=r²u，不是 u）；
  3. 以 û 与以原始均值 ȳ 为依据选留前 10%：被选动物的平均真值与平均预测值之差（高估量）——BLUP 无高估，ȳ 有高估；
  4. 记录数混合时，ȳ 排名与 û 排名的差异及选择反应（被选者平均真值）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.load(open(HERE / "data" / "ex21_15_params.json"))
    rng = np.random.default_rng(cfg["seed"])
    VA, Ve, n = cfg["VA"], cfg["Ve"], cfg["n_animals"]
    ks = rng.choice(cfg["record_counts"], size=n, p=cfg["mix_prob"])
    u = rng.normal(0, np.sqrt(VA), n)
    ybar = u + rng.normal(0, 1, n) * np.sqrt(Ve / ks)
    r2 = ks * VA / (ks * VA + Ve)
    uhat = r2 * ybar            # μ=0 已知
    pev_th = VA * (1 - r2)
    err = u - uhat

    assert abs(uhat.mean()) < 5 * uhat.std() / np.sqrt(n)
    assert abs(err.mean()) < 5 * err.std() / np.sqrt(n)
    assert abs(np.mean(err ** 2) - pev_th.mean()) / pev_th.mean() < 0.02
    cov_ud = np.cov(u, uhat)[0, 1]
    assert abs(cov_ud - np.var(uhat)) / np.var(uhat) < 0.02, "Cov(u,û)=Var(û) 失败"

    slope_u_on_uhat = cov_ud / np.var(uhat)
    out = dict(pev_emp=float(np.mean(err ** 2)), pev_th=float(pev_th.mean()), slope_u_on_uhat=float(slope_u_on_uhat))
    print("=" * 70)
    print("习题 21.15  BLUP 的性质（VA=%.1f, Ve=%.1f, n=%d）" % (VA, Ve, n))
    print("=" * 70)
    print(f"平均 PEV：经验 {np.mean(err**2):.4f}  理论 {pev_th.mean():.4f}；E(u−û)={err.mean():+.4f}")
    print(f"u 对 û 回归斜率 = {slope_u_on_uhat:.4f}（应为1）")
    print("k   r²      E(û|u) 斜率（û 对 u）  理论 r²   PEV 经验  PEV 理论")
    for k in cfg["record_counts"]:
        m = ks == k
        s_hu = np.cov(uhat[m], u[m])[0, 1] / np.var(u[m])
        pe = np.mean(err[m] ** 2)
        print(f"{k:<3d} {r2[m][0]:.4f}  {s_hu:10.4f}          {r2[m][0]:.4f}   {pe:7.3f}   {pev_th[m][0]:7.3f}")
        assert abs(s_hu - r2[m][0]) < 0.02
    # 3. 选择
    top = int(n * cfg["top_frac"])
    rows = {}
    for name, score in (("BLUP û", uhat), ("原始均值 ȳ", ybar), ("单条记录排序（仅 k=1 者）", None)):
        if score is None:
            continue
        idx = np.argsort(-score)[:top]
        rows[name] = dict(mean_true=float(u[idx].mean()), mean_pred=float(score[idx].mean()), mean_k=float(ks[idx].mean()))
    print("\n选留前10%：")
    print(f"{'依据':<14}{'被选者平均真值':>14}{'平均预测/观测':>14}{'高估量':>9}{'平均记录数':>10}")
    for name, v in rows.items():
        print(f"{name:<14}{v['mean_true']:14.3f}{v['mean_pred']:14.3f}{v['mean_pred']-v['mean_true']:9.3f}{v['mean_k']:10.2f}")
    assert abs(rows["BLUP û"]["mean_pred"] - rows["BLUP û"]["mean_true"]) < 0.05
    assert rows["BLUP û"]["mean_true"] > rows["原始均值 ȳ"]["mean_true"]
    # 4. 最优性：以 û 排序的被选者平均真值最大（对线性预测量）
    out["selection"] = rows
    # 条件偏差：固定 u 取极端值
    ext = u > np.quantile(u, 0.99)
    print(f"\n真值最高 1% 的动物：平均真值 {u[ext].mean():.3f}，平均预测 {uhat[ext].mean():.3f}（条件偏差 {uhat[ext].mean()-u[ext].mean():+.3f}）")
    out["extreme_1pct"] = dict(true=float(u[ext].mean()), pred=float(uhat[ext].mean()))
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex21_15_blup_properties.json", "w"), ensure_ascii=False, indent=1)
    try:
        from _plot import get_pyplot
        plt = get_pyplot()
        if plt:
            fig, ax = plt.subplots(1, 2, figsize=(9, 3.6))
            sel = rng.choice(n, 3000, replace=False)
            ax[0].scatter(u[sel], uhat[sel], s=3, alpha=.4); ax[0].set_xlabel("真值 u"); ax[0].set_ylabel("BLUP û")
            ax[1].scatter(uhat[sel], u[sel], s=3, alpha=.4); ax[1].plot([-6, 6], [-6, 6], "r"); ax[1].set_xlabel("û"); ax[1].set_ylabel("u（斜率=1）")
            fig.tight_layout(); fig.savefig(HERE / "results" / "ex21_15_blup_properties.png"); plt.close(fig)
    except Exception:
        pass


if __name__ == "__main__":
    main()
