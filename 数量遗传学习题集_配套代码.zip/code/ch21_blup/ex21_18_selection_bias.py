#!/usr/bin/env python3
"""习题 21.18  选择条件下的 BLUP：全系谱全资料无偏，删除被淘汰者记录或忽略系谱则有偏

闭锁群体，G+1 个世代（0…G），每代 N 头；世代 g≥1 的亲本为上一代表型最高的 n_p 头（不分性别，随机配对，无自交）。
性状 y = μ + a + e，a 按无限小模型传递（含近交的孟德尔抽样方差）。四种分析：
  A  全系谱 + 全部记录的动物模型 BLUP（Henderson 1975：选择基于所用记录时无偏）；
  B  无系谱：û = h²(y − 本代均值)，仅用本代记录（组内选择只调整世代均值，不利用亲属信息）；
  C  全系谱，但只保留被选为亲本的动物与最后一代的记录（淘汰动物的记录被删除，缺失依赖其自身表型）；
  D  无系谱、不调整世代：û = h²(y − 全体均值)。
评价：各世代平均真值与平均 EBV 之差（遗传趋势偏差，基点为第 0 代），末代 EBV 与真值的相关和 u 对 û 的回归斜率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    G, N, npar, VA, Ve = cfg["n_gen"] + 1, cfg["n_per_gen"], cfg["n_parents"], cfg["VA"], cfg["Ve"]
    n = G * N
    gen = np.repeat(np.arange(G), N)
    sire = -np.ones(n, int); dam = -np.ones(n, int)
    A = np.zeros((n, n)); F = np.zeros(n)
    a = np.zeros(n); y = np.zeros(n)
    A[:N, :N] = np.eye(N)
    a[:N] = rng.normal(0, np.sqrt(VA), N)
    y[:N] = a[:N] + rng.normal(0, np.sqrt(Ve), N)
    selected = np.zeros(n, bool)
    for g in range(1, G):
        prev = np.arange((g - 1) * N, g * N)
        par = prev[np.argsort(-y[prev])[:npar]]
        selected[par] = True
        for i in range(g * N, (g + 1) * N):
            s, d = rng.choice(par, 2, replace=False)
            sire[i], dam[i] = s, d
            row = 0.5 * (A[s, :i] + A[d, :i])
            A[i, :i] = row; A[:i, i] = row
            F[i] = 0.5 * A[s, d]; A[i, i] = 1 + F[i]
            sd = np.sqrt(max(VA * 0.5 * (1 - 0.5 * (F[s] + F[d])), 1e-12))
            a[i] = 0.5 * (a[s] + a[d]) + rng.normal(0, sd)
            y[i] = a[i] + rng.normal(0, np.sqrt(Ve))
    selected[(G - 1) * N:] = True     # 最后一代全部保留记录
    return gen, a, y, A, selected


def animal_blup(A, y, mask, VA, Ve):
    """mask 指示有记录的动物；X=1（总均值固定）。MME：[X'X X'Z; Z'X Z'Z+λA⁻¹]。"""
    n = len(y); lam = Ve / VA
    Ainv = np.linalg.inv(A)
    idx = np.where(mask)[0]
    Z = np.zeros((len(idx), n)); Z[np.arange(len(idx)), idx] = 1
    X = np.ones((len(idx), 1))
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * Ainv]])
    rhs = np.r_[X.T @ y[idx], Z.T @ y[idx]]
    sol = np.linalg.solve(C, rhs)
    return sol[1:]


def main():
    cfg = json.load(open(HERE / "data" / "ex21_18_selection.json"))
    rng = np.random.default_rng(cfg["seed"])
    VA, Ve = cfg["VA"], cfg["Ve"]; h2 = VA / (VA + Ve)
    G = cfg["n_gen"] + 1; N = cfg["n_per_gen"]
    methods = ["A 全系谱+全记录", "B 无系谱(本代内)", "C 全系谱+删淘汰者记录", "D 无系谱不调代"]
    bias = {m: np.zeros((cfg["n_rep"], G)) for m in methods}
    corr = {m: [] for m in methods}; slope = {m: [] for m in methods}
    true_gain = np.zeros((cfg["n_rep"], G))
    for r in range(cfg["n_rep"]):
        gen, a, y, A, selected = simulate(cfg, rng)
        ones = np.ones(len(y), bool)
        est = {}
        est[methods[0]] = animal_blup(A, y, ones, VA, Ve)
        gm = np.array([y[gen == g].mean() for g in range(G)])
        est[methods[1]] = h2 * (y - gm[gen])
        est[methods[2]] = animal_blup(A, y, selected, VA, Ve)
        est[methods[3]] = h2 * (y - y.mean())
        tmean = np.array([a[gen == g].mean() for g in range(G)])
        true_gain[r] = tmean - tmean[0]
        last = gen == G - 1
        for m in methods:
            e = est[m]
            emean = np.array([e[gen == g].mean() for g in range(G)])
            bias[m][r] = (emean - emean[0]) - (tmean - tmean[0])
            corr[m].append(np.corrcoef(e[last], a[last])[0, 1])
            e0 = e[last] - e[last].mean(); a0 = a[last] - a[last].mean()
            slope[m].append((e0 @ a0) / (e0 @ e0))       # u 对 û 回归斜率
    print("=" * 84)
    print("习题 21.18  选择下的 BLUP   h²=%.2f, %d 世代 × %d 头, 每代选 %d 头亲本, %d 次重复" % (h2, G, N, cfg["n_parents"], cfg["n_rep"]))
    print("=" * 84)
    print(f"平均真实遗传趋势（相对第0代）：" + " ".join(f"{v:6.2f}" for v in true_gain.mean(0)))
    print(f"{'方法':<22}{'末代趋势偏差':>12}{'(MC SE)':>9}{'末代EBV与真值相关':>16}{'u对û斜率':>10}")
    out = {}
    for m in methods:
        b = bias[m][:, -1]
        print(f"{m:<22}{b.mean():12.3f}{b.std(ddof=1)/np.sqrt(len(b)):9.3f}{np.mean(corr[m]):16.3f}{np.mean(slope[m]):10.3f}")
        out[m] = dict(trend_bias_last=float(b.mean()), se=float(b.std(ddof=1) / np.sqrt(len(b))), corr=float(np.mean(corr[m])), slope=float(np.mean(slope[m])),
                      bias_by_gen=bias[m].mean(0).tolist())
    # 核验：A 无偏（|bias|<3 SE）；B、D 趋势偏差为负且显著（D 完全忽略世代）
    sa = out[methods[0]]
    assert abs(sa["trend_bias_last"]) < 4 * sa["se"] + 0.05
    assert out[methods[3]]["trend_bias_last"] < -1.0
    assert abs(out[methods[1]]["trend_bias_last"]) > 1.0     # 无系谱无法恢复遗传趋势
    print("\n逐代趋势偏差（均值）：")
    for m in methods:
        print(f"  {m:<22}" + " ".join(f"{v:6.2f}" for v in bias[m].mean(0)))
    out["true_gain"] = true_gain.mean(0).tolist()
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex21_18_selection_bias.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
