#!/usr/bin/env python3
"""习题 21.17  可估计性与遗传连通：联结公畜数对跨场比较的影响

设计：H 个场，每场各有 m_own 头本场专用公畜和 L 头跨场“联结公畜”（每场各有后代），每个“场×公畜”格有 n 个后代。
1. 把场与公畜都设为固定效应时，用设计矩阵秩与二部图连通分量数判断可估计性：L=0 时各场互不连通，跨场公畜差不可估；
2. 公畜设为随机效应（已知方差比），计算本场专用公畜在不同场之间的差异的 PEV，以及公畜 BLUP 的平均可靠度；
3. 蒙特卡罗：每次重复按模型生成资料（场效应方差大），比较跨场比较的经验误差方差与 PEV，并统计“跨场正确排序概率”；
核验：经验误差方差与 PEV 的相对差 < 10%。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.sparse.csgraph import connected_components
from scipy.sparse import csr_matrix

HERE = Path(__file__).resolve().parent


def design(H, m_own, L, n):
    sires_own = [[h * m_own + j for j in range(m_own)] for h in range(H)]
    S = H * m_own + L
    link = list(range(H * m_own, S))
    rows = []
    for h in range(H):
        for s in sires_own[h] + link:
            rows += [(h, s)] * n
    herd = np.array([r[0] for r in rows]); sire = np.array([r[1] for r in rows])
    return herd, sire, S, sires_own


def components(herd, sire, H, S):
    A = np.zeros((H + S, H + S))
    A[herd, H + sire] = 1; A = A + A.T
    nc, lab = connected_components(csr_matrix(A), directed=False)
    used = set(herd.tolist()) | set((H + sire).tolist())
    return len({lab[i] for i in used})


def mme(herd, sire, H, S, k, y=None):
    N = len(herd)
    X = np.zeros((N, H)); X[np.arange(N), herd] = 1
    Z = np.zeros((N, S)); Z[np.arange(N), sire] = 1
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + k * np.eye(S)]])
    Cinv = np.linalg.inv(C)
    if y is None:
        return Cinv, X, Z
    sol = Cinv @ np.r_[X.T @ y, Z.T @ y]
    return sol[:H], sol[H:], Cinv


def main():
    cfg = json.load(open(HERE / "data" / "ex21_17_design.json"))
    rng = np.random.default_rng(cfg["seed"])
    H, m, n = cfg["n_herd"], cfg["own_sires_per_herd"], cfg["progeny_per_cell"]
    vs, ve = cfg["var_sire"], cfg["var_e"]; k = ve / vs
    print("=" * 84)
    print("习题 21.17  联结公畜数与跨场比较   H=%d, 每场专用公畜 %d, 每格 %d 个后代" % (H, m, n))
    print("=" * 84)
    print(f"{'L':>3}{'连通分量':>8}{'固定模型秩':>10}{'跨场差可估':>10}{'固定模型方差':>12}{'专用公畜平均可靠度':>18}{'跨场差 PEV':>11}{'同场差 PEV':>11}{'经验MSE':>9}{'跨场排序正确率':>13}")
    res = []
    for L in cfg["link_list"]:
        herd, sire, S, own = design(H, m, L, n)
        nc = components(herd, sire, H, S)
        N = len(herd)
        Xf = np.zeros((N, H + S)); Xf[np.arange(N), herd] = 1; Xf[np.arange(N), H + sire] = 1
        rank = np.linalg.matrix_rank(Xf)
        full_rank_exp = H + S - nc            # 二部图：秩 = 节点数 − 连通分量数
        assert rank == full_rank_exp, (rank, full_rank_exp)
        # 固定模型：跨场公畜差是否可估及其方差（广义逆；可估 ⇔ d 在设计矩阵行空间内）
        dfull = np.zeros(H + S); dfull[H + own[0][0]] = 1; dfull[H + own[1][0]] = -1
        Gm = np.linalg.pinv(Xf.T @ Xf)
        proj = Xf.T @ Xf @ Gm
        estimable = bool(np.allclose(proj @ dfull, dfull, atol=1e-8))
        var_fixed = float(ve * dfull @ Gm @ dfull) if estimable else float("inf")
        Cinv, X, Z = mme(herd, sire, H, S, k)
        C22 = ve * Cinv[H:, H:]
        rel_own = np.mean([1 - C22[s, s] / vs for h in range(H) for s in own[h]])
        a, b, c = own[0][0], own[1][0], own[0][1]
        d_cross = np.zeros(S); d_cross[a], d_cross[b] = 1, -1
        d_same = np.zeros(S); d_same[a], d_same[c] = 1, -1
        pev_cross = d_cross @ C22 @ d_cross; pev_same = d_same @ C22 @ d_same
        # MC
        errs, correct = [], []
        for _ in range(cfg["n_rep"]):
            hv = rng.normal(0, cfg["herd_sd"], H); sv = rng.normal(0, np.sqrt(vs), S)
            y = 100 + hv[herd] + sv[sire] + rng.normal(0, np.sqrt(ve), N)
            bh, sh, _ = mme(herd, sire, H, S, k, y)
            errs.append((sh[a] - sh[b]) - (sv[a] - sv[b]))
            correct.append(np.sign(sh[a] - sh[b]) == np.sign(sv[a] - sv[b]))
        mse = float(np.mean(np.square(errs)))
        assert abs(mse - pev_cross) / pev_cross < 0.15, (L, mse, pev_cross)
        print(f"{L:3d}{nc:8d}{rank:10d}{'是' if estimable else '否':>10}{var_fixed:12.3f}{rel_own:18.3f}{pev_cross:11.3f}{pev_same:11.3f}{mse:9.3f}{np.mean(correct):13.3f}")
        res.append(dict(L=L, components=nc, rank=int(rank), n_cols=H + S, estimable=estimable, var_fixed=var_fixed, rel_own=float(rel_own), pev_cross=float(pev_cross),
                        pev_same=float(pev_same), mse_emp=mse, p_correct=float(np.mean(correct))))
    print("\n说明：固定模型设计矩阵秩 = 场数+公畜数−连通分量数；L=0 时有 4 个互不连通分量，跨场公畜差不可估（方差无穷）；")
    print("随机公畜模型下总可预测，但 PEV 与联结公畜数、场内后代数共同决定可信程度。")
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(res, open(HERE / "results" / "ex21_17_connectedness.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
