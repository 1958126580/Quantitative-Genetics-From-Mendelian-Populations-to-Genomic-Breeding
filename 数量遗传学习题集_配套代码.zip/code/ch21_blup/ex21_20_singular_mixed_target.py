#!/usr/bin/env python3
"""习题 21.20  奇异协方差与固定+随机混合目标的最优预测

8 个动物，其中 (0,1)、(2,3) 为克隆（随机效应完全相等），G = σ_u² K 的秩为 6 < 8，G⁻¹ 不存在。
y = Xb + Zu + e，b = (场1、场2；性别) 固定。内容：
  1. V 形式 û = G Z'V⁻¹(y−Xb̂) 不需要 G⁻¹，直接可用；
  2. 降维混合模型方程：u = L w，L（8×6）为 K 的满列秩因子（把克隆合并），w 的协方差 σ_u² I，用 MME 求 ŵ，û = Lŵ，与 V 形式一致；
  3. 岭近似：G_ε = G + εI 的 MME，ε→0 时 û 收敛到奇异解，同时条件数急剧增大（数值稳定性代价）；
  4. 混合目标 θ = k'b + m'u（如“场 1、雌性条件下动物 3 的期望表现”）的 BLUP，其预测误差方差
     Var(θ̂−θ) = [k' m'] 的联合误差矩阵二次型（含固定估计与随机预测误差的交叉项），并蒙特卡罗核对；
  5. 比较 PEV(θ̂) 与误用 Var(k'b̂)+PEV(m'û)（忽略交叉项）的差别。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import linalg

HERE = Path(__file__).resolve().parent


def build(cfg):
    n = len(cfg["animal_herd"])
    rows = []
    for i, nr in enumerate(cfg["n_records"]):
        rows += [i] * nr
    ani = np.array(rows); N = len(ani)
    X = np.zeros((N, 3))
    X[np.arange(N), np.array(cfg["animal_herd"])[ani]] = 1      # 场 0/1 → 前两列
    X[:, 2] = np.array(cfg["animal_sex"])[ani]                   # 性别（0/1）作协变量
    Z = np.zeros((N, n)); Z[np.arange(N), ani] = 1
    K = np.eye(n)
    for grp in cfg["clone_groups"]:
        for i in grp:
            for j in grp:
                K[i, j] = 1
    return X, Z, K, ani


def lfactor(K, tol=1e-10):
    ev, U = np.linalg.eigh(K)
    keep = ev > tol
    return U[:, keep] * np.sqrt(ev[keep])


def v_form(X, Z, G, ve, y):
    N = len(y)
    V = Z @ G @ Z.T + ve * np.eye(N)
    Vi = np.linalg.inv(V)
    XtViX = X.T @ Vi @ X
    b = np.linalg.solve(XtViX, X.T @ Vi @ y)
    u = G @ Z.T @ Vi @ (y - X @ b)
    P = Vi - Vi @ X @ np.linalg.solve(XtViX, X.T @ Vi)
    return b, u, XtViX, Vi, P


def main():
    cfg = json.load(open(HERE / "data" / "ex21_20_singular.json"))
    rng = np.random.default_rng(cfg["seed"])
    X, Z, K, ani = build(cfg)
    N, n = Z.shape; vu, ve = cfg["var_u"], cfg["var_e"]
    G = vu * K
    rk = np.linalg.matrix_rank(G)
    assert rk == n - len(cfg["clone_groups"])
    beta_true = np.array([cfg["mu"] + cfg["herd_effect"][0], cfg["mu"] + cfg["herd_effect"][1], cfg["sex_effect"][1]])
    L = lfactor(K)
    u_true = np.sqrt(vu) * (L @ rng.standard_normal(L.shape[1]))
    assert abs(u_true[0] - u_true[1]) < 1e-12
    y = X @ beta_true + Z @ u_true + rng.normal(0, np.sqrt(ve), N)

    b_v, u_v, XtViX, Vi, P = v_form(X, Z, G, ve, y)

    # 降维 MME
    ZL = Z @ L
    C = np.block([[X.T @ X, X.T @ ZL], [ZL.T @ X, ZL.T @ ZL + (ve / vu) * np.eye(L.shape[1])]])
    sol = linalg.solve(C, np.r_[X.T @ y, ZL.T @ y], assume_a="sym")
    b_r = sol[:3]; u_r = L @ sol[3:]
    assert np.allclose(b_r, b_v, atol=1e-8) and np.allclose(u_r, u_v, atol=1e-8)

    # 岭近似
    print("=" * 76)
    print("习题 21.20  奇异协方差（rank G = %d / %d）与混合目标" % (rk, n))
    print("=" * 76)
    print("V 形式 û =", np.round(u_v, 3))
    print("克隆对 û_0−û_1 =", f"{u_v[0]-u_v[1]:.2e}", " û_2−û_3 =", f"{u_v[2]-u_v[3]:.2e}")
    print(f"{'ε':>8}{'max|û_ε − û|':>16}{'cond(C_ε)':>14}")
    ridge = []
    for eps in cfg["eps_list"]:
        Ge = G + eps * np.eye(n)
        Ginv = np.linalg.inv(Ge)
        Ce = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + ve * Ginv]])
        se = np.linalg.solve(Ce, np.r_[X.T @ y, Z.T @ y])
        err = np.max(np.abs(se[3:] - u_v))
        ridge.append(dict(eps=eps, err=float(err), cond=float(np.linalg.cond(Ce))))
        print(f"{eps:8.0e}{err:16.3e}{np.linalg.cond(Ce):14.3e}")
    assert ridge[-2]["err"] < 1e-3

    # 混合目标：场1(列0)、雌性(性别=0) 的动物 3（索引 2）：θ = b0 + u_2
    kvec = np.array([1.0, 0, 0]); mvec = np.zeros(n); mvec[2] = 1
    theta_hat = kvec @ b_v + mvec @ u_v
    # 误差协方差：b̂−b 与 û−u 的联合
    Var_b = np.linalg.inv(XtViX)
    # û−u = G Z'P e_* …… 用公式 Cov(b̂−b, û−u)：
    #   b̂−b = (X'V⁻¹X)⁻¹X'V⁻¹(Zu+e−...)；û−u = GZ'P(Zu+e) − u。精确推导用联合矩阵（降维 MME 的逆）：
    Cinv = np.linalg.inv(C)
    # Cinv 对应 (b̂−b, ŵ−w) 的误差协方差 / σ_e²（固定效应 b 作为无先验的）
    Cb = ve * Cinv[:3, :3]; Cbw = ve * Cinv[:3, 3:]; Cw = ve * Cinv[3:, 3:]
    Cbu = Cbw @ L.T; Cu = L @ Cw @ L.T
    assert np.allclose(Cb, Var_b, atol=1e-8)
    assert np.allclose(Cu, G - G @ Z.T @ P @ Z @ G, atol=1e-8), "PEV 矩阵与 V 形式不一致"
    pev_joint = kvec @ Cb @ kvec + 2 * kvec @ Cbu @ mvec + mvec @ Cu @ mvec
    pev_naive = kvec @ Cb @ kvec + mvec @ Cu @ mvec
    # 蒙特卡罗
    errs = []
    for _ in range(cfg["n_rep"]):
        ut = np.sqrt(vu) * (L @ rng.standard_normal(L.shape[1]))
        yy = X @ beta_true + Z @ ut + rng.normal(0, np.sqrt(ve), N)
        b1, u1, *_ = v_form(X, Z, G, ve, yy)
        errs.append((kvec @ b1 + mvec @ u1) - (kvec @ beta_true + mvec @ ut))
    errs = np.array(errs)
    print(f"\n混合目标 θ=b_场1+u_3：θ̂={theta_hat:.3f}；PEV(联合，含交叉项)={pev_joint:.4f}；忽略交叉项={pev_naive:.4f}；MC 经验={errs.var():.4f}；MC 偏差={errs.mean():+.4f}")
    print(f"交叉项贡献 2k'C_bu m = {2*kvec@Cbu@mvec:+.4f}；Var(k'b̂)={kvec@Cb@kvec:.4f}，PEV(u_3)={mvec@Cu@mvec:.4f}")
    assert abs(errs.var() - pev_joint) / pev_joint < 0.08
    assert abs(errs.mean()) < 5 * errs.std() / np.sqrt(len(errs))
    # 克隆对的差异预测误差
    d = np.zeros(n); d[0], d[1] = 1, -1
    print("克隆对 u_0−u_1 的 PEV =", f"{d@Cu@d:.2e}", "（模型规定二者恒等）；非克隆对 u_4−u_5 的 PEV =", f"{(lambda e: e@Cu@e)(np.eye(n)[4]-np.eye(n)[5]):.3f}")
    out = dict(rank=int(rk), b_hat=b_v.tolist(), u_hat=u_v.tolist(), theta_hat=float(theta_hat), pev_joint=float(pev_joint), pev_naive=float(pev_naive),
               mc_var=float(errs.var()), ridge=ridge)
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex21_20_singular_mixed_target.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
