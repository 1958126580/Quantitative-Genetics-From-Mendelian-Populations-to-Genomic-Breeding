#!/usr/bin/env python3
"""习题 12.19  由系谱估计近交速率与有效群体大小：世代间回归、个体近交增量法

模拟闭锁群体（每代 5 公 25 母、随机选择后代为亲本、离散世代）12 代，重复 20 次。
    (1) 理论：N_e = 4 N_m N_f /(N_m + N_f)，ΔF = 1/(2N_e)；
    (2) 世代平均近交的变化 ΔF_t = (F_t − F_{t−1})/(1 − F_{t−1})；
    (3) 个体近交增量（Gutiérrez 等 2009）ΔF_i = 1 − (1 − F_i)^{1/(t_i − 1)}，t_i 为等价完整世代数，
        N_e = 1/(2 mean ΔF_i)；
比较三者：随机选留（家系大小近似泊松）时三者一致；若家系贡献方差增大（如按家系选择），实际 N_e 会低于性别比公式。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def run(cfg, rng):
    nb = cfg["males"] + cfg["females"]; ped = [(-1, -1)] * nb; gen = [0] * nb
    males, females = list(range(cfg["males"])), list(range(cfg["males"], nb))
    for g in range(1, cfg["generations"] + 1):
        new = []
        for _ in range(cfg["offspring_per_gen"]):
            ped.append((int(rng.choice(males)), int(rng.choice(females)))); gen.append(g); new.append(len(ped) - 1)
        perm = rng.permutation(new); males = list(perm[:cfg["males"]]); females = list(perm[cfg["males"]:cfg["males"] + cfg["females"]])
    n = len(ped); A = np.zeros((n, n))
    for i, (s, d) in enumerate(ped):
        for j in range(i):
            A[i, j] = A[j, i] = 0.5 * ((A[j, s] if s >= 0 else 0) + (A[j, d] if d >= 0 else 0))
        A[i, i] = 1 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0)
    return np.diag(A) - 1, np.array(gen)


def main():
    cfg = json.loads((HERE / "data" / "ex12_19_ne.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); Nm, Nf = cfg["males"], cfg["females"]
    Ne_th = 4 * Nm * Nf / (Nm + Nf); G = cfg["generations"]; dF_gen, dF_ind = [], []
    for _ in range(cfg["reps"]):
        F, gen = run(cfg, rng)
        Fm = np.array([F[gen == g].mean() for g in range(G + 1)])
        dF_gen.append(np.mean([(Fm[t] - Fm[t - 1]) / (1 - Fm[t - 1]) for t in range(4, G + 1)]))
        last = gen == G; t = G                    # 完整系谱：等价完整世代数 = G
        dF_ind.append(np.mean(1 - (1 - F[last]) ** (1 / (t - 1))))
    dg, di = float(np.mean(dF_gen)), float(np.mean(dF_ind))
    print(f"性别比公式：N_e = {Ne_th:.2f}，ΔF = {1/(2*Ne_th):.4f}")
    print(f"世代平均近交变化（第4—{G}代）：ΔF = {dg:.4f}，N_e = {1/(2*dg):.2f}")
    print(f"个体近交增量法（末代）：ΔF = {di:.4f}，N_e = {1/(2*di):.2f}")
    out = {"Ne_sexratio": Ne_th, "dF_generation": dg, "Ne_generation": 1 / (2 * dg), "dF_individual": di, "Ne_individual": 1 / (2 * di)}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex12_19_inbreeding_rate.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
