#!/usr/bin/env python3
"""习题 12.20  系谱审计：建模之前必须发现的错误类型

逐项检查原始系谱表：
    (1) 重复 ID（完全重复与冲突重复）；(2) 自身为自身亲本；(3) 性别冲突（雌性作父亲、雄性作母亲）；
    (4) 亲本比后代年轻或同龄（出生年不合理）；(5) 亲本 ID 未出现在系谱中（未知亲本，需补为创始者或置空）；
    (6) 循环（个体是自身祖先）；(7) 能否拓扑排序（父母在前）。
输出问题清单与可用于计算 A 的清理后系谱（问题记录置为未知亲本，并标注）。
"""
from __future__ import annotations
import csv, json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    rows = list(csv.DictReader(open(HERE / "data" / "ex12_20_pedigree_raw.csv", encoding="utf-8")))
    issues = []; seen = {}
    for r in rows:
        key = r["id"]
        if key in seen:
            same = seen[key] == r
            issues.append(("重复ID" + ("（完全相同，可删除）" if same else "（内容冲突）"), key)); continue
        seen[key] = r
    ped = {k: dict(v) for k, v in seen.items()}
    for k, r in ped.items():
        for role, sex_need in (("sire", "M"), ("dam", "F")):
            p = r[role]
            if not p: continue
            if p == k: issues.append((f"自身为{ '父' if role=='sire' else '母' }亲", k)); r[role] = ""; continue
            if p not in ped: issues.append((f"{'父' if role=='sire' else '母'}亲 {p} 不在系谱中（补为创始者）", k)); continue
            if ped[p]["sex"] != sex_need: issues.append((f"性别冲突：{p} 性别 {ped[p]['sex']} 却作{'父' if role=='sire' else '母'}亲", k)); r[role] = ""; continue
            if int(ped[p]["birth_year"]) >= int(r["birth_year"]): issues.append((f"出生年不合理：{'父' if role=='sire' else '母'}亲 {p}({ped[p]['birth_year']}) 不早于后代({r['birth_year']})", k)); r[role] = ""
    # 补缺失创始者
    for k in list(ped):
        for role in ("sire", "dam"):
            p = ped[k][role]
            if p and p not in ped: ped[p] = {"id": p, "sire": "", "dam": "", "sex": "M" if role == "sire" else "F", "birth_year": "0"}
    # 循环检测 + 拓扑排序（Kahn）
    order, state = [], {}
    def visit(v, stack):
        if state.get(v) == 2: return True
        if state.get(v) == 1: issues.append(("循环", "→".join(stack + [v]))); return False
        state[v] = 1
        for p in (ped[v]["sire"], ped[v]["dam"]):
            if p: visit(p, stack + [v])
        state[v] = 2; order.append(v); return True
    for v in sorted(ped): visit(v, [])
    print("发现的问题：")
    for t, k in issues: print(f"  [{k}] {t}")
    print("拓扑排序后的系谱（父母在前）：")
    for v in order: print(f"  {v}: 父 {ped[v]['sire'] or '-'}，母 {ped[v]['dam'] or '-'}")
    out = {"issues": [{"id": k, "type": t} for t, k in issues], "clean_order": order, "clean_pedigree": {v: [ped[v]["sire"], ped[v]["dam"]] for v in order}}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex12_20_pedigree_audit.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
