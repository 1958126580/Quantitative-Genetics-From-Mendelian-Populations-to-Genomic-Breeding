# 第12章　系谱亲缘、近交与遗传连接——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex12_15_ainverse.py
python3 ex12_16_path_method.py
python3 ex12_17_pedigree_completeness.py
python3 ex12_18_connectedness.py
python3 ex12_19_inbreeding_rate.py
python3 ex12_20_pedigree_audit.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex12_15_ainverse.py | 12.15 | 含近交的 A 与 A⁻¹：表格法、LDLᵀ 分解与 Henderson–Quaas 规则 |
| ex12_16_path_method.py | 12.16 | Wright 通径法计算近交系数：枚举经共同祖先的全部路径，并与表格法核对 |
| ex12_17_pedigree_completeness.py | 12.17 | 系谱完整度与近交系数的低估：等价完整世代数与 MacCluer 完整度指数 |
| ex12_18_connectedness.py | 12.18 | 场间遗传连接：共同公畜数如何决定场效应差与跨场公畜比较的精度 |
| ex12_19_inbreeding_rate.py | 12.19 | 由系谱估计近交速率与有效群体大小：世代间回归、个体近交增量法 |
| ex12_20_pedigree_audit.py | 12.20 | 系谱审计：建模之前必须发现的错误类型 |
