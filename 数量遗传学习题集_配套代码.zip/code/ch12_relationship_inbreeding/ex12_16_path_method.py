#!/usr/bin/env python3
"""习题 12.16  Wright 通径法计算近交系数：枚举经共同祖先的全部路径，并与表格法核对

F_X = Σ_路径 (1/2)^{n1 + n2 + 1} (1 + F_A)，其中路径为 X 的父亲 → … → 共同祖先 A ← … ← X 的母亲，
n1、n2 为两侧代数，路径中除共同祖先外不得重复经过同一个体。
程序对习题 12.15 系谱中的个体 12 列出全部路径及贡献，验证总和等于表格法的 F_12。
"""
from __future__ import annotations
import csv, json
from pathlib import Path
import numpy as np
import importlib.util

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("a", HERE / "ex12_15_ainverse.py"); mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)


def ancestors_paths(ped, start):
    """返回从 start 向上的所有路径（含 start 本身），每条路径为个体索引列表。"""
    out = [[start]]; s, d = ped[start]
    for p in (s, d):
        if p >= 0:
            for path in ancestors_paths(ped, p): out.append([start] + path)
    return out


def main():
    ids, ped = mod.read_ped(); A = mod.tabular(ped); F = np.diag(A) - 1
    target = ids.index(12); s, d = ped[target]
    up_s = ancestors_paths(ped, s); up_d = ancestors_paths(ped, d)
    total, rows = 0.0, []
    for ps in up_s:
        for pd in up_d:
            if ps[-1] != pd[-1]: continue                      # 必须终于同一共同祖先
            if set(ps[:-1]) & set(pd[:-1]): continue          # 两侧除共同祖先外不得交叠
            a = ps[-1]; n1, n2 = len(ps) - 1, len(pd) - 1
            c = 0.5 ** (n1 + n2 + 1) * (1 + F[a]); total += c
            path = "→".join(str(ids[i]) for i in ps) + " | " + "→".join(str(ids[i]) for i in pd)
            rows.append({"path": path, "ancestor": ids[a], "n1": n1, "n2": n2, "F_A": float(F[a]), "contribution": c})
    for r in sorted(rows, key=lambda r: -r["contribution"]):
        print(f"  {r['path']:<32s} 祖先 {r['ancestor']:>2d}  n1+n2+1 = {r['n1']+r['n2']+1}  F_A = {r['F_A']:.4f}  贡献 {r['contribution']:.6f}")
    print(f"通径法 F_12 = {total:.6f}；表格法 F_12 = {F[target]:.6f}；路径数 {len(rows)}")
    assert np.isclose(total, F[target])
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex12_16_path_method.json").write_text(json.dumps({"paths": rows, "F_path": total, "F_tabular": float(F[target])}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
