#!/usr/bin/env python3
"""习题 12.15  含近交的 A 与 A⁻¹：表格法、LDLᵀ 分解与 Henderson–Quaas 规则

    A = T D Tᵀ，T 为下三角“祖先传递”矩阵，D = diag(b_i)，孟德尔抽样系数
        b_i = 1/2 − (F_s + F_d)/4（双亲已知），3/4 − F_p/4（单亲已知），1（双亲未知）
    A⁻¹ = (T⁻¹)ᵀ D⁻¹ T⁻¹，T⁻¹ 每行只有 3 个非零元（1, −1/2, −1/2）
Henderson 规则：对每个个体 i 加 δ = 1/b_i 到 (i,i)，−δ/2 到 (i,s)(i,d)，δ/4 到 (s,s)(d,d)(s,d)。
程序比较三种方法、验证 A·A⁻¹ = I，并统计 A 与 A⁻¹ 的非零元数目。
"""
from __future__ import annotations
import csv, json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def read_ped():
    rows = list(csv.DictReader(open(HERE / "data" / "ex12_15_pedigree.csv", encoding="utf-8")))
    idx = {int(r["id"]): k for k, r in enumerate(rows)}
    return [int(r["id"]) for r in rows], [(idx.get(int(r["sire"]), -1), idx.get(int(r["dam"]), -1)) for r in rows]


def tabular(ped):
    n = len(ped); A = np.zeros((n, n))
    for i, (s, d) in enumerate(ped):
        assert s < i and d < i, "系谱须父母在前"
        for j in range(i):
            A[i, j] = A[j, i] = 0.5 * ((A[j, s] if s >= 0 else 0) + (A[j, d] if d >= 0 else 0))
        A[i, i] = 1 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0)
    return A


def henderson(ped, F):
    n = len(ped); Ai = np.zeros((n, n)); b = np.zeros(n)
    for i, (s, d) in enumerate(ped):
        if s >= 0 and d >= 0: b[i] = 0.5 - 0.25 * (F[s] + F[d])
        elif s >= 0 or d >= 0: b[i] = 0.75 - 0.25 * F[max(s, d)]
        else: b[i] = 1.0
        dl = 1 / b[i]; Ai[i, i] += dl
        for p in (s, d):
            if p >= 0:
                Ai[i, p] -= dl / 2; Ai[p, i] -= dl / 2
                for q in (s, d):
                    if q >= 0: Ai[p, q] += dl / 4
    return Ai, b


def main():
    ids, ped = read_ped(); n = len(ped)
    A = tabular(ped); F = np.diag(A) - 1
    Ai, b = henderson(ped, F)
    Tinv = np.eye(n)
    for i, (s, d) in enumerate(ped):
        for p in (s, d):
            if p >= 0: Tinv[i, p] -= 0.5
    T = np.linalg.inv(Tinv)
    assert np.allclose(T @ np.diag(b) @ T.T, A), "TDTᵀ 分解与表格法不一致"
    assert np.allclose(Tinv.T @ np.diag(1 / b) @ Tinv, Ai), "Henderson 规则与分解不一致"
    assert np.allclose(A @ Ai, np.eye(n), atol=1e-10)
    print("近交系数：", {ids[i]: round(float(F[i]), 5) for i in range(n) if F[i] > 0})
    print("孟德尔抽样系数 b：", {ids[i]: round(float(b[i]), 5) for i in range(n)})
    nzA, nzAi = int(np.sum(np.abs(A) > 1e-12)), int(np.sum(np.abs(Ai) > 1e-12))
    print(f"A 非零元 {nzA}/{n*n}，A⁻¹ 非零元 {nzAi}/{n*n}")
    print("A⁻¹（保留3位）:\n", np.round(Ai, 3))
    out = {"ids": ids, "F": F.tolist(), "b": b.tolist(), "A": A.round(6).tolist(), "Ainv": Ai.round(6).tolist(), "nnz_A": nzA, "nnz_Ainv": nzAi}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex12_15_ainverse.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
