#!/usr/bin/env python3
"""习题 12.18  场间遗传连接：共同公畜数如何决定场效应差与跨场公畜比较的精度

公畜模型 y = 场(固定) + 公畜(随机, σ_s² = σ_A²/4) + e，λ = σ_e²/σ_s² = (4 − h²)/h²。
两场各用 6 头公畜，每头在其使用的场中有 20 个后代；其中 k 头“连接公畜”同时在两场使用（每场 20 个后代）。
由混合模型方程逆矩阵 C⁻¹ 计算：
    场效应差的 PEV(ĥ1 − ĥ2) 及与无亲缘、无连接时的比较；
    不同场两头公畜之间比较的 PEV 与“差异决定系数” CD = 1 − PEV(差)/Var(差)；
    以及连接度的 Kennedy & Trus 型指标。k = 0 时场差不可从资料中由公畜差分开，只能依赖公畜为随机效应的先验。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def build(k, cfg):
    S = cfg["sires_per_herd"]; m = cfg["progeny_per_sire_per_herd"]; lam = (4 - cfg["h2"]) / cfg["h2"]
    # 公畜编号：场1专用 S−k，场2专用 S−k，连接 k（两场都用）
    sires1 = list(range(S)); sires2 = list(range(S - k, 2 * S - k)); ns = 2 * S - k
    rows = [(0, s) for s in sires1 for _ in range(m)] + [(1, s) for s in sires2 for _ in range(m)]
    X = np.zeros((len(rows), 2)); Z = np.zeros((len(rows), ns))
    for i, (h, s) in enumerate(rows): X[i, h] = 1; Z[i, s] = 1
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * np.eye(ns)]])
    return np.linalg.inv(C), ns, sires1, sires2, lam


def main():
    cfg = json.loads((HERE / "data" / "ex12_18_connect.json").read_text(encoding="utf-8"))
    out = []
    print(f"h² = {cfg['h2']}，λ = {(4-cfg['h2'])/cfg['h2']:.0f}（以 σ_e² = 1 为单位）")
    print(f"{'连接公畜':>8s}{'PEV(场差)':>11s}{'跨场公畜比较 PEV':>16s}{'CD':>8s}{'同场公畜比较 PEV':>16s}")
    for k in cfg["link_sires"]:
        Ci, ns, s1, s2, lam = build(k, cfg)
        pev_h = Ci[0, 0] + Ci[1, 1] - 2 * Ci[0, 1]
        a, b = 2 + s1[0], 2 + s2[-1]                 # 场1 专用公畜 vs 场2 专用公畜
        pev_ab = Ci[a, a] + Ci[b, b] - 2 * Ci[a, b]; var_diff = 2 / lam   # σ_s² = σ_e²/λ
        cd = 1 - pev_ab / var_diff
        c, d = 2 + s1[0], 2 + s1[1]; pev_cd = Ci[c, c] + Ci[d, d] - 2 * Ci[c, d]
        out.append({"k": k, "pev_herd_diff": float(pev_h), "pev_cross_herd": float(pev_ab), "CD_cross": float(cd), "pev_within_herd": float(pev_cd)})
        print(f"{k:8d}{pev_h:11.5f}{pev_ab:16.5f}{cd:8.4f}{pev_cd:16.5f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex12_18_connectedness.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
