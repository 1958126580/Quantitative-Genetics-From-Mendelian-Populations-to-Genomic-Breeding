#!/usr/bin/env python3
"""习题 12.17  系谱完整度与近交系数的低估：等价完整世代数与 MacCluer 完整度指数

模拟一个闭锁小群体（每代 8 公 40 母，随机交配）8 代，计算真实（完整系谱）近交系数；
再以不同比例随机删除亲本记录（缺失视为未知亲本 = 基础群），重新计算近交系数。
    等价完整世代数 ECG_i = Σ_祖先 (1/2)^{g}，g 为祖先所在代数；
    MacCluer (1983) 完整度指数 PEC_i = 2 C_s C_d /(C_s + C_d)（两侧完整度的调和平均），C 为父/母侧前 d 代祖先已知比例的平均。
报告末代个体的平均 F、平均 ECG、PEC 及 F 的低估程度。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    ped, gen = [], []
    nf = cfg["males"] + cfg["females"]
    for i in range(nf): ped.append((-1, -1)); gen.append(0)
    males = list(range(cfg["males"])); females = list(range(cfg["males"], nf))
    for g in range(1, cfg["generations"] + 1):
        new = []
        for k in range(cfg["offspring_per_gen"]):
            s = int(rng.choice(males)); d = int(rng.choice(females)); ped.append((s, d)); gen.append(g); new.append(len(ped) - 1)
        males = new[:cfg["males"]]; females = new[cfg["males"]:]
    return ped, np.array(gen)


def inbreeding(ped):
    n = len(ped); A = np.zeros((n, n))
    for i, (s, d) in enumerate(ped):
        for j in range(i):
            A[i, j] = A[j, i] = 0.5 * ((A[j, s] if s >= 0 else 0) + (A[j, d] if d >= 0 else 0))
        A[i, i] = 1 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0)
    return np.diag(A) - 1


def ecg(ped, i, depth=0):
    s, d = ped[i]; tot = 0.0
    for p in (s, d):
        if p >= 0: tot += 0.5 + 0.5 * ecg(ped, p, depth + 1)
    return tot


def pec(ped, i, depth=4):
    def side(p):
        if p < 0: return 0.0
        known = []
        level = [p]
        for k in range(1, depth + 1):
            nxt = []
            for a in level:
                if a >= 0: nxt += list(ped[a])
                else: nxt += [-1, -1]
            known.append(np.mean([x >= 0 for x in nxt])); level = nxt
        return (1 + sum(known)) / (depth + 1)    # 含亲本自身
    s, d = ped[i]; cs, cd = side(s), side(d)
    return 0.0 if cs + cd == 0 else 2 * cs * cd / (cs + cd)


def main():
    cfg = json.loads((HERE / "data" / "ex12_17_sim.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); ped, gen = simulate(cfg, rng); last = np.where(gen == gen.max())[0]
    Ftrue = inbreeding(ped); out = []
    print(f"末代 {len(last)} 个个体；理论 ΔF ≈ 1/(2Ne)，Ne = 4·{cfg['males']}·{cfg['females']}/{cfg['males']+cfg['females']} = {4*cfg['males']*cfg['females']/(cfg['males']+cfg['females']):.1f}")
    print(f"{'缺失率':>6s}{'平均F':>9s}{'相对真值':>9s}{'平均ECG':>9s}{'平均PEC':>9s}")
    for m in cfg["missing_rates"]:
        ped2 = [(s if (s < 0 or rng.random() >= m) else -1, d if (d < 0 or rng.random() >= m) else -1) for s, d in ped]
        F2 = inbreeding(ped2); E = np.array([ecg(ped2, i) for i in last]); P = np.array([pec(ped2, i) for i in last])
        row = {"missing": m, "meanF": float(F2[last].mean()), "ratio": float(F2[last].mean() / Ftrue[last].mean()), "meanECG": float(E.mean()), "meanPEC": float(P.mean())}
        out.append(row)
        print(f"{m:6.1f}{row['meanF']:9.4f}{row['ratio']:9.3f}{row['meanECG']:9.2f}{row['meanPEC']:9.3f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex12_17_pedigree_completeness.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
