#!/usr/bin/env python3
"""习题 35.20  个体比较要用预测误差协方差：PEV_i+PEV_j−2PEC_ij，而不是看两个区间是否重叠

对候选羔羊两两比较（GBLUP 与系谱 BLUP）：
(1) 差值误差方差：精确 v_ij=PEV_i+PEV_j−2PEC_ij 与忽略 PEC 的 v⁰_ij=PEV_i+PEV_j；按"同父半同胞/无亲缘"分组报告平均 PEC；
(2) 差值 90% 区间覆盖率（精确、忽略 PEC）；
(3) 宣布"两者不同"的规则：精确 |û_i−û_j|>z√v_ij，与区间重叠法（两个 û±z√PEV 不重叠）；
    报告宣布比例（功效）与已宣布对中符号错误的比例；
(4) 组均值对比：10 只候选的平均育种值，用二次型 1ᵀ PEV 1/n² 与"独立假设" ΣPEV/n² 的误差方差对比，并核验覆盖率。
断言：精确法覆盖率在 0.87—0.93；GBLUP 下同父半同胞对的平均 PEC 大于无亲缘对；
区间重叠法宣布比例低于精确法；两法已宣布对的符号错误率都低于 0.15；组均值的二次型方差与实际误差方差之比在 0.7—1.4 之间。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _sim import simulate, tabular_A, vanraden_G, blup, split

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex35_20_config.json").read_text(encoding="utf-8"))
    z = cfg["level_z"]; gs = cfg["group_size"]
    names = {"G": "GBLUP", "A": "系谱 BLUP"}
    acc = {n: {k: [] for k in ["cov_exact", "cov_naive", "decl_exact", "decl_ovl", "sgn_exact", "sgn_ovl", "pec_hs", "pec_un", "pev", "grp_q", "grp_naive", "grp_mse", "grp_cov", "vr_hs", "cov_hs_exact", "cov_hs_naive"]} for n in names}
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
        train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"])
        Ks = {"A": tabular_A(d["sire"], d["dam"]), "G": vanraden_G(d["Z"], d["p"])}
        nc = len(cand); iu = np.triu_indices(nc, 1); sire = d["sire"][cand]; hs = (sire[iu[0]] == sire[iu[1]])
        for n, K in Ks.items():
            uh, pev = blup(K, train, cand, d["y"], d["sa2"], d["se2"]); u = d["u"][cand]
            pv = np.diag(pev); pec = pev[iu]
            v = pv[iu[0]] + pv[iu[1]] - 2 * pec; v0 = pv[iu[0]] + pv[iu[1]]
            dh = uh[iu[0]] - uh[iu[1]]; dt = u[iu[0]] - u[iu[1]]; e = dt - dh
            a = acc[n]
            a["cov_exact"].append(np.mean(np.abs(e) <= z * np.sqrt(v))); a["cov_naive"].append(np.mean(np.abs(e) <= z * np.sqrt(v0)))
            de = np.abs(dh) > z * np.sqrt(v)
            sd = np.sqrt(pv); do = (np.abs(dh) > z * (sd[iu[0]] + sd[iu[1]]))
            a["decl_exact"].append(de.mean()); a["decl_ovl"].append(do.mean())
            a["sgn_exact"].append(np.mean(np.sign(dh[de]) != np.sign(dt[de])) if de.any() else 0.0)
            a["sgn_ovl"].append(np.mean(np.sign(dh[do]) != np.sign(dt[do])) if do.any() else 0.0)
            a["pec_hs"].append(pec[hs].mean()); a["pec_un"].append(pec[~hs].mean()); a["pev"].append(pv.mean()); a["vr_hs"].append(np.mean(v0[hs] / v[hs])); a["cov_hs_exact"].append(np.mean(np.abs(e[hs]) <= z * np.sqrt(v[hs]))); a["cov_hs_naive"].append(np.mean(np.abs(e[hs]) <= z * np.sqrt(v0[hs])))
            # 组均值对比：同父的前 gs 只 vs 其余随机 gs 只，目标 = 两组均值之差
            idx = rng.permutation(nc); g1 = idx[:gs]; g2 = idx[gs:2 * gs]
            w = np.zeros(nc); w[g1] = 1 / gs; w[g2] = -1 / gs
            q = w @ pev @ w; naive = np.sum(w ** 2 * pv)
            err = w @ (u - uh)
            a["grp_q"].append(q); a["grp_naive"].append(naive); a["grp_mse"].append(err ** 2); a["grp_cov"].append(abs(err) <= z * np.sqrt(q))
    out = {}
    print(f"重复 {cfg['reps']} 次；候选 80 只，两两比较 {80*79//2} 对")
    for n in ("G", "A"):
        a = acc[n]; M = {k: float(np.mean(v)) for k, v in a.items()}; out[n] = M
        print(f"\n{names[n]}：平均 PEV {M['pev']:.3f}；平均 PEC：同父半同胞 {M['pec_hs']:.3f}，无亲缘/其他 {M['pec_un']:.3f}")
        print(f"  差值 90% 区间覆盖率：精确 {M['cov_exact']:.3f}；忽略 PEC {M['cov_naive']:.3f}")
        print(f"  同父半同胞对：v⁰/v 平均 {M['vr_hs']:.3f}；差值区间覆盖率 精确 {M['cov_hs_exact']:.3f}，忽略 PEC {M['cov_hs_naive']:.3f}")
        print(f"  宣布“不同”的比例：精确 {M['decl_exact']:.3f}；区间重叠法 {M['decl_ovl']:.3f}；已宣布对的符号错误率：精确 {M['sgn_exact']:.3f}，重叠法 {M['sgn_ovl']:.3f}")
        print(f"  组均值对比误差方差：二次型 {M['grp_q']:.4f}，独立假设 {M['grp_naive']:.4f}，实际 MSE {M['grp_mse']:.4f}；覆盖率 {M['grp_cov']:.3f}")
    for n in ("G", "A"):
        M = out[n]
        assert 0.87 < M["cov_exact"] < 0.93
        assert M["decl_ovl"] < M["decl_exact"]
        assert M["sgn_exact"] < 0.15 and M["sgn_ovl"] < 0.15
        assert 0.7 < M["grp_q"] / M["grp_mse"] < 1.4
    assert out["G"]["pec_hs"] > out["G"]["pec_un"] and out["G"]["vr_hs"] > 1.05
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex35_20_pairwise_pec.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
