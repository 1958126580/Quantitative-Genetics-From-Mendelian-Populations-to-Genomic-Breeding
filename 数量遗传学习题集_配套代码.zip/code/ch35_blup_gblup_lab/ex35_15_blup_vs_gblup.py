#!/usr/bin/env python3
"""习题 35.15  系谱 BLUP 与 GBLUP 的配对比较：30 次重复、同一资料、已知方差

设计：基础代 20 公 + 100 母（有表型），随机交配得 160 只子代；其中 80 只子代有表型进入训练，
另 80 只为候选。比较系谱 BLUP（A）与 GBLUP（G，全部 240 个因果位点已分型）。
指标：与真实育种值的相关、RMSE、校准斜率与截距、90% 预测区间覆盖率；成对差先在重复内计算再汇总。
独立核验：(1) 协方差形式 BLUP 与 Henderson 混合模型方程的解一致（A 版，一次重复）；
(2) 平均 PEV 与实际 MSE 同量级（GBLUP 下比值在 0.7—1.4）；(3) GBLUP 的相关在多数重复中高于 A-BLUP。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _sim import simulate, tabular_A, vanraden_G, blup, metrics, split

HERE = Path(__file__).resolve().parent


def henderson_check(d, train, cand):
    """用 Henderson MME（A⁻¹）核验协方差形式的 BLUP。"""
    A = tabular_A(d["sire"], d["dam"]); n = len(A)
    idx = np.concatenate([train, cand]); sub = A[np.ix_(idx, idx)]
    lam = d["se2"] / d["sa2"]; nt = len(train); nc = len(cand)
    X = np.ones((nt, 1)); Zm = np.hstack([np.eye(nt), np.zeros((nt, nc))])
    Ai = np.linalg.inv(sub)
    lhs = np.block([[X.T @ X, X.T @ Zm], [Zm.T @ X, Zm.T @ Zm + lam * Ai]])
    rhs = np.concatenate([X.T @ d["y"][train], Zm.T @ d["y"][train]])
    sol = np.linalg.solve(lhs, rhs)
    u_mme = sol[1 + nt:]
    u_cov, _ = blup(A, train, cand, d["y"], d["sa2"], d["se2"])
    return np.max(np.abs(u_mme - u_cov))


def main():
    cfg = json.loads((HERE / "data" / "ex35_15_config.json").read_text(encoding="utf-8"))
    keys = ["r", "rmse", "slope", "icpt", "cover"]
    res = {"A": {k: [] for k in keys}, "G": {k: [] for k in keys}}; ratio = {"A": [], "G": []}
    chk = None
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
        train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"])
        A = tabular_A(d["sire"], d["dam"]); G = vanraden_G(d["Z"], d["p"])
        for name, K in (("A", A), ("G", G)):
            uh, pev = blup(K, train, cand, d["y"], d["sa2"], d["se2"])
            mt = metrics(uh, d["u"][cand], np.diag(pev))
            for k in keys:
                res[name][k].append(mt[k])
            ratio[name].append(np.mean(np.diag(pev)) / np.mean((uh - d["u"][cand]) ** 2))
        if r == 0:
            chk = henderson_check(d, train, cand)
    print(f"重复 {cfg['reps']} 次；m={cfg['m']}，训练 {cfg['n_sire']+cfg['n_dam']+cfg['n_train_off']} 只，候选 {cfg['n_off']-cfg['n_train_off']} 只，h²={cfg['h2']}")
    print(f"{'指标':<10}{'系谱 BLUP':>16}{'GBLUP':>16}")
    names = dict(r="验证相关", rmse="RMSE", slope="校准斜率", icpt="校准截距", cover="90%覆盖率")
    out = {}
    for k in keys:
        a = np.array(res["A"][k]); g = np.array(res["G"][k])
        print(f"{names[k]:<10}{a.mean():>10.3f}±{a.std(ddof=1):.3f}{g.mean():>10.3f}±{g.std(ddof=1):.3f}")
        out[k] = dict(A=[float(a.mean()), float(a.std(ddof=1))], G=[float(g.mean()), float(g.std(ddof=1))])
    dr = np.array(res["G"]["r"]) - np.array(res["A"]["r"]); wins = int((dr > 0).sum())
    se = dr.std(ddof=1) / np.sqrt(len(dr))
    print(f"\n成对相关差 G−A：均值 {dr.mean():.3f}，蒙特卡洛标准误 {se:.3f}；G 更高的重复 {wins}/{cfg['reps']}")
    dm = np.array(res["A"]["rmse"]) - np.array(res["G"]["rmse"])
    print(f"RMSE 降低（A−G）：均值 {dm.mean():.3f}，标准误 {dm.std(ddof=1)/np.sqrt(len(dm)):.3f}")
    print(f"平均 PEV / 实际 MSE：A {np.mean(ratio['A']):.3f}，G {np.mean(ratio['G']):.3f}")
    print(f"协方差形式与 Henderson 混合模型方程（A 版）最大差 {chk:.2e}")
    out["paired"] = dict(dr_mean=float(dr.mean()), dr_se=float(se), wins=wins, rmse_gain=float(dm.mean()))
    out["pev_over_mse"] = dict(A=float(np.mean(ratio["A"])), G=float(np.mean(ratio["G"])))
    assert chk < 1e-8
    assert wins >= 0.6 * cfg["reps"] and dr.mean() > 3 * se
    assert 0.7 < np.mean(ratio["G"]) < 1.4
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex35_15_blup_vs_gblup.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
