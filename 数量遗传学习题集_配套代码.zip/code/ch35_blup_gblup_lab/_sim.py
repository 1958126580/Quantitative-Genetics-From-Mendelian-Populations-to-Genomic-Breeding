"""第35章共用的教学模拟器与 BLUP 求解器（供本文件夹中的程序导入）。

模拟：基础代（n_sire 只公羊 + n_dam 只母羊，位点独立、频率 p_j 已知）随机交配产生 n_off 只子代；
真实加性育种值 u = (Z − 2p) α，α_j ~ N(0, σa²/Σ2p_j q_j)，故基础群体 Var(u)≈σa²；
表型 y = μ + u + e，e ~ N(0, σe²)，σe² = σa²(1−h²)/h²。
关系矩阵：A 由系谱表格法逐项构造；G 为 VanRaden 第一法 (Z−2p)(Z−2p)ᵀ/Σ2pq。
求解：协方差形式的 BLUP，固定效应只有总均值，PEV 含均值估计的不确定性。
"""
from __future__ import annotations
import numpy as np


def simulate(rng, m=240, n_sire=20, n_dam=100, n_off=160, h2=0.5, sa2=1.0, p_lo=0.2, p_hi=0.5):
    p = rng.uniform(p_lo, p_hi, m)
    n0 = n_sire + n_dam
    Z0 = rng.binomial(2, p, (n0, m)).astype(float)
    sire = rng.integers(0, n_sire, n_off)
    dam = n_sire + rng.integers(0, n_dam, n_off)
    def transmit(g):          # 以 g/2 的概率传递参考等位基因
        return (rng.random(g.shape) < g / 2.0).astype(float)
    Z1 = transmit(Z0[sire]) + transmit(Z0[dam])
    Z = np.vstack([Z0, Z1])
    s = np.sum(2 * p * (1 - p))
    alpha = rng.normal(0, np.sqrt(sa2 / s), m)
    u = (Z - 2 * p) @ alpha
    se2 = sa2 * (1 - h2) / h2
    y = 0.0 + u + rng.normal(0, np.sqrt(se2), len(u))
    n = n0 + n_off
    ped_s = np.full(n, -1); ped_d = np.full(n, -1)
    ped_s[n0:] = sire; ped_d[n0:] = dam
    return dict(Z=Z, p=p, u=u, y=y, sire=ped_s, dam=ped_d, n0=n0, n=n, sa2=sa2, se2=se2, s=s)


def tabular_A(sire, dam):
    n = len(sire); A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        if s >= 0 and d >= 0:
            A[i, :i] = 0.5 * (A[s, :i] + A[d, :i])
            A[:i, i] = A[i, :i]
            A[i, i] = 1 + 0.5 * A[s, d]
        elif s >= 0:
            A[i, :i] = 0.5 * A[s, :i]; A[:i, i] = A[i, :i]; A[i, i] = 1.0
        else:
            A[i, i] = 1.0
    return A


def vanraden_G(Z, p, cols=None):
    if cols is not None:
        Z = Z[:, cols]; p = p[cols]
    W = Z - 2 * p
    return W @ W.T / np.sum(2 * p * (1 - p))


def blup(K, train, cand, y, sa2, se2):
    """协方差形式的 BLUP。返回 (û_cand, PEV 矩阵 cand×cand)。K 为训练与候选共用的关系矩阵。"""
    Ktt = K[np.ix_(train, train)]; Kct = K[np.ix_(cand, train)]; Kcc = K[np.ix_(cand, cand)]
    V = sa2 * Ktt + se2 * np.eye(len(train))
    Vi = np.linalg.inv(V)
    one = np.ones(len(train)); denom = one @ Vi @ one
    mu = (one @ Vi @ y[train]) / denom
    uhat = sa2 * Kct @ Vi @ (y[train] - mu)
    t = 1 - sa2 * Kct @ Vi @ one
    pev = sa2 * Kcc - sa2 ** 2 * Kct @ Vi @ Kct.T + np.outer(t, t) / denom
    return uhat, pev


def metrics(uhat, u, pev_diag=None, z90=1.6448536):
    r = np.corrcoef(uhat, u)[0, 1]
    rmse = np.sqrt(np.mean((uhat - u) ** 2))
    b, a = np.polyfit(uhat, u, 1)
    out = dict(r=r, rmse=rmse, slope=b, icpt=a)
    if pev_diag is not None:
        out["cover"] = np.mean(np.abs(u - uhat) <= z90 * np.sqrt(pev_diag))
    return out


def split(rng, n0, n_off, n_train_off):
    off = np.arange(n0, n0 + n_off)
    pick = rng.permutation(off)
    train = np.concatenate([np.arange(n0), np.sort(pick[:n_train_off])])
    cand = np.sort(pick[n_train_off:])
    return train, cand
