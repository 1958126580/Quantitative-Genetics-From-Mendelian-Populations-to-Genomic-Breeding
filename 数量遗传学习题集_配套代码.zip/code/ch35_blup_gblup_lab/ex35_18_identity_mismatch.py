#!/usr/bin/env python3
"""习题 35.18  身份错配：合法的关系矩阵仍会给出错误的预测，并且可以被亲子检查发现

在候选羔羊中随机选 k 只，把它们的基因型行在彼此之间循环错位（每只得到另一只的基因型）；
系谱与表型不变，G 重新计算（仍为合法的半正定矩阵）。比较：
(1) GBLUP 的验证相关随错配数 k 的变化，及理论 r(k)≈(1−k/n)·r(0)（错配个体的预测与真值无关，其余不变）；
(2) 亲子检查：对每个有系谱的羔羊计算 d_i=(G[i,sire]+G[i,dam])/2（期望 0.5），d_i<0.25 的标记为可疑；
    报告可疑标记对错配个体的灵敏度和对正确个体的假阳性率；
(3) 剔除被标记个体后（对其改用系谱 BLUP 预测）的相关恢复程度。
断言：r(k) 单调下降且与理论值相差 <0.05；k=0 的灵敏度不适用，其假阳性率 <0.02；k=40 时灵敏度 >0.85、假阳性率 <0.05；
改用系谱预测后的相关高于不处理（k=40 时）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _sim import simulate, tabular_A, vanraden_G, blup, metrics, split

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex35_18_config.json").read_text(encoding="utf-8"))
    ks = cfg["swap_counts"]; thr = cfg["flag_threshold"]; nc = cfg["n_off"] - cfg["n_train_off"]
    R = {k: [] for k in ks}; Rf = {k: [] for k in ks}; sens = {k: [] for k in ks}; fpr = {k: [] for k in ks}
    dgood = []; dbad = []
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
        train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"]); A = tabular_A(d["sire"], d["dam"])
        uA, _ = blup(A, train, cand, d["y"], d["sa2"], d["se2"])
        for k in ks:
            Z = d["Z"].copy(); bad = np.zeros(len(cand), bool)
            if k > 0:
                sel = rng.choice(len(cand), k, replace=False); perm = np.roll(sel, 1) if k > 1 else sel
                Z[cand[sel]] = d["Z"][cand[perm]]; bad[sel] = True
            G = vanraden_G(Z, d["p"])
            uG, _ = blup(G, train, cand, d["y"], d["sa2"], d["se2"])
            R[k].append(metrics(uG, d["u"][cand])["r"])
            dd = 0.5 * (G[cand, d["sire"][cand]] + G[cand, d["dam"][cand]]); flag = dd < thr
            if k > 0:
                sens[k].append(flag[bad].mean())
            fpr[k].append(flag[~bad].mean() if (~bad).any() else np.nan)
            if k == 40:
                dgood.extend(dd[~bad]); dbad.extend(dd[bad])
            uF = np.where(flag, uA, uG); Rf[k].append(metrics(uF, d["u"][cand])["r"])
    r0 = np.mean(R[0])
    print(f"重复 {cfg['reps']} 次；候选 {nc} 只；亲子检查阈值 d<{thr}")
    print(f"{'错配数k':>8}{'GBLUP r':>10}{'理论(1−k/n)r0':>15}{'灵敏度':>8}{'假阳性率':>9}{'标记后改用A的r':>16}")
    out = {}
    for k in ks:
        th = (1 - k / nc) * r0; se = np.mean(sens[k]) if k > 0 else float("nan"); fp = np.nanmean(fpr[k]) if np.isfinite(fpr[k]).any() else float("nan")
        print(f"{k:>8}{np.mean(R[k]):>10.3f}{th:>15.3f}{se:>8.3f}{fp:>9.3f}{np.mean(Rf[k]):>16.3f}")
        out[str(k)] = dict(r=float(np.mean(R[k])), theory=float(th), sens=None if np.isnan(se) else float(se), fpr=None if np.isnan(fp) else float(fp), r_flag=float(np.mean(Rf[k])))
    print(f"\nk=40 时 d 的分布：正确个体均值 {np.mean(dgood):.3f}（sd {np.std(dgood):.3f}），错配个体均值 {np.mean(dbad):.3f}（sd {np.std(dbad):.3f}）")
    out["d_stats"] = dict(good=[float(np.mean(dgood)), float(np.std(dgood))], bad=[float(np.mean(dbad)), float(np.std(dbad))])
    rs = [np.mean(R[k]) for k in ks]
    assert all(rs[i + 1] < rs[i] for i in range(len(rs) - 1))
    assert all(abs(np.mean(R[k]) - (1 - k / nc) * r0) < 0.05 for k in ks)
    assert np.nanmean(fpr[0]) < 0.02
    assert np.mean(sens[40]) > 0.85 and np.nanmean(fpr[40]) < 0.05
    assert np.mean(Rf[40]) > np.mean(R[40])
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex35_18_identity_mismatch.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
