# 第35章　从系谱 BLUP 到 GBLUP：一个可复算的肉羊教学实验——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex35_15_blup_vs_gblup.py
python3 ex35_16_marker_density.py
python3 ex35_17_variance_ratio.py
python3 ex35_18_identity_mismatch.py
python3 ex35_19_screening_tail.py
python3 ex35_20_pairwise_pec.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex35_15_blup_vs_gblup.py | 35.15 | 系谱 BLUP 与 GBLUP 的配对比较：30 次重复、同一资料、已知方差 |
| ex35_16_marker_density.py | 35.16 | 可观测标记减少：信息损失与模型错设要分开 |
| ex35_17_variance_ratio.py | 35.17 | 方差比错设：排序几乎不变，幅度与不确定性先出问题 |
| ex35_18_identity_mismatch.py | 35.18 | 身份错配：合法的关系矩阵仍会给出错误的预测，并且可以被亲子检查发现 |
| ex35_19_screening_tail.py | 35.19 | 初筛之后：相关为什么下降，尾部损失又如何 |
| ex35_20_pairwise_pec.py | 35.20 | 个体比较要用预测误差协方差：PEV_i+PEV_j−2PEC_ij，而不是看两个区间是否重叠 |
