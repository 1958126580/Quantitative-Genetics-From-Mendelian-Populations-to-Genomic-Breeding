#!/usr/bin/env python3
"""习题 35.17  方差比错设：排序几乎不变，幅度与不确定性先出问题

原始表型不变，只把拟合时的残差方差乘以 f（σe²_fit = f·σe²_true，遗传方差保持真值）。
对 GBLUP 与系谱 BLUP 报告：相关、RMSE、校准斜率 b(u|û)、90% 区间覆盖率（用错设的 PEV）、
EBV 的标准差（幅度）与相对 f=1 的 EBV 排序（Spearman）相关。
断言：f∈[0.5,2] 内相关的变化 <0.03；校准斜率随 f 单调上升（f 大 → 过度收缩 → 斜率>1）；
f=0.1 时 GBLUP 的覆盖率比 f=1 至少低 0.04；f=1 时覆盖率在 0.9±0.03；
f=0.25 与 f=4 的 EBV 排序相关 >0.9（排序对方差比不敏感）；f=1 的 RMSE 为各 f 下最小（容差 0.005）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _sim import simulate, tabular_A, vanraden_G, blup, metrics, split

HERE = Path(__file__).resolve().parent


def rank_corr(a, b):
    ra = np.argsort(np.argsort(a)); rb = np.argsort(np.argsort(b))
    return np.corrcoef(ra, rb)[0, 1]


def main():
    cfg = json.loads((HERE / "data" / "ex35_17_config.json").read_text(encoding="utf-8"))
    fs = cfg["ratio_factors"]; keys = ["r", "rmse", "slope", "cover", "sd"]
    res = {n: {f: {k: [] for k in keys + ["rank"]} for f in fs} for n in ("A", "G")}
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
        train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"])
        Ks = {"A": tabular_A(d["sire"], d["dam"]), "G": vanraden_G(d["Z"], d["p"])}
        for n, K in Ks.items():
            base, _ = blup(K, train, cand, d["y"], d["sa2"], d["se2"])
            for f in fs:
                uh, pev = blup(K, train, cand, d["y"], d["sa2"], f * d["se2"])
                mt = metrics(uh, d["u"][cand], np.diag(pev))
                for k in ("r", "rmse", "slope", "cover"):
                    res[n][f][k].append(mt[k])
                res[n][f]["sd"].append(uh.std()); res[n][f]["rank"].append(rank_corr(uh, base))
    out = {}
    for n, title in (("G", "GBLUP"), ("A", "系谱 BLUP")):
        print(f"\n{title}（真实 σe²/σa²={(1-cfg['h2'])/cfg['h2']:.2f}，重复 {cfg['reps']} 次）")
        print(f"{'f':>6}{'相关':>8}{'RMSE':>8}{'斜率':>8}{'覆盖率':>8}{'EBV sd':>9}{'与f=1排序相关':>14}")
        out[n] = {}
        for f in fs:
            v = {k: float(np.mean(res[n][f][k])) for k in keys + ["rank"]}; out[n][str(f)] = v
            print(f"{f:>6}{v['r']:>8.3f}{v['rmse']:>8.3f}{v['slope']:>8.3f}{v['cover']:>8.3f}{v['sd']:>9.3f}{v['rank']:>14.3f}")
    for n in ("G", "A"):
        rr = [out[n][str(f)]["r"] for f in fs if 0.5 <= f <= 2]; assert max(rr) - min(rr) < 0.03
        sl = [out[n][str(f)]["slope"] for f in fs]; assert all(sl[i + 1] > sl[i] for i in range(len(sl) - 1)), sl
        rm = [out[n][str(f)]["rmse"] for f in fs]; assert out[n]["1.0"]["rmse"] <= min(rm) + 0.005
        assert abs(out[n]["1.0"]["cover"] - 0.9) < 0.03
    assert out["G"]["1.0"]["cover"] - out["G"]["0.1"]["cover"] > 0.04
    # f=0.25 与 f=4 的排序相关
    rng = np.random.default_rng(cfg["seed"] + 999)
    d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
    train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"]); G = vanraden_G(d["Z"], d["p"])
    a, _ = blup(G, train, cand, d["y"], d["sa2"], 0.25 * d["se2"]); b, _ = blup(G, train, cand, d["y"], d["sa2"], 4 * d["se2"])
    rc = rank_corr(a, b); print(f"\n单次示例：f=0.25 与 f=4 的 EBV 排序相关 {rc:.3f}"); out["rank_025_4"] = float(rc)
    assert rc > 0.9
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex35_17_variance_ratio.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
