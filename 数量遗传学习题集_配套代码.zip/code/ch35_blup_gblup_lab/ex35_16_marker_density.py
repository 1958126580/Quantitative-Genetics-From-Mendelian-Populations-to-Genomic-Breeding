#!/usr/bin/env python3
"""习题 35.16  可观测标记减少：信息损失与模型错设要分开

真实育种值始终由全部 240 个因果位点生成；GBLUP 只使用随机抽取的 m_obs 个位点构造 G（并按这些位点的 2pq 之和标准化）。
比较：系谱 BLUP（0 个标记）、m_obs ∈ {15,30,60,120,240} 的 GBLUP，以及 A 与 G 的等权混合 K=(1−w)A+wG。
报告：相关、RMSE、校准斜率、"关系精度"——G 的候选-训练关系与由全位点 G 的关系的相关系数（衡量标记对实际关系的恢复）。
断言：相关随 m_obs 单调不降（容差 0.01）；m_obs=240 比 15 高 0.05 以上；
m_obs=15 的 GBLUP 不优于系谱 BLUP 超过 0.03（信息损失）；关系精度随 m_obs 上升；
混合矩阵的相关在 m_obs=15 时不低于 A 与 G 中较差者。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _sim import simulate, tabular_A, vanraden_G, blup, metrics, split

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex35_16_config.json").read_text(encoding="utf-8"))
    ml = cfg["m_obs_list"]; w = cfg["blend_w"]
    R = {m: [] for m in ml}; S = {m: [] for m in ml}; E = {m: [] for m in ml}; Q = {m: [] for m in ml}; B = {m: [] for m in ml}
    RA = []; EA = []
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
        train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"])
        A = tabular_A(d["sire"], d["dam"]); Gfull = vanraden_G(d["Z"], d["p"])
        uh, _ = blup(A, train, cand, d["y"], d["sa2"], d["se2"]); mt = metrics(uh, d["u"][cand]); RA.append(mt["r"]); EA.append(mt["rmse"])
        ref = Gfull[np.ix_(cand, train)].ravel()
        for m in ml:
            cols = rng.choice(cfg["m"], m, replace=False)
            G = vanraden_G(d["Z"], d["p"], cols)
            uh, _ = blup(G, train, cand, d["y"], d["sa2"], d["se2"]); mt = metrics(uh, d["u"][cand])
            R[m].append(mt["r"]); S[m].append(mt["slope"]); E[m].append(mt["rmse"])
            Q[m].append(np.corrcoef(G[np.ix_(cand, train)].ravel(), ref)[0, 1])
            uh, _ = blup((1 - w) * A + w * G, train, cand, d["y"], d["sa2"], d["se2"]); B[m].append(metrics(uh, d["u"][cand])["r"])
    print(f"重复 {cfg['reps']} 次；真实育种值由 {cfg['m']} 个位点生成；系谱 BLUP 相关 {np.mean(RA):.3f}，RMSE {np.mean(EA):.3f}")
    print(f"{'m_obs':>6}{'GBLUP r':>10}{'RMSE':>8}{'斜率':>8}{'关系精度':>10}{'混合(A+G) r':>13}")
    out = {"A": dict(r=float(np.mean(RA)), rmse=float(np.mean(EA)))}
    for m in ml:
        print(f"{m:>6}{np.mean(R[m]):>10.3f}{np.mean(E[m]):>8.3f}{np.mean(S[m]):>8.3f}{np.mean(Q[m]):>10.3f}{np.mean(B[m]):>13.3f}")
        out[str(m)] = dict(r=float(np.mean(R[m])), rmse=float(np.mean(E[m])), slope=float(np.mean(S[m])), rel=float(np.mean(Q[m])), blend=float(np.mean(B[m])))
    rs = [np.mean(R[m]) for m in ml]
    assert all(rs[i + 1] >= rs[i] - 0.01 for i in range(len(rs) - 1))
    assert rs[-1] > rs[0] + 0.05
    assert rs[0] <= np.mean(RA) + 0.03
    qs = [np.mean(Q[m]) for m in ml]
    assert all(qs[i + 1] > qs[i] for i in range(len(qs) - 1))
    assert np.mean(B[ml[0]]) >= min(np.mean(RA), rs[0]) - 0.005
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex35_16_marker_density.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
