#!/usr/bin/env python3
"""习题 35.19  初筛之后：相关为什么下降，尾部损失又如何

初筛规则：按亲本 EBV 均值（系谱 BLUP 对全部动物的预测，½(û_父+û_母)）保留候选中最高的 30%。
在被保留的候选里比较系谱 BLUP 与 GBLUP：
(1) 相关（全体候选 vs 初筛后）与真实育种值方差（初筛后/全体）；
(2) 初筛后在 select_n 只中的选择：被选个体的真实育种值均值 vs "初筛集合内的最优"（神谕）与"全体候选内的最优"；
(3) 家系内成分：初筛按亲本均值进行，去掉了家系间变异，GBLUP 的优势主要来自孟德尔抽样（家系内）。
断言：两种方法的相关在初筛后都下降；GBLUP 在初筛后仍高于 A（均值差>0.05）；
A 的相关下降比例大于 GBLUP；真实育种值的方差在初筛后更小；GBLUP 选出的真实育种值均值 > A 的（均值差>0）；
选择结果低于初筛内神谕、高于随机。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _sim import simulate, tabular_A, vanraden_G, blup, split

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex35_19_config.json").read_text(encoding="utf-8"))
    nc = cfg["n_off"] - cfg["n_train_off"]; ns = int(round(cfg["screen_frac"] * nc)); sel_n = cfg["select_n"]
    keys = ["rA_all", "rG_all", "rA_scr", "rG_scr", "vratio", "gA", "gG", "orc_in", "orc_all", "rand_in", "gA_all", "gG_all"]
    acc = {k: [] for k in keys}
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        d = simulate(rng, cfg["m"], cfg["n_sire"], cfg["n_dam"], cfg["n_off"], cfg["h2"])
        train, cand = split(rng, d["n0"], cfg["n_off"], cfg["n_train_off"])
        A = tabular_A(d["sire"], d["dam"]); G = vanraden_G(d["Z"], d["p"]); u = d["u"][cand]
        allidx = np.arange(d["n"]); uall, _ = blup(A, train, allidx, d["y"], d["sa2"], d["se2"])
        mid = 0.5 * (uall[d["sire"][cand]] + uall[d["dam"][cand]])
        scr = np.argsort(-mid)[:ns]
        uA, _ = blup(A, train, cand, d["y"], d["sa2"], d["se2"]); uG, _ = blup(G, train, cand, d["y"], d["sa2"], d["se2"])
        c = lambda a, b: np.corrcoef(a, b)[0, 1]
        acc["rA_all"].append(c(uA, u)); acc["rG_all"].append(c(uG, u))
        acc["rA_scr"].append(c(uA[scr], u[scr])); acc["rG_scr"].append(c(uG[scr], u[scr]))
        acc["vratio"].append(u[scr].var() / u.var())
        pick = lambda e: scr[np.argsort(-e[scr])[:sel_n]]
        acc["gA"].append(u[pick(uA)].mean()); acc["gG"].append(u[pick(uG)].mean())
        acc["orc_in"].append(np.sort(u[scr])[::-1][:sel_n].mean()); acc["orc_all"].append(np.sort(u)[::-1][:sel_n].mean())
        acc["rand_in"].append(u[scr].mean())
        acc["gA_all"].append(u[np.argsort(-uA)[:sel_n]].mean()); acc["gG_all"].append(u[np.argsort(-uG)[:sel_n]].mean())
    M = {k: float(np.mean(v)) for k, v in acc.items()}
    se = lambda k: np.std(acc[k], ddof=1) / np.sqrt(len(acc[k]))
    print(f"重复 {cfg['reps']} 次；候选 {nc} 只，初筛保留 {ns} 只，再从中选 {sel_n} 只")
    print(f"{'':<10}{'全体候选相关':>14}{'初筛后相关':>12}{'相对下降':>10}")
    print(f"{'系谱 BLUP':<10}{M['rA_all']:>14.3f}{M['rA_scr']:>12.3f}{1-M['rA_scr']/M['rA_all']:>10.1%}")
    print(f"{'GBLUP':<10}{M['rG_all']:>14.3f}{M['rG_scr']:>12.3f}{1-M['rG_scr']/M['rG_all']:>10.1%}")
    print(f"\n初筛后真实育种值方差 / 全体候选 = {M['vratio']:.3f}")
    print(f"\n选 {sel_n} 只的真实育种值均值：初筛内 A {M['gA']:.3f}，初筛内 G {M['gG']:.3f}（±{se('gG'):.3f}）；")
    print(f"  初筛内神谕 {M['orc_in']:.3f}；初筛集合随机 {M['rand_in']:.3f}；不初筛时 A {M['gA_all']:.3f}，G {M['gG_all']:.3f}；全体神谕 {M['orc_all']:.3f}")
    dgap = np.array(acc["gG"]) - np.array(acc["gA"])
    print(f"  G−A 的选择优势 {dgap.mean():.3f}（标准误 {dgap.std(ddof=1)/np.sqrt(len(dgap)):.3f}）")
    assert M["rA_scr"] < M["rA_all"] and M["rG_scr"] < M["rG_all"]
    assert M["rG_scr"] - M["rA_scr"] > 0.05
    assert (1 - M["rA_scr"] / M["rA_all"]) > (1 - M["rG_scr"] / M["rG_all"])
    assert M["vratio"] < 1
    assert dgap.mean() > 0
    assert M["rand_in"] < M["gA"] < M["orc_in"] and M["gG"] < M["orc_in"]
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex35_19_screening_tail.json").write_text(json.dumps(M, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
