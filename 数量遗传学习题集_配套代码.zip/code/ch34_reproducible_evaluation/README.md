# 第34章　数据字典到可重复评定——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex34_15_data_contract_audit.py
python3 ex34_16_repeated_records.py
python3 ex34_17_validation_design.py
python3 ex34_18_innovation_update.py
python3 ex34_19_influence_deletion.py
python3 ex34_20_identity_version.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex34_15_data_contract_audit.py | 34.15 | 数据契约审计：把登记表、称重事件表与分型样本表变成可追溯的分析表 |
| ex34_16_repeated_records.py | 34.16 | 重复记录不能当作独立样本：公畜可靠度的“宣称值”与“实现值” |
| ex34_17_validation_design.py | 34.17 | 验证切分必须跟随部署场景：同一群体、同一模型，五种“准确度” |
| ex34_18_innovation_update.py | 34.18 | 新增记录的条件创新：精确增量更新、顺序不变性、复传识别与测定设计 |
| ex34_19_influence_deletion.py | 34.19 | 删除、纠错与批次剔除的影响函数：谁是跨场比较的“桥梁记录” |
| ex34_20_identity_version.py | 34.20 | 身份不确定性的混合传播与版本变化的对称归因 |
