#!/usr/bin/env python3
"""习题 34.17  验证切分必须跟随部署场景：同一群体、同一模型，五种“准确度”

模拟闭锁肉羊群体：第0代基础群（12公60母），第1—4代每代120只羔羊（每母2羔），公羊每代更新，母羊在当代母羔与上一代母羊中随机留用。
真实育种值按 u_i = ½u_s + ½u_d + m_i，Var(m_i) = b_i σA²，b_i = ½ − ¼(F_s + F_d)。
表型 y = 世代效应 + u + e，h² = 0.30。模型：世代（固定）+ 动物（随机，A⁻¹）。
部署问题：决策时第0—2代有表型，第3代为刚出生的候选，第4代尚不存在。比较
    A 部署场景：只用第0—2代表型、第0—3代系谱预测第3代；
    B 随机个体切分：第0—3代随机遮蔽20%表型，在遮蔽个体上评估；
    C 越过截止日：遮蔽第3代表型，却使用了第4代（未来子代）表型；
    D 初筛后候选：场景 A 的预测，只在亲本均值前30%的候选中评估（范围缩窄）；
    E 整家系留出：第3代中三分之一公羊的全部后代遮蔽，其余第3代个体有表型。
指标：cor(û, u)、校准斜率 b(u|û)。重复 20 次报告均值与标准误。
独立核验：MME 解与“协方差形式” û = G Zᵀ V⁻¹(y − Xβ̂) 一致；A 由表格法与 TDTᵀ 两种方法一致。
"""
from __future__ import annotations

import json
import os
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")   # 小矩阵上单线程更快，且避免与其他进程争用
import numpy as np
from scipy.linalg import cho_factor, cho_solve

HERE = Path(__file__).resolve().parent


def simulate(cfg: dict, rng: np.random.Generator):
    """返回 sire、dam（−1 未知）、世代、性别、真实育种值。"""
    sire, dam, gen, sex = [], [], [], []
    nb_s, nb_d = cfg["base_sires"], cfg["base_dams"]
    for i in range(nb_s + nb_d):
        sire.append(-1); dam.append(-1); gen.append(0); sex.append("M" if i < nb_s else "F")
    males = list(range(nb_s)); females = list(range(nb_s, nb_s + nb_d))
    for g in range(1, cfg["n_generations"] + 1):
        start = len(sire)
        ds = rng.permutation(females)[: cfg["dams_per_gen"]]
        sires_g = rng.permutation(males)[: cfg["sires_per_gen"]]
        for j, d in enumerate(ds):
            s = sires_g[j % len(sires_g)]
            for _ in range(cfg["lambs_per_dam"]):
                sire.append(int(s)); dam.append(int(d)); gen.append(g)
                sex.append("M" if rng.random() < 0.5 else "F")
        idx = np.arange(start, len(sire))
        sx = np.array(sex)[idx]
        # 公羊只用当代；母羊在当代母羔与上一代在群母羊中随机留用（世代部分重叠）
        males = list(idx[sx == "M"]); females = list(idx[sx == "F"]) + [int(d) for d in ds]
        if len(males) < cfg["sires_per_gen"] or len(females) < cfg["dams_per_gen"]:
            raise RuntimeError("留种个体不足，请调整群体规模或种子")
    return np.array(sire), np.array(dam), np.array(gen), np.array(sex)


def a_matrix(sire, dam):
    """表格法求 A（父母排在后代之前）。"""
    n = len(sire); A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        if i:
            row = 0.5 * ((A[s, :i] if s >= 0 else 0) + (A[d, :i] if d >= 0 else 0))
            A[i, :i] = row; A[:i, i] = row
        A[i, i] = 1 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0)
    return A


def mendel_b(sire, dam, F):
    b = np.ones(len(sire))
    for i, (s, d) in enumerate(zip(sire, dam)):
        if s >= 0 and d >= 0:
            b[i] = 0.5 - 0.25 * (F[s] + F[d])
        elif s >= 0 or d >= 0:
            b[i] = 0.75 - 0.25 * F[max(s, d)]
    return b


def a_inverse(sire, dam, b):
    """Henderson 规则（含近交）。"""
    n = len(sire); Ai = np.zeros((n, n))
    for i in range(n):
        idx = [i] + [p for p in (sire[i], dam[i]) if p >= 0]
        w = np.array([1.0] + [-0.5] * (len(idx) - 1))
        Ai[np.ix_(idx, idx)] += np.outer(w, w) / b[i]
    return Ai


def blup(y, gen, obs, Ai, lam, ngen):
    """世代固定 + 动物随机；obs 为有表型个体的布尔向量。返回 û（全部个体）、β̂。"""
    n = len(y); io = np.where(obs)[0]
    lev = sorted(set(gen[io]))
    X = np.zeros((len(io), len(lev)))
    X[np.arange(len(io)), [lev.index(g) for g in gen[io]]] = 1
    Z = np.zeros((len(io), n)); Z[np.arange(len(io)), io] = 1
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * Ai]])
    rhs = np.concatenate([X.T @ y[io], Z.T @ y[io]])
    sol = cho_solve(cho_factor(C), rhs)
    return sol[len(lev):], sol[: len(lev)], X, Z


def metrics(uhat, u):
    r = float(np.corrcoef(uhat, u)[0, 1])
    b = float(np.cov(u, uhat)[0, 1] / np.var(uhat, ddof=1))
    return r, b


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex34_17_validation.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    vA = cfg["var_A"]; ve = vA * (1 - cfg["h2"]) / cfg["h2"]; lam = ve / vA
    names = {"A": "部署场景（前瞻，第3代）", "B": "随机个体切分", "C": "越过截止日（用第4代）",
             "D": "初筛后候选（前30%）", "E": "整家系留出（第3代）"}
    res = {k: [] for k in names}
    for rep in range(cfg["n_rep"]):
        sire, dam, gen, sex = simulate(cfg, rng)
        n = len(sire)
        A = a_matrix(sire, dam); F = np.diag(A) - 1
        b = mendel_b(sire, dam, F)
        if rep == 0:
            P = np.zeros((n, n))
            for i in range(n):
                for p in (sire[i], dam[i]):
                    if p >= 0:
                        P[i, p] = 0.5
            T = np.linalg.solve(np.eye(n) - P, np.eye(n))
            assert np.allclose(T @ np.diag(b) @ T.T, A, atol=1e-10), "A ≠ TDTᵀ"
        u = np.zeros(n)
        for i in range(n):
            pa = 0.5 * ((u[sire[i]] if sire[i] >= 0 else 0) + (u[dam[i]] if dam[i] >= 0 else 0))
            u[i] = pa + rng.normal(0, np.sqrt(b[i] * vA))
        y = np.array(cfg["gen_effects"])[gen] + u + rng.normal(0, np.sqrt(ve), n)
        G3 = gen == 3

        # A 部署：系谱只到第3代，表型只到第2代
        keep = gen <= 3; ik = np.where(keep)[0]
        Ai_k = a_inverse(sire[ik], dam[ik], b[ik])
        uh, beta, X, Z = blup(y[ik], gen[ik], gen[ik] <= 2, Ai_k, lam, 3)
        res["A"].append(metrics(uh[gen[ik] == 3], u[ik][gen[ik] == 3]))
        if rep == 0:      # 协方差形式核验
            Ak = A[np.ix_(ik, ik)]
            V = Z @ Ak @ Z.T * vA + ve * np.eye(Z.shape[0])
            yo = y[ik][gen[ik] <= 2]
            u_cov = vA * Ak @ Z.T @ np.linalg.solve(V, yo - X @ beta)
            assert np.allclose(u_cov, uh, atol=1e-8), "MME 与协方差形式不一致"
        # D 初筛后：按亲本均值（同一预测下）取前30%
        pa_hat = np.array([0.5 * (uh[sire[i]] + uh[dam[i]]) for i in ik[gen[ik] == 3]])
        top = pa_hat >= np.quantile(pa_hat, 1 - cfg["prescreen_top_fraction"])
        res["D"].append(metrics(uh[gen[ik] == 3][top], u[ik][gen[ik] == 3][top]))

        Ai_all = a_inverse(sire[ik], dam[ik], b[ik])
        # B 随机个体切分（第0—3代）
        mask = rng.random(len(ik)) < cfg["random_mask_fraction"]
        uh, *_ = blup(y[ik], gen[ik], ~mask, Ai_all, lam, 4)
        res["B"].append(metrics(uh[mask], u[ik][mask]))
        # E 整家系留出：第3代中 1/3 公羊的全部后代遮蔽
        s3 = np.unique(sire[ik][gen[ik] == 3])
        out_s = rng.choice(s3, int(round(cfg["family_out_fraction"] * len(s3))), replace=False)
        maskE = (gen[ik] == 3) & np.isin(sire[ik], out_s)
        uh, *_ = blup(y[ik], gen[ik], ~maskE, Ai_all, lam, 4)
        res["E"].append(metrics(uh[maskE], u[ik][maskE]))
        # C 越过截止日：全部系谱，第3代遮蔽，第4代表型可见
        Ai_full = a_inverse(sire, dam, b)
        uh, *_ = blup(y, gen, ~G3, Ai_full, lam, 5)
        res["C"].append(metrics(uh[G3], u[G3]))

    print("=" * 70)
    print("习题 34.17  验证设计与部署场景（%d 次重复，均值 ± 标准误）" % cfg["n_rep"])
    print("=" * 70)
    print(f"{'场景':<22s}{'cor(û,u)':>16s}{'校准斜率':>16s}")
    summary = {}
    for k, lab in names.items():
        arr = np.array(res[k])
        m, se = arr.mean(0), arr.std(0, ddof=1) / np.sqrt(len(arr))
        summary[k] = {"label": lab, "r_mean": m[0], "r_se": se[0], "slope_mean": m[1], "slope_se": se[1]}
        print(f"{k} {lab:<20s}{m[0]:9.3f} ± {se[0]:.3f}{m[1]:10.3f} ± {se[1]:.3f}")
    rA, rB, rC, rD = (summary[k]["r_mean"] for k in "ABCD")
    assert rC > rA and rB > rA and rD < rA, "场景排序与理论不符"
    print("\n解读：B、C 高于 A 是因为它们回答了更容易的问题；D 低于 A 是初筛造成的范围缩窄。")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex34_17_validation_design.json").write_text(
        json.dumps({"summary": summary, "raw": {k: v for k, v in res.items()}}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    from _plot import get_pyplot
    plt = get_pyplot()
    if plt is not None:
        fig, ax = plt.subplots(figsize=(6.4, 3.4))
        ks = list(names)
        ax.bar(range(5), [summary[k]["r_mean"] for k in ks], yerr=[1.96 * summary[k]["r_se"] for k in ks],
               color=["#3b6ea8" if k == "A" else "#9aa9bd" for k in ks], capsize=3)
        ax.set_xticks(range(5)); ax.set_xticklabels([names[k] for k in ks], fontsize=7, rotation=12)
        ax.set_ylabel("cor(û, u)"); ax.set_title("验证切分决定“准确度”回答的问题")
        fig.tight_layout(); fig.savefig(HERE / "results" / "ex34_17_validation_design.png"); plt.close(fig)


if __name__ == "__main__":
    main()
