#!/usr/bin/env python3
"""习题 34.20  身份不确定性的混合传播与版本变化的对称归因

模型：y = Zu + e，u ~ N(0, Aσa²)，e ~ N(0, σe² I)。一条称重记录的归属有 M 种候选身份，
      条形码给出先验 π⁰_m，表型证据按边际似然更新：π_m ∝ π⁰_m · N(y ; 0, Z_m A Z_mᵀσa² + σe² I)。
每种身份状态下 u 的条件分布 N(m_m, C_m)，完整后验是混合：
      m = Σπ_m m_m，Var = Σπ_m C_m + Σπ_m (m_m − m)(m_m − m)ᵀ（全方差分解）。
比较三种处理：只取最可能身份（MAP）、只平均 PEV、完整混合；用模拟检验目标对比的 90% 区间覆盖率。
版本归因：Δ = m(D1,θ1) − m(D0,θ0)，Δ_D = ½[m(D1,θ0)−m(D0,θ0)] + ½[m(D1,θ1)−m(D0,θ1)]，Δ_θ = Δ − Δ_D。
独立核验：书中手算例（π=(3/4,1/4)，混合协方差 13/16、−3/16、17/16）、混合矩与蒙特卡洛、
          归因手算例（0.5→2，资料与参数各 0.75）、两种顺序之和等于总变化。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.stats import multivariate_normal, norm

HERE = Path(__file__).resolve().parent


def tabular_A(ped):
    ids = [p[0] for p in ped]; ix = {a: i for i, a in enumerate(ids)}
    n = len(ids); A = np.zeros((n, n))
    for i, (_, s, d) in enumerate(ped):
        si, di = ix.get(s), ix.get(d)
        for j in range(i):
            v = 0.0
            if si is not None: v += 0.5 * A[j, si]
            if di is not None: v += 0.5 * A[j, di]
            A[i, j] = A[j, i] = v
        A[i, i] = 1.0 + (0.5 * A[si, di] if si is not None and di is not None else 0.0)
    return ids, ix, A


def posterior(A, s2a, s2e, rows, y):
    """记录 y 对应的动物下标 rows；返回后验均值、协方差（σa² 尺度）及边际对数似然。"""
    n = A.shape[0]; Z = np.zeros((len(rows), n)); Z[np.arange(len(rows)), rows] = 1
    G = s2a * A; V = Z @ G @ Z.T + s2e * np.eye(len(rows))
    K = np.linalg.solve(V, Z @ G).T            # G Zᵀ V⁻¹
    mean = K @ y
    cov = G - K @ Z @ G
    ll = multivariate_normal(mean=np.zeros(len(rows)), cov=V).logpdf(y)
    return mean, cov, ll


def mixture(pi, means, covs):
    pi = np.asarray(pi); m = sum(p * mu for p, mu in zip(pi, means))
    within = sum(p * C for p, C in zip(pi, covs))
    between = sum(p * np.outer(mu - m, mu - m) for p, mu in zip(pi, means))
    return m, within, between


def ebv_scalar(y, s2a, s2e):
    """单记录、先验方差 σa²：EBV = σa² y /(σa²+σe²)。书中归因例取 σa²=1。"""
    return s2a * y / (s2a + s2e)


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex34_20_config.json").read_text(encoding="utf-8"))
    ids, ix, A = tabular_A([tuple(p) for p in cfg["pedigree"]])
    s2a, s2e = cfg["sigma_a2"], cfg["sigma_e2"]
    fixed = [(ix[r["barcode_animal"]], r["y"]) for r in cfg["records"]]
    amb = cfg["ambiguous"]; cands = [ix[c] for c in amb["candidates"]]
    pi0 = np.array(amb["barcode_prior"]); ya = amb["y"]
    ta, tb = [ix[t] for t in cfg["target"]]
    a = np.zeros(len(ids)); a[ta], a[tb] = 1, -1

    print("=" * 70)
    print("习题 34.20  身份不确定性的混合传播与版本变化归因")
    print("=" * 70)

    # ---- 1. 书中手算例 ----
    m1, m2 = np.array([1., 0.]), np.array([0., 1.])
    C1, C2 = np.diag([.5, 1.]), np.diag([1., .5])
    m, w, b = mixture([.75, .25], [m1, m2], [C1, C2])
    Cmix = w + b
    assert np.allclose(m, [.75, .25]) and np.allclose(Cmix, [[13/16, -3/16], [-3/16, 17/16]])
    print(f"[手算例] 混合均值 {m}，混合协方差 [[{Cmix[0,0]:.4f},{Cmix[0,1]:.4f}],[{Cmix[1,0]:.4f},{Cmix[1,1]:.4f}]] = 13/16, −3/16, 17/16")

    # ---- 2. 完整问题：每种身份的后验 ----
    rows_fixed = [r for r, _ in fixed]; y_fixed = np.array([v for _, v in fixed])
    means, covs, lls = [], [], []
    for c in cands:
        mu, C, ll = posterior(A, s2a, s2e, rows_fixed + [c], np.append(y_fixed, ya))
        means.append(mu); covs.append(C); lls.append(ll)
    lp = np.log(pi0) + np.array(lls); pi = np.exp(lp - lp.max()); pi /= pi.sum()
    print(f"\n条形码先验 {pi0}，表型更新后的后验身份概率 {np.round(pi, 4)}")
    mu_mix, within, between = mixture(pi, means, covs)
    Cfull = within + between
    pev_full = a @ Cfull @ a; pev_avg = a @ within @ a
    pev_map = a @ covs[int(np.argmax(pi))] @ a
    est_full = a @ mu_mix; est_map = a @ means[int(np.argmax(pi))]
    print(f"目标 {cfg['target'][0]}−{cfg['target'][1]}：各身份下的估计 {[round(float(a @ mu), 4) for mu in means]}")
    print(f"  完整混合：估计 {est_full:.4f}，PEV {pev_full:.4f}（身份内 {pev_avg:.4f} + 身份间 {a @ between @ a:.4f}）")
    print(f"  只取最可能身份：估计 {est_map:.4f}，PEV {pev_map:.4f}；只平均PEV：{pev_avg:.4f}")

    # ---- 3. 蒙特卡洛核验混合矩（直接从混合分布抽样）----
    rng = np.random.default_rng(cfg["seed"])
    N = 200000
    k = rng.choice(len(cands), size=N, p=pi)
    draws = np.empty((N, len(ids)))
    for j in range(len(cands)):
        L = np.linalg.cholesky(covs[j] + 1e-12 * np.eye(len(ids)))
        sel = np.where(k == j)[0]
        draws[sel] = means[j] + rng.standard_normal((len(sel), len(ids))) @ L.T
    cov_mc = np.cov(draws.T)
    assert np.abs(cov_mc - Cfull).max() < 0.01 and np.abs(draws.mean(0) - mu_mix).max() < 0.01
    print(f"蒙特卡洛核验：混合协方差最大偏差 {np.abs(cov_mc - Cfull).max():.4f}")

    # ---- 4. 生成式模拟：三种处理的覆盖率 ----
    reps = cfg["sim_reps"]; z90 = norm.ppf(0.95)
    L0 = np.linalg.cholesky(s2a * A + 1e-10 * np.eye(len(ids)))
    cover = {"完整混合": 0, "只取MAP身份": 0, "只平均PEV": 0}
    abs_err = {"完整混合": 0.0, "只取MAP身份": 0.0}
    wrong = 0
    for _ in range(reps):
        u = L0 @ rng.standard_normal(len(ids))
        true_k = rng.choice(len(cands), p=pi0)
        yy = np.append(u[rows_fixed] + np.sqrt(s2e) * rng.standard_normal(len(rows_fixed)),
                       u[cands[true_k]] + np.sqrt(s2e) * rng.standard_normal())
        ms, cs, ll_ = [], [], []
        for c in cands:
            mu, C, ll = posterior(A, s2a, s2e, rows_fixed + [c], yy); ms.append(mu); cs.append(C); ll_.append(ll)
        l2 = np.log(pi0) + np.array(ll_); p2 = np.exp(l2 - l2.max()); p2 /= p2.sum()
        mm, ww, bb = mixture(p2, ms, cs)
        tgt = a @ u
        for name, est, var in (("完整混合", a @ mm, a @ (ww + bb) @ a),
                               ("只取MAP身份", a @ ms[int(np.argmax(p2))], a @ cs[int(np.argmax(p2))] @ a),
                               ("只平均PEV", a @ mm, a @ ww @ a)):
            cover[name] += abs(tgt - est) <= z90 * np.sqrt(var)
            if name in abs_err: abs_err[name] += (tgt - est) ** 2
        wrong += int(np.argmax(p2) != true_k)
    print(f"\n模拟 {reps} 次（真实身份按条形码先验抽取）：90% 区间覆盖率")
    for k_, v in cover.items():
        print(f"  {k_:<10s} {v / reps:.3f}" + (f"   MSE {abs_err[k_] / reps:.4f}" if k_ in abs_err else ""))
    print(f"  最可能身份判错比例 {wrong / reps:.3f}")
    assert cover["完整混合"] / reps > cover["只取MAP身份"] / reps

    # ---- 5. 版本变化归因 ----
    # 手算例：先验方差1，预测 y/(1+r)，记录 2→4，残差方差 3→1：0.5→2
    f = lambda y, r: ebv_scalar(y, 1.0, r)
    d0, d1 = f(2, 3), f(4, 1)
    dD = 0.5 * (f(4, 3) - f(2, 3)) + 0.5 * (f(4, 1) - f(2, 1))
    assert abs(d0 - 0.5) < 1e-12 and abs(d1 - 2) < 1e-12 and abs(dD - 0.75) < 1e-12 and abs((d1 - d0) - dD - 0.75) < 1e-12
    print(f"\n[手算例] 预测 {d0:.2f}→{d1:.2f}，总变化 {d1 - d0:.2f}，资料归因 {dD:.2f}，参数归因 {d1 - d0 - dD:.2f}")

    ver = cfg["version"]
    y_new = y_fixed.copy(); slot = [r["slot"] for r in cfg["records"]].index(ver["corrected_record"]["slot"])
    y_new[slot] = ver["corrected_record"]["y_new"]
    se1 = ver["sigma_e2_new"]

    def ebv(y, s2e_):  # 固定记录，身份不确定性按混合处理
        ms_, ll_ = [], []
        for c in cands:
            mu, _, ll = posterior(A, s2a, s2e_, rows_fixed + [c], np.append(y, ya)); ms_.append(mu); ll_.append(ll)
        l_ = np.log(pi0) + np.array(ll_); p_ = np.exp(l_ - l_.max()); p_ /= p_.sum()
        return sum(p * mu for p, mu in zip(p_, ms_))

    m00, m10, m01, m11 = ebv(y_fixed, s2e), ebv(y_new, s2e), ebv(y_fixed, se1), ebv(y_new, se1)
    path1 = (m10 - m00, m11 - m10); path2 = (m11 - m01, m01 - m00)   # (资料,参数) 两种顺序
    DD = 0.5 * (path1[0] + path2[0]); Dth = (m11 - m00) - DD
    assert np.allclose(path1[0] + path1[1], m11 - m00) and np.allclose(path2[0] + path2[1], m11 - m00)
    print(f"\n版本变化：S1 记录改正为 {ver['corrected_record']['y_new']}，σe² {s2e}→{se1}")
    print("  动物   旧EBV   新EBV    Δ     资料归因  参数归因  先资料后参数的资料项  先参数后资料的资料项")
    for i in range(len(ids)):
        print(f"  {ids[i]}  {m00[i]:7.3f} {m11[i]:7.3f} {m11[i]-m00[i]:7.3f} {DD[i]:8.3f} {Dth[i]:8.3f}   {path1[0][i]:12.3f}   {path2[0][i]:18.3f}")
    ta_ = a @ (m11 - m00)
    print(f"  目标对比 {cfg['target'][0]}−{cfg['target'][1]}：变化 {ta_:.3f}，其中资料 {a @ DD:.3f}，参数 {a @ Dth:.3f}")

    out = {"posterior_identity": dict(zip(amb["candidates"], map(float, pi))),
           "target_estimate_full": float(est_full), "pev_full": float(pev_full), "pev_avg": float(pev_avg),
           "pev_map": float(pev_map), "between_part": float(a @ between @ a),
           "coverage": {k: v / reps for k, v in cover.items()}, "mse": {k: v / reps for k, v in abs_err.items()},
           "map_wrong": wrong / reps, "target_change": float(ta_),
           "target_data": float(a @ DD), "target_param": float(a @ Dth)}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex34_20_identity_version.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
