#!/usr/bin/env python3
"""习题 34.19  删除、纠错与批次剔除的影响函数：谁是跨场比较的“桥梁记录”

公畜模型（以 σe² = 1 白化）：y = 场（固定，无先验）+ 公畜（随机，先验精度 λ = (4 − h²)/h²）+ e。
    H = J + Σ xᵢxᵢᵀ，b̂ = H⁻¹q，P = H⁻¹，rᵢ = yᵢ − xᵢᵀb̂，hᵢ = xᵢᵀPxᵢ（条件杠杆量）。
单条删除（秩一恒等式）：b̂₋ᵢ − b̂ = −Pxᵢrᵢ/(1 − hᵢ)，P₋ᵢ − P = Pxᵢxᵢᵀ P/(1 − hᵢ)。
成组删除 B：b̂₋B − b̂ = −P X_Bᵀ (I − X_B P X_Bᵀ)⁻¹ r_B。
数值纠错 yᵢ → yᵢ + δ：Δb̂ = P xᵢ δ（精度矩阵不变，无分母）。
目标：场3公畜 S7 与场1公畜 S1 之差 aᵀb。比较“目标特异影响”与“全参数总变化”两种排序。
附加：若公畜作固定效应（λ = 0），删除场3全部桥梁记录后 H 奇异——这是识别结构变化，不是“特别大的影响”。
独立核验：每条记录的快速公式与真正删除后重解逐一比较；成组删除同样核对。
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def load():
    with open(HERE / "data" / "ex34_19_records.csv", encoding="utf-8") as f:
        rec = list(csv.DictReader(f))
    cfg = json.loads((HERE / "data" / "ex34_19_config.json").read_text(encoding="utf-8"))
    return rec, cfg


def build(rec):
    herds = sorted({r["herd"] for r in rec}); sires = sorted({r["sire"] for r in rec})
    X = np.zeros((len(rec), len(herds) + len(sires)))
    for i, r in enumerate(rec):
        X[i, herds.index(r["herd"])] = 1
        X[i, len(herds) + sires.index(r["sire"])] = 1
    y = np.array([float(r["y"]) for r in rec])
    return X, y, herds, sires


def solve(X, y, J):
    H = J + X.T @ X
    return np.linalg.solve(H, X.T @ y), np.linalg.inv(H)


def main() -> None:
    rec, cfg = load()
    X, y, herds, sires = build(rec)
    nh, ns = len(herds), len(sires)
    lam = (4 - cfg["h2"]) / cfg["h2"]
    J = np.zeros((nh + ns,) * 2); J[nh:, nh:] = lam * np.eye(ns)
    b, P = solve(X, y, J)
    r = y - X @ b
    lev = np.einsum("ij,jk,ik->i", X, P, X)
    a = np.zeros(nh + ns)
    a[nh + sires.index(cfg["target"][0])] = 1; a[nh + sires.index(cfg["target"][1])] = -1
    pev_t = float(a @ P @ a)

    # ---------- 单条删除：快速公式 vs 重解 ----------
    infl_t, infl_all, maxerr = [], [], 0.0
    for i in range(len(y)):
        db = -P @ X[i] * r[i] / (1 - lev[i])
        keep = np.arange(len(y)) != i
        b_i, _ = solve(X[keep], y[keep], J)
        maxerr = max(maxerr, float(np.max(np.abs(b_i - b - db))))
        infl_t.append(float(a @ db)); infl_all.append(float(np.linalg.norm(db)))
    assert maxerr < 1e-10, "单条删除公式与重解不一致"
    infl_t, infl_all = np.array(infl_t), np.array(infl_all)
    order_t = np.argsort(-np.abs(infl_t)); order_all = np.argsort(-infl_all)

    # ---------- 成组删除：场3 的桥梁公畜记录 ----------
    B = [i for i, rr in enumerate(rec) if rr["herd"] == "H3" and rr["sire"] == "SB"]
    XB = X[B]
    M = np.eye(len(B)) - XB @ P @ XB.T
    dbB = -P @ XB.T @ np.linalg.solve(M, r[B])
    keep = np.setdiff1d(np.arange(len(y)), B)
    bB, PB = solve(X[keep], y[keep], J)
    assert np.allclose(bB - b, dbB, atol=1e-10), "成组删除公式与重解不一致"
    PB_fast = P + P @ XB.T @ np.linalg.solve(M, XB @ P)
    assert np.allclose(PB, PB_fast, atol=1e-10)
    sum_single = float(np.sum(infl_t[B]))
    pev_tB = float(a @ PB @ a)

    # ---------- 数值纠错 ----------
    ic = next(i for i, rr in enumerate(rec) if rr["rec"] == cfg["correction"]["rec"])
    delta = cfg["correction"]["delta"]
    y2 = y.copy(); y2[ic] += delta
    b2, P2 = solve(X, y2, J)
    assert np.allclose(b2 - b, P @ X[ic] * delta, atol=1e-12) and np.allclose(P2, P)

    # ---------- 公畜作固定效应：识别结构 ----------
    J0 = np.zeros_like(J)
    H0 = J0 + X.T @ X
    rank_full = np.linalg.matrix_rank(H0)
    H0B = J0 + X[keep].T @ X[keep]
    rank_del = np.linalg.matrix_rank(H0B)
    # 固定效应模型只有 nh+ns−1 个可估方向（场与公畜整体平移混杂），删除桥梁后再失去一个
    eig_M0 = None
    Hg = H0 + 1e-12 * np.eye(len(H0))

    print("=" * 72)
    print("习题 34.19  影响函数：删除、纠错与成组剔除")
    print("=" * 72)
    print(f"{len(y)} 条记录，{nh} 个场，{ns} 头公畜，λ = {lam:.0f}；目标 {cfg['target'][0]} − {cfg['target'][1]}"
          f" = {a @ b:.4f}，PEV = {pev_t:.4f}（σe² 单位）")
    print(f"快速删除公式与逐条重解最大差 {maxerr:.1e}")
    print("\n对目标影响最大的 6 条记录：")
    print(f"  {'记录':<6s}{'场':<4s}{'公畜':<5s}{'残差':>8s}{'杠杆':>8s}{'Δ目标':>9s}{'总变化范数':>11s}{'总范数名次':>9s}")
    rank_all = {int(k): j + 1 for j, k in enumerate(order_all)}
    top = []
    for i in order_t[:6]:
        rr = rec[i]
        top.append({"rec": rr["rec"], "herd": rr["herd"], "sire": rr["sire"], "resid": float(r[i]),
                    "leverage": float(lev[i]), "d_target": float(infl_t[i]), "d_norm": float(infl_all[i]),
                    "rank_by_norm": rank_all[int(i)]})
        print(f"  {rr['rec']:<6s}{rr['herd']:<4s}{rr['sire']:<5s}{r[i]:8.3f}{lev[i]:8.3f}{infl_t[i]:9.4f}"
              f"{infl_all[i]:11.4f}{rank_all[int(i)]:9d}")
    print(f"\n杠杆量：场3桥梁记录 {np.round(lev[B], 3).tolist()}；全体中位数 {np.median(lev):.3f}")
    print(f"成组删除场3桥梁记录（{len(B)} 条）：目标变化 {a @ dbB:.4f}（单条之和 {sum_single:.4f}）；"
          f"目标 PEV {pev_t:.4f} → {pev_tB:.4f}")
    print(f"把 {cfg['correction']['rec']} 纠正 δ = {delta}：目标变化 {a @ (P @ X[ic]) * delta:.4f}，PEV 不变")
    print(f"公畜作固定效应：H 的秩 {rank_full}/{len(H0)}；删除桥梁记录后秩 {rank_del}——场3与其公畜整体混杂，"
          "S7 − S1 不再可估")
    rho = float(np.corrcoef(np.argsort(np.argsort(-np.abs(infl_t))), np.argsort(np.argsort(-infl_all)))[0, 1])
    print(f"目标特异影响排序与总范数排序的秩相关 = {rho:.3f}")
    assert rank_del == rank_full - 1

    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex34_19_influence_deletion.json").write_text(json.dumps({
        "lambda": lam, "target_value": float(a @ b), "target_pev": pev_t, "top": top,
        "bridge_leverage": lev[B].tolist(), "median_leverage": float(np.median(lev)),
        "group_delete": {"d_target": float(a @ dbB), "sum_single": sum_single, "pev_after": pev_tB},
        "correction": {"rec": cfg["correction"]["rec"], "delta": delta, "d_target": float(a @ (P @ X[ic]) * delta)},
        "fixed_sire_rank": [int(rank_full), int(rank_del), len(H0)], "rank_corr": rho},
        ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
