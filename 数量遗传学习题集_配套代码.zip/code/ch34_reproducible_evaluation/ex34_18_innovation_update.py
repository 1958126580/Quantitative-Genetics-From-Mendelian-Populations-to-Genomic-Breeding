#!/usr/bin/env python3
"""习题 34.18  新增记录的条件创新：精确增量更新、顺序不变性、复传识别与测定设计

状态向量 θ = (u, c)：加性育种值 u ~ N(0, A σA²)，窝效应 c ~ N(0, I σc²)；记录 y = u_i + c_L(i) + e，均值已知为 0。
旧资料 D 下 θ | D ~ N(m, C)。新批次 z 的条件创新
    v = z − E(z|D)，S = Var(z|D)，K = Cov(θ, z|D)，
    m⁺ = m + K S⁻¹ v，C⁺ = C − K S⁻¹ Kᵀ，目标 aᵀθ 的误差方差减少 Δ_a = aᵀ K S⁻¹ Kᵀ a。
复传记录与旧记录共享同一测量误差，其创新方差为 0（S 奇异）——应识别并删除，而不是加噪声求逆。
测定设计：从 8 个候选新称重中选 3 个，使两只候选公羊之差的误差方差下降最多；比较穷举与贪心。
独立核验：增量更新 = 全资料一次性条件化；分两批任意顺序更新结果相同；Δ_a 等于更新前后方差之差。
"""
from __future__ import annotations

import csv
import itertools
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"


def read_csv(name):
    with open(DATA / name, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def a_matrix(sire, dam):
    n = len(sire); A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        for j in range(i):
            A[i, j] = A[j, i] = 0.5 * ((A[j, s] if s >= 0 else 0) + (A[j, d] if d >= 0 else 0))
        A[i, i] = 1 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0)
    return A


class Model:
    """线性高斯状态模型：记录行 h 只在 u_i 与 c_L 上为 1。"""

    def __init__(self, ped, cfg):
        self.ids = [int(r["id"]) for r in ped]
        pos = {a: k for k, a in enumerate(self.ids)}
        sire = [pos.get(int(r["sire"]), -1) for r in ped]
        dam = [pos.get(int(r["dam"]), -1) for r in ped]
        self.lit = sorted({r["litter"] for r in ped if r["litter"]})
        self.lit_of = {int(r["id"]): r["litter"] for r in ped}
        self.pos = pos
        self.n = len(self.ids); self.nl = len(self.lit)
        A = a_matrix(sire, dam)
        self.Sigma = np.zeros((self.n + self.nl,) * 2)
        self.Sigma[: self.n, : self.n] = A * cfg["var_A"]
        self.Sigma[self.n:, self.n:] = np.eye(self.nl) * cfg["var_c"]
        self.ve = cfg["var_e"]

    def h(self, aid):
        v = np.zeros(self.n + self.nl); v[self.pos[aid]] = 1
        L = self.lit_of[aid]
        if L:
            v[self.n + self.lit.index(L)] = 1
        return v

    def condition(self, H, y, R):
        """一次性条件化：θ | y，y = Hθ + e，Var(e) = R。"""
        V = H @ self.Sigma @ H.T + R
        K = self.Sigma @ H.T
        L = np.linalg.cholesky(V)
        Kt = np.linalg.solve(L, K.T)                     # L⁻¹ Kᵀ
        m = Kt.T @ np.linalg.solve(L, y)
        C = self.Sigma - Kt.T @ Kt
        return m, C


def update(m, C, H, z, ve, tol=1e-10):
    """条件创新更新（新记录误差彼此独立、与旧资料独立）。"""
    v = z - H @ m
    S = H @ C @ H.T + ve * np.eye(len(z))
    K = C @ H.T
    m1 = m + K @ np.linalg.solve(S, v)
    C1 = C - K @ np.linalg.solve(S, K.T)
    return m1, C1, v, S, K


def main() -> None:
    cfg = json.loads((DATA / "ex34_18_config.json").read_text(encoding="utf-8"))
    ped = read_csv("ex34_18_pedigree.csv")
    old = read_csv("ex34_18_old_records.csv")
    new = read_csv("ex34_18_new_batch.csv")
    cands = read_csv("ex34_18_candidates.csv")
    M = Model(ped, cfg)
    ve = M.ve

    Ho = np.array([M.h(int(r["id"])) for r in old]); yo = np.array([float(r["y"]) for r in old])
    m, C = M.condition(Ho, yo, ve * np.eye(len(yo)))

    # ---------- 1. 复传识别：与旧记录共享误差 ----------
    old_by_event = {r["event_id"]: (int(r["id"]), float(r["y"])) for r in old}
    dup_cov = []
    for r in new:
        # 复传与原事件共享测量误差：Cov(z, y_old) 包含 σe²
        base = r["event_id"].rstrip("b")
        if base in old_by_event and old_by_event[base][0] == int(r["id"]):
            k = list(old_by_event).index(base)
            hz = M.h(int(r["id"]))
            # 条件创新方差：Var(z|D) = Var(y_k|D) = 0（y_k 已被观测）
            Vfull = np.block([[Ho @ M.Sigma @ Ho.T + ve * np.eye(len(yo)), (Ho @ M.Sigma @ hz + ve * np.eye(len(yo))[:, k])[:, None]],
                              [(Ho @ M.Sigma @ hz + ve * np.eye(len(yo))[:, k])[None, :], np.array([[hz @ M.Sigma @ hz + ve]])]])
            Vd = Vfull[:-1, :-1]; vzd = Vfull[-1, :-1]
            s_innov = Vfull[-1, -1] - vzd @ np.linalg.solve(Vd, vzd)
            dup_cov.append({"event": r["event_id"], "innovation_var": float(s_innov),
                            "innovation": float(float(r["y"]) - vzd @ np.linalg.solve(Vd, yo))})
    dups = {d["event"] for d in dup_cov if abs(d["innovation_var"]) < 1e-8}
    assert dups, "复传未被识别"
    genuine = [r for r in new if r["event_id"] not in dups]

    # ---------- 2. 增量更新 vs 全资料重算 ----------
    Hz = np.array([M.h(int(r["id"])) for r in genuine]); z = np.array([float(r["y"]) for r in genuine])
    m1, C1, v, S, K = update(m, C, Hz, z, ve)
    mf, Cf = M.condition(np.vstack([Ho, Hz]), np.concatenate([yo, z]), ve * np.eye(len(yo) + len(z)))
    assert np.allclose(m1, mf, atol=1e-10) and np.allclose(C1, Cf, atol=1e-10), "增量更新≠全资料重算"
    # ---------- 3. 顺序不变性 ----------
    a1, b1, *_ = update(*update(m, C, Hz[:2], z[:2], ve)[:2], Hz[2:], z[2:], ve)
    a2, b2, *_ = update(*update(m, C, Hz[2:], z[2:], ve)[:2], Hz[:2], z[:2], ve)
    assert np.allclose(a1, a2, atol=1e-10) and np.allclose(b1, b2, atol=1e-10), "更新顺序改变了结果"

    # ---------- 4. 逐目标信息增量 ----------
    ta, tb = cfg["targets"]["ram_a"], cfg["targets"]["ram_b"]
    a_con = np.zeros(M.n + M.nl); a_con[M.pos[ta]] = 1; a_con[M.pos[tb]] = -1
    KSK = K @ np.linalg.solve(S, K.T)
    rows = []
    for aid in range(15, 23):
        e = np.zeros(M.n + M.nl); e[M.pos[aid]] = 1
        d = float(e @ KSK @ e)
        assert abs(d - (C[M.pos[aid], M.pos[aid]] - C1[M.pos[aid], M.pos[aid]])) < 1e-12
        rows.append({"id": aid, "m_old": float(m[M.pos[aid]]), "m_new": float(m1[M.pos[aid]]),
                     "pev_old": float(C[M.pos[aid], M.pos[aid]]), "pev_new": float(C1[M.pos[aid], M.pos[aid]]), "delta": d})
    d_con = float(a_con @ KSK @ a_con)
    pev_con_old = float(a_con @ C @ a_con)

    # ---------- 5. 测定设计：穷举与贪心 ----------
    W = np.outer(a_con, a_con)
    cand_h = {c["cand"]: M.h(int(c["id"])) for c in cands}

    def value(B, Cb=C1):
        if not B:
            return 0.0
        H = np.array([cand_h[b] for b in B])
        Sb = H @ Cb @ H.T + ve * np.eye(len(B)); Kb = Cb @ H.T
        return float(np.trace(W @ Kb @ np.linalg.solve(Sb, Kb.T)))

    k = cfg["choose_k"]
    allB = sorted(((value(B), B) for B in itertools.combinations(sorted(cand_h), k)), reverse=True)
    best_val, best_B = allB[0]
    greedy, gv_path = [], []
    for _ in range(k):
        nxt = max((c for c in cand_h if c not in greedy), key=lambda c: value(greedy + [c]))
        greedy.append(nxt); gv_path.append(value(greedy))
    single = {c: value([c]) for c in sorted(cand_h)}
    sum_single = sum(single[c] for c in best_B)

    print("=" * 70)
    print("习题 34.18  条件创新与增量更新")
    print("=" * 70)
    for d in dup_cov:
        print(f"复传检查：{d['event']} 的条件创新 = {d['innovation']:.2e}，创新方差 = {d['innovation_var']:.2e} → 删除")
    print(f"有效新记录 {len(genuine)} 条；创新 v = {np.round(v, 3).tolist()}")
    print("增量更新与全资料重算一致（最大差 %.1e）；两种批次顺序结果一致。" % np.max(np.abs(m1 - mf)))
    print(f"\n{'羔羊':>4s}{'旧均值':>9s}{'新均值':>9s}{'旧PEV':>9s}{'新PEV':>9s}{'Δ':>8s}")
    for r in rows:
        print(f"{r['id']:4d}{r['m_old']:9.3f}{r['m_new']:9.3f}{r['pev_old']:9.3f}{r['pev_new']:9.3f}{r['delta']:8.3f}")
    print(f"\n对比 u{ta} − u{tb}：PEV {pev_con_old:.3f} → {pev_con_old - d_con:.3f}，减少 {d_con:.3f}"
          f"；而两只单独减少之和为 {rows[0]['delta'] + rows[4]['delta']:.3f}")
    print(f"\n测定设计（在新资料基础上再选 {k} 个称重，目标为 u{ta} − u{tb}）：")
    print("  单项价值：" + "，".join(f"{c}(羔{int(next(x['id'] for x in cands if x['cand'] == c))})={single[c]:.4f}" for c in single))
    print(f"  穷举最优 {best_B}：联合价值 {best_val:.4f}（单项价值之和 {sum_single:.4f}）")
    print(f"  贪心路径 {greedy}：累计价值 {[round(x, 4) for x in gv_path]}")
    print("  前五个方案：" + "；".join(f"{B} {v_:.4f}" for v_, B in allB[:5]))
    assert best_val >= gv_path[-1] - 1e-12

    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex34_18_innovation_update.json").write_text(json.dumps({
        "duplicates": dup_cov, "innovations": v.tolist(), "per_target": rows,
        "contrast": {"pev_old": pev_con_old, "delta": d_con},
        "design": {"single": single, "best": list(best_B), "best_value": best_val,
                   "greedy": greedy, "greedy_values": gv_path,
                   "top5": [[list(B), v_] for v_, B in allB[:5]]}}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
