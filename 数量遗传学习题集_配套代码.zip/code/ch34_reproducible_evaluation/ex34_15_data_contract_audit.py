#!/usr/bin/env python3
"""习题 34.15  数据契约审计：把登记表、称重事件表与分型样本表变成可追溯的分析表

流程（顺序本身是统计设计的一部分）：
    1. 身份层：主键规范化（统一宽度、未知编码）、重复行、同号冲突，冲突交由裁决表；
    2. 系谱层：父母存在性、性别角色、亲子年龄间隔（违背者把该链接置为未知并记录）；
    3. 事件层：事件编号去重（重复上传≠重复测量）、单位统一、信息截止日；
    4. 派生层：ADG = (w2 − w1)/(a2 − a1)，日龄由出生日期与测定日期计算；
       阻断性错误（负间隔、负增重、缺一端）与提示性异常（罕见但可能真实）分开；
    5. 分型层：截止日前可得、检出率合格、一动物多样本按预定规则形成共识。
独立核验：
    · 守恒：原始事件数 = 进入分析 + 各规则排除数；
    · ADG 两条路径：由“日龄差”与由“日期差”分别计算，二者必须一致；
    · 确定性：输入行序随机打乱后重跑，分析表 SHA-256 完全相同；
    · 朴素连接（不处理一对多）会制造伪重复行，用于对照。
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
DATA, RES = HERE / "data", HERE / "results"


def read_csv(name: str) -> list[dict]:
    with open(DATA / name, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def norm_id(raw: str, width: int, unknown: set[str], adjud: dict) -> str | None:
    """规范化动物主键：未知编码→None；裁决表优先；纯数字补足前导零。"""
    s = raw.strip()
    if s in unknown:
        return None
    if ("animal_id", s) in adjud:
        return adjud[("animal_id", s)]
    return s.zfill(width) if s.isdigit() else s


def pipeline(reg_rows, ev_rows, gs_rows, contract, adjud):
    """完整的确定性流程，返回分析表、审计日志与计数。"""
    unknown = set(contract["unknown_codes"])
    width = contract["id_width"]
    cutoff = dt.date.fromisoformat(contract["cutoff"])
    log: list[dict] = []
    cnt: Counter = Counter()

    # ---------- 1. 身份层 ----------
    seen: dict[str, dict] = {}
    for r in sorted(reg_rows, key=lambda r: tuple(r.values())):
        aid = norm_id(r["animal_id"], width, unknown, adjud)
        rec = {"id": aid, "sex": r["sex"], "birth": dt.date.fromisoformat(r["birth_date"]),
               "sire_raw": r["sire"], "dam_raw": r["dam"], "farm": r["farm"]}
        if aid in seen:
            old = seen[aid]
            if all(old[k] == rec[k] for k in ("sex", "birth", "sire_raw", "dam_raw", "farm")):
                cnt["登记_完全重复行"] += 1
                log.append({"层": "身份", "对象": aid, "规则": "完全重复行", "处理": "删除副本"})
                continue
            key = ("sex", aid)
            if key in adjud:                                   # 冲突只能由裁决表解决
                old["sex"] = adjud[key]
                cnt["登记_同号冲突_裁决"] += 1
                log.append({"层": "身份", "对象": aid, "规则": "同号字段冲突", "处理": f"依裁决表定为 {adjud[key]}"})
                continue
            raise SystemExit(f"阻断：{aid} 存在未裁决的同号冲突")
        seen[aid] = rec
    ped = seen

    # ---------- 2. 系谱层 ----------
    for aid in sorted(ped):
        rec = ped[aid]
        for role, want in (("sire", "M"), ("dam", "F")):
            raw = rec[f"{role}_raw"]
            pid = norm_id(raw, width, unknown, adjud)
            if raw.strip() in unknown and raw.strip() != "":
                cnt["系谱_未知编码统一"] += 1
                log.append({"层": "系谱", "对象": aid, "规则": f"{role} 未知编码'{raw}'", "处理": "统一为空"})
            reason = None
            if pid is not None:
                if pid not in ped:
                    reason = "亲本不在登记表"
                elif ped[pid]["sex"] != want:
                    reason = "性别与亲本角色冲突"
                elif (rec["birth"] - ped[pid]["birth"]).days < contract["min_parent_age_days"]:
                    reason = "亲子年龄间隔不合理"
            if reason:
                cnt[f"系谱_{reason}"] += 1
                log.append({"层": "系谱", "对象": aid, "规则": reason, "处理": f"{role}={pid} 置为未知（保留原值待核）"})
                pid = None
            rec[role] = pid

    # ---------- 3. 事件层 ----------
    events: dict[str, dict] = {}
    for r in sorted(ev_rows, key=lambda r: tuple(r.values())):
        eid = r["event_id"]
        if eid in events:
            cnt["事件_重复上传"] += 1
            log.append({"层": "事件", "对象": eid, "规则": "同一事件编号重复上传", "处理": "保留一个测量事实"})
            continue
        aid = norm_id(r["animal_id"], width, unknown, adjud)
        if r["animal_id"].strip() != aid and ("animal_id", r["animal_id"].strip()) in adjud:
            cnt["事件_主键经裁决映射"] += 1
            log.append({"层": "事件", "对象": eid, "规则": f"主键'{r['animal_id']}'不在登记表", "处理": f"依裁决表映射为 {aid}"})
        if aid not in ped:
            raise SystemExit(f"阻断：事件 {eid} 的动物 {aid} 无法解析")
        unit = r["unit"]
        if unit not in contract["units"]:
            raise SystemExit(f"阻断：事件 {eid} 单位 {unit} 无法解析")
        w = float(r["weight"]) * contract["units"][unit]
        if unit != "kg":
            cnt["事件_单位换算"] += 1
            log.append({"层": "事件", "对象": eid, "规则": f"单位 {unit}", "处理": f"{r['weight']} {unit} → {w:.1f} kg"})
        lo, hi = contract["weight_range_kg"]
        if not lo <= w <= hi:
            raise SystemExit(f"阻断：事件 {eid} 体重 {w} 超出物理范围")
        events[eid] = {"eid": eid, "id": aid, "date": dt.date.fromisoformat(r["date"]), "w": w}
    n_unique = len(events)
    usable = {}
    for eid, e in sorted(events.items()):
        if e["date"] > cutoff:
            cnt["事件_晚于截止日"] += 1
            log.append({"层": "事件", "对象": eid, "规则": "晚于信息截止日", "处理": "保留于原始层，不进入本次分析"})
        else:
            usable[eid] = e

    # ---------- 4. 派生层 ----------
    by_animal: dict[str, list] = defaultdict(list)
    for e in usable.values():
        by_animal[e["id"]].append(e)
    rows, adg_check = [], []
    w_lo, w_hi = contract["window_days"]
    a_lo, a_hi = contract["adg_warn_kg_per_day"]
    ev_used = 0
    for aid in sorted(by_animal):
        evs = sorted(by_animal[aid], key=lambda e: e["date"])
        if len(evs) < 2:
            cnt["派生_缺少一端_ADG缺失"] += 1
            log.append({"层": "派生", "对象": aid, "规则": "截止日前仅一次称重", "处理": "ADG 缺失（状态=未到期），不插补"})
            continue
        e1, e2 = evs[0], evs[-1]
        b = ped[aid]["birth"]
        a1, a2 = (e1["date"] - b).days, (e2["date"] - b).days
        if not (w_lo <= a1 <= w_hi and w_lo <= a2 <= w_hi) or a2 <= a1:
            cnt["派生_日龄窗口或间隔错误"] += 1
            log.append({"层": "派生", "对象": aid, "规则": "日龄不在窗口或间隔非正", "处理": "阻断该动物 ADG"})
            continue
        adg = (e2["w"] - e1["w"]) / (a2 - a1)
        adg_dates = (e2["w"] - e1["w"]) / (e2["date"] - e1["date"]).days      # 第二条路径
        adg_check.append(abs(adg - adg_dates))
        if adg <= 0:
            cnt["派生_负增重_阻断"] += 1
            log.append({"层": "派生", "对象": aid, "规则": f"按日期排序后增重为负（{adg:.3f}）",
                        "处理": "阻断并送人工复核（疑似日期或体重互换录入）"})
            continue
        flag = ""
        if not a_lo <= adg <= a_hi:
            cnt["派生_提示性异常_保留"] += 1
            flag = "复核提示"
            log.append({"层": "派生", "对象": aid, "规则": f"ADG={adg:.3f} 罕见", "处理": "保留并提示复核，不自动删除"})
        ev_used += 2
        rows.append({"animal_id": aid, "sex": ped[aid]["sex"], "farm": ped[aid]["farm"],
                     "sire": ped[aid]["sire"] or "", "dam": ped[aid]["dam"] or "",
                     "age1": a1, "w1": round(e1["w"], 3), "age2": a2, "w2": round(e2["w"], 3),
                     "adg": round(adg, 5), "flag": flag})

    # ---------- 5. 分型层 ----------
    samples = defaultdict(list)
    for r in sorted(gs_rows, key=lambda r: r["sample_id"]):
        aid = norm_id(r["animal_id"], width, unknown, adjud)
        d = dt.date.fromisoformat(r["genotype_date"]); cr = float(r["call_rate"])
        if d > cutoff:
            cnt["分型_晚于截止日"] += 1
            log.append({"层": "分型", "对象": r["sample_id"], "规则": "分型结果晚于截止日", "处理": "本次不可用"})
            continue
        if cr < contract["call_rate_min"]:
            cnt["分型_检出率不合格"] += 1
            log.append({"层": "分型", "对象": r["sample_id"], "规则": f"检出率 {cr}", "处理": "剔除，保留证据"})
            continue
        samples[aid].append((cr, r["sample_id"]))
    consensus = {}
    for aid, lst in samples.items():
        if len(lst) > 1:
            cnt["分型_一动物多样本_取共识"] += 1
            log.append({"层": "分型", "对象": aid, "规则": f"{len(lst)} 个合格样本", "处理": "按预定规则取检出率最高者，其余留档"})
        consensus[aid] = max(lst)[1]
    for row in rows:
        row["sample_id"] = consensus.get(row["animal_id"], "")
    return rows, log, cnt, {"n_unique_events": n_unique, "n_usable_events": len(usable),
                            "n_events_used": ev_used, "adg_path_diff": max(adg_check) if adg_check else 0.0,
                            "pedigree": ped}


def table_hash(rows: list[dict]) -> str:
    keys = sorted(rows[0])
    s = "\n".join("|".join(str(r[k]) for k in keys) for r in sorted(rows, key=lambda r: r["animal_id"]))
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def main() -> None:
    contract = json.loads((DATA / "ex34_15_contract.json").read_text(encoding="utf-8"))
    reg, ev, gs = (read_csv(f"ex34_15_{n}.csv") for n in ("registry", "weigh_events", "genotype_samples"))
    adj = {(r["object"], r["raw_value"]): r["decision"] for r in read_csv("ex34_15_adjudication.csv")}

    rows, log, cnt, info = pipeline(reg, ev, gs, contract, adj)

    # 守恒核验：原始事件 = 去重后事件 + 重复上传；去重后 = 截止日前 + 晚于截止日
    assert len(ev) == info["n_unique_events"] + cnt["事件_重复上传"]
    assert info["n_unique_events"] == info["n_usable_events"] + cnt["事件_晚于截止日"]
    n_blocked_events = info["n_usable_events"] - info["n_events_used"]
    assert info["n_usable_events"] == info["n_events_used"] + n_blocked_events
    assert info["adg_path_diff"] < 1e-12, "两条 ADG 路径不一致"
    # 确定性核验：打乱行序重跑
    rng = np.random.default_rng(contract.get("seed", 34015))
    h1 = table_hash(rows)
    for _ in range(3):
        rr = [reg[i] for i in rng.permutation(len(reg))]
        ee = [ev[i] for i in rng.permutation(len(ev))]
        gg = [gs[i] for i in rng.permutation(len(gs))]
        assert table_hash(pipeline(rr, ee, gg, contract, adj)[0]) == h1, "流程依赖输入行序"
    # 朴素连接对照：动物—样本一对多直接连接
    naive = sum(sum(1 for g in gs if g["animal_id"] == r["animal_id"]) or 1 for r in rows)

    print("=" * 66)
    print("习题 34.15  数据契约审计报告（信息截止日 %s）" % contract["cutoff"])
    print("=" * 66)
    print(f"登记原始行 {len(reg)}，唯一动物 {len(info['pedigree'])}；称重原始行 {len(ev)}，"
          f"唯一事件 {info['n_unique_events']}，截止日前 {info['n_usable_events']}，进入分析 {info['n_events_used']}")
    print(f"分型样本 {len(gs)}，形成共识基因型的动物 {sum(1 for r in rows if r['sample_id'])}（在分析表内）")
    print("\n规则触发计数：")
    for k, v in sorted(cnt.items()):
        print(f"  {k:<24s}{v:3d}")
    print("\n审计日志：")
    for e in log:
        print(f"  [{e['层']}] {e['对象']:<6s} {e['规则']} → {e['处理']}")
    print("\n分析表：")
    print(f"  {'动物':<6s}{'父':<6s}{'母':<6s}{'日龄1':>6s}{'体重1':>7s}{'日龄2':>6s}{'体重2':>7s}{'ADG':>8s}  样本  标记")
    for r in rows:
        print(f"  {r['animal_id']:<6s}{r['sire'] or '—':<6s}{r['dam'] or '—':<6s}{r['age1']:6d}{r['w1']:7.1f}"
              f"{r['age2']:6d}{r['w2']:7.1f}{r['adg']:8.3f}  {r['sample_id'] or '—':<4s}  {r['flag']}")
    print(f"\n朴素连接行数 {naive} 对 正确分析行数 {len(rows)}（多出的行是伪重复）")
    print(f"分析表 SHA-256 = {h1[:16]}…（打乱输入行序 3 次，哈希不变）")

    RES.mkdir(exist_ok=True)
    with open(RES / "ex34_15_analysis_table.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    (RES / "ex34_15_audit.json").write_text(json.dumps(
        {"counts": dict(cnt), "log": log, "n_rows": len(rows), "naive_join_rows": naive, "sha256": h1,
         "n_raw_events": len(ev), "n_unique_events": info["n_unique_events"],
         "n_usable_events": info["n_usable_events"], "n_events_used": info["n_events_used"]},
        ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
