#!/usr/bin/env python3
"""习题 34.16  重复记录不能当作独立样本：公畜可靠度的“宣称值”与“实现值”

数据生成（以千克²计）：y_ijk = μ + s_i + q_ij + e_ijk，
    s_i ~ N(0, σA²/4)        公畜效应；
    q_ij ~ N(0, 3σA²/4 + σpe²) 子代个体效应（孟德尔抽样 + 母亲 + 永久环境，同一子代各次记录共享）；
    e_ijk ~ N(0, σe²)        每次称重的暂时误差。
正确模型：公畜 + 子代（随机）+ 残差；错误模型：只有公畜，把 q 与 e 合成逐次独立残差 σw² = σq² + σe²。
对每种“每头子代记录数 n”，由混合模型方程逆矩阵得到宣称的 PEV（正确：C^{ss}σe²；错误：C^{ss}σw²），
再用 n_rep 次蒙特卡洛重复得到实现的均方误差 E(ŝ − s)² 与校准斜率 b(s|ŝ)。
独立核验：正确模型的全记录 MME 解与“子代均值 + 残差 σq² + σe²/n”的折叠模型解完全一致（充分统计量）。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.linalg import cho_factor, cho_solve

HERE = Path(__file__).resolve().parent


def design(ns: int, npg: int, nrec: int):
    """返回每条记录的公畜与子代索引。"""
    sire = np.repeat(np.arange(ns), npg * nrec)
    prog = np.repeat(np.arange(ns * npg), nrec)
    return sire, prog


def mme(sire, prog, ns, nq, lam_s, lam_q=None):
    """构造 MME 系数矩阵（以残差方差标准化）。lam_q=None 时不含子代效应。"""
    n = len(sire)
    X = np.ones((n, 1))
    Zs = np.zeros((n, ns)); Zs[np.arange(n), sire] = 1
    blocks = [X, Zs]
    if lam_q is not None:
        Zq = np.zeros((n, nq)); Zq[np.arange(n), prog] = 1
        blocks.append(Zq)
    W = np.hstack(blocks)
    C = W.T @ W
    C[1:1 + ns, 1:1 + ns] += lam_s * np.eye(ns)
    if lam_q is not None:
        C[1 + ns:, 1 + ns:] += lam_q * np.eye(nq)
    return W, C


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex34_16_repeated.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    ns, npg = cfg["n_sires"], cfg["progeny_per_sire"]
    vs = cfg["var_A"] / 4
    vq = 3 * cfg["var_A"] / 4 + cfg["var_pe"]
    ve = cfg["var_e"]
    vw = vq + ve
    nq = ns * npg
    out = []
    print("=" * 74)
    print("习题 34.16  重复记录：宣称可靠度与实现可靠度")
    print(f"σs² = {vs:.1f}，σq² = {vq:.1f}，σe² = {ve:.1f}；{ns} 头公畜 × {npg} 头子代；重复 {cfg['n_rep']} 次")
    print("=" * 74)
    print(f"{'n':>3s}{'模型':>6s}{'宣称PEV':>10s}{'实现MSE':>10s}{'宣称r²':>9s}{'实现r²':>9s}{'校准斜率':>10s}")
    for nrec in cfg["records_per_progeny"]:
        sire, prog = design(ns, npg, nrec)
        Wc, Cc = mme(sire, prog, ns, nq, ve / vs, ve / vq)
        Ww, Cw = mme(sire, prog, ns, nq, vw / vs, None)
        fc, fw = cho_factor(Cc), cho_factor(Cw)
        Ci_c = cho_solve(fc, np.eye(Cc.shape[0]))
        Ci_w = cho_solve(fw, np.eye(Cw.shape[0]))
        pev_c = float(np.mean(np.diag(Ci_c)[1:1 + ns])) * ve
        pev_w = float(np.mean(np.diag(Ci_w)[1:1 + ns])) * vw

        S_true, S_c, S_w = [], [], []
        for rep in range(cfg["n_rep"]):
            s = rng.normal(0, np.sqrt(vs), ns)
            q = rng.normal(0, np.sqrt(vq), nq)
            y = cfg["mu"] + s[sire] + q[prog] + rng.normal(0, np.sqrt(ve), len(sire))
            sol_c = cho_solve(fc, Wc.T @ y)
            sol_w = cho_solve(fw, Ww.T @ y)
            if rep == 0:
                # 折叠模型：子代均值 ȳ_ij，残差方差 σq² + σe²/n，公畜随机、μ 固定
                ybar = y.reshape(nq, nrec).mean(1)
                r = vq + ve / nrec
                Wf = np.hstack([np.ones((nq, 1)), np.kron(np.eye(ns), np.ones((npg, 1)))])
                Cf = Wf.T @ Wf; Cf[1:, 1:] += (r / vs) * np.eye(ns)
                sol_f = np.linalg.solve(Cf, Wf.T @ ybar)
                assert np.allclose(sol_f[1:], sol_c[1:1 + ns], atol=1e-9), "折叠模型与全记录模型不一致"
                pev_f = float(np.mean(np.diag(np.linalg.inv(Cf))[1:])) * r
                assert abs(pev_f - pev_c) < 1e-9, "折叠模型 PEV 不一致"
            S_true.append(s); S_c.append(sol_c[1:1 + ns]); S_w.append(sol_w[1:1 + ns])
        S_true, S_c, S_w = map(np.concatenate, (S_true, S_c, S_w))
        for name, est, pev in (("正确", S_c, pev_c), ("错误", S_w, pev_w)):
            mse = float(np.mean((est - S_true) ** 2))
            slope = float(np.cov(S_true, est)[0, 1] / np.var(est, ddof=1))
            rec = {"n_records": nrec, "model": name, "claimed_pev": pev, "realized_mse": mse,
                   "claimed_rel": 1 - pev / vs, "realized_rel": 1 - mse / vs, "calib_slope": slope}
            out.append(rec)
            print(f"{nrec:3d}{name:>6s}{pev:10.4f}{mse:10.4f}{rec['claimed_rel']:9.3f}{rec['realized_rel']:9.3f}{slope:10.3f}")
        # 正确模型：宣称值与实现值在蒙特卡洛误差内一致
        rc = out[-2]
        se = np.sqrt(2 / (cfg["n_rep"] * ns)) * rc["claimed_pev"] * 3     # 宽松 3 倍粗略标准误
        assert abs(rc["claimed_pev"] - rc["realized_mse"]) < se + 0.05 * rc["claimed_pev"], "正确模型 PEV 未校准"
    # 理论极限：n→∞ 时每头子代信息上限 σq²
    lim_rel = npg * vs / (npg * vs + vq)
    print(f"\n理论极限（n→∞，μ 视为已知）：正确模型 r² → {lim_rel:.3f}；错误模型 r² → 1")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex34_16_repeated_records.json").write_text(
        json.dumps({"rows": out, "limit_rel_correct": lim_rel}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
