# 第6章　遗传连锁与连锁图谱的构建——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex06_15_f2_two_point.py
python3 ex06_16_map_order.py
python3 ex06_17_hmm_errors.py
python3 ex06_18_interference.py
python3 ex06_19_segregation_distortion.py
python3 ex06_20_halfsib_phase.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex06_15_f2_two_point.py | 6.15 | F2 共显性标记的两点连锁分析：最大似然、LOD 与信息量 |
| ex06_16_map_order.py | 6.16 | 连锁图谱构建：两点估计、标记排序与多点似然 |
| ex06_17_hmm_errors.py | 6.17 | 隐马尔可夫模型：分型错误如何虚增图谱长度，以及如何用 EM 同时估计重组率与错误率 |
| ex06_18_interference.py | 6.18 | 交叉干涉：计数（χ²）模型的模拟与作图函数比较 |
| ex06_19_segregation_distortion.py | 6.19 | 偏分离：存活选择造成的标记分离比偏离与定位 |
| ex06_20_halfsib_phase.py | 6.20 | 远交半同胞家系的两点连锁：相位未知的似然与检测功效 |
