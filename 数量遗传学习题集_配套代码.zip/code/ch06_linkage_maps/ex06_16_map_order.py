#!/usr/bin/env python3
"""习题 6.16  连锁图谱构建：两点估计、标记排序与多点似然

模拟 150 个回交后代、6 个标记（真实顺序与区间见数据文件，Haldane 无干涉）。
    1. 两点：每对标记的重组率估计 ĉ_ij 与 LOD；
    2. 排序：穷举 6!/2 = 360 种顺序，比较三种准则——
         (a) 相邻重组率之和最小（SAR），(b) 相邻 LOD 之和最大（SAL），(c) 多点似然最大（回交、无干涉、
             相邻区间独立 ⇒ 似然为各相邻区间二项似然之积，参数在每个顺序下分别取 MLE）；
    3. 报告最佳顺序与第二好顺序的 LOD 差（排序的“可信度”），并把相邻区间换算为 Haldane 图距。
"""
from __future__ import annotations
import json
from itertools import permutations
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(order, d_cM, n, rng):
    c = 0.5 * (1 - np.exp(-2 * np.array(d_cM) / 100))
    G = np.zeros((n, len(order)), int); G[:, 0] = rng.integers(0, 2, n)
    for j in range(1, len(order)):
        flip = rng.random(n) < c[j - 1]; G[:, j] = np.where(flip, 1 - G[:, j - 1], G[:, j - 1])
    names = sorted(order); idx = [order.index(m) for m in names]
    return G[:, idx], names


def two_point(G):
    m = G.shape[1]; R = np.zeros((m, m)); L = np.zeros((m, m)); n = G.shape[0]
    for i in range(m):
        for j in range(i + 1, m):
            k = int(np.sum(G[:, i] != G[:, j])); c = k / n
            lod = (k * np.log10(max(c, 1e-12)) + (n - k) * np.log10(max(1 - c, 1e-12)) + n * np.log10(2)) if c < 0.5 else 0.0
            R[i, j] = R[j, i] = c; L[i, j] = L[j, i] = lod
    return R, L


def multipoint_ll(G, order):
    n = G.shape[0]; ll = 0.0
    for a, b in zip(order[:-1], order[1:]):
        k = np.sum(G[:, a] != G[:, b]); c = min(max(k / n, 1e-9), 0.5)
        ll += k * np.log(c) + (n - k) * np.log(1 - c)
    return ll


def main():
    cfg = json.loads((HERE / "data" / "ex06_16_design.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    G, names = simulate(cfg["true_order"], cfg["true_intervals_cM"], cfg["n_backcross"], rng)
    np.savetxt(HERE / "data" / "ex06_16_backcross_genotypes.csv", G, fmt="%d", delimiter=",", header=",".join(names), comments="")
    R, L = two_point(G)
    print("两点重组率估计：")
    print("     " + " ".join(f"{x:>6s}" for x in names))
    for i, a in enumerate(names): print(f"{a:>4s} " + " ".join(f"{R[i,j]:6.3f}" for j in range(len(names))))
    res = []
    for perm in permutations(range(len(names))):
        if perm[0] > perm[-1]: continue
        sar = sum(R[a, b] for a, b in zip(perm[:-1], perm[1:])); sal = sum(L[a, b] for a, b in zip(perm[:-1], perm[1:]))
        res.append((perm, sar, sal, multipoint_ll(G, perm)))
    best_sar = min(res, key=lambda r: r[1]); best_sal = max(res, key=lambda r: r[2]); by_ll = sorted(res, key=lambda r: -r[3])
    fmt = lambda p: "-".join(names[i] for i in p)
    print(f"SAR 最优：{fmt(best_sar[0])}；SAL 最优：{fmt(best_sal[0])}；多点似然最优：{fmt(by_ll[0][0])}")
    dlod = (by_ll[0][3] - by_ll[1][3]) / np.log(10)
    print(f"似然最优与次优顺序（{fmt(by_ll[1][0])}）的 LOD 差 = {dlod:.2f}；真实顺序 = {'-'.join(cfg['true_order'])}")
    best = by_ll[0][0]; ints = []
    for a, b in zip(best[:-1], best[1:]):
        c = R[a, b]; d = -50 * np.log(1 - 2 * c); ints.append(d)
    print("相邻区间 Haldane 图距 (cM) =", np.round(ints, 1), "总长 =", round(sum(ints), 1), "（真值总长", sum(cfg["true_intervals_cM"]), "）")
    out = {"names": names, "R": R.round(4).tolist(), "LOD": L.round(3).tolist(), "best_SAR": fmt(best_sar[0]), "best_SAL": fmt(best_sal[0]),
           "best_ML": fmt(by_ll[0][0]), "second_ML": fmt(by_ll[1][0]), "delta_LOD": dlod, "intervals_cM": ints}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex06_16_map_order.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
