#!/usr/bin/env python3
"""习题 6.19  偏分离：存活选择造成的标记分离比偏离与定位

回交 F1(Aa) × aa 产生 600 个合子，染色体上 43 cM 处有一个存活位点：aa 型合子相对存活率 0.6。
存活下来的后代在 11 个标记上进行 1:1 分离检验。理论：标记距存活位点重组率为 c 时，
    观察到 A 型标记的比例 = [ (1−c)·1 + c·v ] / (1 + v)，v = 0.6
偏离在存活位点附近最大，向两侧按 (1−2c) 衰减。程序给出卡方检验、偏离曲线的理论与观察值，
并以“最大偏离位置”粗略定位存活位点；最后检验偏分离是否使相邻标记重组率估计产生偏差。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import chi2

HERE = Path(__file__).resolve().parent
hal_c = lambda d: 0.5 * (1 - np.exp(-2 * np.abs(d) / 100))


def main():
    cfg = json.loads((HERE / "data" / "ex06_19_distortion.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); pos = np.array(cfg["marker_pos_cM"], float); v = cfg["relative_viability_aa"]
    loc = cfg["viability_locus_cM"]; allpos = np.sort(np.append(pos, loc)); n = cfg["n_zygotes"]
    G = np.zeros((n, len(allpos)), int); G[:, 0] = rng.integers(0, 2, n)
    for j in range(1, len(allpos)):
        c = hal_c(allpos[j] - allpos[j - 1]); G[:, j] = np.where(rng.random(n) < c, 1 - G[:, j - 1], G[:, j - 1])
    k = int(np.where(allpos == loc)[0][0])
    surv = np.where(G[:, k] == 1, True, rng.random(n) < v)          # 1 = A 型（来自 F1 的 A），0 = aa
    M = G[surv][:, [i for i in range(len(allpos)) if i != k]]; N = M.shape[0]
    print(f"合子 {n} 个，存活 {N} 个（期望 {n*(1+v)/2:.0f}）")
    print(f"{'位置cM':>7s}{'A型比例':>9s}{'理论':>8s}{'卡方':>8s}{'p':>10s}")
    rows = []
    for j, x in enumerate(pos):
        pa = M[:, j].mean(); c = hal_c(x - loc); th = ((1 - c) + c * v) / (1 + v)
        X2 = N * (2 * pa - 1) ** 2; p = chi2.sf(X2, 1)
        rows.append({"pos": x, "propA": pa, "theory": th, "chisq": X2, "p": p})
        print(f"{x:7.0f}{pa:9.4f}{th:9.4f}{X2:8.2f}{p:10.2e}")
    peak = rows[int(np.argmax([r["chisq"] for r in rows]))]["pos"]
    print(f"偏离最大的标记位于 {peak:.0f} cM（真实存活位点 {loc} cM）")
    # 复合似然（各标记二项似然之积，忽略标记间相关）对 (位置, 存活率) 的格点估计
    kA = M.sum(0); best = (-np.inf, None, None)
    for L0 in np.arange(0, 100.5, 0.5):
        for vv in np.arange(0.30, 1.001, 0.01):
            th = ((1 - hal_c(pos - L0)) + hal_c(pos - L0) * vv) / (1 + vv)
            ll = float(np.sum(kA * np.log(th) + (N - kA) * np.log(1 - th)))
            if ll > best[0]: best = (ll, L0, vv)
    print(f"复合似然估计：存活位点 ≈ {best[1]:.1f} cM，aa 相对存活率 ≈ {best[2]:.2f}（真值 {loc} cM, {v}）")
    # 相邻标记重组率：选择是否造成偏差？
    c_hat = np.mean(M[:, 1:] != M[:, :-1], axis=0); c_true = hal_c(np.diff(pos))
    print("相邻区间重组率估计：", np.round(c_hat, 3)); print("真实重组率：          ", np.round(c_true, 3))
    out = {"n_survivors": int(N), "markers": rows, "peak_cM": peak, "cl_locus_cM": best[1], "cl_viability": best[2], "c_hat": c_hat.tolist(), "c_true": c_true.tolist()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex06_19_segregation_distortion.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
