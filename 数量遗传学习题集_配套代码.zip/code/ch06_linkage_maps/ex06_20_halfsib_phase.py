#!/usr/bin/env python3
"""习题 6.20  远交半同胞家系的两点连锁：相位未知的似然与检测功效

每头公畜在两个标记上双杂合、相位未知（两种相位等概率），后代中来自公畜的单倍型可判读。
家系 f 中按某一相位计重组 k_f、非重组 n_f − k_f：
    L_f(c) = ½[c^{k}(1−c)^{n−k} + c^{n−k}(1−c)^{k}]，  LOD = Σ_f log10[L_f(ĉ)/L_f(½)]
各家系相位独立，似然相乘，但所有家系共享 c。比较：
    (a) 相位已知（如有祖代资料）时的 LOD；(b) 相位未知时的 LOD；
    在 c = 0.15 下，不同家系数 × 每家后代数组合达到 LOD ≥ 3 的功效（模拟 4000 次）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar

HERE = Path(__file__).resolve().parent


def lod_unknown(k, n):
    k = np.asarray(k, float); n = np.asarray(n, float)
    def nll(c):
        a = k * np.log(c) + (n - k) * np.log(1 - c); b = (n - k) * np.log(c) + k * np.log(1 - c)
        return -np.sum(np.logaddexp(a, b) - np.log(2))
    r = minimize_scalar(nll, bounds=(1e-6, 0.5), method="bounded")
    return (-r.fun + nll(0.5)) / np.log(10), r.x


def lod_known(k, n):
    K, N = np.sum(k), np.sum(n); c = min(K / N, 0.5)
    ll = (K * np.log(c) if K > 0 else 0) + (N - K) * np.log(1 - c)
    return (ll - N * np.log(0.5)) / np.log(10), c


def main():
    cfg = json.loads((HERE / "data" / "ex06_20_halfsib.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); c = cfg["c_true"]; out = {"rows": []}
    print(f"真实 c = {c}，阈值 LOD ≥ {cfg['lod_threshold']}；功效（相位已知 / 相位未知），平均 LOD 损失")
    for F in cfg["n_families"]:
        for m in cfg["offspring_per_family"]:
            pk, pu, loss = 0, 0, []
            for _ in range(cfg["reps"]):
                k = rng.binomial(m, c, F)
                lk, _ = lod_known(k, np.full(F, m)); lu, _ = lod_unknown(k, np.full(F, m))
                pk += lk >= cfg["lod_threshold"]; pu += lu >= cfg["lod_threshold"]; loss.append(lk - lu)
            row = {"families": F, "per_family": m, "power_known": pk / cfg["reps"], "power_unknown": pu / cfg["reps"], "mean_lod_loss": float(np.mean(loss))}
            out["rows"].append(row)
            print(f"  家系 {F:2d} × 后代 {m:3d}：{row['power_known']:.3f} / {row['power_unknown']:.3f}，平均 LOD 损失 {row['mean_lod_loss']:.3f}（上限 {F*np.log10(2):.3f}）")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex06_20_halfsib_phase.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
