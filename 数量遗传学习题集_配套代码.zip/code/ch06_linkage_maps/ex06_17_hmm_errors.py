#!/usr/bin/env python3
"""习题 6.17  隐马尔可夫模型：分型错误如何虚增图谱长度，以及如何用 EM 同时估计重组率与错误率

回交后代 10 个标记，相邻间距 2 cM，分型错误率 ε = 2%（观测以概率 ε 翻转）。
    隐状态：真实基因型 g_j ∈ {0, 1}；转移：P(g_j ≠ g_{j−1}) = c_j；发射：P(o_j ≠ g_j) = ε。
    前向—后向算法给出每个位点真实基因型的后验概率；Baum–Welch(EM) 同时估计 c_j 与 ε。
比较：(a) 忽略错误、按相邻观测直接计数的 c_j；(b) HMM-EM 估计；(c) 真值。
并列出后验“观测错误”概率最高的若干基因型（可疑数据点）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def forward_backward(o, c, eps):
    m = len(o); a = np.zeros((m, 2)); b = np.ones((m, 2))
    E = lambda j: np.array([1 - eps if o[j] == 0 else eps, eps if o[j] == 0 else 1 - eps])
    a[0] = 0.5 * E(0); s = [a[0].sum()]; a[0] /= s[0]
    for j in range(1, m):
        T = np.array([[1 - c[j - 1], c[j - 1]], [c[j - 1], 1 - c[j - 1]]])
        a[j] = (a[j - 1] @ T) * E(j); s.append(a[j].sum()); a[j] /= s[-1]
    for j in range(m - 2, -1, -1):
        T = np.array([[1 - c[j], c[j]], [c[j], 1 - c[j]]])
        b[j] = T @ (E(j + 1) * b[j + 1]); b[j] /= b[j].sum()
    post = a * b; post /= post.sum(1, keepdims=True)
    return post, float(np.sum(np.log(s))), a, b


def em(O, c0, eps0, iters=200):
    c = np.array(c0, float); eps = eps0; n, m = O.shape
    for _ in range(iters):
        rec = np.zeros(m - 1); err = 0.0; ll = 0.0
        for o in O:
            post, l, a, b = forward_backward(o, c, eps); ll += l
            err += np.sum(post[np.arange(m), 1 - o])
            for j in range(m - 1):
                T = np.array([[1 - c[j], c[j]], [c[j], 1 - c[j]]])
                Ej1 = np.array([1 - eps if o[j + 1] == 0 else eps, eps if o[j + 1] == 0 else 1 - eps])
                xi = a[j][:, None] * T * (Ej1 * b[j + 1])[None, :]; xi /= xi.sum()
                rec[j] += xi[0, 1] + xi[1, 0]
        c = np.clip(rec / n, 1e-6, 0.5); eps = max(err / (n * m), 1e-6)
    return c, eps, ll


def main():
    cfg = json.loads((HERE / "data" / "ex06_17_hmm.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); d = np.array(cfg["intervals_cM"]); c_true = 0.5 * (1 - np.exp(-2 * d / 100))
    n, m, eps = cfg["n_backcross"], len(d) + 1, cfg["error_rate"]
    G = np.zeros((n, m), int); G[:, 0] = rng.integers(0, 2, n)
    for j in range(1, m): G[:, j] = np.where(rng.random(n) < c_true[j - 1], 1 - G[:, j - 1], G[:, j - 1])
    flip = rng.random((n, m)) < eps; O = np.where(flip, 1 - G, G)
    np.savetxt(HERE / "data" / "ex06_17_observed.csv", O, fmt="%d", delimiter=",")
    c_naive = np.mean(O[:, 1:] != O[:, :-1], axis=0)
    c_hmm, eps_hat, ll = em(O, np.full(m - 1, 0.05), 0.01)
    haldane = lambda c: -50 * np.log(1 - 2 * np.minimum(c, 0.499))
    L_true, L_naive, L_hmm = haldane(c_true).sum(), haldane(c_naive).sum(), haldane(c_hmm).sum()
    print(f"真实总长 {L_true:.1f} cM；忽略错误的计数估计 {L_naive:.1f} cM；HMM-EM 估计 {L_hmm:.1f} cM（ε̂ = {eps_hat:.4f}，真值 {eps}）")
    print("相邻重组率：真值", np.round(c_true, 4)); print("            直接计数", np.round(c_naive, 4)); print("            HMM-EM  ", np.round(c_hmm, 4))
    # 可疑数据点
    sus = []
    for i, o in enumerate(O):
        post, *_ = forward_backward(o, c_hmm, eps_hat)
        pe = post[np.arange(m), 1 - o]
        for j in np.where(pe > 0.5)[0]: sus.append((i, int(j), float(pe[j]), bool(flip[i, j])))
    sus.sort(key=lambda x: -x[2])
    tp = sum(s[3] for s in sus)
    print(f"后验错误概率 > 0.5 的观测 {len(sus)} 个，其中确为模拟错误 {tp} 个；模拟错误总数 {int(flip.sum())}")
    print("（端点标记只有一侧邻居，单个错误常无法与真实重组区分。）")
    out = {"c_true": c_true.tolist(), "c_naive": c_naive.tolist(), "c_hmm": c_hmm.tolist(), "eps_hat": eps_hat,
           "length_true": L_true, "length_naive": L_naive, "length_hmm": L_hmm, "n_flagged": len(sus), "n_flagged_true_error": int(tp),
           "n_errors": int(flip.sum()), "top_flags": sus[:10]}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex06_17_hmm_errors.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
