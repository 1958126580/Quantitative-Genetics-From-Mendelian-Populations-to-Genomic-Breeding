#!/usr/bin/env python3
"""习题 6.15  F2 共显性标记的两点连锁分析：最大似然、LOD 与信息量

F1 为相引相 AB/ab。配子频率：AB = ab = (1−c)/2，Ab = aB = c/2。F2 九类基因型概率由两配子随机结合得到；
双杂合子 AaBb 可能是 AB/ab（概率 ∝ (1−c)²）或 Ab/aB（∝ c²），重组配子数未知 → 用 EM。
    E 步：双杂合子中“两个重组配子”的后验概率 w = c²/[c² + (1−c)²]
    M 步：c = (确定的重组配子数 + 2w·n_AaBb) / (2N)
LOD = log10 L(ĉ) − log10 L(0.5)；标准误由观测信息得到。
另计算每个个体关于 c 的期望 Fisher 信息，并与回交（1/[c(1−c)]）比较（Allard 1956）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def geno_probs(c):
    g = {"AB": (1 - c) / 2, "ab": (1 - c) / 2, "Ab": c / 2, "aB": c / 2}
    P = np.zeros((3, 3))
    for h1, p1 in g.items():
        for h2, p2 in g.items():
            i = (h1[0] == "a") + (h2[0] == "a"); j = (h1[1] == "b") + (h2[1] == "b")
            P[i, j] += p1 * p2
    return P


def loglik(c, n):
    return float(np.sum(np.asarray(n) * np.log(geno_probs(c))))


def recomb_known(n):
    """非双杂合子中确定的重组配子数（每类基因型含 0/1/2 个重组配子）。"""
    k = np.array([[0, 1, 2], [1, 0, 1], [2, 1, 0]])
    n = np.asarray(n, float); fixed = n * k; fixed[1, 1] = 0
    return fixed.sum()


def em(n, c=0.25, tol=1e-12):
    N = np.sum(n); R = recomb_known(n); dh = n[1][1]
    for _ in range(10000):
        w = c * c / (c * c + (1 - c) ** 2)
        new = (R + 2 * w * dh) / (2 * N)
        if abs(new - c) < tol: return new
        c = new
    return c


def fisher_info(c, eps=1e-6):
    P = geno_probs(c); dP = (geno_probs(c + eps) - geno_probs(c - eps)) / (2 * eps)
    return float(np.sum(dP ** 2 / P))


def main():
    n = json.loads((HERE / "data" / "ex06_15_f2_counts.json").read_text(encoding="utf-8"))["counts"]
    N = int(np.sum(n)); c = em(n)
    lod = (loglik(c, n) - loglik(0.5, n)) / np.log(10)
    e = 1e-5; d2 = (loglik(c + e, n) - 2 * loglik(c, n) + loglik(c - e, n)) / e ** 2
    se = 1 / np.sqrt(-d2)
    grid = np.linspace(0.01, 0.49, 4801); ll = np.array([loglik(x, n) for x in grid])
    assert abs(grid[np.argmax(ll)] - c) < 2e-4, "EM 与格点搜索不一致"
    sup = grid[ll >= ll.max() - np.log(10)]
    print(f"N = {N}，EM 估计 ĉ = {c:.4f}（SE {se:.4f}），LOD = {lod:.2f}，1-LOD 支持区间 = ({sup.min():.4f}, {sup.max():.4f})")
    rows = []
    print(f"{'c':>6s}{'F2信息':>10s}{'回交信息':>10s}{'F2/回交':>9s}")
    for cc in (0.01, 0.05, 0.1, 0.2, 0.3, 0.4):
        iF2 = fisher_info(cc); iBC = 1 / (cc * (1 - cc))
        rows.append({"c": cc, "info_F2": iF2, "info_BC": iBC, "ratio": iF2 / iBC})
        print(f"{cc:6.2f}{iF2:10.3f}{iBC:10.3f}{iF2/iBC:9.3f}")
    out = {"N": N, "c_hat": c, "se": se, "lod": lod, "support_1lod": [float(sup.min()), float(sup.max())], "info_table": rows}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex06_15_f2_two_point.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
