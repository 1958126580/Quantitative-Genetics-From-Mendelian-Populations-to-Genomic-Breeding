#!/usr/bin/env python3
"""习题 6.18  交叉干涉：计数（χ²）模型的模拟与作图函数比较

计数模型（Foss 等 1993；Zhao 等 1995）：在四分体上，交叉“前体”按速率 2(m+1) 每摩尔根的泊松过程出现，
每隔 m 个前体形成一个交叉（起点随机）；m = 0 即无干涉（Haldane）。每个交叉以 1/2 概率进入所考察的染色单体
（无染色单体干涉），因此单条染色单体上交换点期望数为每摩尔根 1 个。
对每个区间长度 d（摩尔根），模拟重组率 c(d) = P(区间内交换点数为奇数)，并与
    Haldane：c = (1 − e^{−2d})/2，   Kosambi：c = tanh(2d)/2
比较；同时估计两个相邻 0.1 M 区间的并发系数（coincidence）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate_chiasmata(L, m, n, rng):
    """返回 n 次减数分裂中单条染色单体上的交换点位置列表。"""
    rate = 2 * (m + 1)                         # 四分体上前体密度（每 M）
    out = []
    for _ in range(n):
        k = rng.poisson(rate * L)
        pos = np.sort(rng.uniform(0, L, k))
        start = rng.integers(0, m + 1)
        chi = pos[start::m + 1]
        chrom = chi[rng.random(len(chi)) < 0.5]   # 每个交叉以 1/2 进入考察染色单体
        out.append(chrom)
    return out


def main():
    cfg = json.loads((HERE / "data" / "ex06_18_interference.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); L = cfg["chrom_length_M"]; n = cfg["n_meioses"]; res = {}
    hal = lambda d: 0.5 * (1 - np.exp(-2 * d)); kos = lambda d: 0.5 * np.tanh(2 * d)
    print(f"{'m':>3s}" + "".join(f"{('d='+str(d)):>10s}" for d in cfg["intervals_M"]) + f"{'并发系数':>10s}")
    for m in cfg["m_values"]:
        ch = simulate_chiasmata(L, m, n, rng); x0 = 0.2
        cs = []
        for d in cfg["intervals_M"]:
            cnt = np.array([np.sum((c > x0) & (c <= x0 + d)) for c in ch]); cs.append(float(np.mean(cnt % 2 == 1)))
        r1 = np.array([np.sum((c > 0.4) & (c <= 0.5)) % 2 for c in ch]); r2 = np.array([np.sum((c > 0.5) & (c <= 0.6)) % 2 for c in ch])
        coin = float(np.mean(r1 & r2) / (r1.mean() * r2.mean()))
        res[str(m)] = {"c": cs, "coincidence": coin}
        print(f"{m:3d}" + "".join(f"{c:10.4f}" for c in cs) + f"{coin:10.3f}")
    print("Haldane" + "".join(f"{hal(d):10.4f}" for d in cfg["intervals_M"]))
    print("Kosambi" + "".join(f"{kos(d):10.4f}" for d in cfg["intervals_M"]))
    res["haldane"] = [hal(d) for d in cfg["intervals_M"]]; res["kosambi"] = [kos(d) for d in cfg["intervals_M"]]
    assert abs(res["0"]["c"][2] - hal(0.2)) < 0.005, "m=0 应与 Haldane 一致"
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex06_18_interference.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
