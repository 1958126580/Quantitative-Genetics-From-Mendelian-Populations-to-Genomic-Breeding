# 第33章　深度学习与基因组基础模型——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex33_15_mlp_vs_gblup.py
python3 ex33_16_conv_motif.py
python3 ex33_17_calibration_prior_shift.py
python3 ex33_18_ensemble_complementarity.py
python3 ex33_19_conformal_shift.py
python3 ex33_20_attribution_ld.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex33_15_mlp_vs_gblup.py | 33.15 | 样本量不是文件中的行数：纯加性与含上位性性状上，岭回归（GBLUP）、小型 MLP 与混合模型的学习曲线 |
| ex33_16_conv_motif.py | 33.16 | 卷积结构与基因组局部性：随机位置的调控基序，卷积滤波器 vs 位置特异线性模型 vs 核苷酸计数 |
| ex33_17_calibration_prior_shift.py | 33.17 | 从基础模型分数到可校准的分子效应概率：先验变化、绝对风险与条件分布变化 |
| ex33_18_ensemble_complementarity.py | 33.18 | 模型组合的收益来自误差互补：两模型最优权重、误差相关与多模型集成 |
| ex33_19_conformal_shift.py | 33.19 | 预测区间与分布外：分裂共形的覆盖率在协变量偏移下失效，加权共形可部分修复 |
| ex33_20_attribution_ld.py | 33.20 | 归因不是因果：连锁不平衡区块内，模型归因最大的 SNP 是真实因果位点的概率 |
