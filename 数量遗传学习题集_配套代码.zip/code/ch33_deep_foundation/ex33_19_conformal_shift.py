#!/usr/bin/env python3
"""习题 33.19  预测区间与分布外：分裂共形的覆盖率在协变量偏移下失效，加权共形可部分修复

设定：x∈R^d，源分布 N(0,I)，目标分布 N(shift·e1, I)；真实 y = xᵀβ + curv·x1² + ε（线性模型被轻度误设）。
在源训练集上拟合线性模型；在源校准集上计算 |残差|，用分裂共形取 (1−α) 分位数得到区间半宽。
(1) 源内测试：覆盖率应≈1−α（有限样本有效性）；
(2) 目标测试（协变量偏移）：未加权共形覆盖率下降（模型误设使目标上的残差更大）；
(3) 加权共形（Tibshirani 等 2019）：权重 w(x)=p_t(x)/p_s(x)，分别用真实密度比与域分类器（逻辑回归）估计；
(4) 按 x1 分箱的条件覆盖率：即便边际覆盖率修复，条件覆盖率仍不均匀。
断言：源内覆盖率落在 [1−α−0.02, 1−α+0.02]；目标上未加权覆盖率 < 1−α−0.04；
真实权重加权共形覆盖率比未加权高且与 1−α 相差 <0.035；估计权重覆盖率也高于未加权；
加权区间平均更宽。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def logistic(X, y, iters=40, ridge=1e-3):
    X1 = np.column_stack([np.ones(len(X)), X]); w = np.zeros(X1.shape[1])
    for _ in range(iters):
        p = 1 / (1 + np.exp(-(X1 @ w))); g = X1.T @ (p - y) + ridge * w
        H = (X1 * (p * (1 - p))[:, None]).T @ X1 + ridge * np.eye(len(w)); w -= np.linalg.solve(H, g)
    return w


def wquantile(res_sorted, w_sorted, w_test, level):
    """对每个测试点的权重 w_test，返回加权共形分位数（含测试点的 +∞ 质点）。"""
    C = np.cumsum(w_sorted); W = C[-1]
    k = np.searchsorted(C, level * (W + w_test), side="left")
    out = np.full(len(w_test), np.inf)
    ok = k < len(res_sorted)
    out[ok] = res_sorted[k[ok]]
    return out


def main():
    cfg = json.loads((HERE / "data" / "ex33_19_config.json").read_text(encoding="utf-8"))
    d, a, sh = cfg["d"], cfg["alpha"], cfg["shift"]
    names = ["源内·分裂共形", "目标·未加权", "目标·真实权重", "目标·估计权重"]
    cov = {k: [] for k in names}; wid = {k: [] for k in names}; ess = []
    cond = {k: [] for k in names[1:]}
    beta = np.linspace(1.0, 0.2, d)
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)

        def gen(n, mu):
            x = rng.normal(0, 1, (n, d)); x[:, 0] += mu
            y = x @ beta + cfg["curv"] * x[:, 0] ** 2 + rng.normal(0, cfg["noise_sd"], n)
            return x, y
        xs, ys = gen(cfg["n_train"], 0); xc, yc = gen(cfg["n_cal"], 0)
        xi, yi = gen(cfg["n_test"], 0); xt, yt = gen(cfg["n_test"], sh)
        X1 = np.column_stack([np.ones(len(xs)), xs]); coef = np.linalg.lstsq(X1, ys, rcond=None)[0]
        f = lambda x: np.column_stack([np.ones(len(x)), x]) @ coef
        res = np.abs(yc - f(xc)); order = np.argsort(res); rs = res[order]
        n = len(rs); q = np.sort(res)[int(np.ceil((n + 1) * (1 - a))) - 1]
        # (1)(2) 标准分裂共形
        ci = np.abs(yi - f(xi)) <= q; ct = np.abs(yt - f(xt)) <= q
        cov[names[0]].append(ci.mean()); wid[names[0]].append(2 * q)
        cov[names[1]].append(ct.mean()); wid[names[1]].append(2 * q)
        # (3) 真实权重 w(x)=exp(shift·x1 − shift²/2)
        wtrue = lambda x: np.exp(sh * x[:, 0] - sh ** 2 / 2)
        # 估计权重：域分类器（源=0，目标=1，用无标签的 x；各取 n_cal 个样本训练）
        xd0 = rng.normal(0, 1, (cfg["n_cal"], d)); xd1 = rng.normal(0, 1, (cfg["n_cal"], d)); xd1[:, 0] += sh
        wd = logistic(np.vstack([xd0, xd1]), np.r_[np.zeros(cfg["n_cal"]), np.ones(cfg["n_cal"])])
        west = lambda x: np.exp(np.column_stack([np.ones(len(x)), x]) @ wd)
        for nm, wf in ((names[2], wtrue), (names[3], west)):
            wc = wf(xc)[order]; wt = wf(xt)
            qt = wquantile(rs, wc, wt, 1 - a)
            hit = np.abs(yt - f(xt)) <= qt
            cov[nm].append(hit.mean()); wid[nm].append(float(np.mean(2 * np.minimum(qt, 1e6))))
            if nm == names[2]:
                ess.append(wc.sum() ** 2 / (wc ** 2).sum())
            edges = np.quantile(xt[:, 0], np.linspace(0, 1, cfg["x1_bins"] + 1)); idx = np.clip(np.searchsorted(edges, xt[:, 0], side="right") - 1, 0, cfg["x1_bins"] - 1)
            cond[nm].append([hit[idx == b].mean() for b in range(cfg["x1_bins"])])
        idx = np.clip(np.searchsorted(np.quantile(xt[:, 0], np.linspace(0, 1, cfg["x1_bins"] + 1)), xt[:, 0], side="right") - 1, 0, cfg["x1_bins"] - 1)
        cond[names[1]].append([ct[idx == b].mean() for b in range(cfg["x1_bins"])])
    print(f"d={d}，shift={sh}，曲率={cfg['curv']}，α={a}，重复 {cfg['reps']} 次；目标 x1 的实际偏移使线性模型误设的残差变大")
    print(f"{'场景':<16}{'覆盖率':>9}{'区间宽度':>10}")
    M = {k: float(np.mean(v)) for k, v in cov.items()}; Wd = {k: float(np.mean(v)) for k, v in wid.items()}
    for k in names:
        print(f"{k:<16}{M[k]:>9.3f}{Wd[k]:>10.3f}")
    print(f"\n真实权重的有效样本量 ESS ≈ {np.mean(ess):.0f}（校准集 {cfg['n_cal']}）")
    print(f"目标上按 x1 五分位的条件覆盖率（由低到高）：")
    for k in names[1:]:
        print(f"  {k:<14}" + "  ".join(f"{v:.3f}" for v in np.mean(cond[k], 0)))
    assert abs(M[names[0]] - (1 - a)) < 0.02
    assert M[names[1]] < 1 - a - 0.04
    assert M[names[2]] > M[names[1]] + 0.02 and abs(M[names[2]] - (1 - a)) < 0.035
    assert M[names[3]] > M[names[1]] + 0.01
    assert Wd[names[2]] > Wd[names[1]]
    out = dict(coverage=M, width=Wd, ess=float(np.mean(ess)), cond={k: np.mean(v, 0).tolist() for k, v in cond.items()})
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex33_19_conformal_shift.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
