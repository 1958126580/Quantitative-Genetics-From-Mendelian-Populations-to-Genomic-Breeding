#!/usr/bin/env python3
"""习题 33.20  归因不是因果：连锁不平衡区块内，模型归因最大的 SNP 是真实因果位点的概率

设定：m 个 SNP 分成 m/B 个区块，块内等相关 ρ（标准化基因型 z）；每块恰有 1 个真实因果位点（随机位置，效应 ±1），
y = Σβ_j z_j + e，遗传力 h²。训练 n 个个体，拟合
 (a) 岭回归（λ=m(1−h²)/h²，即 GBLUP 的等价形式）；(b) Lasso（坐标下降）；(c) 边际单点回归（GWAS 式）。
对线性模型，"梯度×输入"与系数×基因型的平均绝对值归因均与 |β̂_j| 成正比，故以 |β̂_j| 作归因。
指标：块内 argmax 归因 = 因果位点的概率（top-1）；因果位点占块内归因质量的份额；
块内非零系数个数（Lasso 稀疏性）。
断言：ρ=0、n=8000 时岭回归 top-1>0.95；ρ=0.99、n=500 时 top-1<0.5；n=2000 下岭 top-1 随 ρ 单调下降（容差 0.03）；
ρ=0.95 下 top-1 随 n 单调上升；因果位点的归因份额随 ρ 增大而减小；
GWAS 单点回归的 top-1 不高于岭回归（n=2000, ρ=0.8）；Lasso 每块非零数<块大小。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def lasso_cd(G, c, lam, sweeps):
    m = len(c); b = np.zeros(m)
    for _ in range(sweeps):
        for j in range(m):
            rj = c[j] - G[j] @ b + G[j, j] * b[j]
            b[j] = np.sign(rj) * max(abs(rj) - lam, 0) / G[j, j]
    return b


def main():
    cfg = json.loads((HERE / "data" / "ex33_20_config.json").read_text(encoding="utf-8"))
    m, B, h2 = cfg["m"], cfg["block"], cfg["h2"]; nb = m // B
    lam_r = m * (1 - h2) / h2
    res = {}
    print(f"m={m}，{nb} 个区块×{B} 个 SNP，每块 1 个因果位点；h²={h2}；岭 λ={lam_r:.0f}；重复 {cfg['reps']} 次")
    print(f"{'n':>6}{'ρ':>6} |{'岭 top1':>8}{'岭份额':>8}{'Lasso top1':>11}{'非零/块':>8}{'GWAS top1':>10}")
    for n in cfg["n_list"]:
        for rho in cfg["rho_list"]:
            t1 = {"ridge": [], "lasso": [], "gwas": []}; share = []; nz = []
            for r in range(cfg["reps"]):
                rng = np.random.default_rng(cfg["seed"] + 1000 * r + n + int(rho * 100))
                Cb = np.full((B, B), rho) + (1 - rho) * np.eye(B); L = np.linalg.cholesky(Cb)
                Z = np.hstack([rng.normal(size=(n, B)) @ L.T for _ in range(nb)])
                pos = rng.integers(0, B, nb); caus = np.arange(nb) * B + pos
                beta = np.zeros(m); beta[caus] = rng.choice([-1, 1], nb)
                g = Z @ beta; g *= np.sqrt(h2) / g.std(); beta_s = beta * np.sqrt(h2) / (Z @ beta).std()
                y = g + rng.normal(0, np.sqrt(1 - h2), n); y = y - y.mean()
                G = Z.T @ Z / n; c = Z.T @ y / n
                b_r = np.linalg.solve(G + lam_r / n * np.eye(m), c)
                b_l = lasso_cd(G, c, cfg["lasso_lambda"], cfg["lasso_sweeps"])
                b_g = c / np.diag(G)
                for key, b in (("ridge", b_r), ("lasso", b_l), ("gwas", b_g)):
                    A = np.abs(b).reshape(nb, B)
                    t1[key].append(np.mean(A.argmax(1) == pos))
                A = np.abs(b_r).reshape(nb, B); share.append(np.mean(A[np.arange(nb), pos] / A.sum(1)))
                nz.append(np.mean((np.abs(b_l).reshape(nb, B) > 1e-8).sum(1)))
            res[f"{n}|{rho}"] = dict(ridge=float(np.mean(t1["ridge"])), share=float(np.mean(share)), lasso=float(np.mean(t1["lasso"])),
                                      nz=float(np.mean(nz)), gwas=float(np.mean(t1["gwas"])))
            q = res[f"{n}|{rho}"]
            print(f"{n:>6}{rho:>6} |{q['ridge']:>8.3f}{q['share']:>8.3f}{q['lasso']:>11.3f}{q['nz']:>8.2f}{q['gwas']:>10.3f}")
    R = lambda n, rho: res[f"{n}|{rho}"]
    assert R(8000, 0.0)["ridge"] > 0.95
    assert R(500, 0.99)["ridge"] < 0.5
    seq = [R(2000, r)["ridge"] for r in cfg["rho_list"]]
    assert all(seq[i + 1] <= seq[i] + 0.03 for i in range(len(seq) - 1)), seq
    seq = [R(n, 0.95)["ridge"] for n in cfg["n_list"]]
    assert all(seq[i + 1] >= seq[i] - 0.02 for i in range(len(seq) - 1)), seq
    sh = [R(2000, r)["share"] for r in cfg["rho_list"]]
    assert all(sh[i + 1] <= sh[i] + 0.02 for i in range(len(sh) - 1)), sh
    assert R(2000, 0.95)["nz"] < B and R(2000, 0.8)["gwas"] <= R(2000, 0.8)["ridge"]
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex33_20_attribution_ld.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
