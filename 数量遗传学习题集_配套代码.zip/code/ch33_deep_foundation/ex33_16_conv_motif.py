#!/usr/bin/env python3
"""习题 33.16  卷积结构与基因组局部性：随机位置的调控基序，卷积滤波器 vs 位置特异线性模型 vs 核苷酸计数

任务：长度 L 的 DNA 序列，若含基序（motif，如 TGACGT）则以概率 1−label_noise 标为 1，其余为 0；
正例的基序（以 60% 的概率带一个随机错配的简并形式）植入在随机位置（平移不变），反例为随机序列（偶然出现基序的概率约 L/4⁶≈2%）。
模型：
  BAG   ：A/C/G/T 计数的逻辑回归（忽略位置与顺序）；
  POS   ：位置特异一热编码（4L 维）的 L2 逻辑回归（位置相关的线性模型）；
  KMER  ：6-mer 计数的逻辑回归（4096 维，L2）——不受位置限制但参数很多；
  CONV  ：K 个宽度 6 的卷积滤波器 + ReLU + 全局最大池化 + 逻辑输出（numpy 手写反向传播，Adam）。
评价：测试 AUC；训练规模 100–1600；序列长度对 CONV 与 KMER 的影响（L=50/100/200，n=400）。
断言：BAG、POS 接近随机（AUC<0.6）；CONV 在 n=1600 时比 BAG/POS 高 0.2 以上，并与 KMER 相当（相差 <0.04）——卷积靠参数共享，k-mer 靠 4096 维特征；
学到的最强滤波器与真实基序的位置权重矩阵一致（argmax 碱基匹配 ≥5/6）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
NUC = "ACGT"


def one_hot(seqs):
    return np.eye(4)[seqs]                                 # (n,L,4)


MISMATCH_PROB = 0.6


def make_data(rng, n, L, motif, p_pos, noise):
    seqs = rng.integers(0, 4, (n, L)); m = np.array([NUC.index(c) for c in motif]); w = len(m)
    y = (rng.random(n) < p_pos).astype(int)
    for i in np.flatnonzero(y):
        pos = rng.integers(0, L - w + 1); inst = m.copy()
        if rng.random() < MISMATCH_PROB:                      # 简并基序：以概率 MISMATCH_PROB 带一个随机错配
            j = rng.integers(0, w); inst[j] = (inst[j] + rng.integers(1, 4)) % 4
        seqs[i, pos:pos + w] = inst
    flip = rng.random(n) < noise
    return seqs, np.where(flip, 1 - y, y)


def windows(X, w):
    n, L, _ = X.shape
    idx = np.arange(L - w + 1)[:, None] + np.arange(w)[None]
    return X[:, idx, :].reshape(n, L - w + 1, w * 4)


def auc(score, y):
    r = np.argsort(np.argsort(score)) + 1
    n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)


def logreg(F, y, l2, iters=400, lr=0.5):
    w = np.zeros(F.shape[1]); b = 0.0
    for _ in range(iters):
        p = 1 / (1 + np.exp(-(F @ w + b))); g = (p - y) / len(y)
        w -= lr * (F.T @ g + l2 * w); b -= lr * g.sum()
    return lambda Fn: Fn @ w + b


def conv_train(Wt, y, K, epochs, lr, rng, l2=1e-4):
    d = Wt.shape[2]; F = rng.normal(0, 0.5, (K, d)); b0 = np.zeros(K); v = rng.normal(0, 0.5, K); c = 0.0
    P = [F, b0, v]; m_ = [np.zeros_like(x) for x in P] + [0.0]; s_ = [np.zeros_like(x) for x in P] + [0.0]
    n = len(y)
    for t in range(1, epochs + 1):
        S = Wt @ F.T + b0                                   # (n,P,K)
        A = np.maximum(S, 0); idx = A.argmax(1); H = A.max(1)       # (n,K)
        z = H @ v + c; p = 1 / (1 + np.exp(-z)); g = (p - y) / n
        gv = H.T @ g + l2 * v; gc = g.sum()
        dH = np.outer(g, v) * (H > 0)                       # (n,K)
        sel = Wt[np.arange(n)[:, None], idx]                # (n,K,d)
        gF = np.einsum("nk,nkd->kd", dH, sel) + l2 * F; gb = dH.sum(0)
        for j, (par, gr) in enumerate(zip(P, [gF, gb, gv])):
            m_[j] = 0.9 * m_[j] + 0.1 * gr; s_[j] = 0.999 * s_[j] + 0.001 * gr ** 2
            par -= lr * (m_[j] / (1 - 0.9 ** t)) / (np.sqrt(s_[j] / (1 - 0.999 ** t)) + 1e-8)
        m_[3] = 0.9 * m_[3] + 0.1 * gc; s_[3] = 0.999 * s_[3] + 0.001 * gc ** 2
        c -= lr * (m_[3] / (1 - 0.9 ** t)) / (np.sqrt(s_[3] / (1 - 0.999 ** t)) + 1e-8)
    def predict(Wn):
        Hn = np.maximum(Wn @ F.T + b0, 0).max(1); return Hn @ v + c
    return predict, F, v


def kmer_features(seqs, k=6):
    n, L = seqs.shape; out = np.zeros((n, 4 ** k))
    code = sum(seqs[:, j:L - k + 1 + j] * 4 ** (k - 1 - j) for j in range(k))
    for i in range(n):
        out[i] = np.bincount(code[i], minlength=4 ** k)
    return np.minimum(out, 1)


def main():
    cfg = json.loads((HERE / "data" / "ex33_16_config.json").read_text(encoding="utf-8"))
    L, motif = cfg["L"], cfg["motif"]; w = len(motif); res = {}
    models = ("BAG", "POS", "KMER", "CONV"); acc = {k: {n: [] for n in cfg["train_sizes"]} for k in models}
    best_filter = None
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        Xte_s, yte = make_data(rng, cfg["n_test"], L, motif, cfg["p_pos"], cfg["label_noise"])
        Oh_te = one_hot(Xte_s); W_te = windows(Oh_te, w); K_te = kmer_features(Xte_s)
        for n in cfg["train_sizes"]:
            Xs, y = make_data(rng, n, L, motif, cfg["p_pos"], cfg["label_noise"]); Oh = one_hot(Xs)
            bag = logreg(Oh.sum(1) / L, y, 1e-3); acc["BAG"][n].append(auc(bag(Oh_te.sum(1) / L), yte))
            pos = logreg(Oh.reshape(n, -1), y, 0.05); acc["POS"][n].append(auc(pos(Oh_te.reshape(len(yte), -1)), yte))
            km = logreg(kmer_features(Xs), y, 0.02, iters=300); acc["KMER"][n].append(auc(km(K_te), yte))
            pr, F, v = conv_train(windows(Oh, w), y, cfg["n_filters"], cfg["epochs"], cfg["lr"], rng)
            acc["CONV"][n].append(auc(pr(W_te), yte))
            if n == max(cfg["train_sizes"]) and r == 0:
                k = int(np.argmax(v)); best_filter = F[k].reshape(w, 4)
    res = {k: {str(n): float(np.mean(x)) for n, x in d.items()} for k, d in acc.items()}
    print(f"基序 {motif}，L={L}，label 噪声 {cfg['label_noise']}，测试 AUC（重复 {cfg['reps']}）")
    print(f"{'n':>6}" + "".join(f"{k:>8}" for k in models))
    for n in cfg["train_sizes"]:
        print(f"{n:>6}" + "".join(f"{res[k][str(n)]:>8.3f}" for k in models))
    learned = "".join(NUC[i] for i in best_filter.argmax(1))
    print(f"\n最强滤波器每个位置的 argmax 碱基：{learned}（真实基序 {motif}）")
    match = sum(a == b for a, b in zip(learned, motif))
    # 序列长度的影响（n=400）
    lenres = {}
    for LL in cfg["window_check_len"]:
        a_c, a_k = [], []
        for r in range(1):
            rng = np.random.default_rng(cfg["seed"] + 100 + r)
            Xte_s, yte = make_data(rng, 1500, LL, motif, cfg["p_pos"], cfg["label_noise"])
            Xs, y = make_data(rng, 400, LL, motif, cfg["p_pos"], cfg["label_noise"])
            pr, _, _ = conv_train(windows(one_hot(Xs), w), y, cfg["n_filters"], cfg["epochs"], cfg["lr"], rng)
            a_c.append(auc(pr(windows(one_hot(Xte_s), w)), yte))
            km = logreg(kmer_features(Xs), y, 0.02, iters=300); a_k.append(auc(km(kmer_features(Xte_s)), yte))
        lenres[LL] = (float(np.mean(a_c)), float(np.mean(a_k)))
        print(f"L={LL}（n=400）：CONV AUC {lenres[LL][0]:.3f}，KMER AUC {lenres[LL][1]:.3f}")
    s0, s1 = str(cfg["train_sizes"][0]), str(cfg["train_sizes"][-1])
    assert max(res["BAG"].values()) < 0.6 and max(res["POS"].values()) < 0.62
    assert res["CONV"]["1600"] > max(res["BAG"]["1600"], res["POS"]["1600"]) + 0.2
    assert res["CONV"]["800"] > res["KMER"]["800"] - 0.04 and res["CONV"]["400"] > res["KMER"]["400"] - 0.04
    assert match >= 5
    res["learned_filter"] = learned; res["by_length"] = {str(k): v for k, v in lenres.items()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex33_16_conv_motif.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
