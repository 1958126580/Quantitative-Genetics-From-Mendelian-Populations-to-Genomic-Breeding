#!/usr/bin/env python3
"""习题 33.15  样本量不是文件中的行数：纯加性与含上位性性状上，岭回归（GBLUP）、小型 MLP 与混合模型的学习曲线

数据：m 个 SNP（标准化），遗传值 g = 加性部分 + 上位性部分（n_pairs 个成对乘积，占遗传方差的 epi_share），
y = g + e，h² 给定。三种模型（训练样本再划出 20% 作早停/超参验证，测试集独立）：
  RIDGE：岭回归，λ 在验证集上从网格中选（与 GBLUP 等价）；
  MLP：单隐层 tanh 网络（hidden 个单元），Adam + 权重衰减，按验证损失早停（numpy 手写反向传播）；
  HYBRID：先岭回归，再用 MLP 拟合其残差（验证集早停），预测为二者之和。
指标：对真实遗传值 g 的测试相关。
断言：纯加性性状上 RIDGE ≥ MLP（小样本差距最大）；含上位性且样本足够时 HYBRID 与 MLP 都超过 RIDGE；
MLP 的学习曲线上升更陡；小样本（最小 n）上 MLP 不优于 RIDGE。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def make_data(rng, n, m, cfg, pairs, w_add, w_epi, scale):
    p = rng.uniform(0.2, 0.5, m)
    X = rng.binomial(2, p, (n, m)).astype(float)
    Z = (X - 2 * p) / np.sqrt(2 * p * (1 - p))
    g_add = Z @ w_add
    g_epi = sum(w * Z[:, i] * Z[:, j] for w, (i, j) in zip(w_epi, pairs))
    return Z, g_add, g_epi


def ridge_fit(Z, y, lams, Zv, yv):
    mu = y.mean(); best = None
    U, s, Vt = np.linalg.svd(Z, full_matrices=False)
    uty = U.T @ (y - mu)
    for lam in lams:
        beta = Vt.T @ (s / (s ** 2 + lam) * uty)
        err = np.mean((yv - mu - Zv @ beta) ** 2)
        if best is None or err < best[0]:
            best = (err, lam, beta)
    return mu, best[2]


def mlp_train(Z, y, Zv, yv, hidden, epochs, lr, wd, rng):
    n, m = Z.shape
    W1 = rng.normal(0, 1 / np.sqrt(m), (m, hidden)); b1 = np.zeros(hidden)
    W2 = rng.normal(0, 1 / np.sqrt(hidden), hidden); b2 = 0.0
    params = [W1, b1, W2]; mom = [np.zeros_like(p_) for p_ in params]; vel = [np.zeros_like(p_) for p_ in params]
    ym = y.mean(); ys = y.std(); yt = (y - ym) / ys
    best = (np.inf, None); t = 0; patience = 0
    for ep in range(epochs):
        H = np.tanh(Z @ W1 + b1); pred = H @ W2 + b2
        d = (pred - yt) / n
        gW2 = H.T @ d + wd * W2; gb2 = d.sum()
        dH = np.outer(d, W2) * (1 - H ** 2)
        gW1 = Z.T @ dH + wd * W1; gb1 = dH.sum(0)
        t += 1
        for k, (p_, g_) in enumerate(zip(params, [gW1, gb1, gW2])):
            mom[k] = 0.9 * mom[k] + 0.1 * g_; vel[k] = 0.999 * vel[k] + 0.001 * g_ ** 2
            p_ -= lr * (mom[k] / (1 - 0.9 ** t)) / (np.sqrt(vel[k] / (1 - 0.999 ** t)) + 1e-8)
        b2 -= lr * gb2
        vp = np.tanh(Zv @ W1 + b1) @ W2 + b2
        vl = np.mean((vp - (yv - ym) / ys) ** 2)
        if vl < best[0] - 1e-6:
            best = (vl, ([W1.copy(), b1.copy(), W2.copy(), b2])); patience = 0
        else:
            patience += 1
            if patience > 40:
                break
    W1, b1, W2, b2 = best[1]
    return lambda Zn: (np.tanh(Zn @ W1 + b1) @ W2 + b2) * ys + ym


def main():
    cfg = json.loads((HERE / "data" / "ex33_15_config.json").read_text(encoding="utf-8"))
    m = cfg["m"]; res = {}
    lams = [m * x for x in (0.1, 0.3, 1, 3, 10, 30, 100)]
    for trait, epi in (("additive", 0.0), ("epistatic", cfg["epi_share"])):
        acc = {k: {n: [] for n in cfg["train_sizes"]} for k in ("RIDGE", "MLP", "HYBRID")}
        for r in range(cfg["reps"]):
            rng = np.random.default_rng(cfg["seed"] + r)
            pairs = [tuple(rng.choice(m, 2, replace=False)) for _ in range(cfg["n_pairs"])]
            w_add = rng.normal(0, 1, m) / np.sqrt(m); w_epi = rng.normal(0, 1, len(pairs))
            nmax = max(cfg["train_sizes"]) + cfg["n_test"]
            Z, ga, ge = make_data(rng, nmax, m, cfg, pairs, w_add, w_epi, 1.0)
            ga = ga / ga.std(); ge = ge / ge.std() if epi > 0 else ge * 0
            g = np.sqrt(1 - epi) * ga + np.sqrt(epi) * ge; g = g / g.std() * np.sqrt(cfg["h2"])
            y = g + rng.normal(0, np.sqrt(1 - cfg["h2"]), nmax)
            te = np.arange(nmax - cfg["n_test"], nmax)
            for n in cfg["train_sizes"]:
                nv = int(0.2 * n); tr = np.arange(n - nv); va = np.arange(n - nv, n)
                mu, beta = ridge_fit(Z[tr], y[tr], lams, Z[va], y[va])
                pr_r = mu + Z[te] @ beta
                f = mlp_train(Z[tr], y[tr], Z[va], y[va], cfg["hidden"], cfg["epochs"], cfg["lr"], cfg["weight_decay"], rng)
                pr_m = f(Z[te])
                res_tr = y[tr] - (mu + Z[tr] @ beta); res_va = y[va] - (mu + Z[va] @ beta)
                f2 = mlp_train(Z[tr], res_tr, Z[va], res_va, cfg["hidden"], cfg["epochs"], cfg["lr"], cfg["weight_decay"], rng)
                pr_h = pr_r + f2(Z[te]) - res_tr.mean()
                for k, pr in (("RIDGE", pr_r), ("MLP", pr_m), ("HYBRID", pr_h)):
                    acc[k][n].append(np.corrcoef(pr, g[te])[0, 1])
        res[trait] = {k: {str(n): float(np.mean(v)) for n, v in d.items()} for k, d in acc.items()}
        print(f"\n性状：{trait}（epi_share={epi}），m={m}，h²={cfg['h2']}，重复 {cfg['reps']}")
        print(f"{'n':>6}{'RIDGE':>9}{'MLP':>9}{'HYBRID':>9}")
        for n in cfg["train_sizes"]:
            print(f"{n:>6}{res[trait]['RIDGE'][str(n)]:>9.3f}{res[trait]['MLP'][str(n)]:>9.3f}{res[trait]['HYBRID'][str(n)]:>9.3f}")
    s0, s1 = str(cfg["train_sizes"][0]), str(cfg["train_sizes"][-1])
    A, E = res["additive"], res["epistatic"]
    assert all(A["RIDGE"][str(n)] >= A["MLP"][str(n)] - 0.01 for n in cfg["train_sizes"])
    assert E["MLP"][s0] <= E["RIDGE"][s0] + 0.02
    assert E["HYBRID"][s1] > E["RIDGE"][s1] + 0.01 or E["MLP"][s1] > E["RIDGE"][s1] + 0.01
    assert (E["MLP"][s1] - E["MLP"][s0]) > (E["RIDGE"][s1] - E["RIDGE"][s0])
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex33_15_mlp_vs_gblup.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
