#!/usr/bin/env python3
"""习题 33.17  从基础模型分数到可校准的分子效应概率：先验变化、绝对风险与条件分布变化

设定：基础模型对变异给出一维分数 s（如参考与变异序列的对数似然差）。真实"有功能效应"标签 y∈{0,1}，
给定 y 时 s~N(μ_y,1)（μ_0=0，μ_1=mu_pos）。源数据（已标注的富集集合）患病率 π_s=0.30；
部署目标为随机变异，π_t=0.02。
(1) 在源数据上用 Platt 逻辑回归 P(y=1|s)=σ(a+bs) 校准；
(2) 直接用于目标：ECE（10 箱）、Brier、阈值 0.5 的 PPV 与召回、预测的阳性数 vs 真实阳性数；AUC 不随患病率变化；
(3) 先验偏移修正：logit_t = a + b s + log(π_t/(1−π_t)) − log(π_s/(1−π_s))，再次评价；
(4) 条件分布也变化（目标中 μ_1 降为 mu_pos_shifted，如跨物种迁移）：先验修正不够，用 n_target_labeled 个目标标注重新估 (a,b) 并保持先验项。
断言：AUC 在三种使用方式下不变；直接使用时 ECE 大、预测阳性数远超真实；先验修正后 ECE<0.01 且预测阳性数接近真实；
条件分布变化时先验修正后在高分端仍过度自信，用目标标注重校准后更接近实际（以前 1% 高分箱的预测与实际频率衡量）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def sample(rng, n, prev, mu1):
    y = (rng.random(n) < prev).astype(int)
    return rng.normal(0, 1, n) + mu1 * y, y


def platt(s, y, iters=50):
    X = np.column_stack([np.ones_like(s), s]); w = np.zeros(2)
    for _ in range(iters):
        p = 1 / (1 + np.exp(-(X @ w))); g = X.T @ (p - y)
        H = (X * (p * (1 - p))[:, None]).T @ X + 1e-9 * np.eye(2)
        w -= np.linalg.solve(H, g)
    return w


def auc(score, y):
    r = np.argsort(np.argsort(score)) + 1; n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)


def ece(p, y, bins):
    edges = np.quantile(p, np.linspace(0, 1, bins + 1)); idx = np.clip(np.searchsorted(edges, p, side="right") - 1, 0, bins - 1)
    return float(sum((idx == b).mean() * abs(p[idx == b].mean() - y[idx == b].mean()) for b in range(bins) if np.any(idx == b)))


def report(name, p, y, thr):
    pred_pos = (p > thr).sum(); tp = ((p > thr) & (y == 1)).sum()
    k = max(int(0.01 * len(p)), 1); top = np.argsort(-p)[:k]
    return dict(name=name, top_pred=float(p[top].mean()), top_true=float(y[top].mean()), ece=ece(p, y, 10), brier=float(np.mean((p - y) ** 2)), ppv=float(tp / max(pred_pos, 1)), recall=float(tp / y.sum()),
                expected_pos=float(p.sum()), true_pos=int(y.sum()))


def main():
    cfg = json.loads((HERE / "data" / "ex33_17_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); ps, pt = cfg["prev_source"], cfg["prev_target"]
    s_src, y_src = sample(rng, cfg["n_source"], ps, cfg["mu_pos"]); a, b = platt(s_src, y_src)
    lo = np.log(pt / (1 - pt)) - np.log(ps / (1 - ps)); sig = lambda z: 1 / (1 + np.exp(-z))
    print(f"Platt（源，π_s={ps}）：a={a:.3f}，b={b:.3f}（理论 b=μ₁={cfg['mu_pos']}，a=−μ₁²/2+logit π_s={-cfg['mu_pos']**2/2+np.log(ps/(1-ps)):.3f}）；先验位移 {lo:.3f}")
    out = {}
    rows = []
    # 场景 A：只有先验变化
    s_t, y_t = sample(rng, cfg["n_target"], pt, cfg["mu_pos"])
    pA_direct = sig(a + b * s_t); pA_fix = sig(a + b * s_t + lo)
    rows += [report("A 先验变化：直接使用", pA_direct, y_t, cfg["threshold"]), report("A 先验变化：先验修正", pA_fix, y_t, cfg["threshold"])]
    auc_A = auc(s_t, y_t)
    # 场景 B：先验与条件分布都变
    s_b, y_b = sample(rng, cfg["n_target"], pt, cfg["mu_pos_shifted"])
    pB_direct = sig(a + b * s_b); pB_fix = sig(a + b * s_b + lo)
    s_l, y_l = sample(rng, cfg["n_target_labeled"], pt, cfg["mu_pos_shifted"])
    # 小样本重校准：目标标注很少（含约 8 个阳性），对 (a,b) 加岭惩罚到先验修正后的值
    X = np.column_stack([np.ones_like(s_l), s_l]); w = np.array([a + lo, b]); w0 = w.copy(); lam = 2.0
    for _ in range(80):
        p_ = sig(X @ w); g = X.T @ (p_ - y_l) + lam * (w - w0)
        H = (X * (p_ * (1 - p_))[:, None]).T @ X + lam * np.eye(2) + 1e-9 * np.eye(2); w -= np.linalg.solve(H, g)
    pB_re = sig(w[0] + w[1] * s_b)
    rows += [report("B 条件也变：直接使用", pB_direct, y_b, cfg["threshold"]), report("B 条件也变：先验修正", pB_fix, y_b, cfg["threshold"]),
             report("B 条件也变：目标重校准", pB_re, y_b, cfg["threshold"])]
    auc_B = auc(s_b, y_b)
    print(f"\nAUC：场景A {auc_A:.3f}（理论 Φ(μ₁/√2)={0.5*(1+__import__('math').erf(cfg['mu_pos']/2)):.3f}）；场景B {auc_B:.3f}；源 {auc(s_src, y_src):.3f}")
    print(f"{'方案':<20}{'ECE':>8}{'Brier':>9}{'PPV@0.5':>9}{'召回':>7}{'预测阳性数':>11}{'真实阳性数':>11}{'前1%预测':>10}{'前1%实际':>10}")
    for r in rows:
        print(f"{r['name']:<20}{r['ece']:>8.4f}{r['brier']:>9.4f}{r['ppv']:>9.3f}{r['recall']:>7.3f}{r['expected_pos']:>11.0f}{r['true_pos']:>11d}{r['top_pred']:>10.3f}{r['top_true']:>10.3f}")
    r1, r2, r3, r4, r5 = rows
    assert abs(auc_A - auc(s_src, y_src)) < 0.02
    assert r1["ece"] > 0.1 and r1["expected_pos"] > 5 * r1["true_pos"]
    assert r2["ece"] < 0.01 and abs(r2["expected_pos"] / r2["true_pos"] - 1) < 0.08
    assert r4["ece"] > r2["ece"] and r4["ece"] > 0.004
    assert abs(r5["top_pred"] - r5["top_true"]) < abs(r4["top_pred"] - r4["top_true"])      # 高分端：重校准更接近实际
    assert r4["top_pred"] > 1.3 * r4["top_true"]                                              # 仅先验修正在高分端过度自信
    out = {r["name"]: r for r in rows}; out["auc"] = dict(A=float(auc_A), B=float(auc_B))
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex33_17_calibration_prior_shift.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
