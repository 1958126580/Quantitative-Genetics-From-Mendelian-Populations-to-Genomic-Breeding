#!/usr/bin/env python3
"""习题 33.18  模型组合的收益来自误差互补：两模型最优权重、误差相关与多模型集成

数据：含加性与成对上位性的性状（m 个 SNP，epi_share 的遗传方差来自 n_pairs 个成对乘积），y=g+e。
三个模型：RIDGE（加性）、RBF（高斯核岭回归，非线性）、POLY2（二次多项式核 (1+zᵀz'/m)² 岭回归）。
在验证集上计算各模型的预测误差 e_k = ŷ_k − g（对真实遗传值，便于核验），估计 σ_k、误差相关 ρ。
两模型理论：最优权重 w* = (σ₂²−ρσ₁σ₂)/(σ₁²+σ₂²−2ρσ₁σ₂)，组合方差 σ₁²σ₂²(1−ρ²)/(σ₁²+σ₂²−2ρσ₁σ₂)。
报告：(1) 各模型测试 r、RMSE；(2) 误差相关矩阵；(3) 两两最优权重（用验证集误差估计）下组合的测试 RMSE 与理论值；
(4) 三模型等权与"验证集最优权重"集成；(5) M 个等相关（ρ）误差的集成方差 σ²(ρ+(1−ρ)/M) 的理论值与 M→∞ 极限 ρσ²。
断言：RIDGE 与 POLY2 误差相关高于 RIDGE 与 RBF？（以输出为准，仅断言：组合 RMSE 不大于最佳单模型 + 容差；
理论与实测的两模型组合 RMSE 相对误差 <5%；集成方差公式在模拟中成立。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def make(rng, cfg, n):
    m = cfg["m"]; p = rng.uniform(0.2, 0.5, m)
    pairs = [tuple(rng.choice(m, 2, replace=False)) for _ in range(cfg["n_pairs"])]
    return p, pairs


def geno(rng, p, n):
    return (rng.binomial(2, p, (n, len(p))) - 2 * p) / np.sqrt(2 * p * (1 - p))


def gval(Z, w_add, pairs, w_epi, epi, scale):
    ga = Z @ w_add; ge = sum(w * Z[:, i] * Z[:, j] for w, (i, j) in zip(w_epi, pairs))
    return ga, ge


def krr(Ztr, ytr, Zte_list, kernel, lam):
    K = kernel(Ztr, Ztr); mu = ytr.mean()
    a = np.linalg.solve(K + lam * np.eye(len(ytr)), ytr - mu)
    return [mu + kernel(Z, Ztr) @ a for Z in Zte_list]


def main():
    cfg = json.loads((HERE / "data" / "ex33_18_config.json").read_text(encoding="utf-8")); m = cfg["m"]
    lin = lambda A, B: A @ B.T / m
    rbf = lambda A, B: np.exp(-cfg["gamma_rbf"] * ((A ** 2).sum(1)[:, None] + (B ** 2).sum(1)[None] - 2 * A @ B.T))
    poly = lambda A, B: (1 + A @ B.T / m) ** 2
    kernels = {"RIDGE": (lin, cfg["lam_ridge"] / m), "RBF": (rbf, cfg["lam_rbf"]), "POLY2": (poly, cfg["lam_ridge"] / m * 3)}
    names = list(kernels)
    acc = {k: [] for k in names}; rm = {k: [] for k in names}; corr = []; pair = {}
    ens_eq, ens_opt = [], []
    for r in range(cfg["reps"]):
        rng = np.random.default_rng(cfg["seed"] + r)
        p, pairs = make(rng, cfg, 0); w_add = rng.normal(0, 1, m); w_epi = rng.normal(0, 1, len(pairs))
        ntot = cfg["n_train"] + cfg["n_val"] + cfg["n_test"]; Z = geno(rng, p, ntot)
        ga, ge = gval(Z, w_add, pairs, w_epi, cfg["epi_share"], 1)
        g = np.sqrt(1 - cfg["epi_share"]) * ga / ga.std() + np.sqrt(cfg["epi_share"]) * ge / ge.std()
        g = g / g.std() * np.sqrt(cfg["h2"]); y = g + rng.normal(0, np.sqrt(1 - cfg["h2"]), ntot)
        tr = np.arange(cfg["n_train"]); va = np.arange(cfg["n_train"], cfg["n_train"] + cfg["n_val"]); te = np.arange(cfg["n_train"] + cfg["n_val"], ntot)
        pv, pt = {}, {}
        for k, (ker, lam) in kernels.items():
            pv[k], pt[k] = krr(Z[tr], y[tr], [Z[va], Z[te]], ker, lam)
            acc[k].append(np.corrcoef(pt[k], g[te])[0, 1]); rm[k].append(np.sqrt(np.mean((pt[k] - g[te]) ** 2)))
        Ev = np.array([pv[k] - g[va] for k in names]); Et = np.array([pt[k] - g[te] for k in names])
        corr.append(np.corrcoef(Et))
        for i in range(3):
            for j in range(i + 1, 3):
                s1, s2 = Ev[i].std(), Ev[j].std(); rho = np.corrcoef(Ev[i], Ev[j])[0, 1]
                w = (s2 ** 2 - rho * s1 * s2) / (s1 ** 2 + s2 ** 2 - 2 * rho * s1 * s2)
                comb = w * pt[names[i]] + (1 - w) * pt[names[j]]
                t1, t2 = Et[i].std(), Et[j].std(); rt = np.corrcoef(Et[i], Et[j])[0, 1]
                theo = np.sqrt(t1 ** 2 * t2 ** 2 * (1 - rt ** 2) / (t1 ** 2 + t2 ** 2 - 2 * rt * t1 * t2))
                pair.setdefault((names[i], names[j]), []).append((w, np.sqrt(np.mean((comb - g[te]) ** 2)), theo, min(rm[names[i]][-1], rm[names[j]][-1])))
        ens_eq.append(np.sqrt(np.mean((np.mean([pt[k] for k in names], 0) - g[te]) ** 2)))
        # 三模型验证集最优权重（最小二乘，约束和为 1 的闭式解）
        C = np.cov(Ev); one = np.ones(3); wopt = np.linalg.solve(C + 1e-9 * np.eye(3), one); wopt /= wopt.sum()
        ens_opt.append(np.sqrt(np.mean((sum(wopt[i] * pt[names[i]] for i in range(3)) - g[te]) ** 2)))
    print(f"重复 {cfg['reps']} 次；n_train={cfg['n_train']}，h²={cfg['h2']}，epi_share={cfg['epi_share']}")
    print(f"{'模型':<8}{'测试 r':>8}{'RMSE':>8}")
    for k in names:
        print(f"{k:<8}{np.mean(acc[k]):>8.3f}{np.mean(rm[k]):>8.3f}")
    C = np.mean(corr, 0)
    print("\n测试误差相关：" + "；".join(f"{names[i]}-{names[j]} {C[i,j]:.3f}" for i in range(3) for j in range(i + 1, 3)))
    print(f"\n{'两两组合':<14}{'最优权重(前者)':>14}{'组合RMSE':>10}{'理论RMSE':>10}{'较佳单模型':>11}")
    out = {"acc": {k: float(np.mean(v)) for k, v in acc.items()}, "rmse": {k: float(np.mean(v)) for k, v in rm.items()}, "pair": {}}
    for (a, b), rows in pair.items():
        R = np.mean(rows, 0); out["pair"][f"{a}+{b}"] = R.tolist()
        print(f"{a+'+'+b:<14}{R[0]:>14.3f}{R[1]:>10.4f}{R[2]:>10.4f}{R[3]:>11.4f}")
        assert R[1] <= R[3] + 0.005 and abs(R[1] - R[2]) / R[2] < 0.06
    print(f"\n三模型：等权 RMSE {np.mean(ens_eq):.4f}；验证集最优权重 RMSE {np.mean(ens_opt):.4f}；最佳单模型 RMSE {min(np.mean(v) for v in rm.values()):.4f}")
    # 等相关集成的方差公式
    rng = np.random.default_rng(cfg["seed"] + 999); rho, s2 = 0.6, 1.0; out["equicorr"] = {}
    print("\n等相关误差的 M 模型等权集成方差（σ²=1，ρ=0.6）：模拟 vs 理论 σ²(ρ+(1−ρ)/M)")
    for M in (1, 2, 4, 8, 32):
        C0 = np.full((M, M), rho) + (1 - rho) * np.eye(M); L = np.linalg.cholesky(C0)
        e = rng.normal(size=(200000, M)) @ L.T; sim = e.mean(1).var(); th = s2 * (rho + (1 - rho) / M)
        out["equicorr"][str(M)] = (float(sim), th); print(f"  M={M:>2}: {sim:.4f} vs {th:.4f}")
        assert abs(sim - th) < 0.02
    assert np.mean(ens_opt) <= min(np.mean(v) for v in rm.values()) + 0.003
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex33_18_ensemble_complementarity.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
