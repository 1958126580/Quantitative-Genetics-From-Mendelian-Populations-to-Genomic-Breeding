# 第22章　动物模型与复杂遗传效应——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex22_15_animal_model_mme.py
python3 ex22_16_sire_vs_animal.py
python3 ex22_17_maternal_kernels.py
python3 ex22_18_social_effects.py
python3 ex22_19_crossbreeding.py
python3 ex22_20_unknown_parent_groups.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex22_15_animal_model_mme.py | 22.15 | 动物模型 BLUP：无记录祖先的信息回传、吸收（Schur 补）与“直接删除”的区别 |
| ex22_16_sire_vs_animal.py | 22.16 | 公畜模型与动物模型的尺度桥梁：等价条件、λ_s = (4 − h²)/h² 与错误方差比的后果 |
| ex22_17_maternal_kernels.py | 22.17 | 母体模型的协方差核、亲属协方差核验与可识别性（同母一窝 vs 同母两窝） |
| ex22_18_social_effects.py | 22.18 | 社会（间接）遗传效应：总育种值、亲缘组群与个体/群体选择响应，及不规则接触网络 |
| ex22_19_crossbreeding.py | 22.19 | 杂交均值模型的可识别性：品种组成、母体品种、直接与母体杂种优势；纯种—杂种信息上限 |
| ex22_20_unknown_parent_groups.py | 22.20 | 未知亲本组（遗传组）：引入遗传水平不同的外来公畜时的基准偏差与 QP 变换 |
