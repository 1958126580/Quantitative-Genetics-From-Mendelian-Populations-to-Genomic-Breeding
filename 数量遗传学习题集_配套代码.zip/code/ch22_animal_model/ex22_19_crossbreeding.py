#!/usr/bin/env python3
"""习题 22.19  杂交均值模型的可识别性：品种组成、母体品种、直接与母体杂种优势；纯种—杂种信息上限

均值模型  E(y) = μ + δ_a q + δ_m q_m + η h + η_m h_m，
    q = (q_s + q_d)/2（A 品种期望比例），q_m = q_d（母亲的 A 比例），
    h = q_s(1 − q_d) + (1 − q_s)q_d（个体期望品种间杂合系数），h_m = 母亲自身的 h。
对不同交配类型组合：计算设计秩、可估参数的标准误，并在全设计下模拟一次资料作 OLS 估计；
另给出“每种交配类型各在不同场 + 场固定效应”时遗传参数完全不可估的反例。
第二部分（选择指数）：候选公畜纯种 EBV（可靠度 R_P）与 n 个杂种后代均值共同预测其杂种表现育种值 u_C，
    R_P 来源单独时可靠度上限为 r_PC²·R_P；加入杂种后代测定后用指数公式计算。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
COMP = {"A": (1.0, 0.0), "B": (0.0, 0.0), "F1": (0.5, 1.0)}   # (A 比例, 自身杂合系数)
PAR = ["μ", "δ_a", "δ_m", "η", "η_m"]


def coef_row(sire: str, dam: str) -> np.ndarray:
    qs, _ = COMP[sire]; qd, hd = COMP[dam]
    q = 0.5 * (qs + qd); h = qs * (1 - qd) + (1 - qs) * qd
    return np.array([1.0, q, qd, h, hd])


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex22_19_crossbreeding.json").read_text(encoding="utf-8"))
    tr = cfg["true"]; theta = np.array([tr["mu"], tr["delta_a"], tr["delta_m"], tr["eta"], tr["eta_m"]])
    sig, m = cfg["sigma"], cfg["n_per_type"]
    rows = {k: coef_row(*v) for k, v in cfg["types"].items()}
    print("交配类型系数行 (1, q, q_m, h, h_m) 与期望均值：")
    for k, r in rows.items():
        print(f"  {k:<6s} {np.round(r, 3)}  E(y) = {r @ theta:.2f}")
    # 手算核验：A×B 的 F1 期望 = μ + ½δ_a + 0·δ_m + η
    assert np.isclose(rows["AB"] @ theta, tr["mu"] + 0.5 * tr["delta_a"] + tr["eta"])
    assert np.isclose(rows["F1×F1"][3], 0.5), "F1 互交后代期望杂合系数应为 0.5"
    out = {"rows": {k: r.tolist() for k, r in rows.items()}, "designs": {}}
    rng = np.random.default_rng(cfg["seed"])
    for name, types in cfg["designs"].items():
        Xt = np.array([rows[t] for t in types])
        rank = int(np.linalg.matrix_rank(Xt))
        res = {"types": types, "rank": rank}
        line = f"{name:<14s} 类型数 {len(types)}，秩 {rank}/5"
        X = np.repeat(Xt, m, axis=0)
        if rank == 5:
            cov = np.linalg.inv(X.T @ X) * sig ** 2; se = np.sqrt(np.diag(cov))
            res["se"] = se.tolist(); line += "，SE = " + "  ".join(f"{p}:{s:.2f}" for p, s in zip(PAR, se))
        else:
            # 列出零空间：哪些参数组合不可分
            ns = np.linalg.svd(Xt)[2][rank:]
            res["null_space"] = ns.tolist()
            # 可估函数示例：互交平均减纯种平均（直接杂种优势的经典对比）
            line += f"，零空间方向 {np.round(ns, 3).tolist()}"
        print(line)
        out["designs"][name] = res
    # 全设计模拟一次
    types = cfg["designs"]["D4 全部8类"]
    X = np.repeat(np.array([rows[t] for t in types]), m, axis=0)
    y = X @ theta + rng.normal(0, sig, len(X))
    b = np.linalg.lstsq(X, y, rcond=None)[0]
    se = np.sqrt(np.diag(np.linalg.inv(X.T @ X))) * sig
    print("\nD4 一次模拟的 OLS 估计：")
    for p, t, e, s in zip(PAR, theta, b, se):
        print(f"  {p:<4s} 真值 {t:7.2f}  估计 {e:7.2f}  SE {s:5.2f}  z = {(e-t)/s:5.2f}")
        assert abs(e - t) < 4 * s
    # D2 中可估的经典杂种优势对比：(AB + BA)/2 − (AA + BB)/2 = η
    cvec = 0.5 * (rows["AB"] + rows["BA"]) - 0.5 * (rows["AA"] + rows["BB"])
    assert np.allclose(cvec, [0, 0, 0, 1, 0])
    # 场混杂反例：每类各在一个场，加场固定效应
    k = len(types); Xf = np.kron(np.eye(k), np.ones((m, 1)))
    rank_all = np.linalg.matrix_rank(np.column_stack([Xf, X])); rank_f = np.linalg.matrix_rank(Xf)
    print(f"\n每类交配各在不同场并拟合场效应：秩([场, 遗传]) − 秩(场) = {rank_all - rank_f}（遗传参数无剩余信息）")
    out["farm_confounded_extra_rank"] = int(rank_all - rank_f)
    out["ols"] = {"est": b.tolist(), "se": se.tolist()}

    # 第二部分：纯种—杂种信息
    pc = cfg["pure_cross"]; r, RP, h2 = pc["r_pc"], pc["rel_purebred"], pc["h2_cross"]
    sP2 = sC2 = 1.0; sPC = r * np.sqrt(sP2 * sC2); seC2 = sC2 * (1 - h2) / h2
    print(f"\n纯种—杂种遗传相关 r_PC = {r}，纯种 EBV 可靠度 {RP}，杂种性状 h² = {h2}")
    print(f"{'杂种后代数':>10s}{'只用后代':>10s}{'指数合并':>10s}")
    tab = []
    for n in pc["n_cross_progeny"]:
        c = [RP * sPC]; Vm = [[RP * sP2]]
        rel_off = 0.0
        if n > 0:
            vbar = 0.25 * sC2 + (seC2 + 0.75 * sC2) / n
            c.append(0.5 * sC2)
            Vm = [[RP * sP2, 0.5 * RP * sPC], [0.5 * RP * sPC, vbar]]
            rel_off = (0.5 * sC2) ** 2 / (vbar * sC2)
        c = np.array(c); Vm = np.array(Vm)
        rel = float(c @ np.linalg.solve(Vm, c) / sC2)
        tab.append({"n": n, "rel_offspring_only": rel_off, "rel_index": rel})
        print(f"{n:10d}{rel_off:10.4f}{rel:10.4f}")
    assert np.isclose(tab[0]["rel_index"], r * r * RP), "仅纯种信息时应为 r²·R_P"
    out["pure_cross"] = tab
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex22_19_crossbreeding.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
