#!/usr/bin/env python3
"""习题 22.15  动物模型 BLUP：无记录祖先的信息回传、吸收（Schur 补）与“直接删除”的区别

模型  y = Xβ + Zu + e，Var(u) = Aσ_u²，Var(e) = Iσ_e²，λ = σ_e²/σ_u²。
混合模型方程（MME）
    [X'X   X'Z        ] [β]   [X'y]
    [Z'X   Z'Z + λA⁻¹ ] [u] = [Z'y]
其中 A⁻¹ 由 Henderson 规则（含近交，b_i = ½ − ¼(F_s + F_d)）直接构造。
PEV(u_i) = C^{ii} σ_e²，可靠度 r² = 1 − PEV/((1+F_i)σ_u²)。
独立核验：
  (1) 由 V = ZAZ'σ_u² + Iσ_e² 的 GLS + BLUP 公式重算 β̂、û 与 PEV（与 MME 两条路径互验）；
  (2) 用 Schur 补吸收全部无记录动物，保留方程的解与完整 MME 完全一致；
  (3) 若直接删去无记录动物（其后代改作创始者），解发生变化——说明“不输出”不等于“不需要”。
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def read_pedigree(path: Path) -> list[dict]:
    rows = []
    with path.open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows.append({"id": int(r["id"]), "sire": int(r["sire"]), "dam": int(r["dam"]),
                         "herd": int(r["herd"]) if r["herd"] else None,
                         "y": float(r["record"]) if r["record"] else None})
    ids = [r["id"] for r in rows]
    assert ids == list(range(1, len(rows) + 1)), "动物须按 1..n 编号且父母在前"
    for r in rows:
        assert r["sire"] < r["id"] and r["dam"] < r["id"], "父母须排在后代之前"
    return rows


def tabular_A(sire: np.ndarray, dam: np.ndarray) -> np.ndarray:
    """表格法；sire/dam 为 0 起编号，−1 表示未知。"""
    n = len(sire); A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        for j in range(i):
            v = 0.0
            if s >= 0: v += 0.5 * A[j, s]
            if d >= 0: v += 0.5 * A[j, d]
            A[i, j] = A[j, i] = v
        A[i, i] = 1.0 + (0.5 * A[s, d] if (s >= 0 and d >= 0) else 0.0)
    return A


def henderson_Ainv(sire: np.ndarray, dam: np.ndarray, F: np.ndarray) -> np.ndarray:
    n = len(sire); Ai = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        par = [p for p in (s, d) if p >= 0]
        b = 1.0 - 0.25 * sum(1.0 + F[p] for p in par)   # 通式：1 − ¼Σ(1+F_p)
        w = {i: 1.0}
        for p in par: w[p] = w.get(p, 0.0) - 0.5
        for a, wa in w.items():
            for c, wc in w.items():
                Ai[a, c] += wa * wc / b
    return Ai


def solve_mme(X, Z, y, Ainv, lam):
    p = X.shape[1]
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * Ainv]])
    rhs = np.concatenate([X.T @ y, Z.T @ y])
    sol = np.linalg.solve(C, rhs)
    return sol[:p], sol[p:], C


def main() -> None:
    rows = read_pedigree(HERE / "data" / "ex22_15_pedigree.csv")
    par = json.loads((HERE / "data" / "ex22_15_params.json").read_text(encoding="utf-8"))
    su2, se2 = par["sigma_u2"], par["sigma_e2"]; lam = se2 / su2
    n = len(rows)
    sire = np.array([r["sire"] - 1 for r in rows]); dam = np.array([r["dam"] - 1 for r in rows])
    A = tabular_A(sire, dam); F = np.diag(A) - 1.0
    Ainv = henderson_Ainv(sire, dam, F)
    assert np.allclose(A @ Ainv, np.eye(n), atol=1e-10), "A⁻¹ 构造错误"

    rec = [i for i, r in enumerate(rows) if r["y"] is not None]
    y = np.array([rows[i]["y"] for i in rec])
    herds = sorted({rows[i]["herd"] for i in rec})
    X = np.array([[1.0 if rows[i]["herd"] == h else 0.0 for h in herds] for i in rec])
    Z = np.zeros((len(rec), n))
    for k, i in enumerate(rec): Z[k, i] = 1.0

    beta, u, C = solve_mme(X, Z, y, Ainv, lam)
    p = X.shape[1]
    Cinv = np.linalg.inv(C)
    pev = np.diag(Cinv)[p:] * se2
    rel = 1.0 - pev / (np.diag(A) * su2)

    # (1) V 路径
    G = A * su2
    V = Z @ G @ Z.T + se2 * np.eye(len(rec))
    Vi_X = np.linalg.solve(V, X); Vi_y = np.linalg.solve(V, y)
    beta_v = np.linalg.solve(X.T @ Vi_X, X.T @ Vi_y)
    u_v = G @ Z.T @ np.linalg.solve(V, y - X @ beta_v)
    P = np.linalg.inv(V) - Vi_X @ np.linalg.solve(X.T @ Vi_X, Vi_X.T)
    pev_v = np.diag(G - G @ Z.T @ P @ Z @ G)
    assert np.allclose(beta, beta_v, atol=1e-8) and np.allclose(u, u_v, atol=1e-8)
    assert np.allclose(pev, pev_v, atol=1e-8), "MME 与 V 路径 PEV 不一致"

    # (2) Schur 补吸收无记录动物
    unrec = [i for i in range(n) if rows[i]["y"] is None]
    keep_eq = list(range(p)) + [p + i for i in range(n) if i not in unrec]
    drop_eq = [p + i for i in unrec]
    rhs = np.concatenate([X.T @ y, Z.T @ y])
    C11 = C[np.ix_(keep_eq, keep_eq)]; C12 = C[np.ix_(keep_eq, drop_eq)]; C22 = C[np.ix_(drop_eq, drop_eq)]
    S = C11 - C12 @ np.linalg.solve(C22, C12.T)
    r1 = rhs[keep_eq] - C12 @ np.linalg.solve(C22, rhs[drop_eq])
    sol_abs = np.linalg.solve(S, r1)
    full = np.concatenate([beta, u])[keep_eq]
    assert np.allclose(sol_abs, full, atol=1e-9), "吸收后解应与完整 MME 一致"
    # 吸收方程的逆即完整逆的对应子块（PEV 也保持）
    assert np.allclose(np.linalg.inv(S), Cinv[np.ix_(keep_eq, keep_eq)], atol=1e-9)

    # (3) 直接删除无记录动物
    rec_ids = [i for i in range(n) if i not in unrec]
    remap = {old: new for new, old in enumerate(rec_ids)}
    s2 = np.array([remap.get(sire[i], -1) if sire[i] >= 0 else -1 for i in rec_ids])
    d2 = np.array([remap.get(dam[i], -1) if dam[i] >= 0 else -1 for i in rec_ids])
    A2 = tabular_A(s2, d2); Ainv2 = henderson_Ainv(s2, d2, np.diag(A2) - 1)
    Z2 = Z[:, rec_ids]
    beta2, u2, _ = solve_mme(X, Z2, y, Ainv2, lam)
    diff = u2 - u[rec_ids]

    # 报告
    print(f"σ_u² = {su2}，σ_e² = {se2}，λ = {lam:.2f}；记录 {len(rec)} 条，动物 {n} 头")
    print(f"场效应 β̂ = {np.round(beta, 3)}")
    print(f"{'动物':>4s}{'父':>4s}{'母':>4s}{'F':>8s}{'记录':>8s}{'EBV':>9s}{'PEV':>9s}{'r²':>8s}{'删除法EBV':>11s}")
    out_rows = []
    for i in range(n):
        y_i = rows[i]["y"]
        ud = u2[remap[i]] if i in remap else float("nan")
        print(f"{i+1:4d}{rows[i]['sire']:4d}{rows[i]['dam']:4d}{F[i]:8.4f}"
              f"{(f'{y_i:.1f}' if y_i is not None else '—'):>8s}{u[i]:9.3f}{pev[i]:9.3f}{rel[i]:8.3f}"
              f"{(f'{ud:.3f}' if i in remap else '—'):>11s}")
        out_rows.append({"id": i + 1, "F": float(F[i]), "record": y_i, "ebv": float(u[i]), "pev": float(pev[i]),
                         "rel": float(rel[i]), "ebv_deleted_model": (float(ud) if i in remap else None)})
    print(f"无记录动物：{[i+1 for i in unrec]}；吸收后保留方程的解与完整 MME 最大差 "
          f"{np.max(np.abs(sol_abs-full)):.1e}")
    print(f"直接删除无记录祖先：EBV 最大绝对变化 {np.max(np.abs(diff)):.3f}（动物 {rec_ids[int(np.argmax(np.abs(diff)))]+1}），"
          f"场效应变为 {np.round(beta2, 3)}")
    pa = 0.5 * (u[8] + u[11])
    print(f"候选者 14、15 的 EBV = {u[13]:.3f}, {u[14]:.3f}，均等于亲本均值 ½(û9+û12) = {pa:.3f}")
    assert np.isclose(u[13], pa) and np.isclose(u[14], pa)

    res = {"lambda": lam, "beta": beta.tolist(), "animals": out_rows,
           "max_abs_change_when_deleting": float(np.max(np.abs(diff))), "beta_deleted": beta2.tolist(),
           "nonzeros_A": int(np.sum(np.abs(A) > 1e-12)), "nonzeros_Ainv": int(np.sum(np.abs(Ainv) > 1e-12))}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex22_15_animal_model_mme.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
