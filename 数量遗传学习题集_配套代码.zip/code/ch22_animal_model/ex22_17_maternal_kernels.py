#!/usr/bin/env python3
"""习题 22.17  母体模型的协方差核、亲属协方差核验与可识别性（同母一窝 vs 同母两窝）

模型  y = Xβ + Z_d u + Z_m m + W c + L l + e，
      Var[u; m] = [[σ_u², σ_um], [σ_um, σ_m²]] ⊗ A，c 为母体永久环境，l 为窝效应。
观测协方差  V = K_d σ_u² + K_m σ_m² + K_dm σ_um + K_c σ_c² + K_l σ_l² + I σ_e²，
      K_d = Z_d A Z_d'，K_m = Z_m A Z_m'，K_dm = Z_d A Z_m' + Z_m A Z_d'，K_c = WW'，K_l = LL'。
程序：
  (1) 逐对按“共享来源”公式手算两条记录协方差，与 V 的矩阵组装逐元素互验；
  (2) 去均值（L'X = 0 的对比基底）后检验六个核的线性无关性（标准化向量化后的奇异值）：
      甲（每母一窝 4 羔）K_c ≡ K_l → 秩亏；乙（每母两窝各 2 羔，母亲有自身记录）满秩；
      丙（同乙但母亲无自身记录，公羊与母羊无亲缘）A_{i,d_j} = ½A_{d_i d_j} ⇒ K_dm ≡ K_m → 秩亏；
      再把母亲设为固定效应时，母体遗传、交叉与母体永久环境三个核全部被消去；
  (3) 在真实参数处计算 REML 期望信息 ℐ_kl = ½tr(QV_kQV_l)，给出近似标准误与估计相关。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.linalg import null_space

HERE = Path(__file__).resolve().parent
NAMES = ["σ_u²", "σ_m²", "σ_um", "σ_c²", "σ_l²", "σ_e²"]


def tabular_A(sire, dam):
    n = len(sire); A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        for j in range(i):
            v = (0.5 * A[j, s] if s >= 0 else 0) + (0.5 * A[j, d] if d >= 0 else 0)
            A[i, j] = A[j, i] = v
        A[i, i] = 1 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0)
    return A


def build(cfg: dict, design: dict):
    """两代系谱。返回 sire、dam、有记录羔羊编号、其母亲、窝编号、世代，以及全部有后代记录的母亲列表。"""
    sire, dam = [], []
    def add(s, d): sire.append(s); dam.append(d); return len(sire) - 1
    gds = [add(-1, -1) for _ in range(cfg["n_granddams"])]
    gss = [add(-1, -1) for _ in range(cfg["n_grandsires"])]
    lambs, ldam, llit, lgen = [], [], [], []
    lit = 0; dams1 = []
    L, m = design["litters_per_dam"], design["lambs_per_litter"]
    for k, g in enumerate(gds):                        # 第 1 代
        kids = []
        for t in range(L):
            s = gss[(k + t) % len(gss)]
            for _ in range(m):
                a = add(s, g); kids.append(a)
                if design["dam_records"]:
                    lambs.append(a); ldam.append(g); llit.append(lit); lgen.append(1)
            lit += 1
        dams1 += kids[:cfg["dams_per_granddam"]]
    sires2 = [add(-1, -1) for _ in range(cfg["n_sires"])]
    for k, d in enumerate(dams1):                      # 第 2 代
        for t in range(L):
            s = sires2[(k + t) % len(sires2)]
            for _ in range(m):
                lambs.append(add(s, d)); ldam.append(d); llit.append(lit); lgen.append(2)
            lit += 1
    used_dams = sorted(set(ldam))
    llit = np.array(llit); _, llit = np.unique(llit, return_inverse=True)
    return (np.array(sire), np.array(dam), np.array(lambs), np.array(ldam), llit, used_dams, np.array(lgen))


def kernels(A, lambs, lamb_dam, lamb_litter, dams):
    n = len(lambs); N = A.shape[0]
    Zd = np.zeros((n, N)); Zd[np.arange(n), lambs] = 1
    Zm = np.zeros((n, N)); Zm[np.arange(n), lamb_dam] = 1
    dam_idx = {d: k for k, d in enumerate(dams)}
    W = np.zeros((n, len(dams))); W[np.arange(n), [dam_idx[d] for d in lamb_dam]] = 1
    nl = lamb_litter.max() + 1
    Lm = np.zeros((n, nl)); Lm[np.arange(n), lamb_litter] = 1
    K = [Zd @ A @ Zd.T, Zm @ A @ Zm.T, Zd @ A @ Zm.T + Zm @ A @ Zd.T, W @ W.T, Lm @ Lm.T, np.eye(n)]
    return K, W


def vec_sym(M):
    iu = np.triu_indices(M.shape[0])
    w = np.where(iu[0] == iu[1], 1.0, np.sqrt(2.0))
    return M[iu] * w


def identifiability(K, X):
    Lb = null_space(X.T)                      # 满列秩对比基底，L'X = 0
    cols = []
    for Kk in K:
        v = vec_sym(Lb.T @ Kk @ Lb)
        nv = np.linalg.norm(v)
        cols.append(v / nv if nv > 1e-12 else v)
    M = np.column_stack(cols)
    sv = np.linalg.svd(M, compute_uv=False)
    norms = [np.linalg.norm(vec_sym(Lb.T @ Kk @ Lb)) for Kk in K]
    rank = int(np.sum(sv > 1e-8 * sv[0]))
    return rank, sv, norms


def reml_information(K, theta, X):
    V = sum(t * Kk for t, Kk in zip(theta, K))
    Vi = np.linalg.inv(V)
    ViX = Vi @ X
    Q = Vi - ViX @ np.linalg.solve(X.T @ ViX, ViX.T)
    QK = [Q @ Kk for Kk in K]
    p = len(K); I = np.zeros((p, p))
    for a in range(p):
        for b in range(a, p):
            I[a, b] = I[b, a] = 0.5 * np.sum(QK[a] * QK[b].T)
    return I


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex22_17_maternal.json").read_text(encoding="utf-8"))
    pr = cfg["params"]
    theta = np.array([pr["sigma_u2"], pr["sigma_m2"], pr["sigma_um"], pr["sigma_c2"], pr["sigma_l2"], pr["sigma_e2"]])
    assert pr["sigma_um"] ** 2 < pr["sigma_u2"] * pr["sigma_m2"], "直接—母体协方差矩阵须正定"
    out = {}
    for tag, design in cfg["designs"].items():
        sire, dam, lambs, ldam, llit, dams, lgen = build(cfg, design)
        A = tabular_A(sire, dam)
        K, W = kernels(A, lambs, ldam, llit, dams)
        V = sum(t * Kk for t, Kk in zip(theta, K))
        n = len(lambs)
        # (1) 逐对“共享来源”公式与矩阵组装互验
        Vh = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                a, b, da, db = lambs[i], lambs[j], ldam[i], ldam[j]
                Vh[i, j] = (A[a, b] * theta[0] + A[da, db] * theta[1] + (A[a, db] + A[b, da]) * theta[2]
                            + (da == db) * theta[3] + (llit[i] == llit[j]) * theta[4] + (i == j) * theta[5])
        assert np.allclose(V, Vh), "矩阵组装与逐对公式不一致"
        assert np.all(np.linalg.eigvalsh(V) > 0)
        def first(cond):
            for i in range(n):
                for j in range(i + 1, n):
                    if cond(i, j): return i, j
            return None
        S = lambda i: sire[lambs[i]]
        cand = {
            "同窝全同胞": lambda i, j: llit[i] == llit[j],
            "同母异窝": lambda i, j: ldam[i] == ldam[j] and llit[i] != llit[j] and S(i) != S(j),
            "母亲为全同胞姐妹（同窝）": lambda i, j: lgen[i] == lgen[j] == 2 and ldam[i] != ldam[j]
                and dam[ldam[i]] == dam[ldam[j]] and S(i) != S(j),
            "父系半同胞，母无亲缘": lambda i, j: S(i) == S(j) and A[ldam[i], ldam[j]] == 0,
            "母亲自身记录—其羔羊": lambda i, j: lambs[i] == ldam[j],
        }
        print(f"\n===== 设计{tag}：记录 {n} 条 =====")
        pairs = {}
        for name, c in cand.items():
            ij = first(c)
            if ij is None: continue
            i, j = ij
            pairs[name] = {"A_ij": float(A[lambs[i], lambs[j]]), "A_dd": float(A[ldam[i], ldam[j]]),
                           "cross": float(A[lambs[i], ldam[j]] + A[lambs[j], ldam[i]]),
                           "same_dam": bool(ldam[i] == ldam[j]), "same_litter": bool(llit[i] == llit[j]), "cov": float(V[i, j])}
            q = pairs[name]
            print(f"  {name:<14s} A_ij={q['A_ij']:.4f}  A_dd'={q['A_dd']:.3f}  交叉={q['cross']:.3f}  "
                  f"同母={'是' if q['same_dam'] else '否'} 同窝={'是' if q['same_litter'] else '否'}  协方差={q['cov']:.3f}")
        print(f"  单条记录方差 = {V[0,0]:.3f}")
        gens = sorted(set(lgen))
        X = np.column_stack([np.ones(n)] + ([(lgen == 2).astype(float)] if len(gens) > 1 else []))
        rank, sv, norms = identifiability(K, X)
        same_dm = np.allclose(K[1], K[2])
        print(f"  去均值后六个核的秩 = {rank}/6；标准化奇异值 = {np.round(sv, 4)}")
        print(f"  K_c ≡ K_l ？{'是' if np.allclose(K[3], K[4]) else '否'}；K_dm ≡ K_m ？{'是' if same_dm else '否'}")
        rank_d, sv_d, norms_d = identifiability(K, np.column_stack([X, W]))
        print(f"  再把母亲设为固定效应：各核投影范数 = {np.round(norms_d, 2)}（母体三核均为 0），秩 = {rank_d}")
        res = {"n_records": n, "record_var": float(V[0, 0]), "pairs": pairs, "rank": rank, "sv": sv.tolist(),
               "Kc_equals_Kl": bool(np.allclose(K[3], K[4])), "Kdm_equals_Km": bool(same_dm),
               "rank_dam_fixed": rank_d, "norms_dam_fixed": norms_d}
        if rank == 6:
            I = reml_information(K, theta, X)
            Ci = np.linalg.inv(I); se = np.sqrt(np.diag(Ci)); corr = Ci / np.outer(se, se)
            print("  真实参数处 REML 期望信息给出的近似标准误：")
            for nm, t, s_ in zip(NAMES, theta, se):
                print(f"    {nm:<6s} 真值 {t:6.2f}   SE ≈ {s_:7.2f}")
            sum_se = float(np.sqrt(Ci[3, 3] + Ci[4, 4] + 2 * Ci[3, 4]))
            print(f"  corr(σ̂_c², σ̂_l²) = {corr[3,4]:.3f}；corr(σ̂_m², σ̂_um) = {corr[1,2]:.3f}；"
                  f"σ_c²+σ_l² 的 SE ≈ {sum_se:.2f}")
            res.update({"se": se.tolist(), "corr": corr.tolist(), "se_sum_c_l": sum_se})
        out[tag] = res
    keys = list(cfg["designs"])
    assert out[keys[0]]["Kc_equals_Kl"] and out[keys[0]]["rank"] == 5
    assert out[keys[1]]["rank"] == 6
    assert out[keys[2]]["Kdm_equals_Km"] and out[keys[2]]["rank"] == 5
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex22_17_maternal_kernels.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
