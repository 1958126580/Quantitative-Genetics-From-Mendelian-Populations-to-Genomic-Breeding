#!/usr/bin/env python3
"""习题 22.20  未知亲本组（遗传组）：引入遗传水平不同的外来公畜时的基准偏差与 QP 变换

资料生成：基础群（遗传均值 0）闭锁繁殖，母羊与本场公羊按表型选留；每年另引入若干头父母未知、
自身无记录的外来公羊，其遗传均值逐年升高（组 G1…G4）。年份为固定效应，所有后代有记录。
模型 1（无组）：把全部未知亲本都视为同一零均值基础群。
模型 2（遗传组）：u = Qg + a，a ~ N(0, Aσ_u²)，g 为固定组效应；Q_i = ½(Q_s + Q_d)，
    基础群创始者的未知父母视为参照组（g₀ = 0），外来公羊的未知父母属于其引入年份的组。
    Quaas–Pollak 变换把 A⁻¹ 按 Henderson 规则扩展到组：未知亲本位置换成所属组的列，
    得到 [b; u; g] 的稀疏方程，其 û 直接就是 Qĝ + â。
独立核验：显式模型 y = Xb + ZQg + Za + e 的 MME 解经 Qĝ + â 还原后，与 QP 方程的 û 逐元素相等。
重复模拟比较两模型的遗传趋势偏差、外来公羊 EBV 偏差与末代 EBV—TBV 相关。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    su = np.sqrt(cfg["sigma_u2"]); se = np.sqrt(cfg["sigma_e2"])
    sire, dam, grp_s, grp_d, tbv, year, rec, kind = [], [], [], [], [], [], [], []
    def add(s, d, gs, gd, u, yr, has_rec, k):
        sire.append(s); dam.append(d); grp_s.append(gs); grp_d.append(gd); tbv.append(u); year.append(yr)
        rec.append(has_rec); kind.append(k); return len(sire) - 1
    F_tab = {}
    # 基础群：雌性有记录，雄性无记录
    fem = [add(-1, -1, 0, 0, rng.normal(0, su), 0, True, "base") for _ in range(cfg["n_base_females"])]
    mal = [add(-1, -1, 0, 0, rng.normal(0, su), 0, False, "base") for _ in range(cfg["n_base_males"])]
    yeff = cfg["year_effects"]
    y = {}
    for i in fem: y[i] = yeff[0] + tbv[i] + rng.normal(0, se)
    dams = list(rng.choice(fem, cfg["n_dams"], replace=False)); home = list(rng.choice(mal, cfg["home_sires"], replace=False))
    for t in range(1, cfg["generations"] + 1):
        imp = [add(-1, -1, t, t, rng.normal(cfg["import_mean"][t - 1], su), t, False, f"import{t}")
               for _ in range(cfg["import_sires"])]
        sires_t = home + imp
        kids_f, kids_m = [], []
        for k, d in enumerate(dams):
            s = sires_t[k % len(sires_t)]
            for _ in range(cfg["offspring_per_dam"]):
                u = 0.5 * (tbv[s] + tbv[d]) + rng.normal(0, su * np.sqrt(0.5))   # 忽略近交对抽样方差的微小影响
                i = add(s, d, None, None, u, t, True, f"gen{t}")
                y[i] = yeff[t] + u + rng.normal(0, se)
                (kids_f if rng.random() < 0.5 else kids_m).append(i)
        kids_f.sort(key=lambda i: -y[i]); kids_m.sort(key=lambda i: -y[i])
        dams = kids_f[:cfg["n_dams"]] if len(kids_f) >= cfg["n_dams"] else kids_f + list(rng.choice(kids_f, cfg["n_dams"] - len(kids_f)))
        home = kids_m[:cfg["home_sires"]]
    return dict(sire=np.array(sire), dam=np.array(dam), gs=grp_s, gd=grp_d, tbv=np.array(tbv), year=np.array(year),
                rec=np.array(rec), kind=kind, y=y)


def tabular_A(sire, dam):
    n = len(sire); A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        if s >= 0 and d >= 0:
            A[i, :i] = 0.5 * (A[s, :i] + A[d, :i]); A[i, i] = 1 + 0.5 * A[s, d]
        elif s >= 0:
            A[i, :i] = 0.5 * A[s, :i]; A[i, i] = 1
        elif d >= 0:
            A[i, :i] = 0.5 * A[d, :i]; A[i, i] = 1
        else:
            A[i, i] = 1
        A[:i, i] = A[i, :i]
    return A


def ainv_with_groups(sire, dam, gs, gd, F, ng):
    """Henderson 规则扩展到组：返回 (n+ng)×(n+ng) 矩阵；组 0 为参照（不建方程）。"""
    n = len(sire); M = np.zeros((n + ng, n + ng))
    for i in range(n):
        known = [p for p in (sire[i], dam[i]) if p >= 0]
        b = 1.0 - 0.25 * sum(1 + F[p] for p in known)
        w = {i: 1.0}
        for p, g in ((sire[i], gs[i]), (dam[i], gd[i])):
            if p >= 0: w[p] = w.get(p, 0) - 0.5
            elif g is not None and g > 0: w[n + g - 1] = w.get(n + g - 1, 0) - 0.5
        for a, wa in w.items():
            for c, wc in w.items():
                M[a, c] += wa * wc / b
    return M


def q_matrix(sire, dam, gs, gd, ng):
    n = len(sire); Q = np.zeros((n, ng))
    for i in range(n):
        for p, g in ((sire[i], gs[i]), (dam[i], gd[i])):
            if p >= 0: Q[i] += 0.5 * Q[p]
            elif g is not None and g > 0: Q[i, g - 1] += 0.5
    return Q


def fit(sim, cfg, groups: bool):
    sire, dam = sim["sire"], sim["dam"]; n = len(sire); lam = cfg["sigma_e2"] / cfg["sigma_u2"]
    recs = sorted(sim["y"]); yv = np.array([sim["y"][i] for i in recs])
    nyr = cfg["generations"] + 1
    X = np.zeros((len(recs), nyr)); X[np.arange(len(recs)), sim["year"][recs]] = 1
    Z = np.zeros((len(recs), n)); Z[np.arange(len(recs)), recs] = 1
    A = tabular_A(sire, dam); F = np.diag(A) - 1
    ng = cfg["generations"] if groups else 0
    gs = sim["gs"] if groups else [None] * n; gd = sim["gd"] if groups else [None] * n
    M = ainv_with_groups(sire, dam, gs, gd, F, ng)
    p = nyr; dim = p + n + ng
    C = np.zeros((dim, dim)); r = np.zeros(dim)
    C[:p, :p] = X.T @ X; C[:p, p:p + n] = X.T @ Z; C[p:p + n, :p] = Z.T @ X
    C[p:p + n, p:p + n] = Z.T @ Z; C[p:, p:] += lam * M
    r[:p] = X.T @ yv; r[p:p + n] = Z.T @ yv
    sol = np.linalg.solve(C, r)
    u = sol[p:p + n]; g = sol[p + n:]
    if groups:   # 显式模型互验
        Q = q_matrix(sire, dam, sim["gs"], sim["gd"], ng)
        Ainv = np.linalg.inv(A)
        W = np.hstack([X, Z @ Q, Z])
        Ce = W.T @ W; Ce[p + ng:, p + ng:] += lam * Ainv
        se_ = np.linalg.solve(Ce, W.T @ yv)
        u_exp = Q @ se_[p:p + ng] + se_[p + ng:]
        assert np.allclose(u_exp, u, atol=1e-7), "QP 方程与显式遗传组模型不一致"
        assert np.allclose(se_[p:p + ng], g, atol=1e-7)
    return u, g


def metrics(sim, u, cfg):
    tbv = sim["tbv"]; kind = sim["kind"]; G = cfg["generations"]
    gen = {t: [i for i, k in enumerate(kind) if k == f"gen{t}"] for t in range(1, G + 1)}
    base = [i for i, k in enumerate(kind) if k == "base"]
    imp = [i for i, k in enumerate(kind) if k.startswith("import")]
    true_tr = [float(np.mean(tbv[gen[t]]) - np.mean(tbv[base])) for t in range(1, G + 1)]
    est_tr = [float(np.mean(u[gen[t]]) - np.mean(u[base])) for t in range(1, G + 1)]
    last = gen[G]
    return dict(true_trend=true_tr, est_trend=est_tr, import_bias=float(np.mean(u[imp] - tbv[imp])),
                r_last=float(np.corrcoef(u[last], tbv[last])[0, 1]),
                import_bias_by_year=[float(np.mean(u[[i for i in imp if kind[i] == f'import{t}']] -
                                                   tbv[[i for i in imp if kind[i] == f'import{t}']])) for t in range(1, G + 1)])


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex22_20_upg.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    acc = {"nogroup": [], "group": []}; gsol = []
    for rep in range(cfg["n_reps"]):
        sim = simulate(cfg, rng)
        u0, _ = fit(sim, cfg, False)
        u1, g1 = fit(sim, cfg, True)
        acc["nogroup"].append(metrics(sim, u0, cfg)); acc["group"].append(metrics(sim, u1, cfg)); gsol.append(g1)
    G = cfg["generations"]
    def avg(key, mod): return np.mean([m[key] for m in acc[mod]], axis=0)
    print(f"重复 {cfg['n_reps']} 次；每次动物数 {len(sim['sire'])}；外来公羊遗传均值 {cfg['import_mean']}")
    print(f"{'世代':>4s}{'真实趋势':>10s}{'无组估计':>10s}{'遗传组估计':>11s}")
    for t in range(G):
        print(f"{t+1:4d}{avg('true_trend','group')[t]:10.3f}{avg('est_trend','nogroup')[t]:10.3f}{avg('est_trend','group')[t]:11.3f}")
    print(f"外来公羊 EBV − TBV 平均：无组 {avg('import_bias','nogroup'):.3f}，遗传组 {avg('import_bias','group'):.3f}")
    print(f"  分年份（无组）：{np.round(avg('import_bias_by_year','nogroup'), 3)}")
    print(f"  分年份（遗传组）：{np.round(avg('import_bias_by_year','group'), 3)}")
    print(f"末代 EBV—TBV 相关：无组 {avg('r_last','nogroup'):.4f}，遗传组 {avg('r_last','group'):.4f}")
    gmean = np.mean(gsol, axis=0); gsd = np.std(gsol, axis=0)
    print(f"组效应估计（均值 ± 重复间SD）：{[f'{a:.2f}±{b:.2f}' for a, b in zip(gmean, gsd)]}（真值 {cfg['import_mean']}）")
    assert abs(avg("import_bias", "group")) < abs(avg("import_bias", "nogroup")), "遗传组模型应减小外来公羊偏差"
    out = {k: {"true_trend": avg("true_trend", k).tolist(), "est_trend": avg("est_trend", k).tolist(),
               "import_bias": float(avg("import_bias", k)), "import_bias_by_year": avg("import_bias_by_year", k).tolist(),
               "r_last": float(avg("r_last", k))} for k in acc}
    out["group_solutions_mean"] = gmean.tolist(); out["group_solutions_sd"] = gsd.tolist()
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex22_20_unknown_parent_groups.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
