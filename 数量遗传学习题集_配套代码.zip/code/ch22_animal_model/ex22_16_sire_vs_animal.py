#!/usr/bin/env python3
"""习题 22.16  公畜模型与动物模型的尺度桥梁：等价条件、λ_s = (4 − h²)/h² 与错误方差比的后果

动物模型：y = Xβ + Z_a u + e，Var(u) = Aσ_u²，λ_a = σ_e²/σ_u²；全部后代只知父亲（母亲未知、互不相关），
         公畜无记录，公畜之间无亲缘。后代 b_i = 3/4，Henderson 规则给出 A⁻¹。
公畜模型：y = Xβ + Z_s s + w，s = u_sire/2，σ_s² = σ_u²/4，σ_w² = ¾σ_u² + σ_e²，λ_s = σ_w²/σ_s² = (4 − h²)/h²。
在上述条件下两模型对公畜给出完全相同的信息：û_sire(动物模型) = 2ŝ，PEV_u = 4·PEV_s（程序精确核验）。
随后重复模拟比较正确 λ_s 与“把动物模型残差直接搬进公畜方程”的错误 λ = σ_e²/σ_s²：
  真值对预测值的回归（离散度偏差）、相关（排序准确度）与均方误差。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg: dict, rng: np.random.Generator):
    ns = cfg["n_sires"]
    nprog = rng.integers(cfg["progeny_min"], cfg["progeny_max"] + 1, size=ns)
    su2, se2 = cfg["sigma_u2"], cfg["sigma_e2"]
    u_s = rng.normal(0, np.sqrt(su2), ns)
    sire_of = np.repeat(np.arange(ns), nprog); N = len(sire_of)
    grp = rng.integers(0, cfg["n_groups"], size=N)
    gmean = rng.normal(0, cfg["group_sd"], cfg["n_groups"])
    # 后代育种值 = ½父 + ½母(未知) + 孟德尔抽样；合并为方差 ¾σ_u² 的项
    u_o = 0.5 * u_s[sire_of] + rng.normal(0, np.sqrt(0.75 * su2), N)
    y = gmean[grp] + u_o + rng.normal(0, np.sqrt(se2), N)
    return y, grp, sire_of, u_s


def design_X(grp: np.ndarray, ng: int) -> np.ndarray:
    X = np.zeros((len(grp), ng)); X[np.arange(len(grp)), grp] = 1.0
    return X


def sire_model(y, X, sire_of, ns, lam):
    N = len(y); Zs = np.zeros((N, ns)); Zs[np.arange(N), sire_of] = 1.0
    C = np.block([[X.T @ X, X.T @ Zs], [Zs.T @ X, Zs.T @ Zs + lam * np.eye(ns)]])
    sol = np.linalg.solve(C, np.concatenate([X.T @ y, Zs.T @ y]))
    p = X.shape[1]
    return sol[p:], np.linalg.inv(C)[p:, p:]


def animal_model(y, X, sire_of, ns, lam):
    N = len(y); n = ns + N
    Ainv = np.zeros((n, n))
    for s in range(ns): Ainv[s, s] += 1.0
    b = 0.75
    for k in range(N):
        i, s = ns + k, sire_of[k]
        Ainv[i, i] += 1 / b; Ainv[i, s] -= 0.5 / b; Ainv[s, i] -= 0.5 / b; Ainv[s, s] += 0.25 / b
    Z = np.zeros((N, n)); Z[np.arange(N), ns + np.arange(N)] = 1.0
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * Ainv]])
    sol = np.linalg.solve(C, np.concatenate([X.T @ y, Z.T @ y]))
    p = X.shape[1]
    return sol[p:p + ns], np.linalg.inv(C)[p:p + ns, p:p + ns]


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex22_16_sire_design.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    su2, se2 = cfg["sigma_u2"], cfg["sigma_e2"]; h2 = su2 / (su2 + se2)
    ss2 = su2 / 4; sw2 = 0.75 * su2 + se2
    lam_s = sw2 / ss2; lam_wrong = se2 / ss2; lam_a = se2 / su2
    assert np.isclose(lam_s, (4 - h2) / h2)
    ns, ng = cfg["n_sires"], cfg["n_groups"]

    # ---- 一次资料上的精确等价核验 ----
    y, grp, sire_of, u_s = simulate(cfg, rng); X = design_X(grp, ng)
    s_hat, Css = sire_model(y, X, sire_of, ns, lam_s)
    u_hat, Cuu = animal_model(y, X, sire_of, ns, lam_a)
    pev_s = np.diag(Css) * sw2; pev_u = np.diag(Cuu) * se2
    assert np.allclose(u_hat, 2 * s_hat, atol=1e-9), "动物模型公畜 EBV 应等于 2 × 公畜模型解"
    assert np.allclose(pev_u, 4 * pev_s, atol=1e-9), "PEV 应满足 4 倍关系"
    rel_s = 1 - pev_s / ss2; rel_u = 1 - pev_u / su2
    assert np.allclose(rel_s, rel_u)
    print(f"h² = {h2:.2f}；λ_a = {lam_a:.2f}，λ_s = (4−h²)/h² = {lam_s:.2f}，错误 λ = σ_e²/σ_s² = {lam_wrong:.2f}")
    print(f"一次资料（{len(y)} 个后代）：max|û_sire − 2ŝ| = {np.max(np.abs(u_hat-2*s_hat)):.2e}，"
          f"max|PEV_u − 4PEV_s| = {np.max(np.abs(pev_u-4*pev_s)):.2e}")
    nprog = np.bincount(sire_of, minlength=ns)
    for k in np.argsort(nprog)[[0, ns // 2, -1]]:
        print(f"  公畜{k+1:2d}：后代 {nprog[k]:2d}，ŝ = {s_hat[k]:6.3f}，û = {u_hat[k]:6.3f}，可靠度 {rel_s[k]:.3f}"
              f"（理论 n/(n+λ_s) = {nprog[k]/(nprog[k]+lam_s):.3f}，忽略组效应估计）")

    # ---- 重复模拟：正确与错误 λ ----
    stats = {"correct": {"b": [], "r": [], "mse": []}, "wrong": {"b": [], "r": [], "mse": []}}
    for _ in range(cfg["n_reps"]):
        y, grp, sire_of, u_s = simulate(cfg, rng); X = design_X(grp, ng)
        ta = u_s / 2
        for key, lam in (("correct", lam_s), ("wrong", lam_wrong)):
            sh, _ = sire_model(y, X, sire_of, ns, lam)
            sh_c = sh - sh.mean(); ta_c = ta - ta.mean()
            stats[key]["b"].append(float(ta_c @ sh_c / (sh_c @ sh_c)))
            stats[key]["r"].append(float(np.corrcoef(ta, sh)[0, 1]))
            stats[key]["mse"].append(float(np.mean((ta_c - sh_c) ** 2)))
    summ = {k: {m: float(np.mean(v)) for m, v in d.items()} for k, d in stats.items()}
    print(f"\n{cfg['n_reps']} 次重复（传递能力尺度）：")
    print(f"{'方差比':>10s}{'λ':>8s}{'b(真|预测)':>12s}{'相关 r':>9s}{'MSE':>9s}")
    for key, lam, name in (("correct", lam_s, "正确"), ("wrong", lam_wrong, "错误")):
        s = summ[key]
        print(f"{name:>10s}{lam:8.2f}{s['b']:12.4f}{s['r']:9.4f}{s['mse']:9.4f}")
    assert summ["wrong"]["b"] < summ["correct"]["b"], "错误 λ 收缩不足，回归系数应更小"

    res = {"h2": h2, "lambda_s": lam_s, "lambda_wrong": lam_wrong, "lambda_a": lam_a,
           "equivalence_max_diff": float(np.max(np.abs(u_hat - 2 * s_hat))), "summary": summ}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex22_16_sire_vs_animal.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
