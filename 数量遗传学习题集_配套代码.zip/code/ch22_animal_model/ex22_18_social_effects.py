#!/usr/bin/env python3
"""习题 22.18  社会（间接）遗传效应：总育种值、亲缘组群与个体/群体选择响应，及不规则接触网络

固定群大小 n、每头动物对每个同伴以同一单位表达社会效应：
    P_i = D_i + Σ_{k≠i} S_k + c_g + e_i，        T_i = D_i + (n−1) S_i，
    σ_T² = σ_D² + 2(n−1)σ_DS + (n−1)²σ_S²。
群内同伴两两亲缘为 r（组群由家系构成）时：
    Cov(T_i, P_i) = σ_D² + (n−1)(1+r)σ_DS + (n−1)² r σ_S²,
    Var(P_i)      = σ_D² + (n−1)σ_S² + 2(n−1) r σ_DS + (n−1)(n−2) r σ_S² + σ_c² + σ_e²,
    Cov(T_i, ΣP)  = σ_T² [1 + (n−1)r],   Var(ΣP) = nσ_T²[1+(n−1)r] + n²σ_c² + nσ_e²。
个体选择响应 R = i·Cov(T,P)/σ_P；整群选择 R = i·Cov(T,ΣP)/σ_ΣP（以总育种值即群体平均表现计）。
独立核验：大样本蒙特卡洛重现全部协方差与截断选择的实际响应。
网络部分：g = d + W s（行 = 接受者），个体对总体的贡献 T_j = d_j + q_j s_j，q = W'1（列和），1'g = Σ T_j。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def theory(n, sD2, sS2, sDS, sc2, se2, r):
    sT2 = sD2 + 2 * (n - 1) * sDS + (n - 1) ** 2 * sS2
    cTP = sD2 + (n - 1) * (1 + r) * sDS + (n - 1) ** 2 * r * sS2
    vP = sD2 + (n - 1) * sS2 + 2 * (n - 1) * r * sDS + (n - 1) * (n - 2) * r * sS2 + sc2 + se2
    cTG = sT2 * (1 + (n - 1) * r)
    vG = n * sT2 * (1 + (n - 1) * r) + n * n * sc2 + n * se2
    return dict(sT2=sT2, cTP=cTP, vP=vP, cTG=cTG, vG=vG)


def intensity(p: float) -> float:
    x = norm.ppf(1 - p)
    return float(norm.pdf(x) / p)


def simulate(n, Sigma, sc2, se2, r, G, rng):
    L = np.linalg.cholesky(Sigma)
    fam = rng.standard_normal((G, 1, 2)) @ L.T
    own = rng.standard_normal((G, n, 2)) @ L.T
    DS = np.sqrt(r) * fam + np.sqrt(1 - r) * own          # 同群两两协方差 = rΣ
    D, S = DS[..., 0], DS[..., 1]
    c = rng.normal(0, np.sqrt(sc2), (G, 1))
    P = D + (S.sum(axis=1, keepdims=True) - S) + c + rng.normal(0, np.sqrt(se2), (G, n))
    T = D + (n - 1) * S
    return P, T


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex22_18_social.json").read_text(encoding="utf-8"))
    n = cfg["group_size"]; sD2, sS2, sDS = cfg["sigma_D2"], cfg["sigma_S2"], cfg["sigma_DS"]
    sc2, se2 = cfg["sigma_c2"], cfg["sigma_e2"]
    Sigma = np.array([[sD2, sDS], [sDS, sS2]])
    assert np.all(np.linalg.eigvalsh(Sigma) > 0), "直接—社会遗传协方差矩阵须正定"
    rng = np.random.default_rng(cfg["seed"])
    rec_g = sD2 + (n - 1) * sS2
    cov_mates = 2 * sDS + (n - 2) * sS2 + sc2
    t0 = theory(n, sD2, sS2, sDS, sc2, se2, 0.0)
    print(f"n = {n}，r_DS = {sDS/np.sqrt(sD2*sS2):.3f}；σ_T² = {t0['sT2']:.3f}；单条记录遗传方差 = {rec_g:.3f}；"
          f"无亲缘同伴表型协方差 = {cov_mates:.3f}")
    p_sel = 0.2; i_sel = intensity(p_sel)
    print(f"选留比例 {p_sel}，选择强度 i = {i_sel:.4f}")
    print(f"{'r':>5s}{'Cov(T,P)':>10s}{'σ_P':>8s}{'R_个体':>9s}{'R_个体MC':>10s}{'R_整群':>9s}{'R_整群MC':>10s}")
    out = {"sigma_T2": t0["sT2"], "record_genetic_var": rec_g, "cov_groupmates": cov_mates, "i": i_sel, "rows": []}
    G = cfg["n_groups_mc"]
    for r in cfg["relatedness"]:
        th = theory(n, sD2, sS2, sDS, sc2, se2, r)
        P, T = simulate(n, Sigma, sc2, se2, r, G, rng)
        p, t = P.ravel(), T.ravel()
        cTP = np.cov(t, p)[0, 1]; vP = p.var()
        gs = P.sum(axis=1); cTG = np.cov(T[:, 0], gs)[0, 1]; vG = gs.var()
        tol = 0.03 * max(1.0, abs(th["cTP"]))
        assert abs(cTP - th["cTP"]) < tol and abs(vP / th["vP"] - 1) < 0.02
        assert abs(cTG / th["cTG"] - 1) < 0.04 and abs(vG / th["vG"] - 1) < 0.02
        R_ind = i_sel * th["cTP"] / np.sqrt(th["vP"]); R_grp = i_sel * th["cTG"] / np.sqrt(th["vG"])
        # 截断选择的实际响应（T 的均值差）
        thr = np.quantile(p, 1 - p_sel); Rmc_ind = t[p >= thr].mean() - t.mean()
        thg = np.quantile(gs, 1 - p_sel); Rmc_grp = T[gs >= thg].mean() - T.mean()
        print(f"{r:5.2f}{th['cTP']:10.3f}{np.sqrt(th['vP']):8.3f}{R_ind:9.4f}{Rmc_ind:10.4f}{R_grp:9.4f}{Rmc_grp:10.4f}")
        out["rows"].append({"r": r, **{k: float(v) for k, v in th.items()}, "R_ind": float(R_ind), "R_ind_mc": float(Rmc_ind),
                            "R_grp": float(R_grp), "R_grp_mc": float(Rmc_grp)})
        assert abs(Rmc_ind - R_ind) < 0.05 and abs(Rmc_grp - R_grp) < 0.05
    assert out["rows"][0]["R_ind"] < 0 < out["rows"][0]["R_grp"], "本参数下无亲缘个体选择应使总育种值下降"

    # 不规则网络
    net = cfg["network"]; W = np.array(net["W"], float); d = np.array(net["d"]); s = np.array(net["s"])
    g = d + W @ s; q = W.T @ np.ones(len(d)); T = d + q * s
    assert np.isclose(g.sum(), T.sum())
    varT = sD2 + 2 * q * sDS + q ** 2 * sS2
    print("\n接触网络：接受端遗传值 g = d + Ws 与输出端总贡献 T = d + q∘s（q = W'1）")
    print(f"{'位置':>4s}{'行和':>6s}{'q(列和)':>9s}{'d':>6s}{'s':>7s}{'g':>8s}{'T':>8s}{'Var(T)':>9s}")
    for j in range(len(d)):
        print(f"{j+1:4d}{W[j].sum():6.2f}{q[j]:9.2f}{d[j]:6.2f}{s[j]:7.2f}{g[j]:8.3f}{T[j]:8.3f}{varT[j]:9.3f}")
    print(f"Σg = {g.sum():.3f} = ΣT = {T.sum():.3f}；按 g 排序第一为位置 {int(np.argmax(g))+1}，按 T 为位置 {int(np.argmax(T))+1}")
    # 反馈模型 y = ρWy + a 的 Neumann 级数核验
    rho = 0.3; a = np.ones(len(d))
    y_inv = np.linalg.solve(np.eye(len(d)) - rho * W, a)
    y_ser = sum(np.linalg.matrix_power(rho * W, k) @ a for k in range(80))
    assert np.allclose(y_inv, y_ser) and np.max(np.abs(np.linalg.eigvals(W))) * rho < 1
    print(f"反馈模型（ρ = {rho}，a = 1）：平衡表现 = {np.round(y_inv, 4)}（行和为 1 的网络中为 1/(1−ρ) = {1/(1-rho):.4f}）")
    out["network"] = {"g": g.tolist(), "T": T.tolist(), "q": q.tolist(), "varT": varT.tolist(), "feedback_y": y_inv.tolist()}

    plt = __import__("_plot").get_pyplot()
    if plt is not None:
        rs = np.linspace(0, 1, 51)
        ri = [i_sel * theory(n, sD2, sS2, sDS, sc2, se2, r)["cTP"] / np.sqrt(theory(n, sD2, sS2, sDS, sc2, se2, r)["vP"]) for r in rs]
        rg = [i_sel * theory(n, sD2, sS2, sDS, sc2, se2, r)["cTG"] / np.sqrt(theory(n, sD2, sS2, sDS, sc2, se2, r)["vG"]) for r in rs]
        fig, ax = plt.subplots(figsize=(5.2, 3.4))
        ax.plot(rs, ri, label="个体表型选择"); ax.plot(rs, rg, label="整群选择"); ax.axhline(0, color="gray", lw=0.6)
        ax.set_xlabel("群内同伴亲缘 r"); ax.set_ylabel("总育种值响应 / 代"); ax.legend(); fig.tight_layout()
        fig.savefig(HERE / "results" / "ex22_18_social_response.png"); plt.close(fig)
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex22_18_social_effects.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    (HERE / "results").mkdir(exist_ok=True)
    main()
