#!/usr/bin/env python3
"""习题 2.22  单条记录的增加与删除：Sherman–Morrison 公式与留一残差

线性回归 y = Xb + e。记 M = XᵀX。
    增加记录 (x, y)：(M + xxᵀ)⁻¹ = M⁻¹ − M⁻¹x xᵀM⁻¹ /(1 + xᵀM⁻¹x)
    删除记录 i：     (M − x_i x_iᵀ)⁻¹ = M⁻¹ + M⁻¹x_i x_iᵀM⁻¹ /(1 − h_ii)，h_ii = x_iᵀM⁻¹x_i
    留一残差：       e_(i) = e_i /(1 − h_ii)，PRESS = Σ e_(i)²
    Cook 距离：      D_i = e_i² h_ii /[p s² (1 − h_ii)²]
程序逐条核对“公式更新”与“重新拟合”给出相同结果，并找出影响最大的记录。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex02_22_records.json").read_text(encoding="utf-8"))
    x = np.array(cfg["x"], float); y = np.array(cfg["y"], float)
    X = np.column_stack([np.ones_like(x), x]); n, p = X.shape
    Minv = np.linalg.inv(X.T @ X); b = Minv @ X.T @ y
    e = y - X @ b; h = np.einsum("ij,jk,ik->i", X, Minv, X); s2 = e @ e / (n - p)
    loo = e / (1 - h); cook = e ** 2 * h / (p * s2 * (1 - h) ** 2)
    print(f"全部记录：截距 {b[0]:.4f}，斜率 {b[1]:.4f}，s² = {s2:.4f}")
    print(f"{'i':>3s}{'h_ii':>8s}{'残差':>9s}{'留一残差':>10s}{'Cook D':>9s}")
    for i in range(n):
        Xi = np.delete(X, i, 0); yi = np.delete(y, i)
        bi = np.linalg.lstsq(Xi, yi, rcond=None)[0]
        assert np.isclose(y[i] - X[i] @ bi, loo[i]), "留一残差公式核对失败"
        Mi = Minv + np.outer(Minv @ X[i], X[i] @ Minv) / (1 - h[i])
        assert np.allclose(Mi, np.linalg.inv(Xi.T @ Xi)), "删除公式核对失败"
        print(f"{i+1:3d}{h[i]:8.4f}{e[i]:9.4f}{loo[i]:10.4f}{cook[i]:9.4f}")
    press = float(loo @ loo)
    worst = int(np.argmax(cook))
    bdrop = np.linalg.lstsq(np.delete(X, worst, 0), np.delete(y, worst), rcond=None)[0]
    print(f"PRESS = {press:.4f}；影响最大的记录 = 第 {worst+1} 条，删除后截距 {bdrop[0]:.4f}，斜率 {bdrop[1]:.4f}")
    xn = np.array([1.0, cfg["new_record"]["x"]]); yn = cfg["new_record"]["y"]
    Mn = Minv - np.outer(Minv @ xn, xn @ Minv) / (1 + xn @ Minv @ xn)
    bn = Mn @ (X.T @ y + xn * yn)
    Xa = np.vstack([X, xn]); ya = np.append(y, yn)
    assert np.allclose(bn, np.linalg.lstsq(Xa, ya, rcond=None)[0]), "增加公式核对失败"
    # 增加一条记录后 b 的变化也可写为 Δb = M⁻¹x (y − xᵀb)/(1 + xᵀM⁻¹x)
    db = Minv @ xn * (yn - xn @ b) / (1 + xn @ Minv @ xn)
    assert np.allclose(b + db, bn)
    print(f"增加记录 x={cfg['new_record']['x']}, y={yn} 后：截距 {bn[0]:.4f}，斜率 {bn[1]:.4f}；Δb = {np.round(db,4)}")
    out = {"b": b.tolist(), "s2": s2, "leverage": h.round(5).tolist(), "residual": e.round(5).tolist(), "loo": loo.round(5).tolist(),
           "cook": cook.round(5).tolist(), "press": press, "most_influential": worst + 1, "b_without_worst": bdrop.tolist(), "b_after_add": bn.tolist()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex02_22_rank_one_update.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
