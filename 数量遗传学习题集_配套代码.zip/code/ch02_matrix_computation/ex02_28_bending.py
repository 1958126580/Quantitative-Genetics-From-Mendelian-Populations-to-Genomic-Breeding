#!/usr/bin/env python3
"""习题 2.28  分段估计的遗传相关矩阵非正定：诊断与修复（特征值弯曲与最近相关矩阵）

四性状遗传相关由不同资料两两估计后拼成矩阵 R，可能不是半正定。
    1. 特征分解诊断：负特征值的大小与对应特征向量（哪种性状组合“方差为负”）；
    2. 修复 A —— 特征值弯曲（bending）：负特征值替换为 ε，重构后再标准化为相关矩阵；
    3. 修复 B —— Higham (2002) 交替投影求 Frobenius 意义下的最近相关矩阵；
    4. 比较两种修复对各相关系数的改变量，以及对一个线性目标 H = aᵀu 方差的影响。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def to_corr(S):
    d = np.sqrt(np.diag(S)); return S / np.outer(d, d)


def bend(R, eps):
    w, V = np.linalg.eigh(R)
    w2 = np.where(w < eps, eps, w)
    return to_corr((V * w2) @ V.T)


def nearest_corr(R, tol=1e-12, maxit=10000, eps=0.0):
    """Higham 交替投影（带 Dykstra 修正）。"""
    Y = R.copy(); dS = np.zeros_like(R)
    for _ in range(maxit):
        Rk = Y - dS
        w, V = np.linalg.eigh(Rk)
        X = (V * np.maximum(w, eps)) @ V.T
        dS = X - Rk
        Ynew = X.copy(); np.fill_diagonal(Ynew, 1.0)
        if np.linalg.norm(Ynew - Y, "fro") < tol: Y = Ynew; break
        Y = Ynew
    return Y


def main():
    cfg = json.loads((HERE / "data" / "ex02_28_bending.json").read_text(encoding="utf-8"))
    R = np.array(cfg["R_piecewise"]); tr = cfg["traits"]; sd = np.array(cfg["sd"])
    w, V = np.linalg.eigh(R)
    print("特征值 =", np.round(w, 5))
    neg = w < 0
    for j in np.where(neg)[0]:
        print(f"负特征值 {w[j]:.5f} 对应方向（标准化单位）=", np.round(V[:, j], 4))
    Rb = bend(R, cfg["eps"]); Rh = nearest_corr(R, eps=cfg["eps"])
    for name, M in (("弯曲", Rb), ("最近相关", Rh)):
        ev = np.linalg.eigvalsh(M)
        assert ev.min() > 0 and np.allclose(np.diag(M), 1)
        d = M - R
        print(f"\n{name}后最小特征值 {ev.min():.2e}，‖ΔR‖_F = {np.linalg.norm(d):.4f}，最大 |Δr| = {np.abs(d).max():.4f}")
        print(np.round(M, 4))
    a = np.array([0.0, 1.0, 1.0, -2.0])           # 一个教学用目标权重（标准化单位）
    for name, M in (("原矩阵", R), ("弯曲", Rb), ("最近相关", Rh)):
        print(f"{name:<6s} 目标方差 aᵀRa = {a @ M @ a:.4f}")
    G = np.outer(sd, sd) * Rh
    out = {"eigen_original": w.round(6).tolist(), "R_bent": Rb.round(5).tolist(), "R_nearest": Rh.round(5).tolist(),
           "frob_change": {"bend": float(np.linalg.norm(Rb - R)), "nearest": float(np.linalg.norm(Rh - R))},
           "target_var": {"orig": float(a @ R @ a), "bend": float(a @ Rb @ a), "nearest": float(a @ Rh @ a)},
           "G_nearest": G.round(5).tolist()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex02_28_bending.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
