#!/usr/bin/env python3
"""习题 2.19  混合模型方程的迭代求解：Jacobi、Gauss–Seidel 与预条件共轭梯度

构造一个教学用混合模型：y = Xb + Zu + e，b 为 15 个管理组，u 为 300 只动物的随机效应，
协方差 u ~ N(0, Aσu²)，A 由随机系谱递推得到（只用 A⁻¹ 的稀疏 Henderson 规则构造）。
系数矩阵 C = [[XᵀX, XᵀZ], [ZᵀX, ZᵀZ + λA⁻¹]]，λ = σe²/σu²。
    1. 用稀疏 Henderson 规则直接写出 A⁻¹（无需求 A 的逆）；
    2. 以 Jacobi、Gauss–Seidel、对角预条件共轭梯度三法求解，记录相对残差降到 tol 所需迭代数；
    3. 与稠密 Cholesky 直接解比较最大绝对差；
    4. 报告 C 的条件数与对角预条件后的条件数，解释 PCG 为何更快。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.linalg import cho_factor, cho_solve

HERE = Path(__file__).resolve().parent


def random_pedigree(n, rng, n_base=40):
    ped = []
    for i in range(n):
        if i < n_base:
            ped.append((-1, -1))
        else:
            s = int(rng.integers(0, i)); d = int(rng.integers(0, i))
            if rng.random() < 0.15: d = -1          # 15% 未知母亲
            ped.append((s, d))
    return ped


def ainv_henderson(ped):
    """忽略近交的 Henderson 规则（教学用；第12章给出含近交的完整算法）。"""
    n = len(ped); Ai = np.zeros((n, n))
    for i, (s, d) in enumerate(ped):
        known = [p for p in (s, d) if p >= 0]
        delta = {0: 1.0, 1: 4 / 3, 2: 2.0}[len(known)]
        Ai[i, i] += delta
        for p in known:
            Ai[i, p] -= delta / 2; Ai[p, i] -= delta / 2
            for q in known:
                Ai[p, q] += delta / 4
    return Ai


def jacobi(C, r, tol, maxit, omega=1.0):
    """（加权）Jacobi：x ← x + ω D⁻¹(r − Cx)。发散时返回 None。"""
    x = np.zeros_like(r); D = np.diag(C)
    for k in range(1, maxit + 1):
        x = x + omega * (r - C @ x) / D
        rel = np.linalg.norm(r - C @ x) / np.linalg.norm(r)
        if not np.isfinite(rel) or rel > 1e8: return None, k
        if rel < tol: return x, k
    return x, maxit


def jacobi_radius(C, omega=1.0):
    """迭代矩阵 I − ω D⁻¹C 的谱半径：<1 才收敛。"""
    D = np.diag(C)
    return float(np.max(np.abs(np.linalg.eigvals(np.eye(len(D)) - omega * C / D[:, None]))))


def gauss_seidel(C, r, tol, maxit):
    x = np.zeros_like(r); n = len(r)
    for k in range(1, maxit + 1):
        for i in range(n):
            x[i] += (r[i] - C[i] @ x) / C[i, i]
        if np.linalg.norm(r - C @ x) / np.linalg.norm(r) < tol: return x, k
    return x, maxit


def pcg(C, r, tol, maxit):
    Minv = 1 / np.diag(C); x = np.zeros_like(r); res = r.copy(); z = Minv * res; d = z.copy(); rz = res @ z
    for k in range(1, maxit + 1):
        q = C @ d; a = rz / (d @ q); x += a * d; res -= a * q
        if np.linalg.norm(res) / np.linalg.norm(r) < tol: return x, k
        z = Minv * res; rz_new = res @ z; d = z + (rz_new / rz) * d; rz = rz_new
    return x, maxit


def main():
    cfg = json.loads((HERE / "data" / "ex02_19_iterative.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n, g, lam = cfg["n_animals"], cfg["n_groups"], cfg["lambda"]
    ped = random_pedigree(n, rng)
    Ai = ainv_henderson(ped)
    grp = rng.integers(0, g, n)
    X = np.eye(g)[grp]; Z = np.eye(n)
    y = 10 + X @ rng.normal(0, 2, g) + rng.normal(0, 1, n) + rng.normal(0, np.sqrt(lam), n)
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * Ai]])
    r = np.concatenate([X.T @ y, Z.T @ y])
    x_dir = cho_solve(cho_factor(C), r)
    Dm = 1 / np.sqrt(np.diag(C))
    kC = np.linalg.cond(C); kP = np.linalg.cond(C * np.outer(Dm, Dm))
    print(f"方程阶数 = {len(r)}，非零元比例 = {np.mean(C != 0):.4f}，κ(C) = {kC:.1f}，对角预条件后 κ = {kP:.1f}")
    out = {"order": len(r), "density": float(np.mean(C != 0)), "cond": kC, "cond_precond": kP, "methods": {}}
    rho1, rho5 = jacobi_radius(C, 1.0), jacobi_radius(C, 0.5)
    print(f"Jacobi 迭代矩阵谱半径：ω=1 时 {rho1:.4f}，ω=0.5 时 {rho5:.4f}")
    out["jacobi_spectral_radius"] = {"omega1": rho1, "omega0.5": rho5}
    methods = (("Jacobi(ω=1)", lambda C, r, t, m: jacobi(C, r, t, m, 1.0)),
               ("Jacobi(ω=0.5)", lambda C, r, t, m: jacobi(C, r, t, m, 0.5)),
               ("Gauss-Seidel", gauss_seidel), ("PCG(对角)", pcg))
    for name, f in methods:
        x, it = f(C, r, cfg["tol"], cfg["max_iter"])
        if x is None:
            out["methods"][name] = {"iterations": it, "status": "发散"}
            print(f"{name:<14s} 第 {it} 次迭代时残差超过 1e8，判定发散")
            continue
        err = float(np.max(np.abs(x - x_dir)))
        out["methods"][name] = {"iterations": it, "max_abs_diff": err}
        print(f"{name:<14s} 迭代 {it:5d} 次  与直接解最大差 {err:.2e}")
    # 可估计量：组间差与动物育种值 — 检查 PCG 解的动物部分排名与直接解一致
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex02_19_iterative_solvers.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
