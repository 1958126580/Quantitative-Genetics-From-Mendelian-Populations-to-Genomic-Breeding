# 第2章　矩阵方法与稳定计算——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex02_15_estimability.py
python3 ex02_16_cholesky_whitening.py
python3 ex02_17_qr_vs_normal.py
python3 ex02_18_svd_lowrank.py
python3 ex02_19_iterative_solvers.py
python3 ex02_22_rank_one_update.py
python3 ex02_28_bending.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex02_15_estimability.py | 2.15 | 从记录表到设计矩阵：秩、广义逆与可估计函数 |
| ex02_16_cholesky_whitening.py | 2.16 | Cholesky 分解：合法性检查、相关育种值的生成、白化与马氏距离 |
| ex02_17_qr_vs_normal.py | 2.17 | 生长曲线回归：正规方程、QR 与正交多项式的数值稳定性 |
| ex02_18_svd_lowrank.py | 2.18 | 基因型矩阵的奇异值分解与低秩近似 |
| ex02_19_iterative_solvers.py | 2.19 | 混合模型方程的迭代求解：Jacobi、Gauss–Seidel 与预条件共轭梯度 |
| ex02_22_rank_one_update.py | 2.22 | 单条记录的增加与删除：Sherman–Morrison 公式与留一残差 |
| ex02_28_bending.py | 2.28 | 分段估计的遗传相关矩阵非正定：诊断与修复（特征值弯曲与最近相关矩阵） |
