#!/usr/bin/env python3
"""习题 2.16  Cholesky 分解：合法性检查、相关育种值的生成、白化与马氏距离

给定三性状加性协方差矩阵 G：
    1. 计算 Cholesky 因子 L（G = L Lᵀ），以“分解成功且对角元为正”判定正定；
    2. 由 z ~ N(0, I) 生成 u = L z，验证样本协方差逼近 G；
    3. 白化：w = L⁻¹ u 使各分量独立、方差为 1；候选个体的马氏距离 d² = uᵀG⁻¹u = ‖L⁻¹u‖²，
       并给出它在 χ²(3) 下的上尾概率（候选者在三维遗传空间中“有多罕见”）；
    4. 说明 L 的第 j 行给出“第 j 个性状在前 j−1 个性状已知后剩余的遗传标准差”。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.linalg import cholesky, solve_triangular
from scipy.stats import chi2

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex02_16_G.json").read_text(encoding="utf-8"))
    G = np.array(cfg["G"]); traits = cfg["traits"]
    L = cholesky(G, lower=True)
    assert np.all(np.diag(L) > 0) and np.allclose(L @ L.T, G)
    print("Cholesky 因子 L =\n", np.round(L, 5))
    sd = np.sqrt(np.diag(G)); R = G / np.outer(sd, sd)
    print("遗传相关矩阵 =\n", np.round(R, 4))
    # 条件标准差：L[j,j] = sd(u_j | u_1..u_{j-1})
    for j in range(len(G)):
        if j == 0:
            cond = np.sqrt(G[0, 0])
        else:
            A = G[:j, :j]; b = G[:j, j]
            cond = np.sqrt(G[j, j] - b @ np.linalg.solve(A, b))
        assert np.isclose(cond, L[j, j])
        print(f"  {traits[j]} 在前 {j} 个性状已知后的条件遗传标准差 = {L[j,j]:.4f}（边际 {sd[j]:.4f}）")
    rng = np.random.default_rng(cfg["seed"])
    z = rng.standard_normal((len(G), cfg["n_sim"]))
    U = L @ z
    S = np.cov(U)
    rel_err = np.abs(S - G) / np.sqrt(np.outer(np.diag(G), np.diag(G)))
    print("模拟协方差相对误差（按标准差乘积标准化）最大值 =", round(float(rel_err.max()), 4))
    assert rel_err.max() < 0.02
    u = np.array(cfg["candidate_ebv"])
    w = solve_triangular(L, u, lower=True)
    d2 = float(w @ w)
    assert np.isclose(d2, u @ np.linalg.solve(G, u))
    p = float(chi2.sf(d2, df=len(G)))
    print(f"候选者白化坐标 w = {np.round(w,4)}，马氏距离平方 d² = {d2:.4f}，χ²(3) 上尾概率 = {p:.4f}")
    # 若逐性状看标准分数
    zscore = u / sd
    print("逐性状标准分数 =", np.round(zscore, 4), "→ 平方和 =", round(float(zscore @ zscore), 4))
    out = {"L": L.round(6).tolist(), "R": R.round(6).tolist(), "w": w.round(6).tolist(), "d2": round(d2, 6), "p_upper": round(p, 6),
           "zscore_sumsq": round(float(zscore @ zscore), 6), "sim_max_rel_err": round(float(rel_err.max()), 5)}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex02_16_cholesky_whitening.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
