#!/usr/bin/env python3
"""习题 2.18  基因型矩阵的奇异值分解与低秩近似

模拟 20 个全同胞家系、每家 10 只、1000 个 SNP 的基因型（0/1/2），列中心化得 W。
    1. 计算 W = U S Vᵀ；前 k 个主成分解释的方差比例 = Σ_{j≤k} s_j² / Σ s_j²；
    2. Eckart–Young 定理：秩 k 最佳近似 W_k 的 Frobenius 误差平方 = Σ_{j>k} s_j²（数值核对）；
    3. 20 个家系中心化后张成 19 维，前 19 个奇异值显著偏大（家系均值方向），其余近似“噪声底”；
    4. G = WWᵀ/(2Σpq) 的特征值 = s²/(2Σpq)，其秩 ≤ n−1（中心化消去一个方向）。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    m = cfg["n_snp"]
    p = rng.uniform(*cfg["maf_range"], m)
    rows = []
    for _ in range(cfg["n_families"]):
        sire = rng.binomial(1, p, (2, m)); dam = rng.binomial(1, p, (2, m))
        for _ in range(cfg["per_family"]):
            a = sire[rng.integers(0, 2, m), np.arange(m)]
            b = dam[rng.integers(0, 2, m), np.arange(m)]
            rows.append(a + b)
    return np.array(rows, float), p


def main():
    cfg = json.loads((HERE / "data" / "ex02_18_svd.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    M, p0 = simulate(cfg, rng)
    p = M.mean(0) / 2
    W = M - 2 * p
    U, s, Vt = np.linalg.svd(W, full_matrices=False)
    tot = float(np.sum(s ** 2))
    n = W.shape[0]
    rank = int(np.sum(s > 1e-9 * s[0]))
    print(f"W 为 {W.shape}，数值秩 = {rank}（中心化后 ≤ n−1 = {n-1}）")
    rows = []
    for k in cfg["ranks"]:
        Wk = (U[:, :k] * s[:k]) @ Vt[:k]
        err = float(np.sum((W - Wk) ** 2))
        theory = float(np.sum(s[k:] ** 2))
        assert np.isclose(err, theory, rtol=1e-8), "Eckart–Young 核对失败"
        rows.append({"k": k, "explained": round(float(np.sum(s[:k] ** 2) / tot), 4), "frob_err2": round(err, 2)})
        print(f"k={k:4d}  解释方差比例={np.sum(s[:k]**2)/tot:.4f}  ‖W−W_k‖²_F={err:10.2f}（理论 {theory:10.2f}）")
    f = cfg['n_families'] - 1          # 中心化后家系均值张成 F−1 维
    gap = s[f - 1] / s[f]
    print(f"第{f}与第{f+1}个奇异值之比 = {gap:.3f}（{cfg['n_families']} 个家系中心化后张成 {f} 维，形成“断点”）")
    print(f"前{f}个主成分解释方差比例 = {np.sum(s[:f]**2)/tot:.4f}")
    scale = 2 * float(np.sum(p * (1 - p)))
    G = W @ W.T / scale
    ev = np.sort(np.linalg.eigvalsh(G))[::-1]
    assert np.allclose(ev[:rank], (s[:rank] ** 2) / scale)
    print(f"G 的迹 = {np.trace(G):.3f}，平均对角 = {np.trace(G)/n:.4f}，最小特征值 = {ev[-1]:.2e}")
    (HERE / "results").mkdir(exist_ok=True)
    out = {"singular_values_top30": s[:30].round(4).tolist(), "rank": rank, "rows": rows, "gap_ratio": round(float(gap), 4),
           "G_trace": round(float(np.trace(G)), 4)}
    (HERE / "results" / "ex02_18_svd_lowrank.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    plt = get_pyplot()
    if plt:
        fig, ax = plt.subplots(figsize=(6, 3.6))
        ax.plot(np.arange(1, len(s) + 1), s ** 2 / tot, ".-", ms=3)
        ax.axvline(cfg["n_families"] - 1, ls="--", c="gray"); ax.set_yscale("log")
        ax.set_xlabel("主成分序号"); ax.set_ylabel("方差比例"); fig.tight_layout()
        fig.savefig(HERE / "results" / "ex02_18_scree.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    main()
