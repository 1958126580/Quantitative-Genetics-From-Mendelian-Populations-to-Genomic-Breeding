#!/usr/bin/env python3
"""习题 2.15  从记录表到设计矩阵：秩、广义逆与可估计函数

记录：8 条体重，固定效应 = 均值 + 场(3) + 性别(2) + 公羊(4)（把公羊也当固定效应）。
公羊 S4 只出现在 H3，且 H3 只有 S4，因此“H3 场效应”与“S4 公羊效应”完全混杂。
判定 λᵀβ 可估计的充要条件： λᵀ 位于 X 的行空间，等价于  λᵀ (XᵀX)⁻(XᵀX) = λᵀ。
本程序：
    1. 由记录表构造 X，用奇异值求秩并列出零空间方向（不可识别方向）；
    2. 对一组候选线性函数逐一检验可估计性，可估计者给出 BLUE 及其对不同广义逆的不变性；
    3. 用两种广义逆（Moore–Penrose 与“置零约束”）核对：可估计函数的估计值完全相同。
"""
from __future__ import annotations
import csv, json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def design(rows):
    levels = {k: sorted({r[k] for r in rows}) for k in ("herd", "sex", "sire")}
    names = ["mu"] + [f"{k}:{v}" for k in ("herd", "sex", "sire") for v in levels[k]]
    X = np.zeros((len(rows), len(names)))
    for i, r in enumerate(rows):
        X[i, 0] = 1
        for k in ("herd", "sex", "sire"):
            X[i, names.index(f"{k}:{r[k]}")] = 1
    return X, names


def setzero_ginv(XtX, drop):
    """把指定列对应的参数约束为 0 后求逆，得到 XᵀX 的一个（对称）广义逆。"""
    keep = [j for j in range(XtX.shape[0]) if j not in drop]
    G = np.zeros_like(XtX)
    G[np.ix_(keep, keep)] = np.linalg.inv(XtX[np.ix_(keep, keep)])
    return G


def main():
    rows = list(csv.DictReader(open(HERE / "data" / "ex02_15_records.csv", encoding="utf-8")))
    y = np.array([float(r["weight"]) for r in rows])
    X, names = design(rows)
    XtX, Xty = X.T @ X, X.T @ y
    sv = np.linalg.svd(X, compute_uv=False)
    rank = int(np.sum(sv > 1e-10 * sv[0]))
    _, _, Vt = np.linalg.svd(X)
    null = Vt[rank:]
    print(f"X 为 {X.shape[0]}×{X.shape[1]}，秩 = {rank}，零空间维数 = {X.shape[1]-rank}")
    # 用整数化表示零空间（便于解释）：对每个零空间方向做简化
    G1 = np.linalg.pinv(XtX)
    drop = [names.index(n) for n in ("herd:H1", "sex:F", "sire:S1", "sire:S4")]
    G2 = setzero_ginv(XtX, drop)
    assert np.allclose(XtX @ G2 @ XtX, XtX), "置零约束不是广义逆"
    b1, b2 = G1 @ Xty, G2 @ Xty
    H = G1 @ XtX
    def lam(**kw):
        v = np.zeros(len(names))
        for k, c in kw.items():
            v[names.index(k.replace("_", ":"))] += c
        return v
    cands = {
        "H2 - H1": lam(herd_H2=1, herd_H1=-1),
        "H3 - H1": lam(herd_H3=1, herd_H1=-1),
        "M - F": lam(sex_M=1, sex_F=-1),
        "S2 - S1": lam(sire_S2=1, sire_S1=-1),
        "S4 - S1": lam(sire_S4=1, sire_S1=-1),
        "(H3+S4) - (H1+S1)": lam(herd_H3=1, sire_S4=1, herd_H1=-1, sire_S1=-1),
        "mu + H1 + F + S1": lam(mu=1, herd_H1=1, sex_F=1, sire_S1=1),
        "mu": lam(mu=1),
    }
    s2 = float(np.sum((y - X @ b1) ** 2) / (len(y) - rank))
    res = {"rank": rank, "n_params": len(names), "null_space": null.round(4).tolist(), "residual_var": s2, "functions": {}}
    print(f"残差方差估计 = {s2:.4f}\n{'线性函数':<22s}{'可估计?':>8s}{'估计(pinv)':>12s}{'估计(置零)':>12s}{'SE':>8s}")
    for name, l in cands.items():
        est = bool(np.allclose(l @ H, l, atol=1e-9))
        e1, e2 = float(l @ b1), float(l @ b2)
        se = float(np.sqrt(l @ G1 @ l * s2)) if est else float("nan")
        if est:
            assert abs(e1 - e2) < 1e-8, "可估计函数在不同广义逆下应不变"
        res["functions"][name] = {"estimable": est, "est_pinv": round(e1, 4), "est_setzero": round(e2, 4), "se": None if not est else round(se, 4)}
        print(f"{name:<22s}{'是' if est else '否':>8s}{e1:12.4f}{e2:12.4f}{se:8.3f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex02_15_estimability.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
