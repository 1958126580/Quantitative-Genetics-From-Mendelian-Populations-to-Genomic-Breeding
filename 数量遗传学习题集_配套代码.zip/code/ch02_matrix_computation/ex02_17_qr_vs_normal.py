#!/usr/bin/env python3
"""习题 2.17  生长曲线回归：正规方程、QR 与正交多项式的数值稳定性

以日龄 t（30–210 天）的原始幂 1, t, t², …, t^q 作协变量拟合体重。原始幂高度共线，
X 的二范数条件数 κ(X) 随 q 急剧增大，而 κ(XᵀX) = κ(X)²。比较三种算法：
    (a) 正规方程：解 XᵀX b = Xᵀy（Cholesky）；
    (b) Householder QR：X = QR，解 R b = Qᵀy；
    (c) 把 t 标准化到 [−1, 1] 后用 Legendre 正交多项式基。
衡量指标：与高精度（mpmath 不可用时以 QR+迭代精化）参考解的拟合值差异。
结论应当是：拟合值（可估计量）对算法稳健，而原始幂系数本身随 q 增大而失去解释意义。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from numpy.polynomial import legendre as Leg
from scipy.linalg import cho_factor, cho_solve, qr, solve_triangular

HERE = Path(__file__).resolve().parent


def refine(X, y, b, steps=3):
    """以 QR 为求解器做迭代精化（残差用扩展精度累加），作为参考解。"""
    Q, R = qr(X, mode="economic")
    for _ in range(steps):
        r = (y.astype(np.longdouble) - X.astype(np.longdouble) @ b.astype(np.longdouble)).astype(float)
        db = solve_triangular(R, Q.T @ r)
        b = b + db
    return b


def main():
    cfg = json.loads((HERE / "data" / "ex02_17_growth.json").read_text(encoding="utf-8"))
    t = np.array(cfg["ages_days"], float)
    c = cfg["true_coef_raw"]
    rng = np.random.default_rng(cfg["seed"])
    y = c[0] + c[1] * t + c[2] * t ** 2 + rng.normal(0, cfg["noise_sd"], t.size)
    s = (t - t.mean()) / (t.max() - t.mean())        # 映射到 [-1, 1]
    rows = []
    print(f"{'q':>2s} {'κ(X)':>11s} {'κ(XᵀX)':>11s} {'正规方程拟合误差':>16s} {'QR拟合误差':>12s} {'Legendre拟合误差':>16s} {'κ(Legendre)':>11s}")
    for q in range(1, cfg["max_degree"] + 1):
        X = np.vander(t, q + 1, increasing=True)
        P = Leg.legvander(s, q)
        kX = np.linalg.cond(X); kXtX = np.linalg.cond(X.T @ X); kP = np.linalg.cond(P)
        Q, R = qr(X, mode="economic"); b_qr = solve_triangular(R, Q.T @ y)
        b_ref = refine(X, y, b_qr.copy())
        fit_ref = X @ b_ref
        try:
            b_ne = cho_solve(cho_factor(X.T @ X), X.T @ y); err_ne = float(np.max(np.abs(X @ b_ne - fit_ref)))
        except np.linalg.LinAlgError:
            err_ne = float("inf")
        err_qr = float(np.max(np.abs(X @ b_qr - fit_ref)))
        b_leg = np.linalg.lstsq(P, y, rcond=None)[0]
        err_leg = float(np.max(np.abs(P @ b_leg - fit_ref)))
        rows.append({"degree": q, "cond_X": kX, "cond_XtX": kXtX, "cond_legendre": kP,
                     "fit_err_normal_eq": err_ne, "fit_err_qr": err_qr, "fit_err_legendre": err_leg,
                     "raw_coef_qr": b_qr.tolist()})
        print(f"{q:2d} {kX:11.3e} {kXtX:11.3e} {err_ne:16.3e} {err_qr:12.3e} {err_leg:16.3e} {kP:11.3f}")
    # 二次模型的系数与真值比较
    X2 = np.vander(t, 3, increasing=True); b2 = np.linalg.lstsq(X2, y, rcond=None)[0]
    print("二次模型原始幂系数估计 =", np.array2string(b2, precision=6), "真值 =", c)
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex02_17_qr_vs_normal.json").write_text(json.dumps({"rows": rows, "quadratic_coef": b2.tolist()}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
