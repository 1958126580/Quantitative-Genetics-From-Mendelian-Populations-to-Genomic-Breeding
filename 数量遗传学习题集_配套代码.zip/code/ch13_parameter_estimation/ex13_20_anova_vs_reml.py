#!/usr/bin/env python3
"""习题 13.20  不平衡套式资料：方差分析（Henderson 方法 I）与 REML 的蒙特卡洛比较

模型 y_ijl = μ + S_i + D_ij + e_ijl，σ_S² = V_A/4，σ_D² = V_A/4 + V_Ec，σ_W² = V_A/2 + V_Ew（V_D = 0）。
资料结构固定且严重不平衡（data/ 中给出每头公畜各母畜的后代数）。
ANOVA：E(MS_S) = σ_W² + k2σ_D² + k3σ_S²，E(MS_D) = σ_W² + k1σ_D²，E(MS_W) = σ_W²，解线性方程组；
        报告未截断估计与“负值置零”估计。
REML：V_i = σ_W² I + σ_D² ⊕_j J_{n_ij} + σ_S² J_{n_i}，利用块结构解析计算
        log|V_i|、1ᵀV_i⁻¹1、rᵀV_i⁻¹r（无需形成矩阵），−2ℓ_R = Σlog|V_i| + log Σ1ᵀV_i⁻¹1 + Σr̃ᵀV_i⁻¹r̃，
        在 σ² ≥ 0 上用 L-BFGS-B 最小化。
核验：(1) 块解析似然与稠密矩阵 REML 似然一致；(2) 平衡资料且 ANOVA 估计全为正时，REML = ANOVA。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).resolve().parent


class Nested:
    """以母畜为单位的充分统计量：所属公畜、后代数、和、平方和。"""

    def __init__(self, sire: np.ndarray, n: np.ndarray, sy: np.ndarray, syy: np.ndarray):
        self.sire, self.n, self.sy, self.syy = sire, n.astype(float), sy, syy
        self.S = int(sire.max()) + 1; self.D = len(n); self.N = float(n.sum())


def simulate(struct, comp, rng, keep_raw=False):
    s2s, s2d, s2w = comp
    sire, n, sy, syy, raw = [], [], [], [], []
    for i, dams in enumerate(struct):
        si = rng.normal(0, np.sqrt(s2s))
        for nj in dams:
            y = si + rng.normal(0, np.sqrt(s2d)) + rng.normal(0, np.sqrt(s2w), nj)
            sire.append(i); n.append(nj); sy.append(y.sum()); syy.append((y * y).sum())
            if keep_raw: raw.append(y)
    return Nested(np.array(sire), np.array(n), np.array(sy), np.array(syy)), raw


def anova(d: Nested):
    ni = np.bincount(d.sire, d.n, d.S); ti = np.bincount(d.sire, d.sy, d.S)
    gm = d.sy.sum() / d.N
    ss_w = (d.syy - d.sy ** 2 / d.n).sum()
    ss_d = (d.sy ** 2 / d.n).sum() - (ti ** 2 / ni).sum()
    ss_s = (ti ** 2 / ni).sum() - d.N * gm ** 2
    df_s, df_d, df_w = d.S - 1, d.D - d.S, d.N - d.D
    ms = np.array([ss_s / df_s, ss_d / df_d, ss_w / df_w])
    q = np.bincount(d.sire, d.n ** 2, d.S) / ni           # Σ_j n_ij² / n_i
    k1 = (d.N - q.sum()) / df_d
    k2 = (q.sum() - (d.n ** 2).sum() / d.N) / df_s
    k3 = (d.N - (ni ** 2).sum() / d.N) / df_s
    s2w = ms[2]; s2d = (ms[1] - ms[2]) / k1; s2s = (ms[0] - ms[2] - k2 * s2d) / k3
    return np.array([s2s, s2d, s2w]), ms, (k1, k2, k3)


def reml_m2ll(theta, d: Nested) -> float:
    s2s, s2d, s2w = theta
    a = s2w + d.n * s2d
    logdetA = (d.n - 1) * np.log(s2w) + np.log(a)
    sw = np.bincount(d.sire, d.n / a, d.S)                  # Σ_j 1ᵀA_j⁻¹1
    c = 1 + s2s * sw
    logdet = np.bincount(d.sire, logdetA, d.S).sum() + np.log(c).sum()
    one_v_one = sw / c
    one_v_y = np.bincount(d.sire, d.sy / a, d.S) / c
    mu = one_v_y.sum() / one_v_one.sum()
    sr = d.sy - d.n * mu; ssr = d.syy - 2 * mu * d.sy + d.n * mu * mu
    quadA = (ssr - s2d * sr ** 2 / a) / s2w
    u = np.bincount(d.sire, sr / a, d.S)
    quad = quadA.sum() - (s2s * u ** 2 / c).sum()
    return float(logdet + np.log(one_v_one.sum()) + quad)


def reml(d: Nested, start: np.ndarray) -> np.ndarray:
    x0 = np.maximum(start, [1e-3, 1e-3, 1e-2])
    r = minimize(reml_m2ll, x0, args=(d,), method="L-BFGS-B", bounds=[(0, None), (0, None), (1e-6, None)],
                 options={"ftol": 1e-11, "gtol": 1e-7})
    return r.x


def dense_m2ll(theta, raw, struct):
    """稠密矩阵实现（仅用于核验）：log|V| + log|1ᵀV⁻¹1| + yᵀPy。"""
    s2s, s2d, s2w = theta; y = np.concatenate(raw); N = len(y)
    sire_id = np.concatenate([[i] * nj for i, dams in enumerate(struct) for nj in dams])
    dam_id = np.concatenate([[j] * len(r) for j, r in enumerate(raw)])
    V = s2w * np.eye(N) + s2d * (dam_id[:, None] == dam_id[None, :]) + s2s * (sire_id[:, None] == sire_id[None, :])
    L = np.linalg.cholesky(V); one = np.ones(N)
    Vi1 = np.linalg.solve(L.T, np.linalg.solve(L, one)); Viy = np.linalg.solve(L.T, np.linalg.solve(L, y))
    mu = one @ Viy / (one @ Vi1)
    return float(2 * np.log(np.diag(L)).sum() + np.log(one @ Vi1) + (y - mu) @ (Viy - mu * Vi1))


def h2s(c):
    return 4 * c[..., 0] / c.sum(-1)


def summarize(est, truth):
    bias = est.mean(0) - truth; sd = est.std(0, ddof=1); mse = ((est - truth) ** 2).mean(0)
    return bias, sd, mse


def main():
    cfg = json.loads((HERE / "data" / "ex13_20_unbalanced.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); struct = cfg["structure_dam_sizes_by_sire"]
    nsizes = [sum(x) for x in struct]
    print(f"资料结构：{len(struct)} 头公畜，{sum(map(len, struct))} 头母畜，{sum(nsizes)} 个后代；"
          f"每公畜后代数 {min(nsizes)}—{max(nsizes)}，每窝 {min(min(x) for x in struct)}—{max(max(x) for x in struct)}")

    # 核验 1：块解析似然 = 稠密矩阵似然
    d0, raw0 = simulate(struct, (0.06, 0.11, 0.83), rng, keep_raw=True)
    for th in ([0.06, 0.11, 0.83], [0.0, 0.2, 0.7], [0.15, 0.01, 1.1]):
        assert np.isclose(reml_m2ll(np.array(th), d0), dense_m2ll(th, raw0, struct), rtol=1e-10)
    # 核验 2：平衡资料，ANOVA 全正时 REML 与 ANOVA 相同
    bc = cfg["balanced_check"]; comp_b = (bc["VA"] / 4, bc["VA"] / 4 + bc["VEc"], 1 - bc["VA"] / 2 - bc["VEc"])
    db, _ = simulate([[bc["k"]] * bc["d"]] * bc["s"], comp_b, rng)
    ab, _, kb = anova(db); rb = reml(db, ab)
    assert np.all(ab > 0) and np.allclose(kb, (bc["k"], bc["k"], bc["d"] * bc["k"]))
    assert np.allclose(rb, ab, rtol=2e-4, atol=1e-6), (rb, ab)
    print(f"平衡核验（{bc['s']}×{bc['d']}×{bc['k']}）：ANOVA {np.round(ab, 5)}，REML {np.round(rb, 5)}")

    out = {"structure": {"sires": len(struct), "dams": sum(map(len, struct)), "N": sum(nsizes)}, "scenarios": {}}
    _, _, k = anova(simulate(struct, (0.1, 0.1, 0.8), rng)[0])
    out["structure"]["k"] = list(map(float, k)); print(f"k1 = {k[0]:.3f}，k2 = {k[1]:.3f}，k3 = {k[2]:.3f}")
    for sc in cfg["scenarios"]:
        VA, VEc = sc["VA"], sc["VEc"]; truth = np.array([VA / 4, VA / 4 + VEc, cfg["VP"] - VA / 2 - VEc])
        A, R = [], []
        for _ in range(cfg["reps"]):
            d, _ = simulate(struct, truth, rng); a, _, _ = anova(d); A.append(a); R.append(reml(d, a))
        A = np.array(A); R = np.array(R); At = A.copy(); At[:, :2] = np.maximum(At[:, :2], 0)
        print(f"\n情景 {sc['name']}：真 σ_S² = {truth[0]:.4f}，σ_D² = {truth[1]:.4f}，σ_W² = {truth[2]:.4f}，"
              f"真 h² = {VA:.2f}（{cfg['reps']} 次重复）")
        print(f"{'方法':<12s}{'参数':<8s}{'均值':>9s}{'偏差':>9s}{'SD':>9s}{'MSE':>10s}{'σ_S²≤0 比例':>12s}")
        res = {}
        for name, E in (("ANOVA", A), ("ANOVA截断", At), ("REML", R)):
            full = np.column_stack([E[:, 0], E[:, 1], h2s(E)]); tr = np.array([truth[0], truth[1], VA])
            b, s, m = summarize(full, tr)
            frac0 = float(np.mean(E[:, 0] <= 1e-8))
            res[name] = {"mean": full.mean(0).tolist(), "bias": b.tolist(), "sd": s.tolist(), "mse": m.tolist(), "frac_sS_le0": frac0}
            for j, p in enumerate(("σ_S²", "σ_D²", "h²_S")):
                print(f"{name if j == 0 else '':<12s}{p:<8s}{full[:, j].mean():9.4f}{b[j]:9.4f}{s[j]:9.4f}{m[j]:10.5f}"
                      f"{(f'{frac0:.3f}' if j == 0 else ''):>12s}")
        # 核验：未截断 ANOVA 无偏（偏差在 4 个蒙特卡洛标准误内）；REML 估计均在参数空间内
        assert abs(res["ANOVA"]["bias"][0]) < 4 * res["ANOVA"]["sd"][0] / np.sqrt(cfg["reps"])
        assert np.all(R[:, :2] >= 0)
        res["corr_anova_reml_h2"] = float(np.corrcoef(h2s(A), h2s(R))[0, 1])
        print(f"ANOVA 与 REML 的 ĥ²_S 相关：{res['corr_anova_reml_h2']:.3f}")
        out["scenarios"][sc["name"]] = res

    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex13_20_anova_vs_reml.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
