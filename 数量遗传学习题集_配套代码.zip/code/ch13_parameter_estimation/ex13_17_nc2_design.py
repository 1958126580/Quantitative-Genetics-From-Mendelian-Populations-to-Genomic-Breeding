#!/usr/bin/env python3
"""习题 13.17  北卡罗来纳设计 II（析因交配）：一般配合力、特殊配合力与显性方差的估计

m 头雄 × f 头雌全部交配（析因），每个组合 k 个后代。随机模型
    y = μ + M_i + F_j + (MF)_ij + e，σ_M² = σ_F² = V_A/4，σ_MF² = V_D/4 (+ V_Ec)，σ_e² = V_A/2 + 3V_D/4 + V_Ew
平衡 ANOVA 期望均方：E(MS_M) = σ_e² + kσ_MF² + kfσ_M²，E(MS_F) = σ_e² + kσ_MF² + kmσ_F²，
E(MS_MF) = σ_e² + kσ_MF²，E(MS_e) = σ_e²。
程序在 300 次模拟上比较 V̂_A = 2(σ̂_M² + σ̂_F²) 与 V̂_D = 4σ̂_MF² 的偏差与离散，说明显性方差估计的精度远低于加性方差。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex13_17_nc2.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); m, f, k = cfg["n_males"], cfg["n_females"], cfg["progeny_per_cross"]
    VA, VD, VEc, VEw = cfg["VA"], cfg["VD"], cfg["VEc"], cfg["VEw"]
    sM = VA / 4; sMF = VD / 4 + VEc; se = VA / 2 + 0.75 * VD + VEw; est = []
    for _ in range(cfg["reps"]):
        y = (rng.normal(0, np.sqrt(sM), (m, 1, 1)) + rng.normal(0, np.sqrt(sM), (1, f, 1)) + rng.normal(0, np.sqrt(sMF), (m, f, 1)) + rng.normal(0, np.sqrt(se), (m, f, k)))
        gm = y.mean(); cm = y.mean((1, 2)); cf = y.mean((0, 2)); cc = y.mean(2)
        ms_m = f * k * np.sum((cm - gm) ** 2) / (m - 1); ms_f = m * k * np.sum((cf - gm) ** 2) / (f - 1)
        ms_mf = k * np.sum((cc - cm[:, None] - cf[None, :] + gm) ** 2) / ((m - 1) * (f - 1)); ms_e = np.sum((y - cc[:, :, None]) ** 2) / (m * f * (k - 1))
        s2mf = (ms_mf - ms_e) / k; s2m = (ms_m - ms_mf) / (k * f); s2f = (ms_f - ms_mf) / (k * m)
        est.append((2 * (s2m + s2f), 4 * s2mf, ms_e))
    e = np.array(est)
    out = {"VA_mean": float(e[:, 0].mean()), "VA_sd": float(e[:, 0].std()), "VD_mean": float(e[:, 1].mean()), "VD_sd": float(e[:, 1].std()),
           "VD_negative_frac": float(np.mean(e[:, 1] < 0)), "cv_VA": float(e[:, 0].std() / VA), "cv_VD": float(e[:, 1].std() / VD)}
    print(f"{m}×{f} 析因，每组合 {k} 个后代，共 {m*f*k} 个个体；真 V_A = {VA}，V_D = {VD}")
    print(f"V̂_A：均值 {out['VA_mean']:.4f}，SD {out['VA_sd']:.4f}（CV {out['cv_VA']:.2f}）")
    print(f"V̂_D：均值 {out['VD_mean']:.4f}，SD {out['VD_sd']:.4f}（CV {out['cv_VD']:.2f}），负估计比例 {out['VD_negative_frac']:.3f}")
    # 核验：方差分析估计无偏（4 个蒙特卡洛标准误内）；σ_e² 的估计均值接近其因果组成
    R = cfg["reps"]
    assert abs(out["VA_mean"] - VA) < 4 * out["VA_sd"] / np.sqrt(R)
    assert abs(out["VD_mean"] - VD) < 4 * out["VD_sd"] / np.sqrt(R)
    assert abs(e[:, 2].mean() - se) < 4 * e[:, 2].std() / np.sqrt(R)
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex13_17_nc2_design.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
