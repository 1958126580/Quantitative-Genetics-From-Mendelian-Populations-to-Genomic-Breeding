#!/usr/bin/env python3
"""习题 13.16  亲子回归对选择的稳健性：按亲本选择 vs 按后代选择 vs 只用双亲中值

子代对单亲表型回归 b_OP = h²/2；对中亲回归 b_OM = h²。
(1) 只保留亲本表型最高 20% 的亲子对（选择作用于自变量）：回归斜率无偏（Pearson–Aitken），但 SE 改变；
(2) 只保留后代表型最高 20% 的对（选择作用于因变量）：斜率严重有偏；
(3) 亲本与后代的相关在两种选择下都有偏。
各模拟 500 次，报告 h² 估计的均值与标准差。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def one(n, h2, rng):
    a_s = rng.normal(0, np.sqrt(h2), n); a_d = rng.normal(0, np.sqrt(h2), n)
    ps = a_s + rng.normal(0, np.sqrt(1 - h2), n)
    ao = 0.5 * (a_s + a_d) + rng.normal(0, np.sqrt(h2 / 2), n); po = ao + rng.normal(0, np.sqrt(1 - h2), n)
    return ps, po


def main():
    cfg = json.loads((HERE / "data" / "ex13_16_po.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); n, h2, f = cfg["n_pairs"], cfg["h2"], cfg["selected_fraction"]
    res = {k: [] for k in ("全部", "按亲本选择", "按后代选择")}; cor = {k: [] for k in res}
    for _ in range(cfg["reps"]):
        x, y = one(n, h2, rng)
        for k, m in (("全部", np.ones(n, bool)), ("按亲本选择", x > np.quantile(x, 1 - f)), ("按后代选择", y > np.quantile(y, 1 - f))):
            b = np.polyfit(x[m], y[m], 1)[0]; res[k].append(2 * b); cor[k].append(np.corrcoef(x[m], y[m])[0, 1])
    out = {}
    print(f"真 h² = {h2}；每次 {n} 对，保留比例 {f}")
    print(f"{'资料':<10s}{'ĥ²=2b 均值':>12s}{'SD':>8s}{'亲子相关均值':>12s}")
    for k in res:
        out[k] = {"h2_mean": float(np.mean(res[k])), "h2_sd": float(np.std(res[k])), "corr_mean": float(np.mean(cor[k]))}
        print(f"{k:<10s}{np.mean(res[k]):12.4f}{np.std(res[k]):8.4f}{np.mean(cor[k]):12.4f}")
    # 核验：全部资料与按亲本选择的回归无偏（4 个蒙特卡洛标准误内），按后代选择显著有偏
    R = cfg["reps"]
    for k in ("全部", "按亲本选择"):
        assert abs(out[k]["h2_mean"] - h2) < 4 * out[k]["h2_sd"] / np.sqrt(R)
    assert out["按后代选择"]["h2_mean"] < h2 / 2
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex13_16_parent_offspring_selection.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
