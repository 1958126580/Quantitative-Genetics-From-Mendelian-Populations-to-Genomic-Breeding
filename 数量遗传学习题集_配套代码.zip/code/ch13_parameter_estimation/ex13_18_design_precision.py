#!/usr/bin/env python3
"""习题 13.18  固定总测定数下三类设计的遗传力估计精度与最优家系大小

总测定记录数 T 固定（被测定的亲本也计入 T），表型方差标准化为 1，V_D = V_Ec = 0。
(1) 亲子回归：s 头公畜各测定自身并测定 n 个半同胞后代，T = s(1 + n)，对后代均值回归，
        Var(b̂) ≈ [t + (1 − t)/n − b²]/s，b = h²/2，t = h²/4，SE(ĥ²) = 2 SE(b̂)；
(2) 半同胞单因素：s 个家系各 n 个后代，T = sn，t = h²/4，
        Var(t̂) ≈ 2(1 − t)²[1 + (n − 1)t]² / [n(n − 1)(s − 1)]，SE(ĥ²) = 4 SE(t̂)；
(3) 全同胞套式：s 公畜 × d 母畜 × k 后代，T = sdk。三个均方独立，Var(MS) = 2E(MS)²/df，
        σ̂_S² = (MS_S − MS_D)/(dk)，σ̂_D² = (MS_D − MS_W)/k，σ̂_W² = MS_W，
        h²_S = 4σ_S²/σ_T²，h²_SD = 2(σ_S² + σ_D²)/σ_T²，用解析梯度做 delta 法。
对每种设计在网格上搜索使 SE(ĥ²) 最小的家系结构，并在 h² = 0.3 处用蒙特卡洛模拟核验近似公式。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


# ---------------- 解析近似 ----------------
def se_po(h2: float, n: np.ndarray, T: float) -> np.ndarray:
    s = T / (1 + n); t = h2 / 4; b = h2 / 2
    return 2 * np.sqrt((t + (1 - t) / n - b * b) / s)


def se_hs(h2: float, n: np.ndarray, T: float) -> np.ndarray:
    s = T / n; t = h2 / 4
    return 4 * np.sqrt(2 * (1 - t) ** 2 * (1 + (n - 1) * t) ** 2 / (n * (n - 1) * (s - 1)))


def nested_se(h2: float, d: float, k: float, T: float) -> tuple[float, float]:
    """返回 (SE(h²_S), SE(h²_SD))；delta 法，梯度对均方解析求得。"""
    s = T / (d * k)
    sS, sD, sW = h2 / 4, h2 / 4, 1 - h2 / 2
    E = np.array([sW + k * sD + d * k * sS, sW + k * sD, sW])
    df = np.array([s - 1, s * (d - 1), s * d * (k - 1)])
    V = 2 * E ** 2 / df
    # 组分对 (MS_S, MS_D, MS_W) 的雅可比
    J = np.array([[1 / (d * k), -1 / (d * k), 0], [0, 1 / k, -1 / k], [0, 0, 1]])
    VT = sS + sD + sW
    g_S = np.array([4 / VT - 4 * sS / VT ** 2, -4 * sS / VT ** 2, -4 * sS / VT ** 2]) @ J
    num = 2 * (sS + sD)
    g_SD = np.array([2 / VT - num / VT ** 2, 2 / VT - num / VT ** 2, -num / VT ** 2]) @ J
    return float(np.sqrt(g_S ** 2 @ V)), float(np.sqrt(g_SD ** 2 @ V))


# ---------------- 蒙特卡洛 ----------------
def mc_po(h2, s, n, reps, rng):
    a = rng.normal(0, np.sqrt(h2), (reps, s))
    x = a + rng.normal(0, np.sqrt(1 - h2), (reps, s))
    ybar = a / 2 + rng.normal(0, np.sqrt(1 - h2 / 4), (reps, s, n)).mean(2)
    xc = x - x.mean(1, keepdims=True)
    b = (xc * (ybar - ybar.mean(1, keepdims=True))).sum(1) / (xc ** 2).sum(1)
    return 2 * b


def mc_hs(h2, s, n, reps, rng):
    y = rng.normal(0, np.sqrt(h2 / 4), (reps, s, 1)) + rng.normal(0, np.sqrt(1 - h2 / 4), (reps, s, n))
    fm = y.mean(2); gm = fm.mean(1, keepdims=True)
    msb = n * ((fm - gm) ** 2).sum(1) / (s - 1)
    msw = ((y - fm[..., None]) ** 2).sum((1, 2)) / (s * (n - 1))
    sb = (msb - msw) / n
    return 4 * sb / (sb + msw)


def nested_anova_balanced(y: np.ndarray):
    """y 形状 (reps, s, d, k)；返回 (MS_S, MS_D, MS_W) 各为长度 reps 的数组。"""
    _, s, d, k = y.shape
    dm = y.mean(3); sm = dm.mean(2); gm = sm.mean(1)
    ms_s = d * k * ((sm - gm[:, None]) ** 2).sum(1) / (s - 1)
    ms_d = k * ((dm - sm[..., None]) ** 2).sum((1, 2)) / (s * (d - 1))
    ms_w = ((y - dm[..., None]) ** 2).sum((1, 2, 3)) / (s * d * (k - 1))
    return ms_s, ms_d, ms_w


def mc_nested(h2, s, d, k, reps, rng):
    y = (rng.normal(0, np.sqrt(h2 / 4), (reps, s, 1, 1)) + rng.normal(0, np.sqrt(h2 / 4), (reps, s, d, 1))
         + rng.normal(0, np.sqrt(1 - h2 / 2), (reps, s, d, k)))
    ms_s, ms_d, ms_w = nested_anova_balanced(y)
    sS = (ms_s - ms_d) / (d * k); sD = (ms_d - ms_w) / k; VT = sS + sD + ms_w
    return 4 * sS / VT, 2 * (sS + sD) / VT


def main():
    cfg = json.loads((HERE / "data" / "ex13_18_design.json").read_text(encoding="utf-8"))
    T = cfg["total_records"]; rng = np.random.default_rng(cfg["seed"]); mins = cfg["min_families"]
    out = {"T": T, "optimum": {}, "mc": {}}
    print(f"总测定记录 T = {T}（表型方差 = 1，V_D = V_Ec = 0）")
    print(f"{'h²':>5s} | {'亲子回归 n*':>10s}{'SE':>8s} | {'半同胞 n*':>9s}{'SE':>8s}{'4/h²':>7s} | "
          f"{'套式 h²_S (d,k)':>15s}{'SE':>8s} | {'套式 h²_SD (d,k)':>16s}{'SE':>8s}")
    curves = {}
    for h2 in cfg["h2_grid"]:
        n_po = np.arange(1, cfg["po_n_max"] + 1, dtype=float); n_po = n_po[T / (1 + n_po) >= mins]
        e_po = se_po(h2, n_po, T)
        n_hs = np.arange(2, cfg["hs_n_max"] + 1, dtype=float); n_hs = n_hs[T / n_hs >= mins]
        e_hs = se_hs(h2, n_hs, T)
        best_S = (np.inf, None); best_SD = (np.inf, None); grid = []
        for d in range(2, cfg["nested_d_max"] + 1):
            for k in range(2, cfg["nested_k_max"] + 1):
                if T / (d * k) < mins:
                    continue
                a, b = nested_se(h2, d, k, T); grid.append((d, k, a, b))
                if a < best_S[0]: best_S = (a, (d, k))
                if b < best_SD[0]: best_SD = (b, (d, k))
        i_po, i_hs = int(np.argmin(e_po)), int(np.argmin(e_hs))
        rec = {"po": {"n": int(n_po[i_po]), "se": float(e_po[i_po])},
               "hs": {"n": int(n_hs[i_hs]), "se": float(e_hs[i_hs]), "robertson_4_over_h2": 4 / h2},
               "nested_S": {"d": best_S[1][0], "k": best_S[1][1], "se": best_S[0]},
               "nested_SD": {"d": best_SD[1][0], "k": best_SD[1][1], "se": best_SD[0]}}
        out["optimum"][str(h2)] = rec; curves[h2] = (n_po, e_po, n_hs, e_hs, grid)
        print(f"{h2:5.2f} | {rec['po']['n']:10d}{rec['po']['se']:8.4f} | {rec['hs']['n']:9d}{rec['hs']['se']:8.4f}{4/h2:7.1f} | "
              f"{str(best_S[1]):>15s}{best_S[0]:8.4f} | {str(best_SD[1]):>16s}{best_SD[0]:8.4f}")
        # 核验：半同胞最优家系大小应接近 Robertson 的 1/t = 4/h²（同一数量级，误差 < 35%）
        assert abs(rec["hs"]["n"] - 4 / h2) / (4 / h2) < 0.35
        # 核验：k = 1 的单子代亲子回归公式与式 (13.1) 2√[(1 − b²)/N] 等价（此处 N = T/2）
        assert np.isclose(se_po(h2, np.array([1.0]), T)[0], 2 * np.sqrt((1 - (h2 / 2) ** 2) / (T / 2)))

    # 蒙特卡洛核验（h² = cfg["h2_mc"]）
    h2 = cfg["h2_mc"]; R = cfg["mc_reps"]; rec = out["optimum"][str(h2)]
    n = rec["po"]["n"]; s = int(round(T / (1 + n))); b = mc_po(h2, s, n, R, rng)
    a_po = float(se_po(h2, np.array([float(n)]), s * (1 + n))[0])
    n = rec["hs"]["n"]; s2 = int(round(T / n)); hs = mc_hs(h2, s2, n, R, rng)
    a_hs = float(se_hs(h2, np.array([float(n)]), s2 * n)[0])
    d, k = rec["nested_SD"]["d"], rec["nested_SD"]["k"]; s3 = int(round(T / (d * k)))
    hS, hSD = mc_nested(h2, s3, d, k, R, rng); a_S, a_SD = nested_se(h2, d, k, s3 * d * k)
    print(f"\n蒙特卡洛核验（h² = {h2}，{R} 次重复）：设计 | 结构 | 均值 | 模拟 SD | 近似 SE")
    rows = [("亲子回归", f"s={s}, n={rec['po']['n']}", b, a_po), ("半同胞", f"s={s2}, n={rec['hs']['n']}", hs, a_hs),
            ("套式 h²_S", f"s={s3}, d={d}, k={k}", hS, a_S), ("套式 h²_SD", f"s={s3}, d={d}, k={k}", hSD, a_SD)]
    for name, st, est, se_a in rows:
        sd = float(est.std(ddof=1)); m = float(est.mean())
        out["mc"][name] = {"structure": st, "mean": m, "sd": sd, "approx_se": se_a}
        print(f"  {name:<10s}{st:>22s}{m:8.4f}{sd:9.4f}{se_a:9.4f}")
        assert 0.8 < sd / se_a < 1.25, f"{name} 近似 SE 与模拟不符"
        assert abs(m - h2) < 4 * sd / np.sqrt(R) + 0.02, f"{name} 估计有偏"

    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex13_18_design_precision.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    from _plot import get_pyplot
    plt = get_pyplot()
    if plt is not None:
        n_po, e_po, n_hs, e_hs, grid = curves[h2]
        g = np.array(grid); fig, ax = plt.subplots(figsize=(6.4, 4))
        ax.plot(n_po, e_po, label="亲子回归（每公畜 n 个后代）")
        ax.plot(n_hs, e_hs, label="半同胞（家系大小 n）")
        for dd in (2, 4, 8):
            m = g[:, 0] == dd; ax.plot(g[m, 0] * g[m, 1], g[m, 3], "--", label=f"套式 h²_SD，d={dd}（n=dk）")
        ax.set_xscale("log"); ax.set_ylim(0, 0.25); ax.set_xlabel("每头公畜的后代数"); ax.set_ylabel("SE(ĥ²)")
        ax.set_title(f"T = {T}，h² = {h2}"); ax.legend(fontsize=8); fig.tight_layout()
        fig.savefig(HERE / "results" / "ex13_18_design_precision.png"); plt.close(fig)


if __name__ == "__main__":
    main()
