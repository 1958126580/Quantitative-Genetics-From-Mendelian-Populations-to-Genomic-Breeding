# 第13章　遗传参数的经典估计方法与试验设计——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex13_15_nested_anova.py
python3 ex13_16_parent_offspring_selection.py
python3 ex13_17_nc2_design.py
python3 ex13_18_design_precision.py
python3 ex13_19_genetic_correlation.py
python3 ex13_20_anova_vs_reml.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex13_15_nested_anova.py | 13.15 | 不平衡套式（公畜—母畜—后代）设计的方差分析估计与家系自助标准误 |
| ex13_16_parent_offspring_selection.py | 13.16 | 亲子回归对选择的稳健性：按亲本选择 vs 按后代选择 vs 只用双亲中值 |
| ex13_17_nc2_design.py | 13.17 | 北卡罗来纳设计 II（析因交配）：一般配合力、特殊配合力与显性方差的估计 |
| ex13_18_design_precision.py | 13.18 | 固定总测定数下三类设计的遗传力估计精度与最优家系大小 |
| ex13_19_genetic_correlation.py | 13.19 | 半同胞资料的两性状方差—协方差分析：遗传相关、Robertson 近似 SE 与公畜自助法 |
| ex13_20_anova_vs_reml.py | 13.20 | 不平衡套式资料：方差分析（Henderson 方法 I）与 REML 的蒙特卡洛比较 |
