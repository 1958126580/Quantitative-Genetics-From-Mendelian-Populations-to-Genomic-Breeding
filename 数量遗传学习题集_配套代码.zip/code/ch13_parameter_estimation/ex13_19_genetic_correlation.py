#!/usr/bin/env python3
"""习题 13.19  半同胞资料的两性状方差—协方差分析：遗传相关、Robertson 近似 SE 与公畜自助法

单因素随机公畜模型（向量形式）y_ij = μ + s_i + w_ij，Var(s) = Σ_S = G/4，Var(w) = Σ_W = 3G/4 + E。
以交叉乘积代替平方和（MANOVA/ANCOVA）：
    M_B = B/(s − 1)，M_W = W/(N − s)，n0 = [N − Σn_i²/N]/(s − 1)（不平衡家系的有效大小），
    Σ̂_S = (M_B − M_W)/n0，Ĝ = 4Σ̂_S，P̂ = Σ̂_S + Σ̂_W，Ê = P̂ − Ĝ，
    r̂_A = σ̂_SXY / √(σ̂_SX² σ̂_SY²)，
Robertson (1959) 近似：SE(r̂_A) ≈ (1 − r_A²)/√2 · √[SE(ĥ_X²)SE(ĥ_Y²)/(h_X² h_Y²)]。
标准误另用“整头公畜重抽样”的自助法估计，并以已知参数的蒙特卡洛模拟检验两种 SE。
核验：B + W = 总 SSCP；由“和性状”单变量方差分析间接求得的协方差组分与直接计算一致。
"""
from __future__ import annotations
import csv
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def read_data():
    sires, y = [], []
    with open(HERE / "data" / "ex13_19_halfsib_2trait.csv", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            sires.append(r["sire"]); y.append((float(r["backfat"]), float(r["litter_wt"])))
    ids = {s: i for i, s in enumerate(dict.fromkeys(sires))}
    return np.array([ids[s] for s in sires]), np.array(y)


def suff_stats(g: np.ndarray, y: np.ndarray):
    """每头公畜的 n_i、和向量 t_i、平方和交叉乘积矩阵 Q_i。"""
    s = g.max() + 1
    n = np.bincount(g, minlength=s).astype(float)
    t = np.zeros((s, 2)); np.add.at(t, g, y)
    Q = np.zeros((s, 2, 2)); np.add.at(Q, g, y[:, :, None] * y[:, None, :])
    return n, t, Q


def manova(n, t, Q):
    """n:(..., s)  t:(..., s, 2)  Q:(..., s, 2, 2)，可带前导批次维（自助法向量化）。"""
    s = n.shape[-1]; N = n.sum(-1)
    T = t.sum(-2)
    between_raw = (t[..., :, None] * t[..., None, :] / n[..., None, None]).sum(-3)
    B = between_raw - T[..., :, None] * T[..., None, :] / N[..., None, None]
    W = Q.sum(-3) - between_raw
    MB = B / (s - 1); MW = W / (N[..., None, None] - s)
    n0 = (N - (n ** 2).sum(-1) / N) / (s - 1)
    SS = (MB - MW) / n0[..., None, None]
    return SS, MW, n0


def params(SS, MW):
    G = 4 * SS; P = SS + MW; E = P - G
    h2 = np.diagonal(G, axis1=-2, axis2=-1) / np.diagonal(P, axis1=-2, axis2=-1)
    with np.errstate(invalid="ignore", divide="ignore"):
        rA = G[..., 0, 1] / np.sqrt(G[..., 0, 0] * G[..., 1, 1])
        rP = P[..., 0, 1] / np.sqrt(P[..., 0, 0] * P[..., 1, 1])
        rE = E[..., 0, 1] / np.sqrt(E[..., 0, 0] * E[..., 1, 1])
    return G, P, E, h2, rA, rP, rE


def oneway_component(g: np.ndarray, x: np.ndarray) -> float:
    """独立的单变量单因素方差分析（逐家系循环实现），返回公畜方差组分。"""
    fams = [x[g == i] for i in range(g.max() + 1)]; N = len(x); s = len(fams); gm = x.mean()
    ssb = sum(len(f) * (f.mean() - gm) ** 2 for f in fams); ssw = sum(((f - f.mean()) ** 2).sum() for f in fams)
    n0 = (N - sum(len(f) ** 2 for f in fams) / N) / (s - 1)
    return (ssb / (s - 1) - ssw / (N - s)) / n0


def robertson_se(h2, rA, n0, s):
    t = h2 / 4
    se_t = np.sqrt(2 * (1 - t) ** 2 * (1 + (n0 - 1) * t) ** 2 / (n0 * (n0 - 1) * (s - 1)))
    se_h2 = 4 * se_t
    return se_h2, (1 - rA ** 2) / np.sqrt(2) * np.sqrt(se_h2[0] * se_h2[1] / (h2[0] * h2[1]))


def bootstrap(n, t, Q, B, rng):
    idx = rng.integers(0, len(n), (B, len(n)))
    SS, MW, _ = manova(n[idx], t[idx], Q[idx])
    return params(SS, MW)


def true_matrices(cfg):
    sd = np.array(cfg["sd_P"]); h2 = np.array(cfg["h2"]); sa = np.sqrt(h2) * sd; se = np.sqrt(1 - h2) * sd
    G = np.array([[sa[0] ** 2, cfg["rA"] * sa[0] * sa[1]], [cfg["rA"] * sa[0] * sa[1], sa[1] ** 2]])
    E = np.array([[se[0] ** 2, cfg["rE"] * se[0] * se[1]], [cfg["rE"] * se[0] * se[1], se[1] ** 2]])
    return G, E


def main():
    cfg = json.loads((HERE / "data" / "ex13_19_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    g, y = read_data(); n, t, Q = suff_stats(g, y); s = len(n); N = int(n.sum())
    SS, MW, n0 = manova(n, t, Q); G, P, E, h2, rA, rP, rE = params(SS, MW)

    # 核验 1：B + W = 总 SSCP
    yc = y - y.mean(0)
    Bm = (SS * n0 + MW) * (s - 1); Wm = MW * (N - s)
    assert np.allclose(Bm + Wm, yc.T @ yc)
    # 核验 2：和性状法求协方差组分
    cov_sum = (oneway_component(g, y[:, 0] + y[:, 1]) - oneway_component(g, y[:, 0]) - oneway_component(g, y[:, 1])) / 2
    assert np.isclose(cov_sum, SS[0, 1])

    se_h2_rob, se_rA_rob = robertson_se(h2, rA, n0, s)
    Gb, Pb, Eb, h2b, rAb, rPb, rEb = bootstrap(n, t, Q, cfg["B"], rng)
    ok = np.isfinite(rAb)
    names = cfg["traits"]
    print(f"{s} 头公畜，N = {N} 个半同胞后代，有效家系大小 n0 = {n0:.2f}")
    print("公畜间与公畜内均方—均积矩阵：")
    print(f"  M_B = {np.round(SS * n0 + MW, 3).tolist()}\n  M_W = {np.round(MW, 3).tolist()}")
    print(f"{'参数':<16s}{'估计':>9s}{'Robertson SE':>14s}{'自助 SE':>9s}{'自助 95% 区间':>20s}")
    rows = [(f"h² {names[0]}", h2[0], se_h2_rob[0], h2b[:, 0]), (f"h² {names[1]}", h2[1], se_h2_rob[1], h2b[:, 1]),
            ("r_A", rA, se_rA_rob, rAb[ok]), ("r_P", rP, np.nan, rPb), ("r_E", rE, np.nan, rEb[np.isfinite(rEb)])]
    out = {"n_sires": s, "N": N, "n0": float(n0), "G": G.tolist(), "P": P.tolist(), "E": E.tolist(), "est": {}}
    for name, est, rse, bs in rows:
        lo, hi = np.quantile(bs, [0.025, 0.975])
        out["est"][name] = {"est": float(est), "se_robertson": None if np.isnan(rse) else float(rse),
                            "se_boot": float(bs.std(ddof=1)), "ci95": [float(lo), float(hi)]}
        rs = "—" if np.isnan(rse) else f"{rse:.4f}"
        print(f"{name:<16s}{est:9.4f}{rs:>14s}{bs.std(ddof=1):9.4f}{f'[{lo:.3f}, {hi:.3f}]':>20s}")
    print(f"自助样本中 |r̂_A| > 1 的比例：{np.mean(np.abs(rAb[ok]) > 1):.3f}")

    # 蒙特卡洛：已知参数、相同家系结构
    Gt, Et = true_matrices(cfg); St = Gt / 4; Wt = 0.75 * Gt + Et
    Ls, Lw = np.linalg.cholesky(St), np.linalg.cholesky(Wt)
    mc_r, mc_bse, notpd = [], [], 0
    for _ in range(cfg["mc_reps"]):
        ys = (rng.standard_normal((s, 2)) @ Ls.T)[g] + rng.standard_normal((N, 2)) @ Lw.T
        n_, t_, Q_ = suff_stats(g, ys); SS_, MW_, _ = manova(n_, t_, Q_)
        G_, *_r = params(SS_, MW_); r_ = _r[3]
        notpd += np.linalg.eigvalsh(G_)[0] <= 0
        mc_r.append(r_)
        rb = bootstrap(n_, t_, Q_, cfg["mc_B"], rng)[4]; mc_bse.append(np.nanstd(rb, ddof=1))
    mc_r = np.array(mc_r); fin = np.isfinite(mc_r)
    h2t = np.array(cfg["h2"]); _, rse_true = robertson_se(h2t, cfg["rA"], n0, s)
    mc = {"rA_true": cfg["rA"], "mean": float(mc_r[fin].mean()), "sd": float(mc_r[fin].std(ddof=1)),
          "mean_boot_se": float(np.mean(mc_bse)), "robertson_se_at_truth": float(rse_true),
          "frac_G_not_pd": notpd / cfg["mc_reps"], "frac_abs_gt1": float(np.mean(np.abs(mc_r[fin]) > 1))}
    out["mc"] = mc
    print(f"\n蒙特卡洛（{cfg['mc_reps']} 次，真 r_A = {cfg['rA']}）：r̂_A 均值 {mc['mean']:.4f}，SD {mc['sd']:.4f}；"
          f"平均自助 SE {mc['mean_boot_se']:.4f}；真值处 Robertson SE {rse_true:.4f}；"
          f"Ĝ 非正定比例 {mc['frac_G_not_pd']:.3f}")
    assert 0.7 < mc["mean_boot_se"] / mc["sd"] < 1.4
    assert abs(mc["mean"] - cfg["rA"]) < 0.1

    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex13_19_genetic_correlation.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    from _plot import get_pyplot
    plt = get_pyplot()
    if plt is not None:
        fig, ax = plt.subplots(figsize=(6, 3.6))
        ax.hist(rAb[ok], bins=40, alpha=0.6, density=True, label="资料的公畜自助分布")
        ax.hist(mc_r[fin], bins=40, alpha=0.6, density=True, label="已知参数的蒙特卡洛分布")
        ax.axvline(cfg["rA"], color="k", ls="--", label="真值"); ax.axvline(rA, color="C3", label="资料估计")
        ax.set_xlabel("r̂_A"); ax.legend(fontsize=8); fig.tight_layout()
        fig.savefig(HERE / "results" / "ex13_19_genetic_correlation.png"); plt.close(fig)


if __name__ == "__main__":
    main()
