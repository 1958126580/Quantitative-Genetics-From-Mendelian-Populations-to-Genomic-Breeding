#!/usr/bin/env python3
"""习题 13.15  不平衡套式（公畜—母畜—后代）设计的方差分析估计与家系自助标准误

模拟 40 头公畜，每头配 3—5 头母畜，每窝 4—8 个后代（随机不平衡）。因果组分：
    σ_S² = V_A/4，σ_D² = V_A/4 + V_D/4 + V_Ec，σ_W² = V_A/2 + 3V_D/4 + V_Ew
不平衡资料的期望均方系数（Henderson 方法 I / Sokal–Rohlf 的 k 系数）：
    E(MS_S) = σ_W² + k2 σ_D² + k3 σ_S²，E(MS_D) = σ_W² + k1 σ_D²，E(MS_W) = σ_W²
程序计算 k1、k2、k3，解出三个观察组分，给出公畜组分、母畜组分与合并组分遗传力，
并以“按公畜整体重抽样”的自助法求标准误。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    VA, VD, VEc, VEw = cfg["VA"], cfg["VD"], cfg["VEc"], cfg["VEw"]
    s2s, s2d, s2w = VA / 4, VA / 4 + VD / 4 + VEc, VA / 2 + 0.75 * VD + VEw
    data = []
    for _ in range(cfg["n_sires"]):
        s = rng.normal(0, np.sqrt(s2s)); fam = []
        for _ in range(rng.choice(cfg["dams_per_sire"])):
            d = rng.normal(0, np.sqrt(s2d)); n = rng.choice(cfg["offspring_per_dam"])
            fam.append(s + d + rng.normal(0, np.sqrt(s2w), n))
        data.append(fam)
    return data, (s2s, s2d, s2w)


def anova(data):
    y = np.concatenate([np.concatenate(f) for f in data]); N = len(y); gm = y.mean()
    S = len(data); D = sum(len(f) for f in data)
    nij = [[len(x) for x in f] for f in data]; ni = np.array([sum(r) for r in nij])
    ss_s = sum(n * (np.concatenate(f).mean() - gm) ** 2 for f, n in zip(data, ni))
    ss_d = sum(len(x) * (x.mean() - np.concatenate(f).mean()) ** 2 for f in data for x in f)
    ss_w = sum(((x - x.mean()) ** 2).sum() for f in data for x in f)
    df_s, df_d, df_w = S - 1, D - S, N - D
    ms_s, ms_d, ms_w = ss_s / df_s, ss_d / df_d, ss_w / df_w
    sum_nij2_over_ni = sum(sum(n * n for n in r) / sum(r) for r in nij); sum_nij2 = sum(n * n for r in nij for n in r)
    k1 = (N - sum_nij2_over_ni) / df_d
    k2 = (sum_nij2_over_ni - sum_nij2 / N) / df_s
    k3 = (N - np.sum(ni ** 2) / N) / df_s
    s2w = ms_w; s2d = (ms_d - ms_w) / k1; s2s = (ms_s - ms_w - k2 * s2d) / k3
    VP = s2s + s2d + s2w
    return dict(N=N, ms=(ms_s, ms_d, ms_w), k=(k1, k2, k3), comp=(s2s, s2d, s2w), h2_S=4 * s2s / VP, h2_D=4 * s2d / VP, h2_SD=2 * (s2s + s2d) / VP)


def main():
    cfg = json.loads((HERE / "data" / "ex13_15_nested.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"]); data, true = simulate(cfg, rng); r = anova(data)
    VPt = sum(true); print(f"真实观察组分 σS², σD², σW² = {np.round(true,4)}；真 h² = {cfg['VA']/VPt:.3f}，"
                           f"母畜组分“遗传力” 4σD²/VP = {4*true[1]/VPt:.3f}")
    print(f"N = {r['N']}，k1 = {r['k'][0]:.3f}，k2 = {r['k'][1]:.3f}，k3 = {r['k'][2]:.3f}")
    print(f"MS_S = {r['ms'][0]:.4f}，MS_D = {r['ms'][1]:.4f}，MS_W = {r['ms'][2]:.4f}")
    print(f"估计 σS² = {r['comp'][0]:.4f}，σD² = {r['comp'][1]:.4f}，σW² = {r['comp'][2]:.4f}")
    bs = np.array([[anova([data[i] for i in rng.integers(0, len(data), len(data))])[k] for k in ("h2_S", "h2_D", "h2_SD")] for _ in range(cfg["B"])])
    se = bs.std(0, ddof=1)
    for k, s in zip(("h2_S", "h2_D", "h2_SD"), se): print(f"  {k} = {r[k]:.4f}（公畜自助 SE {s:.4f}）")
    # 核验：平衡资料时 k1 = k2 = k、k3 = dk，且 σ̂ 与平衡公式 (13.3) 一致
    bal = [[np.arange(6.0) + 10 * i + j for j in range(4)] for i in range(5)]
    rb = anova(bal); assert np.allclose(rb["k"], (6, 6, 24))
    ms_s, ms_d, ms_w = rb["ms"]; assert np.allclose(rb["comp"], ((ms_s - ms_d) / 24, (ms_d - ms_w) / 6, ms_w))
    out = {k: (list(v) if isinstance(v, tuple) else v) for k, v in r.items()}; out["se_boot"] = se.tolist(); out["true_components"] = list(true)
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex13_15_nested_anova.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
