#!/usr/bin/env python3
"""运行全部（或指定章的）习题程序，报告成功与否及用时。

用法：
    python3 run_all.py              # 运行全部章
    python3 run_all.py 5 12 37      # 只运行第 5、12、37 章
    python3 run_all.py -j 4         # 4 个进程并行
"""
import subprocess, sys, time, re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parent

def run_one(p):
    t0 = time.time()
    try:
        r = subprocess.run([sys.executable, p.name], cwd=p.parent, capture_output=True, text=True, timeout=300)
        ok, msg = r.returncode == 0, (r.stderr or r.stdout)[-300:]
    except subprocess.TimeoutExpired:
        ok, msg = False, '超时（>300 s）'
    return p, ok, time.time() - t0, msg

def main(argv):
    jobs, chs = 1, []
    i = 0
    while i < len(argv):
        if argv[i] == '-j':
            jobs = int(argv[i + 1]); i += 2
        else:
            chs.append(int(argv[i])); i += 1
    progs = []
    for d in sorted(ROOT.glob('ch*_*')):
        n = int(d.name[2:4])
        if chs and n not in chs:
            continue
        progs += sorted(d.glob('ex*.py'))
    t0 = time.time(); bad = []
    with ThreadPoolExecutor(jobs) as ex:
        for p, ok, dt, msg in ex.map(run_one, progs):
            print(f"{'通过' if ok else '失败'}  {p.parent.name}/{p.name}  {dt:5.1f}s", flush=True)
            if not ok:
                bad.append((p, msg)); print(msg)
    print(f'\n共 {len(progs)} 个程序，失败 {len(bad)} 个，总用时 {time.time() - t0:.0f} s')
    return 1 if bad else 0

if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
