#!/usr/bin/env python3
"""习题 24.19  病例富集抽样下的风险预测：截距平移、加权校准与 AUC 不变性

总体：logit P(y=1|g) = β0 + β1 g，g~N(0,1)（标准化多基因评分），发病率约 2%。
抽样：保留全部病例，并按 1:k 抽取对照（k∈{1,2,5,10}）。抽样与 y 有关、与 g 无关（条件于 y），
理论：富集样本中 logit 的截距平移 Δ = log(s1/s0)，斜率 β1 不变；AUC 只依赖 g 对 y 的排序，不变。
方法：自写牛顿法拟合（普通与逆概率加权）；在独立总体留出集上评价校准（总体平均预测 vs 观测发病率；校准截距、斜率）和 AUC。
核验：(1) 估计的截距平移与 log(s1/s0) 相差 < 3 个标准误；(2) 加权估计恢复 β0；(3) 各 k 的 AUC 彼此差 < 0.004；
      (4) 未校正模型在总体上高估风险（校准截距为负），校正后校准截距≈0（|·|<0.1）；(5) 精度（β1 的标准误）随 k 增大而下降并趋于平台。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def logit_fit(g, y, w=None, iters=50):
    n = len(y); X = np.column_stack([np.ones(n), g]); w = np.ones(n) if w is None else w
    b = np.zeros(2)
    for _ in range(iters):
        p = 1 / (1 + np.exp(-X @ b))
        W = w * p * (1 - p)
        H = X.T @ (X * W[:, None]); gr = X.T @ (w * (y - p))
        step = np.linalg.solve(H, gr); b += step
        if np.abs(step).max() < 1e-10:
            break
    p = 1 / (1 + np.exp(-X @ b))
    # 稳健（三明治）方差，对加权同样有效
    U = X * (w * (y - p))[:, None]
    Hinv = np.linalg.inv(X.T @ (X * (w * p * (1 - p))[:, None]))
    V = Hinv @ (U.T @ U) @ Hinv
    return b, np.sqrt(np.diag(V))


def auc(score, y):
    r = np.empty(len(y)); order = np.argsort(score, kind="mergesort"); r[order] = np.arange(1, len(y) + 1)
    n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)


def calib(pred_logit, y):
    """校准截距（斜率固定 1 的偏移）与校准斜率。"""
    # 截距：offset 模型
    a = 0.0
    for _ in range(50):
        p = 1 / (1 + np.exp(-(pred_logit + a)))
        a += (y - p).sum() / (p * (1 - p)).sum()
    b, _ = logit_fit(pred_logit, y)
    return a, b[1]


def main():
    cfg = json.load(open(HERE / "data" / "ex24_19_enrich.json"))
    rng = np.random.default_rng(cfg["seed"])
    N = cfg["N"]; b0, b1 = cfg["beta0"], cfg["beta1"]
    g = rng.standard_normal(N); p = 1 / (1 + np.exp(-(b0 + b1 * g))); y = (rng.random(N) < p).astype(float)
    gh = rng.standard_normal(cfg["n_holdout"]); yh = (rng.random(cfg["n_holdout"]) < 1 / (1 + np.exp(-(b0 + b1 * gh)))).astype(float)
    prev = y.mean(); n1 = int(y.sum())
    print("=" * 78)
    print(f"习题 24.19  病例富集抽样：总体 N={N}，发病率 {prev:.4f}，病例 {n1}；真 β0={b0}, β1={b1}")
    print("=" * 78)
    print(f"{'k':>3} {'n':>7} {'β0*':>8} {'SE':>6} {'Δ估计':>7} {'log(s1/s0)':>11} {'β1':>6} {'SE':>6} {'加权β0':>8} {'AUC':>6} {'未校正截距':>10} {'校正后':>7} {'斜率':>6}")
    rows = []; aucs = []; ses = []
    cases = np.where(y == 1)[0]; ctrl = np.where(y == 0)[0]
    for k in cfg["control_ratios"]:
        nc = min(k * n1, len(ctrl))
        idx_c = rng.choice(ctrl, nc, replace=False)
        idx = np.concatenate([cases, idx_c]); gs, ys = g[idx], y[idx]
        s1 = 1.0; s0 = nc / len(ctrl)
        wts = np.where(ys == 1, 1 / s1, 1 / s0)
        b, se = logit_fit(gs, ys)
        bw, sew = logit_fit(gs, ys, wts)
        delta = b[0] - b0; delta_th = np.log(s1 / s0)
        a_raw, sl_raw = calib(b[0] + b[1] * gh, yh)       # 未校正：直接用富集样本的截距
        a_cor, sl_cor = calib(b[0] - delta_th + b[1] * gh, yh)  # 理论校正：截距减 log(s1/s0)
        A = auc(gs, ys); A_h = auc(gh, yh); aucs.append(A_h); ses.append(se[1])
        print(f"{k:>3} {len(ys):>7} {b[0]:>8.3f} {se[0]:>6.3f} {delta:>7.3f} {delta_th:>11.3f} {b[1]:>6.3f} {se[1]:>6.3f} {bw[0]:>8.3f} {A_h:>6.4f} {a_raw:>10.3f} {a_cor:>7.3f} {sl_cor:>6.3f}")
        assert abs(delta - delta_th) < 3 * se[0], (k, delta, delta_th, se[0])
        assert abs(bw[0] - b0) < 3 * sew[0] + 0.05, (k, bw[0])
        assert a_raw < -1.0 and abs(a_cor) < 0.1, (a_raw, a_cor)
        rows.append(dict(k=k, n=int(len(ys)), beta0_star=float(b[0]), se0=float(se[0]), beta1=float(b[1]), se1=float(se[1]),
                         delta_hat=float(delta), delta_theory=float(delta_th), beta0_weighted=float(bw[0]), auc_holdout=float(A_h),
                         calib_int_raw=float(a_raw), calib_int_corrected=float(a_cor), calib_slope=float(sl_cor)))
    assert max(aucs) - min(aucs) < 0.004, aucs
    assert ses[0] > ses[1] > ses[2] > ses[3] * 0.999, ses
    gain_last = (ses[2] - ses[3]) / ses[2]; gain_first = (ses[0] - ses[1]) / ses[0]
    print(f"\n各 k 的留出 AUC 极差 {max(aucs)-min(aucs):.4f}；β1 标准误依次 {', '.join(f'{s:.3f}' for s in ses)}（边际收益递减：k 1→2 降 {gain_first:.1%}，5→10 降 {gain_last:.1%}）")
    assert gain_last < gain_first
    json.dump(dict(prevalence=float(prev), rows=rows), open(HERE / "results" / "ex24_19_case_control_enrichment.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
