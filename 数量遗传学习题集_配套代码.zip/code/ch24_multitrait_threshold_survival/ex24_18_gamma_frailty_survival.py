#!/usr/bin/env python3
"""习题 24.18  伽马脆弱性（frailty）生存模型：右删失 + 左截断下的种公牛“长寿”评定

模型：女儿 j（种公牛 i 的后代）的风险 h_ij(t) = w_i · λ0 · exp(β x_ij)，指数基线；w_i ~ Gamma(shape=1/θ, rate=1/θ)（均值 1、方差 θ）。
资料：随机进入时刻（左截断：只有活到进入时刻者才被观测）、随机行政删失。
解析：边缘似然（积分掉 w_i）
      L_i = Π_j (λ_ij)^{δ_ij} · Γ(1/θ+d_i)/Γ(1/θ) · θ^{d_i} · (1+θ H_i)^{-(1/θ+d_i)}，  H_i=Σ_j λ_ij (t_ij − entry_ij)，
      后验脆弱性均值 E[w_i|data] = (1/θ + d_i)/(1/θ + H_i)。
比较：(a) 脆弱性模型 MLE（含截断处理）；(b) 忽略左截断（把暴露从 0 起算）；(c) 朴素排序 d_i/Σ暴露（不含协变量、不收缩）。
核验：(1) 边缘似然与数值积分一致；(2) MLE 处解析梯度≈0（数值梯度）；(3) θ=0 的似然比检验显著；
      (4) 后验脆弱性对真 w 的相关 ≥ 朴素排序；(5) 忽略截断使 λ0 估计偏低。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from scipy.special import gammaln
from scipy.integrate import quad
from scipy.stats import gamma as gamma_dist, chi2

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    S, m = cfg["n_sires"], cfg["daughters"]
    th = cfg["theta"]
    w = rng.gamma(1 / th, th, S)
    ids, X, ent, tim, dlt = [], [], [], [], []
    for i in range(S):
        got = 0
        while got < m:
            x = rng.integers(0, 2)
            e = rng.uniform(0, cfg["entry_max"])
            rate = w[i] * cfg["lambda0"] * np.exp(cfg["beta"] * x)
            T = rng.exponential(1 / rate)
            if T <= e:       # 在进入前已死亡：不被观测（左截断）
                continue
            c = e + rng.uniform(*cfg["cens_range"]) * rng.uniform(0.4, 1.0)
            ids.append(i); X.append(x); ent.append(e)
            tim.append(min(T, c)); dlt.append(1.0 if T <= c else 0.0); got += 1
    return w, np.array(ids), np.array(X, float), np.array(ent), np.array(tim), np.array(dlt)


def negll(par, ids, X, ent, tim, dlt, S, truncation=True, th_fixed=None):
    ll0, b = par[0], par[1]
    th = th_fixed if th_fixed is not None else np.exp(par[2])
    lam = np.exp(ll0 + b * X)
    expo = tim - (ent if truncation else 0.0)
    H = np.bincount(ids, lam * expo, S); d = np.bincount(ids, dlt, S)
    ll = (dlt * (ll0 + b * X)).sum()
    if th <= 1e-8:
        return -(ll - (d * np.log(np.maximum(H, 1e-300))).sum() * 0 - H.sum())
    k = 1 / th
    ll += (gammaln(k + d) - gammaln(k) + d * np.log(th) - (k + d) * np.log1p(th * H)).sum()
    return -ll


def fit(ids, X, ent, tim, dlt, S, truncation=True):
    r = minimize(negll, [np.log(0.1), 0.0, np.log(0.3)], args=(ids, X, ent, tim, dlt, S, truncation), method="Nelder-Mead",
                 options=dict(xatol=1e-7, fatol=1e-9, maxiter=4000))
    r2 = minimize(negll, r.x, args=(ids, X, ent, tim, dlt, S, truncation), method="BFGS")
    return r2 if r2.fun <= r.fun + 1e-9 else r


def post_w(par, ids, X, ent, tim, dlt, S, truncation=True):
    th = np.exp(par[2]); lam = np.exp(par[0] + par[1] * X)
    H = np.bincount(ids, lam * (tim - (ent if truncation else 0)), S); d = np.bincount(ids, dlt, S)
    return (1 / th + d) / (1 / th + H)


def main():
    cfg = json.load(open(HERE / "data" / "ex24_18_frailty.json"))
    rng = np.random.default_rng(cfg["seed"]); S = cfg["n_sires"]
    w, ids, X, ent, tim, dlt = simulate(cfg, rng)
    # (1) 边缘似然数值积分核验（取第 0 个家系）
    th, lam0, b = cfg["theta"], cfg["lambda0"], cfg["beta"]
    m0 = ids == 0
    lam = lam0 * np.exp(b * X[m0]); expo = tim[m0] - ent[m0]; d0 = dlt[m0].sum()
    integrand = lambda u: gamma_dist.pdf(u, 1 / th, scale=th) * np.exp(d0 * np.log(u) - u * (lam * expo).sum())
    L_num = np.log(quad(integrand, 0, np.inf)[0]) + (dlt[m0] * np.log(lam)).sum()
    par_true = [np.log(lam0), b, np.log(th)]
    # 只取该家系的 negll
    L_closed = -negll(par_true, np.zeros(m0.sum(), int), X[m0], ent[m0], tim[m0], dlt[m0], 1)
    # (2) 拟合
    res = fit(ids, X, ent, tim, dlt, S)
    par = res.x
    r_naive = fit(ids, X, ent, tim, dlt, S, truncation=False)
    # 数值梯度
    eps = 1e-5; g = np.array([(negll(par + eps * np.eye(3)[k], ids, X, ent, tim, dlt, S) - negll(par - eps * np.eye(3)[k], ids, X, ent, tim, dlt, S)) / (2 * eps) for k in range(3)])
    # (3) θ=0 LRT（θ=0 取极限：指数模型）
    r0 = minimize(lambda p: negll([p[0], p[1], 0], ids, X, ent, tim, dlt, S, True, th_fixed=1e-12), [np.log(0.1), 0.0], method="Nelder-Mead")
    lrt = 2 * (r0.fun - res.fun); pval = 0.5 * chi2.sf(lrt, 1)
    # 评定
    wh = post_w(par, ids, X, ent, tim, dlt, S)
    d = np.bincount(ids, dlt, S); expo_s = np.bincount(ids, tim - ent, S)
    naive = d / expo_s
    c_post = np.corrcoef(wh, w)[0, 1]; c_naive = np.corrcoef(naive, w)[0, 1]
    # 重复
    cp, cn, lam_hat, lam_nt = [], [], [], []
    for k in range(cfg["n_rep"]):
        r2 = np.random.default_rng(cfg["seed"] + 1 + k)
        w2, i2, X2, e2, t2, d2 = simulate(cfg, r2)
        f = fit(i2, X2, e2, t2, d2, S); fn = fit(i2, X2, e2, t2, d2, S, truncation=False)
        cp.append(np.corrcoef(post_w(f.x, i2, X2, e2, t2, d2, S), w2)[0, 1])
        dd = np.bincount(i2, d2, S); ee = np.bincount(i2, t2 - e2, S)
        cn.append(np.corrcoef(dd / ee, w2)[0, 1])
        lam_hat.append(np.exp(f.x[0])); lam_nt.append(np.exp(fn.x[0]))
    print("=" * 78)
    print(f"习题 24.18  伽马脆弱性生存模型：{S} 头公牛 × {cfg['daughters']} 女儿，事件比例 {dlt.mean():.2f}")
    print("=" * 78)
    print(f"边缘似然：闭式 {L_closed:.6f}  数值积分 {L_num:.6f}  差 {abs(L_closed - L_num):.2e}")
    print(f"MLE：λ0={np.exp(par[0]):.4f}（真 {lam0}），β={par[1]:.3f}（真 {b}），θ={np.exp(par[2]):.3f}（真 {th}）；梯度范数 {np.linalg.norm(g):.2e}")
    print(f"忽略左截断：λ0={np.exp(r_naive.x[0]):.4f}，β={r_naive.x[1]:.3f}，θ={np.exp(r_naive.x[2]):.3f}")
    print(f"θ=0 的似然比 {lrt:.1f}，p≈{pval:.2e}")
    print(f"单次资料：后验脆弱性对真 w 相关 {c_post:.3f}；朴素 d/暴露 {c_naive:.3f}；后验均值 {wh.mean():.3f}")
    print(f"{cfg['n_rep']} 次重复：后验相关 {np.mean(cp):.3f}，朴素 {np.mean(cn):.3f}；λ0 估计均值 含截断 {np.mean(lam_hat):.4f}，忽略截断 {np.mean(lam_nt):.4f}（真 {lam0}）")
    assert abs(L_closed - L_num) < 1e-6
    assert np.linalg.norm(g) < 0.5, g
    assert pval < 1e-3
    assert np.mean(cp) >= np.mean(cn) - 1e-3
    assert np.mean(lam_nt) < np.mean(lam_hat)
    assert abs(np.mean(lam_hat) - lam0) / lam0 < 0.15
    out = dict(L_closed=float(L_closed), L_num=float(L_num), mle=dict(lambda0=float(np.exp(par[0])), beta=float(par[1]), theta=float(np.exp(par[2]))),
               ignore_truncation=dict(lambda0=float(np.exp(r_naive.x[0])), beta=float(r_naive.x[1]), theta=float(np.exp(r_naive.x[2]))),
               lrt=float(lrt), corr_posterior=float(c_post), corr_naive=float(c_naive),
               rep=dict(corr_post=float(np.mean(cp)), corr_naive=float(np.mean(cn)), lam_with=float(np.mean(lam_hat)), lam_without=float(np.mean(lam_nt))))
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex24_18_gamma_frailty_survival.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
