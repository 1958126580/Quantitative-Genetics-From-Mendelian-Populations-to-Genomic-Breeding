#!/usr/bin/env python3
"""习题 24.20  二性状选择指数的可靠度曲面：什么时候“相关性状”真正有用

目标：性状 1 的个体育种值 a_1。设 h²=(h1²,h2²)，遗传相关 r_g，环境（残差）相关 r_e；总表型方差各为 1。
信息来源（均为候选个体）：
  D1 仅有自身性状 1 记录；
  D2 仅有自身性状 2 记录；
  D3 自身两性状记录；
  D4 自身性状 1 记录 + n 个全同胞的性状 2 平均记录（同胞间 a 相关 ½，残差不相关）。
公式：可靠度 R² = c' P_I⁻¹ c / G11，c = Cov(I, a_1)，P_I = Var(I)。
结论检验：
  (1) r_g=0, r_e=0 时，D3 的可靠度等于 D1（性状 2 无用）；
  (2) 在 r_e = r_e* := r_g·(h2/e2)·(e1/h1) 这条线上（e=√(1−h²)），性状 2 对 D3 的边际贡献恰为 0——
      即遗传相关与残差相关“同比例”时，第二性状不提供额外信息；
  (3) 远离该线时增益为正，且 r_e 与 r_g 反号时增益最大；
  (4) D2 的可靠度闭式 = r_g²·h2²（总表型方差为 1 时），随 |r_g| 单调增；
  (5) 蒙特卡罗（线性回归预测 EBV 的相关平方）在 3 个格点与解析一致。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def mats(h2, rg, re):
    h1, h2_ = h2
    e1, e2 = 1 - h1, 1 - h2_
    G = np.array([[h1, rg * np.sqrt(h1 * h2_)], [rg * np.sqrt(h1 * h2_), h2_]])
    E = np.array([[e1, re * np.sqrt(e1 * e2)], [re * np.sqrt(e1 * e2), e2]])
    return G, E


def rel(h2, rg, re, design, nsib=20):
    G, E = mats(h2, rg, re); P = G + E
    if design == "D1":
        idx = [0]; Pi = P[np.ix_(idx, idx)]; c = G[idx, 0]
    elif design == "D2":
        idx = [1]; Pi = P[np.ix_(idx, idx)]; c = G[idx, 0]
    elif design == "D3":
        Pi = P; c = G[:, 0]
    elif design == "D4":
        # I = (y_own1, mean_fs2)；Var(mean_fs2)=(1/n)P22 + (1-1/n)·(1/2)G22 ... 全同胞：a 相关 1/2；残差独立
        n = nsib
        # 注意：同胞 a 之间的协方差 = 0.5·G22（相加性）；个体自身 a 与同胞 y2 的 a 协方差 0.5·G12
        v_m = (G[1, 1] / n) * (1 + 0.5 * (n - 1)) + E[1, 1] / n
        cov_own_m = 0.5 * P[0, 1] * 0 + 0.5 * G[0, 1]      # 自身 y1 与同胞 y2：仅通过 a（0.5·G12），残差独立
        Pi = np.array([[P[0, 0], cov_own_m], [cov_own_m, v_m]])
        c = np.array([G[0, 0], 0.5 * G[0, 1]])
    else:
        raise ValueError(design)
    return float(c @ np.linalg.solve(Pi, c) / G[0, 0])


def mc_check(h2, rg, re, n, rng, nsib=20):
    """蒙特卡罗：模拟候选 + nsib 同胞（全同胞，亲本 a 之间 0.5 共享），线性回归得 EBV，比较 R²。"""
    G, E = mats(h2, rg, re); LG = np.linalg.cholesky(G); LE = np.linalg.cholesky(E)
    # 共同 midparent 成分（方差 ½G）+ 各自 Mendelian 抽样（½G）
    mp = rng.standard_normal((n, 2)) @ (np.sqrt(0.5) * LG).T
    own_a = mp + rng.standard_normal((n, 2)) @ (np.sqrt(0.5) * LG).T
    sib_a = mp[:, None, :] + rng.standard_normal((n, nsib, 2)) @ (np.sqrt(0.5) * LG).T
    own_e = rng.standard_normal((n, 2)) @ LE.T; sib_e = rng.standard_normal((n, nsib, 2)) @ LE.T
    y = own_a + own_e; ys = sib_a + sib_e
    target = own_a[:, 0]
    out = {}
    def r2(X):
        X1 = np.column_stack([np.ones(n), X]); b = np.linalg.lstsq(X1, target, rcond=None)[0]
        return np.corrcoef(X1 @ b, target)[0, 1] ** 2
    out["D1"] = r2(y[:, [0]]); out["D2"] = r2(y[:, [1]]); out["D3"] = r2(y)
    out["D4"] = r2(np.column_stack([y[:, 0], ys[:, :, 1].mean(1)]))
    return out


def main():
    cfg = json.load(open(HERE / "data" / "ex24_20_reliability.json"))
    rng = np.random.default_rng(cfg["seed"]); h2 = cfg["h2"]; grid = cfg["grid"]; ns = cfg["n_sibs"]
    h1, h2b = h2; e1, e2 = 1 - h1, 1 - h2b
    # (1)
    r1 = rel(h2, 0, 0, "D1"); r3 = rel(h2, 0, 0, "D3")
    assert abs(r1 - h1) < 1e-12 and abs(r3 - r1) < 1e-12
    # (2) 零增益线
    zero_gain = []
    for rg in [-0.8, -0.4, 0.3, 0.7]:
        re_star = rg * (np.sqrt(h2b) / np.sqrt(e2)) * (np.sqrt(e1) / np.sqrt(h1))
        if abs(re_star) < 1:
            gain = rel(h2, rg, re_star, "D3") - rel(h2, rg, re_star, "D1")
            zero_gain.append((rg, float(re_star), float(gain))); assert abs(gain) < 1e-10, (rg, re_star, gain)
    # 曲面
    surf = np.array([[rel(h2, rg, re, "D3") - rel(h2, rg, re, "D1") for re in grid] for rg in grid])
    surf4 = np.array([[rel(h2, rg, re, "D4") - rel(h2, rg, re, "D1") for re in grid] for rg in grid])
    assert surf.min() > -1e-10 and surf4.min() > -1e-10
    # (3) 同 |r_g|，r_e 反号的增益 > 同号
    rg0 = 0.6
    g_opp = rel(h2, rg0, -0.6, "D3") - rel(h2, rg0, -0.6, "D1"); g_same = rel(h2, rg0, 0.6, "D3") - rel(h2, rg0, 0.6, "D1")
    assert g_opp > g_same
    # (4) D2 闭式 r_g² h2 / ... ： R²=cov²/(var·G11)=(rg√(h1h2))²/(1·G11)=rg² h2（总表型方差 1）
    for rg in grid:
        assert abs(rel(h2, rg, 0.2, "D2") - rg ** 2 * h2b) < 1e-12
    # (5) MC
    mcs = []
    for rg, re in cfg["mc_points"]:
        mc = mc_check(h2, rg, re, cfg["n_mc"], rng, ns)
        an = {d: rel(h2, rg, re, d, ns) for d in ["D1", "D2", "D3", "D4"]}
        mcs.append(dict(rg=rg, re=re, analytic=an, mc=mc))
        for d in an:
            assert abs(an[d] - mc[d]) < 0.012, (rg, re, d, an[d], mc[d])
    print("=" * 78)
    print(f"习题 24.20  二性状可靠度曲面：h²=({h1},{h2b})，同胞数 n={ns}")
    print("=" * 78)
    print("D3 − D1（候选自身第二性状的边际可靠度增益）；行 r_g，列 r_e")
    print("r_g\\r_e " + " ".join(f"{x:6.1f}" for x in grid))
    for rg, row in zip(grid, surf):
        print(f"{rg:6.1f}  " + " ".join(f"{v:6.3f}" for v in row))
    print("\n零增益线 r_e*(r_g)：" + "；".join(f"r_g={a:+.1f}→r_e*={b:+.3f}（增益 {c:.1e}）" for a, b, c in zero_gain))
    print(f"r_g=0.6：r_e=−0.6 的增益 {g_opp:.4f} > r_e=+0.6 的增益 {g_same:.4f}")
    print("蒙特卡罗核对（解析 / MC）：")
    for m in mcs:
        print(f"  r_g={m['rg']:+.1f}, r_e={m['re']:+.1f}: " + "  ".join(f"{d} {m['analytic'][d]:.3f}/{m['mc'][d]:.3f}" for d in ["D1", "D2", "D3", "D4"]))
    json.dump(dict(h2=h2, grid=grid, gain_D3_minus_D1=surf.tolist(), gain_D4_minus_D1=surf4.tolist(), zero_gain_line=zero_gain, mc=mcs),
              open(HERE / "results" / "ex24_20_two_trait_reliability_surface.json", "w"), ensure_ascii=False, indent=1)
    try:
        from _plot import get_pyplot
        plt = get_pyplot()
        fig, ax = plt.subplots(figsize=(5.2, 4.2))
        im = ax.imshow(surf, origin="lower", extent=[grid[0], grid[-1], grid[0], grid[-1]], aspect="auto", cmap="viridis")
        xs = np.linspace(-0.9, 0.9, 50); ax.plot(xs * 0 + xs, xs * (np.sqrt(h2b / e2) * np.sqrt(e1 / h1)), "w--", lw=1)
        ax.set_xlim(grid[0], grid[-1]); ax.set_ylim(grid[0], grid[-1]); ax.set_xlabel("r_e"); ax.set_ylabel("r_g")
        fig.colorbar(im, label="R2 gain"); fig.tight_layout(); fig.savefig(HERE / "results" / "ex24_20_surface.png", dpi=130); plt.close(fig)
    except Exception as ex:
        print("绘图跳过：", ex)


if __name__ == "__main__":
    main()
