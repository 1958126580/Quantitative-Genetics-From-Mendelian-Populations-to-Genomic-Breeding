#!/usr/bin/env python3
"""习题 24.17  二分类性状的阈值（probit）种公牛模型：Gibbs 抽样、Dempster–Lerner 换算与线性模型比较

模型：潜在液态变量 l_ij = μ + h_k + s_i + e_ij，e~N(0,1)，s_i~N(0,σ_s²)；观测 y_ij = 1{l_ij>0}。
      h_k 为群（herd）固定效应；各公牛后代数不等且群分布不同，使线性模型的排序受群阈值差异扰动。
方法：(a) Albert–Chib 数据扩增 Gibbs（l | y 为截尾正态，其余为共轭更新）；
      (b) 对 0/1 记录拟合线性种公牛模型（BLUP，方差比取 Dempster–Lerner 换算后的值）；
      (c) Dempster–Lerner：h²_obs = h²_liab · z²/(p(1−p))，z 为阈值处标准正态密度，p 为发病率。
指标：公牛真效应的相关、排序相关；h² 的液态变量尺度与观测尺度换算；重复 n_rep 次资料的平均表现。
核验：(1) Gibbs 单次资料 σ_s² 后验区间覆盖真值；(2) D–L 换算与 ANOVA 观测尺度 h² 一致（容差 30%）；
      (3) 重复试验中阈值模型与真值相关平均不低于线性模型。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm, truncnorm, spearmanr

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    S = cfg["n_sires"]; K = cfg["n_herds"]
    s_true = rng.standard_normal(S) * np.sqrt(cfg["sigma_s2"])
    cnt = rng.integers(cfg["progeny_min"], cfg["progeny_max"] + 1, S)
    sire = np.repeat(np.arange(S), cnt)
    # 每头公牛偏好某些群：群概率随公牛序号倾斜
    herd = np.empty(len(sire), int)
    pos = 0
    for i in range(S):
        pr = np.exp(0.5 * np.cos(2 * np.pi * (np.arange(K) - (i % K)) / K))   # 温和的群偏好
        pr /= pr.sum()
        herd[pos:pos + cnt[i]] = rng.choice(K, cnt[i], p=pr); pos += cnt[i]
    h = np.array(cfg["herd_effects"])
    liab = cfg["mu"] + h[herd] + s_true[sire] + rng.standard_normal(len(sire))
    y = (liab > 0).astype(float)
    return s_true, sire, herd, y


def gibbs(y, sire, herd, S, K, cfg, rng):
    n = len(y); nit, burn = cfg["n_iter"], cfg["burn"]
    nu, s2p = cfg["prior_nu"], cfg["prior_s2"]
    # 设计：固定效应 = K 个群均值（无独立 μ，避免奇异）
    s = np.zeros(S); b = np.zeros(K); vs = 0.1
    cnt_s = np.bincount(sire, minlength=S).astype(float)
    cnt_h = np.bincount(herd, minlength=K).astype(float)
    lo = np.where(y == 1, 0.0, -np.inf); hi = np.where(y == 1, np.inf, 0.0)
    keep_s = []; keep_vs = []; keep_b = []
    for it in range(nit):
        m = b[herd] + s[sire]
        l = truncnorm.rvs(lo - m, hi - m, loc=m, scale=1.0, random_state=rng)
        # 群效应（平坦先验）
        r = l - s[sire]
        b = np.bincount(herd, r, K) / cnt_h + rng.standard_normal(K) / np.sqrt(cnt_h)
        # 公牛
        r = l - b[herd]
        lam = 1.0 / vs
        prec = cnt_s + lam
        s = np.bincount(sire, r, S) / prec + rng.standard_normal(S) / np.sqrt(prec)
        # 方差（缩放逆卡方）
        vs = (nu * s2p + s @ s) / rng.chisquare(nu + S)
        if it >= burn:
            keep_s.append(s.copy()); keep_vs.append(vs); keep_b.append(b.copy())
    return np.array(keep_s), np.array(keep_vs), np.array(keep_b)


def linear_blup(y, sire, herd, S, K, lam):
    n = len(y)
    X = np.zeros((n, K)); X[np.arange(n), herd] = 1
    Z = np.zeros((n, S)); Z[np.arange(n), sire] = 1
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * np.eye(S)]])
    rhs = np.concatenate([X.T @ y, Z.T @ y])
    sol = np.linalg.solve(C, rhs)
    return sol[:K], sol[K:]


def anova_h2(y, sire, S, herd=None, K=0):
    """观测尺度单向随机效应方差分析（不平衡，Searle 系数）→ h² = 4σ_s²/(σ_s²+σ_e²)。先扣除群均值。"""
    if herd is not None:
        y = y - (np.bincount(herd, y, K) / np.bincount(herd, minlength=K))[herd]
    n = len(y); cnt = np.bincount(sire, minlength=S).astype(float)
    ybar = np.bincount(sire, y, S) / cnt; gm = y.mean()
    SSB = (cnt * (ybar - gm) ** 2).sum(); SSW = ((y - ybar[sire]) ** 2).sum()
    MSB = SSB / (S - 1); MSW = SSW / (n - S)
    n0 = (n - (cnt ** 2).sum() / n) / (S - 1)
    vs = (MSB - MSW) / n0
    return 4 * vs / (vs + MSW), vs, MSW


def one_rep(cfg, rng, full=False):
    S, K = cfg["n_sires"], cfg["n_herds"]
    s_true, sire, herd, y = simulate(cfg, rng)
    ks, kvs, kb = gibbs(y, sire, herd, S, K, cfg, rng)
    s_th = ks.mean(0)
    h2_obs, vs_o, ve_o = anova_h2(y, sire, S, herd, K)
    lam_lin = ve_o / max(vs_o, 1e-6)
    _, s_lin = linear_blup(y, sire, herd, S, K, lam_lin)
    return dict(s_true=s_true, s_th=s_th, s_lin=s_lin, vs=kvs, h2_obs=h2_obs, y=y, kb=kb, herd=herd, sire=sire)


def main():
    cfg = json.load(open(HERE / "data" / "ex24_17_threshold.json"))
    rng = np.random.default_rng(cfg["seed"])
    r = one_rep(cfg, rng)
    vs_true = cfg["sigma_s2"]
    h2_liab_true = 4 * vs_true / (vs_true + 1)
    vs_hat = r["vs"].mean(); lo, hi = np.percentile(r["vs"], [2.5, 97.5])
    h2_liab_hat = np.mean(4 * r["vs"] / (r["vs"] + 1))
    y = r["y"]; p = y.mean(); t = norm.ppf(1 - p); z = norm.pdf(t)
    h2_dl = h2_liab_hat * z ** 2 / (p * (1 - p))
    corr_th = np.corrcoef(r["s_th"], r["s_true"])[0, 1]
    corr_lin = np.corrcoef(r["s_lin"], r["s_true"])[0, 1]
    rho = spearmanr(r["s_th"], r["s_lin"])[0]
    top = lambda v, k=10: set(np.argsort(-v)[:k])
    overlap = len(top(r["s_th"]) & top(r["s_lin"]))
    # 重复试验
    ct, cl = [], []
    for k in range(cfg["n_rep"]):
        q = one_rep({**cfg, "n_iter": 900, "burn": 300}, np.random.default_rng(cfg["seed"] + 100 + k))
        ct.append(np.corrcoef(q["s_th"], q["s_true"])[0, 1]); cl.append(np.corrcoef(q["s_lin"], q["s_true"])[0, 1])
    print("=" * 78)
    print(f"习题 24.17  阈值 probit 种公牛模型：{cfg['n_sires']} 头公牛，{len(y)} 条 0/1 记录，发病率 p̂={p:.3f}")
    print("=" * 78)
    print(f"σ_s² 真值 {vs_true:.3f}；Gibbs 后验均值 {vs_hat:.3f}，95% 区间 [{lo:.3f}, {hi:.3f}]")
    print(f"液态变量尺度 h²：真值 {h2_liab_true:.3f}；后验均值 {h2_liab_hat:.3f}")
    print(f"阈值 t={t:.3f}，密度 z={z:.4f}；Dempster–Lerner 换算观测尺度 h²_obs = {h2_dl:.4f}；ANOVA 直接估计 {r['h2_obs']:.4f}")
    print(f"公牛真效应相关：阈值模型 {corr_th:.3f}，线性模型 {corr_lin:.3f}；两者排序 Spearman {rho:.3f}；前 10 名重合 {overlap}/10")
    print(f"{cfg['n_rep']} 次重复：阈值 {np.mean(ct):.3f}±{np.std(ct):.3f}，线性 {np.mean(cl):.3f}±{np.std(cl):.3f}；阈值更优的比例 {np.mean(np.array(ct)>np.array(cl)):.2f}")
    assert lo < vs_true < hi, "后验区间应覆盖真值"
    assert abs(h2_dl - r["h2_obs"]) / r["h2_obs"] < 0.30, (h2_dl, r["h2_obs"])
    assert np.mean(ct) >= np.mean(cl) - 0.005
    assert rho > 0.85
    res = dict(vs_true=vs_true, vs_hat=float(vs_hat), ci=[float(lo), float(hi)], h2_liab_true=h2_liab_true, h2_liab_hat=float(h2_liab_hat),
               p=float(p), t=float(t), z=float(z), h2_dl=float(h2_dl), h2_anova=float(r["h2_obs"]),
               corr_threshold=float(corr_th), corr_linear=float(corr_lin), spearman=float(rho), top10_overlap=int(overlap),
               rep_threshold_mean=float(np.mean(ct)), rep_linear_mean=float(np.mean(cl)))
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(res, open(HERE / "results" / "ex24_17_threshold_probit_gibbs.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
