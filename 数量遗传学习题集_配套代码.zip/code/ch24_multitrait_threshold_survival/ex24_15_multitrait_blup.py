#!/usr/bin/env python3
"""习题 24.15  二性状动物模型 BLUP：缺失记录的信息价值与选择偏倚

模型：y = (I_2⊗...)  性状 t 的记录 y_t = μ_t + a_t + e_t，Var[a_1;a_2] = G⊗A，Var[e_1;e_2] = R⊗I（同一动物的两性状残差相关）。
群体：闭锁、3 代，每代 40 头；世代 g≥1 的亲本依性状 1 的表型选留（比例 40%）。
记录模式：性状 1 在所有动物上有记录；性状 2 只在“选留”之后的动物上有记录（缺失依赖于性状 1 的表型——MAR）。
比较对性状 2 育种值的预测：
  (a) 二性状 BLUP（堆叠的 MME，使用 G⊗A⁻¹）；
  (b) 仅用性状 2 记录的单性状 BLUP（忽略性状 1 与选择）；
  (c) 二性状 BLUP 但把 R 的相关设为 0（模型错误设定）。
指标：对全部动物的性状 2 真育种值的相关、真值对预测的回归斜率、末代遗传趋势偏差。
核验：V 形式（多性状堆叠协方差）与 MME 解一致；PEV 矩阵对称半正定；单性状 PEV ≥ 二性状 PEV。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def simulate(cfg, rng):
    nf, Gn, npg = cfg["n_founders"], cfg["n_gen"], cfg["n_per_gen"]
    G = np.array(cfg["G"]); R = np.array(cfg["R"])
    n = nf + Gn * npg
    A = np.zeros((n, n)); gen = np.zeros(n, int)
    a = np.zeros((n, 2)); F = np.zeros(n)
    LG = np.linalg.cholesky(G); LR = np.linalg.cholesky(R)
    A[:nf, :nf] = np.eye(nf)
    a[:nf] = rng.standard_normal((nf, 2)) @ LG.T
    e = rng.standard_normal((n, 2)) @ LR.T
    y = a + e
    idx = nf; prev = np.arange(nf)
    obs2 = np.ones(n, bool)
    for g in range(1, Gn + 1):
        # 选留：按性状 1 表型选留亲本
        k = max(int(len(prev) * cfg["select_frac"]), 4)
        par = prev[np.argsort(-y[prev, 0])[:k]]
        cur = []
        for _ in range(npg):
            s, d = rng.choice(par, 2, replace=False)
            row = 0.5 * (A[s, :idx] + A[d, :idx]); A[idx, :idx] = row; A[:idx, idx] = row
            F[idx] = 0.5 * A[s, d]; A[idx, idx] = 1 + F[idx]
            f = max(0.5 - 0.25 * (F[s] + F[d]), 1e-9)
            a[idx] = 0.5 * (a[s] + a[d]) + rng.standard_normal(2) @ (LG.T * np.sqrt(f))
            gen[idx] = g; cur.append(idx); idx += 1
        e[nf + (g - 1) * npg: nf + g * npg] = rng.standard_normal((npg, 2)) @ LR.T
        y = a + e
        prev = np.array(cur)
    # 性状 2 记录：被选为亲本者（及最后一代全部）有记录
    parents = set()
    for g in range(1, Gn + 1):
        pass
    return gen, A, a, y, F


def mt_blup(A, y, obs, G, R, ncount=None):
    """obs：(n,2) 布尔，记录是否存在。堆叠顺序：性状 1 的 n 个动物，然后性状 2 的 n 个动物。
    返回 â (n,2)，PEV 矩阵 (2n,2n)，用 MME：[X'R⁻¹X X'R⁻¹Z; Z'R⁻¹X Z'R⁻¹Z + G⁻¹⊗A⁻¹]。"""
    n = A.shape[0]
    Ai = np.linalg.inv(A)
    Gi = np.linalg.inv(G)
    # 记录列表
    rows = []
    for i in range(n):
        for t in range(2):
            if obs[i, t]:
                rows.append((i, t))
    N = len(rows)
    Z = np.zeros((N, 2 * n)); X = np.zeros((N, 2)); yy = np.zeros(N)
    for r, (i, t) in enumerate(rows):
        Z[r, t * n + i] = 1; X[r, t] = 1; yy[r] = y[i, t]
    keep = X.sum(0) > 0
    X = X[:, keep]; npar = int(keep.sum())
    # R⁻¹：同一动物的两条记录相关
    Rinv = np.zeros((N, N))
    pos = {}
    for r, (i, t) in enumerate(rows):
        pos.setdefault(i, {})[t] = r
    for i, d in pos.items():
        ts = sorted(d)
        Rs = R[np.ix_(ts, ts)]
        Ri = np.linalg.inv(Rs)
        for a_, ta in enumerate(ts):
            for b_, tb in enumerate(ts):
                Rinv[d[ta], d[tb]] = Ri[a_, b_]
    # 随机块： G⁻¹ ⊗ A⁻¹，顺序（性状主序）
    Kin = np.kron(Gi, Ai)
    C = np.block([[X.T @ Rinv @ X, X.T @ Rinv @ Z], [Z.T @ Rinv @ X, Z.T @ Rinv @ Z + Kin]])
    rhs = np.r_[X.T @ Rinv @ yy, Z.T @ Rinv @ yy]
    sol = np.linalg.solve(C, rhs)
    Cinv = np.linalg.inv(C)
    u = sol[npar:]
    return np.column_stack([u[:n], u[n:]]), Cinv[npar:, npar:], (X, Z, Rinv, yy, rows)


def main():
    cfg = json.load(open(HERE / "data" / "ex24_15_multitrait.json"))
    rng = np.random.default_rng(cfg["seed"])
    G, R = np.array(cfg["G"]), np.array(cfg["R"])
    out = {}
    rs = {k: [] for k in ("MT", "ST2", "MT_wrongR")}
    sl = {k: [] for k in ("MT", "ST2", "MT_wrongR")}
    tb = {k: [] for k in ("MT", "ST2", "MT_wrongR")}
    pev_chk = None
    for rep in range(cfg["n_rep"]):
        gen, A, a, y, F = simulate(cfg, rng)
        n = len(gen)
        # 性状 2 缺失：基础群（第 0 代）及每一代中非“被选”的动物缺失；最后一代全记录
        obs = np.ones((n, 2), bool)
        last = gen == gen.max()
        # 依性状 1 表型，各世代前 40% 有性状 2 记录（选择依赖性状 1）；最后一代全有记录
        for g in range(gen.max()):
            ids = np.where(gen == g)[0]
            top = ids[np.argsort(-y[ids, 0])[: int(len(ids) * cfg["select_frac"])]]
            m = np.zeros(len(ids), bool); m[np.isin(ids, top)] = True
            obs[ids[~m], 1] = False
        mt, pev, _ = mt_blup(A, y, obs, G, R)
        wrong, _, _ = mt_blup(A, y, obs, G, np.diag(np.diag(R)))
        # 单性状 2：仅性状 2 记录
        obs_st = obs.copy(); obs_st[:, 0] = False
        st, _, _ = mt_blup(A, y, obs_st, np.diag([G[0, 0], G[1, 1]]) * np.array([[1, 0], [0, 1]]), np.diag(np.diag(R)))
        # 注：单性状时 G 取对角（相关 0），性状 1 无记录，不影响性状 2 的解
        tm = np.array([a[gen == g, 1].mean() for g in range(gen.max() + 1)])
        for name, est in (("MT", mt), ("ST2", st), ("MT_wrongR", wrong)):
            e2 = est[:, 1]
            rs[name].append(np.corrcoef(a[last, 1], e2[last])[0, 1])
            x = e2[last] - e2[last].mean(); z = a[last, 1] - a[last, 1].mean()
            sl[name].append((x @ z) / (x @ x))
            em = np.array([e2[gen == g].mean() for g in range(gen.max() + 1)])
            tb[name].append((em[-1] - em[0]) - (tm[-1] - tm[0]))
        if rep == 0:
            # 核验：V 形式
            idx = [(i, t) for i in range(n) for t in range(2) if obs[i, t]]
            N = len(idx)
            Zs = np.zeros((N, 2 * n)); Xs = np.zeros((N, 2)); ys = np.zeros(N)
            for r, (i, t) in enumerate(idx):
                Zs[r, t * n + i] = 1; Xs[r, t] = 1; ys[r] = y[i, t]
            Rs = np.zeros((N, N)); pos = {}
            for r, (i, t) in enumerate(idx): pos.setdefault(i, {})[t] = r
            for i, d in pos.items():
                for ta, ra in d.items():
                    for tb_, rb in d.items(): Rs[ra, rb] = R[ta, tb_]
            Gs = np.kron(G, A)
            V = Zs @ Gs @ Zs.T + Rs
            Vi = np.linalg.inv(V)
            XtViX = Xs.T @ Vi @ Xs
            b = np.linalg.solve(XtViX, Xs.T @ Vi @ ys)
            u = Gs @ Zs.T @ Vi @ (ys - Xs @ b)
            assert np.allclose(np.column_stack([u[:n], u[n:]]), mt, atol=1e-7), "V 形式与 MME 不一致"
            Pm = Vi - Vi @ Xs @ np.linalg.solve(XtViX, Xs.T @ Vi)
            pev_v = Gs - Gs @ Zs.T @ Pm @ Zs @ Gs
            assert np.allclose(pev_v, pev * 1.0, atol=1e-6) or np.allclose(pev_v, pev, atol=1e-5)
            ev = np.linalg.eigvalsh((pev_v + pev_v.T) / 2)
            assert ev.min() > -1e-8
            pev2 = np.diag(pev_v)[n:]
            pev_chk = dict(mean_pev_trait2_obs=float(pev2[obs[:, 1]].mean()), mean_pev_trait2_missing=float(pev2[~obs[:, 1]].mean()))
    print("=" * 84)
    print("习题 24.15  二性状 BLUP：缺失与选择（%d 次重复，G=%s，R=%s）" % (cfg["n_rep"], cfg["G"], cfg["R"]))
    print("=" * 84)
    print(f"{'方法':<22}{'末代相关(性状2)':>16}{'真值对预测斜率':>14}{'末代趋势偏差':>14}")
    names = {"MT": "二性状 BLUP", "ST2": "仅性状2（单性状）", "MT_wrongR": "二性状但 R 相关设 0"}
    for k in rs:
        print(f"{names[k]:<22}{np.mean(rs[k]):16.3f}{np.mean(sl[k]):14.3f}{np.mean(tb[k]):14.3f}")
        out[k] = dict(corr=float(np.mean(rs[k])), slope=float(np.mean(sl[k])), trend_bias=float(np.mean(tb[k])))
    print("首次重复 PEV（性状 2）：有记录者 %.3f；缺记录者 %.3f（先验 G22=%.1f）" % (pev_chk["mean_pev_trait2_obs"], pev_chk["mean_pev_trait2_missing"], G[1, 1]))
    out["pev_check"] = pev_chk
    # 核验：二性状利用性状 1 的信息，应不差于单性状
    assert np.mean(rs["MT"]) >= np.mean(rs["ST2"]) - 0.005
    assert abs(np.mean(tb["MT"])) < abs(np.mean(tb["ST2"])) + 0.3
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex24_15_multitrait_blup.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
