#!/usr/bin/env python3
"""习题 24.16  随机回归测定日模型：曲线预测、逐点可靠度与积分目标

y_ij = Σ_k f_k φ_k(s_ij) + Σ_k a_ik φ_k(s_ij) + Σ_k p_ik φ_k(s_ij) + e_ij，φ_k 为标准化的 Legendre 多项式（0—2 阶），
s = 2(t − t_min)/(t_max − t_min) − 1。家系：n_families 个半同胞家系（共同父亲，母亲不相关），遗传系数 a_i ~ N(0, G⊗A)，
永久环境系数 p_i ~ N(0, P⊗I)，残差独立方差 σ_e²。
计算：
  (1) BLUP：V = Z(G⊗A)Z' + Z(P⊗I)Z' + σ_e²I，â = (G⊗A)Z'V⁻¹(y − Xf̂)，PEV = 联合误差协方差；
  (2) 遗传曲线 g_i(s) = φ(s)'a_i 的逐点预测误差 φ(s)'PEV_i φ(s)、可靠度 1 − PEV/Var(g(s))；
  (3) 积分目标 Σ w_s g_i(s)（窗口 [−1,0]）的预测、误差方差与可靠度；
  (4) 蒙特卡罗核对：重复生成 n_mc 次，经验误差方差与解析 PEV 的相对差 < 10%；
  (5) 曲线边缘的外推：边缘时点的可靠度低于中间时点。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from numpy.polynomial import legendre

HERE = Path(__file__).resolve().parent


def phi(s, order=2):
    s = np.atleast_1d(s)
    cols = []
    for k in range(order + 1):
        c = np.zeros(k + 1); c[k] = 1
        cols.append(np.sqrt((2 * k + 1) / 2) * legendre.legval(s, c))
    return np.column_stack(cols)


def build(cfg, rng):
    nf, fs, rpa = cfg["n_families"], cfg["fam_size"], cfg["records_per_animal"]
    n = nf * fs
    A = np.zeros((n, n))
    for f in range(nf):
        sl = slice(f * fs, (f + 1) * fs)
        A[sl, sl] = 0.25; A[sl, sl] += 0.75 * np.eye(fs)
    ani = np.repeat(np.arange(n), rpa)
    t0, t1 = cfg["t_range"]
    t = rng.uniform(t0, t1, len(ani))
    s = 2 * (t - t0) / (t1 - t0) - 1
    return n, A, ani, s


def design(ani, s, n, order=2):
    Phi = phi(s, order)
    N = len(ani); K = order + 1
    Z = np.zeros((N, n * K))
    for r in range(N):
        Z[r, ani[r] * K:(ani[r] + 1) * K] = Phi[r]
    return Phi, Z


def blup(y, Phi, Z, GA, PI, se2):
    N = len(y)
    V = Z @ GA @ Z.T + Z @ PI @ Z.T + se2 * np.eye(N)
    L = np.linalg.cholesky(V)
    Vi = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(N)))
    XtVi = Phi.T @ Vi
    f = np.linalg.solve(XtVi @ Phi, XtVi @ y)
    r = y - Phi @ f
    a = GA @ Z.T @ Vi @ r
    P = Vi - Vi @ Phi @ np.linalg.solve(XtVi @ Phi, XtVi)
    pev = GA - GA @ Z.T @ P @ Z @ GA
    return f, a, pev


def main():
    cfg = json.load(open(HERE / "data" / "ex24_16_random_regression.json"))
    rng = np.random.default_rng(cfg["seed"])
    G, P, se2 = np.array(cfg["G"]), np.array(cfg["P"]), cfg["sigma_e2"]
    n, A, ani, s = build(cfg, rng)
    K = 3
    Phi, Z = design(ani, s, n)
    GA = np.kron(A, G)          # 顺序：动物主序，每动物 K 个系数
    PI = np.kron(np.eye(n), P)
    LG = np.linalg.cholesky(GA + 1e-10 * np.eye(n * K)); LP = np.linalg.cholesky(PI)
    # 一次资料
    a0 = LG @ rng.standard_normal(n * K); p0 = LP @ rng.standard_normal(n * K)
    y0 = Phi @ np.array(cfg["fixed"]) + Z @ a0 + Z @ p0 + np.sqrt(se2) * rng.standard_normal(len(ani))
    f, ah, pev = blup(y0, Phi, Z, GA, PI, se2)
    # 逐点
    pts = np.array(cfg["eval_points"]); Pp = phi(pts)
    rel_pts = []; pev_pts = []; var_pts = []
    for i in range(n):
        sl = slice(i * K, (i + 1) * K)
        pe = np.einsum("pk,kl,pl->p", Pp, pev[sl, sl], Pp)
        vg = np.einsum("pk,kl,pl->p", Pp, GA[sl, sl], Pp)
        pev_pts.append(pe); var_pts.append(vg)
    pev_pts = np.array(pev_pts); var_pts = np.array(var_pts)
    rel = 1 - pev_pts.mean(0) / var_pts.mean(0)
    # 积分目标：窗口 [lo,hi] 上的平均曲线
    lo, hi = cfg["target_window"]
    ss = np.linspace(lo, hi, 101); w = np.ones_like(ss) / len(ss)
    wvec = (w[:, None] * phi(ss)).sum(0)
    tgt_hat = np.array([wvec @ ah[i * K:(i + 1) * K] for i in range(n)])
    tgt_true = np.array([wvec @ a0[i * K:(i + 1) * K] for i in range(n)])
    pev_t = np.array([wvec @ pev[i * K:(i + 1) * K, i * K:(i + 1) * K] @ wvec for i in range(n)])
    var_t = np.array([wvec @ GA[i * K:(i + 1) * K, i * K:(i + 1) * K] @ wvec for i in range(n)])
    # 蒙特卡罗
    err_pts = np.zeros((cfg["n_mc"], len(pts))); err_t = np.zeros(cfg["n_mc"])
    for m in range(cfg["n_mc"]):
        a = LG @ rng.standard_normal(n * K); pe = LP @ rng.standard_normal(n * K)
        y = Phi @ np.array(cfg["fixed"]) + Z @ a + Z @ pe + np.sqrt(se2) * rng.standard_normal(len(ani))
        _, ahm, _ = blup(y, Phi, Z, GA, PI, se2)
        for j, pt in enumerate(Pp):
            ghat = np.array([pt @ ahm[i * K:(i + 1) * K] for i in range(n)])
            gtrue = np.array([pt @ a[i * K:(i + 1) * K] for i in range(n)])
            err_pts[m, j] = np.mean((ghat - gtrue) ** 2)
        th = np.array([wvec @ ahm[i * K:(i + 1) * K] for i in range(n)]); tt = np.array([wvec @ a[i * K:(i + 1) * K] for i in range(n)])
        err_t[m] = np.mean((th - tt) ** 2)
    print("=" * 80)
    print("习题 24.16  随机回归：%d 头动物 × %d 条记录；G 对角 %.1f/%.1f/%.1f" % (n, cfg["records_per_animal"], *np.diag(G)))
    print("=" * 80)
    print("标准化时间 s：      " + "  ".join(f"{p:6.2f}" for p in pts))
    print("遗传方差 φ'Gφ：     " + "  ".join(f"{v:6.3f}" for v in var_pts.mean(0)))
    print("平均 PEV（解析）：  " + "  ".join(f"{v:6.3f}" for v in pev_pts.mean(0)))
    print("经验 MSE（MC）：    " + "  ".join(f"{v:6.3f}" for v in err_pts.mean(0)))
    print("逐点可靠度：        " + "  ".join(f"{v:6.3f}" for v in rel))
    rel_t = 1 - pev_t.mean() / var_t.mean()
    print(f"\n积分目标（s∈[{lo},{hi}] 平均）：平均 PEV {pev_t.mean():.4f}（MC {err_t.mean():.4f}），目标遗传方差 {var_t.mean():.4f}，可靠度 {rel_t:.3f}")
    print(f"一次资料：目标 EBV 与真值相关 {np.corrcoef(tgt_hat, tgt_true)[0,1]:.3f}；固定回归估计 {np.round(f, 3)}（真值 {cfg['fixed']}）")
    for j in range(len(pts)):
        assert abs(err_pts[:, j].mean() - pev_pts.mean(0)[j]) / pev_pts.mean(0)[j] < 0.10, (j, err_pts[:, j].mean(), pev_pts.mean(0)[j])
    assert abs(err_t.mean() - pev_t.mean()) / pev_t.mean() < 0.10
    assert rel[2] > rel[0] and rel[2] > rel[-1], "边缘时点可靠度应低于中间时点"
    out = dict(points=pts.tolist(), var=var_pts.mean(0).tolist(), pev=pev_pts.mean(0).tolist(), mse_mc=err_pts.mean(0).tolist(), reliability=rel.tolist(),
               target=dict(pev=float(pev_t.mean()), mse_mc=float(err_t.mean()), var=float(var_t.mean()), reliability=float(rel_t)), fixed_hat=f.tolist())
    (HERE / "results").mkdir(exist_ok=True)
    json.dump(out, open(HERE / "results" / "ex24_16_random_regression.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
