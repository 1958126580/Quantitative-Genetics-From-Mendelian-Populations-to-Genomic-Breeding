# 第24章　多性状、阈值、生存与纵向遗传模型——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex24_15_multitrait_blup.py
python3 ex24_16_random_regression.py
python3 ex24_17_threshold_probit_gibbs.py
python3 ex24_18_gamma_frailty_survival.py
python3 ex24_19_case_control_enrichment.py
python3 ex24_20_two_trait_reliability_surface.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex24_15_multitrait_blup.py | 24.15 | 二性状动物模型 BLUP：缺失记录的信息价值与选择偏倚 |
| ex24_16_random_regression.py | 24.16 | 随机回归测定日模型：曲线预测、逐点可靠度与积分目标 |
| ex24_17_threshold_probit_gibbs.py | 24.17 | 二分类性状的阈值（probit）种公牛模型：Gibbs 抽样、Dempster–Lerner 换算与线性模型比较 |
| ex24_18_gamma_frailty_survival.py | 24.18 | 伽马脆弱性（frailty）生存模型：右删失 + 左截断下的种公牛“长寿”评定 |
| ex24_19_case_control_enrichment.py | 24.19 | 病例富集抽样下的风险预测：截距平移、加权校准与 AUC 不变性 |
| ex24_20_two_trait_reliability_surface.py | 24.20 | 二性状选择指数的可靠度曲面：什么时候“相关性状”真正有用 |
