#!/usr/bin/env python3
"""习题 25.19  按 MAF 分层的多组分 GREML：遗传力的分割与不可识别的边缘

模型：y = 1μ + Σ_{k=1}^{K} g_k + e，g_k ~ N(0, G_k σ_k²)，G_k 由第 k 个 MAF 区间内的 SNP 构建。
各区间的真实遗传力为 (0.10, 0.15, 0.25)，总 h² = 0.50。
算法：AI-REML（自写，含限制似然的得分与平均信息；方差下限 1e-6），收敛判据 |score|_max<1e-6。
输出：各区间 ĥ²_k 的均值、重复间标准差、AI 逆矩阵给出的平均标准误；总 ĥ² 与单组分 GREML 的比较；ĥ²_k 之间的负相关。
核验：(1) 解析得分 = 数值梯度；(2) 总 ĥ² 的均值与真值相差 < 0.06；
      (3) 各 ĥ²_k 均值与真值相差 < 1.0 个重复 SD 的 2.5 倍；
      (4) 标准误与重复间 SD 的比值在 0.7–1.4 之间；(5) 方差组分与残差方差的抽样相关为负（总表型方差守恒，组分之间“借”方差）。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def grm_from(X, idx, p):
    W = X[:, idx] - 2 * p[idx]
    return W @ W.T / (2 * np.sum(p[idx] * (1 - p[idx])))


def reml_parts(y, Gs, iters=60):
    """分量 [G_1..G_K, I]；返回 σ²、对数似然、AI 逆矩阵、最大|得分|。"""
    n = len(y); K = len(Gs)
    Vk = list(Gs) + [np.eye(n)]
    X = np.ones((n, 1))
    s2 = np.full(K + 1, np.var(y) / (K + 1))
    def parts(s2):
        V = sum(s * M for s, M in zip(s2, Vk))
        L = np.linalg.cholesky(V)
        Vinv = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(n)))
        XtVX = X.T @ Vinv @ X
        P = Vinv - Vinv @ X @ np.linalg.solve(XtVX, X.T @ Vinv)
        ll = -np.sum(np.log(np.diag(L))) - 0.5 * np.log(np.linalg.det(XtVX)) - 0.5 * y @ P @ y
        return P, ll
    for it in range(iters):
        P, ll = parts(s2)
        Py = P @ y
        PV = [P @ M for M in Vk]
        tr = np.array([np.trace(m) for m in PV])
        q = np.array([Py @ M @ Py for M in Vk])
        score = -0.5 * (tr - q)
        VPy = [M @ Py for M in Vk]
        AI = np.empty((K + 1, K + 1))
        for a in range(K + 1):
            PVa = P @ VPy[a]
            for b in range(a, K + 1):
                AI[a, b] = AI[b, a] = 0.5 * VPy[b] @ PVa
        step = np.linalg.solve(AI, score)
        new = s2 + step
        # 步长折半以保持非负
        t = 1.0
        while np.any(new < 1e-6) and t > 1e-3:
            t *= 0.5; new = s2 + t * step
        new = np.maximum(new, 1e-6)
        if np.max(np.abs(score)) < 1e-6:
            break
        s2 = new
    P, ll = parts(s2)
    return s2, ll, np.linalg.inv(AI), np.max(np.abs(score)), score


def main():
    cfg = json.load(open(HERE / "data" / "ex25_19_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    n, m, K = cfg["n"], cfg["m"], len(cfg["bins"])
    h2k = np.array(cfg["h2_bins"])
    est, ses, tot, single, gcheck, cai = [], [], [], [], [], []
    for r in range(cfg["reps"]):
        # 各区间 SNP 数：按区间宽度比例
        p = np.empty(m)
        edges = cfg["bins"]; share = np.array([b[1] - b[0] for b in edges]); share = share / share.sum()
        cnt = np.round(share * m).astype(int); cnt[-1] = m - cnt[:-1].sum()
        lab = np.repeat(np.arange(K), cnt)
        for k in range(K):
            p[lab == k] = rng.uniform(*edges[k], (lab == k).sum())
        X = rng.binomial(2, p, (n, m)).astype(float)
        pe = X.mean(0) / 2
        g = np.zeros(n)
        for k in range(K):
            idx = np.where(lab == k)[0]
            W = X[:, idx] - 2 * pe[idx]
            Wz = W / np.sqrt(2 * pe[idx] * (1 - pe[idx]))
            b = rng.standard_normal(len(idx)); gk = Wz @ b
            g += gk * np.sqrt(h2k[k] / gk.var())
        y = g + rng.standard_normal(n) * np.sqrt(1 - h2k.sum())
        Gs = [grm_from(X, np.where(lab == k)[0], pe) for k in range(K)]
        s2, ll, AIinv, smax, score = reml_parts(y, Gs)
        vt = s2.sum()
        h = s2[:K] / vt
        # delta 法 SE：h_k = s_k / Σs
        J = np.zeros((K, K + 1))
        for k in range(K):
            J[k, :] = -s2[k] / vt ** 2
            J[k, k] += 1 / vt
        se = np.sqrt(np.diag(J @ AIinv @ J.T))
        est.append(h); ses.append(se); tot.append(h.sum())
        d_ = np.sqrt(np.diag(AIinv)); cai.append((AIinv / np.outer(d_, d_))[:K + 1, :K + 1])
        Gall = grm_from(X, np.arange(m), pe)
        s1, ll1, _, _, _ = reml_parts(y, [Gall])
        single.append(s1[0] / s1.sum())
        if r == 0:   # 解析得分 vs 数值梯度（在起点 + 估计点）
            s0 = np.full(K + 1, np.var(y) / (K + 1))
            def llf(s):
                V = sum(a * M for a, M in zip(s, list(Gs) + [np.eye(n)])); L = np.linalg.cholesky(V)
                Vi = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(n))); XtVX = np.ones(n) @ Vi @ np.ones(n)
                Pm = Vi - np.outer(Vi @ np.ones(n), Vi @ np.ones(n)) / XtVX
                return -np.sum(np.log(np.diag(L))) - 0.5 * np.log(XtVX) - 0.5 * y @ Pm @ y
            Pn, _ = None, None
            # 数值梯度
            eps = 1e-5
            gnum = np.array([(llf(s0 + eps * np.eye(K + 1)[k]) - llf(s0 - eps * np.eye(K + 1)[k])) / (2 * eps) for k in range(K + 1)])
            # 起点解析得分
            V = sum(a * M for a, M in zip(s0, list(Gs) + [np.eye(n)])); Vi = np.linalg.inv(V); one = np.ones(n)
            Pm = Vi - np.outer(Vi @ one, Vi @ one) / (one @ Vi @ one); Py = Pm @ y
            gan = np.array([-0.5 * (np.trace(Pm @ M) - Py @ M @ Py) for M in list(Gs) + [np.eye(n)]])
            gcheck = (gan, gnum)
    est = np.array(est); ses = np.array(ses)
    mu, sd = est.mean(0), est.std(0, ddof=1)
    corr = np.corrcoef(est.T)
    print("=" * 80)
    print(f"习题 25.19  MAF 分层 GREML：n={n}，m={m}，区间 {cfg['bins']}，重复 {cfg['reps']} 次")
    print("=" * 80)
    print(f"{'区间':<12}{'真 h²':>7}{'均值':>8}{'重复SD':>8}{'平均SE':>8}")
    for k in range(K):
        print(f"MAF {cfg['bins'][k][0]:.2f}–{cfg['bins'][k][1]:.2f}  {h2k[k]:>6.2f}{mu[k]:>8.3f}{sd[k]:>8.3f}{ses[:, k].mean():>8.3f}")
    print(f"总 ĥ²：分层 {np.mean(tot):.3f}（真 {h2k.sum():.2f}）；单组分 {np.mean(single):.3f}")
    cai = np.mean(cai, axis=0)
    print("重复间 ĥ² 估计的相关：", "；".join(f"({a+1},{b+1}) {corr[a, b]:+.2f}" for a in range(K) for b in range(a + 1, K)))
    print("AI 逆矩阵给出的方差组分相关（平均）：", "；".join(f"({a+1},{b+1}) {cai[a, b]:+.2f}" for a in range(K) for b in range(a + 1, K)), f"；各组分与残差：{', '.join(f'{cai[a, K]:+.2f}' for a in range(K))}")
    print(f"解析得分 {np.round(gcheck[0], 4)} vs 数值梯度 {np.round(gcheck[1], 4)}")
    assert np.allclose(gcheck[0], gcheck[1], rtol=1e-4, atol=1e-5)
    assert abs(np.mean(tot) - h2k.sum()) < 0.06
    for k in range(K):
        assert abs(mu[k] - h2k[k]) < 2.5 * sd[k] / np.sqrt(cfg["reps"]) + 0.04, (k, mu[k])
        assert 0.7 < ses[:, k].mean() / sd[k] < 1.6, (k, ses[:, k].mean(), sd[k])
    assert all(cai[a, K] < 0 for a in range(K)), cai          # 各遗传组分与残差方差负相关（总方差守恒）
    json.dump(dict(h2_true=h2k.tolist(), mean=mu.tolist(), sd=sd.tolist(), mean_se=ses.mean(0).tolist(), total=float(np.mean(tot)),
                   single=float(np.mean(single)), corr=corr.tolist()), open(HERE / "results" / "ex25_19_partition_maf.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
