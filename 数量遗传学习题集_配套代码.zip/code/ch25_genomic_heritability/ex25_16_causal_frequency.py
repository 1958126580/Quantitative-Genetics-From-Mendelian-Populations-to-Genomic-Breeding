#!/usr/bin/env python3
"""习题 25.16  致因变异的频率决定芯片 SNP 能捕获多少遗传力

单倍型“马赛克”模型：基因组分为 B 个独立区块，每个区块有 F 条祖先单倍型（频率 ~ Dirichlet），
每条现代单倍型在每个区块中复制一条祖先单倍型。
  · 常见位点：由祖先单倍型携带的等位基因决定，频率是携带者祖先频率之和；
  · 低频/稀有变异：较新的突变，只出现在某一祖先背景上的少数拷贝中。
芯片 = 随机抽取的部分常见位点（MAF ≥ 0.05）。性状真实 h² = 0.5，由 n_causal 个致因变异决定，
每个致因变异的标准化效应方差相同。三种情形：致因变异为常见、低频（0.01 ≤ MAF < 0.05）、稀有（MAF < 0.01）。
用芯片 G 做 GREML 与 HE 回归，并以“致因变异与区块内芯片 SNP 的最大 r²”解释被捕获的比例。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar

HERE = Path(__file__).resolve().parent


def reml_h2(y: np.ndarray, G: np.ndarray) -> float:
    n = len(y); S, U = np.linalg.eigh(G); yt, xt = U.T @ y, U.T @ np.ones(n)

    def negll(h2: float) -> float:
        d = h2 * S + (1 - h2)
        xvx = np.sum(xt * xt / d); beta = np.sum(xt * yt / d) / xvx
        r = yt - xt * beta
        return 0.5 * (np.sum(np.log(d)) + np.log(xvx) + (n - 1) * np.log(np.sum(r * r / d)))

    return float(minimize_scalar(negll, bounds=(1e-4, 0.9999), method="bounded").x)


def he_h2(y: np.ndarray, G: np.ndarray) -> float:
    z = (y - y.mean()) / y.std(); iu = np.triu_indices(len(y), 1)
    g = G[iu] - G[iu].mean()
    return float(np.sum(g * np.outer(z, z)[iu]) / np.sum(g * g))


def simulate_genome(rng: np.random.Generator, cfg: dict):
    """返回 haps（2N × 位点）、每位点的区块号与类型（0 常见，1 新突变）。"""
    N2 = 2 * cfg["n"]
    blocks, kinds, cols = [], [], []
    for b in range(cfg["blocks"]):
        fq = rng.dirichlet(np.full(cfg["founders"], cfg["dirichlet_alpha"]))
        anc = rng.choice(cfg["founders"], size=N2, p=fq)                  # 每条单倍型复制的祖先
        allele = rng.random((cfg["founders"], cfg["common_per_block"])) < 0.5
        cols.append(allele[anc].astype(np.int8)); blocks += [b] * cfg["common_per_block"]; kinds += [0] * cfg["common_per_block"]
        for _ in range(cfg["new_per_block"]):
            f = rng.choice(cfg["founders"], p=fq)
            pool = np.where(anc == f)[0]
            k = min(len(pool), int(rng.integers(cfg["new_copies"][0], cfg["new_copies"][1] + 1)))
            h = np.zeros(N2, np.int8)
            if k > 0:
                h[rng.choice(pool, k, replace=False)] = 1
            cols.append(h[:, None]); blocks.append(b); kinds.append(1)
    H = np.hstack(cols)
    return H, np.array(blocks), np.array(kinds)


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex25_16_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    classes = {"常见（MAF≥0.05）": (0.05, 0.5), "低频（0.01–0.05）": (0.01, 0.05), "稀有（MAF<0.01）": (0.0, 0.01)}
    res = {c: {"reml": [], "he": [], "max_r2": []} for c in classes}
    for rep in range(cfg["reps"]):
        H, blk, kind = simulate_genome(rng, cfg)
        X = H[0::2].astype(float) + H[1::2]                              # 个体基因型
        p = X.mean(0) / 2; maf = np.minimum(p, 1 - p)
        common = np.where((maf >= 0.05))[0]
        chip = rng.choice(common, size=int(cfg["chip_fraction"] * len(common)), replace=False)
        Wc = X[:, chip] - 2 * p[chip]
        G = Wc @ Wc.T / (2 * np.sum(p[chip] * (1 - p[chip])))
        Zc = Wc / np.sqrt(2 * p[chip] * (1 - p[chip]))
        for c, (lo, hi) in classes.items():
            pool = np.where((maf >= lo) & (maf < hi) & (maf > 0))[0]
            pool = np.setdiff1d(pool, chip)                               # 致因变异本身不在芯片上
            causal = rng.choice(pool, size=cfg["n_causal"], replace=False)
            Zq = (X[:, causal] - 2 * p[causal]) / np.sqrt(2 * p[causal] * (1 - p[causal]))
            g = Zq @ rng.normal(0, 1, cfg["n_causal"])
            g *= np.sqrt(cfg["h2"] / g.var())
            y = g + rng.normal(0, np.sqrt(1 - cfg["h2"]), cfg["n"])
            res[c]["reml"].append(reml_h2(y, G)); res[c]["he"].append(he_h2(y, G))
            # 机制：每个致因变异与同区块芯片 SNP 的最大 r²
            r2 = []
            n = cfg["n"]
            for j in causal[:200]:
                same = np.where(blk[chip] == blk[j])[0]
                if len(same) == 0:
                    r2.append(0.0); continue
                r = (Zc[:, same].T @ Zq[:, list(causal).index(j)]) / n
                r2.append(float(np.max(r * r)))
            res[c]["max_r2"].append(float(np.mean(r2)))
        print(f"重复 {rep + 1}/{cfg['reps']} 完成：芯片 SNP {len(chip)} 个，常见位点 {len(common)} 个")

    out = {"config": cfg, "summary": {}}
    print(f"\n真实 h² = {cfg['h2']}，n = {cfg['n']}，致因变异 {cfg['n_causal']} 个，重复 {cfg['reps']} 次")
    print(f"{'致因变异':<16s}{'GREML 均值':>10s}{'标准差':>8s}{'HE 均值':>9s}{'平均最大r²':>11s}{'捕获比例':>9s}")
    for c in classes:
        a = np.array(res[c]["reml"]); b = np.array(res[c]["he"]); r2 = np.mean(res[c]["max_r2"])
        out["summary"][c] = {"reml_mean": float(a.mean()), "reml_sd": float(a.std(ddof=1)), "he_mean": float(b.mean()),
                             "mean_max_r2": float(r2), "captured_fraction": float(a.mean() / cfg["h2"])}
        print(f"{c:<16s}{a.mean():10.3f}{a.std(ddof=1):8.3f}{b.mean():9.3f}{r2:11.3f}{a.mean() / cfg['h2']:9.2f}")
    s = out["summary"]; keys = list(classes)
    # 核验：常见致因变异被大量捕获；致因变异越稀有，与芯片 SNP 的最大 r² 越低
    # 低频与稀有两类的 GREML 估计都很低、彼此差异小于抽样噪声，故只断言“常见 ≫ 其余”
    assert s[keys[0]]["reml_mean"] > 3 * max(s[keys[1]]["reml_mean"], s[keys[2]]["reml_mean"])
    assert s[keys[0]]["mean_max_r2"] > s[keys[1]]["mean_max_r2"] > s[keys[2]]["mean_max_r2"]
    assert abs(s[keys[0]]["reml_mean"] - cfg["h2"]) < 0.15
    (HERE / "results" / "ex25_16_causal_frequency.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
