#!/usr/bin/env python3
"""习题 25.17  LD 分数回归：由汇总统计量估计 SNP 遗传力并区分多基因信号与群体分层

模型：标准化基因型 z_j，性状 y = Σ_j β_j z_j + e，β_j ~ N(0, h²/M)。
边际关联统计量 χ²_j = n r²_{jy}，在多基因模型下（式 25.4）
        E(χ²_j) = N h² ℓ_j / M + N a + 1，   ℓ_j = Σ_k r²_{jk}（含自身）。
程序流程：
  1. 用高斯 copula 在“块内 AR(1) 相关（各块相关系数不同）”下模拟含 LD 的基因型（单倍型阈值化为 0/1）；
  2. 情形 A（纯多基因）与情形 B（多基因 + 两个亚群的频率差异与表型均值差异，不做分层校正）；
  3. LD 分数取自独立的单群体参照样本，用 r² − (1−r²)/(n_ref−2) 作无偏校正；
  4. χ² 对 ℓ 作普通最小二乘回归，斜率→ h²=斜率·M/N，截距→ 混杂；以“按块”刀切法求标准误。
核验：（i）样本中 mean(χ²) 与公式预测的 1 + N h² mean(ℓ)/M 一致；
      （ii）情形 A 截距≈1、h² 近似无偏；情形 B 截距显著 >1；
      （iii）χ² 的 LD 分数回归与按 LD 分数分组均值给出同样的趋势（斜率 >0）。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def sim_block_haplotypes(rng, n_hap: int, cfg: dict, p: np.ndarray) -> np.ndarray:
    """块内 AR(1) 潜变量 → 阈值化为单倍型（0/1）。p 可为 (m,) 或 (n_hap, m)。"""
    B, L = cfg["blocks"], cfg["block_size"]
    rhos = cfg["_rhos"]
    z = np.empty((n_hap, B * L))
    e = rng.standard_normal((n_hap, B * L))
    for b in range(B):
        j0 = b * L
        z[:, j0] = e[:, j0]
        rho = rhos[b]
        for j in range(1, L):
            z[:, j0 + j] = rho * z[:, j0 + j - 1] + np.sqrt(1 - rho ** 2) * e[:, j0 + j]
    thr = norm.ppf(1 - p)                       # P(z > thr) = p
    return (z > thr).astype(np.int8)


def genotypes(rng, n: int, cfg: dict, p: np.ndarray) -> np.ndarray:
    h = sim_block_haplotypes(rng, 2 * n, cfg, p if p.ndim == 1 else np.repeat(p, 2, axis=0))
    return (h[0::2] + h[1::2]).astype(float)


def ld_scores(Z_ref: np.ndarray, cfg: dict) -> np.ndarray:
    """块内 LD 分数（块间独立），用无偏 r² 估计。"""
    n = Z_ref.shape[0]
    B, L = cfg["blocks"], cfg["block_size"]
    ell = np.empty(B * L)
    for b in range(B):
        S = Z_ref[:, b * L:(b + 1) * L]
        S = (S - S.mean(0)) / S.std(0)
        r2 = (S.T @ S / n) ** 2
        r2 = r2 - (1 - r2) / (n - 2)
        np.fill_diagonal(r2, 1.0)
        ell[b * L:(b + 1) * L] = r2.sum(1)
    return ell


def ldsc(chi2: np.ndarray, ell: np.ndarray, N: int, cfg: dict) -> dict:
    """加权最小二乘 LDSC + 按块刀切标准误。"""
    M, B, L = len(chi2), cfg["blocks"], cfg["block_size"]

    def fit(mask):
        A = np.column_stack([np.ones(mask.sum()), ell[mask]])
        coef = np.linalg.lstsq(A, chi2[mask], rcond=None)[0]
        # 加权两步（Bulik-Sullivan 等 2015）：Var(χ²) ∝ (E χ²)²，且 LD 分数大的 SNP 彼此相关，再按 1/ℓ 降权
        for _ in range(2):
            mu = np.maximum(A @ coef, 0.5)
            w = 1.0 / (mu ** 2 * ell[mask])
            sw = np.sqrt(w)
            coef = np.linalg.lstsq(A * sw[:, None], chi2[mask] * sw, rcond=None)[0]
        return coef

    full = fit(np.ones(M, bool))
    jk = []
    for b in range(B):
        mask = np.ones(M, bool); mask[b * L:(b + 1) * L] = False
        jk.append(fit(mask))
    jk = np.array(jk)
    se = np.sqrt((B - 1) / B * np.sum((jk - jk.mean(0)) ** 2, axis=0))
    return {"intercept": float(full[0]), "slope": float(full[1]), "h2": float(full[1] * M / N),
            "se_intercept": float(se[0]), "se_h2": float(se[1] * M / N)}


def run_case(rng, cfg: dict, stratified: bool, p: np.ndarray, ell: np.ndarray) -> dict:
    n, M = cfg["n"], cfg["blocks"] * cfg["block_size"]
    if stratified:
        d = cfg["delta_p"]
        p1 = np.clip(p - d, 0.02, 0.98); p2 = np.clip(p + d, 0.02, 0.98)
        half = n // 2
        X = np.vstack([genotypes(rng, half, cfg, p1), genotypes(rng, n - half, cfg, p2)])
        pop = np.r_[np.zeros(half), np.ones(n - half)]
    else:
        X = genotypes(rng, n, cfg, p); pop = np.zeros(n)
    keep = X.std(0) > 0
    Z = (X - X.mean(0)) / np.where(keep, X.std(0), 1)
    beta = rng.normal(0, np.sqrt(cfg["h2"] / M), M)
    g = Z @ beta
    y = g + rng.normal(0, np.sqrt(1 - cfg["h2"]), n)
    if stratified:                                   # 表型均值随亚群变化，且亚群效应方差不属于 h²
        y = y + cfg["pop_shift"] * (pop - 0.5) * 2
    y = (y - y.mean()) / y.std()
    r = Z.T @ y / n
    chi2 = n * r ** 2
    res = ldsc(chi2, ell, n, cfg)
    res["mean_chi2"] = float(chi2.mean())
    res["pred_mean_chi2"] = float(1 + n * cfg["h2"] * ell.mean() / M)
    return res


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex25_17_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    M = cfg["blocks"] * cfg["block_size"]
    cfg["_rhos"] = rng.uniform(cfg["rho_lo"], cfg["rho_hi"], cfg["blocks"])     # 各块 AR(1) 相关不同，使 LD 分数有足够离散度
    p = rng.uniform(cfg["maf_lo"], cfg["maf_hi"], M)
    # 参照样本：单群体（频率 p），独立于分析样本
    Xref = genotypes(rng, cfg["n_ref"], cfg, p)
    ell = ld_scores(Xref, cfg)
    print(f"M = {M}，n = {cfg['n']}，参照样本 {cfg['n_ref']}；平均 LD 分数 ℓ̄ = {ell.mean():.2f}，范围 {ell.min():.2f}–{ell.max():.2f}")

    out = {"config": {k: v for k, v in cfg.items() if not k.startswith("_")}, "mean_ld_score": float(ell.mean()), "cases": {}}
    for name, strat in (("A 纯多基因", False), ("B 多基因+分层", True)):
        recs = [run_case(rng, cfg, strat, p, ell) for _ in range(cfg["reps"])]
        keys = ["intercept", "h2", "se_h2", "se_intercept", "mean_chi2", "pred_mean_chi2"]
        avg = {k: float(np.mean([r[k] for r in recs])) for k in keys}
        avg["h2_sd"] = float(np.std([r["h2"] for r in recs], ddof=1))
        avg["intercept_sd"] = float(np.std([r["intercept"] for r in recs], ddof=1))
        out["cases"][name] = avg
        print(f"\n情形 {name}（重复 {cfg['reps']} 次）")
        print(f"  平均 χ² = {avg['mean_chi2']:.3f}（公式预测 {avg['pred_mean_chi2']:.3f}）")
        print(f"  截距 = {avg['intercept']:.3f}（重复间 SD {avg['intercept_sd']:.3f}，刀切 SE {avg['se_intercept']:.3f}）")
        print(f"  ĥ² = {avg['h2']:.3f}（重复间 SD {avg['h2_sd']:.3f}，刀切 SE {avg['se_h2']:.3f}；真值 {cfg['h2']}）")
    A, B = out["cases"]["A 纯多基因"], out["cases"]["B 多基因+分层"]
    assert abs(A["mean_chi2"] / A["pred_mean_chi2"] - 1) < 0.08, "χ² 均值与式 25.4 不符"
    assert abs(A["intercept"] - 1) < 0.15
    assert abs(A["h2"] - cfg["h2"]) < 0.12
    assert B["intercept"] > A["intercept"] + 0.15, "分层应抬高截距"
    assert B["mean_chi2"] > A["mean_chi2"]
    (HERE / "results" / "ex25_17_ldsc.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
