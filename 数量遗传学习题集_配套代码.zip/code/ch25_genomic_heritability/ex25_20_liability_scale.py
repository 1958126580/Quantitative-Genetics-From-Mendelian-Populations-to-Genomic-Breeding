#!/usr/bin/env python3
"""习题 25.20  病例—对照资料的 SNP 遗传力：观测尺度、液态变量尺度与抽样偏差的换算

总体：n_pop 个体，m 个 SNP 的标准化基因型，液态变量 l = g + e（h²_liab = 0.5），患病 y=1 当 l > t，总体患病率 K=5%。
抽样：随机抽取 n_case 例病例与 n_ctrl 例对照（样本病例比例 P≈0.5，“富集”）。
方法：对 0/1 表型在样本内用 HE 回归与 GREML 得到观测尺度 ĥ²_o，再用 Lee 等（2011）公式换算
      ĥ²_l = ĥ²_o · K(1−K)/z² · K(1−K)/[P(1−P)]，   z = φ(Φ⁻¹(1−K))。
对比：(a) 不换算；(b) 只做 D–L 换算（忽略 P≠K 的富集）；(c) 完整换算。
核验：(1) 总体上整份资料的观测尺度 h²_o 满足 D–L：h²_o ≈ h²_l z²/[K(1−K)]；
      (2) 完整换算的均值与真 h²_liab 相差 < 0.07，且比 (a)、(b) 都更接近；
      (3) 样本内 ĥ²_o 在 P≈0.5 时远大于总体观测尺度（富集抬高）。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm

HERE = Path(__file__).resolve().parent


def he(y, G):
    z = (y - y.mean()) / y.std()
    iu = np.triu_indices(len(y), 1)
    g = G[iu]; gc = g - g.mean()
    return float(np.sum(gc * np.outer(z, z)[iu]) / np.sum(gc * gc))


def main():
    cfg = json.load(open(HERE / "data" / "ex25_20_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    N, m, h2, K = cfg["n_pop"], cfg["m"], cfg["h2_liab"], cfg["K"]
    t = norm.ppf(1 - K); z = norm.pdf(t)
    P = cfg["n_case"] / (cfg["n_case"] + cfg["n_ctrl"])
    f_dl = K * (1 - K) / z ** 2
    f_asc = K * (1 - K) / (P * (1 - P))
    # 总体（独立基因型，二项/正态近似）
    p = rng.uniform(0.1, 0.5, m)
    X = rng.binomial(2, p, (N, m)).astype(np.float32)
    Z = (X - 2 * p.astype(np.float32)) / np.sqrt(2 * p * (1 - p)).astype(np.float32)
    beta = rng.standard_normal(m) * np.sqrt(h2 / m)
    g = (Z @ beta.astype(np.float32)).astype(float)
    g *= np.sqrt(h2 / g.var())
    liab = g + rng.standard_normal(N) * np.sqrt(1 - h2)
    y = (liab > np.quantile(liab, 1 - K)).astype(float)
    # (1) 总体观测尺度 h²_o：对 y 回归 g（真遗传值）的 R²≈cov²/(var g var y)；用 g 的线性回归系数更直接
    b = np.cov(g, y)[0, 1] / g.var()
    h2_o_pop = b ** 2 * g.var() / y.var()
    h2_o_dl = h2 * z ** 2 / (K * (1 - K))
    print("=" * 78)
    print(f"习题 25.20  液态变量尺度换算：K={K}，z={z:.4f}，样本病例比例 P={P}；D–L 因子 {1/f_dl:.3f}，富集因子 {1/f_asc:.3f}")
    print("=" * 78)
    print(f"总体观测尺度 h²_o：模拟 {h2_o_pop:.4f}；D–L 预测 {h2_o_dl:.4f}（真 h²_liab={h2}）")
    res = {"raw": [], "dl_only": [], "full": []}
    cases = np.where(y == 1)[0]; ctrls = np.where(y == 0)[0]
    for r in range(cfg["reps"]):
        ic = rng.choice(cases, cfg["n_case"], replace=False); ik = rng.choice(ctrls, cfg["n_ctrl"], replace=False)
        idx = np.concatenate([ic, ik])
        Zs = Z[idx].astype(float); Zs = (Zs - Zs.mean(0)) / Zs.std(0)
        G = Zs @ Zs.T / m
        ho = he(y[idx], G)
        res["raw"].append(ho); res["dl_only"].append(ho * f_dl); res["full"].append(ho * f_dl * f_asc)
    ms = {k: (float(np.mean(v)), float(np.std(v, ddof=1))) for k, v in res.items()}
    print(f"{'方法':<22}{'均值':>8}{'重复SD':>8}{'与真值之差':>10}")
    for k, name in (("raw", "(a) 观测尺度，不换算"), ("dl_only", "(b) 仅 D–L 换算"), ("full", "(c) 完整换算（含富集）")):
        print(f"{name:<22}{ms[k][0]:>8.3f}{ms[k][1]:>8.3f}{ms[k][0] - h2:>+10.3f}")
    print(f"样本内观测尺度 ĥ²_o 均值 {ms['raw'][0]:.3f} 是总体观测尺度 {h2_o_pop:.3f} 的 {ms['raw'][0] / h2_o_pop:.1f} 倍（富集抬高）")
    assert abs(h2_o_pop - h2_o_dl) / h2_o_dl < 0.15
    assert abs(ms["full"][0] - h2) < 0.07
    assert abs(ms["full"][0] - h2) < abs(ms["raw"][0] - h2) and abs(ms["full"][0] - h2) < abs(ms["dl_only"][0] - h2)
    assert ms["raw"][0] > 3 * h2_o_pop
    json.dump(dict(K=K, z=float(z), P=P, h2_o_pop=float(h2_o_pop), h2_o_dl=float(h2_o_dl), methods=ms),
              open(HERE / "results" / "ex25_20_liability_scale.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
