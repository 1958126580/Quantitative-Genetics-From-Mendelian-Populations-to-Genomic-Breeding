#!/usr/bin/env python3
"""习题 25.18  效应方差与频率的关系（α 模型）：GRM 的权重设定如何影响 SNP 遗传力估计

模型：β_j ~ N(0, σ²[2p_j(1−p_j)]^α)，g = Σ_j x̃_j β_j（x̃ 为中心化的 0/1/2 基因型），
      Var(g)=σ² Σ_j [2p_j q_j]^{1+α}；对应 GRM  G_α = Σ_j [2p_j q_j]^α x̃_j x̃_jᵀ / Σ_j [2p_j q_j]^{1+α}。
α = −1 即标准 GRM（各 SNP 标准化后等方差），α = 0 为“每个等位基因同等效应”，α > 0 表示常见变异效应更大。
程序：对 true α ∈ {−1, −0.25, 0.5} 模拟性状（h²=0.5），在 α 网格上做 GREML，
      报告各 α 下的限制对数似然、ĥ² 及其排序；以网格峰值作 α̂（剖面似然）。
核验：(1) α = −1 的 G_α 与教材 VanRaden 公式（按 2pq 标准化）逐元一致；
      (2) 真 α=−1 时 α=1 的平均对数似然低于 α=−1；真 α=0.5 时 α=0.5 的平均对数似然高于 α=−1；
      (3) α̂ 的均值在真 α 从 −1 增至 −0.25 时增大；此后（−0.25→0.5）似然曲面极平，只能要求大致不降；
      (4) 在 α 设错至少 1.0 时 ĥ² 的平均绝对偏差不超过 0.25（遗传力估计比 α 本身稳健）。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar

HERE = Path(__file__).resolve().parent


def grm_alpha(X, alpha, p=None):
    p = X.mean(0) / 2 if p is None else p
    W = X - 2 * p
    h = 2 * p * (1 - p)
    w = h ** alpha
    return (W * w) @ W.T / np.sum(h ** (1 + alpha))


def reml(y, G):
    n = len(y); S, U = np.linalg.eigh(G)
    S = np.maximum(S, 0)
    yt, xt = U.T @ y, U.T @ np.ones(n)

    def nll(h2):
        d = h2 * S + (1 - h2)
        xvx = np.sum(xt * xt / d); b = np.sum(xt * yt / d) / xvx
        r = yt - xt * b; ypy = np.sum(r * r / d)
        return 0.5 * (np.sum(np.log(d)) + np.log(xvx) + (n - 1) * np.log(ypy))
    r = minimize_scalar(nll, bounds=(1e-4, 0.9999), method="bounded", options={"xatol": 1e-6})
    return float(r.x), float(-r.fun)


def main():
    cfg = json.load(open(HERE / "data" / "ex25_18_config.json"))
    rng = np.random.default_rng(cfg["seed"])
    n, m, h2 = cfg["n"], cfg["m"], cfg["h2"]
    al = cfg["alphas"]
    # (1) 与标准 VanRaden 对照
    Xt = rng.binomial(2, rng.uniform(0.1, 0.5, 60), (30, 60)).astype(float)
    p = Xt.mean(0) / 2; W = Xt - 2 * p
    Zs = W / np.sqrt(2 * p * (1 - p))                      # 标准化基因型
    assert np.allclose(grm_alpha(Xt, -1.0), Zs @ Zs.T / Xt.shape[1])
    out = {}
    print("=" * 84)
    print(f"习题 25.18  α 模型：n={n}，m={m}，h²={h2}，重复 {cfg['reps']} 次；表中为 ĥ² 均值 / 对数似然相对 α=−1 的均值")
    print("=" * 84)
    print("真 α    " + "  ".join(f"α={a:>5.1f}" for a in al) + "   α̂（网格峰值均值）")
    mean_ahat = []; abs_bias = {}
    for ta in cfg["true_alphas"]:
        H = np.zeros((cfg["reps"], len(al))); L = np.zeros_like(H); ahat = []
        for r in range(cfg["reps"]):
            pj = rng.uniform(cfg["maf_min"], 0.5, m)
            X = rng.binomial(2, pj, (n, m)).astype(float)
            pe = X.mean(0) / 2; keep = (pe > 0) & (pe < 1)
            X = X[:, keep]; pe = pe[keep]
            Wc = X - 2 * pe; hh = 2 * pe * (1 - pe)
            beta = rng.standard_normal(X.shape[1]) * np.sqrt(hh ** ta)
            g = Wc @ beta; g *= np.sqrt(h2 / g.var())
            y = g + rng.standard_normal(n) * np.sqrt(1 - h2)
            for k, a in enumerate(al):
                H[r, k], L[r, k] = reml(y, grm_alpha(X, a, pe))
            ahat.append(al[int(np.argmax(L[r]))])
        rel = L - L[:, [al.index(-1.0)]]
        out[str(ta)] = dict(h2_mean=H.mean(0).tolist(), loglik_rel_mean=rel.mean(0).tolist(), alpha_hat_mean=float(np.mean(ahat)))
        mean_ahat.append(float(np.mean(ahat)))
        print(f"{ta:>5.2f}   " + "  ".join(f"{H[:, k].mean():5.3f}/{rel[:, k].mean():+5.1f}" for k in range(len(al))) + f"   {np.mean(ahat):+.2f}")
        k_true = int(np.argmin([abs(a - ta) for a in al]))
        abs_bias[ta] = (float(np.abs(H[:, k_true] - h2).mean()), float(np.abs(H[:, [al.index(1.0) if ta < 0 else al.index(-1.0)]] - h2).mean()))
    print("\n网格最近 α 的 |ĥ²−h²| 平均 与 α 设错（相差≥1.0）时的 |ĥ²−h²| 平均：")
    for ta, (b_ok, b_wrong) in abs_bias.items():
        print(f"  真 α={ta:>5.2f}：{b_ok:.3f}  vs  {b_wrong:.3f}")
    assert mean_ahat[0] < mean_ahat[1] <= mean_ahat[2] + 0.3, mean_ahat     # α>0 时 n=800 下几乎不可识别：只要求非递减的大趋势
    ta = cfg["true_alphas"][0]
    assert out[str(ta)]["loglik_rel_mean"][al.index(1.0)] < 0, "真 α=−1 时 α=1 的似然应低于 α=−1"
    assert out[str(cfg["true_alphas"][-1])]["loglik_rel_mean"][al.index(0.5)] > 0, "真 α=0.5 时 α=0.5 的似然应高于 α=−1"
    assert max(b[1] for b in abs_bias.values()) < 0.25
    json.dump(out, open(HERE / "results" / "ex25_18_alpha_model.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
