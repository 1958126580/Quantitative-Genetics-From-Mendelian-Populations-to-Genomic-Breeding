#!/usr/bin/env python3
"""习题 25.15  GREML 与 Haseman–Elston 回归：SNP 遗传力的估计、标准误与近亲的影响

模型  y = 1μ + g + e，g ~ N(0, G σ_g²)，e ~ N(0, I σ_e²)，h²_SNP = σ_g²/(σ_g² + σ_e²)。
G 按 VanRaden（2008）方法一由样本频率中心化：G = WWᵀ / [2 Σ p_j(1−p_j)]。
GREML：对 G 作特征分解 G = U S Uᵀ，V ∝ h² S + (1 − h²) I 为对角阵，σ_P² 解析地剖面化，
       在 (0,1) 上一维最大化限制似然；标准误由剖面对数似然的曲率给出。
HE 回归：标准化表型的乘积 y_j y_k (j<k) 对 G_jk 回归，斜率即 h²（式 25.2）。
理论标准误：SE(ĥ²) ≈ √[2 / (n² Var(G_jk))]（式 25.3）。
情形 A：无亲缘个体；情形 B：样本中混入全同胞对且同胞共享共同环境 c²，
比较“全部保留”与“剔除 G_jk > 0.025 的一方”两种处理。
"""
from __future__ import annotations
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")   # 中小矩阵单线程更快且避免线程争用
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar

HERE = Path(__file__).resolve().parent


def grm(M: np.ndarray) -> np.ndarray:
    """VanRaden 方法一，频率取自样本。"""
    p = M.mean(0) / 2
    W = M - 2 * p
    return W @ W.T / (2 * np.sum(p * (1 - p)))


def reml_h2(y: np.ndarray, G: np.ndarray) -> tuple[float, float]:
    """单随机效应 GREML（截距为唯一固定效应），返回 (ĥ², SE)。"""
    n = len(y)
    S, U = np.linalg.eigh(G)
    yt, xt = U.T @ y, U.T @ np.ones(n)

    def negll(h2: float) -> float:
        d = h2 * S + (1 - h2)                  # V/σ_P² 的特征值
        if np.any(d <= 0):
            return 1e10
        xvx = np.sum(xt * xt / d)
        beta = np.sum(xt * yt / d) / xvx
        r = yt - xt * beta
        ypy = np.sum(r * r / d)
        # 剖面化 σ_P² = yᵀPy/(n−1) 后的 −2×REML 对数似然（去常数）
        return 0.5 * (np.sum(np.log(d)) + np.log(xvx) + (n - 1) * np.log(ypy))

    res = minimize_scalar(negll, bounds=(1e-4, 0.9999), method="bounded", options={"xatol": 1e-7})
    h = res.x
    eps = 1e-3
    lo, hi = max(h - eps, 1e-4), min(h + eps, 0.9999)
    curv = (negll(hi) - 2 * negll((lo + hi) / 2) + negll(lo)) / ((hi - lo) / 2) ** 2
    se = 1 / np.sqrt(curv) if curv > 0 else float("nan")
    return float(h), float(se)


def he_h2(y: np.ndarray, G: np.ndarray) -> tuple[float, float]:
    """HE 回归：返回 (斜率 ĥ², 非对角元方差)。"""
    z = (y - y.mean()) / y.std()
    iu = np.triu_indices(len(y), 1)
    g = G[iu]
    prod = np.outer(z, z)[iu]
    gc = g - g.mean()
    slope = np.sum(gc * prod) / np.sum(gc * gc)
    return float(slope), float(g.var())


def simulate(rng: np.random.Generator, cfg: dict, n_sib_pairs: int, c2: float):
    """独立位点；前 2×n_sib_pairs 个体为全同胞对（双亲随机抽自群体），其余无亲缘。"""
    m, n, h2 = cfg["n_snp"], cfg["n"], cfg["h2"]
    p = rng.uniform(cfg["maf_min"], 0.5, m)
    n_unrel = n - 2 * n_sib_pairs
    M_un = rng.binomial(2, p, size=(n_unrel, m)).astype(float)
    sib = []
    for _ in range(n_sib_pairs):
        sire = rng.binomial(1, p, size=(2, m)); dam = rng.binomial(1, p, size=(2, m))
        for _k in range(2):
            a = sire[rng.integers(0, 2, m), np.arange(m)]
            b = dam[rng.integers(0, 2, m), np.arange(m)]
            sib.append(a + b)
    M = np.vstack([np.array(sib, float).reshape(-1, m), M_un]) if n_sib_pairs else M_un
    beta = rng.normal(0, 1, m)
    W = M - 2 * p
    g = W @ beta
    g *= np.sqrt(h2 / g.var())
    env_c = np.zeros(n)
    if n_sib_pairs:
        cfam = rng.normal(0, np.sqrt(c2), n_sib_pairs)
        env_c[: 2 * n_sib_pairs] = np.repeat(cfam, 2)
        env_c[2 * n_sib_pairs:] = rng.normal(0, np.sqrt(c2), n - 2 * n_sib_pairs)   # 无亲缘者各自的“家庭”环境
    e = rng.normal(0, np.sqrt(1 - h2 - (c2 if n_sib_pairs else 0)), n)
    return M, g + env_c + e


def prune(G: np.ndarray, thr: float) -> np.ndarray:
    """贪婪剔除：若某对 G_jk > thr，删去其中一员，返回保留的索引。"""
    keep = np.ones(len(G), bool)
    off = np.triu(G, 1)
    for j, k in zip(*np.where(off > thr)):
        if keep[j] and keep[k]:
            keep[k] = False
    return np.where(keep)[0]


def main() -> None:
    cfg = json.loads((HERE / "data" / "ex25_15_config.json").read_text(encoding="utf-8"))
    rng = np.random.default_rng(cfg["seed"])
    out: dict = {"config": cfg}

    # 情形 A：无亲缘
    rec = []
    for _ in range(cfg["reps"]):
        M, y = simulate(rng, cfg, 0, 0.0)
        G = grm(M)
        hr, se = reml_h2(y, G)
        hh, vg = he_h2(y, G)
        q = M.mean(0) / 2; h = 2 * q * (1 - q)
        rec.append((hr, se, hh, vg, np.sum(h * h) / np.sum(h) ** 2))
    rec = np.array(rec)
    se_theory = np.sqrt(2 / (cfg["n"] ** 2 * rec[:, 3].mean()))
    A = {"reml_mean": rec[:, 0].mean(), "reml_sd": rec[:, 0].std(ddof=1), "reml_se_mean": rec[:, 1].mean(),
         "he_mean": rec[:, 2].mean(), "he_sd": rec[:, 2].std(ddof=1), "var_Gjk": rec[:, 3].mean(),
         "inv_m": 1 / cfg["n_snp"], "var_theory": rec[:, 4].mean(), "se_theory": float(se_theory)}
    out["A_unrelated"] = {k: float(v) for k, v in A.items()}
    print("情形 A  无亲缘个体：n = %d，m = %d，真实 h² = %.2f，重复 %d 次" % (cfg["n"], cfg["n_snp"], cfg["h2"], cfg["reps"]))
    print(f"  GREML 均值 {A['reml_mean']:.3f}  重复间标准差 {A['reml_sd']:.3f}  平均曲率标准误 {A['reml_se_mean']:.3f}")
    print(f"  HE    均值 {A['he_mean']:.3f}  重复间标准差 {A['he_sd']:.3f}")
    print(f"  Var(G_jk) = {A['var_Gjk']:.2e}（理论 Σ(2pq)²/(Σ2pq)² = {A['var_theory']:.2e}，1/m = {A['inv_m']:.2e}），式 25.3 理论 SE = {se_theory:.3f}")
    # 核验：两种估计近似无偏；理论 SE 与重复间 SD 同量级；独立位点时 Var(G_jk) = Σ(2pq)²/(Σ2pq)²
    assert abs(A["reml_mean"] - cfg["h2"]) < 3 * A["reml_sd"] / np.sqrt(cfg["reps"]) + 0.02
    assert abs(A["he_mean"] - cfg["h2"]) < 3 * A["he_sd"] / np.sqrt(cfg["reps"]) + 0.02
    assert 0.6 < se_theory / A["reml_sd"] < 1.6
    assert abs(A["var_Gjk"] / A["var_theory"] - 1) < 0.05
    assert A["he_sd"] >= 0.9 * A["reml_sd"], "HE 效率不应明显高于 REML"

    # 情形 B：混入全同胞对与共同环境
    recB = []
    for _ in range(cfg["reps_B"]):
        M, y = simulate(rng, cfg, cfg["sib_pairs"], cfg["c2"])
        G = grm(M)
        h_all, _ = reml_h2(y, G)
        keep = prune(G, cfg["prune_thr"])
        Gk = grm(M[keep])
        h_pr, _ = reml_h2(y[keep], Gk)
        recB.append((h_all, h_pr, len(keep)))
    recB = np.array(recB)
    B = {"reml_all_mean": recB[:, 0].mean(), "reml_pruned_mean": recB[:, 1].mean(), "n_kept_mean": recB[:, 2].mean()}
    out["B_with_sibs"] = {k: float(v) for k, v in B.items()}
    print(f"\n情形 B  {cfg['sib_pairs']} 对全同胞，同胞共同环境 c² = {cfg['c2']}，重复 {cfg['reps_B']} 次")
    print(f"  全部保留：GREML 均值 {B['reml_all_mean']:.3f}")
    print(f"  剔除 G_jk > {cfg['prune_thr']} 后（平均保留 {B['n_kept_mean']:.0f} 人）：GREML 均值 {B['reml_pruned_mean']:.3f}")
    assert B["reml_all_mean"] > B["reml_pruned_mean"], "共同环境应使保留近亲时的估计偏高"
    assert recB[:, 2].max() <= cfg["n"] - cfg["sib_pairs"] + 5

    (HERE / "results" / "ex25_15_greml_he.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
