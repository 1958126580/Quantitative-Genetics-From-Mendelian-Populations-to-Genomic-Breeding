# 第25章　基因组时代的遗传力——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex25_15_greml_he.py
python3 ex25_16_causal_frequency.py
python3 ex25_17_ldsc.py
python3 ex25_18_alpha_model.py
python3 ex25_19_partition_maf.py
python3 ex25_20_liability_scale.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex25_15_greml_he.py | 25.15 | GREML 与 Haseman–Elston 回归：SNP 遗传力的估计、标准误与近亲的影响 |
| ex25_16_causal_frequency.py | 25.16 | 致因变异的频率决定芯片 SNP 能捕获多少遗传力 |
| ex25_17_ldsc.py | 25.17 | LD 分数回归：由汇总统计量估计 SNP 遗传力并区分多基因信号与群体分层 |
| ex25_18_alpha_model.py | 25.18 | 效应方差与频率的关系（α 模型）：GRM 的权重设定如何影响 SNP 遗传力估计 |
| ex25_19_partition_maf.py | 25.19 | 按 MAF 分层的多组分 GREML：遗传力的分割与不可识别的边缘 |
| ex25_20_liability_scale.py | 25.20 | 病例—对照资料的 SNP 遗传力：观测尺度、液态变量尺度与抽样偏差的换算 |
