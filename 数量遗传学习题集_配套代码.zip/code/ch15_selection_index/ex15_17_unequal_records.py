#!/usr/bin/env python3
"""习题 15.17  不等重复记录数：个体均值为什么不能直接排序

模型：y_ij = μ + a_i + p_i + e_ij，V_A = h²，V_PE = t − h²，V_e = 1 − t（V_P = 1）。
记录数为 n 的个体，记录均值 ȳ 的最优预测为  â = b_n (ȳ − μ)，
    b_n = n h² / (1 + (n − 1) t)，其可靠度 r_n² 与 b_n 数值相同（因 Cov(ā, a) = V_A）。
程序比较两种排序依据：(1) 原始均值；(2) 指数（BLUP）b_n(ȳ − μ)。
指标：全体、以及选前10%中的真实育种值均值（实现反应）、选中个体的记录数构成、预测值的校准斜率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex15_17_repeated.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); h2, t, N = cfg["h2"], cfg["t"], cfg["n"]
    counts = np.array(cfg["counts"]); freq = np.array(cfg["freq"])
    nrec = rng.choice(counts, N, p=freq)
    a = rng.normal(0, np.sqrt(h2), N); pe = rng.normal(0, np.sqrt(t - h2), N)
    ybar = a + pe + rng.normal(0, np.sqrt((1 - t) / nrec))
    bn = nrec * h2 / (1 + (nrec - 1) * t)       # 均值对 a 的回归系数 = 最优权重
    blup = bn * ybar
    rel = nrec * h2 / (1 + (nrec - 1) * t)       # 可靠度（与 b_n 同式，因 Var(ā)=h² 时）
    print(f"h² = {h2}，重复力 t = {t}；记录数分布 {dict(zip(counts.tolist(), freq.tolist()))}")
    print(f"{'n':>3s}{'b_n':>8s}{'可靠度':>8s}{'准确度':>8s}{'MC r(ȳ,a)':>10s}{'MC r(BLUP,a)':>13s}{'校准斜率':>9s}")
    for n in counts:
        m = nrec == n
        r_y = np.corrcoef(ybar[m], a[m])[0, 1]; r_b = np.corrcoef(blup[m], a[m])[0, 1]
        slope = np.polyfit(blup[m], a[m], 1)[0]
        rr = n * h2 / (1 + (n - 1) * t)
        assert abs(r_y - np.sqrt(rr)) < 0.012 and abs(slope - 1) < 0.04
        print(f"{n:3d}{n * h2 / (1 + (n - 1) * t):8.3f}{rr:8.3f}{np.sqrt(rr):8.3f}{r_y:10.3f}{r_b:13.3f}{slope:9.3f}")
    # 选择比较
    p = 0.10; res = {}
    for name, score in (("原始均值", ybar), ("BLUP", blup)):
        sel = score >= np.quantile(score, 1 - p)
        res[name] = dict(gain=a[sel].mean(), mean_n=nrec[sel].mean(), share={int(n): float((nrec[sel] == n).mean()) for n in counts})
    print(f"\n选前10%（理论上最优者 BLUP）")
    for k, v in res.items():
        print(f"{k:<6s}  真实育种值均值 {v['gain']:.4f}，入选个体平均记录数 {v['mean_n']:.2f}，各记录数占比 " + "  ".join(f"{n}:{s:.2f}" for n, s in v["share"].items()))
    assert res["BLUP"]["gain"] >= res["原始均值"]["gain"]
    print(f"\n用 BLUP 比原始均值多获得 {100 * (res['BLUP']['gain'] / res['原始均值']['gain'] - 1):.1f}% 的遗传进展")
    (HERE / "results" / "ex15_17_unequal_records.json").write_text(json.dumps(res, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
