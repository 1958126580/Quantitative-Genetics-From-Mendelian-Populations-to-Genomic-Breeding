#!/usr/bin/env python3
"""习题 15.20  再测一次是否值得：重复记录的边际信息价值

候选个体育种值 a ~ N(0, V_A)；n 次重复记录均值的可靠度 r_n² = n h²/(1 + (n−1) t)。
从 m 个候选中选 1 个最优者（按预测值），预期入选者真实育种值
    E[a_选] = r_n σ_A · E[Z_(m:m)]，E[Z_(m:m)] 为 m 个标准正态的期望最大值（精确数值积分）。
每个候选多测一次的边际收益 Δ(n) = 价值·(E_n − E_{n−1})，成本 = m·c·1（每头动物多一次记录）。
求最优测定次数 n*，并以蒙特卡洛核对期望最大值公式。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import integrate, stats
HERE = Path(__file__).resolve().parent


def exp_max(m: int) -> float:
    """m 个标准正态的期望最大值：∫ z m φ(z) Φ(z)^{m−1} dz。"""
    f = lambda z: z * m * stats.norm.pdf(z) * stats.norm.cdf(z) ** (m - 1)
    return integrate.quad(f, -10, 10)[0]


def main():
    cfg = json.loads((HERE / "data" / "ex15_20_voi.json").read_text())
    h2, t, VA = cfg["h2"], cfg["t"], cfg["VA"]; sA = np.sqrt(VA)
    rel = lambda n: n * h2 / (1 + (n - 1) * t) if n > 0 else 0.0
    rng = np.random.default_rng(cfg["seed"])
    print(f"h² = {h2}，重复力 t = {t}；价值 {cfg['value_per_sd']}/σ_A，每次记录成本 {cfg['cost_per_record']}")
    summary = {}
    for m in cfg["cand_options"]:
        em = exp_max(m)
        # 蒙特卡洛核对（n=3 的情形）
        n3 = 3; r = np.sqrt(rel(n3)); a = rng.normal(0, 1, (cfg["n_mc"] // m, m))
        I = r * a + np.sqrt(1 - r * r) * rng.normal(0, 1, a.shape)      # 与 a 相关 r 的标准化指数
        mc = a[np.arange(len(a)), I.argmax(1)].mean(); th = r * em
        assert abs(mc - th) < 0.01, (m, mc, th)
        print(f"\n候选数 m = {m}：E[最大值] = {em:.4f}（MC 核对：n=3 时 理论 {th:.4f}，模拟 {mc:.4f}）")
        print(f"{'n':>3s}{'可靠度':>8s}{'准确度':>8s}{'E[a_选]/σ_A':>12s}{'边际收益':>10s}{'边际成本':>10s}{'净收益':>10s}")
        best, bn = -1e9, 0; rows = []
        prev = 0.0
        for n in range(1, cfg["n_max"] + 1):
            gain = np.sqrt(rel(n)) * em; mg = cfg["value_per_sd"] * sA * (gain - prev) if n > 1 else cfg["value_per_sd"] * sA * gain
            mcst = m * cfg["cost_per_record"]
            net = cfg["value_per_sd"] * sA * gain - mcst * n
            rows.append(dict(n=n, rel=rel(n), acc=np.sqrt(rel(n)), gain=gain, marg=mg, cost=mcst, net=net))
            print(f"{n:3d}{rel(n):8.3f}{np.sqrt(rel(n)):8.3f}{gain:12.4f}{mg:10.2f}{mcst:10.2f}{net:10.2f}")
            if net > best: best, bn = net, n
            prev = gain
        print(f"→ 最优测定次数 n* = {bn}（净收益 {best:.2f}）；可靠度上限 h²/t = {h2 / t:.3f}，n→∞ 时准确度上限 {np.sqrt(h2 / t):.3f}")
        summary[m] = dict(n_star=bn, rows=rows)
    (HERE / "results" / "ex15_20_voi.json").write_text(json.dumps(summary, indent=1, default=float))


if __name__ == "__main__":
    main()
