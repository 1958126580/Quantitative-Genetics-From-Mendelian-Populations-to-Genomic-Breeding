#!/usr/bin/env python3
"""习题 15.16  参数估计误差使名义信息增益落空（Sales–Hill 型模拟）

候选信息：自身记录 + n_fs 个全同胞均值 + n_hs 个半同胞均值。真实指数用真实 h² 构造；
实际应用时 h² 由一个独立的半同胞试验（n_sires 头公畜，每头 m 个后代）经 ANOVA 估计，
再代入同样的指数公式（估计值负时截断为 0.01，大于 0.99 时截断为 0.99），评价
    ρ̂ = 用估计参数的指数与真实育种值的相关；相对效率 ρ̂/ρ_真。
候选结构的协方差用解析式（以 V_P = 1 为单位）：
    Cov(y_自身, a)=h²，Cov(F̄_fs, a)=h²/2，Cov(H̄_hs, a)=h²/4；
    Var(F̄_fs)=[1+(n−1)h²/2]/n，Var(H̄)=[1+(n−1)h²/4]/n，Cov(y,F̄)=h²/2，Cov(y,H̄)=h²/4，Cov(F̄,H̄)=h²/4。
（忽略共同环境；全同胞与半同胞来自同一父亲。）
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


def pc(h2, nfs, nhs):
    P = np.array([[1, h2 / 2, h2 / 4],
                  [h2 / 2, (1 + (nfs - 1) * h2 / 2) / nfs, h2 / 4],
                  [h2 / 4, h2 / 4, (1 + (nhs - 1) * h2 / 4) / nhs]])
    C = np.array([h2, h2 / 2, h2 / 4]); return P, C


def rho(b, h2_true, nfs, nhs):
    """权重 b 在真实参数下与育种值的相关。"""
    P, C = pc(h2_true, nfs, nhs)
    return float(b @ C / np.sqrt(b @ P @ b * h2_true))


def estimate_h2(rng, h2, s, m):
    """半同胞 ANOVA：s 头公畜、每头 m 个后代，h² = 4σ²_S/σ²_P。"""
    sire = rng.normal(0, np.sqrt(h2 / 4), s)
    y = sire[:, None] + rng.normal(0, np.sqrt(1 - h2 / 4), (s, m))
    msb = m * y.mean(1).var(ddof=1); msw = y.var(1, ddof=1).mean()
    sS = (msb - msw) / m; sP = sS + msw
    return float(np.clip(4 * sS / sP, 0.01, 0.99))


def main():
    cfg = json.loads((HERE / "data" / "ex15_16_param_error.json").read_text())
    rng = np.random.default_rng(cfg["seed"]); h2 = cfg["h2"]; nfs, nhs = cfg["n_fs"], cfg["n_hs"]
    P0, C0 = pc(h2, nfs, nhs); b0 = np.linalg.solve(P0, C0); rho0 = rho(b0, h2, nfs, nhs)
    print(f"真实 h² = {h2}；真实参数最优指数准确度 ρ = {rho0:.4f}；权重 b = {np.round(b0, 4)}")
    print(f"{'公畜数':>6s}{'后代/公畜':>9s}{'ĥ²均值':>8s}{'ĥ² SD':>8s}{'ρ̂ 均值':>8s}{'相对效率':>9s}{'损失%':>7s}{'仅用自身 ρ':>10s}{'劣于仅自身比例':>14s}")
    out = []
    own = np.sqrt(h2)
    for m in cfg["offspring_per_sire"]:
        for s in cfg["n_sires"]:
            hs, rr = [], []
            for _ in range(cfg["reps"]):
                hh = estimate_h2(rng, h2, s, m); P, C = pc(hh, nfs, nhs); b = np.linalg.solve(P, C)
                hs.append(hh); rr.append(rho(b, h2, nfs, nhs))
            hs, rr = np.array(hs), np.array(rr)
            out.append(dict(m=m, s=s, h2_mean=hs.mean(), h2_sd=hs.std(), rho=rr.mean(), eff=rr.mean() / rho0, worse=float((rr < own).mean())))
            print(f"{s:6d}{m:9d}{hs.mean():8.3f}{hs.std():8.3f}{rr.mean():8.4f}{rr.mean() / rho0:9.4f}{100 * (1 - rr.mean() / rho0):7.2f}{own:10.4f}{(rr < own).mean():14.3f}")
    # 解析核对：用真实 h² 代入，效率恰为 1
    assert abs(rho(b0, h2, nfs, nhs) - rho0) < 1e-12
    assert all(o["eff"] <= 1 + 1e-9 for o in out)
    (HERE / "results" / "ex15_16_estimation_error.json").write_text(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
