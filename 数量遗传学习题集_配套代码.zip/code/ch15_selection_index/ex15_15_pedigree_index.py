#!/usr/bin/env python3
"""习题 15.15  由系谱构造的多来源选择指数

对候选个体 X，信息来源可含：自身记录、母亲记录、父亲记录、同父异母同胞、全同胞、后代。
程序先构造包含这些个体的小系谱，用表格法求加性关系矩阵 A，再令表型协方差
    P = V_A·A + V_E·I，   候选育种值与各记录的协方差 C = V_A·A[:, X]，
最优指数权重 b = P⁻¹C（线性方程组求解），准确度 r = √(bᵀC / V_A)（X 非近交），可靠度 r²，PEV = V_A(1 − r²)。
并用多元正态模拟核对：模拟育种值 a = L z（L 为 A 的 Cholesky 因子），实际计算指数与育种值的相关。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


def build_pedigree(sc):
    """返回 (sire, dam 列表, 角色字典)。个体顺序保证亲本在前；其余亲本为无关创始者。"""
    ped, role = [], {}
    def add(s, d):
        ped.append((s, d)); return len(ped) - 1
    S = add(-1, -1); D = add(-1, -1); X = add(S, D); role["X"] = X; role["S"] = S; role["D"] = D
    hs_dams = [add(-1, -1) for _ in range(sc["hs"])]
    hs = [add(S, d) for d in hs_dams]
    fs = [add(S, D) for _ in range(sc["fs"])]
    mates = [add(-1, -1) for _ in range(sc["prog"])]
    prog = [add(X, m) for m in mates]
    role.update(hs=hs, fs=fs, prog=prog)
    return ped, role


def relationship(ped):
    n = len(ped); A = np.zeros((n, n))
    for i, (s, d) in enumerate(ped):
        for j in range(i):
            v = 0.5 * ((A[j, s] if s >= 0 else 0) + (A[j, d] if d >= 0 else 0))
            A[i, j] = A[j, i] = v
        A[i, i] = 1 + (0.5 * A[s, d] if s >= 0 and d >= 0 else 0)
    return A


def index_stats(sc, VA, VE, VPE=0.0):
    ped, role = build_pedigree(sc); A = relationship(ped)
    use = ([role["X"]] if sc["own"] else []) + ([role["D"]] if sc["dam"] else []) + ([role["S"]] if sc["sire"] else []) + role["hs"] + role["fs"] + role["prog"]
    P = VA * A[np.ix_(use, use)] + (VE + VPE) * np.eye(len(use))
    C = VA * A[use, role["X"]]
    b = np.linalg.solve(P, C); rel = float(b @ C / VA)
    return dict(n_records=len(use), b=b, rel=rel, acc=np.sqrt(rel), pev=VA * (1 - rel)), (A, use, role, P)


def main():
    cfg = json.loads((HERE / "data" / "ex15_15_scenarios.json").read_text())
    VA, VE, VPE = cfg["VA"], cfg["VE"], cfg["VPE"]; rng = np.random.default_rng(cfg["seed"])
    print(f"V_A = {VA}, V_E = {VE}, h² = {VA / (VA + VE):.3f}")
    print(f"{'方案':<24s}{'记录数':>6s}{'可靠度':>8s}{'准确度':>8s}{'PEV':>8s}{'MC准确度':>9s}")
    out = []
    for sc in cfg["scenarios"]:
        st, (A, use, role, P) = index_stats(sc, VA, VE, VPE)
        L = np.linalg.cholesky(A + 1e-12 * np.eye(len(A)))
        a = (L @ rng.standard_normal((len(A), cfg["n_mc"]))) * np.sqrt(VA)
        y = a[use] + rng.normal(0, np.sqrt(VE + VPE), (len(use), cfg["n_mc"]))
        I = st["b"] @ y; r_mc = np.corrcoef(I, a[role["X"]])[0, 1]
        assert abs(r_mc - st["acc"]) < 0.012
        out.append(dict(name=sc["name"], n=st["n_records"], rel=st["rel"], acc=st["acc"], pev=st["pev"], mc=r_mc, b=st["b"].tolist()))
        print(f"{sc['name']:<24s}{st['n_records']:6d}{st['rel']:8.3f}{st['acc']:8.3f}{st['pev']:8.2f}{r_mc:9.3f}")
    st, _ = index_stats(cfg["scenarios"][4], VA, VE, VPE)
    print("\n方案5（自身+4全同胞+8半同胞）权重：自身 {:.3f}；半同胞逐个 {:.3f}；全同胞逐个 {:.3f}".format(st["b"][0], st["b"][1], st["b"][-1]))
    (HERE / "results" / "ex15_15_pedigree_index.json").write_text(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
