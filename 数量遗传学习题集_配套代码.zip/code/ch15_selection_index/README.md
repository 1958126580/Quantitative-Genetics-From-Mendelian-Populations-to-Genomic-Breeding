# 第15章　单性状选择指数与信息融合——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex15_15_pedigree_index.py
python3 ex15_16_estimation_error.py
python3 ex15_17_unequal_records.py
python3 ex15_18_two_stage_selection.py
python3 ex15_19_missing_records.py
python3 ex15_20_value_of_information.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex15_15_pedigree_index.py | 15.15 | 由系谱构造的多来源选择指数 |
| ex15_16_estimation_error.py | 15.16 | 参数估计误差使名义信息增益落空（Sales–Hill 型模拟） |
| ex15_17_unequal_records.py | 15.17 | 不等重复记录数：个体均值为什么不能直接排序 |
| ex15_18_two_stage_selection.py | 15.18 | 两阶段选择：先用廉价信息初筛，再用昂贵信息终选 |
| ex15_19_missing_records.py | 15.19 | 记录缺失模式不同的候选个体如何公平比较 |
| ex15_20_value_of_information.py | 15.20 | 再测一次是否值得：重复记录的边际信息价值 |
