#!/usr/bin/env python3
"""习题 15.19  记录缺失模式不同的候选个体如何公平比较

每个候选可能有：自身 n 次重复记录（有永久环境 V_PE）、母亲记录（1次，母亲与候选的加性关系 1/2）。
对每种缺失模式构造最优指数（BLP），得到该模式的预测值 â 与可靠度 r²（预测误差方差 V_A(1 − r²)）。
比较三种做法选前 10%：
  (A) 预测值 â（BLP，各模式已向均值收缩）；
  (B) “各自标准化”后的指数 â/√(V_A r²)（相当于 z 分数，错误地抹平了收缩差异）；
  (C) 原始可用记录的均值（缺失模式直接丢弃缺失项后取平均，缺失者记为群体均值）。
评价：被选个体真实育种值的均值，以及模式构成。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent


def pattern_blp(pt, VA, VE, VPE):
    """返回 (权重向量对应 [自身均值, 母亲记录], 可靠度)。"""
    items = []
    if pt["own_n"]: items.append("own")
    if pt["dam"]: items.append("dam")
    if not items: return {}, 0.0
    n = pt["own_n"]; m = len(items); P = np.zeros((m, m)); C = np.zeros(m)
    for i, a in enumerate(items):
        for j, b in enumerate(items):
            if a == b == "own": P[i, j] = VA + VPE + VE / n
            elif a == b == "dam": P[i, j] = VA + VPE + VE
            else: P[i, j] = 0.5 * VA
        C[i] = VA if a == "own" else 0.5 * VA
    b = np.linalg.solve(P, C)
    return dict(zip(items, b)), float(b @ C / VA)


def main():
    cfg = json.loads((HERE / "data" / "ex15_19_missing.json").read_text())
    VA, VE, VPE, N = cfg["VA"], cfg["VE"], cfg["VPE"], cfg["n"]
    rng = np.random.default_rng(cfg["seed"])
    pats = cfg["patterns"]; pr = np.array(cfg["pattern_prob"]); pid = rng.choice(len(pats), N, p=pr)
    # 生成：候选育种值 a，母亲育种值 ad = a/2 + √(3/4)·VA... （母亲与候选的相关 0.5，母亲育种值方差 VA）
    ad = rng.normal(0, np.sqrt(VA), N); a = 0.5 * ad + rng.normal(0, np.sqrt(0.75 * VA), N)
    pe, ped = rng.normal(0, np.sqrt(VPE), N), rng.normal(0, np.sqrt(VPE), N)
    nown = np.array([p["own_n"] for p in pats])[pid]
    ybar = a + pe + rng.normal(0, np.sqrt(VE / np.maximum(nown, 1)))
    ydam = ad + ped + rng.normal(0, np.sqrt(VE), N)
    A_hat = np.zeros(N); rel = np.zeros(N); raw = np.zeros(N)
    print(f"{'模式':<22s}{'占比':>6s}{'权重(自身,母亲)':>20s}{'可靠度':>8s}{'MC r²':>8s}")
    for k, pt in enumerate(pats):
        w, r2 = pattern_blp(pt, VA, VE, VPE); m = pid == k
        A_hat[m] = w.get("own", 0) * ybar[m] + w.get("dam", 0) * ydam[m]; rel[m] = r2
        avail = [v[m] for v, ok in ((ybar, pt["own_n"] > 0), (ydam, pt["dam"])) if ok]
        raw[m] = np.mean(avail, axis=0) if avail else 0.0
        mc = np.corrcoef(A_hat[m], a[m])[0, 1] ** 2 if r2 > 0 else 0.0
        if r2 > 0: assert abs(mc - r2) < 0.02
        print(f"{pt['name']:<22s}{pr[k]:6.2f}{'(%.3f, %.3f)' % (w.get('own', 0), w.get('dam', 0)):>20s}{r2:8.3f}{mc:8.3f}")
    z = np.where(rel > 0, A_hat / np.sqrt(np.maximum(VA * rel, 1e-9)), 0.0)
    p = 0.10; res = {}
    print(f"\n{'方法':<26s}{'入选真实育种值均值':>18s}" + "".join(f"{'模式%d' % (k + 1):>8s}" for k in range(len(pats))))
    for name, s in (("(A) BLP 预测值", A_hat), ("(B) 标准化 z 分数", z), ("(C) 可用记录的原始均值", raw)):
        sel = s >= np.quantile(s, 1 - p)
        res[name] = dict(gain=float(a[sel].mean()), share=[float((pid[sel] == k).mean()) for k in range(len(pats))])
        print(f"{name:<24s}{a[sel].mean():18.4f}" + "".join(f"{x:8.3f}" for x in res[name]["share"]))
    assert res["(A) BLP 预测值"]["gain"] >= max(res["(B) 标准化 z 分数"]["gain"], res["(C) 可用记录的原始均值"]["gain"]) - 0.005
    (HERE / "results" / "ex15_19_missing_records.json").write_text(json.dumps(res, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
