#!/usr/bin/env python3
"""习题 15.18  两阶段选择：先用廉价信息初筛，再用昂贵信息终选

阶段1指数 I₁ 的准确度 r₁（与育种值 A 的相关），阶段2的完整指数 I₂（包含阶段1信息及新增信息）准确度 r₂ ≥ r₁，
r₁₂ = Corr(I₁, I₂) = r₁/r₂（I₁ 是 I₂ 的一个线性函数，投影关系）。设 A、I₁、I₂ 联合正态（标准化）。
阶段1保留比例 q₁，最终保留比例 p（占全部候选），所以阶段2的相对比例 q₂ = p/q₁。
反应 R = E[A | I₁ > c₁, I₂ > c₂]·，用二元正态概率积分的数值解（scipy mvn）求入选概率与条件期望，
并用蒙特卡洛核对；再按“阶段2每个被测候选的成本为阶段1的 κ 倍”比较每单位成本的反应。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy import integrate, stats
HERE = Path(__file__).resolve().parent


def two_stage_gain(r1, r2, q1, p):
    """返回 (R/σ_A, 阶段2阈值 c2)。A、I1、I2 标准化，Corr(A,I1)=r1，Corr(A,I2)=r2，Corr(I1,I2)=r1/r2。"""
    if q1 >= 1.0:                                    # 单阶段
        x = stats.norm.isf(p); return r2 * stats.norm.pdf(x) / p, x
    c1 = stats.norm.isf(q1); rho = r1 / r2
    def sel_prob(c2):
        # P(I1>c1, I2>c2) = ∫_{c1}^{∞} φ(u) P(I2>c2 | I1=u) du
        f = lambda u: stats.norm.pdf(u) * stats.norm.sf((c2 - rho * u) / np.sqrt(1 - rho ** 2))
        return integrate.quad(f, c1, 12)[0]
    from scipy.optimize import brentq
    c2 = brentq(lambda c: sel_prob(c) - p, -3, 6)
    # E[I2; I1>c1, I2>c2]：对 I2 的条件：用 E[I2·1] = ∫ φ(u)[ρu·S + √(1−ρ²) φ(z)] du，z=(c2−ρu)/√(1−ρ²)
    s = np.sqrt(1 - rho ** 2)
    g = lambda u: stats.norm.pdf(u) * (rho * u * stats.norm.sf((c2 - rho * u) / s) + s * stats.norm.pdf((c2 - rho * u) / s))
    EI2 = integrate.quad(g, c1, 12)[0] / p
    return r2 * EI2, c2                              # E[A|…] = r2 E[I2|…]（A 对 (I1,I2) 的回归只通过 I2）


def main():
    cfg = json.loads((HERE / "data" / "ex15_18_two_stage.json").read_text())
    r1, r2, p = np.sqrt(cfg["h2_stage1"]), cfg["r_stage2"], cfg["final_keep"]
    rng = np.random.default_rng(cfg["seed"]); n = cfg["n_mc"]; ratios = cfg["stage2_cost_ratio"]
    # 蒙特卡洛：A = r2 I2 + √(1−r2²) e；I1 = (r1/r2) I2 + √(1−(r1/r2)²) w
    I2 = rng.standard_normal(n); A = r2 * I2 + np.sqrt(1 - r2 ** 2) * rng.standard_normal(n)
    I1 = (r1 / r2) * I2 + np.sqrt(1 - (r1 / r2) ** 2) * rng.standard_normal(n)
    print(f"r₁ = {r1:.3f}（阶段1）, r₂ = {r2:.3f}（阶段2），终选比例 p = {p}；阶段1成本 1/候选，阶段2成本 κ/被测候选")
    head = f"{'q₁':>6s}{'R/σ_A 数值':>11s}{'R/σ_A MC':>10s}{'c₂':>7s}" + "".join(f"{'成本 κ=%d' % k:>10s}{'R/成本':>9s}" for k in ratios)
    print(head); rows = []
    for q1 in cfg["stage1_keep"]:
        R, c2 = two_stage_gain(r1, r2, q1, p)
        score = np.where(I1 > np.quantile(I1, 1 - q1), I2, -np.inf) if q1 < 1 else I2
        keep = np.argsort(score)[-int(p * n):]; Rmc = A[keep].mean()
        assert abs(R - Rmc) < 0.01, (q1, R, Rmc)
        costs = [1.0 + q1 * k for k in ratios]
        rows.append(dict(q1=q1, R=R, Rmc=Rmc, c2=c2, costs=costs, per_cost=[R / c for c in costs]))
        print(f"{q1:6.2f}{R:11.4f}{Rmc:10.4f}{c2:7.3f}" + "".join(f"{c:10.2f}{R / c:9.4f}" for c in costs))
    (HERE / "results" / "ex15_18_two_stage.json").write_text(json.dumps(rows, indent=1, default=float))


if __name__ == "__main__":
    main()
