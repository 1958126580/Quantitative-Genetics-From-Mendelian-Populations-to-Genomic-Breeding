#!/usr/bin/env python3
"""习题 9.16  多等位基因位点的平均效应、育种值与方差分解

k 个等位基因、频率 p_i，基因型值 G_ij。随机交配下：
    群体均值 M = Σ_i Σ_j p_i p_j G_ij
    等位基因平均效应 α_i = Σ_j p_j G_ij − M（携带 A_i 的配子与随机配子结合后的平均离差）
    育种值 BV_ij = α_i + α_j，显性偏差 δ_ij = G_ij − M − α_i − α_j
    V_A = 2 Σ p_i α_i²，V_D = Σ Σ p_i p_j δ_ij²
独立核对：以各等位基因剂量（去掉一个以避免共线）为自变量，对基因型值做加权最小二乘回归，
拟合值离均值部分应等于 BV。并检验 Σ p_i α_i = 0、Σ_j p_j δ_ij = 0。
"""
from __future__ import annotations
import json
from itertools import combinations_with_replacement
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex09_16_multiallele.json").read_text(encoding="utf-8"))
    p = np.array(cfg["freq"]); G = np.array(cfg["genotypic_values"]); k = len(p); names = cfg["alleles"]
    assert np.allclose(G, G.T) and np.isclose(p.sum(), 1)
    M = p @ G @ p; alpha = G @ p - M
    BV = alpha[:, None] + alpha[None, :]; delta = G - M - BV
    VA = 2 * p @ alpha ** 2; VD = p @ (delta ** 2) @ p; VG = p @ ((G - M) ** 2) @ p
    assert np.isclose(p @ alpha, 0) and np.allclose(delta @ p, 0) and np.isclose(VG, VA + VD)
    # 回归核对：每个无序基因型为一个观测，权重为其频率
    rows, w, y = [], [], []
    for i, j in combinations_with_replacement(range(k), 2):
        x = np.zeros(k); x[i] += 1; x[j] += 1; rows.append(x); w.append(p[i] * p[j] * (1 if i == j else 2)); y.append(G[i, j])
    X = np.column_stack([np.ones(len(rows)), np.array(rows)[:, :-1]]); w = np.array(w); y = np.array(y)
    beta = np.linalg.solve(X.T @ (w[:, None] * X), X.T @ (w * y)); fit = X @ beta
    bv_list = np.array([BV[i, j] for i, j in combinations_with_replacement(range(k), 2)])
    assert np.allclose(fit - M, bv_list), "回归拟合值与育种值不一致"
    print(f"群体均值 M = {M:.4f}")
    for i in range(k): print(f"  α({names[i]}) = {alpha[i]:+.4f}")
    print(f"{'基因型':<8s}{'频率':>8s}{'G':>7s}{'BV':>9s}{'δ':>9s}")
    for (i, j), wi in zip(combinations_with_replacement(range(k), 2), w):
        print(f"{names[i]+names[j]:<8s}{wi:8.4f}{G[i,j]:7.2f}{BV[i,j]:9.4f}{delta[i,j]:9.4f}")
    print(f"V_A = {VA:.4f}，V_D = {VD:.4f}，V_G = {VG:.4f}，V_A/V_G = {VA/VG:.4f}")
    out = {"M": M, "alpha": dict(zip(names, alpha.tolist())), "VA": VA, "VD": VD, "VG": VG, "BV": BV.tolist(), "delta": delta.tolist()}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex09_16_multiallele_effects.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
