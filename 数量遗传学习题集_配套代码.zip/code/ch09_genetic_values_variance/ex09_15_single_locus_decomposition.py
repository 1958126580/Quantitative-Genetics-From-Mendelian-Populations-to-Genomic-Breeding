#!/usr/bin/env python3
"""习题 9.15  单位点的完整分解：基因型值、育种值、显性偏差与方差随频率的变化

基因型值 (以纯合子中点为原点)：A1A1 = a，A1A2 = d，A2A2 = −a；p 为 A1 频率，随机交配。
    群体均值      M  = a(p − q) + 2pqd
    平均替代效应  α  = a + d(q − p)
    育种值        BV = 2qα, (q − p)α, −2pα
    显性偏差      D  = −2q²d, 2pqd, −2p²d
    方差          V_A = 2pqα²，V_D = (2pqd)²
程序：(1) 对 p = 0.7、d = 0.5 列出完整分解表，并以加权最小二乘（基因型值对 A1 剂量回归）独立核对 α；
      (2) 验证 BV 与 D 的加权均值为 0、加权协方差为 0；
      (3) 对四种显性程度计算 V_A/V_G 随 p 的变化，找出 V_A 最大的频率与 V_D > V_A 的频率区间。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from _plot import get_pyplot

HERE = Path(__file__).resolve().parent


def decompose(p, a, d):
    q = 1 - p; f = np.array([p * p, 2 * p * q, q * q]); G = np.array([a, d, -a])
    M = f @ G; alpha = a + d * (q - p)
    BV = np.array([2 * q * alpha, (q - p) * alpha, -2 * p * alpha]); D = np.array([-2 * q * q * d, 2 * p * q * d, -2 * p * p * d])
    return dict(f=f, G=G, M=M, alpha=alpha, BV=BV, D=D, VA=2 * p * q * alpha ** 2, VD=(2 * p * q * d) ** 2)


def main():
    cfg = json.loads((HERE / "data" / "ex09_15_locus.json").read_text(encoding="utf-8"))
    a = cfg["a"]; p0, d0 = cfg["table_p"], cfg["table_d"]
    r = decompose(p0, a, d0)
    x = np.array([2, 1, 0.0]); W = r["f"]
    X = np.column_stack([np.ones(3), x]); beta = np.linalg.solve(X.T @ (W[:, None] * X), X.T @ (W * r["G"]))
    assert np.isclose(beta[1], r["alpha"]), "加权回归斜率应等于 α"
    assert np.isclose(W @ r["BV"], 0) and np.isclose(W @ r["D"], 0) and np.isclose(W @ (r["BV"] * r["D"]), 0)
    assert np.allclose(r["G"] - r["M"], r["BV"] + r["D"])
    VG = W @ (r["G"] - r["M"]) ** 2; assert np.isclose(VG, r["VA"] + r["VD"])
    print(f"p = {p0}, a = {a}, d = {d0}：M = {r['M']:.4f}，α = {r['alpha']:.4f}（回归核对 {beta[1]:.4f}）")
    print(f"{'基因型':<6s}{'频率':>8s}{'G−M':>9s}{'BV':>9s}{'D':>9s}")
    for k, name in enumerate(["A1A1", "A1A2", "A2A2"]):
        print(f"{name:<6s}{W[k]:8.4f}{r['G'][k]-r['M']:9.4f}{r['BV'][k]:9.4f}{r['D'][k]:9.4f}")
    print(f"V_A = {r['VA']:.4f}，V_D = {r['VD']:.4f}，V_G = {VG:.4f}，V_A/V_G = {r['VA']/VG:.4f}")
    grid = np.arange(cfg["p_grid_step"], 1, cfg["p_grid_step"]); out = {"table": {k: (v.tolist() if isinstance(v, np.ndarray) else float(v)) for k, v in r.items()}, "curves": {}}
    for name, k in cfg["d_over_a"].items():
        d = k * a; VA = np.array([decompose(p, a, d)["VA"] for p in grid]); VD = np.array([decompose(p, a, d)["VD"] for p in grid])
        pmax = float(grid[np.argmax(VA)]); over = grid[VD > VA]
        rng_txt = f"[{over.min():.2f}, {over.max():.2f}]" if over.size else "无"
        out["curves"][name] = {"p_at_max_VA": pmax, "max_VA": float(VA.max()), "VD_gt_VA_range": [float(over.min()), float(over.max())] if over.size else None}
        print(f"{name:<14s} V_A 最大于 p = {pmax:.2f}（V_A = {VA.max():.4f}）；V_D > V_A 的 p 区间：{rng_txt}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex09_15_single_locus_decomposition.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    plt = get_pyplot()
    if plt:
        fig, axs = plt.subplots(1, 2, figsize=(9, 3.6))
        for name, k in cfg["d_over_a"].items():
            d = k * a; axs[0].plot(grid, [decompose(p, a, d)["VA"] for p in grid], label=name)
            axs[1].plot(grid, [decompose(p, a, d)["alpha"] for p in grid], label=name)
        axs[0].set_xlabel("p (A1 频率)"); axs[0].set_ylabel("V_A"); axs[1].set_xlabel("p"); axs[1].set_ylabel("α"); axs[1].axhline(0, c="gray", lw=0.6)
        axs[0].legend(fontsize=7); fig.tight_layout(); fig.savefig(HERE / "results" / "ex09_15_va_alpha.png", dpi=160); plt.close(fig)


if __name__ == "__main__":
    main()
