#!/usr/bin/env python3
"""习题 9.19  连锁不平衡下的边际效应、偏回归效应与加性方差

两个加性位点（无显性、无互作），偏回归（“真实”）效应 α_A、α_B，剂量 x_A、x_B。HWE 且两条配子独立时
    Var(x_A) = 2p_Aq_A，Var(x_B) = 2p_Bq_B，Cov(x_A, x_B) = 2D
    加性方差  V_A = α_A²·2p_Aq_A + α_B²·2p_Bq_B + 2α_Aα_B·2D
    A 的边际效应（只对 x_A 回归）  α_A^marg = α_A + α_B · D/(p_Aq_A)
程序对一组 D 值验证：(1) D 的可行范围；(2) 边际效应与偏回归效应之差；
(3) 用两位点“单倍型”精确枚举 16 种二倍体基因型，以加权回归独立核对上述公式。
"""
from __future__ import annotations
import json
from itertools import product
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def enumerate_genotypes(pA, pB, D):
    h = {"AB": pA * pB + D, "Ab": pA * (1 - pB) - D, "aB": (1 - pA) * pB - D, "ab": (1 - pA) * (1 - pB) + D}
    if min(h.values()) < -1e-12: raise ValueError("D 超出可行范围")
    xa, xb, w = [], [], []
    for h1, h2 in product(h, h):
        xa.append((h1[0] == "A") + (h2[0] == "A")); xb.append((h1[1] == "B") + (h2[1] == "B")); w.append(h[h1] * h[h2])
    return np.array(xa, float), np.array(xb, float), np.array(w)


def main():
    cfg = json.loads((HERE / "data" / "ex09_19_ld.json").read_text(encoding="utf-8"))
    pA, pB, aA, aB = cfg["pA"], cfg["pB"], cfg["alpha_A"], cfg["alpha_B"]; qA, qB = 1 - pA, 1 - pB
    Dmin, Dmax = -min(pA * pB, qA * qB), min(pA * qB, qA * pB)
    print(f"p_A = {pA}, p_B = {pB}，D 的可行范围 [{Dmin:.3f}, {Dmax:.3f}]；α_A = {aA}, α_B = {aB}")
    print(f"{'D':>7s}{'V_A':>9s}{'忽略LD的V_A':>12s}{'α_A边际':>10s}{'α_B边际':>10s}")
    rows = []
    for D in cfg["D_values"]:
        xa, xb, w = enumerate_genotypes(pA, pB, D); g = aA * xa + aB * xb
        mean = lambda v: float(w @ v); cov = lambda u, v: mean((u - mean(u)) * (v - mean(v)))
        VA = cov(g, g); VA_th = aA ** 2 * 2 * pA * qA + aB ** 2 * 2 * pB * qB + 2 * aA * aB * 2 * D
        mA = cov(g, xa) / cov(xa, xa); mB = cov(g, xb) / cov(xb, xb)
        assert np.isclose(VA, VA_th) and np.isclose(mA, aA + aB * D / (pA * qA)) and np.isclose(mB, aB + aA * D / (pB * qB))
        rows.append({"D": D, "VA": VA, "VA_noLD": VA_th - 4 * aA * aB * D, "marg_A": mA, "marg_B": mB})
        print(f"{D:7.3f}{VA:9.4f}{VA_th-4*aA*aB*D:12.4f}{mA:10.4f}{mB:10.4f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex09_19_ld_marginal_partial.json").write_text(json.dumps({"D_range": [Dmin, Dmax], "rows": rows}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
