#!/usr/bin/env python3
"""习题 9.20  育种值的群体基准：纯种内、杂交（配偶为另一品种）与合成群体中的平均效应

单位点 a = 1, d = 2（超显性）。公羊来自品种 A（p_A = 0.8），用于三种场合：
    (1) 纯种繁殖：配偶为品种 A 母羊 → α_A = a + d(q_A − p_A)；
    (2) 杂交：配偶为品种 B 母羊（p_B = 0.2）→ 公羊配子的“平均效应”取决于配偶群体频率：
        α_{A→B} = a + d(q_B − p_B)（Wei & van der Werf 1994 的杂交平均效应思想）；
    (3) 合成系 F2 群体（p = 0.5）→ α = a。
对三只不同基因型的候选公羊，计算其在三种场合下的“传递能力”（配子平均值离差之和的一半），并比较排名。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def gamete_effects(a, d, p_mate):
    """配偶群体等位基因频率为 p_mate 时，A1 与 A2 配子各自产生后代的平均基因型值。"""
    q = 1 - p_mate
    m1 = p_mate * a + q * d          # A1 配子 × 随机配偶配子
    m2 = p_mate * d + q * (-a)       # A2 配子
    return m1, m2


def main():
    cfg = json.loads((HERE / "data" / "ex09_20_breeds.json").read_text(encoding="utf-8"))
    a, d = cfg["a"], cfg["d"]
    settings = {"纯种(配偶 A)": cfg["p_breedA"], "杂交(配偶 B)": cfg["p_breedB"], "合成 F2(p=0.5)": 0.5}
    out = {}
    for name, pm in settings.items():
        m1, m2 = gamete_effects(a, d, pm); alpha = m1 - m2
        assert np.isclose(alpha, a + d * (1 - 2 * pm))
        ta = {}
        for cand, x in cfg["candidates"].items():
            ta[cand] = (x * m1 + (2 - x) * m2) / 2          # 后代平均基因型值（传递能力 + 常数）
        base = np.mean(list(ta.values())); ranks = sorted(ta, key=lambda k: -ta[k])
        out[name] = {"alpha": alpha, "offspring_mean": ta, "ranking": ranks}
        print(f"{name:<12s} α = {alpha:+.2f}；后代平均值：" + "，".join(f"{k} {v:+.2f}" for k, v in ta.items()) + f"；排名 {ranks}")
    print("说明：超显性时，与 A1 频率高的配偶交配，A1 配子的平均效应为负，A2A2 公羊反而最优；与 A1 稀少的品种 B 杂交时排名完全相反。")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex09_20_reference_population.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
