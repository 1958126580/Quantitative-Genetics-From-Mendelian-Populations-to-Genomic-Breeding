#!/usr/bin/env python3
"""习题 9.18  两位点互作的正交分解：V_G = V_A + V_D + V_AA + V_AD + V_DA + V_DD

在 HWE 与连锁平衡下，两位点基因型频率为 f_i^A f_j^B。Cockerham (1954) 正交分解：
以每个位点的“加性”和“显性”正交对比（相对于频率加权内积）为基，构造 9 维加权空间的正交基
    {1, a_A, d_A} ⊗ {1, a_B, d_B}
其中 a = x − 2p（剂量离均差），d = 显性偏差的标准形（−2q², 2pq, −2p² 的方向）。
基因型值在每个基向量上的加权投影平方和即对应方差组分。程序：
    (1) 构造并验证 9 个基向量加权正交；
    (2) 计算各方差组分并验证其和等于 V_G；
    (3) 给出两个位点各自的“边际”平均效应，说明互作为何使边际效应依赖于另一个位点的频率。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def locus_basis(p):
    q = 1 - p; f = np.array([p * p, 2 * p * q, q * q])
    one = np.ones(3); add = np.array([2, 1, 0.0]) - 2 * p; dom = np.array([-2 * q * q, 2 * p * q, -2 * p * p])
    return f, {"1": one, "A": add, "D": dom}


def main():
    cfg = json.loads((HERE / "data" / "ex09_18_twolocus.json").read_text(encoding="utf-8"))
    G = np.array(cfg["genotypic_values"], float)
    fA, bA = locus_basis(cfg["pA"]); fB, bB = locus_basis(cfg["pB"]); W = np.outer(fA, fB)
    ip = lambda u, v: float(np.sum(W * u * v))
    basis = {kA + kB: np.outer(bA[kA], bB[kB]) for kA in bA for kB in bB}
    keys = list(basis)
    for i, k1 in enumerate(keys):
        for k2 in keys[i + 1:]:
            assert abs(ip(basis[k1], basis[k2])) < 1e-12, f"{k1} 与 {k2} 不正交"
    M = ip(G, basis["11"]); comps = {}
    for k in keys:
        if k == "11": continue
        coef = ip(G, basis[k]) / ip(basis[k], basis[k]); comps[k] = coef ** 2 * ip(basis[k], basis[k])
    VG = ip((G - M) ** 2, np.ones_like(G))
    name = {"A1": "V_A(A位点)", "1A": "V_A(B位点)", "D1": "V_D(A位点)", "1D": "V_D(B位点)", "AA": "V_AA", "AD": "V_AD", "DA": "V_DA", "DD": "V_DD"}
    VA = comps["A1"] + comps["1A"]; VD = comps["D1"] + comps["1D"]
    print(f"群体均值 M = {M:.4f}，V_G = {VG:.4f}")
    for k in ("A1", "1A", "D1", "1D", "AA", "AD", "DA", "DD"):
        print(f"  {name[k]:<10s} = {comps[k]:.4f}（占 V_G {comps[k]/VG*100:5.1f}%）")
    tot = sum(comps.values()); assert np.isclose(tot, VG)
    print(f"V_A = {VA:.4f}，V_D = {VD:.4f}，V_I = {comps['AA']+comps['AD']+comps['DA']+comps['DD']:.4f}，合计 = {tot:.4f}")
    # 边际平均效应：A 位点的 α_A = 对 A 剂量的回归（在 B 的频率下平均）
    alphaA = ip(G, basis["A1"]) / ip(basis["A1"], basis["A1"]); alphaB = ip(G, basis["1A"]) / ip(basis["1A"], basis["1A"])
    # 条件效应：固定 B 基因型时 A 的加性效应
    condA = []
    for j in range(3):
        g = G[:, j]; a_ = bA["A"]; condA.append(float(np.sum(fA * g * a_) / np.sum(fA * a_ * a_)))
    print(f"边际平均效应 α_A = {alphaA:.4f}，α_B = {alphaB:.4f}；A 在 BB/Bb/bb 背景下的条件效应 = {np.round(condA,4)}")
    out = {"M": M, "VG": VG, "components": {name[k]: v for k, v in comps.items()}, "VA": VA, "VD": VD, "alphaA": alphaA, "alphaB": alphaB, "alphaA_given_B": condA}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex09_18_two_locus_epistasis.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
