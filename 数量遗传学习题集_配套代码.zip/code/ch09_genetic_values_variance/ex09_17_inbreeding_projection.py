#!/usr/bin/env python3
"""习题 9.17  偏离随机交配时重新定义统计投影：近交群体中的平均效应

近交系数 F 下基因型频率 p² + Fpq, 2pq(1 − F), q² + Fpq；A1 剂量 x 的方差为 2pq(1 + F)。
把“平均效应”定义为基因型值对剂量的（加权）最小二乘回归斜率，可推得
    α_F = a + d (q − p)(1 − F)/(1 + F)，   “加性方差” V_A(F) = 2pq(1 + F) α_F²，
而群体均值 M_F = a(p − q) + 2pq(1 − F)d（近交衰退 −2pqdF）。
程序对一组 F 值：(1) 用加权回归数值计算 α_F 并与公式核对；(2) 计算 V_A(F)、残差（“显性”）方差与总遗传方差；
(3) 说明 F → 1 时 α_1 = a，V_A = 4pqa²，即近交系之间的方差恰为基础群加性方差在 d = 0 时的两倍。
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def main():
    cfg = json.loads((HERE / "data" / "ex09_17_inbred.json").read_text(encoding="utf-8"))
    a, d, p = cfg["a"], cfg["d"], cfg["p"]; q = 1 - p; G = np.array([a, d, -a]); x = np.array([2, 1, 0.0]); rows = []
    print(f"a = {a}, d = {d}, p = {p}")
    print(f"{'F':>5s}{'M_F':>9s}{'α_F(回归)':>11s}{'α_F(公式)':>11s}{'V_A(F)':>9s}{'剩余':>9s}{'V_G':>9s}")
    for F in cfg["F_values"]:
        f = np.array([p * p + F * p * q, 2 * p * q * (1 - F), q * q + F * p * q])
        M = f @ G; X = np.column_stack([np.ones(3), x]); beta = np.linalg.solve(X.T @ (f[:, None] * X), X.T @ (f * G))
        af = a + d * (q - p) * (1 - F) / (1 + F)
        assert np.isclose(beta[1], af), "回归斜率与公式不一致"
        VG = f @ (G - M) ** 2; VA = 2 * p * q * (1 + F) * af ** 2; res = VG - VA
        assert np.isclose(M, a * (p - q) + 2 * p * q * (1 - F) * d)
        rows.append({"F": F, "M": M, "alpha": af, "VA": VA, "residual": res, "VG": VG})
        print(f"{F:5.2f}{M:9.4f}{beta[1]:11.4f}{af:11.4f}{VA:9.4f}{res:9.4f}{VG:9.4f}")
    print(f"F = 1 时 α = a = {a}，V_A = 4pq a² = {4*p*q*a*a:.4f}；F = 0 时 2pq a²（假设 d=0 时）= {2*p*q*a*a:.4f}")
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results" / "ex09_17_inbreeding_projection.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
