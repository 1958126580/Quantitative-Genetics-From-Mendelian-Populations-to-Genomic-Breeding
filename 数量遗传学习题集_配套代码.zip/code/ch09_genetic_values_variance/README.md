# 第9章　数量遗传与群体依赖性——配套程序

运行环境：Python 3.9+，依赖 numpy、scipy、matplotlib（绘图可选）。在本文件夹内逐个运行：

```
python3 ex09_15_single_locus_decomposition.py
python3 ex09_16_multiallele_effects.py
python3 ex09_17_inbreeding_projection.py
python3 ex09_18_two_locus_epistasis.py
python3 ex09_19_ld_marginal_partial.py
python3 ex09_20_reference_population.py
```

输入数据在 `data/`，输出（json、png）写入 `results/`。每个程序都含独立核验（assert），核验失败会中止运行。

| 程序 | 对应习题 | 内容 |
|:--|:--|:--|
| ex09_15_single_locus_decomposition.py | 9.15 | 单位点的完整分解：基因型值、育种值、显性偏差与方差随频率的变化 |
| ex09_16_multiallele_effects.py | 9.16 | 多等位基因位点的平均效应、育种值与方差分解 |
| ex09_17_inbreeding_projection.py | 9.17 | 偏离随机交配时重新定义统计投影：近交群体中的平均效应 |
| ex09_18_two_locus_epistasis.py | 9.18 | 两位点互作的正交分解：V_G = V_A + V_D + V_AA + V_AD + V_DA + V_DD |
| ex09_19_ld_marginal_partial.py | 9.19 | 连锁不平衡下的边际效应、偏回归效应与加性方差 |
| ex09_20_reference_population.py | 9.20 | 育种值的群体基准：纯种内、杂交（配偶为另一品种）与合成群体中的平均效应 |
