# 第十三章　动物模型的扩展 —— 配套代码

**所属**：第三篇　线性混合模型的理论与计算　　**对应正文**：第十三章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch13.ipynb` | IJulia 笔记本：8 个代码单元，约 229 行 Julia 代码，穿插与正文对应的说明 |
| `ch13.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 17 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　重复记录模型（正文 §13.1）
  - 1.1 MPPA 与 EBV 的区别（正文 §13.1.3）
- 2　三种 PE 结构的对照（正文 §13.1.4）
- 3　母体效应模型（正文 §13.2）
- 4　随机回归：Legendre 基与协方差函数（正文 §13.3）
  - 4.1 特征函数分析与降秩（正文 §13.3.4）
- 5　社会互作模型的方差放大（正文式 13.24）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 13
```

或在 Jupyter 中打开 `ch13/ch13.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
