# 本脚本由 tools/nb2jl.py 从同目录的 ch13.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 13

# %% [markdown]
# # 第十三章　动物模型的扩展 —— 配套代码
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | 重复记录模型与 PE 效应 | §13.1 |
# | 2 | 三种 PE 结构的方差—协方差对照 | §13.1.4 |
# | 3 | 母体效应模型与总体遗传效应 | §13.2 |
# | 4 | 随机回归：Legendre 基与协方差函数 | §13.3 |
# | 5 | 社会互作模型的方差放大 | §13.4.1 |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions, BenchmarkTools
rng = Xoshiro(20260918)

# ── 全书通用工具（第九章）────────────────────────────────────────────
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        b = inv(delta)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

function random_pedigree(n::Int; nbase::Int=max(10,n÷50), rng=Random.default_rng())
    sire=zeros(Int,n); dam=zeros(Int,n)
    for i in nbase+1:n; sire[i]=rand(rng,1:i-1); dam[i]=rand(rng,1:i-1); end
    return sire, dam
end

# %% [markdown]
# ## 1　重复记录模型（正文 §13.1）

# %%
sire = [0,0,0,1,1,2,4,4,5,7,7,9]
dam  = [0,0,0,2,3,3,5,6,6,8,8,10]
n = length(sire)
A = build_A(sire, dam); F = diag(A) .- 1
Ainv = build_Ainv(sire, dam, F)

h2, r = 0.25, 0.45
s2P = 100.0
s2a, s2pe, s2e = h2*s2P, (r-h2)*s2P, (1-r)*s2P
lam_a, lam_pe = s2e/s2a, s2e/s2pe
@printf("h2=%.2f, r=%.2f  =>  s2a=%.1f, s2pe=%.1f, s2e=%.1f\n", h2, r, s2a, s2pe, s2e)
@printf("lambda_a = (1-r)/h2 = %.3f ,  lambda_pe = (1-r)/(r-h2) = %.3f\n", lam_a, lam_pe)
@printf("验证式 (13.5): %s\n\n",
        (isapprox(lam_a,(1-r)/h2) && isapprox(lam_pe,(1-r)/(r-h2))) ? "通过" : "不一致")

rr = Xoshiro(21)
u  = cholesky(Symmetric(A + 1e-10I)).L * randn(rr, n) .* sqrt(s2a)
pe = randn(rr, n) .* sqrt(s2pe)
recA = Int[]; recY = Float64[]; recYear = Int[]
for i in 4:n
    for k in 1:rand(rr, 1:3)
        push!(recA, i); push!(recYear, rand(rr,1:3))
        push!(recY, 20.0 + 2.0*recYear[end] + u[i] + pe[i] + randn(rr)*sqrt(s2e))
    end
end
nr = length(recY)
@printf("共 %d 条记录，来自 %d 个个体\n", nr, length(unique(recA)))

X = sparse(1:nr, recYear, ones(nr), nr, 3)
Z = sparse(1:nr, recA,    ones(nr), nr, n)
W = Z
LHS = [Matrix(X'X)            Matrix(X'Z)              Matrix(X'W);
       Matrix(Z'X)  Matrix(Z'Z)+lam_a*Matrix(Ainv)     Matrix(Z'W);
       Matrix(W'X)            Matrix(W'Z)      Matrix(W'W)+lam_pe*I]
RHS = vcat(Vector(X'recY), Vector(Z'recY), Vector(W'recY))
sol = LHS \ RHS
uhat  = sol[4:3+n]; pehat = sol[4+n:end]

println("\n", rpad("个体",6), rpad("记录数",9), rpad("真 u",11), rpad("EBV",11), rpad("真 pe",11), "pe_hat")
println("-"^60)
for i in 4:n
    ni = count(==(i), recA)
    @printf("%-6d%-9d%+-11.3f%+-11.3f%+-11.3f%+.3f\n", i, ni, u[i], uhat[i], pe[i], pehat[i])
end
@printf("\ncor(uhat, u) = %.4f ;  cor(pehat, pe) = %.4f\n",
        cor(uhat[4:n], u[4:n]), cor(pehat[4:n], pe[4:n]))

# %% [markdown]
# ### 1.1 MPPA 与 EBV 的区别（正文 §13.1.3）

# %%
mppa(n_i, r, Pbar, mu) = mu + n_i*r/(1 + (n_i-1)*r)*(Pbar - mu)
mu_bar = mean(recY)
println(rpad("个体",6), rpad("n",5), rpad("平均表型",13), rpad("MPPA",13), rpad("EBV",13), "说明")
println("-"^64)
for i in 4:min(9,n)
    idx = findall(==(i), recA); ni = length(idx)
    Pbar = mean(recY[idx])
    @printf("%-6d%-5d%-13.3f%-13.3f%+-13.3f%s\n", i, ni, Pbar, mppa(ni, r, Pbar, mu_bar), uhat[i],
            ni >= 2 ? "多条记录" : "单条记录")
end
println("\n=> MPPA 预测个体自身未来表现（含 u+pe）；EBV 预测传递给后代的部分（只含 u）。")
println("   用 MPPA 选种是错误的；用它做淘汰决策是正确的。")

# %% [markdown]
# ## 2　三种 PE 结构的对照（正文 §13.1.4）

# %%
function pe_structures(k, l, s2a, s2pe, s2e; rho=0.7)
    common = (var_k = s2a + s2pe + s2e,        cov_kl = s2a + s2pe)
    cumul  = (var_k = s2a + k*s2pe + s2e,      cov_kl = s2a + min(k,l)*s2pe)
    ar1    = (var_k = s2a + s2pe + s2e,        cov_kl = s2a + rho^abs(k-l)*s2pe)
    return common, cumul, ar1
end

println(rpad("记录对 (k,l)", 16), rpad("常规 PE", 22), rpad("累积 PE", 22), "AR(1), rho=0.7")
println("-"^84)
for (k,l) in ((1,1),(2,2),(3,3),(1,2),(1,3),(2,3))
    c, cu, a = pe_structures(k, l, s2a, s2pe, s2e)
    f(x) = k==l ? @sprintf("Var=%.1f", x.var_k) : @sprintf("Cov=%.1f", x.cov_kl)
    @printf("%-16s%-22s%-22s%s\n", "($k,$l)", f(c), f(cu), f(a))
end
println("\n=> 累积 PE 的特征是方差随记录序号递增 —— 这是检验它是否适用的依据。")
println("   第二版断言「累积 PE 模型通常更适合」过强；应由似然比较决定（第十七章）。")

# %% [markdown]
# ## 3　母体效应模型（正文 §13.2）

# %%
G0 = [100.0 -30.0; -30.0 64.0]
r_dm = G0[1,2]/sqrt(G0[1,1]*G0[2,2])
s2T  = G0[1,1] + G0[1,2] + 0.25*G0[2,2]

@printf("s2_ad = %.1f ,  s2_am = %.1f ,  s_adm = %.1f ,  r_dm = %+.3f\n",
        G0[1,1], G0[2,2], G0[1,2], r_dm)
@printf("总体遗传方差 s2T = s2_ad + s_adm + 0.25*s2_am = %.1f\n", s2T)
@printf("s2T / s2_ad = %.3f\n\n", s2T/G0[1,1])

println("【r_dm 对 s2T 的影响】")
println(rpad("r_dm", 10), rpad("s_adm", 12), rpad("s2T", 12), "s2T/s2_ad")
println("-"^46)
for rdm in (0.5, 0.2, 0.0, -0.2, -0.5, -0.8)
    sdm = rdm*sqrt(G0[1,1]*G0[2,2])
    sT  = G0[1,1] + sdm + 0.25*G0[2,2]
    @printf("%+-10.2f%+-12.1f%-12.1f%.3f\n", rdm, sdm, sT, sT/G0[1,1])
end
println("\n=> s_adm 以系数 1（而非 1/2）进入 —— 这是肉牛断奶重选择反应低于预期的原因。")

s6, d6 = [0,0,1,1,3,3], [0,0,2,2,4,4]
A6 = build_A(s6, d6); F6 = diag(A6).-1; Ai6 = build_Ainv(s6, d6, F6)
@printf("\n【验证式 (3.24)】norm((G0 kron A)^-1 - G0^-1 kron A^-1) = %.3e\n",
        norm(inv(kron(G0, A6)) - kron(inv(G0), Matrix(Ai6))))

# %% [markdown]
# ## 4　随机回归：Legendre 基与协方差函数（正文 §13.3）

# %%
"""
    legendre_basis(t, k; tmin, tmax)

标准化 Legendre 多项式基（式 13.18）。t 被映射到 [-1, 1]。
"""
function legendre_basis(t::Real, k::Int; tmin=5.0, tmax=305.0)
    x = 2*(t - tmin)/(tmax - tmin) - 1
    phi = zeros(k+1)
    phi[1] = sqrt(0.5)
    k >= 1 && (phi[2] = sqrt(1.5)*x)
    k >= 2 && (phi[3] = 0.5*sqrt(2.5)*(3x^2 - 1))
    k >= 3 && (phi[4] = 0.5*sqrt(3.5)*(5x^3 - 3x))
    k >= 4 && (phi[5] = 0.125*sqrt(4.5)*(35x^4 - 30x^2 + 3))
    return phi
end

k = 2
ts = [5.0, 50.0, 100.0, 150.0, 200.0, 250.0, 305.0]
println("Legendre 基（k = $k）:")
println(rpad("t (天)", 10), join([rpad("phi$(m-1)", 13) for m in 1:k+1]))
println("-"^50)
for t in ts
    phi = legendre_basis(t, k)
    @printf("%-10.0f%s\n", t, join([@sprintf("%-13.5f", phi[m]) for m in 1:k+1]))
end

# 正交性：用高斯求积数值验证
function legendre_raw(x, m)
    m == 0 && return sqrt(0.5)
    m == 1 && return sqrt(1.5)*x
    m == 2 && return 0.5*sqrt(2.5)*(3x^2-1)
    m == 3 && return 0.5*sqrt(3.5)*(5x^3-3x)
    error("未实现")
end
# 复合 Simpson 数值积分
function simpson(f, a, b; n=2000)
    h = (b-a)/n; s = f(a) + f(b)
    for i in 1:n-1
        s += (isodd(i) ? 4 : 2) * f(a + i*h)
    end
    return s*h/3
end
println("\n正交性检验（数值积分 int phi_i phi_j dx over [-1,1]）:")
for i in 0:k, j in i:k
    val = simpson(x -> legendre_raw(x,i)*legendre_raw(x,j), -1.0, 1.0)
    @printf("  int phi%d phi%d = %+.6f   %s\n", i, j, val,
            abs(val - (i==j ? 1.0 : 0.0)) < 1e-6 ? "OK" : "")
end

Ka = [12.0  -2.0  0.5;
      -2.0   3.0 -0.4;
       0.5  -0.4  1.2]
println("\n遗传协方差函数 K(t1,t2) = phi(t1)' Ka phi(t2):")
println(rpad("t", 8), join([rpad(@sprintf("%.0f", t), 11) for t in ts]))
println("-"^85)
for t1 in ts
    row = [dot(legendre_basis(t1,k), Ka*legendre_basis(t2,k)) for t2 in ts]
    @printf("%-8.0f%s\n", t1, join([@sprintf("%-11.3f", v) for v in row]))
end
@printf("\n参数个数：完整多性状 %d 个测定日需 %d 个；随机回归 k=%d 只需 %d 个。\n",
        length(ts), length(ts)*(length(ts)+1)÷2, k, (k+1)*(k+2)÷2)

# %% [markdown]
# ### 4.1 特征函数分析与降秩（正文 §13.3.4）

# %%
ev = eigen(Symmetric(Ka))
lams = reverse(ev.values); V = reverse(ev.vectors, dims=2)
@printf("Ka 的特征值 = %s\n", string(round.(lams, digits=4)))
@printf("累积解释比例 = %s\n", string(round.(cumsum(lams)./sum(lams), digits=4)))
println("\n特征函数 psi_k(t) = phi(t)' v_k :")
println(rpad("t", 8), rpad("psi1", 13), rpad("psi2", 13), "psi3")
println("-"^47)
for t in ts
    phi = legendre_basis(t, k)
    @printf("%-8.0f%-13.5f%-13.5f%.5f\n", t, dot(phi,V[:,1]), dot(phi,V[:,2]), dot(phi,V[:,3]))
end
@printf("\n=> 保留前 2 个成分可解释 %.1f%% 的遗传方差，可降秩到 r=2。\n", 100*sum(lams[1:2])/sum(lams))

w = [simpson(t -> legendre_basis(t, k)[m], 5.0, 305.0) for m in 1:k+1]
println("\n305 天产量的权重 w = int phi(t) dt = ", round.(w, digits=4))
@printf("其遗传方差 = w' Ka w = %.3f\n", dot(w, Ka*w))

# %% [markdown]
# ## 5　社会互作模型的方差放大（正文式 13.24）

# %%
sTBV(s2D, sDS, s2S, n) = s2D + 2*(n-1)*sDS + (n-1)^2*s2S

println("【总体遗传方差随栏内个体数的变化】s2D=100, sDS=-5, s2S=1")
println(rpad("栏内个体数 n", 18), rpad("s2_TBV", 14), "相对 s2D")
println("-"^46)
for n in (1, 2, 4, 6, 8, 10, 12, 16)
    v = sTBV(100.0, -5.0, 1.0, n)
    @printf("%-18d%-14.1f%.2f x\n", n, v, v/100)
end
println("\n【s2S 的敏感性】n = 12")
for s2 in (0.0, 0.25, 0.5, 1.0, 2.0)
    @printf("  s2S = %.2f  ->  s2_TBV = %8.1f   (%.2f x s2D)\n",
            s2, sTBV(100.0,-5.0,s2,12), sTBV(100.0,-5.0,s2,12)/100)
end
println("\n=> 社会效应以 (n-1)^2 的系数进入：即使 s2S 很小，在 n=12 的栏中也放大 121 倍。")
println("   忽略社会效应可能严重低估可利用的遗传变异（正文 §13.4.1）。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **$\lambda_a=(1-r)/h^2$、$\lambda_{pe}=(1-r)/(r-h^2)$** 已验证；后者的正定性直接要求 $r>h^2$。
# 2. **MPPA 含 $u+pe$，EBV 只含 $u$** —— 用途完全不同。
# 3. **三种 PE 结构的方差—协方差模式截然不同**；累积 PE 的特征是方差随记录序号递增。
# 4. **母体效应中 $\sigma_{a_da_m}$ 以系数 1 进入 $\sigma_T^2$**；强负相关时总体遗传方差可远小于直接遗传方差。
# 5. **Legendre 基的正交性已数值验证**；协方差函数把 $T(T+1)/2$ 个参数压缩为 $(k+1)(k+2)/2$ 个。
# 6. **社会互作的 $(n-1)^2\sigma_S^2$ 项极大放大总体遗传方差**。
