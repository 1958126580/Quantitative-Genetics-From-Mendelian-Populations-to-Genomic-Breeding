# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex4.py    依赖：numpy, scipy
import numpy as np
from numpy.polynomial import legendre as L
from scipy.integrate import quad
np.set_printoptions(precision=4, suppress=True, linewidth=200)
def phi(x,k):  # normalized Legendre, orders 0..k
    x=np.atleast_1d(np.asarray(x,float))
    P=np.zeros((len(x),k+1)); P[:,0]=1.0
    if k>=1: P[:,1]=x
    for m in range(2,k+1): P[:,m]=((2*m-1)*x*P[:,m-1]-(m-1)*P[:,m-2])/m
    nrm=np.sqrt((2*np.arange(k+1)+1)/2.0)
    return P*nrm
tmin,tmax=5.0,305.0
def tx(t): return 2*(np.asarray(t,float)-tmin)/(tmax-tmin)-1
print("--- normalized Legendre values (k=0..3) ---")
for t in [5,35,65,95,125,155,185,215,245,275,305]:
    x=tx(t); v=phi(x,3)[0]
    print(f" t={t:5.0f}  x={float(x):+.4f}   "+"  ".join(f"{z:+.4f}" for z in v))
print("\n--- orthonormality on [-1,1] ---")
for i in range(4):
    row=[quad(lambda x,i=i,j=j: phi(x,3)[0,i]*phi(x,3)[0,j],-1,1)[0] for j in range(4)]
    print(" ".join(f"{z:+.6f}" for z in row))
print("\nint_{-1}^{1} phi_m dx :",[round(quad(lambda x,m=m: phi(x,3)[0,m],-1,1)[0],6) for m in range(4)])
print("=> w = int_5^305 phi(t)dt = (tmax-tmin)/2 * above =",
      [round((tmax-tmin)/2*quad(lambda x,m=m: phi(x,3)[0,m],-1,1)[0],4) for m in range(4)])
print("sqrt(1/2)*2*150 =",np.sqrt(0.5)*2*150)
td=np.arange(15,300,30.0); print("\ntest days:",td)
Phi=phi(tx(td),3); print("Phi (10x4):\n",Phi)
print("Phi'Phi:\n",Phi.T@Phi)
print("cond(Phi'Phi) Legendre:",np.linalg.cond(Phi.T@Phi))
Raw=np.vstack([td**m for m in range(4)]).T
print("cond(raw t^m, t in days):",np.linalg.cond(Raw.T@Raw))
Raw2=np.vstack([tx(td)**m for m in range(4)]).T
print("cond(raw x^m, x in [-1,1]):",np.linalg.cond(Raw2.T@Raw2))
for k in (3,5,7):
    P=phi(tx(td),k); R=np.vstack([tx(td)**m for m in range(k+1)]).T
    print(f" k={k}: cond(Legendre)={np.linalg.cond(P.T@P):10.2f}  cond(raw x^m)={np.linalg.cond(R.T@R):12.2f}  cond(raw t^m)={np.linalg.cond((np.vstack([td**m for m in range(k+1)]).T).T@np.vstack([td**m for m in range(k+1)]).T):.3e}")
