# 第 13 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch13/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `ex1.py` | ---------- pedigree & A^-1 (Henderson rules, no inbreeding here) ---------- | numpy | 1.4 | `outputs/ex1.out` |
| `ex1b.py` | 数值复核 | numpy | 1.1 | `outputs/ex1b.out` |
| `ex1c.py` | 数值复核 | numpy | 1.3 | `outputs/ex1c.out` |
| `ex2.py` | 数值复核 | numpy, scipy | 6.9 | `outputs/ex2.out` |
| `ex4.py` | 数值复核 | numpy, scipy | 7.4 | `outputs/ex4.out` |
| `ex5.py` | 数值复核 | numpy | 1.1 | `outputs/ex5.out` |
| `ex6.py` | classic thought-question check | numpy | 1.1 | `outputs/ex6.out` |
| `ex7.py` | 数值复核 | numpy, sympy | 8.1 | `outputs/ex7.out` |
| `ex8.py` | ---- rank deficiency with fixed group effects ---- | numpy | 3.0 | `outputs/ex8.out` |
| `ex9.py` | grandparents | numpy | 6.9 | `outputs/ex9.out` |
| `rr_test.py` | 数值复核 | numpy, scipy | 7.1 | `outputs/rr_test.out` |
| `s1c1_check.py` | 数值复核 | numpy, scipy | 8.3 | `outputs/s1c1_check.out` |
| `s1c_test.py` | unit test: reduced (between/within) REML equals record-level dense REML on a small data set | numpy, scipy | 5.6 | `outputs/s1c_test.out` |
| `s2a_fisher.py` | S2a: expected (Fisher) REML information for the direct-maternal model for a grid of designs with ~constant number of calf records. | numpy, scipy | 36.5 | `outputs/s2a_fisher.out` |
| `s2a_fisher2.py` | S2a (final): Fisher information of the direct-maternal REML for designs with equal expected number of records (~900). | numpy, scipy | 39.8 | `outputs/s2a_fisher2.out` |
| `s2a_post.py` | 数值复核 | numpy, scipy | 6.5 | `outputs/s2a_post.out` |
| `s2c.py` | S2c: exact parent-offspring phenotypic covariances under the direct-maternal model, three ways: | numpy, scipy | 18.5 | `outputs/s2c.out` |

公共函数模块（被上列脚本导入，不单独运行）：`common.py`、`mat_lib.py`、`reml_rep.py`、`rr_lib.py`。
