# -*- coding: utf-8 -*-
"""REML for the repeated-records model (and its misspecified version without PE) via the exact between/within
factorisation of the likelihood (overall mean as the only fixed effect):
 within-animal part: df_W = sum(k_i-1), SSW -> sigma_e^2
 between part      : ybar_i = mu + a_i + (pe_i + ebar_i),  Var = s2a*A + diag(s2pe + s2e/k_i)  (pe term dropped in the misspecified model).
Equal k: A = Q L Q' once, O(n) per likelihood. Unequal k: dense Cholesky."""
from common import *
from scipy.optimize import minimize

def nll_eigen(par, z, w, lam, k, n, SSW, with_pe):
    if with_pe:
        s2a, s2pe, s2e = par
    else:
        s2a, s2e = par; s2pe = 0.0
    if s2a <= 0 or s2e <= 0 or s2pe < 0: return 1e10
    v = s2a * lam + s2pe + s2e / k
    sw = np.sum(w * w / v)
    mu = np.sum(w * z / v) / sw
    r = z - w * mu
    ll_b = -0.5 * (np.sum(np.log(v)) + np.log(sw) + np.sum(r * r / v))
    dfw = n * (k - 1)
    ll_w = -0.5 * (dfw * np.log(s2e) + SSW / s2e) if dfw > 0 else 0.0
    return -(ll_b + ll_w)

def fit_eigen(Y, lam, Q, with_pe, starts=None):
    n, k = Y.shape
    ybar = Y.mean(1)
    SSW = np.sum((Y - ybar[:, None]) ** 2)
    z = Q.T @ ybar; w = Q.T @ np.ones(n)
    best = None
    if with_pe:
        starts = starts or [(0.15, 0.2, 0.6), (0.3, 0.05, 0.4), (0.05, 0.4, 0.5)]
        bounds = [(1e-6, 5), (1e-9, 5), (1e-6, 5)]
    else:
        starts = starts or [(0.3, 0.6), (0.15, 0.8), (0.5, 0.3)]
        bounds = [(1e-6, 5), (1e-6, 5)]
    for s0 in starts:
        r = minimize(nll_eigen, s0, args=(z, w, lam, k, n, SSW, with_pe), method='L-BFGS-B', bounds=bounds)
        if best is None or r.fun < best.fun: best = r
    return best.x, -best.fun

def nll_dense(par, ybar, kk, A, SSW, dfw, with_pe):
    if with_pe:
        s2a, s2pe, s2e = par
    else:
        s2a, s2e = par; s2pe = 0.0
    if s2a <= 0 or s2e <= 0 or s2pe < 0: return 1e10
    n = len(ybar)
    V = s2a * A
    V[np.diag_indices(n)] += s2pe + s2e / kk
    try:
        cf = sla.cho_factor(V, lower=True)
    except Exception:
        return 1e10
    one = np.ones(n)
    Vi1 = sla.cho_solve(cf, one); Viy = sla.cho_solve(cf, ybar)
    sw = one @ Vi1
    mu = (one @ Viy) / sw
    logdet = 2 * np.sum(np.log(np.diag(cf[0])))
    q = ybar @ Viy - mu * mu * sw      # (y-mu1)'V^{-1}(y-mu1)
    ll_b = -0.5 * (logdet + np.log(sw) + q)
    ll_w = -0.5 * (dfw * np.log(s2e) + SSW / s2e) if dfw > 0 else 0.0
    return -(ll_b + ll_w)

def fit_dense(ybar, kk, SSW, dfw, A, with_pe, x0=None):
    if with_pe:
        starts = [x0] if x0 is not None else [(0.15, 0.2, 0.6)]
        bounds = [(1e-6, 5), (1e-9, 5), (1e-6, 5)]
    else:
        starts = [x0] if x0 is not None else [(0.3, 0.6)]
        bounds = [(1e-6, 5), (1e-6, 5)]
    best = None
    for s0 in starts:
        r = minimize(nll_dense, s0, args=(ybar, kk, A, SSW, dfw, with_pe), method='L-BFGS-B', bounds=bounds,
                     options=dict(ftol=1e-10, gtol=1e-7))
        if best is None or r.fun < best.fun: best = r
    return best.x, -best.fun
