# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex7.py    依赖：numpy, sympy
import numpy as np, sympy as sp
sd,sm,cdm,c,SP=sp.symbols('sigma_d2 sigma_m2 sigma_dm c sigma_P2',positive=True)
CovAdP = sd + sp.Rational(1,2)*cdm
CovAmP = cdm + sp.Rational(1,2)*sm
T = sd + 2*c*cdm + c**2*sm            # Var(A_d + c A_m)
CovTP = CovAdP + c*CovAmP
print("Cov(A_d,P)=",CovAdP,"  Cov(A_m,P)=",CovAmP)
print("Cov(T,P)=",sp.expand(CovTP))
print("Var(T) =",sp.expand(T))
eq=sp.factor(sp.expand(CovTP-T))
print("Cov(T,P)-Var(T) =",eq, "  roots c:",sp.solve(sp.Eq(CovTP,T),c))
print("at c=1/2: Var(T)=",sp.expand(T.subs(c,sp.Rational(1,2))),"  Cov(T,P)=",sp.expand(CovTP.subs(c,sp.Rational(1,2))))
print("Willham numerator Cov(A_d+A_m,P)=",sp.expand(CovAdP+CovAmP))
print("Var(P) =", sd+cdm+sm, "(+pe+e)")

# ---- Monte-Carlo check of the covariance identities & one-generation response ----
rng=np.random.default_rng(7)
N=400000
sad,sam,cov,spem,se=150.,90.,-40.,40.,350.
G=np.array([[sad,cov],[cov,sam]]); Lc=np.linalg.cholesky(G)
par=(Lc@rng.standard_normal((2,2*N))).T            # 2N unrelated parents
sire=par[:N]; dam=par[N:]
ms=(np.linalg.cholesky(0.5*G)@rng.standard_normal((2,N))).T   # Mendelian sampling, Var=G/2
off=0.5*(sire+dam)+ms
pem=rng.standard_normal(N)*np.sqrt(spem)
P=off[:,0]+dam[:,1]+pem+rng.standard_normal(N)*np.sqrt(se)
print("\nMC: Var(P)=",P.var()," theory=",sad+cov+sam+spem+se)
print("MC Cov(A_d,P)=",np.cov(off[:,0],P)[0,1]," theory=",sad+0.5*cov)
print("MC Cov(A_m,P)=",np.cov(off[:,1],P)[0,1]," theory=",cov+0.5*sam)
Tv=off[:,0]+0.5*off[:,1]
print("MC Var(T)=",Tv.var()," theory=",sad+cov+0.25*sam,"  MC Cov(T,P)=",np.cov(Tv,P)[0,1])
print("MC Cov(A_d+A_m,P)=",np.cov(off[:,0]+off[:,1],P)[0,1]," theory=",sad+1.5*cov+0.5*sam)
# truncation selection: top 20%
thr=np.quantile(P,0.8); sel=P>=thr; S=P[sel].mean()-P.mean()
print("S=",S," dd=",off[sel,0].mean()," dm=",off[sel,1].mean())
print("pred dd=",(sad+0.5*cov)/P.var()*S," pred dm=",(cov+0.5*sam)/P.var()*S)
print("Delta mu pred = h2T*S =",(sad+1.5*cov+0.5*sam)/P.var()*S," observed dd+dm=",off[sel,0].mean()+off[sel,1].mean())
print("Delta Tbar pred = (sigma_T2/sP2)*S =",(sad+cov+0.25*sam)/P.var()*S," observed=",Tv[sel].mean())
