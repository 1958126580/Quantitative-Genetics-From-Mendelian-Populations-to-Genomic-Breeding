# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 rr_test.py    依赖：scipy
from rr_lib import *
import time
Ka = np.array([[3.0, -0.5, 0.2], [-0.5, 1.2, -0.1], [0.2, -0.1, 0.4]])
Kp = np.array([[4.0, -0.6, 0.3], [-0.6, 1.5, -0.2], [0.3, -0.2, 0.6]])
s2e = 4.0
print('eig Ka', np.linalg.eigvalsh(Ka), 'eig Kp', np.linalg.eigvalsh(Kp))
print('n_params k=0..4', [n_params(k) for k in range(5)])
rng = np.random.default_rng(1)
Y = simulate(100, 20, Ka, Kp, s2e, rng)
MSB, MSW, dfB, dfW, m = mstats(Y)
mod = RRModel(2)
th0 = mod.start(MSB, MSW, m)
# gradient check
from scipy.optimize import approx_fprime, check_grad
f = lambda t: mod.nll_grad(t, MSB, MSW, dfB, dfW, m)[0]
g = lambda t: mod.nll_grad(t, MSB, MSW, dfB, dfW, m)[1]
th_r = th0 + 0.1 * rng.standard_normal(len(th0))
print('grad check (rel err):', np.linalg.norm(approx_fprime(th_r, f, 1e-6) - g(th_r)) / np.linalg.norm(g(th_r)))
t0 = time.time()
r = mod.fit(MSB, MSW, dfB, dfW, m)
print('fit time', time.time() - t0, 'nit', r.nit, 'fun', r.fun, 'success', r.success)
Kah, Kph, s2eh = mod.Ks(r.x)
print('Ka hat\n', np.round(Kah, 3), '\nKp hat\n', np.round(Kph, 3), '\ns2e hat', s2eh)
for k in range(5):
    mm = RRModel(k); t0 = time.time(); rr = mm.fit(MSB, MSW, dfB, dfW, m)
    print('order', k, 'npar', mm.npar, 'logLR(-fun)=%.3f' % (-rr.fun), 'nit', rr.nit, 'time %.2f' % (time.time() - t0))
