# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex1c.py    依赖：numpy
import numpy as np
np.set_printoptions(precision=4, suppress=True, linewidth=170)
def Amat(ped,n):
    A=np.zeros((n,n))
    for i in range(1,n+1):
        s,d=ped[i]
        for j in range(1,i+1):
            if j==i: A[i-1,i-1]=1+(0.5*A[s-1,d-1] if (s and d) else 0)
            else:
                a=0.0
                if s:a+=0.5*A[s-1,j-1]
                if d:a+=0.5*A[d-1,j-1]
                A[i-1,j-1]=A[j-1,i-1]=a
    return A
ped={1:(0,0),2:(0,0),3:(0,0),4:(0,0),5:(1,3),6:(1,4),7:(2,3),8:(2,4)}
n=8; A=Amat(ped,n); Ai=np.linalg.inv(A)
print("A=\n",A); print("Ainv=\n",Ai)
rec=[(5,1,8.4),(5,2,9.1),(5,3,9.6),(6,1,7.9),(6,2,8.6),
     (7,1,7.2),(7,2,8.0),(7,3,8.5),(8,1,8.9),(8,2,9.8)]
cows=[5,6,7,8]; nr=len(rec)
X=np.zeros((nr,3));Z=np.zeros((nr,n));W=np.zeros((nr,4));y=np.zeros(nr)
for k,(a,p,v) in enumerate(rec):
    X[k,p-1]=1;Z[k,a-1]=1;W[k,cows.index(a)]=1;y[k]=v
h2,r=0.25,0.45; sa,spe,se=h2,r-h2,1-r; la,lpe=se/sa,se/spe
print("lam_a,lam_pe:",la,lpe)
print("parity means:",[round(np.mean([v for a,p,v in rec if p==q]),4) for q in (1,2,3)])
print("cow means:",[round(np.mean([v for a,p,v in rec if a==c]),4) for c in cows])
C=np.block([[X.T@X,X.T@Z,X.T@W],[Z.T@X,Z.T@Z+Ai*la,Z.T@W],[W.T@X,W.T@Z,W.T@W+np.eye(4)*lpe]])
rhs=np.concatenate([X.T@y,Z.T@y,W.T@y])
sol=np.linalg.solve(C,rhs); b,u,pe=sol[:3],sol[3:3+n],sol[3+n:]
print("\nbeta(parity):",np.round(b,4)); print("EBV:",np.round(u,4)); print("PE:",np.round(pe,4))
rs=y-X@b-Z@u
for i,a in enumerate(cows):
    idx=[k for k,(aa,p,v) in enumerate(rec) if aa==a]; ni=len(idx); eb=rs[idx].mean()
    print(f" cow {a}: n={ni} ebar*={eb:.6f} n*ebar/(n+lpe)={ni*eb/(ni+lpe):.6f} pe={pe[i]:.6f}")
eh=y-X@b-Z@u-W@pe
print("X'e:",np.abs(X.T@eh).max(),"Z'e-la*Ai*u:",np.abs(Z.T@eh-la*Ai@u).max(),
      "W'e-lpe*pe:",np.abs(W.T@eh-lpe*pe).max(),"sum base EBV:",u[:4].sum())
Ci=np.linalg.inv(C); pev=np.diag(Ci)[3:3+n]*se; rel=1-pev/sa
print("PEV:",np.round(pev,4)); print("R2:",np.round(rel,4)); print("acc:",np.round(np.sqrt(rel),4))
print("MPPA(2nd parity):",[round(b[1]+u[c-1]+pe[i],4) for i,c in enumerate(cows)])
print("EBV-only pred(2nd parity):",[round(b[1]+u[c-1],4) for i,c in enumerate(cows)])
# ---- no PE ----
C2=np.block([[X.T@X,X.T@Z],[Z.T@X,Z.T@Z+Ai*la]]); rhs2=np.concatenate([X.T@y,Z.T@y])
s2=np.linalg.solve(C2,rhs2); b2,u2=s2[:3],s2[3:]
print("\nno-PE beta:",np.round(b2,4)); print("no-PE EBV:",np.round(u2,4))
print("ratio:",np.round(u2/np.where(np.abs(u)<1e-12,np.nan,u),4))
pev2=np.diag(np.linalg.inv(C2))[3:]*se
print("no-PE R2:",np.round(1-pev2/sa,4))
print("max |EBV| PE vs noPE:",np.abs(u).max(),np.abs(u2).max())
# rank of cows
print("rank PE:",np.argsort(-u[4:]) ,"rank noPE:",np.argsort(-u2[4:]))
