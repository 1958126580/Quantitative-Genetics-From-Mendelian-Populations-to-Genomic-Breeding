# -*- coding: utf-8 -*-
"""Maternal-effect model library: design generator, covariance components, Fisher information, AI-REML (dense)."""
from common import *

PAR = dict(s2ad=100.0, r_dm=-0.5, s2am=60.0, s2pem=40.0, sig2P=400.0)
def true_theta():
    s2ad, s2am, s2pem = PAR['s2ad'], PAR['s2am'], PAR['s2pem']
    cov = PAR['r_dm'] * np.sqrt(s2ad * s2am)
    s2e = PAR['sig2P'] - s2ad - s2am - cov - s2pem      # Var(P)=s2ad+s2am+cov+s2pem+s2e (non-inbred)
    return np.array([s2ad, cov, s2am, s2pem, s2e])

def maternal_design(G, Nd, n_o, f, rng, sires_per_dam=5):
    """G calf generations; Nd dams per generation each with n_o calves; sires are fresh unrelated founders each generation;
    next generation's Nd dams are a random subset of the calves; a retained dam's own record is kept with prob f."""
    sire, dam, gen = [], [], []
    has_rec = []
    def new(s, d, g, rec):
        sire.append(s); dam.append(d); gen.append(g); has_rec.append(rec); return len(sire) - 1
    dams_cur = [new(-1, -1, 0, False) for _ in range(Nd)]
    S = max(3, int(round(Nd / sires_per_dam)))
    for g in range(1, G + 1):
        sires_g = [new(-1, -1, g, False) for _ in range(S)]
        calves = []
        for d in dams_cur:
            for j in range(n_o):
                calves.append(new(int(rng.choice(sires_g)), d, g, True))
        if g < G:
            keep = rng.choice(len(calves), size=Nd, replace=False)
            dams_cur = [calves[i] for i in keep]
            for i in dams_cur:
                if rng.random() > f: has_rec[i] = False
    return np.array(sire), np.array(dam), np.array(gen), np.array(has_rec)

def components(sire, dam, has_rec):
    """Return A, record index vector, and the five unit-coefficient V_i matrices (record level)."""
    A = A_dense(sire, dam)
    rec = np.where(has_rec)[0]
    di = rec
    mi = dam[rec]
    Add = A[np.ix_(di, di)]
    Adm = A[np.ix_(di, mi)]
    Amm = A[np.ix_(mi, mi)]
    same_dam = (mi[:, None] == mi[None, :]).astype(float)
    N = len(rec)
    Vs = [Add, Adm + Adm.T, Amm, same_dam, np.eye(N)]
    return A, rec, mi, Vs

def build_V(theta, Vs):
    V = np.zeros_like(Vs[0])
    for t, Vi in zip(theta, Vs): V += t * Vi
    return V

def fisher_info(theta, Vs):
    N = Vs[0].shape[0]
    V = build_V(theta, Vs)
    cf = sla.cho_factor(V)
    Vi = sla.cho_solve(cf, np.eye(N))
    one = np.ones(N); Vi1 = Vi @ one
    P = Vi - np.outer(Vi1, Vi1) / (one @ Vi1)
    M = [P @ Vi_ for Vi_ in Vs]
    k = len(Vs)
    I = np.zeros((k, k))
    for i in range(k):
        for j in range(i, k):
            I[i, j] = I[j, i] = 0.5 * np.sum(M[i] * M[j].T)
    return I

def sd_from_info(I, theta):
    """SDs of the five parameters, corr matrix, and SD of r_dm by delta method. Returns None if singular."""
    w = np.linalg.eigvalsh(I)
    if w.min() <= 1e-9 * w.max():
        return None
    C = np.linalg.inv(I)
    sd = np.sqrt(np.diag(C))
    corr = C / np.outer(sd, sd)
    a, c, m = theta[0], theta[1], theta[2]
    r = c / np.sqrt(a * m)
    g = np.zeros(5); g[0] = -r / (2 * a); g[1] = 1 / np.sqrt(a * m); g[2] = -r / (2 * m)
    sd_r = np.sqrt(g @ C @ g)
    return sd, corr, sd_r, w.min() / w.max()

def ai_reml(y, Vs, theta0, maxit=40, tol=1e-7, verbose=False):
    N = len(y); one = np.ones(N)
    theta = np.array(theta0, float)
    def ll_of(th):
        V = build_V(th, Vs)
        try:
            cf = sla.cho_factor(V)
        except Exception:
            return -np.inf, None
        Vi = sla.cho_solve(cf, np.eye(N))
        Vi1 = Vi @ one; sw = one @ Vi1
        P = Vi - np.outer(Vi1, Vi1) / sw
        ld = 2 * np.sum(np.log(np.diag(cf[0])))
        return -0.5 * (ld + np.log(sw) + y @ P @ y), P
    ll, P = ll_of(theta)
    for it in range(maxit):
        Py = P @ y
        VPy = [Vi_ @ Py for Vi_ in Vs]
        PVPy = [P @ v for v in VPy]
        k = len(Vs)
        AI = np.zeros((k, k))
        for i in range(k):
            for j in range(i, k):
                AI[i, j] = AI[j, i] = 0.5 * VPy[i] @ PVPy[j]
        g = np.array([-0.5 * (np.sum(P * Vs[i]) - Py @ VPy[i]) for i in range(k)])
        try:
            step = np.linalg.solve(AI, g)
        except np.linalg.LinAlgError:
            break
        lam = 1.0
        ok = False
        while lam > 1e-4:
            th_new = theta + lam * step
            ll_new, P_new = ll_of(th_new)
            if np.isfinite(ll_new) and ll_new >= ll - 1e-10:
                ok = True; break
            lam /= 2
        if not ok: break
        dll = ll_new - ll
        theta, ll, P = th_new, ll_new, P_new
        if verbose: print(it, theta, ll)
        if np.abs(lam * step).max() < tol * max(1, np.abs(theta).max()) and abs(dll) < 1e-8: break
    return theta, ll

def design_for(G, n_o, f, NREC=900, base_seed=777):
    """Equal-expected-N design: Nd dams per generation so that the expected number of calf records is ~NREC."""
    Nd = int(round(NREC / (G * n_o - (1 - f) * (G - 1))))
    seed = base_seed + 100 * G + 10 * n_o + int(round(10 * f))
    rng = np.random.default_rng(seed)
    sire, dam, gen, has = maternal_design(G, Nd, n_o, f, rng)
    return Nd, sire, dam, gen, has
