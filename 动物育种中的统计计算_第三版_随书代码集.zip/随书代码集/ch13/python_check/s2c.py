# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2c.py    依赖：仅标准库
"""S2c: exact parent-offspring phenotypic covariances under the direct-maternal model, three ways:
(1) hand-derived coefficients, (2) A-matrix algebra (V = sum theta_i V_i), (3) Monte Carlo (seed 20261002, 4e6 triples)."""
from mat_lib import *
th = true_theta()
s2ad, cov, s2am, s2pem, s2e = th
print('theta', th, 'sigma_P^2 =', th.sum() - 0 )
# note Var(P) = s2ad + s2am + cov + s2pem + s2e  (not th.sum(): the covariance enters once)
print('Var(P) = %.4f' % (s2ad + s2am + cov + s2pem + s2e))
# (1) hand-derived
cov_mo = 0.5 * s2ad + 1.25 * cov + 0.5 * s2am
cov_so = 0.5 * s2ad + 0.25 * cov
cov_book = 0.5 * s2ad + cov + 0.25 * s2am
print('dam-offspring: hand %.4f  | existing-text (13.15c) numerics 0.5*s2ad+cov+0.25*s2am = %.4f' % (cov_mo, cov_book))
print('sire-offspring: hand %.4f' % cov_so)
print('doubling: 2*cov_mo = %.2f (h2 = %.4f), 2*cov_so = %.2f (h2 = %.4f), true s2ad=%.1f (h2d=%.3f), 2*cov_book=%.2f' % (
    2 * cov_mo, 2 * cov_mo / 400, 2 * cov_so, 2 * cov_so / 400, s2ad, s2ad / 400, 2 * cov_book))
# (2) A-matrix algebra: 0 SS, 1 DS, 2 S, 3 SD, 4 DD, 5 D, 6 o
sire = np.array([-1, -1, 0, -1, -1, 3, 2]); dam = np.array([-1, -1, 1, -1, -1, 4, 5])
has = np.array([False, False, True, False, False, True, True])
A, rec, mi, Vs = components(sire, dam, has)
V = build_V(th, Vs)
print('records (animals):', rec, ' dam of each:', mi)
print('V =\n', np.round(V, 4))
print('Cov(P_S,P_D) = %.4f, Cov(P_D,P_o) = %.4f, Cov(P_S,P_o) = %.4f, Var(P_o)=%.4f' % (V[0, 1], V[1, 2], V[0, 2], V[2, 2]))
# (3) Monte Carlo
rng = np.random.default_rng(20261002)
N = 4_000_000
G0 = np.array([[s2ad, cov], [cov, s2am]]); L = np.linalg.cholesky(G0)
def f(): return rng.standard_normal((N, 2)) @ L.T
def ms(): return (rng.standard_normal((N, 2)) @ L.T) * np.sqrt(0.5)
SS, DS, SD, DD = f(), f(), f(), f()
S = 0.5 * (SS + DS) + ms(); D = 0.5 * (SD + DD) + ms(); o = 0.5 * (S + D) + ms()
c_DS, c_DD, c_D = [np.sqrt(s2pem) * rng.standard_normal(N) for _ in range(3)]
e = [np.sqrt(s2e) * rng.standard_normal(N) for _ in range(3)]
P_S = S[:, 0] + DS[:, 1] + c_DS + e[0]
P_D = D[:, 0] + DD[:, 1] + c_DD + e[1]
P_o = o[:, 0] + D[:, 1] + c_D + e[2]
def cv(x, y): return np.mean(x * y) - np.mean(x) * np.mean(y)
def se(x, y): 
    z = (x - x.mean()) * (y - y.mean()); return z.std() / np.sqrt(len(z))
print('MC: Cov(P_o,P_D) = %.3f (SE %.3f), Cov(P_o,P_S) = %.3f (SE %.3f), Cov(P_S,P_D) = %.3f, Var(P_o) = %.3f' % (
    cv(P_o, P_D), se(P_o, P_D), cv(P_o, P_S), se(P_o, P_S), cv(P_S, P_D), np.var(P_o)))
# regression estimates of s2ad from each pair type (doubling slope*var): b = cov/var; h2hat = 2b; s2ad_hat = 2*cov
print('single-trait doubling: dam %.2f, sire %.2f; heritability dam %.4f sire %.4f (true h2_d = %.3f)' % (2 * cv(P_o, P_D), 2 * cv(P_o, P_S), 2 * cv(P_o, P_D) / np.var(P_D), 2 * cv(P_o, P_S) / np.var(P_S), s2ad / 400))
# the half-sib-by-sire estimate and what a naive "ignore maternal" REML would lean on
print('paternal half-sib covariance = 1/4 s2ad = %.2f' % (0.25 * s2ad))
# maternal half-sib covariance
print('maternal half-sib covariance = 1/4 s2ad + cov + s2am + s2pem = %.4f' % (0.25 * s2ad + cov + s2am + s2pem))
print('full-sib covariance = 1/2 s2ad + cov + s2am + s2pem = %.4f' % (0.5 * s2ad + cov + s2am + s2pem))
