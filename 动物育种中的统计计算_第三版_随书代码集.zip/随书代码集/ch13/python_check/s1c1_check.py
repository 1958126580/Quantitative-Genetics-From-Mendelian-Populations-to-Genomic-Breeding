# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1c1_check.py    依赖：scipy
from reml_rep import *
rng_ped = np.random.default_rng(20261001)
sire, dam, gen, sex = ped_random(4, 150, rng_ped)
n = len(sire); A = A_dense(sire, dam); F = np.diag(A) - 1
lam, Q = np.linalg.eigh(A); lam = np.clip(lam, 1e-12, None)
print('eigenvalues of A: max %.2f, share >1: %.3f, median %.3f, mean %.3f' % (lam.max(), np.mean(lam > 1), np.median(lam), lam.mean()))
rng = np.random.default_rng(1)
h2, t, k = 0.15, 0.4, 6
a = sim_bv(sire, dam, np.array([[h2]]), rng, F)[:, 0]
Y = (a + np.sqrt(t - h2) * rng.standard_normal(n))[:, None] + np.sqrt(1 - t) * rng.standard_normal((n, k))
ybar = Y.mean(1); SSW = np.sum((Y - ybar[:, None]) ** 2); z = Q.T @ ybar; w = Q.T @ np.ones(n)
p0, l0 = fit_eigen(Y, lam, Q, False)
print('L-BFGS-B mis fit', p0, l0)
# grid check
best = (1e9, None)
for sa in np.linspace(0.05, 1.5, 59):
    for se in np.linspace(0.3, 0.9, 61):
        v = nll_eigen((sa, se), z, w, lam, k, n, SSW, False)
        if v < best[0]: best = (v, (sa, se))
print('grid best', best, ' -> nll at L-BFGS', -l0)
p1, l1 = fit_eigen(Y, lam, Q, True)
print('correct fit', p1, l1)
# dense full check of mis fit gradient: finite diff
from scipy.optimize import approx_fprime
g = approx_fprime(p0, lambda p: nll_eigen(p, z, w, lam, k, n, SSW, False), 1e-6)
print('gradient at optimum', g)
