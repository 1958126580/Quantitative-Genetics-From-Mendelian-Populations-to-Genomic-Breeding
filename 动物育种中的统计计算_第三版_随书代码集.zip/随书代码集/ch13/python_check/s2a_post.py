# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2a_post.py    依赖：仅标准库
from mat_lib import *
import pickle
out = pickle.load(open('s2a_sim.pkl', 'rb'))
theta = true_theta()
for key, v in out.items():
    e = v['ests']
    rdm = e[:, 1] / np.sqrt(np.clip(e[:, 0], 1e-9, None) * np.clip(e[:, 2], 1e-9, None))
    ok = (e[:, 0] > 0) & (e[:, 2] > 0)
    q1, q2, q3 = np.percentile(rdm[ok], [25, 50, 75])
    inb = (e[:, 0] > 0) & (e[:, 2] > 0) & (e[:, 3] > 0) & (np.abs(rdm) <= 1)
    print(key, 'r_dm median %.3f, IQR %.3f -> robust SD %.3f; delta SD %.3f; in-space fraction %.2f; outside %.2f; neg s2am %.2f neg s2pem %.2f' % (
        q2, q3 - q1, (q3 - q1) / 1.349, v['sd_r'], inb.mean(), 1 - inb.mean(), np.mean(e[:, 2] < 0), np.mean(e[:, 3] < 0)))
    print('   ratios emp/fisher:', np.round(e.std(0, ddof=1) / v['sd_fisher'], 2), ' n=', len(e))
    # sample SD of r_dm among in-space fits
    print('   SD of r_dm among in-space fits: %.3f (n=%d)' % (np.std(rdm[inb], ddof=1), inb.sum()))
# extra: n_o = 1 singular check; N needed for SD(r)=0.1
import sys
rng = np.random.default_rng(777)
sire, dam, gen, has = maternal_design(3, 300, 1, 1.0, rng)
A, rec, mi, Vs = components(sire, dam, has)
I = fisher_info(theta, Vs)
w = np.linalg.eigvalsh(I)
print('n_o=1 design: N=%d, eig min/max of info: %.3e' % (len(rec), w.min() / w.max()))
print('N needed for SD(r_dm)=0.1 in design (3,4,1.0): %.0f' % (900 * (0.226 / 0.1) ** 2))
