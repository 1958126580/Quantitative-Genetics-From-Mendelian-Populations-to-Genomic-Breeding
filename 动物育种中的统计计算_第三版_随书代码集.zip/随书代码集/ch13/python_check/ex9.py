# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex9.py    依赖：numpy
import numpy as np
rng=np.random.default_rng(11)
sad,sam,cov,spem,se=150.,90.,-40.,40.,350.
G=np.array([[sad,cov],[cov,sam]]); L=np.linalg.cholesky(G); Lh=np.linalg.cholesky(G/2)
N=600000
def kid(s,d): return 0.5*(s+d)+(Lh@rng.standard_normal((2,len(s)))).T
base=lambda k:(L@rng.standard_normal((2,k))).T
def pheno(anim,dam,pem): return anim[:,0]+dam[:,1]+pem+rng.standard_normal(len(anim))*np.sqrt(se)
# grandparents
gs,gd=base(N),base(N)          # sire's parents
S=kid(gs,gd)                   # sire, dam of sire = gd
D=base(N); D2=base(N)          # two unrelated dams
pemD=rng.standard_normal(N)*np.sqrt(spem); pemD2=rng.standard_normal(N)*np.sqrt(spem)
pemgd=rng.standard_normal(N)*np.sqrt(spem)
X1=kid(S,D); X2=kid(S,D)       # full sibs (same sire S, same dam D)
Y1=kid(S,D2)                   # paternal half sib of X1
# maternal half sibs: same dam D, different sires
S2=base(N); M1=kid(S,D); M2=kid(S2,D)
P_X1=pheno(X1,D,pemD); P_X2=pheno(X2,D,pemD); P_Y1=pheno(Y1,D2,pemD2)
P_M1=pheno(M1,D,pemD); P_M2=pheno(M2,D,pemD)
P_S=pheno(S,gd,pemgd)          # sire's own record (his dam is gd)
theory=dict(
  fullsib=0.5*sad+cov+sam+spem, pat=0.25*sad, mat=0.25*sad+cov+sam+spem,
  sire_off=0.5*sad+0.25*cov, dam_off=0.5*sad+1.25*cov+0.5*sam)
print("full sibs      MC=%.2f  theory=%.2f"%(np.cov(P_X1,P_X2)[0,1],theory['fullsib']))
print("paternal HS    MC=%.2f  theory=%.2f"%(np.cov(P_X1,P_Y1)[0,1],theory['pat']))
print("maternal HS    MC=%.2f  theory=%.2f"%(np.cov(P_M1,P_M2)[0,1],theory['mat']))
print("sire-offspring MC=%.2f  theory=%.2f"%(np.cov(P_S,P_X1)[0,1],theory['sire_off']))
# dam-offspring: dam D has own record; her dam is unknown base -> give D a dam
gdD=base(N); sD=base(N); D3=kid(sD,gdD); pemgdD=rng.standard_normal(N)*np.sqrt(spem)
pemD3=rng.standard_normal(N)*np.sqrt(spem)
P_D3=pheno(D3,gdD,pemgdD)
O=kid(base(N),D3); P_O=pheno(O,D3,pemD3)
print("dam-offspring  MC=%.2f  theory=%.2f"%(np.cov(P_D3,P_O)[0,1],theory['dam_off']))
print("Var(P) MC=%.2f theory=%.2f"%(P_X1.var(),sad+cov+sam+spem+se))
