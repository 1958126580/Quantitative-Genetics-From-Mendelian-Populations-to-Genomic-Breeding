# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex1b.py    依赖：numpy
import numpy as np
np.set_printoptions(precision=6, suppress=True, linewidth=170)
def Amat(ped,n):
    A=np.zeros((n,n))
    for i in range(1,n+1):
        s,d=ped[i]
        for j in range(1,i+1):
            if j==i: A[i-1,i-1]=1+(0.5*A[s-1,d-1] if (s and d) else 0)
            else:
                a=0.0
                if s:a+=0.5*A[s-1,j-1]
                if d:a+=0.5*A[d-1,j-1]
                A[i-1,j-1]=A[j-1,i-1]=a
    return A
# variant A: shared sire
ped={1:(0,0),2:(0,0),3:(0,0),4:(1,2),5:(1,3),6:(1,2)}
A=Amat(ped,6); Ai=np.linalg.inv(A)
rec=[(4,1,8.4),(4,2,9.1),(4,3,9.6),(5,1,7.2),(5,2,8.0),(6,1,8.9),(6,2,9.8),(6,3,9.2)]
def solve(rec,Ai,n,cows,lam_a,lam_pe,npar=3):
    nr=len(rec);X=np.zeros((nr,npar));Z=np.zeros((nr,n));W=np.zeros((nr,len(cows)));y=np.zeros(nr)
    for k,(a,p,v) in enumerate(rec):
        X[k,p-1]=1;Z[k,a-1]=1;W[k,cows.index(a)]=1;y[k]=v
    C=np.block([[X.T@X,X.T@Z,X.T@W],[Z.T@X,Z.T@Z+Ai*lam_a,Z.T@W],[W.T@X,W.T@Z,W.T@W+np.eye(len(cows))*lam_pe]])
    rhs=np.concatenate([X.T@y,Z.T@y,W.T@y])
    return np.linalg.solve(C,rhs),C,X,Z,W,y
s,_,_,_,_,_=solve(rec,Ai,6,[4,5,6],2.2,2.75)
print("variant A u:",s[3:9])
rec2=[(4,1,8.4),(4,2,9.1),(4,3,9.6),(5,1,7.2),(5,2,8.0),(6,1,10.9),(6,2,9.8),(6,3,9.2)]
s2,_,_,_,_,_=solve(rec2,Ai,6,[4,5,6],2.2,2.75)
print("variant A perturbed u:",s2[3:9])
