# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex2.py    依赖：numpy, scipy
import numpy as np
from scipy.optimize import minimize
np.set_printoptions(precision=4, suppress=True, linewidth=160)
sa, spe, se = 0.25, 0.20, 0.55     # constant-PE benchmark, sigma_P^2=1, h2=.25, r=.45
n = 4
J = np.ones((n,n)); I = np.eye(n)
print("=== (1) constant PE ===")
V1 = sa*J + spe*J + se*I
print(V1); print("corr:\n", V1/np.sqrt(np.outer(np.diag(V1),np.diag(V1))))
print("eigs:", np.linalg.eigvalsh(V1), "cond:", np.linalg.cond(V1))
print("=== (2) cumulative PE, sigma_w^2 = 0.08 ===")
sw = 0.08
M = np.array([[min(k,l) for l in range(1,n+1)] for k in range(1,n+1)], float)
V2 = sa*J + sw*M + se*I
print(M); print(V2); print("corr:\n", V2/np.sqrt(np.outer(np.diag(V2),np.diag(V2))))
print("=== (3) AR(1) PE, rho=0.7 ===")
rho=0.7
R = np.array([[rho**abs(k-l) for l in range(n)] for k in range(n)])
V3 = sa*J + spe*R + se*I
print(V3); print("corr:\n", V3/np.sqrt(np.outer(np.diag(V3),np.diag(V3))))
# implied repeatability (phenotypic corr) by lag
for name,V in [("const",V1),("cum",V2),("ar1",V3)]:
    cc=V/np.sqrt(np.outer(np.diag(V),np.diag(V)))
    print(name,"var by order:",np.round(np.diag(V),4),"corr lag1:",np.round([cc[i,i+1] for i in range(n-1)],4),
          "lag2:",np.round([cc[i,i+2] for i in range(n-2)],4),"lag3:",round(cc[0,3],4))

# ---- model discrimination on simulated data ----
rng=np.random.default_rng(20240513)
N=800; nrec=5
def Vstruct(kind,th,m=nrec):
    Jm=np.ones((m,m));Im=np.eye(m)
    if kind=="const": g,p,e=np.exp(th); return g*Jm+p*Jm+e*Im
    if kind=="cum":
        g,w,e=np.exp(th); Mm=np.array([[min(k,l) for l in range(1,m+1)] for k in range(1,m+1)],float)
        return g*Jm+w*Mm+e*Im
    if kind=="ar1":
        g,p,e=np.exp(th[:3]); rr=1/(1+np.exp(-th[3]))
        Rm=np.array([[rr**abs(k-l) for l in range(m)] for k in range(m)]); return g*Jm+p*Rm+e*Im
Vtrue=Vstruct("cum",np.log([0.25,0.08,0.55]))
L=np.linalg.cholesky(Vtrue); Y=(L@rng.standard_normal((nrec,N))).T
S=Y.T@Y/N
def nll(th,kind):
    V=Vstruct(kind,th)
    sgn,ld=np.linalg.slogdet(V)
    if sgn<=0: return 1e10
    return 0.5*N*(ld+np.trace(np.linalg.solve(V,S)))
res={}
for kind,x0,k in [("const",np.log([0.3,0.15,0.5]),3),("cum",np.log([0.3,0.06,0.5]),3),
                  ("ar1",np.concatenate([np.log([0.3,0.15,0.5]),[1.0]]),4)]:
    r0=minimize(nll,x0,args=(kind,),method="Nelder-Mead",options=dict(maxiter=40000,maxfev=40000,xatol=1e-10,fatol=1e-10))
    res[kind]=(-r0.fun,k,r0.x)
    print(kind,"logL=%.3f"%(-r0.fun),"k=",k,"AIC=%.2f"%(2*k+2*r0.fun),"par=",np.round(np.exp(r0.x[:3]),4),
          ("rho=%.3f"%(1/(1+np.exp(-r0.x[3]))) if kind=="ar1" else ""))
print("LRT cum vs const (same k, not nested): dlogL=%.3f"%(res["cum"][0]-res["const"][0]))
print("LRT ar1 vs const (1 df): 2dlogL=%.3f"%(2*(res["ar1"][0]-res["const"][0])))
print("empirical var by record order:",np.round(np.diag(S),4))
print("empirical corr matrix:\n",np.round(S/np.sqrt(np.outer(np.diag(S),np.diag(S))),4))
