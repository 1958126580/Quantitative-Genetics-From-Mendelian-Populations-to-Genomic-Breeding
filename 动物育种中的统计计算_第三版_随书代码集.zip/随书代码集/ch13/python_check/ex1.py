# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex1.py    依赖：numpy
import numpy as np
np.set_printoptions(precision=4, suppress=True, linewidth=150)

# ---------- pedigree & A^-1 (Henderson rules, no inbreeding here) ----------
ped = {1:(0,0), 2:(0,0), 3:(0,0), 4:(1,2), 5:(1,3), 6:(1,2)}
n = 6
A = np.zeros((n,n))
for i in range(1,n+1):
    s,d = ped[i]
    for j in range(1,i+1):
        if j==i:
            A[i-1,i-1] = 1 + (0.5*A[s-1,d-1] if (s and d) else 0)
        else:
            a = 0.0
            if s: a += 0.5*A[s-1,j-1]
            if d: a += 0.5*A[d-1,j-1]
            A[i-1,j-1]=A[j-1,i-1]=a
print("A =\n", A)
Ainv = np.linalg.inv(A)
print("A^-1 =\n", Ainv)

# ---------- data ----------
# records: (animal, parity, y)
rec = [(4,1,8.4),(4,2,9.1),(4,3,9.6),
       (5,1,7.2),(5,2,8.0),
       (6,1,8.9),(6,2,9.8),(6,3,9.2)]
nr = len(rec)
X = np.zeros((nr,3)); Z = np.zeros((nr,n)); y = np.zeros(nr)
cows = [4,5,6]
W = np.zeros((nr,len(cows)))
for k,(a,p,v) in enumerate(rec):
    X[k,p-1]=1; Z[k,a-1]=1; W[k,cows.index(a)]=1; y[k]=v
h2, r = 0.25, 0.45
sa, spe, se = h2, r-h2, 1-r
lam_a, lam_pe = se/sa, se/spe
print("sigma_a2,sigma_pe2,sigma_e2 =", sa, spe, se, " lam_a =", lam_a, " lam_pe =", lam_pe)
print("parity means:", [round(np.mean([v for a,p,v in rec if p==q]),4) for q in (1,2,3)])

def build(withPE=True):
    if withPE:
        C = np.block([[X.T@X, X.T@Z, X.T@W],
                      [Z.T@X, Z.T@Z+Ainv*lam_a, Z.T@W],
                      [W.T@X, W.T@Z, W.T@W+np.eye(len(cows))*lam_pe]])
        rhs = np.concatenate([X.T@y, Z.T@y, W.T@y])
    else:
        C = np.block([[X.T@X, X.T@Z],[Z.T@X, Z.T@Z+Ainv*lam_a]])
        rhs = np.concatenate([X.T@y, Z.T@y])
    return C, rhs
C,rhs = build(True)
sol = np.linalg.solve(C,rhs)
b, u, pe = sol[:3], sol[3:3+n], sol[3+n:]
print("\n--- repeatability model ---")
print("parity solutions:", np.round(b,4))
print("EBV:", np.round(u,4))
print("PE :", np.round(pe,4))
# check eq 13.6
resid_star = y - X@b - Z@u
for i,a in enumerate(cows):
    idx=[k for k,(aa,p,v) in enumerate(rec) if aa==a]
    ni=len(idx); ebar=resid_star[idx].mean()
    print(f"  cow {a}: n={ni}, ebar*={ebar:.6f}, n*ebar/(n+lam_pe)={ni*ebar/(ni+lam_pe):.6f}, pe_hat={pe[i]:.6f}")
ehat = y - X@b - Z@u - W@pe
print("X'ehat =", np.round(X.T@ehat,12))
print("Z'ehat - lam_a A^-1 u  =", np.round(Z.T@ehat - lam_a*Ainv@u, 12))
print("W'ehat - lam_pe pe =", np.round(W.T@ehat - lam_pe*pe,12))
print("sum of base EBV (1,2,3):", round(u[0]+u[1]+u[2],12))

# PEV / reliability
Cinv = np.linalg.inv(C)
pev = np.diag(Cinv)[3:3+n]*se
rel = 1-pev/sa
print("PEV :", np.round(pev,4))
print("R2  :", np.round(rel,4))
print("acc :", np.round(np.sqrt(rel),4))

# MPPA for each cow (future parity = parity 2 level)
print("MPPA (future = 2nd parity):", [round(b[1]+u[cows[i]-1]+pe[i],4) for i in range(3)])
print("mean records:", [round(np.mean([v for a,p,v in rec if a==c]),4) for c in cows])

# ---------- ignore PE: treat records as independent ----------
C2,rhs2 = build(False)
sol2 = np.linalg.solve(C2,rhs2)
b2,u2 = sol2[:3], sol2[3:]
print("\n--- PE ignored (same lam_a) ---")
print("parity:", np.round(b2,4)); print("EBV:", np.round(u2,4))
print("ratio EBV(noPE)/EBV(PE):", np.round(u2/u,4))
pev2 = np.diag(np.linalg.inv(C2))[3:]*se
print("R2 (wrongly claimed):", np.round(1-pev2/sa,4))

# ---------- single-record mean model comparison: index weight ----------
for ni in (1,2,3,5,10):
    print(f"n={ni}: b_EBV = n h2/(1+(n-1)r) = {ni*h2/(1+(ni-1)*r):.4f}, b_MPPA = n r/(1+(n-1)r) = {ni*r/(1+(ni-1)*r):.4f}, h2_(n) = {ni*h2/(1+(ni-1)*r):.4f}")
