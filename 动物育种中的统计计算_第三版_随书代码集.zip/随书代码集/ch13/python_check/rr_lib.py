# -*- coding: utf-8 -*-
"""Random-regression (covariance function) REML for a balanced half-sib design with complete test-day data.
Design: s sires x m daughters x T test days; dams unrelated, one daughter each.  Model per cow j of sire i:
   y_ijt = mu_t + phi_t'(alpha_ij + rho_ij) + e_ijt,  alpha_ij = 1/2 alpha_si + eps_ij, eps ~ N(0, 3/4 Ka)
   Var(alpha)=Ka, Var(rho)=Kp, Var(e)=s2e I.
The REML likelihood factorises exactly into two Wishart pieces (between sires / within sires):
   Sigma_C = 3/4 Phi Ka Phi' + Phi Kp Phi' + s2e I        (within sires, df_W = s(m-1))
   Sigma_B = Sigma_C + m * 1/4 Phi Ka Phi'                 (between sires, df_B = s-1)
   l_R = -1/2 [ df_B (log|Sigma_B| + tr(Sigma_B^-1 MS_B)) + df_W (log|Sigma_C| + tr(Sigma_C^-1 MS_W)) ]  (+const)
which is the exact animal-model REML for this pedigree (T separate fixed means)."""
from common import *
from scipy.optimize import minimize

TD = 5.0 + 30.0 * np.arange(11)            # DIM 5, 35, ..., 305
XT = tx(TD)                                # -1, -0.8, ..., 1
PHI_ALL = phi_leg(XT, 4)                   # 11 x 5
T = len(TD)

def simulate(s, m, Ka, Kp, s2e, rng):
    q = Ka.shape[0]; Phi = PHI_ALL[:, :q]
    La = np.linalg.cholesky(Ka); Lp = np.linalg.cholesky(Kp)
    alpha_s = rng.standard_normal((s, q)) @ La.T
    eps = (rng.standard_normal((s, m, q)) @ La.T) * np.sqrt(0.75)
    rho = rng.standard_normal((s, m, q)) @ Lp.T
    coef = 0.5 * alpha_s[:, None, :] + eps + rho
    Y = coef @ Phi.T + np.sqrt(s2e) * rng.standard_normal((s, m, T))
    return Y

def mstats(Y):
    s, m, _ = Y.shape
    ybi = Y.mean(1)                         # s x T
    ybb = ybi.mean(0)
    dB = ybi - ybb
    MSB = m * (dB.T @ dB) / (s - 1)
    W = Y - ybi[:, None, :]
    MSW = np.einsum('ijt,iju->tu', W, W) / (s * (m - 1))
    return MSB, MSW, s - 1, s * (m - 1), m

def lower_pattern(q, r):
    """index pairs (i,j) of free elements of a q x r lower-trapezoidal factor"""
    return [(i, j) for i in range(q) for j in range(min(i, r - 1) + 1)]

class RRModel:
    def __init__(self, k, rank=None):
        self.k = k; self.q = k + 1; self.r = rank or self.q
        self.pa = lower_pattern(self.q, self.r); self.pp = lower_pattern(self.q, self.q)
        self.na, self.np_ = len(self.pa), len(self.pp)
        self.npar = self.na + self.np_ + 1     # number of variance parameters  (K_a: q r - r(r-1)/2 ; K_p: q(q+1)/2 ; s2e)
        self.Phi = PHI_ALL[:, :self.q]
    def unpack(self, th):
        La = np.zeros((self.q, self.r)); Lp = np.zeros((self.q, self.q))
        for v, (i, j) in zip(th[:self.na], self.pa): La[i, j] = v
        for v, (i, j) in zip(th[self.na:self.na + self.np_], self.pp): Lp[i, j] = v
        s2e = np.exp(th[-1])
        return La, Lp, s2e
    def Ks(self, th):
        La, Lp, s2e = self.unpack(th)
        return La @ La.T, Lp @ Lp.T, s2e
    def nll_grad(self, th, MSB, MSW, dfB, dfW, m):
        La, Lp, s2e = self.unpack(th)
        Ka, Kp = La @ La.T, Lp @ Lp.T
        Phi = self.Phi
        PKaP = Phi @ Ka @ Phi.T; PKpP = Phi @ Kp @ Phi.T
        SC = 0.75 * PKaP + PKpP + s2e * np.eye(T)
        SB = SC + 0.25 * m * PKaP
        try:
            cB = np.linalg.cholesky(SB); cC = np.linalg.cholesky(SC)
        except np.linalg.LinAlgError:
            return 1e12, np.zeros_like(th)
        SBi = np.linalg.inv(SB); SCi = np.linalg.inv(SC)
        ldB = 2 * np.sum(np.log(np.diag(cB))); ldC = 2 * np.sum(np.log(np.diag(cC)))
        ll = -0.5 * (dfB * (ldB + np.trace(SBi @ MSB)) + dfW * (ldC + np.trace(SCi @ MSW)))
        Gb = SBi - SBi @ MSB @ SBi
        Gc = SCi - SCi @ MSW @ SCi
        dB = -0.5 * dfB * Gb; dC = -0.5 * dfW * Gc
        Da = Phi.T @ ((0.75 + 0.25 * m) * dB + 0.75 * dC) @ Phi
        Dp = Phi.T @ (dB + dC) @ Phi
        gLa = 2 * Da @ La; gLp = 2 * Dp @ Lp
        g = np.zeros_like(th)
        for idx, (i, j) in enumerate(self.pa): g[idx] = gLa[i, j]
        for idx, (i, j) in enumerate(self.pp): g[self.na + idx] = gLp[i, j]
        g[-1] = s2e * np.trace(dB + dC)
        return -ll, -g
    def start(self, MSB, MSW, m):
        Phi = self.Phi; Pinv = np.linalg.pinv(Phi)
        S_s = (MSB - MSW) / m
        Ka0 = 4 * Pinv @ S_s @ Pinv.T
        w, V = np.linalg.eigh(Ka0); w = np.clip(w, 0.05, None); Ka0 = (V * w) @ V.T
        R = MSW - 0.75 * Phi @ Ka0 @ Phi.T
        Kp0 = Pinv @ R @ Pinv.T
        w, V = np.linalg.eigh(Kp0); w = np.clip(w, 0.05, None); Kp0 = (V * w) @ V.T
        res = R - Phi @ Kp0 @ Phi.T
        s2e0 = max(np.mean(np.diag(res)), 0.5)
        # factors
        th = np.zeros(self.npar)
        if self.r == self.q:
            La0 = np.linalg.cholesky(Ka0)
        else:
            w, V = np.linalg.eigh(Ka0); idx = np.argsort(-w)[:self.r]
            Lf = V[:, idx] * np.sqrt(w[idx])
            # rotate to lower-trapezoidal by QR of Lf'
            Qm, Rm = np.linalg.qr(Lf.T); La0 = Rm.T
            sgn = np.sign(np.diag(La0)); sgn[sgn == 0] = 1
            La0 = La0 * sgn
        Lp0 = np.linalg.cholesky(Kp0)
        for idx, (i, j) in enumerate(self.pa): th[idx] = La0[i, j]
        for idx, (i, j) in enumerate(self.pp): th[self.na + idx] = Lp0[i, j]
        th[-1] = np.log(s2e0)
        return th
    def fit(self, MSB, MSW, dfB, dfW, m, th0=None, restarts=0, rng=None):
        th0 = self.start(MSB, MSW, m) if th0 is None else th0
        best = None
        starts = [th0]
        if restarts:
            for _ in range(restarts):
                starts.append(th0 + 0.3 * rng.standard_normal(len(th0)))
        for t0 in starts:
            r = minimize(self.nll_grad, t0, args=(MSB, MSW, dfB, dfW, m), jac=True, method='BFGS',
                         options=dict(maxiter=3000, gtol=1e-6))
            if best is None or r.fun < best.fun: best = r
        return best

def n_params(k, rank=None):
    q = k + 1; r = rank or q
    return q * r - r * (r - 1) // 2 + q * (q + 1) // 2 + 1

def curves(Ka, Kp, s2e, tt):
    ph = phi_leg(tx(tt), Ka.shape[0] - 1)
    va = np.einsum('ti,ij,tj->t', ph, Ka, ph)
    vp = np.einsum('ti,ij,tj->t', ph, Kp, ph)
    return va, vp, va / (va + vp + s2e)

def corr_fn(Ka, tt):
    ph = phi_leg(tx(tt), Ka.shape[0] - 1)
    C = ph @ Ka @ ph.T
    d = np.sqrt(np.diag(C)); return C / np.outer(d, d)
