# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex6.py    依赖：numpy
import numpy as np
sets=[("A: sD2=100, sDS=-5, sS2=1, se2=200",100.,-5.,1.,200.),
      ("B: sD2=100, sDS=0,  sS2=4, se2=200",100.,0.,4.,200.)]
for name,sD,sDS,sS,se in sets:
    print("\n=== "+name+" ===")
    print(" n | sigma2_TBV | sigma2_P | T2=s2TBV/s2P | h2_classic | cov(y_i,y_j)")
    for n in (1,2,4,6,8,10,12,16,20):
        tbv=sD+2*(n-1)*sDS+(n-1)**2*sS
        sp=sD+(n-1)*sS+se
        cij=2*sDS+(n-2)*sS if n>=2 else float('nan')
        print(f"{n:3d} | {tbv:10.1f} | {sp:8.1f} | {tbv/sp:12.4f} | {sD/sp:10.4f} | {cij:8.2f}")
# classic thought-question check
print("\nQ7: n=12:",100+2*11*(-5)+121*1, " ratio vs sD2:",(100+2*11*(-5)+121*1)/100)
for n in (6,10,20):
    print(f" n={n}: 100+2*{n-1}*(-5)+{(n-1)**2}*1 =",100+2*(n-1)*(-5)+(n-1)**2*1)
# maternal Q4
sad,sam,rdm=100.,64.,-0.5
cov=rdm*np.sqrt(sad*sam); print("\nQ4: cov=",cov," sigma_T2=",sad+cov+0.25*sam," ratio=",(sad+cov+0.25*sam)/sad)
print(" Willham numerator=",sad+1.5*cov+0.5*sam)
# Q3
h2,r=0.20,0.45; print("\nQ3: lam_a=",(1-r)/h2," lam_pe=",(1-r)/(r-h2))
# repeatability lambda table
print("\nlambda table:")
for h2 in (0.10,0.20,0.25,0.30):
    for r in (0.30,0.45,0.60):
        if r>h2: print(f"  h2={h2:.2f} r={r:.2f}: lam_a={(1-r)/h2:7.4f} lam_pe={(1-r)/(r-h2):9.4f} spe2/sP2={r-h2:.2f}")
print("\nr->h2 limit: h2=0.25")
for r in (0.26,0.27,0.30,0.35,0.45):
    print(f"  r={r:.2f}: lam_pe={(1-r)/(r-0.25):.3f}")
