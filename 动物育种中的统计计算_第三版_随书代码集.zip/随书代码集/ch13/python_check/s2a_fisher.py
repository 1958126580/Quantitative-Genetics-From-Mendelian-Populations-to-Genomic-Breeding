# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2a_fisher.py    依赖：仅标准库
"""S2a: expected (Fisher) REML information for the direct-maternal model for a grid of designs with ~constant number of calf records."""
from mat_lib import *
import time, sys
theta = true_theta()
print('true theta [s2ad, s_adam, s2am, s2pem, s2e] =', np.round(theta, 4), ' sum check Var(P) =', theta[0] + theta[1] + theta[2] + theta[3] + theta[4])
NREC = 900
def run(G, n_o, f, seed=777):
    rng = np.random.default_rng(seed + 100 * G + 10 * n_o + int(10 * f))
    Nd = int(round(NREC / (G * n_o)))
    sire, dam, gen, has = maternal_design(G, Nd, n_o, f, rng)
    A, rec, mi, Vs = components(sire, dam, has)
    I = fisher_info(theta, Vs)
    r = sd_from_info(I, theta)
    ndd = int(np.sum([has[d] for d in set(dam[rec]) if d >= 0 and gen[d] > 0]))   # dams (gen>0) with own record
    ndam = len(set(dam[rec]))
    return dict(Nd=Nd, N=len(rec), nanimals=len(sire), I=I, res=r, ndd=ndd, ndam=ndam, sire=sire, dam=dam, gen=gen, has=has)
t0 = time.time()
results = {}
for (G, n_o, f) in [(3, 2, 0.0), (3, 2, 0.3), (3, 2, 1.0), (3, 4, 0.0), (3, 4, 0.3), (3, 4, 1.0), (3, 8, 0.0), (3, 8, 0.3), (3, 8, 1.0),
                    (1, 4, 1.0), (2, 4, 1.0), (5, 4, 1.0)]:
    d = run(G, n_o, f)
    results[(G, n_o, f)] = d
    if d['res'] is None:
        print('G=%d n_o=%d f=%.1f  Nd=%d N=%d n_dd=%d : SINGULAR information (min eig ratio tiny)' % (G, n_o, f, d['Nd'], d['N'], d['ndd']), 'time %.0f' % (time.time() - t0))
    else:
        sd, corr, sd_r, ratio = d['res']
        print('G=%d n_o=%d f=%.1f Nd=%d N=%d n_dd=%d | SD: s2ad %.2f s_adam %.2f s2am %.2f s2pem %.2f s2e %.2f | SD(r_dm) %.3f | corr(am,pem) %.3f corr(ad,adam) %.3f corr(adam,am) %.3f | eigratio %.2e | time %.0f' % (
            G, n_o, f, d['Nd'], d['N'], d['ndd'], sd[0], sd[1], sd[2], sd[3], sd[4], sd_r, corr[2, 3], corr[0, 1], corr[1, 2], ratio, time.time() - t0))
        sys.stdout.flush()
import pickle
pickle.dump({k: dict(I=v['I'], N=v['N'], Nd=v['Nd'], ndd=v['ndd'], ndam=v['ndam']) for k, v in results.items()}, open('s2a_fisher.pkl', 'wb'))
