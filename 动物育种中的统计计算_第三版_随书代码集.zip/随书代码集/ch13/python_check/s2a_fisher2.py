# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2a_fisher2.py    依赖：仅标准库
"""S2a (final): Fisher information of the direct-maternal REML for designs with equal expected number of records (~900)."""
from mat_lib import *
import pickle
theta = true_theta()
print('true theta [s2ad, s_adam, s2am, s2pem, s2e] =', np.round(theta, 4))
res = {}
for (G, n_o, f) in [(3, 2, 0.0), (3, 2, 0.3), (3, 2, 1.0), (3, 4, 0.0), (3, 4, 0.3), (3, 4, 1.0), (3, 8, 0.0), (3, 8, 0.3), (3, 8, 1.0),
                    (1, 4, 1.0), (2, 4, 1.0), (3, 4, 1.0), (5, 4, 1.0), (3, 1, 1.0)]:
    Nd, sire, dam, gen, has = design_for(G, n_o, f)
    A, rec, mi, Vs = components(sire, dam, has)
    I = fisher_info(theta, Vs)
    r = sd_from_info(I, theta)
    ndd = int(sum(1 for d in set(dam[rec]) if d >= 0 and gen[d] > 0 and has[d]))
    ndam = len(set(dam[rec]))
    res[(G, n_o, f)] = dict(I=I, N=len(rec), Nd=Nd, ndd=ndd, ndam=ndam)
    if r is None:
        print('G=%d n_o=%d f=%.1f Nd=%d N=%d n_dd=%d n_dam=%d : SINGULAR' % (G, n_o, f, Nd, len(rec), ndd, ndam))
    else:
        sd, corr, sd_r, ratio = r
        print('G=%d n_o=%d f=%.1f Nd=%d N=%d n_dd=%d n_dam=%d | SD: s2ad %.1f s_adam %.1f s2am %.1f s2pem %.1f s2e %.1f | SD(r) %.3f | corr(am,pem) %.2f corr(ad,adam) %.2f corr(adam,am) %.2f' % (
            G, n_o, f, Nd, len(rec), ndd, ndam, sd[0], sd[1], sd[2], sd[3], sd[4], sd_r, corr[2, 3], corr[0, 1], corr[1, 2]))
pickle.dump(res, open('s2a_fisher2.pkl', 'wb'))
