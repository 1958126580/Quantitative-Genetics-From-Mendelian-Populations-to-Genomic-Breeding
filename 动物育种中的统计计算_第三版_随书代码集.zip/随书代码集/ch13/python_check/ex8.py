# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex8.py    依赖：numpy
import numpy as np
np.set_printoptions(precision=4,suppress=True,linewidth=200)
# ---- rank deficiency with fixed group effects ----
npen, per = 5, 4
n=npen*per
Xp=np.zeros((n,npen)); ZD=np.eye(n); ZS=np.zeros((n,n))
for g in range(npen):
    idx=list(range(g*per,(g+1)*per))
    for i in idx:
        Xp[i,g]=1
        for j in idx:
            if j!=i: ZS[i,j]=1
M=np.hstack([Xp,ZD,ZS])
print("columns:",M.shape[1]," rank:",np.linalg.matrix_rank(M)," predicted G+n =",npen+n)
d=np.random.default_rng(1).standard_normal(n)
print("max|ZD d + ZS d - pen-sums|:",np.abs(ZD@d+ZS@d-Xp@np.array([d[g*per:(g+1)*per].sum() for g in range(npen)])).max())
# ---- pen-mate covariance MC ----
rng=np.random.default_rng(3)
sD,sDS,sS,se=100.,-5.,1.,200.
G=np.array([[sD,sDS],[sDS,sS]]); L=np.linalg.cholesky(G)
for nn in (4,10):
    N=200000
    A=(L@rng.standard_normal((2,N*nn))).T.reshape(N,nn,2)
    tot=A[:,:,1].sum(axis=1,keepdims=True)
    y=A[:,:,0]+(tot-A[:,:,1])+rng.standard_normal((N,nn))*np.sqrt(se)
    print(f"n={nn}: Var(y)={y.var():.3f} theory={sD+(nn-1)*sS+se}",
          f" Cov(y_i,y_j)={np.cov(y[:,0],y[:,1])[0,1]:.3f} theory={2*sDS+(nn-2)*sS}",
          f" Var(TBV)={(A[:,0,0]+(nn-1)*A[:,0,1]).var():.3f} theory={sD+2*(nn-1)*sDS+(nn-1)**2*sS}")
# ---- compound symmetry ----
import numpy.linalg as la
for nrec in (2,3,5,10):
    r=0.45; V=(1-r)*np.eye(nrec)+r*np.ones((nrec,nrec))
    print(f"n={nrec}: eigs={np.round(la.eigvalsh(V),4)} det={la.det(V):.6f} theory det={(1-r)**(nrec-1)*(1+(nrec-1)*r):.6f} cond={la.cond(V):.4f} theory cond={(1+(nrec-1)*r)/(1-r):.4f}")
    Vi=la.inv(V); a=1/(1-r); b=-r/((1-r)*(1+(nrec-1)*r))
    print("   inv ok:",np.allclose(Vi,a*np.eye(nrec)+b*np.ones((nrec,nrec))),"a=",round(a,4),"b=",round(b,4))
# ---- cumulative PE: variance ratio last/first ----
print("\ncumulative PE: sa2=0.25 sw2=0.08 se2=0.55")
for k in range(1,7): print(f"  k={k}: Var={0.25+0.08*k+0.55:.3f}  r(1,k)={(0.25+0.08*1)/np.sqrt((0.25+0.08+0.55)*(0.25+0.08*k+0.55)):.4f}")
