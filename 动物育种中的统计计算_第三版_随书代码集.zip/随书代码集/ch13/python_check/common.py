# -*- coding: utf-8 -*-
"""Shared helpers for the chapter-13 expansion scripts (all numbers in the text come from these scripts)."""
import os
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np
import scipy.linalg as sla
import scipy.sparse as sp

def ped_random(n_gen, n_per_gen, rng):
    """Random-mating discrete generations. Founders (gen 0) have unknown parents.
    Returns sire, dam, gen, sex arrays (0-based indices, -1 = unknown). sex: 0 male, 1 female."""
    sire, dam, gen, sex = [], [], [], []
    for i in range(n_per_gen):
        sire.append(-1); dam.append(-1); gen.append(0); sex.append(i % 2)
    for g in range(1, n_gen):
        prev = [i for i in range(len(sire)) if gen[i] == g - 1]
        males = [i for i in prev if sex[i] == 0]
        females = [i for i in prev if sex[i] == 1]
        for j in range(n_per_gen):
            sire.append(int(rng.choice(males))); dam.append(int(rng.choice(females)))
            gen.append(g); sex.append(int(rng.integers(0, 2)))
    return np.array(sire), np.array(dam), np.array(gen), np.array(sex)

def A_dense(sire, dam):
    """Numerator relationship matrix by the tabular method (parents must precede offspring)."""
    n = len(sire)
    A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i], dam[i]
        if s >= 0 and d >= 0:
            A[i, :i] = 0.5 * (A[s, :i] + A[d, :i])
            A[i, i] = 1.0 + 0.5 * A[s, d]
        elif s >= 0:
            A[i, :i] = 0.5 * A[s, :i]; A[i, i] = 1.0
        elif d >= 0:
            A[i, :i] = 0.5 * A[d, :i]; A[i, i] = 1.0
        else:
            A[i, i] = 1.0
        A[:i, i] = A[i, :i]
    return A

def sim_bv(sire, dam, G0, rng, F):
    """Simulate q-variate breeding values (n x q) with covariance G0 (x) A by the Mendelian-sampling recursion."""
    G0 = np.atleast_2d(G0)
    q = G0.shape[0]
    L = np.linalg.cholesky(G0)
    n = len(sire)
    a = np.zeros((n, q))
    z = rng.standard_normal((n, q))
    for i in range(n):
        s, d = sire[i], dam[i]
        if s >= 0 and d >= 0:
            v = 0.5 - 0.25 * (F[s] + F[d])
            a[i] = 0.5 * (a[s] + a[d]) + np.sqrt(v) * (z[i] @ L.T)
        else:
            a[i] = z[i] @ L.T
    return a

def Ainv_sparse(sire, dam, F):
    """Henderson's rules for A^{-1} (with inbreeding), returned as scipy.sparse csc."""
    n = len(sire)
    rows, cols, vals = [], [], []
    def add(i, j, v):
        rows.append(i); cols.append(j); vals.append(v)
    for i in range(n):
        s, d = sire[i], dam[i]
        if s >= 0 and d >= 0:
            di = 0.5 - 0.25 * (F[s] + F[d])
        elif s >= 0:
            di = 0.75 - 0.25 * F[s]
        elif d >= 0:
            di = 0.75 - 0.25 * F[d]
        else:
            di = 1.0
        b = 1.0 / di
        add(i, i, b)
        ps = [p for p in (s, d) if p >= 0]
        for p in ps:
            add(i, p, -0.5 * b); add(p, i, -0.5 * b); add(p, p, 0.25 * b)
        if len(ps) == 2:
            add(s, d, 0.25 * b); add(d, s, 0.25 * b)
    return sp.csc_matrix((vals, (rows, cols)), shape=(n, n))

def phi_leg(x, k):
    """Normalised Legendre polynomials of orders 0..k at x in [-1,1]; returns (len(x), k+1)."""
    x = np.atleast_1d(np.asarray(x, float))
    P = np.zeros((len(x), k + 1)); P[:, 0] = 1.0
    if k >= 1: P[:, 1] = x
    for m in range(2, k + 1):
        P[:, m] = ((2 * m - 1) * x * P[:, m - 1] - (m - 1) * P[:, m - 2]) / m
    return P * np.sqrt((2 * np.arange(k + 1) + 1) / 2.0)

def tx(t, tmin=5.0, tmax=305.0):
    return 2 * (np.asarray(t, float) - tmin) / (tmax - tmin) - 1
