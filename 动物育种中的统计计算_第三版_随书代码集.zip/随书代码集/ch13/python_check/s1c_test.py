# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1c_test.py    依赖：仅标准库
# unit test: reduced (between/within) REML equals record-level dense REML on a small data set
from reml_rep import *
rng = np.random.default_rng(7)
sire, dam, gen, sex = ped_random(3, 30, rng)
n = len(sire); A = A_dense(sire, dam); F = np.diag(A) - 1
a = sim_bv(sire, dam, np.array([[0.15]]), rng, F)[:, 0]
kk = np.array([1, 2, 3, 4, 2, 3] * 15)[:n]
s2a, s2pe, s2e = 0.15, 0.25, 0.6
pe = np.sqrt(s2pe) * rng.standard_normal(n)
recs = [a[i] + pe[i] + np.sqrt(s2e) * rng.standard_normal(kk[i]) for i in range(n)]
# record-level dense likelihood
idx = np.concatenate([[i] * kk[i] for i in range(n)]); y = np.concatenate(recs); N = len(y)
Z = np.zeros((N, n)); Z[np.arange(N), idx] = 1
def nll_full(par, with_pe):
    if with_pe: sa, sp_, se = par
    else: sa, se = par; sp_ = 0.0
    V = sa * Z @ A @ Z.T + sp_ * Z @ Z.T + se * np.eye(N)
    cf = sla.cho_factor(V); one = np.ones(N)
    Vi1 = sla.cho_solve(cf, one); Viy = sla.cho_solve(cf, y)
    sw = one @ Vi1; mu = one @ Viy / sw
    ld = 2 * np.sum(np.log(np.diag(cf[0])))
    return 0.5 * (ld + np.log(sw) + y @ Viy - mu * mu * sw)
ybar = np.array([r.mean() for r in recs])
SSW = sum(((r - r.mean()) ** 2).sum() for r in recs); dfw = int((kk - 1).sum())
for with_pe, par in ((True, (0.2, 0.1, 0.5)), (False, (0.2, 0.7))):
    full = nll_full(par, with_pe)
    red = nll_dense(par, ybar, kk.astype(float), A, SSW, dfw, with_pe)
    # constants differ by a parameter-free constant; check by two different parameter vectors
    par2 = tuple(np.array(par) * 1.3)
    d_full = nll_full(par2, with_pe) - full
    d_red = nll_dense(par2, ybar, kk.astype(float), A, SSW, dfw, with_pe) - red
    print('with_pe', with_pe, 'difference of NLL between two par vectors: full %.8f reduced %.8f' % (d_full, d_red))
