# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 13 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ex5.py    依赖：numpy
import numpy as np
np.set_printoptions(precision=4, suppress=True, linewidth=220)
def phi(x,k):
    x=np.atleast_1d(np.asarray(x,float)); P=np.zeros((len(x),k+1)); P[:,0]=1.0
    if k>=1: P[:,1]=x
    for m in range(2,k+1): P[:,m]=((2*m-1)*x*P[:,m-1]-(m-1)*P[:,m-2])/m
    return P*np.sqrt((2*np.arange(k+1)+1)/2.0)
tmin,tmax=5.0,305.0
tx=lambda t: 2*(np.asarray(t,float)-tmin)/(tmax-tmin)-1
td=np.arange(15,300,30.0)
sd=1.5+1.0*(td/305.0)
Cr=0.15+0.85*np.exp(-np.abs(td[:,None]-td[None,:])/160.0)
np.fill_diagonal(Cr,1.0)
G=np.outer(sd,sd)*Cr
print("genetic SD by test day:",np.round(sd,4))
print("G (10x10):\n",G)
print("corr:\n",np.round(Cr,4))
print("eigs(G):",np.round(np.linalg.eigvalsh(G)[::-1],5))
print("trace(G)=",G.trace())
for k in (1,2,3,5):
    Ph=phi(tx(td),k); Pi=np.linalg.pinv(Ph)
    K=Pi@G@Pi.T
    Gh=Ph@K@Ph.T
    ev=np.linalg.eigvalsh(K)[::-1]
    print(f"\n=== k={k} ({k+1} basis, {(k+1)*(k+2)//2} params) ===")
    print("K=\n",np.round(K,5))
    print("eigs(K):",np.round(ev,6)," share:",np.round(ev/ev.sum(),4)," cum:",np.round(np.cumsum(ev)/ev.sum(),4))
    print("rel RMSE of fit:",np.sqrt(((Gh-G)**2).mean())/np.sqrt((G**2).mean()),
          " max abs dev:",np.abs(Gh-G).max()," diag fit:",np.round(np.diag(Gh),4))
    tt=np.array([5,15,150,285,305.0]); Pt=phi(tx(tt),k)
    print("var function at t=5,15,150,285,305:",np.round(np.einsum('ij,jk,ik->i',Pt,K,Pt),4))
    w=np.zeros(k+1); w[0]=(tmax-tmin)/2*np.sqrt(2)
    print("Var(305d EBV)=w'Kw=",round(float(w@K@w),3)," sd=",round(float(np.sqrt(w@K@w)),3))
    # persistency contrast u(280)-u(60)
    c=(phi(tx(280.0),k)-phi(tx(60.0),k))[0]
    print("Var(persistency u(280)-u(60))=",round(float(c@K@c),4))
# rank reduction at k=3
k=3; Ph=phi(tx(td),k); Pi=np.linalg.pinv(Ph); K=Pi@G@Pi.T
ev,V=np.linalg.eigh(K); ev=ev[::-1]; V=V[:,::-1]
print("\n--- eigenfunctions at k=3 ---")
for j in range(4):
    print(f" psi_{j+1}: lambda={ev[j]:.5f} v={np.round(V[:,j],4)}")
    tt=np.array([15,75,150,225,285.0]); print("   psi at t=15,75,150,225,285:",np.round(phi(tx(tt),k)@V[:,j],4))
for r in (1,2,3,4):
    Kr=V[:,:r]@np.diag(ev[:r])@V[:,:r].T
    Gh=Ph@Kr@Ph.T
    print(f" rank {r}: var explained={ev[:r].sum()/ev.sum():.4f}  rel RMSE vs G={np.sqrt(((Gh-G)**2).mean())/np.sqrt((G**2).mean()):.4f}  #par={r*(2*(k+1)-r+1)//2}")
