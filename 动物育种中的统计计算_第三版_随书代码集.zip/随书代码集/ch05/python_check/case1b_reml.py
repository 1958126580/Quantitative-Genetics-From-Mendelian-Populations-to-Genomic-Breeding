# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 case1b_reml.py    依赖：numpy, scipy
"""案例一（续）：用漏近交的 A⁻¹ 做 REML，遗传力被高估还是低估？"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import numpy as np
from scipy.optimize import minimize_scalar
import importlib.util, sys
spec = importlib.util.spec_from_file_location("c1", os.path.join(HERE, 'case1_ainv.py'))

def amatrix(ped):
    n = ped.shape[0]; A = np.zeros((n, n))
    for i in range(n):
        s, d = ped[i]
        for j in range(i):
            A[i, j] = A[j, i] = 0.5*((A[j, s] if s >= 0 else 0.0)+(A[j, d] if d >= 0 else 0.0))
        A[i, i] = 1.0 + 0.5*(A[s, d] if (s >= 0 and d >= 0) else 0.0)
    return A

def ainv(ped, F, correct=True):
    n = ped.shape[0]; Ai = np.zeros((n, n))
    for i in range(n):
        s, d = ped[i]
        if s >= 0 and d >= 0:
            b = 0.5-0.25*((F[s]+F[d]) if correct else 0.0); idx=[i,s,d]; q=np.array([1.,-.5,-.5])
        elif s >= 0 or d >= 0:
            p = s if s >= 0 else d
            b = 0.75-0.25*(F[p] if correct else 0.0); idx=[i,p]; q=np.array([1.,-.5])
        else:
            b = 1.0; idx=[i]; q=np.array([1.])
        w = 1.0/b
        for a_,ia in enumerate(idx):
            for b_,ib in enumerate(idx): Ai[ia,ib] += w*q[a_]*q[b_]
    return Ai

def sim_pedigree(n_found=20, n_gen=6, n_off=30, rng=None):
    rng = rng or np.random.default_rng(7)
    ped=[(-1,-1)]*n_found; sex=list(rng.integers(0,2,n_found)); cur=list(range(n_found))
    for g in range(n_gen):
        males=[i for i in cur if sex[i]==0]; females=[i for i in cur if sex[i]==1]
        if not males or not females: break
        males=list(rng.choice(males,size=min(3,len(males)),replace=False)); nxt=[]
        for k in range(n_off):
            s=int(rng.choice(males)); d=int(rng.choice(females))
            ped.append((s,d)); sex.append(int(rng.integers(0,2))); nxt.append(len(ped)-1)
        cur=nxt
    return np.array(ped,dtype=int)

rng = np.random.default_rng(20240513)
ped = sim_pedigree(rng=rng); n = ped.shape[0]
A = amatrix(ped); F = np.diag(A)-1.0
Ai_w = ainv(ped, F, False); A_w = np.linalg.inv(Ai_w)
X = np.ones((n,1)); p = 1

def reml_h2(y, Aassume):
    ev, U = np.linalg.eigh(Aassume)
    ev = np.maximum(ev, 1e-12)
    Uty = U.T @ y; UtX = U.T @ X
    def nll(lg):
        g = np.exp(lg); dv = 1.0 + g*ev
        logdetV = np.log(dv).sum()
        XtVX = (UtX.T * (1/dv)) @ UtX
        XtVy = (UtX.T * (1/dv)) @ Uty
        q = (Uty**2/dv).sum() - float(XtVy.T @ np.linalg.solve(XtVX, XtVy))
        s2e = q/(n-p)
        return 0.5*((n-p)*np.log(s2e) + logdetV + np.log(np.linalg.det(XtVX)) + (n-p))
    r = minimize_scalar(nll, bounds=(-9, 6), method='bounded', options={'xatol':1e-7})
    g = np.exp(r.x)
    return g/(1+g)

h2_true = 0.30; sa = h2_true; se = 1-h2_true
L = np.linalg.cholesky(A + 1e-10*np.eye(n))
R = 300
hc = np.zeros(R); hw = np.zeros(R)
for r in range(R):
    u = L @ rng.standard_normal(n)*np.sqrt(sa)
    y = 10.0 + u + rng.standard_normal(n)*np.sqrt(se)
    hc[r] = reml_h2(y, A); hw[r] = reml_h2(y, A_w)
print("真值 h² = %.2f, 重复 R = %d, n = %d, 平均 F = %.3f" % (h2_true, R, n, F.mean()))
print("正确 A⁻¹  : ĥ² 均值 %.4f  (偏差 %+.4f)  sd %.4f" % (hc.mean(), hc.mean()-h2_true, hc.std()))
print("漏近交 A⁻¹: ĥ² 均值 %.4f  (偏差 %+.4f)  sd %.4f" % (hw.mean(), hw.mean()-h2_true, hw.std()))
print("配对差 均值 %+.4f  (sd %.4f, 相对 %+.1f%%)" % ((hw-hc).mean(), (hw-hc).std(), 100*(hw-hc).mean()/h2_true))
print("ĥ²_漏 > ĥ²_正确 的比例 = %.3f" % (hw > hc).mean())
