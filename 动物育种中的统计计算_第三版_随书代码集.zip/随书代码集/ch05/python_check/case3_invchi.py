# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 case3_invchi.py    依赖：numpy
"""案例三：逆卡方参数化（推导 + 抽样验证 + 对 BayesA 的后果）"""
import numpy as np
rng = np.random.default_rng(31415)
nu, S = 4.0, 1.0
N = 400000
# 写法 A（本书约定）：σ² = νS/χ²_ν
a = nu*S/rng.chisquare(nu, N)
# 写法 B：误把 νS 当作尺度 → σ² = ν(νS)/χ²_ν
b = nu*(nu*S)/rng.chisquare(nu, N)
# 写法 C：InvGamma(α,β) 且误取 β=S（漏掉 ν/2）→ σ² = S/Gamma(ν/2,1)
c = S/rng.gamma(nu/2, 1.0, N)
# 写法 D：InvGamma(α=ν/2, β=νS/2) —— 与 A 等价
d = (nu*S/2)/rng.gamma(nu/2, 1.0, N)
for tag, x, th in [("A: χ⁻²(ν,S)，σ²=νS/χ²_ν", a, nu*S/(nu-2)),
                   ("B: 尺度误写为 νS",        b, nu*nu*S/(nu-2)),
                   ("C: InvGamma(ν/2, S)",     c, S/(nu/2-1)),
                   ("D: InvGamma(ν/2, νS/2)",  d, nu*S/(nu-2))]:
    print("%-28s 抽样均值 %7.4f   理论均值 %7.4f   众数(理论) %6.4f" 
          % (tag, x.mean(), th, (nu*S/(nu+2) if tag[0] in 'AD' else (nu*nu*S/(nu+2) if tag[0]=='B' else S/(nu/2+1)))))
print("\nν=4, S=1 时：A/D 的先验均值 = 2；B 高 %.0f 倍；C 低 %.0f 倍" % (nu*nu*S/(nu-2)/(nu*S/(nu-2)), (nu*S/(nu-2))/(S/(nu/2-1))))

# --- 后果：BayesA 中每个标记一个方差 ---
# σ_j² | α_j ~ χ⁻²(ν+1, (νS+α_j²)/(ν+1))，后验均值 (νS+α_j²)/(ν−1)
print("\nBayesA 的单位点收缩：σ_j² 的后验均值 = (νS+α_j²)/(ν−1)")
print("%8s | %12s | %12s | %12s" % ("α_j", "正确 S", "S 误乘 ν", "S 误除 ν"))
for al in [0.0, 0.05, 0.2, 0.5]:
    S0 = 0.01
    e_ok  = (nu*S0+al**2)/(nu-1)
    e_hi  = (nu*(nu*S0)+al**2)/(nu-1)
    e_lo  = (nu*(S0/nu)+al**2)/(nu-1)
    print("%8.2f | %12.5f | %12.5f | %12.5f" % (al, e_ok, e_hi, e_lo))
# 收缩因子 λ_j = σ_e²/σ_j²
se2 = 0.6
print("\n对应的收缩系数 λ_j = σ_e²/σ_j²（σ_e²=%.1f）：" % se2)
for al in [0.0, 0.05, 0.2, 0.5]:
    S0 = 0.01
    print("  α_j=%.2f : 正确 %9.1f | S 误乘 ν %9.1f | S 误除 ν %9.1f"
          % (al, se2/((nu*S0+al**2)/(nu-1)), se2/((nu*(nu*S0)+al**2)/(nu-1)), se2/((nu*(S0/nu)+al**2)/(nu-1))))
