# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 case4b.py    依赖：numpy
import numpy as np, time
rng = np.random.default_rng(424242)
n, m = 300, 100
p = rng.uniform(0.1,0.9,m); M = rng.binomial(2,p,size=(n,m)).astype(float); Z = M-2*p
h2=0.5; s2a=h2/(2*np.sum(p*(1-p))); s2e=1-h2
alpha_t = rng.standard_normal(m)*np.sqrt(s2a)
y = 5.0 + Z@alpha_t + rng.standard_normal(n)*np.sqrt(s2e)
lam = s2e/s2a; X=np.ones((n,1))
C = np.block([[X.T@X, X.T@Z],[Z.T@X, Z.T@Z+lam*np.eye(m)]])
sol = np.linalg.solve(C, np.concatenate([X.T@y, Z.T@y])); a_ex=sol[1:]
Cinv = np.linalg.inv(C); sd_ex = np.sqrt(np.diag(Cinv)[1:]*s2e)
zpz=(Z*Z).sum(0)
def gibbs(bug=None, niter=15000, burn=3000, seed=1):
    g=np.random.default_rng(seed); a=np.zeros(m); mu=y.mean(); e=y-mu-Z@a
    s1=np.zeros(m); s2=np.zeros(m); cnt=0
    for it in range(niter):
        mu_n=(e.sum()+n*mu)/n + g.standard_normal()*np.sqrt(s2e/n); e-=(mu_n-mu); mu=mu_n
        for j in range(m):
            zj=Z[:,j]
            rhs = zj@e + (0.0 if bug=='rhs' else zpz[j]*a[j])
            lhs = zpz[j]+lam
            aj = rhs/lhs + g.standard_normal()*np.sqrt(s2e/lhs)
            if bug in ('jacobi','never'): a[j]=aj
            else: e-=zj*(aj-a[j]); a[j]=aj
        if bug=='jacobi': e = y-mu-Z@a          # 每轮末重算
        if it>=burn: s1+=a; s2+=a*a; cnt+=1
    return s1/cnt, np.sqrt(np.maximum(s2/cnt-(s1/cnt)**2,0))
for tag,bug in [("正确",None),("漏 z'z·α^old",'rhs'),("轮内不更新 e，轮末重算",'jacobi'),("从不更新 e",'never')]:
    am,asd = gibbs(bug)
    print("%-24s 斜率(对解析解) %.4f  corr %.5f  后验SD 比值中位数 %.4f"
          % (tag, np.polyfit(a_ex,am,1)[0], np.corrcoef(am,a_ex)[0,1], np.median(asd/sd_ex)))
