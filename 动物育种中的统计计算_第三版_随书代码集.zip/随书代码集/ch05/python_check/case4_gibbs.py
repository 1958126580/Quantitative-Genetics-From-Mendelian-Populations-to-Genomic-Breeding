# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 case4_gibbs.py    依赖：numpy
"""案例四：Gibbs 完全条件分布漏项（与解析解对照）"""
import numpy as np, time
rng = np.random.default_rng(424242)
n, m = 300, 100
p = rng.uniform(0.1,0.9,m)
M = rng.binomial(2,p,size=(n,m)).astype(float)
Z = M - 2*p
h2 = 0.5; s2a = h2/(2*np.sum(p*(1-p))); s2e = 1-h2
alpha_t = rng.standard_normal(m)*np.sqrt(s2a)
y = 5.0 + Z@alpha_t + rng.standard_normal(n)*np.sqrt(s2e)
lam = s2e/s2a
# 解析解：方差已知时 SNP-BLUP 的后验均值 = MME 解
X = np.ones((n,1))
C = np.block([[X.T@X, X.T@Z],[Z.T@X, Z.T@Z+lam*np.eye(m)]])
sol = np.linalg.solve(C, np.concatenate([X.T@y, Z.T@y]))
mu_ex, a_ex = sol[0], sol[1:]

zpz = (Z*Z).sum(0)
def gibbs(bug=None, niter=15000, burn=3000, seed=1):
    g = np.random.default_rng(seed)
    a = np.zeros(m); mu = y.mean(); e = y - mu - Z@a
    acc = np.zeros(m); accmu = 0.0; cnt = 0
    for it in range(niter):
        # 截距
        rhs = e.sum() + n*mu; lhs = n
        mu_n = rhs/lhs + g.standard_normal()*np.sqrt(s2e/lhs)
        e -= (mu_n-mu); mu = mu_n
        for j in range(m):
            zj = Z[:,j]
            if bug == 'rhs':            # 漏掉 z_j'z_j α_j^old
                rhs = zj@e
            else:
                rhs = zj@e + zpz[j]*a[j]
            lhs = zpz[j] + lam
            aj = rhs/lhs + g.standard_normal()*np.sqrt(s2e/lhs)
            if bug == 'noe':            # 忘记更新残差
                a[j] = aj
            else:
                e -= zj*(aj-a[j]); a[j] = aj
        if bug == 'noe':                # 每轮末才重算（"偶尔重算"版本）
            e = y - mu - Z@a
        if it >= burn:
            acc += a; accmu += mu; cnt += 1
    return acc/cnt, accmu/cnt

t0=time.time()
res = {}
for tag,bug in [("正确", None), ("漏 z_j'z_j·α_j^old", 'rhs'), ("忘记更新残差 e", 'noe')]:
    am, mum = gibbs(bug)
    res[tag] = (am, mum)
    r = np.corrcoef(am, a_ex)[0,1]
    slope = np.polyfit(a_ex, am, 1)[0]
    print("%-20s 与解析解 corr=%.5f  回归斜率=%.4f  ‖差‖/‖解析解‖=%.4f  截距 μ̂=%.4f(解析 %.4f)"
          % (tag, r, slope, np.linalg.norm(am-a_ex)/np.linalg.norm(a_ex), mum, mu_ex))
print("(%.1f s)"%(time.time()-t0))
am = res["漏 z_j'z_j·α_j^old"][0]
print("\n漏项版：后验均值的方差是解析解的 %.4f 倍；SNP 效应总方差 Σα̂² 之比 = %.4f"
      % (am.var()/a_ex.var(), (am**2).sum()/(a_ex**2).sum()))
gb = Z@am; ge = Z@a_ex; gt = Z@alpha_t
print("育种值：corr(漏项版, 解析解)=%.5f ；与真值的相关 %.4f vs %.4f ；回归斜率(真值 on 预测) %.3f vs %.3f"
      % (np.corrcoef(gb,ge)[0,1], np.corrcoef(gb,gt)[0,1], np.corrcoef(ge,gt)[0,1],
         np.polyfit(gb,gt,1)[0], np.polyfit(ge,gt,1)[0]))
print("\n理论：漏掉 z_j'z_j·α_j^old 时，条件均值变为 z_j'e/(z_j'z_j+λ)，而 e 中仍含 −z_jα_j^old，")
print("      故每次更新都把 α_j 再乘一次 λ/(z_j'z_j+λ) 之外的额外收缩；本例 z_j'z_j 均值 = %.1f，λ = %.1f" % (zpz.mean(), lam))
