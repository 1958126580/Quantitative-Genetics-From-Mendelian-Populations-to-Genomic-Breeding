# 第 5 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch05/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `case1_ainv.py` | 案例一：A^{-1} 漏近交修正的后果（实算） | numpy | 0.6 | `outputs/case1_ainv.out` |
| `case1b_reml.py` | 案例一（续）：用漏近交的 A⁻¹ 做 REML，遗传力被高估还是低估？ | numpy, scipy | 10.9 | `outputs/case1b_reml.out` |
| `case2_gmat.py` | 案例二：G 矩阵的中心化基准（实算） | numpy | 3.4 | `outputs/case2_gmat.out` |
| `case2b.py` | 案例二（续）：中心化基准的真正后果在哪里 | numpy, scipy | 4.5 | `outputs/case2b.out` |
| `case3_invchi.py` | 案例三：逆卡方参数化（推导 + 抽样验证 + 对 BayesA 的后果） | numpy | 0.5 | `outputs/case3_invchi.out` |
| `case4_gibbs.py` | 案例四：Gibbs 完全条件分布漏项（与解析解对照） | numpy | 58.8 | `outputs/case4_gibbs.out` |
| `case4b.py` | 数值复核 | numpy | 72.1 | `outputs/case4b.out` |
| `conventions.py` | 移植逐项对照：把"默认参数不同"逐条实测出来 | numpy, pandas, scipy | 2.3 | `outputs/conventions.out` |
| `reduction.py` | 数值复核 | numpy | 3.7 | `outputs/reduction.out` |
| `verif_layers.py` | 第六、七层验证的功效：需要多少次重复 | numpy, scipy | 75.0 | `outputs/verif_layers.out` |
