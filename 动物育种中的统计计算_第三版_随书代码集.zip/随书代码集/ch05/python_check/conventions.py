# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 conventions.py    依赖：numpy, pandas, scipy
"""移植逐项对照：把"默认参数不同"逐条实测出来"""
import numpy as np, scipy.linalg as sla
x = np.array([1.0,2.0,4.0,8.0])
print("样本 x =", x)
print("np.var(x)              =", np.var(x), "  (ddof=0, 除以 n)")
print("np.var(x, ddof=1)      =", np.var(x,ddof=1), "  (除以 n−1；R 的 var()、Julia 的 var() 默认是这个)")
print("np.std(x)/np.std(x,1)  = %.6f / %.6f  比值 %.6f = sqrt((n-1)/n)" % (np.std(x),np.std(x,ddof=1),np.std(x)/np.std(x,ddof=1)))
print("→ n=%d 时标准化后的 Z 差 %.2f%%；m=50000 个标记逐列标准化后 G 的尺度差同样是这个比例" % (len(x),100*(1-np.std(x)/np.std(x,ddof=1))))
for n in [4, 100, 2000]:
    print("   n=%5d: sqrt((n-1)/n)=%.6f → 方差尺度差 %.3f%%" % (n, np.sqrt((n-1)/n), 100*(1-(n-1)/n)))

A = np.array([[4.0,2.0,1.0],[2.0,5.0,3.0],[1.0,3.0,6.0]])
Ln = np.linalg.cholesky(A)          # numpy: 下三角 A = L L'
Us = sla.cholesky(A)                # scipy 默认 lower=False: 上三角 A = U' U
print("\nCholesky 约定：")
print(" np.linalg.cholesky → 下三角 L，A = L·Lᵀ ；对角 =", np.round(np.diag(Ln),4))
print(" scipy.linalg.cholesky（默认）→ 上三角 U，A = Uᵀ·U ；对角 =", np.round(np.diag(Us),4))
print(" 两者满足 U = Lᵀ 吗？", np.allclose(Us, Ln.T), "（R 的 chol() 返回上三角；Julia 用 cholesky(A).L / .U 显式取）")
print(" 若把上三角当下三角用：L_wrong·L_wrongᵀ 的第一个元素 =", np.round((Us@Us.T)[0,0],4), "，而 A[1,1] =", A[0,0])

w,V = np.linalg.eigh(A)
print("\n特征值顺序：np.linalg.eigh 升序 =", np.round(w,4), "（R 的 eigen() 默认降序；Julia eigen() 升序）")
print(" 取'前 k 个主成分'若照搬 R 的写法 V[:,1:k]，在 numpy/Julia 中取到的是最小的 k 个：",
      np.round(w[:2],4), "vs", np.round(w[-2:],4))
print(" 特征向量符号不唯一：−v 也是特征向量，跨语言逐位对照必然失败；应对照 |V| 或 V·diag(sign(V[1,:]))")

print("\n缺失值语义：")
a=np.array([1.0,2.0,np.nan,4.0])
print(" np.mean 含 NaN →", np.mean(a), "; np.nanmean →", np.nanmean(a))
try:
    import pandas as pd
    print(" pandas Series.mean() 默认 skipna=True →", pd.Series(a).mean())
except Exception as e:
    print(" pandas 不可用")
print(" R 的 mean() 默认 na.rm=FALSE（返回 NA），但 lm() 默认 na.action=na.omit（**悄悄删行**）")

print("\n整数除法与取模：")
print(" Python 3: 7/2 =", 7/2, "; 7//2 =", 7//2, "; -7//2 =", -7//2, "(向下取整)")
print(" Julia:    7/2 = 3.5 ; div(7,2)=7÷2 = 3 ; div(-7,2) = -3 (向零取整) —— 负数处不同")
print(" numpy 取模 -7 %% 2 =", -7 % 2, "（Python 结果符号随除数）")

print("\n浮点归约顺序（并行/分块会改变结果）：")
g=np.random.default_rng(0); v=g.standard_normal(10_000_000)
s_seq = np.float64(0.0)
for chunk in [v]:
    pass
def naive(v):
    s=np.float64(0.0)
    for k in range(0, v.size, 1_000_000):
        s += np.add.reduce(v[k:k+1_000_000])   # 分块再累加
    return s
ref = math_sum = float(np.sum(v))             # numpy 内部成对求和
alt = [float(np.add.reduce(v.reshape(k,-1),axis=1).sum()) for k in (1,2,4,8,16)]
print(" np.sum(v) =", repr(ref))
print(" 不同分块数下的和 :", [repr(a) for a in alt])
print(" 最大相对差 = %.2e （n=10⁷，Float64）；这就是'多线程归约不可逐位复现'的量级" 
      % (max(abs(a-ref) for a in alt)/max(abs(ref),1e-300)))
v32=v.astype(np.float32)
alt32=[float(np.add.reduce(v32.reshape(k,-1),axis=1).sum()) for k in (1,2,4,8,16)]
print(" 换成 Float32：最大相对差 = %.2e" % (max(abs(a-alt32[0]) for a in alt32)/max(abs(alt32[0]),1e-300)))
