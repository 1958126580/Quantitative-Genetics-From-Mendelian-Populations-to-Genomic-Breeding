# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 reduction.py    依赖：numpy
import numpy as np, math
g=np.random.default_rng(0)
n=10_000_000
v=g.standard_normal(n)*1000 + 1e6          # 量级悬殊：模拟"大均值+小离差"的表型数据
ref=math.fsum(v.tolist())                  # 精确（Kahan/Shewchuk）参考
seq=np.float64(0.0)
for chunk in np.array_split(v, 1000):      # 近似顺序累加（1000 段，段内成对）
    for x in chunk[:0]: pass
def leftright(v):
    s=np.float64(0.0)
    acc=v.astype(np.float64)
    tot=np.float64(0.0)
    for x in np.add.reduceat(acc, np.arange(0,acc.size,1000)):  # 每 1000 个成对求和后左→右累加
        tot=tot+x
    return float(tot)
lr=leftright(v)
pw=float(np.sum(v))
perm=float(np.sum(v[g.permutation(n)]))
f32=float(np.sum(v.astype(np.float32)))
print("精确和 (fsum)       = %.6f" % ref)
print("np.sum（成对求和）  = %.6f  相对误差 %.2e" % (pw,abs(pw-ref)/abs(ref)))
print("分段左→右累加       = %.6f  相对误差 %.2e" % (lr,abs(lr-ref)/abs(ref)))
print("打乱次序后 np.sum    = %.6f  相对误差 %.2e" % (perm,abs(perm-ref)/abs(ref)))
print("Float32 的 np.sum    = %.6f  相对误差 %.2e" % (f32,abs(f32-ref)/abs(ref)))
print("→ 同一批数、只改求和次序，Float64 的结果就已相差 %.1e 的相对量；" % (abs(lr-pw)/abs(ref)))
print("  因此'多线程归约与单线程逐位相同'是不能要求的；正确的验收标准是 rtol 而不是 ==。")
# 需要多大的 rtol
print("建议阈值：本例三种次序的最大相对散布 = %.2e，取 rtol=1e-10 足够宽、又能抓住真错误"
      % max(abs(a-ref)/abs(ref) for a in (pw,lr,perm)))
