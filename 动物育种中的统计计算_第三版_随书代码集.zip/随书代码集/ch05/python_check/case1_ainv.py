# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 case1_ainv.py    依赖：numpy
"""案例一：A^{-1} 漏近交修正的后果（实算）"""
import numpy as np

def amatrix(ped):
    """ped: n x 2 int array, 0-based parent index or -1 for unknown, topologically sorted"""
    n = ped.shape[0]
    A = np.zeros((n, n))
    for i in range(n):
        s, d = ped[i]
        for j in range(i):
            asj = A[j, s] if s >= 0 else 0.0
            adj = A[j, d] if d >= 0 else 0.0
            A[i, j] = A[j, i] = 0.5 * (asj + adj)
        asd = A[s, d] if (s >= 0 and d >= 0) else 0.0
        A[i, i] = 1.0 + 0.5 * asd
    return A

def ainv(ped, F, correct=True):
    n = ped.shape[0]
    Ai = np.zeros((n, n))
    for i in range(n):
        s, d = ped[i]
        if s >= 0 and d >= 0:
            b = 0.5 - 0.25 * ((F[s] + F[d]) if correct else 0.0)
            idx = [i, s, d]; q = np.array([1.0, -0.5, -0.5])
        elif s >= 0 or d >= 0:
            p = s if s >= 0 else d
            b = 0.75 - 0.25 * (F[p] if correct else 0.0)
            idx = [i, p]; q = np.array([1.0, -0.5])
        else:
            b = 1.0
            idx = [i]; q = np.array([1.0])
        w = 1.0 / b
        for a_, ia in enumerate(idx):
            for b_, ib in enumerate(idx):
                Ai[ia, ib] += w * q[a_] * q[b_]
    return Ai

def sim_pedigree(n_found=20, n_gen=6, n_off=30, rng=None):
    rng = rng or np.random.default_rng(7)
    ped = [(-1, -1)] * n_found
    sex = list(rng.integers(0, 2, n_found))   # 0 male 1 female
    cur = list(range(n_found))
    for g in range(n_gen):
        males = [i for i in cur if sex[i] == 0]
        females = [i for i in cur if sex[i] == 1]
        if not males or not females:
            break
        males = list(rng.choice(males, size=min(3, len(males)), replace=False))  # few sires -> inbreeding
        nxt = []
        for k in range(n_off):
            s = int(rng.choice(males)); d = int(rng.choice(females))
            ped.append((s, d)); sex.append(int(rng.integers(0, 2))); nxt.append(len(ped) - 1)
        cur = nxt
    return np.array(ped, dtype=int)

rng = np.random.default_rng(20240513)
ped = sim_pedigree(rng=rng)
n = ped.shape[0]
A = amatrix(ped)
F = np.diag(A) - 1.0
print("n =", n, " 平均 F = %.4f" % F.mean(), " max F = %.4f" % F.max(),
      " F>0 的比例 = %.3f" % (F > 1e-12).mean())
# 最后一个世代的平均 F
last = np.arange(n - 30, n)
print("末代平均 F = %.4f" % F[last].mean())

Ai_c = ainv(ped, F, True)
Ai_w = ainv(ped, F, False)
I = np.eye(n)
print("‖A·A⁻¹(正确) − I‖_max = %.3e" % np.abs(A @ Ai_c - I).max())
print("‖A·A⁻¹(漏近交) − I‖_max = %.3f" % np.abs(A @ Ai_w - I).max())
print("‖A·A⁻¹(漏近交) − I‖_F  = %.3f" % np.linalg.norm(A @ Ai_w - I))
# 漏近交的 A^{-1} 对应哪个"隐含的 A"
Aw = np.linalg.inv(Ai_w)
print("隐含 A 的对角均值 = %.4f （真值 %.4f）" % (np.diag(Aw).mean(), np.diag(A).mean()))
print("隐含 F 的均值     = %.4f （真值 %.4f）" % ((np.diag(Aw)-1).mean(), F.mean()))

# --- BLUP 对照 ---
h2 = 0.30; sa = h2; se = 1 - h2; lam = se / sa
Z = np.eye(n); X = np.ones((n, 1))
L = np.linalg.cholesky(A + 1e-10 * I)
u_true = L @ rng.standard_normal(n) * np.sqrt(sa)
y = 10.0 + u_true + rng.standard_normal(n) * np.sqrt(se)

def blup(Ainv_, lam):
    C = np.block([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + Ainv_ * lam]])
    r = np.concatenate([X.T @ y, Z.T @ y])
    sol = np.linalg.solve(C, r)
    Cinv = np.linalg.inv(C)
    d = np.diag(Cinv)[1:]
    pev = d * se
    rel = 1 - pev / (sa * np.diag(A))     # 用真 a_ii 算可靠性
    rel_rep = 1 - d * lam                 # 软件常报的 r² = 1 - d_ii*λ（隐含 a_ii=1）
    return sol[1:], rel, rel_rep

u_c, rel_c, relrep_c = blup(Ai_c, lam)
u_w, rel_w, relrep_w = blup(Ai_w, lam)
print("\nEBV: corr(正确, 漏近交) = %.5f" % np.corrcoef(u_c, u_w)[0, 1])
print("EBV: 最大绝对差 / σ_a = %.4f, 平均绝对差 / σ_a = %.4f"
      % (np.abs(u_c - u_w).max() / np.sqrt(sa), np.abs(u_c - u_w).mean() / np.sqrt(sa)))
k = 20
top_c = set(np.argsort(-u_c)[:k]); top_w = set(np.argsort(-u_w)[:k])
print("前 %d 名重合数 = %d/%d" % (k, len(top_c & top_w), k))
print("可靠性均值：正确 %.4f，漏近交 %.4f（差 %.4f）" % (rel_c.mean(), rel_w.mean(), rel_w.mean()-rel_c.mean()))
print("末代可靠性均值：正确 %.4f，漏近交 %.4f" % (rel_c[last].mean(), rel_w[last].mean()))
print("与真值的相关：正确 %.4f，漏近交 %.4f" % (np.corrcoef(u_c, u_true)[0,1], np.corrcoef(u_w, u_true)[0,1]))
