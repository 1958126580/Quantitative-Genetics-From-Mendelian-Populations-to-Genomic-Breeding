# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 case2_gmat.py    依赖：numpy
"""案例二：G 矩阵的中心化基准（实算）"""
import numpy as np
rng = np.random.default_rng(2025)
m, n0 = 3000, 1200
p0 = rng.uniform(0.05, 0.95, m)                      # 基础群频率
# 基础群基因型
M0 = rng.binomial(2, p0, size=(n0, m)).astype(float)
# 经 8 代有限群体规模的漂变得到"当前群体"
Ne = 60
p = p0.copy()
for g in range(8):
    p = rng.binomial(2*Ne, p)/(2*Ne)
p = np.clip(p, 1e-6, 1-1e-6)
n = 1000
M = rng.binomial(2, p, size=(n, m)).astype(float)
print("频率漂变：corr(p0,p)=%.4f，平均 |p−p0|=%.4f，固定位点数 %d"
      % (np.corrcoef(p0,p)[0,1], np.abs(p-p0).mean(), int(((p<1e-5)|(p>1-1e-5)).sum())))

def G_of(M, pcent, pdenom=None):
    pd = pcent if pdenom is None else pdenom
    Z = M - 2*pcent
    return Z @ Z.T / (2*np.sum(pd*(1-pd)))

G_base = G_of(M, p0)     # 用基础群频率（VanRaden 原始定义）
G_cur  = G_of(M, p)      # 用当前样本频率（常见近似）
n_ = n
for tag, G in [("基础群频率 p0", G_base), ("当前样本频率 p̂", G_cur)]:
    off = G[np.triu_indices(n_,1)]
    print("%-14s  tr(G)/n = %.4f   diag 均值 = %.4f   非对角均值 = %.5f   全矩阵均值 = %.5f"
          % (tag, np.trace(G)/n_, np.diag(G).mean(), off.mean(), G.mean()))

# 性质：用样本频率中心化时，Z 的列均值恰为 0，非对角均值≈−diag均值/(n−1) → 全矩阵均值≈0
Zc = M - 2*p
print("列均值 |max| : 用 p̂ 中心化 %.2e ；用 p0 中心化 %.4f" % (np.abs(Zc.mean(0)).max(), np.abs((M-2*p0).mean(0)).max()))

# --- 后果 1：GEBV ---
h2 = 0.4
alpha = rng.standard_normal(m)*np.sqrt(h2/(2*np.sum(p*(1-p))))
g = (M-2*p) @ alpha
g = g/np.std(g)*np.sqrt(h2)
y = g + rng.standard_normal(n)*np.sqrt(1-h2)
lam = (1-h2)/h2
X = np.ones((n,1))
def gblup(G):
    Gr = G + 0.01*np.eye(n)          # 轻微正则化以可逆
    C = np.block([[X.T@X, X.T],[X, np.eye(n)+np.linalg.inv(Gr)*lam]])
    r = np.concatenate([X.T@y, y])
    s = np.linalg.solve(C, r)
    return s[1:]
gb = gblup(G_base); gc = gblup(G_cur)
print("\nGEBV: corr(基础群频率版, 当前频率版) = %.5f ;  与真 g 的相关：%.4f vs %.4f"
      % (np.corrcoef(gb,gc)[0,1], np.corrcoef(gb,g)[0,1], np.corrcoef(gc,g)[0,1]))

# --- 后果 2：基因型编码被悄悄换成 {-1,0,1} 而中心化仍用 2p ---
Mc = M - 1.0
G_bad = Mc @ Mc.T/(2*np.sum(p*(1-p)))            # 完全忘了中心化（等价于用 p=0.5）
Zmix = Mc - 2*p                                   # 编码换了但中心化没换
G_mix = Zmix @ Zmix.T/(2*np.sum(p*(1-p)))
shift = m/(2*np.sum(p*(1-p)))
print("\n编码/中心化不一致：G_mix − G_cur 的元素应为常数 %.4f；实测均值 %.4f，标准差 %.2e"
      % (shift, (G_mix-G_cur).mean(), (G_mix-G_cur).std()))
print("G_mix: tr/n = %.4f  非对角均值 = %.4f （正确版 %.5f）"
      % (np.trace(G_mix)/n_, G_mix[np.triu_indices(n_,1)].mean(), G_cur[np.triu_indices(n_,1)].mean()))
gm = gblup(G_mix)
print("GEBV: corr(G_mix 版, 正确版) = %.5f ;  与真 g 的相关 %.4f（正确版 %.4f）"
      % (np.corrcoef(gm,gc)[0,1], np.corrcoef(gm,g)[0,1], np.corrcoef(gc,g)[0,1]))
