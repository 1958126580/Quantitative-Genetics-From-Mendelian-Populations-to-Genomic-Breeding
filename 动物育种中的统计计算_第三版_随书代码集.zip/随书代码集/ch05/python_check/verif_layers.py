# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 verif_layers.py    依赖：numpy, scipy
"""第六、七层验证的功效：需要多少次重复"""
import numpy as np
from scipy import stats
rng=np.random.default_rng(1234)

# ---- (A) 参数回收：检验 sd(z)=1，能否检出"标准误低估 10%" ----
# 若 SE 被低估 10%，则 z=(θ̂−θ0)/SE 的真实 sd = 1/0.9 = 1.1111
# (R−1)s²/σ² ~ χ²_{R−1}；检验 H0: σ=1（双侧 α=0.05）
print("参数回收：检验 sd(z)=1 的功效（双侧 α=0.05）")
print("%6s | %8s %8s %8s" % ("R","SE低估5%","SE低估10%","SE低估20%"))
for R in [50,100,200,400,800,1600]:
    row=[]
    for d in [0.05,0.10,0.20]:
        sig=1/(1-d)
        lo=stats.chi2.ppf(0.025,R-1); hi=stats.chi2.ppf(0.975,R-1)
        # P((R-1)s²>hi 或 <lo | σ=sig)，其中 (R-1)s²/sig² ~ χ²_{R-1}
        pw = 1-stats.chi2.cdf(hi/sig**2,R-1) + stats.chi2.cdf(lo/sig**2,R-1)
        row.append(pw)
    print("%6d | %7.3f %8.3f %8.3f"%(R,*row))
# 精确解需要的 R
for d in [0.05,0.10,0.20]:
    for R in range(20,20001):
        sig=1/(1-d); lo=stats.chi2.ppf(0.025,R-1); hi=stats.chi2.ppf(0.975,R-1)
        if 1-stats.chi2.cdf(hi/sig**2,R-1)+stats.chi2.cdf(lo/sig**2,R-1) >= 0.80:
            print("  达到 80%% 功效所需 R：SE 低估 %.0f%% → R = %d"%(100*d,R)); break

# ---- (B) SBC：秩直方图对后验过窄/过宽的灵敏度 ----
# 模型 θ~N(0,1)，y|θ~N(θ,σ²/n)；正确后验 N(m,v)；有 bug 的实现把后验方差乘了 c
print("\nSBC：秩直方图的卡方检验功效（L=99 个后验样本，B=20 个分箱，α=0.05）")
def sbc_power(c, R, nrep=2000, L=99, B=20, sig2=1.0, nobs=10):
    v = 1/(1+nobs/sig2); 
    g=np.random.default_rng(int(abs(c)*1e6)+R)
    rej=0
    for _ in range(nrep):
        th0=g.standard_normal(R)
        ybar=th0+g.standard_normal(R)*np.sqrt(sig2/nobs)
        m=v*(nobs/sig2)*ybar
        draws=m[:,None]+g.standard_normal((R,L))*np.sqrt(v*c)
        rank=(draws<th0[:,None]).sum(1)          # 0..L
        cnt=np.bincount((rank*B)//(L+1),minlength=B)
        chi=((cnt-R/B)**2/(R/B)).sum()
        if chi>stats.chi2.ppf(0.95,B-1): rej+=1
    return rej/nrep
print("%6s | %10s %10s %10s %10s"%("R","c=1(假阳)","c=0.81","c=0.64","c=1.44"))
for R in [100,200,400,800]:
    print("%6d | %10.3f %10.3f %10.3f %10.3f"%(R,sbc_power(1.0,R),sbc_power(0.81,R),sbc_power(0.64,R),sbc_power(1.44,R)))
print("（c 是后验方差的乘数：c=0.81 即后验标准差被低估 10%，c=0.64 即低估 20%）")
