# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 5 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 case2b.py    依赖：numpy, scipy
"""案例二（续）：中心化基准的真正后果在哪里"""
import numpy as np
from scipy.optimize import minimize_scalar
rng = np.random.default_rng(2025)
m, Ne, t = 3000, 60, 8
p0 = rng.uniform(0.05, 0.95, m)
p = p0.copy()
for g in range(t): p = rng.binomial(2*Ne, p)/(2*Ne)
p = np.clip(p, 1e-6, 1-1e-6)
n = 1000
M = rng.binomial(2, p, size=(n, m)).astype(float)
Fbar_theory = 1-(1-1/(2*Ne))**t
print("理论：t=%d 代、Ne=%d 的累积近交 F̄ = 1−(1−1/(2Ne))^t = %.4f，故 G（以基础群为参照）的非对角均值应≈2F̄ = %.4f"
      % (t, Ne, Fbar_theory, 2*Fbar_theory))
def G_of(M, pc, pd): 
    Z = M-2*pc; return Z@Z.T/(2*np.sum(pd*(1-pd)))
Gb = G_of(M,p0,p0); Gc = G_of(M,p,p)
iu = np.triu_indices(n,1)
print("实测：G(基础群频率) 非对角均值 = %.4f，对角均值 = %.4f（理论 1+F̄ = %.4f）"
      % (Gb[iu].mean(), np.diag(Gb).mean(), 1+Fbar_theory))
print("实测：G(样本频率)   非对角均值 = %.5f，对角均值 = %.4f" % (Gc[iu].mean(), np.diag(Gc).mean()))

# --- 后果 A：h²_SNP 的尺度 ---
h2 = 0.4
alpha = rng.standard_normal(m); gtrue = (M-2*p)@alpha
gtrue = gtrue/gtrue.std()*np.sqrt(h2)
y = gtrue + rng.standard_normal(n)*np.sqrt(1-h2)
X = np.ones((n,1))
def reml_h2(G):
    ev,U = np.linalg.eigh(G); ev=np.maximum(ev,1e-10)
    Uty=U.T@y; UtX=U.T@X; nn=n; pp=1
    def nll(lg):
        gm=np.exp(lg); dv=1+gm*ev
        XtVX=(UtX.T*(1/dv))@UtX; XtVy=(UtX.T*(1/dv))@Uty
        q=(Uty**2/dv).sum()-float(XtVy.T@np.linalg.solve(XtVX,XtVy))
        s2=q/(nn-pp)
        return 0.5*((nn-pp)*np.log(s2)+np.log(dv).sum()+np.log(np.linalg.det(XtVX))+(nn-pp))
    r=minimize_scalar(nll,bounds=(-9,6),method='bounded',options={'xatol':1e-8})
    gm=np.exp(r.x); return gm/(1+gm), gm
hb,_ = reml_h2(Gb); hc,_ = reml_h2(Gc)
print("\nĥ²_SNP：用 G(基础群频率) %.4f ；用 G(样本频率) %.4f ；相对差 %+.1f%%（tr 比 %.4f）"
      % (hb, hc, 100*(hb/hc-1), (np.trace(Gb)/n)/(np.trace(Gc)/n)))

# --- 后果 B：与 A22 的兼容（ssGBLUP 调平系数） ---
mA_off, mA_dia = 2*Fbar_theory, 1+Fbar_theory
def tune(G):
    g_off, g_dia = G[iu].mean(), np.diag(G).mean()
    b = (mA_dia-mA_off)/(g_dia-g_off); a = mA_off-b*g_off
    return a,b
for tag,G in [("G(基础群频率)",Gb), ("G(样本频率)",Gc)]:
    a,b = tune(G); print("%-14s 调平 G* = %+.4f + %.4f·G" % (tag,a,b))

# --- 后果 C：逐折重算频率 ---
idx = rng.permutation(n); folds = np.array_split(idx,5)
trs=[]; 
for k in range(5):
    tr = np.concatenate([folds[j] for j in range(5) if j!=k])
    pk = M[tr].mean(0)/2
    Gk = G_of(M, pk, pk)
    trs.append(np.trace(Gk)/n)
print("\n逐折重算频率：5 折的 tr(G)/n = %s，极差 %.4f（%.2f%%）"
      % (np.round(trs,4), max(trs)-min(trs), 100*(max(trs)-min(trs))/np.mean(trs)))
print("若各折的 σ̂_g² 直接平均，相当于把 %.2f%% 的尺度差当成了折间变异" % (100*(max(trs)-min(trs))/np.mean(trs)))
