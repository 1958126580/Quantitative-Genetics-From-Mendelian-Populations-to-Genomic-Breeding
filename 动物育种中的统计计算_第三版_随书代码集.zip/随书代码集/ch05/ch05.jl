# 本脚本由 tools/nb2jl.py 从同目录的 ch05.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 05

# %% [markdown]
# # 第五章　氛围编程（Vibe Coding）与 AI 辅助的科学计算 —— 配套代码
#
# 本笔记本包含两部分：
#
# 1. **五个反面案例的可复现演示**——每个都"能跑、结果看似合理"，但都是错的。本笔记本给出检测方法。
# 2. **验证工具箱**——参数回收、基于模拟的校准、统计代码的断言模板。
#
# > **阅读方式**：不要只看结论。每个案例都先运行错误版本，观察它"看起来多正常"，再运行检测。这种体验比读十遍警告更有效。

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions
rng = Xoshiro(20260918)

# %% [markdown]
# ## 案例一　$\mathbf A^{-1}$ 遗漏近交修正
#
# 教科书的入门版本给出 $d_i\in\{1,0.75,0.5\}$；完整版本还要减去 $0.25(F_s+F_d)$。
# AI 常常只写前者，因为训练数据中入门版本更多。

# %%
# 通用工具：由系谱构建 A（稠密递推）
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            asj = s > 0 ? A[j, s] : 0.0
            adj = d > 0 ? A[j, d] : 0.0
            A[i, j] = A[j, i] = 0.5*(asj + adj)
        end
        A[i, i] = 1.0 + (s > 0 && d > 0 ? 0.5*A[s, d] : 0.0)
    end
    return A
end

# 通用工具：Henderson/Quaas 规则（use_F 控制是否做近交修正）
function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64}; use_F::Bool=true)
    n = length(sire); I_, J_, V_ = Int[], Int[], Float64[]
    for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        Fs = (use_F && s > 0) ? F[s] : 0.0
        Fd = (use_F && d > 0) ? F[d] : 0.0
        if s > 0 && d > 0;   q = (-0.5,-0.5,1.0); δ = 0.5  - 0.25*(Fs + Fd)
        elseif s > 0;        q = (-0.5, 0.0,1.0); δ = 0.75 - 0.25*Fs
        elseif d > 0;        q = ( 0.0,-0.5,1.0); δ = 0.75 - 0.25*Fd
        else;                q = ( 0.0, 0.0,1.0); δ = 1.0
        end
        b = 1/δ
        for a in 1:3, c in 1:3
            (pos[a] > 0 && pos[c] > 0) || continue
            push!(I_, pos[a]); push!(J_, pos[c]); push!(V_, q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

# 一个含近交的系谱
sire = [0,0,1,1,3,1,5,5,7,7]
dam  = [0,0,0,2,4,4,6,6,8,8]
A = build_A(sire, dam); F = diag(A) .- 1
@printf("近交系数 F = %s\n", string(round.(F, digits=4)))

Ai_wrong = build_Ainv(sire, dam, F; use_F=false)   # ← AI 常给的版本
Ai_right = build_Ainv(sire, dam, F; use_F=true)

println("\n错误版本看起来完全正常：")
@printf("  对称吗?          %s\n", issymmetric(Matrix(Ai_wrong)) ? "是 ✓" : "否")
@printf("  正定吗?          %s\n", isposdef(Matrix(Ai_wrong)) ? "是 ✓" : "否")
@printf("  对角元都为正?    %s\n", all(diag(Ai_wrong) .> 0) ? "是 ✓" : "否")

println("\n但检测立刻暴露它：")
@printf("  ‖A·A⁻¹ − I‖∞ （错误版本）= %.3e   ← 应当 ≈ 1e-16\n", maximum(abs, A*Matrix(Ai_wrong) - I))
@printf("  ‖A·A⁻¹ − I‖∞ （正确版本）= %.3e   ✓\n",            maximum(abs, A*Matrix(Ai_right) - I))

# %%
# 后果：对育种值的影响
λ = 3.0   # h² = 0.25
n = length(sire)
y = 100.0 .+ randn(rng, n) .* 10
X = ones(n, 1); Z = Matrix(1.0I, n, n)

function solve_mme(Ainv, λ)
    C = [X'X  X'Z; Z'X  Z'Z + λ*Matrix(Ainv)]
    r = [X'y; Z'y]
    return (C \ r)[2:end]
end
u_w, u_r = solve_mme(Ai_wrong, λ), solve_mme(Ai_right, λ)
@printf("两组 EBV 的相关系数 = %.4f   ← 看起来“没什么差别”\n", cor(u_w, u_r))
@printf("但近交个体上的相对偏差最大 = %.1f%%\n", 100*maximum(abs.(u_w-u_r)./(abs.(u_r).+1e-9)))
println("\n→ 这正是“似是而非的正确”：相关 0.99+，排序几乎一致，但确实是错的。")

# %% [markdown]
# ## 案例二　$\mathbf G$ 矩阵的中心化基准错误

# %%
nI, mM = 300, 2000
p_true = 0.05 .+ 0.45 .* rand(rng, mM)
Mg = [Float64(rand(rng) < p_true[j]) + Float64(rand(rng) < p_true[j]) for i in 1:nI, j in 1:mM]

train = 1:200; test = 201:nI

# 【错误】用训练群频率中心化，然后把同一 Z 用于全体
p_tr = vec(mean(Mg[train, :], dims=1)) ./ 2
Z_wrong = Mg .- 2 .* p_tr'
G_wrong = Z_wrong*Z_wrong' ./ (2*sum(p_tr .* (1 .- p_tr)))

# 【正确】用全体（或基础群）频率中心化
p_all = vec(mean(Mg, dims=1)) ./ 2
Z_right = Mg .- 2 .* p_all'
G_right = Z_right*Z_right' ./ (2*sum(p_all .* (1 .- p_all)))

println("两个 G 都是对称正定的合法关系矩阵：")
@printf("  错误版本 isposdef = %s ； 正确版本 isposdef = %s\n",
        isposdef(G_wrong + 1e-6I), isposdef(G_right + 1e-6I))
println("\n检测：")
@printf("  tr(G)/n  错误 = %.4f   正确 = %.4f   ← 正确构建时应 ≈ 1\n", tr(G_wrong)/nI, tr(G_right)/nI)
@printf("  Z 的列均值  错误 = %.3e （对全体）  正确 = %.3e\n",
        maximum(abs, mean(Z_wrong, dims=1)), maximum(abs, mean(Z_right, dims=1)))
@printf("  验证群对角元均值  错误 = %.4f   正确 = %.4f\n",
        mean(diag(G_wrong)[test]), mean(diag(G_right)[test]))
println("\n→ 错误版本使验证群的对角元系统性偏移，单步法的调平会失效（第二十三章）。")

# %% [markdown]
# ## 案例三　逆卡方参数化混淆
#
# 三种常见写法：
# - $\chi^{-2}(\nu,S)$：$p(\sigma^2)\propto(\sigma^2)^{-(\nu/2+1)}\exp\!\big(-\tfrac{\nu S}{2\sigma^2}\big)$，均值 $\dfrac{\nu S}{\nu-2}$
# - $\chi^{-2}(\nu, \nu S)$：尺度已乘自由度
# - $\mathrm{InvGamma}(\alpha,\beta)$：$\alpha=\nu/2$，$\beta=\nu S/2$，均值 $\dfrac{\beta}{\alpha-1}$
#
# **检测方法：在无数据条件下从先验抽样，检验样本均值是否等于理论值。**

# %%
ν, S = 4.0, 2.0

# 写法 A（本书约定）：σ² = νS / χ²_ν
draw_A(k) = [ν*S / rand(rng, Chisq(ν)) for _ in 1:k]
# 写法 B（常见错误）：σ² = S / χ²_ν —— 漏掉了 ν
draw_B(k) = [S   / rand(rng, Chisq(ν)) for _ in 1:k]
# 写法 C：InvGamma(ν/2, νS/2) —— 与 A 等价
draw_C(k) = rand(rng, InverseGamma(ν/2, ν*S/2), k)

K = 400_000
theo = ν*S/(ν-2)
@printf("理论先验均值 νS/(ν−2) = %.4f\n\n", theo)
for (nm, f) in (("A: νS/χ²_ν（正确）", draw_A), ("B: S/χ²_ν（漏 ν）", draw_B),
                ("C: InvGamma(ν/2,νS/2)", draw_C))
    s = f(K)
    @printf("%-24s 样本均值 = %8.4f   偏差 %6.1f%%\n", nm, mean(s), 100*(mean(s)-theo)/theo)
end
println()
println("→ 写法 B 的先验均值只有正确值的 1/ν。在 BayesA/B 中每个标记一个方差、")
println("  数据信息极少，先验直接决定结果 —— 这个错误会完全改变分析结论。")

# %% [markdown]
# ## 案例四　Gibbs 抽样的完全条件分布漏项
#
# 在逐标记扫描中，对 $\alpha_j$ 抽样的右手项应为 $\mathbf z_j'\mathbf e+\mathbf z_j'\mathbf z_j\alpha_j^{\text{old}}$，
# 因为残差 $\mathbf e$ 中已经扣掉了 $\mathbf z_j\alpha_j^{\text{old}}$。漏掉第二项，链仍收敛，但收敛到错误的分布。

# %%
"""单性状 SNP-BLUP 的 Gibbs 抽样。`bug` 控制是否引入"漏项"错误。"""
function gibbs_snpblup(y, Z, λ; niter=4000, burn=1000, bug::Bool=false, rng=Random.default_rng())
    n, m = size(Z)
    α  = zeros(m); μ = mean(y)
    e  = y .- μ
    zpz = vec(sum(abs2, Z, dims=1))
    σ²e = var(y)
    acc = zeros(m); nkeep = 0
    for it in 1:niter
        # 截距
        e .+= μ
        μ  = mean(e) + randn(rng)*sqrt(σ²e/n)
        e .-= μ
        # 标记
        @inbounds for j in 1:m
            zj  = @view Z[:, j]
            rhs = dot(zj, e) + (bug ? 0.0 : zpz[j]*α[j])      # ← 漏项在此
            lhs = zpz[j] + λ
            mean_j = rhs / lhs
            old = α[j]
            α[j] = mean_j + randn(rng)*sqrt(σ²e/lhs)
            e .+= zj .* (old - α[j])
        end
        if it > burn; acc .+= α; nkeep += 1; end
    end
    return acc ./ nkeep
end

# 模拟：标记效应真值已知
nI, mM = 250, 120
Zg = randn(rng, nI, mM)
α0 = randn(rng, mM) .* 0.3
y  = 5.0 .+ Zg*α0 .+ randn(rng, nI).*1.0
λg = 1.0 / 0.09

α_ok  = gibbs_snpblup(y, Zg, λg; bug=false, rng=Xoshiro(7))
α_bug = gibbs_snpblup(y, Zg, λg; bug=true,  rng=Xoshiro(7))

@printf("正确实现 : cor(α̂, α₀) = %.4f ， 回归斜率 = %.4f\n",
        cor(α_ok, α0),  (Zg'Zg \ Zg'Zg; cov(α_ok, α0)/var(α0)))
@printf("漏项实现 : cor(α̂, α₀) = %.4f ， 回归斜率 = %.4f\n",
        cor(α_bug, α0), cov(α_bug, α0)/var(α0))
println()
println("→ 两者的相关系数都不低，轨迹图和 R̂ 都正常 —— 常规收敛诊断查不出来。")
println("  暴露它的是【回归斜率】：正确实现应当接近 1（无系统性压缩偏差）。")

# %% [markdown]
# ## 案例五　REML 与 ML 混用
#
# REML 的对数似然比 ML 多一项 $-\tfrac12\log|\mathbf X'\mathbf V^{-1}\mathbf X|$。
# **最灵敏的检测**：在平衡设计的单因子随机模型上，REML 应当与 ANOVA 估计**精确相等**。

# %%
# 平衡设计：a 个水平，每水平 r 次重复
a, r = 20, 5
σ²α, σ²ε = 3.0, 2.0
grp = repeat(1:a, inner=r)
yv  = 10.0 .+ repeat(randn(rng, a).*sqrt(σ²α), inner=r) .+ randn(rng, a*r).*sqrt(σ²ε)

# ANOVA 估计（平衡设计的闭式解）
ȳ  = mean(yv); ȳi = [mean(yv[grp .== i]) for i in 1:a]
MSA = r*sum((ȳi .- ȳ).^2)/(a-1)
MSE = sum((yv .- ȳi[grp]).^2)/(a*(r-1))
σ²α_anova = (MSA - MSE)/r
σ²ε_anova = MSE

# ML / REML（一维 profile，平衡设计下可直接搜索）
function loglik(σ²α, σ²ε; restricted::Bool)
    N = a*r
    V = σ²ε*Matrix(1.0I, N, N) + σ²α*Float64.(grp .== grp')
    X = ones(N, 1)
    Vi = inv(V)
    P  = Vi - Vi*X*inv(X'Vi*X)*X'Vi
    ℓ  = -0.5*(logdet(V) + yv'*P*yv)
    restricted && (ℓ -= 0.5*logdet(X'Vi*X))
    return ℓ
end

using Optim
opt(restricted) = Optim.optimize(θ -> -loglik(exp(θ[1]), exp(θ[2]); restricted=restricted),
                                 [log(1.0), log(1.0)], NelderMead(),
                                 Optim.Options(g_tol=1e-10, iterations=5000))
r_ml   = exp.(Optim.minimizer(opt(false)))
r_reml = exp.(Optim.minimizer(opt(true)))

println(rpad("方法", 14), rpad("σ²α", 12), "σ²ε")
println("-"^40)
@printf("%-14s%-12.6f%.6f\n", "真值",   σ²α, σ²ε)
@printf("%-14s%-12.6f%.6f\n", "ANOVA", σ²α_anova, σ²ε_anova)
@printf("%-14s%-12.6f%.6f\n", "REML",  r_reml[1], r_reml[2])
@printf("%-14s%-12.6f%.6f\n", "ML",    r_ml[1],   r_ml[2])
println()
@printf("REML 与 ANOVA 的相对差 : σ²α %.2e ， σ²ε %.2e   ← 应当 ≈ 0\n",
        abs(r_reml[1]-σ²α_anova)/σ²α_anova, abs(r_reml[2]-σ²ε_anova)/σ²ε_anova)
@printf("ML   与 ANOVA 的相对差 : σ²α %.2e ， σ²ε %.2e   ← ML 有固有的向下偏性\n",
        abs(r_ml[1]-σ²α_anova)/σ²α_anova, abs(r_ml[2]-σ²ε_anova)/σ²ε_anova)
println()
println("→ 若你的“REML”实现在平衡设计上不等于 ANOVA，它多半实际上是 ML。")

# %% [markdown]
# ## 验证工具箱
#
# ### 工具一：参数回收（正文 §5.3.2）

# %%
"""
    parameter_recovery(simulate, estimate, θ₀; R=200)

参数回收：重复 `R` 次"按 θ₀ 模拟 → 估计"，返回 z 统计量 (θ̂−θ₀)/SE。
正确实现应当满足 mean(z) ≈ 0 且 sd(z) ≈ 1。
"""
function parameter_recovery(simulate::Function, estimate::Function, θ₀; R::Int=200, rng=Random.default_rng())
    z = Float64[]
    for r in 1:R
        data = simulate(Xoshiro(hash((20260918, r))))   # 按重复号播种，与线程数无关
        θ̂, se = estimate(data)
        push!(z, (θ̂ - θ₀) / se)
    end
    return z
end

# 示例：检验一个简单均值估计器的标准误是否正确
θ₀, nobs = 5.0, 60
sim(r)   = θ₀ .+ randn(r, nobs).*2.0
est_ok(d)  = (mean(d), std(d)/sqrt(length(d)))          # 正确
est_bad(d) = (mean(d), std(d)/sqrt(length(d))*0.9)      # SE 低估 10%

for (nm, est) in (("正确的 SE", est_ok), ("SE 低估 10%", est_bad))
    z = parameter_recovery(sim, est, θ₀; R=3000)
    @printf("%-14s  mean(z) = %7.4f   sd(z) = %7.4f   95%%覆盖率 = %.3f\n",
            nm, mean(z), std(z), mean(abs.(z) .< 1.96))
end
println()
println("→ sd(z) 显著大于 1 ⇒ 标准误被低估；显著小于 1 ⇒ 被高估。")
println("  这是检验 PEV / 可靠性计算是否正确的标准方法。")

# %% [markdown]
# ### 工具二：基于模拟的校准（SBC）
#
# 对贝叶斯实现，更强的检验：从先验抽 $\theta_0$ → 模拟数据 → 跑 MCMC → 计算 $\theta_0$ 在后验样本中的**秩**。
# 若实现正确，这些秩服从均匀分布。

# %%
"""
    sbc_ranks(prior_draw, simulate, posterior_draws; R=200, L=99)

基于模拟的校准。返回 R 个秩（取值 0..L），正确实现下应服从离散均匀分布。
"""
function sbc_ranks(prior_draw::Function, simulate::Function, posterior_draws::Function;
                   R::Int=200, L::Int=99)
    ranks = Int[]
    for r in 1:R
        rr  = Xoshiro(hash((424242, r)))
        θ₀  = prior_draw(rr)
        y   = simulate(θ₀, rr)
        post = posterior_draws(y, L, rr)
        push!(ranks, count(<(θ₀), post))
    end
    return ranks
end

# 共轭正态模型：先验 θ ~ N(0,1)，似然 y|θ ~ N(θ, 1)，后验解析可得
prior_draw(r) = randn(r)
simulate(θ, r) = θ .+ randn(r, 20)
function posterior_ok(y, L, r)          # 正确的后验
    n = length(y); v = 1/(1 + n); m = v*sum(y)
    return m .+ sqrt(v).*randn(r, L)
end
function posterior_bad(y, L, r)         # 后验方差算错（低估）
    n = length(y); v = 1/(1 + n); m = v*sum(y)
    return m .+ sqrt(v/2).*randn(r, L)  # ← 方差低估一半
end

using Statistics
for (nm, post) in (("正确后验", posterior_ok), ("后验方差低估", posterior_bad))
    rk = sbc_ranks(prior_draw, simulate, post; R=2000, L=99)
    # 卡方拟合优度检验（分 10 箱）
    bins = zeros(Int, 10)
    for x in rk; bins[min(10, x÷10 + 1)] += 1; end
    expct = length(rk)/10
    χ² = sum((bins .- expct).^2 ./ expct)
    @printf("%-14s  χ²(9) = %8.2f   %s\n", nm, χ²,
            χ² < 16.9 ? "✓ 与均匀分布相容" : "✗ 显著偏离均匀 ⇒ 实现有误")
end
println()
println("→ 秩分布呈 ∪ 形 ⇒ 后验过窄；∩ 形 ⇒ 后验过宽；单调倾斜 ⇒ 有偏。")

# %% [markdown]
# ### 工具三：统计代码的断言模板（正文 §5.3.3）

# %%
"""
    check_relationship_matrix(A; name="A")

关系矩阵的标准不变量检查。这类检查应当写进你每一个项目的测试。
"""
function check_relationship_matrix(A::AbstractMatrix; name="A", tol=1e-8)
    n = size(A, 1)
    ok = true
    checks = [
        ("方阵",            size(A,1) == size(A,2)),
        ("对称",            maximum(abs, A - A') < tol),
        ("对角元 ≥ 1",      all(diag(A) .>= 1 - tol)),
        ("对角元 < 2",      all(diag(A) .< 2 + tol)),
        ("正定",            isposdef(Symmetric(Matrix(A)) + tol*I)),
        ("元素在 [-tol, 2]", all(-tol .<= A .<= 2 + tol)),
    ]
    println("检查关系矩阵 $name ($(n)×$(n))：")
    for (nm, pass) in checks
        @printf("  %-18s %s\n", nm, pass ? "✓" : "✗")
        ok &= pass
    end
    return ok
end

check_relationship_matrix(A; name="A（第五章案例一的系谱）")
println()
println("→ 把不变量写成可执行的检查，是把“我以为它对”变成“我验证过它对”的最小代价。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **五个反面案例的共同特征**：代码能跑、结果看似合理、常规诊断查不出来。它们分别被下列检测暴露：
#    - $\mathbf A^{-1}$ 近交修正 → $\mathbf{AA}^{-1}=\mathbf I$
#    - $\mathbf G$ 中心化基准 → $\mathrm{tr}(\mathbf G)/n\approx1$ 与列均值为 0
#    - 逆卡方参数化 → **无数据下的先验抽样均值**
#    - Gibbs 漏项 → **参数回收的回归斜率**
#    - REML/ML 混用 → **平衡设计上 REML = ANOVA**
# 2. **参数回收**检验无偏性与标准误的正确性：$\overline{z}\approx0$、$\mathrm{sd}(z)\approx1$、覆盖率 $\approx95\%$。
# 3. **基于模拟的校准**是贝叶斯实现的最强检验：秩分布应服从均匀分布。
# 4. **把不变量写成可执行的检查**。`check_relationship_matrix` 可以直接复制到你自己的项目中。
# 5. 本笔记本中的每个检测都是**廉价**的——几行代码、几秒运行。相比一篇基于错误代码的论文，这个成本可以忽略不计。
