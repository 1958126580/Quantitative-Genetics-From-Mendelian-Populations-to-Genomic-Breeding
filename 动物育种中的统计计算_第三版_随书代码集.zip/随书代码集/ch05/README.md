# 第五章　氛围编程（Vibe Coding）与 AI 辅助的科学计算 —— 配套代码

**所属**：第一篇　计算基础与 Julia 语言　　**对应正文**：第五章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch05.ipynb` | IJulia 笔记本：10 个代码单元，约 306 行 Julia 代码，穿插与正文对应的说明 |
| `ch05.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 10 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 案例一　$\mathbf A^{-1}$ 遗漏近交修正
- 案例二　$\mathbf G$ 矩阵的中心化基准错误
- 案例三　逆卡方参数化混淆
- 案例四　Gibbs 抽样的完全条件分布漏项
- 案例五　REML 与 ML 混用
- 验证工具箱
  - 工具一：参数回收（正文 §5.3.2）
  - 工具二：基于模拟的校准（SBC）
  - 工具三：统计代码的断言模板（正文 §5.3.3）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 05
```

或在 Jupyter 中打开 `ch05/ch05.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
