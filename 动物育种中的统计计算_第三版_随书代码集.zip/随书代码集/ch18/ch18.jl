# 本脚本由 tools/nb2jl.py 从同目录的 ch18.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 18

# %% [markdown]
# # 第十八章　REML 的数值算法 —— 配套代码
#
# **本笔记本实现四种 REML 算法并对照其收敛行为**：EM、Newton–Raphson、Fisher scoring、平均信息（AI）。
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | 公共构件：MME 求解、$\mathbf P\mathbf v$、似然 | §18.3.5 |
# | 2 | EM‑REML（单调收敛、参数空间保持） | §18.2 |
# | 3 | NR / Fisher scoring / AI 三种二阶方法 | §18.3 |
# | 4 | 四种算法的收敛轨迹对照 | §18.1 |
# | 5 | 迹项：稀疏选择求逆 vs Hutchinson 估计 | §18.4 |
# | 6 | 免费的正确性约束（式 18.17） | §18.4.3 |
# | 7 | 与 JWAS 的交叉验证（可选） | §18.6.4、附录 E |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions
rng = Xoshiro(20260918)

function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        b = inv(delta)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

function random_pedigree(n::Int; nbase::Int=max(10,n÷50), rng=Random.default_rng())
    sire=zeros(Int,n); dam=zeros(Int,n)
    for i in nbase+1:n; sire[i]=rand(rng,1:i-1); dam[i]=rand(rng,1:i-1); end
    return sire, dam
end

"""按给定方差组分，在给定系谱上模拟单性状动物模型数据。"""
function sim_animal_model(sire, dam, s2a, s2e; nherd=10, rng=Random.default_rng())
    n = length(sire)
    A = build_A(sire, dam)
    L = cholesky(Symmetric(A + 1e-10I)).L
    u = L*randn(rng, n).*sqrt(s2a)
    recs = collect((n÷10+1):n)
    nr = length(recs)
    hd = rand(rng, 1:nherd, nr)
    he = randn(rng, nherd).*2.0
    y  = 10.0 .+ he[hd] .+ u[recs] .+ randn(rng, nr).*sqrt(s2e)
    X = zeros(nr, nherd); for k in 1:nr; X[k, hd[k]] = 1.0; end
    Z = zeros(nr, n);     for k in 1:nr; Z[k, recs[k]] = 1.0; end
    return (y=y, X=X, Z=Z, A=A, u=u, recs=recs)
end

# %% [markdown]
# ## 1　公共构件

# %%
"""
    mme_solve(y, X, Z, Ainv, lambda) -> (beta, u, C, rhs)

求解单性状动物模型的 MME（式 12.10），返回解与系数矩阵。
"""
function mme_solve(y, X, Z, Ainv, lambda)
    nf = size(X,2); nu = size(Z,2)
    C = [X'X  X'Z; Z'X  Z'Z + lambda*Matrix(Ainv)]
    r = vcat(X'y, Z'y)
    sol = Symmetric(C) \ r
    return sol[1:nf], sol[nf+1:end], C, r
end

"""
    Pv(v, X, Z, Ainv, lambda, s2e) -> P*v

利用 P 的性质 3（第十七章）：P v = (v - X beta~ - Z u~)/s2e，
其中 (beta~, u~) 是以 v 为「表型」求解 MME 的结果。只需一次 MME 求解。
"""
function Pv(v, X, Z, Ainv, lambda, s2e)
    b, u, _, _ = mme_solve(v, X, Z, Ainv, lambda)
    return (v .- X*b .- Z*u) ./ s2e
end

"""REML 对数似然（式 17.13），直接用 V 计算（小规模）。"""
function reml_ll(s2a, s2e, y, X, Z, A)
    N = length(y)
    V = s2a*(Z*A*Z') + s2e*Matrix(1.0I, N, N)
    Vc = cholesky(Symmetric(V)); Vi = inv(Vc)
    XtVi = X'*Vi; Mx = XtVi*X
    P = Vi - Vi*X*(Mx \ XtVi)
    return -0.5*(logdet(Vc) + logdet(Mx) + y'*P*y)
end

# 测试数据
sire, dam = random_pedigree(400; rng=Xoshiro(7))
F = diag(build_A(sire, dam)) .- 1
Ainv = build_Ainv(sire, dam, F)
D = sim_animal_model(sire, dam, 3.0, 7.0; rng=Xoshiro(8))
y, X, Z, A = D.y, D.X, D.Z, D.A
N = length(y); q = size(Z,2); r = rank(X)
@printf("N = %d 条记录, q = %d 个随机效应, r = rank(X) = %d\n", N, q, r)
@printf("真值: sigma2_a = 3.0, sigma2_e = 7.0  (h2 = %.3f)\n", 3.0/10.0)

# %% [markdown]
# ## 2　EM‑REML（正文式 18.3、18.5）
#
# **两个定理**：似然单调不降；参数空间自动保持。

# %%
"""
    em_reml(y, X, Z, A, Ainv; theta0, maxiter) -> (traj, ll_traj)

EM-REML（式 18.3、18.5）。返回参数轨迹与似然轨迹。
"""
function em_reml(y, X, Z, A, Ainv; theta0=[1.0,1.0], maxiter=200, tol=1e-10)
    s2a, s2e = theta0
    q = size(Z,2); N = length(y); r = rank(X)
    traj = [[s2a, s2e]]; lls = [reml_ll(s2a, s2e, y, X, Z, A)]
    for it in 1:maxiter
        lam = s2e/s2a
        b, u, C, _ = mme_solve(y, X, Z, Ainv, lam)
        Cinv = inv(Symmetric(C))
        nf = size(X,2)
        Cuu = Cinv[nf+1:end, nf+1:end]
        # E 步 + M 步（式 18.3）
        s2a_new = (u'*Matrix(Ainv)*u + tr(Matrix(Ainv)*Cuu)*s2e) / q
        e = y .- X*b .- Z*u
        s2e_new = (y'*e) / (N - r)                      # 式 18.5
        push!(traj, [s2a_new, s2e_new])
        push!(lls, reml_ll(s2a_new, s2e_new, y, X, Z, A))
        conv = norm([s2a_new,s2e_new] .- [s2a,s2e])/norm([s2a,s2e])
        s2a, s2e = s2a_new, s2e_new
        conv < tol && break
    end
    return traj, lls
end

traj_em, ll_em = em_reml(y, X, Z, A, Ainv; theta0=[1.0,1.0], maxiter=300)
@printf("EM 迭代 %d 轮后: sigma2_a = %.6f , sigma2_e = %.6f\n",
        length(traj_em)-1, traj_em[end][1], traj_em[end][2])
# 单调性检验（定理！）
dlls = diff(ll_em)
@printf("似然单调不降？ %s   （最小增量 = %.3e）\n",
        all(dlls .>= -1e-10) ? "是 —— 符合定理" : "否 —— 实现有误！", minimum(dlls))
@printf("参数始终非负？ %s\n", all(all(t .> 0) for t in traj_em) ? "是 —— 符合定理" : "否")
println("\n前 8 轮轨迹：")
for k in 1:min(9, length(traj_em))
    @printf("  %2d: s2a = %.5f , s2e = %.5f , logL = %.5f\n",
            k-1, traj_em[k][1], traj_em[k][2], ll_em[k])
end

# %% [markdown]
# ## 3　二阶方法：得分、三种信息矩阵（正文 §18.3）

# %%
"""
    score_and_info(s2a, s2e, y, X, Z, A) -> (s, I_O, I_E, I_A)

计算得分向量（式 18.9）与三种信息矩阵（式 17.20–17.22）。
小规模下直接用 P 矩阵；大规模实现见正文 §18.3.5 的工作变量法。
"""
function score_and_info(s2a, s2e, y, X, Z, A)
    N = length(y)
    V1 = Z*A*Z'; V2 = Matrix(1.0I, N, N)
    V  = s2a*V1 + s2e*V2
    Vi = inv(Symmetric(V)); XtVi = X'*Vi
    P  = Vi - Vi*X*((XtVi*X) \ XtVi)
    Py = P*y
    Vl = [V1, V2]
    s  = [-0.5*(tr(P*Vl[i]) - y'*P*Vl[i]*Py) for i in 1:2]
    I_O = [ (y'*P*Vl[i]*P*Vl[j]*Py) - 0.5*tr(P*Vl[i]*P*Vl[j]) for i in 1:2, j in 1:2]
    I_E = [ 0.5*tr(P*Vl[i]*P*Vl[j]) for i in 1:2, j in 1:2]
    I_A = [ 0.5*(y'*P*Vl[i]*P*Vl[j]*Py) for i in 1:2, j in 1:2]
    return s, I_O, I_E, I_A
end

# 验证式 (18.10)：AI = (I_O + I_E)/2，迹项抵消
sv, IO, IE, IA = score_and_info(3.0, 7.0, y, X, Z, A)
@printf("norm( (I_O + I_E)/2 - I_A ) = %.3e   <- 应当 ~ 0（式 18.10）\n", norm((IO+IE)/2 - IA))
println("\n得分向量 s = ", round.(sv, digits=6))
println("I_O = "); display(round.(IO, digits=4))
println("I_E = "); display(round.(IE, digits=4))
println("I_A = "); display(round.(IA, digits=4))
@printf("\nI_E 正定？%s  （Fisher scoring 恒正定，故稳健）\n", isposdef(Symmetric(IE)))
@printf("I_O 正定？%s\n", isposdef(Symmetric(IO)))

# %% [markdown]
# ### 3.1 三种二阶算法的统一实现

# %%
"""
    second_order_reml(y, X, Z, A; kind, theta0) -> (traj, ll_traj)

二阶 REML。kind = :NR / :FS / :AI 分别用观测信息、期望信息、平均信息。
含步长减半（正文 §18.3.6）。
"""
function second_order_reml(y, X, Z, A; kind::Symbol=:AI, theta0=[1.0,1.0],
                           maxiter=60, tol=1e-10)
    th = copy(theta0)
    traj = [copy(th)]; lls = [reml_ll(th[1], th[2], y, X, Z, A)]
    for it in 1:maxiter
        s, IO, IE, IA = score_and_info(th[1], th[2], y, X, Z, A)
        Inf_ = kind === :NR ? IO : (kind === :FS ? IE : IA)
        step = try
            Symmetric(Inf_) \ s
        catch
            pinv(Inf_)*s
        end
        alpha = 1.0; ok = false; th_new = th
        for _ in 1:20                                  # 步长减半
            cand = th .+ alpha .* step
            if all(cand .> 1e-10)
                llc = reml_ll(cand[1], cand[2], y, X, Z, A)
                if llc >= lls[end] - 1e-8
                    th_new = cand; ok = true; break
                end
            end
            alpha /= 2
        end
        ok || break
        push!(traj, copy(th_new)); push!(lls, reml_ll(th_new[1], th_new[2], y, X, Z, A))
        conv = norm(th_new .- th)/norm(th); th = th_new
        conv < tol && break
    end
    return traj, lls
end

for kind in (:NR, :FS, :AI)
    tr_, ll_ = second_order_reml(y, X, Z, A; kind=kind, theta0=[1.0,1.0])
    @printf("%-4s: %3d 轮 -> sigma2_a = %.6f , sigma2_e = %.6f , logL = %.6f\n",
            string(kind), length(tr_)-1, tr_[end][1], tr_[end][2], ll_[end])
end

# %% [markdown]
# ## 4　四种算法的收敛对照（正文 §18.1）

# %%
results = Dict{String,Any}()
tr_em, ll_em2 = em_reml(y, X, Z, A, Ainv; theta0=[1.0,1.0], maxiter=400)
results["EM"] = (tr_em, ll_em2)
for kind in (:NR, :FS, :AI)
    results[string(kind)] = second_order_reml(y, X, Z, A; kind=kind, theta0=[1.0,1.0])
end
# 标准配方：EM 3 轮 + AI
tr_mix, ll_mix = em_reml(y, X, Z, A, Ainv; theta0=[1.0,1.0], maxiter=3)
tr_ai2, ll_ai2 = second_order_reml(y, X, Z, A; kind=:AI, theta0=tr_mix[end])
results["EM(3)+AI"] = (vcat(tr_mix, tr_ai2[2:end]), vcat(ll_mix, ll_ai2[2:end]))

println(rpad("算法", 14), rpad("迭代次数", 12), rpad("sigma2_a", 14), rpad("sigma2_e", 14), "logL")
println("-"^66)
for k in ("EM", "NR", "FS", "AI", "EM(3)+AI")
    tr_, ll_ = results[k]
    @printf("%-14s%-12d%-14.6f%-14.6f%.6f\n", k, length(tr_)-1,
            tr_[end][1], tr_[end][2], ll_[end])
end
println("\n收敛轨迹（sigma2_a）：")
println(rpad("轮次", 8), join([rpad(k, 12) for k in ("EM","NR","FS","AI")]))
println("-"^56)
for it in 0:min(10, maximum(length(results[k][1])-1 for k in ("EM","NR","FS","AI")))
    row = [it < length(results[k][1]) ? @sprintf("%-12.5f", results[k][1][it+1][1]) : rpad("—",12)
           for k in ("EM","NR","FS","AI")]
    @printf("%-8d%s\n", it, join(row))
end
println("\n=> 二阶方法数轮收敛，EM 需要数十至数百轮；")
println("   「EM 几轮 + AI」是主流软件的标准配方（正文 §18.1）。")

# %% [markdown]
# ### 4.1 遗传力对 EM 收敛速度的影响（正文式 18.6，思考题 8）

# %%
println(rpad("真实 h2", 12), rpad("EM 迭代数", 14), rpad("AI 迭代数", 14), "比值")
println("-"^54)
for h2 in (0.05, 0.15, 0.30, 0.50)
    s2a_t = 10*h2; s2e_t = 10*(1-h2)
    Dh = sim_animal_model(sire, dam, s2a_t, s2e_t; rng=Xoshiro(hash((55, h2))))
    te, _ = em_reml(Dh.y, Dh.X, Dh.Z, Dh.A, Ainv; theta0=[1.0,1.0], maxiter=800, tol=1e-8)
    ta, _ = second_order_reml(Dh.y, Dh.X, Dh.Z, Dh.A; kind=:AI, theta0=[1.0,1.0], tol=1e-8)
    @printf("%-12.2f%-14d%-14d%.0f x\n", h2, length(te)-1, length(ta)-1,
            (length(te)-1)/max(length(ta)-1,1))
end
println("\n=> 遗传力越低，「缺失信息」比例越高，EM 越慢（式 18.6）。")

# %% [markdown]
# ## 5　迹项：精确 vs Hutchinson 估计（正文 §18.4）

# %%
"""
    hutchinson_trace(Mv, n; S, rng) -> 迹的 Monte Carlo 估计

Hutchinson 估计量（式 18.14、18.15）：tr(M) ~ (1/S) sum z' M z，
z 为 Rademacher 向量（+-1 等概率，方差最小）。
`Mv` 是计算 M*v 的函数。
"""
function hutchinson_trace(Mv::Function, n::Int; S::Int=50, rng=Random.default_rng())
    acc = 0.0
    for s in 1:S
        z = rand(rng, (-1.0, 1.0), n)
        acc += dot(z, Mv(z))
    end
    return acc/S
end

# 目标：tr(A^-1 * C^uu)，它出现在 EM 更新式 (18.3) 与得分中
lam = 7.0/3.0
_, _, C, _ = mme_solve(y, X, Z, Ainv, lam)
nf = size(X,2)
Cinv = inv(Symmetric(C))
Cuu = Cinv[nf+1:end, nf+1:end]
Ai_m = Matrix(Ainv)
tr_exact = tr(Ai_m*Cuu)

Mv(v) = Ai_m*(Cuu*v)
println(rpad("S（样本数）", 14), rpad("Hutchinson 估计", 20), rpad("相对误差", 14), "理论 SE")
println("-"^62)
for S in (10, 30, 100, 300, 1000)
    ests = [hutchinson_trace(Mv, size(Cuu,1); S=S, rng=Xoshiro(hash((66,S,k)))) for k in 1:20]
    @printf("%-14d%-20.4f%-14.2f%%%.2f%%\n", S, mean(ests),
            100*abs(mean(ests)-tr_exact)/tr_exact, 100*std(ests)/tr_exact)
end
@printf("\n精确值 tr(A^-1 C^uu) = %.4f\n", tr_exact)
println("=> S = 30~50 通常足够，因为迹项只影响得分，而得分在收敛附近趋于零。")

# %% [markdown]
# ## 6　免费的正确性约束（正文式 18.17）
#
# $\sum_i\theta_i\,\mathrm{tr}(\mathbf{PV}_i)=\mathrm{tr}(\mathbf{PV})=N-r$ —— 这是一个恒等式，
# 可用作迹计算正确性的检验（第五章的"不变量断言"）。

# %%
function trace_constraint_check(s2a, s2e, y, X, Z, A)
    N = length(y)
    V1 = Z*A*Z'; V2 = Matrix(1.0I, N, N)
    V  = s2a*V1 + s2e*V2
    Vi = inv(Symmetric(V)); XtVi = X'*Vi
    P  = Vi - Vi*X*((XtVi*X) \ XtVi)
    lhs = s2a*tr(P*V1) + s2e*tr(P*V2)
    rhs = N - rank(X)
    return lhs, rhs
end

for (sa, se) in ((3.0,7.0), (1.0,1.0), (0.5,12.0), (8.0,2.0))
    l, r_ = trace_constraint_check(sa, se, y, X, Z, A)
    @printf("s2a=%5.1f, s2e=%5.1f : sum theta_i tr(P V_i) = %.6f , N - r = %d , 差 = %.3e\n",
            sa, se, l, r_, abs(l-r_))
end
println("\n=> 该恒等式对任意 theta 成立，是检验 P 矩阵与迹计算的免费断言。")

# %% [markdown]
# ## 7　与 JWAS 的交叉验证（可选，需安装 JWAS）
#
# REML 给出的是**限制似然的众数**，JWAS 给出的是**后验均值**（方差组分取刻度逆卡方先验，$\nu=4$）。二者不必逐位相等，但在记录数适中时应落在**一到两个后验标准差**以内；差距远超于此，几乎总是**模型设定不一致**（固定效应、系谱编码、先验均值），而不是算法问题（正文 §18.6.4）。
#
# **JWAS 2.4 的三个接口要点（已对照源码核实）：**
#
# 1. `get_pedigree(df)` 可直接接受 DataFrame，但**未知亲本必须是 `missing`，不能是 `"0"`**——`missingstring = ["0"]` 只在读文件时生效；若写成 `"0"`，JWAS 会把 `"0"` 当成一个真实的祖先，所有基础个体都变成它的后代！
# 2. 模型式中的随机效应名（这里是 `ID`）必须同时是表型数据框的列名和 `set_random` 的第二个参数。
# 3. `out["polygenic effects covariance matrix"]`、`out["residual variance"]` 是含 `Estimate`、`SD` 两列的数据框。

# %%
RUN_JWAS = false            # 先实例化可选环境 envs/jwas（附录 E），再改为 true
if RUN_JWAS
    let env = joinpath(dirname(Base.active_project()), "envs", "jwas")
        isdir(env) || (env = normpath(joinpath(pwd(), "..", "envs", "jwas")))
        env in LOAD_PATH || push!(LOAD_PATH, env)   # 叠加可选环境（附录 E）
    end
    using JWAS, DataFrames
end

# %%
if RUN_JWAS
    ids    = string.(1:length(sire))
    ped_df = DataFrame(ID   = ids,
                       Sire = [s > 0 ? string(s) : missing for s in sire],
                       Dam  = [d > 0 ? string(d) : missing for d in dam])
    pedigree = get_pedigree(ped_df)

    herd = [findfirst(>(0.5), view(X, k, :)) for k in 1:N]    # 由设计矩阵还原牛群编号
    rec  = [findfirst(>(0.5), view(Z, k, :)) for k in 1:N]    # 由设计矩阵还原个体编号
    phen = DataFrame(ID = string.(rec), herd = string.(herd), y = y)

    model = build_model("y = intercept + herd + ID", 7.0)      # 7.0：残差方差的先验均值
    set_random(model, "ID", pedigree, 3.0)                     # 3.0：加性方差的先验均值
    out = runMCMC(model, phen; chain_length = 60_000, burnin = 10_000,
                  output_samples_frequency = 10, seed = 20260918,
                  printout_model_info = false, output_folder = "jwas_ch18")

    va = out["polygenic effects covariance matrix"]
    ve = out["residual variance"]
    s2a_mc, sd_a = Float64(va[1, :Estimate]), Float64(va[1, :SD])
    s2e_mc, sd_e = Float64(ve[1, :Estimate]), Float64(ve[1, :SD])
    s2a_reml, s2e_reml = results["AI"][1][end]

    @printf("%-8s%-12s%-26s%-10s\n", "参数", "AI-REML", "JWAS 后验均值 ± SD", "|差|/SD")
    @printf("%-8s%-12.4f%8.4f ± %-15.4f%-10.2f\n", "σ²_a", s2a_reml, s2a_mc, sd_a, abs(s2a_reml - s2a_mc)/sd_a)
    @printf("%-8s%-12.4f%8.4f ± %-15.4f%-10.2f\n", "σ²_e", s2e_reml, s2e_mc, sd_e, abs(s2e_reml - s2e_mc)/sd_e)
    agree = abs(s2a_reml - s2a_mc) < 2sd_a && abs(s2e_reml - s2e_mc) < 2sd_e
    println(agree ? "✔ 两者在两个后验标准差以内一致" :
                    "✘ 差距过大：检查固定效应、系谱编码与先验设定")
    rm("jwas_ch18"; recursive = true, force = true)
    rm("IDs_for_individuals_with_pedigree.txt"; force = true)
else
    println("RUN_JWAS = false：跳过 JWAS 交叉验证。")
end

# %% [markdown]
# ## 本章代码小结
#
# 1. **EM 的两个定理已数值验证**：似然单调不降、参数始终非负。**似然下降必定是实现错误** —— 这是最灵敏的免费检验。
# 2. **式 (18.10) 已验证**：$(\mathcal I^O+\mathcal I^E)/2=\mathcal I^A$，迹项完全抵消。
# 3. **$\mathcal I^E$ 恒正定**而 $\mathcal I^O$ 不一定 —— 这解释了 NR 的不稳健。
# 4. **四种算法的对照**：二阶方法数轮收敛，EM 需数十至数百轮；**「EM 几轮 + AI」是标准配方**。
# 5. **遗传力越低 EM 越慢**（式 18.6），$h^2=0.05$ 时差距可达两个数量级。
# 6. **Hutchinson 迹估计**的相对标准误按 $1/\sqrt S$ 下降，$S=30$–$50$ 通常足够。
# 7. **式 (18.17) 是免费的正确性约束**，对任意参数值成立。
