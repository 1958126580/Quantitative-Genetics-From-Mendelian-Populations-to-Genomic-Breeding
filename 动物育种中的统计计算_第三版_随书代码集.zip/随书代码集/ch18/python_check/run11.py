# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 run11.py    依赖：numpy
import os; HERE = os.path.dirname(os.path.abspath(__file__))
# -*- coding: utf-8 -*-
import sys, numpy as np
sys.path.insert(0, os.path.join(HERE, 'ch18b'))
import core
np.set_printoptions(precision=6, suppress=True)
D = core.prep(core.simulate(seed=20260418, n_base=120, n_gen=3, per_gen=200, n_herd=3,
                            sa2=25.0, se2=75.0, frac_rec=0.60)); core.prep_eig(D)
SOL = np.array([24.00991961, 71.04510776]); sa2, se2 = SOL
q, N, r, p = D['q'], D['N'], D['r'], D['p']
M = core.mme_fast(D, sa2, se2)
uAu, trACuu, ehe, yeh = M['uAu'], M['trACuu'], M['ehe'], M['yeh']
al = se2/sa2
print('=== 解处的 EM 分子拆解 ===')
print("û'A⁻¹û      = %.6f" % uAu)
print('tr(A⁻¹C^uu) = %.6f' % trACuu)
print('tr(A⁻¹C^uu)·σe² = %.6f' % (trACuu*se2))
print('分子合计 = %.6f ,  /q = %.6f （应等于 σ̂a² = %.6f）'
      % (uAu+trACuu*se2, (uAu+trACuu*se2)/q, sa2))
print('若漏掉迹项： σa² = %.6f/%d = %.6f （低估 %.1f%%）'
      % (uAu, q, uAu/q, 100*(1-uAu/q/sa2)))
print('迹项在分子中占比 = %.2f%%' % (100*trACuu*se2/(uAu+trACuu*se2)))
print('\n=== 两种 σe² 更新式在解处 ===')
trCWW = (p+q) - al*trACuu
Eee = ehe + se2*trCWW
print("ê'ê = %.6f ,  tr(C⁻¹W'W) = %.6f ,  E[e'e|y] = %.6f" % (ehe, trCWW, Eee))
print("严格 EM： E[e'e|y]/N = %.6f / %d = %.6f" % (Eee, N, Eee/N))
print("Henderson： y'ê/(N-r) = %.6f / %d = %.6f" % (yeh, N-r, yeh/(N-r)))
print("代数关系核对： y'ê + σe²(p+q) - α·q·σa²  = %.6f  (= E[e'e|y] %.6f, 差 %.2e)"
      % (yeh + se2*(p+q) - al*q*sa2, Eee, yeh + se2*(p+q) - al*q*sa2 - Eee))
print("ê'ê = y'ê - α û'A⁻¹û 核对： %.6f vs %.6f （差 %.2e）" % (yeh-al*uAu, ehe, yeh-al*uAu-ehe))
print('α = σe²/σa² = %.6f' % al)

print('\n=== MC 迹误差的放大倍数（解析预测 vs 实测） ===')
si = core.score_info(D, sa2, se2); IA = si['IA']; IAi = np.linalg.inv(IA)
# 迹误差 δ -> Δs = (δ/(2σa²))·(α, -1)   （用恒等式 18.17 定 tr(PVe)）
v = np.array([al, -1.0])/(2*sa2)
dth = IAi @ v            # 每单位 δ 引起的 Δθ
print('每单位迹误差 δ 引起：Δσa² = %.6f ,  Δσe² = %.6f' % (dth[0], dth[1]))
g = np.array([SOL[1], -SOL[0]])/SOL.sum()**2
print('每单位 δ 引起 Δh² = %.8f' % (g @ dth))
tr_ex = trACuu
print('相对放大倍数（σa²）= |Δσa²/σa²| / |δ/tr| = %.3f' % (abs(dth[0])/sa2*tr_ex))
print('相对放大倍数（h²） = |Δh²/h²| / |δ/tr| = %.3f' % (abs(g@dth)/(sa2/(sa2+se2))*tr_ex))
v2 = 1.9734  # Var_Rade(M2) per probe（run6）
for S, sd_obs_a, sd_obs_h in [(5,6.9292,0.06857),(10,4.4114,0.04393),(20,3.1328,0.03142),
                              (50,1.9834,0.01994),(100,1.5070,0.01516)]:
    sd_tr = np.sqrt(v2/S)
    print('S=%3d: 迹 SD=%.4f (相对 %.5f) -> 预测 SD(σ̂a²)=%.4f 实测 %.4f ; 预测 SD(ĥ²)=%.5f 实测 %.5f'
          % (S, sd_tr, sd_tr/tr_ex, abs(dth[0])*sd_tr, sd_obs_a, abs(g@dth)*sd_tr, sd_obs_h))
print('\n=== 总迭代耗时对照（例 18.1，稠密参考实现） ===')
print('EM  ：1244 轮 × 69.0 ms = %.1f s' % (1244*0.069))
print('AI  ：   9 轮 × 34.4 ms = %.2f s' % (9*0.0344))
print('FS  ：  12 轮 × 48.9 ms = %.2f s' % (12*0.0489))
print('NR  ：   5 轮 × 48.9 ms = %.2f s' % (5*0.0489))
print('EM/AI = %.0f 倍' % (1244*0.069/(9*0.0344)))
print('\n常数项 -(N-r)/2 ln(2π) = %.6f' % (-(N-r)/2*np.log(2*np.pi)))
print('EM 预测迭代数 ln(1e-8)/ln(0.988022) = %.0f' % (np.log(1e-8)/np.log(0.988022)))
print('缺失信息比例（σa² 分量）= 0.604773/0.624484 = %.5f' % (0.604773/0.624484))
