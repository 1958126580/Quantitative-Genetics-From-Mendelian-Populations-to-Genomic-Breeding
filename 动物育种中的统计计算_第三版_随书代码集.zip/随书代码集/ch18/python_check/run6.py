# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 run6.py    依赖：numpy
"""例 18.5：Hutchinson 迹估计的方差、探针数与对 θ̂ 的传播。"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import sys, numpy as np
sys.path.insert(0, os.path.join(HERE, 'ch18b'))
import core
np.set_printoptions(precision=6, suppress=True)
D = core.prep(core.simulate(seed=20260418, n_base=120, n_gen=3, per_gen=200, n_herd=3,
                            sa2=25.0, se2=75.0, frac_rec=0.60)); core.prep_eig(D)
SOL = np.array([24.0099196, 71.0451078])
q = D['q']
Mg = core.mme_fast(D, SOL[0], SOL[1]); Cuu = Mg['Cuu']; Ainv = D['Ainv']
M1 = Ainv @ Cuu                       # 非对称
L = np.linalg.cholesky(Ainv)
M2 = L.T @ Cuu @ L                    # 对称，与 M1 相似
tr1, tr2 = np.trace(M1), np.trace(M2)
print('=== 被估的迹 ===')
print('tr(A⁻¹C^uu) = %.6f （非对称形式 M₁）' % tr1)
print('tr(L\'C^uu L) = %.6f （对称形式 M₂ = L\'C^uu L, A⁻¹=LL\'）  差 = %.2e' % (tr2, tr1-tr2))
print('q = %d ,  迹/q = %.6f' % (q, tr1/q))

def varfac(M):
    fro = float(np.sum(M*M)); tr2_ = float(np.sum(M*M.T)); dg = float(np.sum(np.diag(M)**2))
    return dict(fro=fro, trM2=tr2_, dg=dg,
                rade=fro+tr2_-2*dg, gauss=fro+tr2_)
v1, v2 = varfac(M1), varfac(M2)
print('\n=== 单探针方差 Var(z\'Mz) ===')
print('形式 | ‖M‖_F²      | tr(M²)      | Σm_ii²     | Rademacher | Gauss   | Gauss/Rade')
for nm, v in [('M₁(非对称)', v1), ('M₂(对称)  ', v2)]:
    print('%s | %11.4f | %11.4f | %10.4f | %10.4f | %7.4f | %.3f'
          % (nm, v['fro'], v['trM2'], v['dg'], v['rade'], v['gauss'], v['gauss']/v['rade']))

print('\n=== 达到给定相对精度所需探针数 S（对称形式 M₂、Rademacher）===')
print('相对标准误 SD/tr | 所需 S（Rademacher） | 所需 S（Gauss）')
for rel in [0.10, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001]:
    tgt = (rel*tr2)**2
    print('%16.3f | %20.0f | %14.0f' % (rel, np.ceil(v2['rade']/tgt), np.ceil(v2['gauss']/tgt)))

print('\n=== 给定 S 时的相对标准误 ===')
print('   S | SD(Rade) | SD/tr(Rade) | SD(Gauss) | SD/tr(Gauss) | 实测 SD(Rade, 2000 次重复)')
rng = np.random.default_rng(20260419)
for S in [5,10,20,30,50,100,200,500]:
    sdR = np.sqrt(v2['rade']/S); sdG = np.sqrt(v2['gauss']/S)
    reps = 2000
    Zs = rng.integers(0,2,size=(q,S*0+q*0+1))  # placeholder
    est = np.empty(reps)
    for b in range(reps):
        Z = rng.integers(0,2,size=(q,S))*2.0-1.0
        est[b] = np.mean(np.sum(Z*(M2@Z), axis=0))
    print('%4d | %8.4f | %11.5f | %9.4f | %12.5f | %10.4f  (均值 %.4f)'
          % (S, sdR, sdR/tr2, sdG, sdG/tr2, est.std(ddof=1), est.mean()))
