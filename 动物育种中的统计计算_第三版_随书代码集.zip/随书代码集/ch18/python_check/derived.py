# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 derived.py    依赖：numpy
"""正文中由其他脚本结果二次推出的几个数字。"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import sys, numpy as np
sys.path.insert(0, os.path.join(HERE, 'ch18b'))
sa2, se2, tr, q = 24.00991980, 71.04510760, 216.872056, 720
al = se2/sa2
print('α·tr(A⁻¹C^uu) = %.4f' % (al*tr))
print('q - α·tr       = %.4f' % (q - al*tr))
print('(q-α·tr)/σa²   = %.8f  （= tr(PVa)）' % ((q-al*tr)/sa2))
print('相消放大 q/(q-α·tr) = %.3f' % (q/(q-al*tr)))
print('总放大 81.07 -> 余下 (I^A)⁻¹ 部分 = %.3f' % (81.07/(q/(q-al*tr))))
sds = [(10,0.04393),(20,0.03142),(50,0.01994)]
c = np.mean([sd*np.sqrt(S) for S,sd in sds])
print('SD(ĥ²)·√S（S=10,20,50 三点均值） = %.4f' % c)
print('压到 SE 的 10%% 需要 S = %.0f ；此时膨胀 = %.3f%%'
      % ((c/(0.107398*0.10))**2, (np.sqrt(1+0.01)-1)*100))
print('第十八章第四节第六小节：n=21500 每轮总代价')
tf, ts = 9.2044, 0.025489
print('  分解 %.2f s ；精确(c=2) 总 %.2f s (+%.0f%%) ；MC(S=30) 总 %.2f s (+%.1f%%) ；MC 便宜 %.1f 倍'
      % (tf, tf+2*tf, 200, tf+30*ts, 100*30*ts/tf, 2*tf/(30*ts)))
