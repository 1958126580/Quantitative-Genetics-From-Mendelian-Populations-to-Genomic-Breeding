# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 run9.py    依赖：numpy
"""例 18.8：对数-Cholesky 参数化的 Jacobian、标准误变换、正定性保持；典型变换的失效。"""
import numpy as np
np.set_printoptions(precision=6, suppress=True)

# ---------- 三性状 G0 ----------
sd = np.array([5.0, 6.324555320336759, 3.1622776601683795])   # 方差 25, 40, 10
Rc = np.array([[1.0, 0.6, -0.3],[0.6, 1.0, 0.5],[-0.3, 0.5, 1.0]])
G0 = np.outer(sd, sd) * Rc
print('=== G0 ===\n', G0)
print('特征值', np.linalg.eigvalsh(G0))
L = np.linalg.cholesky(G0)
print('Cholesky 因子 L =\n', L)
t = 3
def pack(L):
    g = []
    for j in range(t):
        for i in range(j, t):
            g.append(np.log(L[i,j]) if i == j else L[i,j])
    return np.array(g)
def unpack(g):
    L = np.zeros((t,t)); k = 0
    for j in range(t):
        for i in range(j, t):
            L[i,j] = np.exp(g[k]) if i == j else g[k]; k += 1
    return L
gam = pack(L)
names = ['γ1=log l11','γ2=l21','γ3=l31','γ4=log l22','γ5=l32','γ6=log l33']
print('γ =', gam)
print('还原 L 最大差 %.2e' % np.abs(unpack(gam)-L).max())

def vech(M):
    return np.array([M[i,j] for j in range(t) for i in range(j,t)])
def f(g):
    Lg = unpack(g); return vech(Lg @ Lg.T)
# 解析 Jacobian：dG/dgamma_k = dL/dgamma_k L' + L dL/dgamma_k'
J = np.zeros((6,6))
k = 0
for j in range(t):
    for i in range(j, t):
        dL = np.zeros((t,t)); dL[i,j] = L[i,j] if i == j else 1.0   # 对角元用 exp 参数化
        dG = dL @ L.T + L @ dL.T
        J[:, k] = vech(dG); k += 1
# 数值 Jacobian
Jn = np.zeros((6,6)); h = 1e-6
for k in range(6):
    gp = gam.copy(); gp[k] += h; gm = gam.copy(); gm[k] -= h
    Jn[:, k] = (f(gp)-f(gm))/(2*h)
print('\n=== Jacobian J = ∂vech(G0)/∂γ\' ===\n', J)
print('与数值微分的最大绝对差 = %.3e' % np.abs(J-Jn).max())
print('det(J) = %.6f ,  条件数 = %.4f' % (np.linalg.det(J), np.linalg.cond(J)))

# ---------- 标准误变换 ----------
rng = np.random.default_rng(20260421)
B = rng.standard_normal((6,6)); Ig = B @ B.T + 6*np.eye(6)      # 假想的 γ 尺度信息矩阵
Vg = np.linalg.inv(Ig)
Vv = J @ Vg @ J.T                                               # vech(G0) 尺度
print('\n=== 标准误变换 ===')
print('SE(γ) =', np.sqrt(np.diag(Vg)))
lbl = ['g11','g21','g31','g22','g32','g33']
print('SE(vech G0) =', dict(zip(lbl, np.round(np.sqrt(np.diag(Vv)),6))))
# 遗传相关 r12 的标准误：两条路径
def r12_of_vech(v):
    G = np.zeros((t,t)); k=0
    for j in range(t):
        for i in range(j,t):
            G[i,j]=G[j,i]=v[k]; k+=1
    return G[0,1]/np.sqrt(G[0,0]*G[1,1])
v0 = vech(G0); h=1e-6
d_v = np.array([(r12_of_vech(v0+h*np.eye(6)[k])-r12_of_vech(v0-h*np.eye(6)[k]))/(2*h) for k in range(6)])
se_a = np.sqrt(d_v @ Vv @ d_v)
d_g = J.T @ d_v
se_b = np.sqrt(d_g @ Vg @ d_g)
print('SE(r12)：经 vech 尺度 = %.8f ；经 γ 尺度 = %.8f ；差 = %.2e' % (se_a, se_b, se_a-se_b))

# ---------- 正定性保持 ----------
print('\n=== 一步更新是否跳出正定锥 ===')
step = np.array([-6.0, 9.0, -6.0, -12.0, 7.0, -4.0])   # vech 尺度上的一步
G1 = np.zeros((t,t)); k=0
for j in range(t):
    for i in range(j,t):
        G1[i,j]=G1[j,i]=v0[k]+step[k]; k+=1
print('原尺度更新后的 G0 =\n', G1)
ev = np.linalg.eigvalsh(G1)
print('特征值 =', ev, ' -> %s' % ('正定' if ev.min()>0 else '**非正定**'))
print('对应的遗传相关 r12 = %.6f  r13 = %.6f  r23 = %.6f'
      % (G1[0,1]/np.sqrt(G1[0,0]*G1[1,1]), G1[0,2]/np.sqrt(G1[0,0]*G1[2,2]), G1[1,2]/np.sqrt(G1[1,1]*G1[2,2])))
dg = np.linalg.solve(J, step)     # 同样的一阶位移，折算到 γ 尺度
G2 = unpack(gam+dg) @ unpack(gam+dg).T
print('\n同一位移在 γ 尺度上走完后的 G0 =\n', G2)
ev2 = np.linalg.eigvalsh(G2)
print('特征值 =', ev2, ' -> %s' % ('正定' if ev2.min()>0 else '非正定'))
print('相关 r12 = %.6f  r13 = %.6f  r23 = %.6f'
      % (G2[0,1]/np.sqrt(G2[0,0]*G2[1,1]), G2[0,2]/np.sqrt(G2[0,0]*G2[2,2]), G2[1,2]/np.sqrt(G2[1,1]*G2[2,2])))
print('γ 尺度上的位移 dg = J⁻¹ step =', dg)
for mult in [0.5, 1.0, 2.0, 5.0, 20.0, 100.0]:
    Lm = unpack(gam+mult*dg); Gm = Lm @ Lm.T
    ev = np.linalg.eigvalsh(Gm)
    print('  步长 ×%6.1f：L 对角 = %s ；G0 最小特征值 = %.4e （恒 > 0）'
          % (mult, np.round(np.diag(Lm),6), ev.min()))
print('注：最小特征值可以任意接近 0（边界解），但永不为负。')
Lm = unpack(gam+dg)
print('走完一步后 γ = %s' % np.round(gam+dg,4))
print('其中 γ6 = log l33 = %.4f（原为 %.4f），l33 = %.3e —— "跳出锥外"被翻译成"贴到锥的边界上"'
      % ((gam+dg)[5], gam[5], Lm[2,2]))

# ---------- 典型变换的适用与失效 ----------
print('\n\n=== 典型变换：同时对角化的条件 ===')
R0 = np.array([[60.0, 12.0, 5.0],[12.0, 55.0, -8.0],[5.0, -8.0, 30.0]])
print('R0 =\n', R0); print('R0 特征值', np.linalg.eigvalsh(R0))
Lr = np.linalg.cholesky(R0)
S = np.linalg.solve(Lr, np.linalg.solve(Lr, G0).T).T
S = 0.5*(S+S.T)
w, U = np.linalg.eigh(S)
T = (U.T @ np.linalg.inv(Lr))          # 变换矩阵：T R0 T' = I, T G0 T' = diag(w)
print('T R0 T\' =\n', T @ R0 @ T.T)
print('T G0 T\' =\n', T @ G0 @ T.T)
print('典型尺度上的"遗传力" w/(w+1) =', w/(w+1))
print('等模型下：三性状 REML 解耦为 3 个单性状 REML，参数由 %d 个降为 %d 个'
      % (2*t*(t+1)//2, 2*t))

print('\n--- 有缺失时会发生什么 ---')
pats = {'全测(1,2,3)': [0,1,2], '缺性状3(1,2)': [0,1], '只测性状1': [0]}
for nm, idx in pats.items():
    idx = np.array(idx)
    Rs = R0[np.ix_(idx, idx)]
    # 对该模式，个体的残差协方差在典型尺度上的像：T_sub 为 T 的相应列
    Ts = T[:, idx]
    Rt = Ts @ Rs @ Ts.T
    off = Rt - np.diag(np.diag(Rt))
    print('%14s : T R_sub T\' 的对角 = %s' % (nm, np.round(np.diag(Rt),4)))
    print('%14s   非对角最大绝对值 = %.4f ；相对对角均值 = %.1f%%'
          % ('', np.abs(off).max(), 100*np.abs(off).max()/np.mean(np.diag(Rt))))

# ---------- 随机回归的参数个数 ----------
print('\n\n=== 随机回归模型的参数个数 ===')
print('拟合阶 d | 基函数个数 k | K_a 参数 | K_pe 参数 | 残差方差类 m | 合计')
for d in range(1, 6):
    k = d+1; na = k*(k+1)//2
    for m in [1, 4]:
        print('%8d | %12d | %8d | %9d | %12d | %5d' % (d, k, na, na, m, 2*na+m))
print('\n降秩（只保留前 r 个主成分）后的 K_a 参数个数：')
print(' k \\ r |' + ''.join('%6d'%r for r in range(1,7)))
for k in range(2, 7):
    row = []
    for r in range(1, 7):
        row.append(r*k - r*(r-1)//2 if r <= k else 0)
    print('%5d |'%k + ''.join(('%6d'%v if v else '     -') for v in row))
