# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 run10.py    依赖：numpy
"""例 18.9：收敛判据的定量比较；与外部软件对照的容差。"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import sys, numpy as np
sys.path.insert(0, os.path.join(HERE, 'ch18b'))
import core
np.set_printoptions(precision=6, suppress=True)
D = core.prep(core.simulate(seed=20260418, n_base=120, n_gen=3, per_gen=200, n_herd=3,
                            sa2=25.0, se2=75.0, frac_rec=0.60)); core.prep_eig(D)
SOL = np.array([24.00991961, 71.04510776]); h2S = SOL[0]/SOL.sum()
siS = core.score_info(D, SOL[0], SOL[1]); IA = siS['IA']
SEa, SEe = np.sqrt(np.diag(np.linalg.inv(IA)))
g = np.array([SOL[1], -SOL[0]])/SOL.sum()**2
SEh = float(np.sqrt(g @ np.linalg.inv(IA) @ g))
lRmax = siS['lR']
print('REML 解 σ̂a²=%.6f σ̂e²=%.6f ĥ²=%.6f  ℓ_R=%.6f' % (SOL[0],SOL[1],h2S,lRmax))
print('SE(σ̂a²)=%.4f SE(σ̂e²)=%.4f SE(ĥ²)=%.6f' % (SEa,SEe,SEh))
print('AI 矩阵特征值 =', np.linalg.eigvalsh(IA))

# --- EM 轨迹：三个判据各在何时触发、此时离解有多远 ---
th = np.array([10.0, 90.0]); prev = core.eig_quant(D, th[0], th[1])['lR']
s0 = np.linalg.norm(core.score_info(D, th[0], th[1])['s'])
rows = []
hit = {}
for t in range(1, 30001):
    a,e,_ = core.em_eig(D, th[0], th[1]); thn = np.array([a,e])
    relp = np.max(np.abs(thn-th)/np.abs(th)); th = thn
    lR = core.eig_quant(D, th[0], th[1])['lR']
    dl = abs(lR-prev); prev = lR
    for eps in [1e-4, 1e-6, 1e-8, 1e-10]:
        if ('dl', eps) not in hit and dl < eps: hit[('dl',eps)] = (t, th.copy(), lR)
        if ('dp', eps) not in hit and relp < eps: hit[('dp',eps)] = (t, th.copy(), lR)
    if t % 25 == 0 or t < 5:
        sn = np.linalg.norm(core.score_info(D, th[0], th[1])['s'])
        for eps in [1e-2, 1e-3, 1e-4, 1e-6]:
            if ('sc', eps) not in hit and sn < eps*s0: hit[('sc',eps)] = (t, th.copy(), lR)
    if relp < 1e-12: break
print('\nEM 共 %d 轮到 rel<1e-12' % t)
print('\n=== 三个判据触发时离真解有多远（EM 轨迹）===')
print('判据                      | 触发轮次 |    σ̂a²   |  σ̂a² 相对误差 |    ĥ²    | |Δĥ²|/SE(ĥ²) | ℓ_Rmax-ℓ_R')
lab = {'dl':'|Δℓ_R| < ', 'dp':'‖Δθ‖/‖θ‖ < ', 'sc':'‖s‖ < ε·‖s⁰‖, ε='}
for key in sorted(hit, key=lambda k: hit[k][0]):
    kind, eps = key; t_, th_, lR_ = hit[key]
    h2_ = th_[0]/th_.sum()
    print('%-25s | %8d | %9.5f | %13.3e | %8.6f | %12.4f | %10.3e'
          % (lab[kind]+('%.0e'%eps), t_, th_[0], abs(th_[0]-SOL[0])/SOL[0], h2_,
             abs(h2_-h2S)/SEh, lRmax-lR_))

# --- 似然差与参数差的二次关系 ---
print('\n=== 似然差 Δℓ 能容许多大的参数差（二次近似 Δℓ ≈ ½Δθ\'I^A Δθ）===')
ev = np.linalg.eigvalsh(IA); vec = np.linalg.eigh(IA)[1]
print('最平坦方向（I^A 最小特征值 %.6f）上的单位向量 = %s' % (ev[0], vec[:,0]))
print('   Δℓ_R  | 最平坦方向上的 ‖Δθ‖ | Δσa² | Δĥ² | Δĥ²/SE(ĥ²)')
for dl in [1e-2, 1e-3, 1e-4, 1e-6, 1e-8]:
    nrm = np.sqrt(2*dl/ev[0]); d = nrm*vec[:,0]
    thd = SOL + d; h2d = thd[0]/thd.sum()
    print('%8.0e | %19.5f | %7.5f | %8.6f | %10.4f' % (dl, nrm, d[0], h2d-h2S, abs(h2d-h2S)/SEh))

# --- 跨软件对照的容差建议 ---
print('\n=== 跨软件对照：容差与 SE 的关系 ===')
print('若两套实现给出的 ĥ² 相差 δ，则 δ/SE(ĥ²) 为：')
for d in [1e-2, 1e-3, 1e-4, 1e-5, 1e-6]:
    print('   δ = %8.0e -> δ/SE = %9.5f  (%.3g%% 的抽样标准误)' % (d, d/SEh, 100*d/SEh))
print('\n对数似然：ℓ_R 的绝对值依赖于常数项约定（是否含 -(N-r)/2·log 2π = %.6f）'
      % (-(D['N']-D['r'])/2*np.log(2*np.pi)))
print('本书 ℓ_R = %.6f（不含常数）；加上常数后 = %.6f'
      % (lRmax, lRmax - (D['N']-D['r'])/2*np.log(2*np.pi)))
print('故跨软件只能比较 ℓ_R 的**差**，不能比较绝对值。')
