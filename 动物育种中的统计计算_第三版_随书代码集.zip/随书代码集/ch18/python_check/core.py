# -*- coding: utf-8 -*-
"""ch18 扩充：公共模块——模拟数据、A 矩阵、似然、得分、三种信息矩阵、四种算法。"""
import numpy as np

# ---------- 系谱与 A ----------
def make_ped(n_base, n_gen, per_gen, rng):
    """返回 sire, dam 数组（0 表示未知），个体编号 0..n-1，父母编号小于子代。"""
    sire = np.zeros(0, dtype=int); dam = np.zeros(0, dtype=int)
    sire = np.full(n_base, -1); dam = np.full(n_base, -1)
    males = list(range(0, n_base, 2)); females = list(range(1, n_base, 2))
    for g in range(n_gen):
        ns = rng.choice(males, size=per_gen)
        nd = rng.choice(females, size=per_gen)
        start = len(sire)
        sire = np.concatenate([sire, ns]); dam = np.concatenate([dam, nd])
        newids = list(range(start, start + per_gen))
        males = newids[0::2]; females = newids[1::2]
    return sire, dam

def amat(sire, dam):
    n = len(sire); A = np.zeros((n, n))
    zero = np.zeros(n)
    for i in range(n):
        s, d = sire[i], dam[i]
        rs = A[s] if s >= 0 else zero
        rd = A[d] if d >= 0 else zero
        row = 0.5 * (rs[:i] + rd[:i])
        A[i, :i] = row; A[:i, i] = row
        a_sd = A[s, d] if (s >= 0 and d >= 0) else 0.0
        A[i, i] = 1.0 + 0.5 * a_sd
    return A

# ---------- 模拟数据 ----------
def simulate(seed=20260418, n_base=120, n_gen=3, per_gen=200, n_herd=3,
             sa2=25.0, se2=75.0, frac_rec=0.60):
    rng = np.random.default_rng(seed)
    sire, dam = make_ped(n_base, n_gen, per_gen, rng)
    n = len(sire)
    A = amat(sire, dam)
    L = np.linalg.cholesky(A + 1e-10 * np.eye(n))
    u = L @ rng.standard_normal(n) * np.sqrt(sa2)
    # 有记录的个体：最后两代中随机抽 frac_rec
    cand = np.arange(n_base, n)
    rec = np.sort(rng.choice(cand, size=int(frac_rec * len(cand)), replace=False))
    N = len(rec)
    herd = rng.integers(0, n_herd, size=N)
    X = np.zeros((N, n_herd))
    X[np.arange(N), herd] = 1.0                    # cell-means 编码，满秩
    beta = np.array([10.0, 14.0, 12.0])[:n_herd]
    Z = np.zeros((N, n))
    Z[np.arange(N), rec] = 1.0
    e = rng.standard_normal(N) * np.sqrt(se2)
    y = X @ beta + Z @ u + e
    return dict(A=A, Ainv=np.linalg.inv(A), X=X, Z=Z, y=y, n=n, N=N,
                q=n, r=np.linalg.matrix_rank(X), sire=sire, dam=dam, u=u, rec=rec)

# ---------- 似然、得分、信息矩阵（稠密参考实现） ----------
def pieces(D, sa2, se2):
    A, X, Z, y = D['A'], D['X'], D['Z'], D['y']
    N = D['N']
    Va = Z @ A @ Z.T
    V = Va * sa2 + np.eye(N) * se2
    Vi = np.linalg.inv(V)
    XtViX = X.T @ Vi @ X
    P = Vi - Vi @ X @ np.linalg.solve(XtViX, X.T @ Vi)
    sgn1, ld1 = np.linalg.slogdet(V)
    sgn2, ld2 = np.linalg.slogdet(XtViX)
    yPy = y @ P @ y
    lR = -0.5 * (ld1 + ld2 + yPy)
    return dict(Va=Va, V=V, P=P, yPy=yPy, lR=lR, logdetV=ld1, logdetXVX=ld2)

def score_info(D, sa2, se2):
    pc = pieces(D, sa2, se2)
    P, Va, y, N = pc['P'], pc['Va'], D['y'], D['N']
    Vs = [Va, np.eye(N)]
    Py = P @ y
    PV = [P @ Vi_ for Vi_ in Vs]
    s = np.array([-0.5 * (np.trace(PV[i]) - y @ PV[i] @ P @ y) for i in range(2)])
    IO = np.zeros((2, 2)); IE = np.zeros((2, 2)); IA = np.zeros((2, 2))
    for i in range(2):
        for j in range(2):
            quad = y @ PV[i] @ PV[j] @ Py
            tr = np.trace(PV[i] @ PV[j])
            IO[i, j] = quad - 0.5 * tr
            IE[i, j] = 0.5 * tr
            IA[i, j] = 0.5 * quad
    return dict(s=s, IO=IO, IE=IE, IA=IA, lR=pc['lR'], yPy=pc['yPy'],
                trPVa=np.trace(PV[0]), trPVe=np.trace(PV[1]), Py=Py)

# ---------- MME ----------
def mme(D, sa2, se2):
    X, Z, y, Ainv = D['X'], D['Z'], D['y'], D['Ainv']
    p, q = X.shape[1], Z.shape[1]
    alpha = se2 / sa2
    C = np.zeros((p + q, p + q))
    C[:p, :p] = X.T @ X; C[:p, p:] = X.T @ Z
    C[p:, :p] = Z.T @ X; C[p:, p:] = Z.T @ Z + Ainv * alpha
    rhs = np.concatenate([X.T @ y, Z.T @ y])
    sol = np.linalg.solve(C, rhs)
    Cinv = np.linalg.inv(C)
    return dict(C=C, Cinv=Cinv, sol=sol, beta=sol[:p], u=sol[p:],
                Cuu=Cinv[p:, p:], p=p, q=q, alpha=alpha)

def em_step(D, sa2, se2, strict=True):
    """strict=True: 严格 EM（sigma_e^2 = E[e'e|y]/N）；False: Henderson 形式 y'ê/(N-r)。"""
    M = mme(D, sa2, se2)
    X, Z, y, Ainv = D['X'], D['Z'], D['y'], D['Ainv']
    q, N, r = D['q'], D['N'], D['r']
    uh, bh = M['u'], M['beta']
    trACuu = np.trace(Ainv @ M['Cuu'])
    uAu = uh @ Ainv @ uh
    sa2_new = (uAu + trACuu * se2) / q
    eh = y - X @ bh - Z @ uh
    if strict:
        W = np.hstack([X, Z])
        trC = np.trace(M['Cinv'] @ (W.T @ W))
        ee = eh @ eh + se2 * trC
        se2_new = ee / N
    else:
        se2_new = (y @ eh) / (N - r)
    return sa2_new, se2_new, dict(uAu=uAu, trACuu=trACuu, ehe=eh @ eh, yeh=y @ eh)

# ---------- 高效 MME 路径（用于长迭代） ----------
from scipy.linalg import cho_factor, cho_solve
def prep(D):
    X, Z, y = D['X'], D['Z'], D['y']
    D['XtX'] = X.T @ X; D['XtZ'] = X.T @ Z; D['ZtZ'] = Z.T @ Z
    D['Xty'] = X.T @ y; D['Zty'] = Z.T @ y; D['yty'] = y @ y
    s, D['logdetA'] = np.linalg.slogdet(D['A'])
    D['p'] = X.shape[1]
    return D

def mme_fast(D, sa2, se2, want_inv=True):
    p, q, N = D['p'], D['q'], D['N']
    alpha = se2 / sa2
    m = p + q
    C = np.empty((m, m))
    C[:p, :p] = D['XtX']; C[:p, p:] = D['XtZ']; C[p:, :p] = D['XtZ'].T
    C[p:, p:] = D['ZtZ'] + D['Ainv'] * alpha
    rhs = np.concatenate([D['Xty'], D['Zty']])
    cf = cho_factor(C, lower=True)
    sol = cho_solve(cf, rhs)
    logdetC = 2.0 * np.sum(np.log(np.diag(cf[0])))
    b, u = sol[:p], sol[p:]
    yeh = D['yty'] - b @ D['Xty'] - u @ D['Zty']
    lR = -0.5 * (logdetC + (N - p - q) * np.log(se2) + q * np.log(sa2)
                 + D['logdetA'] + yeh / se2)
    out = dict(beta=b, u=u, yeh=yeh, lR=lR, logdetC=logdetC, alpha=alpha)
    if want_inv:
        Cinv = cho_solve(cf, np.eye(m))
        Cuu = Cinv[p:, p:]
        out['Cuu'] = Cuu
        out['trACuu'] = float(np.sum(D['Ainv'] * Cuu))
        out['uAu'] = float(u @ (D['Ainv'] @ u))
        eh = D['y'] - D['X'] @ b - D['Z'] @ u
        out['ehe'] = float(eh @ eh); out['eh'] = eh
    return out

def em_fast(D, sa2, se2, strict=True):
    M = mme_fast(D, sa2, se2)
    q, N, r, p = D['q'], D['N'], D['r'], D['p']
    sa2n = (M['uAu'] + M['trACuu'] * se2) / q
    if strict:
        trCWW = (p + q) - M['alpha'] * M['trACuu']
        se2n = (M['ehe'] + se2 * trCWW) / N
    else:
        se2n = M['yeh'] / (N - r)
    return sa2n, se2n, M

# ---------- 特征分解快速路径（仅用于长迭代；与稠密路径逐位核对过） ----------
from scipy.linalg import solve_triangular, eigh
def prep_eig(D):
    X, Z, y, A = D['X'], D['Z'], D['y'], D['A']
    N, q, p = D['N'], D['q'], D['p']
    M = np.eye(N) - X @ np.linalg.solve(X.T @ X, X.T)
    ZMZ = Z.T @ M @ Z; ZMy = Z.T @ (M @ y)
    L = np.linalg.cholesky(D['Ainv'] + 0.0)          # A^{-1} = L L'
    S = solve_triangular(L, solve_triangular(L, ZMZ, lower=True).T, lower=True)
    S = 0.5 * (S + S.T)
    lam, Q = eigh(S)
    lam = np.maximum(lam, 0.0)
    g = Q.T @ solve_triangular(L, ZMy, lower=True)
    D['E'] = dict(lam=lam, Q=Q, L=L, g=g, ZMZ=ZMZ, ZMy=ZMy,
                  yMy=float(y @ (M @ y)),
                  logdetXX=float(np.linalg.slogdet(X.T @ X)[1]))
    return D

def eig_quant(D, sa2, se2):
    E = D['E']; lam, Q, L, g = E['lam'], E['Q'], E['L'], E['g']
    N, q, p, r = D['N'], D['q'], D['p'], D['r']
    al = se2 / sa2; dd = lam + al
    trACuu = float(np.sum(1.0 / dd))
    c = g / dd                                        # (Λ+αI)^{-1} g
    uAu = float(np.sum((c) ** 2 * 1.0))               # ||Q c||^2 = ||c||^2
    uh = solve_triangular(L.T, Q @ c, lower=False)    # û
    yeh = E['yMy'] - float(E['ZMy'] @ uh)
    ehe = E['yMy'] - 2*float(E['ZMy'] @ uh) + float(uh @ (E['ZMZ'] @ uh))
    lR = -0.5*(E['logdetXX'] + float(np.sum(np.log(dd))) + (N-p-q)*np.log(se2)
               + q*np.log(sa2) + yeh/se2)
    return dict(trACuu=trACuu, uAu=uAu, yeh=yeh, ehe=ehe, lR=lR, alpha=al, u=uh)

def em_eig(D, sa2, se2, strict=True):
    E = eig_quant(D, sa2, se2)
    q, N, r, p = D['q'], D['N'], D['r'], D['p']
    sa2n = (E['uAu'] + E['trACuu'] * se2) / q
    if strict:
        trCWW = (p + q) - E['alpha'] * E['trACuu']
        se2n = (E['ehe'] + se2 * trCWW) / N
    else:
        se2n = E['yeh'] / (N - r)
    return sa2n, se2n, E
