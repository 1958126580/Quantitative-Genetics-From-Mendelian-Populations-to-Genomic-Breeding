# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 run3.py    依赖：numpy
import os; HERE = os.path.dirname(os.path.abspath(__file__))
# -*- coding: utf-8 -*-
import sys, numpy as np
sys.path.insert(0, os.path.join(HERE, 'ch18b'))
import core
np.set_printoptions(precision=6, suppress=True)
D = core.prep(core.simulate(seed=20260418, n_base=120, n_gen=3, per_gen=200, n_herd=3,
                            sa2=25.0, se2=75.0, frac_rec=0.60))
print('=== 宽范围扫描 IO 的最小特征值（例 18.1 数据） ===')
print('  sa2   |   se2   |  sa2+se2 |  h2   |  eigmin(IO) | eigmin(IE) | eigmin(IA) | s\'d(NR)')
for a, e in [(1,3),(5,15),(12.5,37.5),(25,75),(50,150),(100,300),(200,600),(400,1200),
             (2,190),(190,2),(0.5,1.5),(60,600),(600,60)]:
    si = core.score_info(D, float(a), float(e))
    eO = np.linalg.eigvalsh(si['IO']); eE = np.linalg.eigvalsh(si['IE']); eA = np.linalg.eigvalsh(si['IA'])
    try:
        d = np.linalg.solve(si['IO'], si['s']); sd = si['s'] @ d
    except Exception: sd = np.nan
    print('%7.2f | %7.2f | %8.1f | %5.3f | %11.6f | %10.6f | %10.6f | %10.4f'
          % (a, e, a+e, a/(a+e), eO[0], eE[0], eA[0], sd))
print()
for a, e in [(100,300),(200,600),(400,1200),(600,60),(60,600)]:
    si = core.score_info(D, float(a), float(e))
    print('θ=(%.0f,%.0f)  IO=%s  eig=%s  s=%s' % (a,e,si['IO'].ravel(), np.linalg.eigvalsh(si['IO']), si['s']))
    if np.linalg.eigvalsh(si['IO'])[0] < 0:
        d = np.linalg.solve(si['IO'], si['s'])
        print('    NR 方向 d=%s  s\'d=%.6f  新点=%s  lR(旧)=%.4f' % (d, si['s']@d, np.array([a,e])+d, si['lR']))
