# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 run2.py    依赖：numpy
"""例 18.2：二阶方法（NR / Fisher scoring / AI）在例 18.1 数据上的对照。"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import sys, numpy as np
sys.path.insert(0, os.path.join(HERE, 'ch18b'))
import core
np.set_printoptions(precision=6, suppress=True)
D = core.prep(core.simulate(seed=20260418, n_base=120, n_gen=3, per_gen=200, n_herd=3,
                            sa2=25.0, se2=75.0, frac_rec=0.60))
SOL = np.array([24.0099004, 71.0451075])
START = np.array([10.0, 90.0])

def run(kind, start, maxit=100, tol=1e-8, damp=True):
    th = np.array(start, float); rows = []; nhalf = 0; status='ok'
    for t in range(1, maxit+1):
        si = core.score_info(D, th[0], th[1])
        I = si[kind]; ev = np.linalg.eigvalsh(I)
        d = np.linalg.solve(I, si['s'])
        step = 1.0; used = 0
        while True:
            thn = th + step*d
            if not damp: break
            ok = np.all(thn > 1e-8)
            if ok:
                lRn = core.mme_fast(D, thn[0], thn[1], want_inv=False)['lR']
                if lRn >= si['lR'] - 1e-9: break
            step /= 2; used += 1; nhalf += 1
            if used > 25: status='步长耗尽'; break
        if status != 'ok': break
        if np.any(thn <= 0):
            rows.append((t, thn[0], thn[1], np.nan, np.nan, np.nan, ev.min(), step))
            status = '跳出参数空间'; break
        rel = np.max(np.abs(thn-th)/np.abs(th)); th = thn
        lR = core.mme_fast(D, th[0], th[1], want_inv=False)['lR']
        rows.append((t, th[0], th[1], th[0]/th.sum(), lR, rel, ev.min(), step))
        if rel < tol: break
    return rows, status, nhalf

for kind, name in [('IA','AI-REML'), ('IE','Fisher scoring'), ('IO','Newton-Raphson')]:
    for damp in (True, False):
        rows, st, nh = run(kind, START, damp=damp)
        print('\n=== %s  [%s] === 状态=%s 迭代数=%d 步长减半共 %d 次'
              % (name, '带步长阻尼' if damp else '全步长', st, len(rows), nh))
        print('  it |     sa2    |     se2    |    h2    |      lR         | 相对变化  | min eig(I) | 步长')
        for t,a,e,h,l,rel,ev,stp in rows:
            print('%5d | %10.6f | %10.6f | %8.6f | %15.9f | %9.3e | %10.6f | %.5f' % (t,a,e,h,l,rel,ev,stp))

# ---- NR 的非正定 Hessian：网格扫描 ----
print('\n\n=== Newton-Raphson 的观测信息在哪些点非正定 ===')
print('   sa2 |    se2  |   h2   |   eig1(IO)   |   eig2(IO)   | 正定? |  eig min(IE) | eig min(IA)')
pts = [(2.0,95.0),(5.0,92.0),(10.0,90.0),(24.0099,71.0451),(45.0,55.0),(60.0,45.0),
       (75.0,30.0),(80.0,20.0),(90.0,12.0),(95.0,6.0)]
for a,e in pts:
    si = core.score_info(D, a, e)
    ev = np.linalg.eigvalsh(si['IO']); eE = np.linalg.eigvalsh(si['IE']); eA = np.linalg.eigvalsh(si['IA'])
    print('%6.2f | %6.2f | %6.4f | %12.6f | %12.6f |  %s  | %12.6f | %12.6f'
          % (a,e,a/(a+e),ev[0],ev[1],'是' if ev[0]>0 else '否',eE[0],eA[0]))

# 从一个 IO 非正定的点出发，全步长 NR
for bad in [(90.0,12.0),(80.0,20.0),(95.0,6.0)]:
    si = core.score_info(D, bad[0], bad[1])
    d = np.linalg.solve(si['IO'], si['s'])
    print('\n起点 (%.1f, %.1f): IO 特征值 %s' % (bad[0],bad[1], np.linalg.eigvalsh(si['IO'])))
    print('   得分 s =', si['s'], '  NR 方向 d =', d, '  s\'d = %.6f （<0 即非上升方向）' % (si['s']@d))
    print('   全步长后 theta =', np.array(bad)+d)
    rows, st, nh = run('IO', bad, damp=False, maxit=12)
    print('   全步长 NR：状态=%s' % st)
    for t,a,e,h,l,rel,ev,stp in rows[:6]:
        print('      it%2d  sa2=%12.4f se2=%12.4f  lR=%s' % (t,a,e,('%15.6f'%l) if l==l else '  —（出界）'))
    rows, st, nh = run('IO', bad, damp=True, maxit=60)
    print('   带阻尼 NR：状态=%s 迭代数=%d 减半 %d 次 -> sa2=%.6f se2=%.6f' % (st,len(rows),nh,rows[-1][1],rows[-1][2]))
    rows, st, nh = run('IA', bad, damp=True, maxit=60)
    print('   带阻尼 AI：状态=%s 迭代数=%d 减半 %d 次 -> sa2=%.6f se2=%.6f' % (st,len(rows),nh,rows[-1][1],rows[-1][2]))
    rows, st, nh = run('IE', bad, damp=True, maxit=60)
    print('   带阻尼 FS：状态=%s 迭代数=%d 减半 %d 次 -> sa2=%.6f se2=%.6f' % (st,len(rows),nh,rows[-1][1],rows[-1][2]))
