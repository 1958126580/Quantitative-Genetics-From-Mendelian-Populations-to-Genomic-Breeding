# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 final_numbers.py    依赖：numpy
"""例 18.1 的全部正文数字，统一在高精度解处计算一次。"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import sys, numpy as np
sys.path.insert(0, os.path.join(HERE, 'ch18b'))
import core
np.set_printoptions(precision=8, suppress=True)
D = core.prep(core.simulate(seed=20260418, n_base=120, n_gen=3, per_gen=200, n_herd=3,
                            sa2=25.0, se2=75.0, frac_rec=0.60)); core.prep_eig(D)
th = np.array([25.0, 75.0])
for _ in range(400):
    si = core.score_info(D, th[0], th[1]); thn = th + np.linalg.solve(si['IA'], si['s'])
    if np.max(np.abs(thn-th)/np.abs(th)) < 1e-15: th = thn; break
    th = thn
sa2, se2 = th; q,N,r,p = D['q'],D['N'],D['r'],D['p']
si = core.score_info(D, sa2, se2); M = core.mme_fast(D, sa2, se2)
print('σ̂a² = %.8f   σ̂e² = %.8f   ĥ² = %.8f' % (sa2, se2, sa2/(sa2+se2)))
print('ℓ_R = %.8f   得分 = %s' % (si['lR'], si['s']))
print("û'A⁻¹û = %.6f ; tr(A⁻¹C^uu) = %.6f ; ê'ê = %.6f ; y'ê = %.6f" %
      (M['uAu'], M['trACuu'], M['ehe'], M['yeh']))
al = se2/sa2; print('α = %.6f' % al)
num = M['uAu'] + M['trACuu']*se2
print('EM 分子 = %.4f + %.4f = %.4f ; /q = %.8f' % (M['uAu'], M['trACuu']*se2, num, num/q))
print('漏掉迹项： %.6f （低估 %.2f%%）；迹项占分子 %.2f%%'
      % (M['uAu']/q, 100*(1-M['uAu']/q/sa2), 100*M['trACuu']*se2/num))
trCWW = (p+q) - al*M['trACuu']; Eee = M['ehe'] + se2*trCWW
print("tr(C⁻¹W'W) = %.6f ; E[e'e|y] = %.6f ; /N = %.8f ; y'ê/(N-r) = %.8f"
      % (trCWW, Eee, Eee/N, M['yeh']/(N-r)))
print('\ntr(PVa) = %.8f ; tr(PVe)=tr(P) = %.8f ; 恒等式和 = %.8f (N-r=%d)'
      % (si['trPVa'], si['trPVe'], si['trPVa']*sa2+si['trPVe']*se2, N-r))
print("y'Py = %.8f" % si['yPy'])
for nm in ['IE','IO','IA']:
    print('%s = %s  特征值 %s' % (nm, si[nm].ravel(), np.linalg.eigvalsh(si[nm])))
V = np.linalg.inv(si['IA']); g = np.array([se2,-sa2])/(sa2+se2)**2
print('SE(σ̂a²)=%.6f SE(σ̂e²)=%.6f corr=%.6f SE(ĥ²)=%.6f'
      % (np.sqrt(V[0,0]), np.sqrt(V[1,1]), V[0,1]/np.sqrt(V[0,0]*V[1,1]), np.sqrt(g@V@g)))
Icom = np.diag([q/(2*sa2**2), N/(2*se2**2)]); DM = np.eye(2)-np.linalg.solve(Icom, si['IO'])
ev = np.sort(np.abs(np.linalg.eigvals(DM)))[::-1]
print('\nI_com = diag(%.6f, %.6f) ; I_mis = %s' % (Icom[0,0], Icom[1,1], (Icom-si['IO']).ravel()))
print('DM 特征值 = %s ; ρ = %.6f ; 缺失信息比例(σa²) = %.5f'
      % (np.linalg.eigvals(DM), ev[0], (Icom-si['IO'])[0,0]/Icom[0,0]))
print('ln(1e-8)/ln(ρ) = %.0f' % (np.log(1e-8)/np.log(ev[0])))
print('起点 (10,90) 的 ℓ_R = %.8f' % core.eig_quant(D,10.,90.)['lR'])
print('常数 -(N-r)/2 ln2π = %.6f' % (-(N-r)/2*np.log(2*np.pi)))
print('var(y) = %.4f ; mean F = %.6f ; max F = %.6f'
      % (np.var(D['y'],ddof=1), np.mean(np.diag(D['A']))-1, np.max(np.diag(D['A']))-1))
# 迹误差放大
IAi = np.linalg.inv(si['IA']); v = np.array([al,-1.0])/(2*sa2); dth = IAi@v
print('\n每单位迹误差： Δσa²=%.6f  Δσe²=%.6f  Δh²=%.8f' % (dth[0], dth[1], g@dth))
print('相对放大倍数 σa²: %.2f ; h²: %.2f' % (abs(dth[0])/sa2*M['trACuu'], abs(g@dth)/(sa2/(sa2+se2))*M['trACuu']))
for S in [5,10,20,50,100]:
    sd = np.sqrt(1.9734/S)
    print('  S=%3d 预测 SD(σ̂a²)=%.4f SD(ĥ²)=%.5f' % (S, abs(dth[0])*sd, abs(g@dth)*sd))
