# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 run4.py    依赖：numpy
"""例 18.3：NR 的非正定 Hessian 与补救；AI 的 MME 实现验证。"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import sys, numpy as np, time
sys.path.insert(0, os.path.join(HERE, 'ch18b'))
import core
np.set_printoptions(precision=6, suppress=True)
D = core.prep(core.simulate(seed=20260418, n_base=120, n_gen=3, per_gen=200, n_herd=3,
                            sa2=25.0, se2=75.0, frac_rec=0.60))
SOL = np.array([24.0099196, 71.0451078])
BAD = np.array([100.0, 300.0])

si = core.score_info(D, BAD[0], BAD[1])
print('=== 起点 θ=(100,300)（总方差取成 var(y) 的 4 倍）===')
print('lR = %.6f   得分 s = %s' % (si['lR'], si['s']))
print('IO =', si['IO'].ravel(), ' 特征值 =', np.linalg.eigvalsh(si['IO']))
print('IE =', si['IE'].ravel(), ' 特征值 =', np.linalg.eigvalsh(si['IE']))
print('IA =', si['IA'].ravel(), ' 特征值 =', np.linalg.eigvalsh(si['IA']))
dO = np.linalg.solve(si['IO'], si['s']); dE = np.linalg.solve(si['IE'], si['s']); dA = np.linalg.solve(si['IA'], si['s'])
for nm, d in [('NR', dO), ('FS', dE), ('AI', dA)]:
    print('%s: d = %s   s\'d = %12.6f   新点 = %s' % (nm, d, si['s']@d, BAD+d))

def iterate(kind, start, maxit=200, tol=1e-8, damp=True, lm=False, tr=None):
    th = np.array(start, float); rows=[]; nh=0; status='ok'; lam_used=[]
    for t in range(1, maxit+1):
        s_ = core.score_info(D, th[0], th[1]); I = s_[kind].copy()
        lam = 0.0
        if lm:  # Levenberg-Marquardt：加 lam*I 直到正定
            base = max(1e-12, np.abs(np.diag(I)).max())
            while np.linalg.eigvalsh(I + lam*np.eye(2))[0] <= 1e-10*base:
                lam = base*1e-3 if lam == 0 else lam*10
            I = I + lam*np.eye(2)
        lam_used.append(lam)
        d = np.linalg.solve(I, s_['s'])
        if tr is not None and np.linalg.norm(d) > tr*np.linalg.norm(th):
            d = d * tr*np.linalg.norm(th)/np.linalg.norm(d)
        step = 1.0; used = 0
        while damp:
            thn = th + step*d
            if np.all(thn > 1e-8):
                lRn = core.mme_fast(D, thn[0], thn[1], want_inv=False)['lR']
                if lRn >= s_['lR'] - 1e-9: break
            step /= 2; used += 1; nh += 1
            if used > 30: status = '步长耗尽（方向本身非上升）'; break
        if not damp: thn = th + d
        if status != 'ok': break
        if np.any(thn <= 0) or not np.all(np.isfinite(thn)):
            status = '跳出参数空间'; rows.append((t, thn[0], thn[1], np.nan, lam, step)); break
        rel = np.max(np.abs(thn-th)/np.abs(th)); th = thn
        lR = core.mme_fast(D, th[0], th[1], want_inv=False)['lR']
        rows.append((t, th[0], th[1], lR, lam, step))
        if rel < tol: break
        if th[0]+th[1] > 1e7: status='发散'; break
    return rows, status, nh, lam_used

print('\n--- 全步长 NR，从 (100,300) 出发 ---')
rows, st, nh, lam = iterate('IO', BAD, damp=False, maxit=12)
print('状态=%s' % st)
for t,a,e,l,lm_,stp in rows[:12]:
    print('  it%3d  sa2=%14.4f  se2=%14.4f  sa2+se2=%14.4f  lR=%s' %
          (t,a,e,a+e,('%13.6f'%l) if l==l else '   —'))

print('\n--- 步长减半的 NR（只缩步长，不改方向）---')
rows, st, nh, lam = iterate('IO', BAD, damp=True, maxit=60)
print('状态=%s  迭代数=%d  减半共 %d 次' % (st, len(rows), nh))

print('\n--- Levenberg–Marquardt 修正的 NR ---')
rows, st, nh, lam = iterate('IO', BAD, damp=True, lm=True, maxit=80)
print('状态=%s  迭代数=%d  减半共 %d 次' % (st, len(rows), nh))
for t,a,e,l,lm_,stp in rows[:10]:
    print('  it%3d  sa2=%12.6f se2=%12.6f lR=%13.6f  λ=%10.3e 步长=%.4f' % (t,a,e,l,lm_,stp))
print('  ... 末行:', '  it%3d  sa2=%12.6f se2=%12.6f lR=%13.6f' % (rows[-1][0],rows[-1][1],rows[-1][2],rows[-1][3]))

print('\n--- 信赖域（‖Δθ‖ ≤ 0.5‖θ‖）的 NR ---')
rows, st, nh, lam = iterate('IO', BAD, damp=True, lm=True, tr=0.5, maxit=120)
print('状态=%s  迭代数=%d  减半共 %d 次  末点 sa2=%.6f se2=%.6f' % (st, len(rows), nh, rows[-1][1], rows[-1][2]))

for kind, nm in [('IA','AI'), ('IE','Fisher scoring')]:
    rows, st, nh, lam = iterate(kind, BAD, damp=True, maxit=120)
    print('\n--- %s 从 (100,300) 出发 --- 状态=%s 迭代数=%d 减半 %d 次 末点 sa2=%.6f se2=%.6f'
          % (nm, st, len(rows), nh, rows[-1][1], rows[-1][2]))
    for t,a,e,l,lm_,stp in rows[:6]:
        print('  it%3d  sa2=%12.6f se2=%12.6f lR=%13.6f 步长=%.4f' % (t,a,e,l,stp))

# EM 从 (100,300)
th = BAD.copy()
for t in range(1, 6000+1):
    a,e,M = core.em_fast(D, th[0], th[1]); thn=np.array([a,e])
    rel = np.max(np.abs(thn-th)/np.abs(th)); th = thn
    if rel < 1e-8: break
print('\n--- EM 从 (100,300) 出发 --- 迭代数=%d 末点 sa2=%.6f se2=%.6f' % (t, th[0], th[1]))

# ---------- AI 的 MME 实现（工作变量）验证 ----------
print('\n\n=== AI 矩阵的 MME 实现验证（θ = REML 解） ===')
def ai_via_mme(D, sa2, se2):
    X, Z, y, A = D['X'], D['Z'], D['y'], D['A']
    M = core.mme_fast(D, sa2, se2, want_inv=False)
    eh = y - X@M['beta'] - Z@M['u']
    Py = eh/se2
    ya = Z @ M['u'] / sa2          # = Z A Z' Py
    ye = Py                        # = V_e Py
    W = [ya, ye]
    AI = np.zeros((2,2))
    Pw = []
    for w in W:                    # 每个工作变量当作一个"额外右端项"回代
        Dw = dict(D); Dw['Xty'] = X.T@w; Dw['Zty'] = Z.T@w; Dw['yty'] = w@w
        Mw = core.mme_fast(Dw, sa2, se2, want_inv=False)
        Pw.append((w - X@Mw['beta'] - Z@Mw['u'])/se2)
    for i in range(2):
        for j in range(2):
            AI[i,j] = 0.5 * (W[i] @ Pw[j])
    return AI, ya, ye, Py, M
AI2, ya, ye, Py, M = ai_via_mme(D, SOL[0], SOL[1])
siS = core.score_info(D, SOL[0], SOL[1])
print('稠密 IA =', siS['IA'].ravel())
print('MME  IA =', AI2.ravel())
print('最大绝对差 = %.3e' % np.abs(AI2-siS['IA']).max())
print('校验 ZAZ\'Py 与 Zû/σa² 最大差 = %.3e'
      % np.abs(D['Z']@D['A']@D['Z'].T@Py - ya).max())
print('tr(PVe)=tr(P)=%.10f ; [N-r-q+α tr(A⁻¹Cuu)]/σe² = %.10f'
      % (siS['trPVe'], (D['N']-D['r']-D['q'] + (SOL[1]/SOL[0])*core.mme_fast(D,SOL[0],SOL[1])['trACuu'])/SOL[1]))

# ---------- 每次迭代的实测耗时 ----------
print('\n=== 实测每次迭代耗时（稠密参考实现，N=%d，q=%d） ===' % (D['N'], D['q']))
t0=time.time()
for _ in range(5): core.em_fast(D, SOL[0], SOL[1])
t_em=(time.time()-t0)/5
t0=time.time()
for _ in range(5): ai_via_mme(D, SOL[0], SOL[1])
t_ai=(time.time()-t0)/5
t0=time.time()
for _ in range(3): core.score_info(D, SOL[0], SOL[1])
t_fs=(time.time()-t0)/3
t0=time.time()
for _ in range(5): core.mme_fast(D, SOL[0], SOL[1], want_inv=False)
t_mme=(time.time()-t0)/5
print('一次 MME 求解（分解+回代，不求逆）: %.1f ms' % (t_mme*1000))
print('EM 一次迭代（需 C^uu）           : %.1f ms  = %.1f×MME' % (t_em*1000, t_em/t_mme))
print('AI 一次迭代（MME 实现）          : %.1f ms  = %.1f×MME' % (t_ai*1000, t_ai/t_mme))
print('FS/NR 一次迭代（需 tr(PViPVj)）  : %.1f ms  = %.1f×MME' % (t_fs*1000, t_fs/t_mme))
