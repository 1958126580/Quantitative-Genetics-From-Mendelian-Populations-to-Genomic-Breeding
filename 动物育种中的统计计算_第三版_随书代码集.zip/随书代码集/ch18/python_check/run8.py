# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 run8.py    依赖：numpy, scipy
"""例 18.7：精确迹（选择求逆）与 Monte Carlo 迹的耗时对照——实测稀疏分解/回代时间。"""
import sys, numpy as np, time
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.sparse.csgraph import reverse_cuthill_mckee
rng0 = np.random.default_rng(20260420)

def build(n_base, n_gen, per_gen, frac_rec=0.6, alpha=3.0, seed=20260420):
    rng = np.random.default_rng(seed)
    sire = np.full(n_base, -1); dam = np.full(n_base, -1)
    males = list(range(0, n_base, 2)); females = list(range(1, n_base, 2))
    for g in range(n_gen):
        ns = rng.choice(males, size=per_gen); nd = rng.choice(females, size=per_gen)
        st = len(sire); sire = np.concatenate([sire, ns]); dam = np.concatenate([dam, nd])
        ids = list(range(st, st+per_gen)); males = ids[0::2]; females = ids[1::2]
    n = len(sire)
    k = (sire >= 0).astype(int) + (dam >= 0).astype(int)
    dinv = np.where(k == 2, 2.0, np.where(k == 1, 4.0/3.0, 1.0))
    self_ = np.arange(n)
    rows=[]; cols=[]; vals=[]
    def add(ri, ci, v):
        rows.append(ri); cols.append(ci); vals.append(v)
    ms = sire >= 0; md = dam >= 0
    add(self_, self_, dinv)                                   # (i,i)
    add(self_[ms], sire[ms], -0.5*dinv[ms]); add(sire[ms], self_[ms], -0.5*dinv[ms])
    add(self_[md], dam[md],  -0.5*dinv[md]); add(dam[md],  self_[md], -0.5*dinv[md])
    add(sire[ms], sire[ms], 0.25*dinv[ms])
    add(dam[md],  dam[md],  0.25*dinv[md])
    both = ms & md
    add(sire[both], dam[both], 0.25*dinv[both]); add(dam[both], sire[both], 0.25*dinv[both])
    rows=np.concatenate(rows); cols=np.concatenate(cols); vals=np.concatenate(vals)
    Ainv = sp.coo_matrix((vals,(rows,cols)), shape=(n,n)).tocsc()
    cand = np.arange(n_base, n)
    rec = np.sort(rng.choice(cand, size=int(frac_rec*len(cand)), replace=False))
    N = len(rec)
    ZtZ = sp.coo_matrix((np.ones(N),(rec,rec)), shape=(n,n)).tocsc()
    Cuu = (ZtZ + alpha*Ainv).tocsc()
    return n, N, Ainv, Cuu

print('实测环境：scipy %s，SuperLU 稀疏分解，MMD(A+A\') 重排，对称模式' % __import__('scipy').__version__)
print('\n   n(系谱) |  N(记录) | nnz(A⁻¹) | nnz(L+U) | 填入比 | 分解 t_f(ms) | 单回代 t_s(ms) | t_f/t_s')
tab=[]
for (nb, ng, pg) in [(300,3,400),(400,3,700),(800,4,1800),(1500,5,4000)]:
    n, N, Ainv, Cuu = build(nb, ng, pg)
    t0=time.time(); lu = spl.splu(Cuu, permc_spec='MMD_AT_PLUS_A',
                                  diag_pivot_thresh=0.0, options=dict(SymmetricMode=True))
    tf=time.time()-t0
    b = np.random.default_rng(1).standard_normal(n)
    lu.solve(b)
    t0=time.time()
    for _ in range(20): lu.solve(b)
    ts=(time.time()-t0)/20
    nnzL = lu.L.nnz + lu.U.nnz
    print('%10d | %8d | %8d | %8d | %6.2f | %12.1f | %14.3f | %7.1f'
          % (n, N, Ainv.nnz, nnzL, nnzL/Ainv.nnz, tf*1000, ts*1000, tf/ts))
    tab.append((n,N,Ainv.nnz,nnzL,tf,ts))

print('\n=== 由实测时间推出的"精确 vs MC"交叉点 ===')
print('设精确选择求逆的代价 = c × 一次数值分解（Takahashi 递推与分解同阶，第十五章 §15.2.5），取 c = 1、2、3')
print('   n     | 一次分解(ms) | 单回代(ms) | MC(S=30)(ms) | 精确 c=1 | 精确 c=2 | 精确 c=3 | S* (c=2)')
for n,N,na,nl,tf,ts in tab:
    mc30 = 30*ts*1000
    print('%8d | %12.1f | %10.3f | %12.1f | %8.1f | %8.1f | %8.1f | %8.0f'
          % (n, tf*1000, ts*1000, mc30, tf*1000, 2*tf*1000, 3*tf*1000, 2*tf/ts))
