# 第 18 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch18/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `derived.py` | 正文中由其他脚本结果二次推出的几个数字。 | numpy | 0.1 | `outputs/derived.out` |
| `final_numbers.py` | 例 18.1 的全部正文数字，统一在高精度解处计算一次。 | numpy, scipy | 1.4 | `outputs/final_numbers.out` |
| `run10.py` | 例 18.9：收敛判据的定量比较；与外部软件对照的容差。 | numpy, scipy | 10.5 | `outputs/run10.out` |
| `run11.py` | 数值复核 | numpy, scipy | 0.9 | `outputs/run11.out` |
| `run2.py` | 例 18.2：二阶方法（NR / Fisher scoring / AI）在例 18.1 数据上的对照。 | numpy, scipy | 12.2 | `outputs/run2.out` |
| `run3.py` | 数值复核 | numpy, scipy | 1.5 | `outputs/run3.out` |
| `run4.py` | 例 18.3：NR 的非正定 Hessian 与补救；AI 的 MME 实现验证。 | numpy, scipy | 83.3 | `outputs/run4.out` |
| `run5.py` | 例 18.4：EM 收敛速率与缺失信息比例（不同遗传力）。 | numpy, scipy | 33.5 | `outputs/run5.out` |
| `run6.py` | 例 18.5：Hutchinson 迹估计的方差、探针数与对 θ̂ 的传播。 | numpy, scipy | 68.0 | `outputs/run6.out` |
| `run8.py` | 例 18.7：精确迹（选择求逆）与 Monte Carlo 迹的耗时对照——实测稀疏分解/回代时间。 | numpy, scipy | 19.7 | `outputs/run8.out` |
| `run9.py` | 例 18.8：对数-Cholesky 参数化的 Jacobian、标准误变换、正定性保持；典型变换的失效。 | numpy | 0.1 | `outputs/run9.out` |

公共函数模块（被上列脚本导入，不单独运行）：`core.py`。
