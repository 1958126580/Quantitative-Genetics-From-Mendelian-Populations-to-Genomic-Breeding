# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 18 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 run5.py    依赖：numpy
"""例 18.4：EM 收敛速率与缺失信息比例（不同遗传力）。"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import sys, numpy as np
sys.path.insert(0, os.path.join(HERE, 'ch18b'))
import core
np.set_printoptions(precision=6, suppress=True)

def solve_and_rate(h2, seed=20260418):
    sa2 = 100.0*h2; se2 = 100.0*(1-h2)
    D = core.prep(core.simulate(seed=seed, n_base=120, n_gen=3, per_gen=200, n_herd=3,
                                sa2=sa2, se2=se2, frac_rec=0.60)); core.prep_eig(D)
    th = np.array([sa2, se2])
    for _ in range(500):
        si = core.score_info(D, th[0], th[1]); thn = th + np.linalg.solve(si['IA'], si['s'])
        thn = np.maximum(thn, 1e-6)
        if np.max(np.abs(thn-th)/np.abs(th)) < 1e-14: th = thn; break
        th = thn
    SOL = th.copy(); siS = core.score_info(D, SOL[0], SOL[1])
    q, N = D['q'], D['N']
    Icom = np.diag([q/(2*SOL[0]**2), N/(2*SOL[1]**2)])
    DM = np.eye(2) - np.linalg.solve(Icom, siS['IO'])
    rate = max(abs(np.linalg.eigvals(DM)))
    Imis = Icom - siS['IO']
    # EM 实跑（起始 h2=0.10 的中庸值，总方差取 var(y)）
    vy = np.var(D['y'], ddof=1)
    st = np.array([10.0, 90.0]); thc = st.copy()
    nit = 0
    for t in range(1, 50001):
        a,e,_ = core.em_eig(D, thc[0], thc[1]); thn = np.array([a,e])
        rel = np.max(np.abs(thn-thc)/np.abs(thc)); thc = thn; nit = t
        if rel < 1e-8: break
    # AI 实跑
    thA = st.copy(); nai = 0
    for t in range(1, 300):
        si = core.score_info(D, thA[0], thA[1]); d = np.linalg.solve(si['IA'], si['s'])
        step = 1.0
        for _ in range(30):
            tn = thA + step*d
            if np.all(tn>1e-8) and core.mme_fast(D,tn[0],tn[1],want_inv=False)['lR'] >= si['lR']-1e-9: break
            step /= 2
        rel = np.max(np.abs(tn-thA)/np.abs(thA)); thA = tn; nai = t
        if rel < 1e-8: break
    pred = np.log(1e-8)/np.log(rate)
    return dict(h2=h2, D=D, SOL=SOL, rate=rate, Icom=Icom, Iobs=siS['IO'], Imis=Imis,
                nit=nit, nai=nai, pred=pred, start=st, h2hat=SOL[0]/SOL.sum(), vy=vy,
                frac_a=Imis[0,0]/Icom[0,0], frac_e=Imis[1,1]/Icom[1,1])

print('真 h² | 估计 h² |  σ̂a²    |  σ̂e²    | 缺失信息比例(a) | EM 速率 ρ | 预测迭代数 | 实测 EM | 实测 AI')
res = []
for h2 in [0.05, 0.10, 0.25, 0.50, 0.80]:
    r = solve_and_rate(h2); res.append(r)
    print('%5.2f | %7.4f | %8.4f | %8.4f | %15.6f | %9.6f | %10.0f | %7d | %7d'
          % (r['h2'], r['h2hat'], r['SOL'][0], r['SOL'][1], r['frac_a'], r['rate'], r['pred'], r['nit'], r['nai']))
print()
for r in res:
    print('h²=%.2f: I_com=diag(%.6f, %.6f)  I_obs=%s  I_mis=%s'
          % (r['h2'], r['Icom'][0,0], r['Icom'][1,1], r['Iobs'].ravel(), r['Imis'].ravel()))
    print('        起始值 = (%.4f, %.4f)  var(y)=%.4f' % (r['start'][0], r['start'][1], r['vy']))
