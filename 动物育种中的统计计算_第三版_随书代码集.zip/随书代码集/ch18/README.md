# 第十八章　REML 的数值算法 —— 配套代码

**所属**：第四篇　方差组分估计　　**对应正文**：第十八章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch18.ipynb` | IJulia 笔记本：11 个代码单元，约 343 行 Julia 代码，穿插与正文对应的说明 |
| `ch18.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 11 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　公共构件
- 2　EM‑REML（正文式 18.3、18.5）
- 3　二阶方法：得分、三种信息矩阵（正文 §18.3）
  - 3.1 三种二阶算法的统一实现
- 4　四种算法的收敛对照（正文 §18.1）
  - 4.1 遗传力对 EM 收敛速度的影响（正文式 18.6，思考题 8）
- 5　迹项：精确 vs Hutchinson 估计（正文 §18.4）
- 6　免费的正确性约束（正文式 18.17）
- 7　与 JWAS 的交叉验证（可选，需安装 JWAS）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 18
```

或在 Jupyter 中打开 `ch18/ch18.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 可选单元

- 开关 `RUN_JWAS`（默认 `false`）：JWAS 2.4（与 JWAS 的交叉验证单元）；需先实例化 `envs/jwas`：`julia --project=envs/jwas -e 'using Pkg; Pkg.instantiate()'`，再把笔记本中的开关改为 `true`。
- 开关关闭时只打印一行提示并跳过，不影响其余单元（见 `../README.md` 与正文附录 E）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
