# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s8_h2bias.py    依赖：numpy
"""错父率对半同胞法估计 h2 的影响：验证 (1-p)^2 规律；并度量记录的父子关系的真实期望。"""
import numpy as np
rng=np.random.default_rng(31415)
H2=0.30; NS=200; NPS=50          # 200 头公畜，每头 50 个后代
def sim(p,seed):
    r=np.random.default_rng(seed)
    s=r.normal(0,np.sqrt(H2/4),NS)                 # 公畜效应，var = h2/4 (sigma_P^2=1)
    sid=np.repeat(np.arange(NS),NPS)
    y=s[sid]+r.normal(0,np.sqrt(1-H2/4),NS*NPS)
    rec=sid.copy()
    m=r.random(NS*NPS)<p
    rec[m]=r.integers(0,NS,m.sum())
    # 单因子随机模型 ANOVA（平衡）
    out={}
    for nm,g in [("真实",sid),("记录",rec)]:
        df=np.bincount(g,minlength=NS)
        gm=np.bincount(g,weights=y,minlength=NS)/np.maximum(df,1)
        ybar=y.mean()
        SSB=np.sum(df*(gm-ybar)**2); SSW=np.sum((y-gm[g])**2)
        k=NS*NPS/NS
        # 不平衡时用 k0
        k0=(NS*NPS-np.sum(df**2)/(NS*NPS))/(NS-1)
        MSB=SSB/(NS-1); MSW=SSW/(NS*NPS-NS)
        s2s=(MSB-MSW)/k0
        out[nm]=4*s2s/(s2s+MSW)
    return out
print("半同胞方差分析估计 h2（真 h2 = %.2f，%d 头公畜×%d 后代，50 次重复）"%(H2,NS,NPS))
print("| 错父率 p | 记录系谱的 ĥ² | (1-p)² h² | 相对偏倚 |")
for p in [0.0,0.05,0.10,0.20,0.30]:
    v=[sim(p,1000+i)["记录"] for i in range(50)]
    m=np.mean(v); se=np.std(v,ddof=1)/np.sqrt(50)
    print("| %.0f%% | %.4f±%.4f | %.4f | %+.1f%% |"%(100*p,m,se,(1-p)**2*H2,100*(m-H2)/H2))
print()
# 记录父—后代的真实加性关系
print("记录的“父—后代”真实加性关系 a 的期望（错父者记为同期另一随机公畜、公畜间无亲缘）：")
for p in [0.0,0.05,0.10,0.20]:
    print("  p = %.0f%%  →  E[a] = (1-p)*0.5 = %.4f （模型仍按 0.5 使用，相对高估 %.1f%%）"%(
        100*p,(1-p)*0.5,100*(0.5-(1-p)*0.5)/((1-p)*0.5) if p<1 else float('nan')))
