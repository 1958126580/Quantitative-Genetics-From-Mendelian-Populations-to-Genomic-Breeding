# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s9b_ext.py    依赖：numpy
import os; HERE = os.path.dirname(os.path.abspath(__file__))
# -*- coding: utf-8 -*-
import sys; sys.path.insert(0,os.path.join(HERE, 'ch09b'))
import numpy as np
from ped import *
np.set_printoptions(linewidth=250,suppress=True)
A=buildA(); F=np.diag(A)-1; d=dvec(A); P=Pmat()
Ainv=(np.eye(N)-P).T@np.diag(1/d)@(np.eye(N)-P)
# ---- 显性关系矩阵 ----
Dd=np.zeros((N,N))
for x in range(N):
    for y in range(N):
        sx,dx,sy,dy=S[x]-1,Dm[x]-1,S[y]-1,Dm[y]-1
        Dd[x,y]=0.0 if min(sx,dx,sy,dy)<0 else 0.25*(A[sx,sy]*A[dx,dy]+A[sx,dy]*A[dx,sy])
    Dd[x,x]=1.0
print("=== D_d ===");print(md(Dd))
Ddi=np.linalg.inv(Dd)
print("nnz(D_d)=%d  nnz(D_d^{-1})=%d (%.0f%% of n^2)  nnz(A^{-1})=%d (%.0f%%)"%(
  int((np.abs(Dd)>1e-12).sum()),int((np.abs(Ddi)>1e-10).sum()),
  100*(np.abs(Ddi)>1e-10).sum()/N**2,int((np.abs(Ainv)>1e-12).sum()),100*(np.abs(Ainv)>1e-12).sum()/N**2))
ev=np.linalg.eigvalsh(Dd); print("D_d 特征值 [%.6f, %.6f]"%(ev[0],ev[-1]))
print("D_d[9,12]=%.6f  D_d[13,14]=%.6f  D_d[11,12]=%.6f  D_d[12,14]=%.6f"%(Dd[8,11],Dd[12,13],Dd[10,11],Dd[11,13]))
print("全同胞对 (5,6): a=%.4f  D_d=%.4f"%(A[4,5],Dd[4,5]))
print("半同胞对 (12,14) 共母 10: a=%.6f  D_d=%.6f"%(A[11,13],Dd[11,13]))
print()
# ---- 配子关系矩阵 ----
M=2*N; G=np.zeros((M,M))
for i in range(N):
    s,dd=S[i]-1,Dm[i]-1
    for g,par in ((2*i,s),(2*i+1,dd)):
        for k in range(g):
            G[g,k]=G[k,g]=(0.5*(G[2*par,k]+G[2*par+1,k]) if par>=0 else 0.0)
        G[g,g]=1.0
    if s>=0 and dd>=0:
        v=0.25*(G[2*s,2*dd]+G[2*s,2*dd+1]+G[2*s+1,2*dd]+G[2*s+1,2*dd+1])
    else: v=0.0
    G[2*i,2*i+1]=G[2*i+1,2*i]=v
K=np.zeros((N,M))
for i in range(N): K[i,2*i]=1; K[i,2*i+1]=1
print("=== 配子关系矩阵 ===")
print("维数 %dx%d ；max|A-0.5 K G_v K'| = %.3e"%(M,M,np.max(np.abs(A-0.5*K@G@K.T))))
print("max|g(i^p,i^m)-F_i| = %.3e"%np.max(np.abs(np.array([G[2*i,2*i+1] for i in range(N)])-F)))
print("G_v 最小特征值 %.6f ；秩 %d ；nnz = %d (%.0f%%)"%(np.linalg.eigvalsh(G)[0],np.linalg.matrix_rank(G),int((np.abs(G)>1e-12).sum()),100*(np.abs(G)>1e-12).sum()/M**2))
Gi=np.linalg.inv(G)
print("nnz(G_v^{-1}) = %d (%.0f%%)"%(int((np.abs(Gi)>1e-10).sum()),100*(np.abs(Gi)>1e-10).sum()/M**2))
lab=[]
for i in range(N): lab+= ["%d^p"%(i+1),"%d^m"%(i+1)]
sel=[2*8,2*8+1,2*10,2*10+1,2*14,2*14+1]
print("个体 9、11、15 的配子子块：")
print(md(G[np.ix_(sel,sel)],4,[lab[k] for k in sel]))
print()
# ---- X 染色体 ----
Phi=np.zeros((N,N))
for i in range(N):
    s,dd=S[i]-1,Dm[i]-1
    for j in range(i):
        if SEX[i]==1: Phi[i,j]=Phi[j,i]=(Phi[j,dd] if dd>=0 else 0.0)
        else: Phi[i,j]=Phi[j,i]=0.5*((Phi[j,s] if s>=0 else 0.0)+(Phi[j,dd] if dd>=0 else 0.0))
    Phi[i,i]=1.0 if SEX[i]==1 else 0.5*(1.0+(Phi[s,dd] if (s>=0 and dd>=0) else 0.0))
print("=== X 染色体共祖系数 Phi^X ===")
print("性别：", " ".join("%d=%s"%(i+1,"♂" if SEX[i] else "♀") for i in range(N)))
print(md(Phi,4))
print("母畜 X 近交系数 F^X = 2*Phi_ii-1：", {i+1:round(2*Phi[i,i]-1,6) for i in range(N) if SEX[i]==0})
print("常染色体 F 对照：", {i+1:round(F[i],6) for i in range(N) if SEX[i]==0})
print()
print("| 个体对 | 性别 | $f_{xy}=a_{xy}/2$ | $\\Phi^X_{xy}$ |")
for (x,y) in [(1,5),(1,7),(2,5),(5,9),(8,11),(11,13),(13,15),(9,11),(10,14),(12,14)]:
    print("| (%d,%d) | %s%s | %.6f | %.6f |"%(x,y,"♂" if SEX[x-1] else "♀","♂" if SEX[y-1] else "♀",0.5*A[x-1,y-1],Phi[x-1,y-1]))
print()
print("父—子（均为公）的 X 关系：")
for i in range(N):
    if S[i]>0 and SEX[i]==1 and SEX[S[i]-1]==1:
        print("  %d 与父 %d ：Phi^X=%.6f ， f=%.6f"%(i+1,S[i],Phi[i,S[i]-1],0.5*A[i,S[i]-1]))
