# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ped15.py    依赖：numpy
"""贯穿第九章的 15 头个体系谱：A、T、D、A^{-1} 及各种性质。"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import numpy as np
np.set_printoptions(linewidth=250, suppress=True)

# (id, sire, dam)  0 = 未知
PED = [(1,0,0),(2,0,0),(3,0,0),(4,0,0),
       (5,1,2),(6,1,2),(7,1,3),
       (8,4,5),(9,6,7),(10,5,0),
       (11,8,9),(12,9,10),
       (13,11,12),(14,8,12),(15,13,14)]
N=len(PED)
S=np.array([p[1] for p in PED]); Dm=np.array([p[2] for p in PED])

def buildA(S,Dm):
    n=len(S); A=np.zeros((n,n))
    for i in range(n):
        s,d=S[i]-1,Dm[i]-1
        for j in range(i):
            v=0.0
            if s>=0: v+=A[j,s]
            if d>=0: v+=A[j,d]
            A[i,j]=A[j,i]=0.5*v
        A[i,i]=1.0+(0.5*A[s,d] if (s>=0 and d>=0) else 0.0)
    return A

A=buildA(S,Dm)
Fv=np.diag(A)-1.0
print("=== F_i ===")
for i in range(N): print(f"  个体 {i+1:2d}  (s={S[i]},d={Dm[i]})  a_ii={A[i,i]:.6f}  F={Fv[i]:.6f}")
print()
print("=== A (4 位小数) ===")
print(np.round(A,4))
print()
# markdown 表
def md(A,dec=4):
    n=A.shape[0]
    head="| |"+"|".join(str(j+1) for j in range(n))+"|"
    sep="|:--:|"+"|".join(["--:"]*n)+"|"
    out=[head,sep]
    for i in range(n):
        out.append(f"|**{i+1}**|"+"|".join(f"{A[i,j]:.{dec}f}".rstrip('0').rstrip('.') if A[i,j]!=0 else "0" for j in range(n))+"|")
    return "\n".join(out)
print("=== A markdown ===")
print(md(A))
print()
# d_i and T
d=np.zeros(N)
for i in range(N):
    s,dd=S[i]-1,Dm[i]-1
    if s>=0 and dd>=0: d[i]=0.5-0.25*(Fv[s]+Fv[dd])
    elif s>=0: d[i]=0.75-0.25*Fv[s]
    elif dd>=0: d[i]=0.75-0.25*Fv[dd]
    else: d[i]=1.0
print("=== d_i ===")
for i in range(N): print(f"  个体 {i+1:2d}  d={d[i]:.8f}  1/d={1/d[i]:.8f}")
print()
P=np.zeros((N,N))
for i in range(N):
    if S[i]>0: P[i,S[i]-1]=0.5
    if Dm[i]>0: P[i,Dm[i]-1]=0.5
T=np.linalg.inv(np.eye(N)-P)
print("=== T (4 位小数) ===")
print(np.round(T,4))
print("=== T markdown ===")
print(md(T))
print()
Arec=T@np.diag(d)@T.T
print("TDT' 复原 A 的最大绝对误差 = %.3e"%np.max(np.abs(Arec-A)))
print("T 的非零元个数 = %d  (n^2=%d, 下三角含对角 %d)"%(np.sum(np.abs(T)>1e-14),N*N,N*(N+1)//2))
Tinv=np.eye(N)-P
print("T^{-1} 的非零元个数 = %d  (上界 3n = %d)"%(np.sum(np.abs(Tinv)>1e-14),3*N))
print()
Ainv=np.linalg.inv(A)
Ainv2=Tinv.T@np.diag(1/d)@Tinv
print("两种途径求 A^{-1} 的最大差 = %.3e"%np.max(np.abs(Ainv-Ainv2)))
print("||A A^{-1} - I||_max = %.3e"%np.max(np.abs(A@Ainv2-np.eye(N))))
nz=np.sum(np.abs(Ainv2)>1e-12)
print("A^{-1} 结构非零元 = %d ; 9n = %d ; 7n = %d ; n^2 = %d ; 稠密度 = %.1f%%"%(nz,9*N,7*N,N*N,100*nz/N**2))
# 7n 界的分项
e=sum(1 for i in range(N) if S[i]>0)+sum(1 for i in range(N) if Dm[i]>0)
pairs=set((S[i],Dm[i]) for i in range(N) if S[i]>0 and Dm[i]>0)
print("  亲子连线数 e = %d ; 不同配对数 m = %d ; n+2e+2m = %d"%(e,len(pairs),N+2*e+2*len(pairs)))
print()
print("=== A^{-1} markdown (4位小数) ===")
print(md(Ainv2))
print()
ev=np.linalg.eigvalsh(A)
print("=== A 的特征值 ===")
print(np.round(ev,6))
print("lambda_min = %.8f   lambda_max = %.8f   条件数 = %.4f"%(ev[0],ev[-1],ev[-1]/ev[0]))
print("tr(A) = %.6f = n + sum F = %.6f"%(np.trace(A),N+Fv.sum()))
print("tr(A)/n = %.6f (= 1+Fbar) ; lambda_max >= tr/n : %s"%(np.trace(A)/N, ev[-1]>=np.trace(A)/N))
print("||A||_inf = max row sum = %.6f  >= lambda_max : %s"%(np.abs(A).sum(1).max(), np.abs(A).sum(1).max()>=ev[-1]))
cmax=max(max((S==j).sum()+(Dm==j).sum() for j in range(1,N+1)),0)
print("最大子女数 c_max = %d ; min d_i = %.6f ; 下界 min_d/(2+c_max) = %.8f <= lambda_min : %s"%(
    cmax,d.min(),d.min()/(2+cmax), d.min()/(2+cmax)<=ev[0]))
print()
one=np.ones(N)
r=Ainv2@one
print("=== A^{-1} 1 ===")
for i in range(N): print(f"  j={i+1:2d}  (A^-1 1)_j = {r[i]:+.8f}")
print("1'A^{-1}1 = %.8f"%(one@r))
n0=sum(1 for i in range(N) if S[i]==0 and Dm[i]==0)
n1=sum(1 for i in range(N) if (S[i]==0)!=(Dm[i]==0))
print("基础群个体数 n0 = %d ; 单亲未知个体数 n1 = %d"%(n0,n1))
# 公式核对
g=np.array([1.0-0.5*(S[i]>0)-0.5*(Dm[i]>0) for i in range(N)])
pred=np.zeros(N)
for j in range(N):
    pred[j]=g[j]/d[j]
    for i in range(N):
        if S[i]==j+1 or Dm[i]==j+1: pred[j]-=0.5*g[i]/d[i]
print("公式预测与实测最大差 = %.3e"%np.max(np.abs(pred-r)))
np.save(os.path.join(HERE, 'A15.npy'),A)
