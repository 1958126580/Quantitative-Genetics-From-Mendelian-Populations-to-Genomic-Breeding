# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_jacquard.py    依赖：numpy
"""Jacquard 9 condensed identity states: exact single-locus covariance for inbred relatives."""
import numpy as np, itertools
rng = np.random.default_rng(20260923)

STATES = {1:[[0,1,2,3]],2:[[0,1],[2,3]],3:[[0,1,2],[3]],4:[[0,1],[2],[3]],
          5:[[0,2,3],[1]],6:[[2,3],[0],[1]],7:[[0,2],[1,3]],8:[[0,2],[1],[3]],
          9:[[0],[1],[2],[3]]}

def base_params(p, G):
    mu = float(p @ G @ p)
    alpha = G @ p - mu
    sigA2 = 2.0*float(np.sum(p*alpha**2))
    dl = G - mu - alpha[:,None] - alpha[None,:]
    sigD2 = float(np.sum(np.outer(p,p)*dl**2))
    dii = np.diag(dl).copy()
    dbar = float(p@dii)
    H  = -dbar                                     # 近交衰退（每单位 F）
    D1 = float(np.sum(p*alpha*dii))                # cov(alpha, delta_aa)
    D2 = float(np.sum(p*(dii-dbar)**2))            # var(delta_aa)
    muI = float(p@np.diag(G))
    return dict(mu=mu,muI=muI,sigA2=sigA2,sigD2=sigD2,H=H,D1=D1,D2=D2)

def EGxGy(p,G,parts):
    k=len(p); lab=[0]*4
    for ci,cl in enumerate(parts):
        for s in cl: lab[s]=ci
    tot=0.0
    for types in itertools.product(range(k),repeat=len(parts)):
        pr=1.0
        for t in types: pr*=p[t]
        tot+=pr*G[types[lab[0]],types[lab[1]]]*G[types[lab[2]],types[lab[3]]]
    return tot

def theta(D): return D[1]+0.5*(D[3]+D[5]+D[7])+0.25*D[8]

maxres=0.0; rows=[]
for trial in range(500):
    k=int(rng.integers(2,6))
    p=rng.dirichlet(np.ones(k)*1.5)
    G=rng.normal(size=(k,k)); G=(G+G.T)/2
    dv=rng.dirichlet(np.ones(9)*0.8); D={i+1:dv[i] for i in range(9)}
    bp=base_params(p,G)
    Fx=D[1]+D[2]+D[3]+D[4]; Fy=D[1]+D[2]+D[5]+D[6]
    exact=sum(D[s]*EGxGy(p,G,STATES[s]) for s in range(1,10))-(bp['mu']-bp['H']*Fx)*(bp['mu']-bp['H']*Fy)
    form=(2*theta(D)*bp['sigA2'] + D[7]*bp['sigD2']
          + (4*D[1]+D[3]+D[5])*bp['D1'] + D[1]*bp['D2']
          + (D[1]+D[2]-Fx*Fy)*bp['H']**2)
    maxres=max(maxres,abs(exact-form))
print("公式验证：500 个随机位点/随机 Delta 向量，|精确-公式| 最大 =", f"{maxres:.3e}")

# 非近交特例还原为式 (9.1) 的 A+D 部分
tests={"亲子":{8:1.0},"全同胞":{7:0.25,8:0.5,9:0.25},"半同胞":{8:0.5,9:0.5},
       "同一个体":{7:1.0},"一代堂表亲":{8:0.25,9:0.75}}
print()
print("非近交关系的 Delta_7 / Delta_8 与 r,u：")
for nm,dd in tests.items():
    D={i:0.0 for i in range(1,10)}; D.update(dd)
    print(f"  {nm:10s} D7={D[7]:.4f} D8={D[8]:.4f} D9={D[9]:.4f}  2*theta={2*theta(D):.4f}  u=D7={D[7]:.4f}")

# 全同胞近交算例：双亲为全同胞（F_parent=0）→ 子代 F=0.25；两个这样的全同胞子代
# 用 Karigl 递推精确算 9 个系数太长，这里用一个可解析的经典例：x,y 为双亲完全近交(F=1)的全同胞
print()
print("数值算例：一个位点 p=(0.6,0.4)，G_11=1, G_12=d, G_22=-1（完全显性 d=1）")
p=np.array([0.6,0.4]); a=1.0; d=1.0
G=np.array([[a,d],[d,-a]])
bp=base_params(p,G)
print("  sigA2=%.6f sigD2=%.6f H=%.6f D1*=%.6f D2*=%.6f"%(bp['sigA2'],bp['sigD2'],bp['H'],bp['D1'],bp['D2']))
print("  mu=%.6f  muI=%.6f"%(bp['mu'],bp['muI']))
# 非近交全同胞
D={i:0.0 for i in range(1,10)}; D[7]=0.25; D[8]=0.5; D[9]=0.25
Fx=Fy=0.0
cov0=(2*theta(D)*bp['sigA2']+D[7]*bp['sigD2']+(4*D[1]+D[3]+D[5])*bp['D1']+D[1]*bp['D2']+(D[1]+D[2]-Fx*Fy)*bp['H']**2)
print("  非近交全同胞 Cov = %.6f  ( =0.5 sigA2 + 0.25 sigD2 = %.6f )"%(cov0,0.5*bp['sigA2']+0.25*bp['sigD2']))
