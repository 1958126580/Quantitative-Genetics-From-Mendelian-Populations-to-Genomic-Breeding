# 第 9 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch09/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `ped15.py` | 贯穿第九章的 15 头个体系谱：A、T、D、A^{-1} 及各种性质。 | numpy | 0.8 | `outputs/ped15.out` |
| `s10_misc.py` | ---------- 1. 大系谱上 A^{-1} 与 D_d^{-1} 的稀疏性对照 ---------- | numpy | 12.9 | `outputs/s10_misc.out` |
| `s11_cenv.py` | 共同环境与遗传混杂的定量分析。 | numpy | 0.8 | `outputs/s11_cenv.out` |
| `s12_bounds.py` | 1) 连续自交（或连续全同胞交配）链上 F 的增长与界 1-2^{-g} | numpy | 4.4 | `outputs/s12_bounds.out` |
| `s1_cockerham.py` | Cockerham decomposition coefficients r^k u^l for common relative pairs. | 标准库 | 0.2 | `outputs/s1_cockerham.out` |
| `s2_jacquard.py` | Jacquard 9 condensed identity states: exact single-locus covariance for inbred relatives. | numpy | 2.4 | `outputs/s2_jacquard.out` |
| `s3_delta9.py` | 精确枚举基因传递，求近交系谱上任意个体对的 9 个凝聚系数 Delta_1..Delta_9。 | numpy | 0.5 | `outputs/s3_delta9.out` |
| `s4_groups.py` | 遗传分组：Q 矩阵、Quaas–Pollak 增广 A^{-1} 的等价性验证与数值算例。 | numpy | 0.6 | `outputs/s4_groups.out` |
| `s4b_groups.py` | 数值复核 | numpy | 0.6 | `outputs/s4b_groups.out` |
| `s5_grouptrend.py` | 遗传分组的定量效果：外来个体有遗传趋势时，不分组 / 分组模型的 EBV 偏倚对照。 | numpy, scipy | 15.8 | `outputs/s5_grouptrend.out` |
| `s8_h2bias.py` | 错父率对半同胞法估计 h2 的影响：验证 (1-p)^2 规律；并度量记录的父子关系的真实期望。 | numpy | 3.2 | `outputs/s8_h2bias.out` |
| `s9_ext.py` | 显性关系矩阵、配子关系矩阵、X 染色体关系矩阵（15 头算例）。 | numpy | 1.1 | `outputs/s9_ext.out` |
| `s9b_ext.py` | ---- 显性关系矩阵 ---- | numpy | 1.0 | `outputs/s9b_ext.out` |

公共函数模块（被上列脚本导入，不单独运行）：`ped.py`。
