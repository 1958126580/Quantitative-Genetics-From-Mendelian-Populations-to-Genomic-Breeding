# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4_groups.py    依赖：numpy
"""遗传分组：Q 矩阵、Quaas–Pollak 增广 A^{-1} 的等价性验证与数值算例。"""
import numpy as np
np.set_printoptions(linewidth=200, suppress=True)
PED=[(1,0,0),(2,0,0),(3,0,0),(4,0,0),(5,1,2),(6,1,2),(7,1,3),(8,4,5),(9,6,7),
     (10,5,0),(11,8,9),(12,9,10),(13,11,12),(14,8,12),(15,13,14)]
N=len(PED); S=np.array([p[1] for p in PED]); Dm=np.array([p[2] for p in PED])
# 未知亲本的分组：g1(本地老基础群)=1, g2(引进)=2
# 个体 1,2,3 双亲未知 -> g1 ; 个体 4 双亲未知 -> g2 ; 个体 10 母未知 -> g2
GRPS=2
GS={1:(1,1),2:(1,1),3:(1,1),4:(2,2),10:(None,2)}   # (父所属组,母所属组)，None 表示该亲本已知
def buildA(S,Dm):
    n=len(S);A=np.zeros((n,n))
    for i in range(n):
        s,d=S[i]-1,Dm[i]-1
        for j in range(i):
            v=(A[j,s] if s>=0 else 0)+(A[j,d] if d>=0 else 0); A[i,j]=A[j,i]=0.5*v
        A[i,i]=1+(0.5*A[s,d] if (s>=0 and d>=0) else 0)
    return A
A=buildA(S,Dm); Fv=np.diag(A)-1
d=np.empty(N)
for i in range(N):
    s,dd=S[i]-1,Dm[i]-1
    if s>=0 and dd>=0: d[i]=0.5-0.25*(Fv[s]+Fv[dd])
    elif s>=0: d[i]=0.75-0.25*Fv[s]
    elif dd>=0: d[i]=0.75-0.25*Fv[dd]
    else: d[i]=1.0
P=np.zeros((N,N))
for i in range(N):
    if S[i]>0: P[i,S[i]-1]=.5
    if Dm[i]>0: P[i,Dm[i]-1]=.5
Ainv=(np.eye(N)-P).T@np.diag(1/d)@(np.eye(N)-P)
# Q0 与 Q
Q0=np.zeros((N,GRPS))
for i in range(N):
    idx=i+1
    if idx in GS:
        gs,gd=GS[idx]
        if S[i]==0 and gs: Q0[i,gs-1]+=0.5
        if Dm[i]==0 and gd: Q0[i,gd-1]+=0.5
T=np.linalg.inv(np.eye(N)-P)
Q=T@Q0
print("=== Q 矩阵（每个个体来自各组的基因比例）===")
print("| 个体 | q_g1 | q_g2 | 合计 |")
for i in range(N):
    print(f"| {i+1} | {Q[i,0]:.4f} | {Q[i,1]:.4f} | {Q[i].sum():.4f} |")
print("行和是否全为 1：", np.allclose(Q.sum(1),1))
print()
# 增广 A^{-1}：组在前
M=GRPS+N
Pt=np.zeros((M,M))
for i in range(N):
    r=GRPS+i
    if S[i]>0: Pt[r,GRPS+S[i]-1]=.5
    else:
        gs=GS[i+1][0]
        if gs: Pt[r,gs-1]+=.5
    if Dm[i]>0: Pt[r,GRPS+Dm[i]-1]=.5
    else:
        gd=GS[i+1][1]
        if gd: Pt[r,gd-1]+=.5
Dinv=np.zeros(M); Dinv[GRPS:]=1/d
Astar=(np.eye(M)-Pt).T@np.diag(Dinv)@(np.eye(M)-Pt)
blk=np.block([[Q.T@Ainv@Q, -Q.T@Ainv],[-Ainv@Q, Ainv]])
print("=== Quaas–Pollak 等价性 ===")
print("max|增广规则 A_*^{-1} - [[Q'A^{-1}Q, -Q'A^{-1}],[-A^{-1}Q, A^{-1}]]| = %.3e"%np.max(np.abs(Astar-blk)))
print("Q'A^{-1}Q =")
print(np.round(Q.T@Ainv@Q,6))
print("增广 A_*^{-1} 左上 2x2 块 =")
print(np.round(Astar[:GRPS,:GRPS],6))
print("增广矩阵非零元 = %d ; 原 A^{-1} 非零元 = %d ; 增广维数 %d"%(
   np.sum(np.abs(Astar)>1e-12), np.sum(np.abs(Ainv)>1e-12), M))
print("A_*^{-1} 的行和（应为 0）最大绝对值 = %.3e"%np.max(np.abs(Astar@np.ones(M))))
print()
# 数值 BLUP 算例
rng=np.random.default_rng(7)
h2=0.25; lam=(1-h2)/h2
# 真值：g1 组均值 0，g2 组均值 +2（引进公畜遗传水平高）
gtrue=np.array([0.0,2.0])
mtrue=Q@gtrue
u=np.zeros(N)
for i in range(N):
    s,dd=S[i]-1,Dm[i]-1
    pm=0.0
    if s>=0: pm+=0.5*(u[s])
    if dd>=0: pm+=0.5*(u[dd])
    u[i]=pm+np.sqrt(d[i])*rng.normal()
utot=mtrue+u
rec=list(range(4,15))    # 个体 5..15 有记录
ny=len(rec)
y=np.array([10.0+utot[i]+np.sqrt(1-h2)/np.sqrt(h2)*0*0+rng.normal(0,np.sqrt((1-h2)/h2*1.0)) for i in rec])
X=np.ones((ny,1)); Z=np.zeros((ny,N))
for k,i in enumerate(rec): Z[k,i]=1
# 模型一：不分组
C1=np.block([[X.T@X, X.T@Z],[Z.T@X, Z.T@Z+Ainv*lam]])
r1=np.concatenate([X.T@y, Z.T@y])
sol1=np.linalg.solve(C1+1e-10*np.eye(C1.shape[0]), r1)
eb1=sol1[1:]
# 模型二：分组（Quaas–Pollak）
Zt=np.hstack([np.zeros((ny,GRPS)),Z])
C2=np.block([[X.T@X, X.T@Zt],[Zt.T@X, Zt.T@Zt+Astar*lam]])
r2=np.concatenate([X.T@y, Zt.T@y])
sol2=np.linalg.lstsq(C2,r2,rcond=None)[0]
ghat=sol2[1:1+GRPS]; eb2=sol2[1+GRPS:]
print("=== BLUP 数值算例（h2=0.25, lambda=%.1f, 11 条记录）==="%lam)
print("真实组效应 g=(0, 2)；估计 g_hat =",np.round(ghat,4)," 组间差 = %.4f"%(ghat[1]-ghat[0]))
print("| 个体 | 真实总育种值 | 不分组 EBV | 分组 EBV |")
for i in range(N):
    print(f"| {i+1} | {utot[i]:+.4f} | {eb1[i]:+.4f} | {eb2[i]:+.4f} |")
c1=np.corrcoef(eb1,utot)[0,1]; c2=np.corrcoef(eb2,utot)[0,1]
print("与真值的相关：不分组 %.4f ；分组 %.4f"%(c1,c2))
b1=np.polyfit(eb1,utot,1)[0]; b2=np.polyfit(eb2,utot,1)[0]
print("真值对 EBV 的回归斜率：不分组 %.4f ；分组 %.4f （理想为 1）"%(b1,b2))
