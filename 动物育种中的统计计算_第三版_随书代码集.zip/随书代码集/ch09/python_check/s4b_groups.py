# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4b_groups.py    依赖：numpy
import os; HERE = os.path.dirname(os.path.abspath(__file__))
# -*- coding: utf-8 -*-
import sys; sys.path.insert(0,os.path.join(HERE, 'ch09b'))
import numpy as np
from ped import *
np.set_printoptions(linewidth=200,suppress=True)
A=buildA(); d=dvec(A); P=Pmat(); T=np.linalg.inv(np.eye(N)-P)
Ainv=(np.eye(N)-P).T@np.diag(1/d)@(np.eye(N)-P)
GRPS=2
GS={1:(1,1),2:(1,1),3:(1,1),4:(2,2),10:(None,2)}
Q0=np.zeros((N,GRPS))
for i in range(N):
    k=i+1
    if k in GS:
        gs,gd=GS[k]
        if S[i]==0 and gs: Q0[i,gs-1]+=0.5
        if Dm[i]==0 and gd: Q0[i,gd-1]+=0.5
Q=T@Q0
print("=== Q ===")
print("| 个体 | $q_{i1}$ | $q_{i2}$ |")
for i in range(N): print("| %d | %.4f | %.4f |"%(i+1,Q[i,0],Q[i,1]))
print("行和全为 1 :",np.allclose(Q.sum(1),1))
M=GRPS+N; Pt=np.zeros((M,M))
for i in range(N):
    r=GRPS+i
    if S[i]>0: Pt[r,GRPS+S[i]-1]+=.5
    elif GS.get(i+1,(None,None))[0]: Pt[r,GS[i+1][0]-1]+=.5
    if Dm[i]>0: Pt[r,GRPS+Dm[i]-1]+=.5
    elif GS.get(i+1,(None,None))[1]: Pt[r,GS[i+1][1]-1]+=.5
Dinv=np.zeros(M); Dinv[GRPS:]=1/d
Astar=(np.eye(M)-Pt).T@np.diag(Dinv)@(np.eye(M)-Pt)
blk=np.block([[Q.T@Ainv@Q,-Q.T@Ainv],[-Ainv@Q,Ainv]])
print("max|增广规则 - 分块公式| = %.3e"%np.max(np.abs(Astar-blk)))
print("Q'A^{-1}Q =\n",np.round(Q.T@Ainv@Q,8))
print("A_*^{-1} 行和最大绝对值 = %.3e"%np.max(np.abs(Astar@np.ones(M))))
print("nnz(A_*^{-1}) = %d ; nnz(A^{-1}) = %d ; 维数 %d"%(int(np.sum(np.abs(Astar)>1e-12)),int(np.sum(np.abs(Ainv)>1e-12)),M))
print("左上 2x2 与 -Q'A^{-1} 的前 6 列：")
print(np.round(Astar[:2,:8],6))
print("1'A^{-1}1 = %.8f ；= 组块元素之和 %.8f"%(np.ones(N)@Ainv@np.ones(N),(Q.T@Ainv@Q).sum()))
