# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s10_misc.py    依赖：numpy
import os; HERE = os.path.dirname(os.path.abspath(__file__))
# -*- coding: utf-8 -*-
import sys; sys.path.insert(0,os.path.join(HERE, 'ch09b'))
import numpy as np, time
from ped import *
np.set_printoptions(linewidth=220,suppress=True)

# ---------- 1. 大系谱上 A^{-1} 与 D_d^{-1} 的稀疏性对照 ----------
def sim(n,nbase,nsire,seed=11):
    r=np.random.default_rng(seed)
    s=np.zeros(n,dtype=int);dd=np.zeros(n,dtype=int)
    cur=np.arange(nbase);i=nbase
    while i<n:
        k=min(200,n-i)
        sires=r.choice(cur,min(nsire,len(cur)),replace=False)
        dams=r.choice(cur,min(len(cur),100),replace=False)
        for j in range(k):
            a=int(r.choice(sires));b=int(r.choice(dams))
            while b==a: b=int(r.choice(dams))
            s[i+j]=a+1;dd[i+j]=b+1
        cur=np.arange(i,i+k);i+=k
    return s,dd
for n,nb,ns in [(200,40,8),(500,60,10),(1000,80,12)]:
    s,dm=sim(n,nb,ns)
    A=buildA(s,dm); d=dvec(A,s,dm); P=Pmat(s,dm)
    Ai=(np.eye(n)-P).T@np.diag(1/d)@(np.eye(n)-P)
    Dd=np.eye(n)
    for x in range(n):
        for y in range(x):
            sx,dx,sy,dy=s[x]-1,dm[x]-1,s[y]-1,dm[y]-1
            Dd[x,y]=Dd[y,x]=0.0 if min(sx,dx,sy,dy)<0 else 0.25*(A[sx,sy]*A[dx,dy]+A[sx,dy]*A[dx,sy])
    Ddi=np.linalg.inv(Dd)
    print("n=%4d : nnz(A^{-1})=%6d (%.2f n, %.1f%%)   nnz(D_d^{-1})=%7d (%.1f%% of n^2)"%(
        n,int((np.abs(Ai)>1e-12).sum()),(np.abs(Ai)>1e-12).sum()/n,100*(np.abs(Ai)>1e-12).sum()/n**2,
        int((np.abs(Ddi)>1e-10).sum()),100*(np.abs(Ddi)>1e-10).sum()/n**2))
print()
# ---------- 2. 三个概念在近交个体上的数值对照（15 头算例）----------
A=buildA(); F=np.diag(A)-1
print("=== 三个概念的数值对照（贯穿算例）===")
print("| 个体对 | 关系 | $F_x$ | $F_y$ | $f_{xy}$ | $a_{xy}$ | $r_{xy}$ | $a_{xy}-r_{xy}$ |")
pairs=[(5,6,"全同胞（均非近交）"),(9,11,"母—子"),(11,13,"父—子"),(13,14,"配偶（半同胞）"),
       (13,15,"父—子"),(14,15,"母—子"),(12,13,"母—子"),(11,15,"祖—孙"),(12,14,"母系半同胞")]
for x,y,nm in pairs:
    a=A[x-1,y-1]; r=a/np.sqrt(A[x-1,x-1]*A[y-1,y-1])
    print("| (%d,%d) | %s | %.6f | %.6f | %.6f | %.6f | %.6f | %+.6f |"%(
        x,y,nm,F[x-1],F[y-1],a/2,a,r,a-r))
print()
# ---------- 3. 7 头算例的完整验算 ----------
S7=np.array([0,0,1,1,3,1,5]); D7=np.array([0,0,0,2,4,4,6])
A7=buildA(S7,D7); F7=np.diag(A7)-1; d7=dvec(A7,S7,D7); P7=Pmat(S7,D7)
T7=np.linalg.inv(np.eye(7)-P7)
Ai7=(np.eye(7)-P7).T@np.diag(1/d7)@(np.eye(7)-P7)
print("=== 7 头算例 ===")
print("F =",np.round(F7,6))
print("d =",np.round(d7,8),"  1/d =",np.round(1/d7,8))
print("T ="); print(md(T7,5,[str(i+1) for i in range(7)]))
print("A ="); print(md(A7,5,[str(i+1) for i in range(7)]))
print("A^{-1} ="); print(md(Ai7,5,[str(i+1) for i in range(7)]))
print("max|TDT'-A| = %.3e"%np.max(np.abs(T7@np.diag(d7)@T7.T-A7)))
print("||A A^{-1}-I||max = %.3e"%np.max(np.abs(A7@Ai7-np.eye(7))))
print("nnz(A^{-1}) = %d ; 9n=%d ; n+2e+2m = %d"%(int((np.abs(Ai7)>1e-12).sum()),63,
    7+2*(int((S7>0).sum())+int((D7>0).sum()))+2*len(set((S7[i],D7[i]) for i in range(7) if S7[i]>0 and D7[i]>0))))
print("A^{-1}1 =",np.round(Ai7@np.ones(7),8),"  1'A^{-1}1 = %.8f"%(np.ones(7)@Ai7@np.ones(7)))
L=np.linalg.cholesky(A7)
print("Cholesky 对角元 l_ii =",np.round(np.diag(L),8))
print("l_ii^2 =",np.round(np.diag(L)**2,8),"  与 d_i 的最大差 = %.3e"%np.max(np.abs(np.diag(L)**2-d7)))
print("max|L - T D^{1/2}| = %.3e"%np.max(np.abs(L-T7@np.diag(np.sqrt(d7)))))
ev7=np.linalg.eigvalsh(A7)
print("特征值：",np.round(ev7,6)," lmin=%.8f lmax=%.8f cond=%.4f"%(ev7[0],ev7[-1],ev7[-1]/ev7[0]))
print("tr(A)=%.6f  ||A||inf=%.6f  1'A1/n=%.6f"%(np.trace(A7),np.abs(A7).sum(1).max(),np.ones(7)@A7@np.ones(7)/7))
cmax=max(int((S7==j).sum()+(D7==j).sum()) for j in range(1,8))
print("cmax=%d mind=%.8f 下界=%.8f"%(cmax,d7.min(),d7.min()/(2+cmax)))
# A^{-1} 的分数形式
from fractions import Fraction as Fr
print("A^{-1} 的分数形式：")
for i in range(7):
    print("  行%d: "%(i+1)+"  ".join(str(Fr(Ai7[i,j]).limit_denominator(10000)) for j in range(7)))
