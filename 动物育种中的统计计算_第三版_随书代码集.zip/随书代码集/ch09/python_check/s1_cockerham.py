# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_cockerham.py    依赖：仅标准库
"""Cockerham decomposition coefficients r^k u^l for common relative pairs."""
from fractions import Fraction as F

# (name, r, u)
rels = [
    ("同一个体 / 同卵双生", F(1),   F(1)),
    ("亲子",               F(1,2), F(0)),
    ("全同胞",             F(1,2), F(1,4)),
    ("半同胞",             F(1,4), F(0)),
    ("祖孙",               F(1,4), F(0)),
    ("叔侄（全同胞叔）",   F(1,4), F(0)),
    ("一代堂表亲",         F(1,8), F(0)),
    ("双重一代堂表亲",     F(1,4), F(1,16)),
    ("曾祖孙",             F(1,8), F(0)),
]

comps = [("A","r",1,0), ("D","u",0,1), ("AA","r^2",2,0), ("AD","ru",1,1),
         ("DD","u^2",0,2), ("AAA","r^3",3,0), ("AAD","r^2 u",2,1), ("ADD","r u^2",1,2)]

def fs(x):
    if x == 0: return "0"
    if x.denominator == 1: return str(x.numerator)
    return f"{x.numerator}/{x.denominator}"

hdr = ["关系"] + [c[0] for c in comps]
print(" | ".join(hdr))
rows = []
for name, r, u in rels:
    row = [name]
    for nm, expr, k, l in comps:
        v = r**k * u**l
        row.append(fs(v))
    rows.append(row)
    print(" | ".join(row))

print()
print("--- decimal values ---")
for name, r, u in rels:
    vals = [float(r**k * u**l) for nm,expr,k,l in comps]
    print(f"{name:22s} " + " ".join(f"{v:9.6f}" for v in vals))

print()
print("--- 数值算例：sigA2=40, sigD2=20, sigAA2=10, sigAD2=6, sigDD2=4 ---")
sA,sD,sAA,sAD,sDD = 40.0,20.0,10.0,6.0,4.0
print("关系 | A项 | D项 | AA项 | AD项 | DD项 | 合计 | 只算A项的相对误差%")
for name, r, u in rels:
    tA=float(r)*sA; tD=float(u)*sD; tAA=float(r**2)*sAA; tAD=float(r*u)*sAD; tDD=float(u**2)*sDD
    tot=tA+tD+tAA+tAD+tDD
    print(f"{name:22s} {tA:7.4f} {tD:7.4f} {tAA:7.4f} {tAD:7.4f} {tDD:7.4f} {tot:8.4f} {100*(tot-tA)/tot:7.3f}")

print()
print("--- 半同胞法与全同胞法估计 h2 的偏倚 ---")
# 表型方差 sigP2
sigP = sA+sD+sAA+sAD+sDD+30.0   # 加环境 30
print("sigP2 =", sigP, " 真 h2 =", sA/sigP)
r,u=F(1,4),F(0)
covHS = float(r)*sA+float(u)*sD+float(r**2)*sAA+float(r*u)*sAD+float(u**2)*sDD
r,u=F(1,2),F(1,4)
covFS = float(r)*sA+float(u)*sD+float(r**2)*sAA+float(r*u)*sAD+float(u**2)*sDD
r,u=F(1,2),F(0)
covPO = float(r)*sA+float(u)*sD+float(r**2)*sAA+float(r*u)*sAD+float(u**2)*sDD
h2=sA/sigP
for nm,cov,mult in [("半同胞 4t",covHS,4),("全同胞 2t",covFS,2),("亲子回归 2b",covPO,2)]:
    est = mult*cov/sigP
    print(f"{nm:12s} cov={cov:8.4f} t={cov/sigP:8.5f} 估计h2={est:8.5f} 偏倚={est-h2:+8.5f} 相对偏倚={100*(est-h2)/h2:+7.3f}%")
