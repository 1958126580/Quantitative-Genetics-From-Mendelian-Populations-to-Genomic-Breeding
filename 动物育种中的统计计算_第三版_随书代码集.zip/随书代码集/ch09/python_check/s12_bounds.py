# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s12_bounds.py    依赖：numpy
import os; HERE = os.path.dirname(os.path.abspath(__file__))
# -*- coding: utf-8 -*-
import sys; sys.path.insert(0,os.path.join(HERE, 'ch09b'))
import numpy as np
from ped import buildA,dvec,Pmat
# 1) 连续自交（或连续全同胞交配）链上 F 的增长与界 1-2^{-g}
print("=== 连续自交链：F_i 与界 1-2^{-g} ===")
n=12; S=np.zeros(n,dtype=int); D=np.zeros(n,dtype=int)
for i in range(1,n): S[i]=i; D[i]=i        # 个体 i+1 由个体 i 自交
A=buildA(S,D); F=np.diag(A)-1; d=dvec(A,S,D)
print("| 世代 g | $F$ | 界 $1-2^{-g}$ | $d_i$ | $2^{-(g+1)}$ |")
for i in range(n):
    print("| %d | %.8f | %.8f | %.8f | %.8f |"%(i,F[i],1-2.0**(-i),d[i],2.0**(-(i+1))))
print("A 正定？最小特征值 = %.3e"%np.linalg.eigvalsh(A)[0])
print()
print("=== 连续全同胞交配链 ===")
n=14; S=np.zeros(n,dtype=int);D=np.zeros(n,dtype=int)
S[2]=1;D[2]=2; S[3]=1;D[3]=2
k=4
while k<n-1:
    S[k]=k-1; D[k]=k       # k+1 与 k+2 的双亲是 k-1,k ...
    S[k+1]=k-1; D[k+1]=k
    k+=2
A2=buildA(S,D); F2=np.diag(A2)-1
print("全同胞连续交配的 F：",np.round(F2,6))
print("理论极限 F->1；最小特征值 = %.3e"%np.linalg.eigvalsh(A2)[0])
print()
# 2) 特征值界在较大模拟系谱上的紧度
def sim(n,nbase,nsire,seed=5):
    r=np.random.default_rng(seed); s=np.zeros(n,dtype=int);dd=np.zeros(n,dtype=int)
    cur=np.arange(nbase); i=nbase
    while i<n:
        k=min(100,n-i)
        si=r.choice(cur,min(nsire,len(cur)),replace=False); da=r.choice(cur,min(len(cur),60),replace=False)
        for j in range(k):
            a=int(r.choice(si)); b=int(r.choice(da))
            while b==a: b=int(r.choice(da))
            s[i+j]=a+1; dd[i+j]=b+1
        cur=np.arange(i,i+k); i+=k
    return s,dd
print("=== 特征值界的紧度 ===")
print("| n | $\\lambda_{\\min}$ | 下界 $\\min d_i/(2+c_{\\max})$ | $\\lambda_{\\max}$ | $\\mathbf1'\\mathbf A\\mathbf1/n$ | $\\|\\mathbf A\\|_\\infty$ | 条件数 |")
for n,nb,ns in [(200,40,8),(500,60,10),(1000,80,12)]:
    s,dm=sim(n,nb,ns); A=buildA(s,dm); d=dvec(A,s,dm)
    ev=np.linalg.eigvalsh(A); cmax=max(int((s==j).sum()+(dm==j).sum()) for j in range(1,n+1))
    lo=d.min()/(2+cmax); one=np.ones(n)
    print("| %d | %.6f | %.6f | %.4f | %.4f | %.4f | %.1f |"%(n,ev[0],lo,ev[-1],one@A@one/n,np.abs(A).sum(1).max(),ev[-1]/ev[0]))
