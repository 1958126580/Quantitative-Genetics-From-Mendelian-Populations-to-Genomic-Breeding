# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_delta9.py    依赖：numpy
"""精确枚举基因传递，求近交系谱上任意个体对的 9 个凝聚系数 Delta_1..Delta_9。"""
import itertools, numpy as np
from fractions import Fraction as Fr

def condensed(ped, x, y):
    """ped: dict id -> (sire, dam) or None for founder. 返回 Delta_1..9 (Fraction)."""
    founders=[i for i in ped if ped[i] is None]
    nonf=[i for i in ped if ped[i] is not None]
    # 拓扑序
    order=[]
    def dfs(i):
        if i in order: return
        if ped[i] is not None:
            for p in ped[i]: dfs(p)
        order.append(i)
    for i in ped: dfs(i)
    alle={}
    for k,f in enumerate(founders): alle[f]=(2*k,2*k+1)
    cnt={k:0 for k in range(1,10)}
    N=4**len(nonf)
    for bits in itertools.product([0,1],repeat=2*len(nonf)):
        a=dict(alle); b=iter(bits)
        bl=list(bits); idx=0
        for i in order:
            if ped[i] is None: continue
            s,d=ped[i]
            a[i]=(a[s][bl[idx]], a[d][bl[idx+1]]); idx+=2
        x1,x2=a[x]; y1,y2=a[y]
        ex = (x1==x2); ey=(y1==y2)
        # 跨个体 IBD 模式
        m13=(x1==y1); m14=(x1==y2); m23=(x2==y1); m24=(x2==y2)
        cross = m13 or m14 or m23 or m24
        if ex and ey:
            st = 1 if cross else 2
        elif ex and not ey:
            st = 3 if cross else 4
        elif ey and not ex:
            st = 5 if cross else 6
        else:
            npair = (1 if m13 else 0)+(1 if m14 else 0)+(1 if m23 else 0)+(1 if m24 else 0)
            st = 7 if npair==2 else (8 if npair==1 else 9)
        cnt[st]+=1
    return {k: Fr(cnt[k],N) for k in range(1,10)}

def theta(D): return D[1]+Fr(1,2)*(D[3]+D[5]+D[7])+Fr(1,4)*D[8]

# 系谱：1,2 基础；3=(1,2), 4=(1,2) 全同胞；5=(3,4), 6=(3,4) 全同胞且 F=0.25
ped={1:None,2:None,3:(1,2),4:(1,2),5:(3,4),6:(3,4)}
D=condensed(ped,5,6)
Fx=D[1]+D[2]+D[3]+D[4]; Fy=D[1]+D[2]+D[5]+D[6]
print("系谱：3=(1,2),4=(1,2),5=(3,4),6=(3,4)；考察个体对 (5,6)")
print("Delta_1..9 =", [str(D[k]) for k in range(1,10)])
print("sum =", sum(D.values()))
print("F_5 =", Fx, "=", float(Fx), "   F_6 =", Fy)
print("theta_56 =", theta(D), "=", float(theta(D)), "   a_56 = 2*theta =", 2*theta(D), "=", float(2*theta(D)))
print("Delta_7 (u) =", D[7], "=", float(D[7]))
print()
# 同一系谱上的其他对照
for pair in [(3,4),(5,3),(5,5)]:
    if pair[0]==pair[1]: continue
    Dp=condensed(ped,*pair)
    print(f"对 {pair}: Delta7={Dp[7]} Delta8={Dp[8]} theta={theta(Dp)}={float(theta(Dp)):.6f} a={2*theta(Dp)}={float(2*theta(Dp)):.6f}")
print()
# 数值协方差对照
p=np.array([0.6,0.4]); a=1.0; d=1.0
G=np.array([[a,d],[d,-a]])
mu=float(p@G@p); alpha=G@p-mu
sigA2=2*float(np.sum(p*alpha**2))
dl=G-mu-alpha[:,None]-alpha[None,:]; sigD2=float(np.sum(np.outer(p,p)*dl**2))
dii=np.diag(dl).copy(); dbar=float(p@dii); H=-dbar
D1=float(np.sum(p*alpha*dii)); D2=float(np.sum(p*(dii-dbar)**2))
Df={k:float(D[k]) for k in range(1,10)}
fx,fy=float(Fx),float(Fy); th=float(theta(D))
t1=2*th*sigA2; t2=Df[7]*sigD2; t3=(4*Df[1]+Df[3]+Df[5])*D1; t4=Df[1]*D2; t5=(Df[1]+Df[2]-fx*fy)*H**2
print("位点参数 sigA2=%.6f sigD2=%.6f H=%.6f D1*=%.6f D2*=%.6f"%(sigA2,sigD2,H,D1,D2))
print("  2*theta*sigA2           = %.6f"%t1)
print("  Delta7*sigD2            = %.6f"%t2)
print("  (4D1+D3+D5)*D1*         = %.6f"%t3)
print("  Delta1*D2*              = %.6f"%t4)
print("  (D1+D2-Fx Fy)*H^2       = %.6f"%t5)
print("  合计 Cov                = %.6f"%(t1+t2+t3+t4+t5))
print("  若沿用非近交公式 r sigA2+u sigD2 = %.6f  → 相对误差 %.3f%%"%(t1+t2,100*(t3+t4+t5)/(t1+t2+t3+t4+t5)))
