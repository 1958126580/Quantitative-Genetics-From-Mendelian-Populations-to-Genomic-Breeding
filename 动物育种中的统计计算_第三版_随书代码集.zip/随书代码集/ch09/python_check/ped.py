# -*- coding: utf-8 -*-
"""第九章贯穿算例：15 头个体、性别自洽、含近交与单亲未知的系谱。"""
import numpy as np
# (id, sire, dam, sex) sex: 1=公 0=母
PED=[(1,0,0,1),(2,0,0,0),(3,0,0,0),(4,0,0,1),
     (5,1,2,1),(6,1,2,0),(7,1,3,0),
     (8,4,6,1),(9,5,7,0),(10,5,0,0),
     (11,8,9,1),(12,8,10,0),
     (13,11,12,1),(14,11,10,0),(15,13,14,1)]
N=len(PED)
S=np.array([p[1] for p in PED]); Dm=np.array([p[2] for p in PED]); SEX=np.array([p[3] for p in PED])
def check_sex():
    for i in range(N):
        if S[i]>0: assert SEX[S[i]-1]==1,(i+1,'sire',S[i])
        if Dm[i]>0: assert SEX[Dm[i]-1]==0,(i+1,'dam',Dm[i])
    return True
def buildA(S=S,Dm=Dm):
    n=len(S);A=np.zeros((n,n))
    for i in range(n):
        s,d=S[i]-1,Dm[i]-1
        for j in range(i):
            A[i,j]=A[j,i]=0.5*((A[j,s] if s>=0 else 0)+(A[j,d] if d>=0 else 0))
        A[i,i]=1+(0.5*A[s,d] if (s>=0 and d>=0) else 0)
    return A
def dvec(A,S=S,Dm=Dm):
    F=np.diag(A)-1; n=len(S); d=np.empty(n)
    for i in range(n):
        s,dd=S[i]-1,Dm[i]-1
        if s>=0 and dd>=0: d[i]=0.5-0.25*(F[s]+F[dd])
        elif s>=0: d[i]=0.75-0.25*F[s]
        elif dd>=0: d[i]=0.75-0.25*F[dd]
        else: d[i]=1.0
    return d
def Pmat(S=S,Dm=Dm):
    n=len(S);P=np.zeros((n,n))
    for i in range(n):
        if S[i]>0: P[i,S[i]-1]=.5
        if Dm[i]>0: P[i,Dm[i]-1]=.5
    return P
def md(M,dec=4,lab=None,zero="0"):
    n=M.shape[0]; lab=lab or [str(i+1) for i in range(n)]
    out=["| |"+"|".join(lab)+"|","|:--:|"+"|".join(["--:"]*n)+"|"]
    for i in range(n):
        out.append(f"|**{lab[i]}**|"+"|".join(
            ("%.*f"%(dec,M[i,j])).rstrip('0').rstrip('.') if abs(M[i,j])>1e-12 else zero for j in range(n))+"|")
    return "\n".join(out)
