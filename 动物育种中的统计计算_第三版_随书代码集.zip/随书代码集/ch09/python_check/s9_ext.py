# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s9_ext.py    依赖：numpy
"""显性关系矩阵、配子关系矩阵、X 染色体关系矩阵（15 头算例）。"""
import numpy as np
np.set_printoptions(linewidth=250,suppress=True)
PED=[(1,0,0),(2,0,0),(3,0,0),(4,0,0),(5,1,2),(6,1,2),(7,1,3),(8,4,5),(9,6,7),
     (10,5,0),(11,8,9),(12,9,10),(13,11,12),(14,8,12),(15,13,14)]
N=len(PED); S=np.array([p[1] for p in PED]); Dm=np.array([p[2] for p in PED])
def buildA(S,Dm):
    n=len(S);A=np.zeros((n,n))
    for i in range(n):
        s,d=S[i]-1,Dm[i]-1
        for j in range(i):
            A[i,j]=A[j,i]=0.5*((A[j,s] if s>=0 else 0)+(A[j,d] if d>=0 else 0))
        A[i,i]=1+(0.5*A[s,d] if (s>=0 and d>=0) else 0)
    return A
A=buildA(S,Dm); F=np.diag(A)-1
def md(M,dec=4,lab=None):
    n=M.shape[0]; lab=lab or [str(i+1) for i in range(n)]
    out=["| |"+"|".join(lab)+"|","|:--:|"+"|".join(["--:"]*n)+"|"]
    for i in range(n):
        out.append(f"|**{lab[i]}**|"+"|".join(("%.*f"%(dec,M[i,j])).rstrip('0').rstrip('.') if abs(M[i,j])>1e-12 else "0" for j in range(n))+"|")
    return "\n".join(out)

# ---------- 显性关系矩阵（非近交公式）----------
Dd=np.zeros((N,N))
for x in range(N):
    for y in range(N):
        sx,dx=S[x]-1,Dm[x]-1; sy,dy=S[y]-1,Dm[y]-1
        if min(sx,dx,sy,dy)<0: Dd[x,y]=0.0
        else: Dd[x,y]=0.25*(A[sx,sy]*A[dx,dy]+A[sx,dy]*A[dx,sy])
    Dd[x,x]=1.0
print("=== 显性关系矩阵 D_d（非近交公式，对角置 1）===")
print(md(Dd))
Ddi=np.linalg.inv(Dd)
Ainv=np.linalg.inv(A)
print("nnz(D_d) = %d ; nnz(D_d^{-1}) = %d (n^2=%d, %.0f%%)"%(
   np.sum(np.abs(Dd)>1e-12),np.sum(np.abs(Ddi)>1e-10),N*N,100*np.sum(np.abs(Ddi)>1e-10)/N**2))
print("对照 nnz(A^{-1}) = %d (%.0f%%)"%(np.sum(np.abs(Ainv)>1e-10),100*np.sum(np.abs(Ainv)>1e-10)/N**2))
print("D_d 的特征值范围 [%.6f, %.6f]"%(np.linalg.eigvalsh(Dd)[0],np.linalg.eigvalsh(Dd)[-1]))
print("若干元素：D_d[5,6]（全同胞 5、6）= %.4f ；D_d[13,14] = %.6f ；D_d[11,12] = %.6f"%(
    Dd[4,5],Dd[12,13],Dd[10,11]))
print("D_d[8,9]（8=(4,5), 9=(6,7)）= %.6f"%Dd[7,8])
print()
# ---------- 配子关系矩阵 ----------
M=2*N
G=np.zeros((M,M))
def pat(i): return 2*i
def mat(i): return 2*i+1
order=[]
for i in range(N): order+= [pat(i),mat(i)]
for i in range(N):
    s,d=S[i]-1,Dm[i]-1
    for g,par in ((pat(i),s),(mat(i),d)):
        for k in order:
            if k>=g: break
            G[g,k]=G[k,g]=0.5*(G[par*2,k]+G[par*2+1,k]) if par>=0 else 0.0
        G[g,g]=1.0
    # 同一个体两个配子之间
    gp,gm=pat(i),mat(i)
    if s>=0 and d>=0:
        G[gp,gm]=G[gm,gp]=0.25*(G[2*s,2*d]+G[2*s,2*d+1]+G[2*s+1,2*d]+G[2*s+1,2*d+1])
    else: G[gp,gm]=G[gm,gp]=0.0
K=np.zeros((N,M))
for i in range(N): K[i,pat(i)]=1; K[i,mat(i)]=1
print("=== 配子关系矩阵 G_v ===")
print("维数 %d x %d （A 为 %d x %d）"%(M,M,N,N))
print("max |A - 0.5*K G_v K'| = %.3e"%np.max(np.abs(A-0.5*K@G@K.T)))
print("g(i^p,i^m) 与 F_i 的最大差 = %.3e"%np.max(np.abs(np.array([G[pat(i),mat(i)] for i in range(N)])-F)))
print("G_v 的秩 = %d ；最小特征值 = %.6f"%(np.linalg.matrix_rank(G),np.linalg.eigvalsh(G)[0]))
print("G_v 前 8 个配子的子块（个体 1-4）：")
print(md(G[:8,:8],4,["1p","1m","2p","2m","3p","3m","4p","4m"]))
print()
# ---------- X 染色体 ----------
# 性别：1=公 0=母。按系谱里出现在“父”列的为公，“母”列的为母
SEX=np.zeros(N,dtype=int)
for i in range(N):
    if S[i]>0: SEX[S[i]-1]=1
    if Dm[i]>0: SEX[Dm[i]-1]=0
# 未在任何位置出现的：15 设为公，10、13 按需要
known=set(list(S[S>0])+list(Dm[Dm>0]))
for i in range(N):
    if i+1 not in known: SEX[i]=1 if (i+1)%2==1 else 0
print("=== X 染色体关系 ===")
print("性别（1=公，0=母）：", dict((i+1,int(SEX[i])) for i in range(N)))
Phi=np.zeros((N,N))
for i in range(N):
    s,d=S[i]-1,Dm[i]-1
    for j in range(i):
        if SEX[i]==1:                      # 公：X 只来自母
            Phi[i,j]=Phi[j,i]=Phi[j,d] if d>=0 else 0.0
        else:                              # 母：父的唯一 X + 母的随机 X
            Phi[i,j]=Phi[j,i]=0.5*((Phi[j,s] if s>=0 else 0)+(Phi[j,d] if d>=0 else 0))
    if SEX[i]==1: Phi[i,i]=1.0
    else: Phi[i,i]=0.5*(1.0+(Phi[s,d] if (s>=0 and d>=0) else 0.0))
print("Phi^X（X 染色体共祖系数）：")
print(md(Phi,4))
FX=np.array([2*Phi[i,i]-1 if SEX[i]==0 else np.nan for i in range(N)])
print("母畜的 X 近交系数 F^X：", {i+1:round(float(FX[i]),6) for i in range(N) if SEX[i]==0})
print("常染色体共祖 f=0.5*a 对照：")
for (x,y) in [(1,5),(1,7),(2,5),(5,8),(9,11),(13,15)]:
    print("  (%2d,%2d)  性别 %s/%s   Phi^X = %.6f   f = %.6f"%(
        x,y,"公" if SEX[x-1] else "母","公" if SEX[y-1] else "母",Phi[x-1,y-1],0.5*A[x-1,y-1]))
# 父子（公-公）X 关系
print("公—公的父子对：")
for i in range(N):
    if S[i]>0 and SEX[i]==1 and SEX[S[i]-1]==1:
        print("  个体 %d 与其父 %d ：Phi^X = %.6f ， f = %.6f"%(i+1,S[i],Phi[i,S[i]-1],0.5*A[i,S[i]-1]))
