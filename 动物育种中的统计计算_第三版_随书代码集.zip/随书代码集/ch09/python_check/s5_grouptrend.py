# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 9 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5_grouptrend.py    依赖：numpy, scipy
"""遗传分组的定量效果：外来个体有遗传趋势时，不分组 / 分组模型的 EBV 偏倚对照。"""
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve
rng=np.random.default_rng(2026)

NG=6          # 世代数（1..6）
NOFF=240      # 每世代后代数
NSIRE=12; NDAM=120
NIMM=20       # 每世代新引入（双亲未知）的个体数
DELTA=0.30    # 引入个体每世代的遗传水平提高（单位 sigma_A）
H2=0.30

def one_rep(seed, use_groups):
    r=np.random.default_rng(seed)
    sire=[];dam=[];gen=[];tbv=[];grp=[]
    # 第 0 世代：40 个本地基础个体（组 1）
    for i in range(200):
        sire.append(0);dam.append(0);gen.append(0);grp.append(1);tbv.append(r.normal())
    for t in range(1,NG+1):
        # 本世代新引入个体（双亲未知，组 = t+1，真实均值 = t*DELTA）
        for k in range(NIMM):
            sire.append(0);dam.append(0);gen.append(t);grp.append(t+1)
            tbv.append(t*DELTA + r.normal())
        prev=[i for i in range(len(gen)) if gen[i]==t-1] + [i for i in range(len(gen)) if gen[i]==t and sire[i]==0]
    
        cand=[i for i in range(len(gen)) if gen[i]<t or (gen[i]==t and sire[i]==0)]
        sires=list(r.choice(cand,NSIRE,replace=False))
        dams=list(r.choice([i for i in cand if i not in sires],NDAM,replace=False))
        for k in range(NOFF):
            s=sires[k%NSIRE]; d=dams[r.integers(NDAM)]
            sire.append(s+1);dam.append(d+1);gen.append(t);grp.append(0)
            tbv.append(0.5*(tbv[s]+tbv[d])+np.sqrt(0.5)*r.normal())
    n=len(gen)
    sire=np.array(sire);dam=np.array(dam);tbv=np.array(tbv);gen=np.array(gen);grp=np.array(grp)
    y=tbv+r.normal(0,np.sqrt((1-H2)/H2),n)      # sigma_A^2=1
    # A^{-1}（忽略近交对 d 的修正影响很小，这里用精确 Meuwissen-Luo）
    F=np.zeros(n); d=np.ones(n)
    import heapq
    for i in range(n):
        s,dd=sire[i]-1,dam[i]-1
        if s>=0 and dd>=0: d[i]=0.5-0.25*(F[s]+F[dd])
        elif s>=0: d[i]=0.75-0.25*F[s]
        elif dd>=0: d[i]=0.75-0.25*F[dd]
        else:
            F[i]=0.0; d[i]=1.0; continue
        L={}; hp=[]
        L[i]=1.0; heapq.heappush(hp,-i); inh={i}
        aii=0.0
        while hp:
            j=-heapq.heappop(hp); lj=L.pop(j)
            aii+=lj*lj*d[j]
            for p in (sire[j]-1,dam[j]-1):
                if p>=0:
                    if p not in L: L[p]=0.0; heapq.heappush(hp,-p)
                    L[p]+=lj/2
        F[i]=aii-1.0
    def ainv_sparse(sire,dam,d,ngrp=0,grpcode=None):
        rows=[];cols=[];vals=[]
        off=ngrp
        for i in range(n):
            b=1.0/d[i]
            par=[]
            if sire[i]>0: par.append(off+sire[i]-1)
            elif ngrp: par.append(grpcode[i]-1)
            if dam[i]>0: par.append(off+dam[i]-1)
            elif ngrp: par.append(grpcode[i]-1)
            ii=off+i
            rows.append(ii);cols.append(ii);vals.append(b)
            for p in par:
                rows+= [ii,p]; cols+=[p,ii]; vals+=[-b/2,-b/2]
            for p in par:
                for q in par:
                    rows.append(p);cols.append(q);vals.append(b/4)
            # 注意：par 中同组出现两次时上面的双重循环自动给出 4 个 b/4 = b，正确
        m=off+n
        return sparse.coo_matrix((vals,(rows,cols)),shape=(m,m)).tocsr()
    lam=(1-H2)/H2
    if not use_groups:
        Ai=ainv_sparse(sire,dam,d)
        X=sparse.csr_matrix(np.ones((n,1)))
        Z=sparse.identity(n,format='csr')
        C=sparse.bmat([[X.T@X, X.T@Z],[Z.T@X, Z.T@Z+Ai*lam]],format='csc')
        rhs=np.concatenate([X.T@y, y])
        C=C+sparse.identity(C.shape[0],format='csc')*1e-8
        sol=spsolve(C,rhs); eb=sol[1:]
    else:
        ngrp=NG+1
        gc=np.where(grp>0,grp,1)
        Ai=ainv_sparse(sire,dam,d,ngrp,gc)
        X=sparse.csr_matrix(np.ones((n,1)))
        Z=sparse.hstack([sparse.csr_matrix((n,ngrp)),sparse.identity(n,format='csr')],format='csr')
        C=sparse.bmat([[X.T@X, X.T@Z],[Z.T@X, Z.T@Z+Ai*lam]],format='csc')
        rhs=np.concatenate([X.T@y, Z.T@y])
        C=C+sparse.identity(C.shape[0],format='csc')*1e-8
        sol=spsolve(C,rhs); eb=sol[1+ngrp:]
    return tbv,eb,gen

res={}
for ug in [False,True]:
    cors=[];slopes=[];trend_err=[];lastbias=[]
    for rep in range(20):
        tbv,eb,gen=one_rep(1000+rep,ug)
        sel=gen>=1
        cors.append(np.corrcoef(eb[sel],tbv[sel])[0,1])
        slopes.append(np.polyfit(eb[sel],tbv[sel],1)[0])
        # 真实/估计遗传趋势（各世代均值对世代回归）
        gm_t=[tbv[gen==t].mean() for t in range(1,NG+1)]
        gm_e=[eb[gen==t].mean() for t in range(1,NG+1)]
        bt=np.polyfit(range(1,NG+1),gm_t,1)[0]; be=np.polyfit(range(1,NG+1),gm_e,1)[0]
        trend_err.append((be,bt))
        lastbias.append((eb[gen==NG].mean()-eb[gen==1].mean())-(tbv[gen==NG].mean()-tbv[gen==1].mean()))
    be=np.array([a for a,b in trend_err]); bt=np.array([b for a,b in trend_err])
    res[ug]=(np.mean(cors),np.std(cors,ddof=1)/np.sqrt(20),np.mean(slopes),
             np.mean(be),np.mean(bt),np.mean(lastbias),np.std(lastbias,ddof=1)/np.sqrt(20))
print("每重复：n = %d 头，世代 1..%d，每世代引入 %d 头双亲未知个体，其遗传水平每世代 +%.2f sigma_A"%(
    200+NG*(NIMM+NOFF),NG,NIMM,DELTA))
print("20 次重复，h2 = %.2f\n"%H2)
print("| 模型 | r(EBV,TBV) | 回归斜率 | 估计遗传趋势 | 真实遗传趋势 | 世代1->6 遗传进展的估计偏倚 |")
for ug,nm in [(False,"不分组"),(True,"6+1 个遗传分组")]:
    c,cse,sl,be_,bt_,lb,lbse=res[ug]
    print(f"| {nm} | {c:.4f}±{cse:.4f} | {sl:.4f} | {be_:+.4f} | {bt_:+.4f} | {lb:+.4f}±{lbse:.4f} |")
