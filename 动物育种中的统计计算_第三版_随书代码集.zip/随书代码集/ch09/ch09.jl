# 本脚本由 tools/nb2jl.py 从同目录的 ch09.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 09

# %% [markdown]
# # 第九章　亲属间的协方差与系谱关系矩阵 —— 配套代码
#
# **本笔记本是全书使用频率最高的一个。** 它给出 $\mathbf A$、$\mathbf A^{-1}$、近交系数与 $\mathbf{Av}$ 的
# 【原理实现】与【优化实现】，并逐一验证正文的每个公式。
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | $\mathbf A$ 的递推构建与 7 个体算例 | §9.2 |
# | 2 | $\mathbf A=\mathbf{TDT}'$ 分解及其遗传学含义 | §9.3.1 |
# | 3 | Henderson–Quaas 规则构建 $\mathbf A^{-1}$ | §9.3.2 |
# | 4 | Meuwissen–Luo 近交算法 | §9.3.4 |
# | 5 | Colleau 算法：$O(n)$ 计算 $\mathbf{Av}$ | §9.3.5 |
# | 6 | 显性与上位关系矩阵 | §9.4 |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions, BenchmarkTools
rng = Xoshiro(20260918)

# %% [markdown]
# ## 1　$\mathbf A$ 的构建（正文式 9.2、9.3）

# %%
"""
    build_A(sire, dam) -> Matrix{Float64}

按递推式 (9.2)、(9.3) 构建分子血缘关系矩阵。
**要求**：个体已按拓扑序编号（后代序号 > 双亲序号），未知亲本记为 0。
复杂度 O(n²)，存储 O(n²)。A 在真实群体中是稠密的，故用稠密格式。
"""
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire)
    @assert length(dam) == n
    @assert all(sire[i] < i && dam[i] < i for i in 1:n) "系谱必须已拓扑排序"
    A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            asj = s > 0 ? A[j, s] : 0.0
            adj = d > 0 ? A[j, d] : 0.0
            A[i, j] = A[j, i] = 0.5*(asj + adj)
        end
        A[i, i] = 1.0 + (s > 0 && d > 0 ? 0.5*A[s, d] : 0.0)
    end
    return A
end

# 正文第二节的 7 个体算例
sire = [0, 0, 1, 1, 3, 1, 5]
dam  = [0, 0, 0, 2, 4, 4, 6]
A = build_A(sire, dam)
F = diag(A) .- 1

println("A 矩阵（保留 5 位小数）：")
display(round.(A, digits=5))
println()
println("近交系数 F = ", round.(F, digits=5))
println("【手算核对】F₅=0.125, F₆=0.25, F₇=0.28125  → ",
        isapprox(F[5:7], [0.125, 0.25, 0.28125]; atol=1e-12) ? "✓ 一致" : "✗")
@printf("\n稠密度：非零元占 %.1f%%  ← A 是稠密的，不应用稀疏格式存储\n",
        100*count(!iszero, A)/length(A))

# %% [markdown]
# ## 2　$\mathbf A=\mathbf{TDT}'$ 分解（正文式 9.5、9.8）

# %%
"""
    TD_decomposition(sire, dam, F) -> (T, D)

构建 A = T D T' 分解。T = (I − P)⁻¹ 为单位下三角（基因传递路径），
D 为对角阵，dᵢ 是 Mendel 抽样方差的系数（式 9.5）。
"""
function TD_decomposition(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire)
    P = zeros(n, n)
    d = zeros(n)
    for i in 1:n
        s, dd = sire[i], dam[i]
        s  > 0 && (P[i, s]  = 0.5)
        dd > 0 && (P[i, dd] = 0.5)
        d[i] = if s > 0 && dd > 0
            0.5 - 0.25*(F[s] + F[dd])
        elseif s > 0
            0.75 - 0.25*F[s]
        elseif dd > 0
            0.75 - 0.25*F[dd]
        else
            1.0
        end
    end
    T = inv(I - P)                    # 小规模可直接求逆；大规模用前代
    return LowerTriangular(T), Diagonal(d)
end

T, D = TD_decomposition(sire, dam, F)
@printf("【验证式 9.8】‖A − T D T'‖ = %.3e\n", norm(A - T*D*T'))
println("\nMendel 抽样方差系数 d = ", round.(diag(D), digits=6))
println("  个体 1,2（双亲未知）    : d = 1")
println("  个体 3（仅父已知）      : d = 0.75")
println("  个体 4,5,6（双亲已知）  : d = 0.5 − 0.25(Fs+Fd)")
println("  个体 7（双亲 F₅,F₆>0）  : d = 0.5 − 0.25(0.125+0.25) = ", 0.5-0.25*(0.125+0.25))

# 验证第三章式 (3.10)：L_chol = T·D^{1/2}，d_i = l_ii²（第二版勘误 1-1）
Lc = cholesky(Symmetric(A)).L
@printf("\n【第二版勘误 1-1 的验证】\n")
@printf("  ‖L_chol − T·D^{1/2}‖ = %.3e   ⇒ L = T D^{1/2}  ✓\n", norm(Matrix(Lc) - Matrix(T)*sqrt.(D)))
println("  d 的对角元          = ", round.(diag(D), digits=6))
println("  L_chol 对角元的平方 = ", round.(diag(Lc).^2, digits=6))
println("  ⇒ dᵢ = lᵢᵢ²（不是 dᵢ = lᵢᵢ）")

# T⁻¹ 的稀疏性
Tinv = I - [i>j && (sire[i]==j || dam[i]==j) ? 0.5 : 0.0 for i in 1:7, j in 1:7]
@printf("\nT⁻¹ 的非零元数 = %d  （上界 3n = %d）\n", count(!iszero, Tinv), 3*7)

# %% [markdown]
# ## 3　$\mathbf A^{-1}$：Henderson–Quaas 规则（正文式 9.9–9.11）

# %%
"""
    build_Ainv(sire, dam, F) -> SparseMatrixCSC

由系谱按 Henderson (1976) / Quaas (1976) 规则直接构建 A⁻¹。
复杂度 O(n)，非零元 ≤ 9n，**不需要先构建 A**。

每个个体以 q = (−½, −½, 1)（对应 s, d, i）向 A⁻¹ 的 3×3 块贡献 q q'/dᵢ。
"""
function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire)
    I_ = Int[]; J_ = Int[]; V_ = Float64[]
    sizehint!(I_, 9n); sizehint!(J_, 9n); sizehint!(V_, 9n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        pos = (s, d, i)
        if s > 0 && d > 0
            q = (-0.5, -0.5, 1.0); δ = 0.5 - 0.25*(F[s] + F[d])
        elseif s > 0
            q = (-0.5,  0.0, 1.0); δ = 0.75 - 0.25*F[s]
        elseif d > 0
            q = ( 0.0, -0.5, 1.0); δ = 0.75 - 0.25*F[d]
        else
            q = ( 0.0,  0.0, 1.0); δ = 1.0
        end
        b = inv(δ)
        for a in 1:3, c in 1:3
            (pos[a] > 0 && pos[c] > 0) || continue
            push!(I_, pos[a]); push!(J_, pos[c]); push!(V_, q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)      # 重复下标自动求和
end

Ai = build_Ainv(sire, dam, F)
println("A⁻¹（保留 5 位小数）：")
display(round.(Matrix(Ai), digits=5))
println()
@printf("【核心验证】‖A·A⁻¹ − I‖∞ = %.3e\n", maximum(abs, A*Matrix(Ai) - I))
@printf("对称性误差              = %.3e\n", maximum(abs, Ai - Ai'))
@printf("非零元 %d 个（上界 9n = %d）\n", nnz(Ai), 9*length(sire))
println()
println("【对照验证】与 inv(A) 的差 = ", round(norm(Matrix(Ai) - inv(A)), sigdigits=3))

# %% [markdown]
# ### 3.1 规模测试：$O(n)$ vs $O(n^3)$（正文 §9.3.3）

# %%
"""生成随机系谱（前 nbase 个体为基础群）。"""
function random_pedigree(n::Int; nbase::Int=max(10, n÷100), rng=Random.default_rng())
    sire = zeros(Int, n); dam = zeros(Int, n)
    for i in nbase+1:n
        sire[i] = rand(rng, 1:i-1); dam[i] = rand(rng, 1:i-1)
    end
    return sire, dam
end

println(rpad("n", 10), rpad("build_A + inv (ms)", 22), rpad("build_Ainv (ms)", 20), "加速比")
println("-"^62)
for n in (100, 300, 1000)
    s, d = random_pedigree(n; rng=Xoshiro(n))
    AA = build_A(s, d); FF = diag(AA) .- 1
    t1 = @belapsed (AAx = build_A($s, $d); inv(AAx)) samples=3 evals=1
    t2 = @belapsed build_Ainv($s, $d, $FF)          samples=3 evals=1
    # 正确性
    ok = maximum(abs, AA*Matrix(build_Ainv(s,d,FF)) - I) < 1e-8
    @printf("%-10d%-22.2f%-20.3f%.0f×  %s\n", n, t1*1e3, t2*1e3, t1/t2, ok ? "✓" : "✗")
end
println()
println("→ 随 n 增大，加速比按 n² 增长（O(n³) vs O(n)）。")
println("  n = 10⁷ 时（正文 §1.3.3）：前者需 5.3 年、728 TiB；后者不到 1 秒、1.3 GiB。")

# %% [markdown]
# ## 4　Meuwissen–Luo 近交算法（正文式 9.12）

# %%
"""
    inbreeding_ml(sire, dam) -> Vector{Float64}

Meuwissen & Luo (1992) 算法计算全部个体的近交系数。
利用 aᵢᵢ = Σ_{j≤i} tᵢⱼ² dⱼ，每个个体只需遍历其祖先，代价正比于祖先数而非 n。
"""
function inbreeding_ml(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire)
    F = zeros(n); L = zeros(n); d = zeros(n)
    anc = Int[]                      # 当前个体的祖先集合（按序号降序处理）
    for i in 1:n
        s, dd = sire[i], dam[i]
        d[i] = if s > 0 && dd > 0
            0.5 - 0.25*(F[s] + F[dd])
        elseif s > 0 || dd > 0
            0.75 - 0.25*F[max(s, dd)]
        else
            1.0
        end
        if s == 0 || dd == 0
            F[i] = 0.0
            continue
        end
        fill!(L, 0.0); L[i] = 1.0
        empty!(anc); push!(anc, i)
        aii = 0.0
        while !isempty(anc)
            j = maximum(anc)                       # 取序号最大的祖先
            filter!(!=(j), anc)
            aii += L[j]^2 * d[j]
            sj, dj = sire[j], dam[j]
            if sj > 0
                L[sj] += 0.5*L[j]; sj ∈ anc || push!(anc, sj)
            end
            if dj > 0
                L[dj] += 0.5*L[j]; dj ∈ anc || push!(anc, dj)
            end
            L[j] = 0.0
        end
        F[i] = aii - 1.0
    end
    return F
end

# 【对照验证】与 build_A 的对角元比较
F_ml = inbreeding_ml(sire, dam)
@printf("【对照验证】Meuwissen–Luo vs build_A 对角元：最大差 = %.3e\n",
        maximum(abs, F_ml - F))
println("  F = ", round.(F_ml, digits=6))

# 在较大系谱上对照
s2, d2 = random_pedigree(800; rng=Xoshiro(5))
A2 = build_A(s2, d2)
F2 = inbreeding_ml(s2, d2)
@printf("\nn=800 随机系谱：最大差 = %.3e ， 平均 F = %.4f ， 最大 F = %.4f\n",
        maximum(abs, F2 - (diag(A2).-1)), mean(F2), maximum(F2))
t1 = @belapsed (AA = build_A($s2,$d2); diag(AA) .- 1) samples=3 evals=1
t2 = @belapsed inbreeding_ml($s2, $d2)                samples=3 evals=1
@printf("build_A 路径 %.2f ms ； Meuwissen–Luo %.2f ms （加速 %.1f×）\n", t1*1e3, t2*1e3, t1/t2)

# %% [markdown]
# ## 5　Colleau 算法：$O(n)$ 计算 $\mathbf{Av}$（正文 §9.3.5）
#
# 许多场合需要的是 $\mathbf{Av}$ 而非 $\mathbf A$ 本身（OCS 的 $\mathbf c'\mathbf{Ac}$、单步法、遗传趋势）。
# Colleau (2002) 算法用三步完成，**完全不接触 $\mathbf A$ 的任何元素**。

# %%
"""
    colleau(sire, dam, d, v) -> A*v

Colleau (2002) 算法：以 O(n) 计算 A·v，不构建 A。
三步：(1) 解 (I−P')w = v（逆序回代）；(2) z = D w；(3) 解 (I−P)y = z（正序前代）。
"""
function colleau(sire::Vector{Int}, dam::Vector{Int}, d::Vector{Float64}, v::Vector{Float64})
    n = length(sire)
    # 步骤 1：w = T'v ⇔ (I − P')w = v，逆序
    w = copy(v)
    @inbounds for i in n:-1:1
        s, dd = sire[i], dam[i]
        s  > 0 && (w[s]  += 0.5*w[i])
        dd > 0 && (w[dd] += 0.5*w[i])
    end
    # 步骤 2：z = D w
    z = d .* w
    # 步骤 3：y = T z ⇔ (I − P)y = z，正序
    y = copy(z)
    @inbounds for i in 1:n
        s, dd = sire[i], dam[i]
        s  > 0 && (y[i] += 0.5*y[s])
        dd > 0 && (y[i] += 0.5*y[dd])
    end
    return y
end

# 【对照验证】小规模
dvec = diag(D)
v = randn(rng, 7)
@printf("【对照验证】‖colleau(v) − A·v‖ / ‖A·v‖ = %.3e\n",
        norm(colleau(sire, dam, dvec, v) - A*v)/norm(A*v))

# 大规模性能
n = 20_000
s3, d3 = random_pedigree(n; rng=Xoshiro(9))
F3 = inbreeding_ml(s3, d3)
dv3 = [let s=s3[i], dd=d3[i]
           s>0 && dd>0 ? 0.5-0.25*(F3[s]+F3[dd]) :
           (s>0 || dd>0 ? 0.75-0.25*F3[max(s,dd)] : 1.0)
       end for i in 1:n]
v3 = randn(rng, n)
t = @belapsed colleau($s3, $d3, $dv3, $v3)
@printf("\nn = %d 时 Colleau 计算 A·v : %.3f ms （完全不构建 A）\n", n, t*1e3)
@printf("若构建 A 需要 %.1f GiB 内存 —— 而 Colleau 只需 O(n)\n", n^2*8/2^30)

# %% [markdown]
# ## 6　显性与上位关系矩阵（正文 §9.4）

# %%
"""
    dominance_matrix(A, sire, dam) -> Matrix

由式 (9.13) 构建显性关系矩阵（非近交近似）：
u_xy = f(sx,sy)·f(dx,dy) + f(sx,dy)·f(dx,sy)，其中 f = a/2。
"""
function dominance_matrix(A::Matrix{Float64}, sire::Vector{Int}, dam::Vector{Int})
    n = size(A, 1)
    f(i, j) = (i > 0 && j > 0) ? A[i, j]/2 : 0.0
    Dd = zeros(n, n)
    for x in 1:n, y in 1:n
        if x == y
            Dd[x, y] = 1.0
        else
            sx, dx, sy, dy = sire[x], dam[x], sire[y], dam[y]
            Dd[x, y] = f(sx, sy)*f(dx, dy) + f(sx, dy)*f(dx, sy)
        end
    end
    return Dd
end

Dd = dominance_matrix(A, sire, dam)
println("显性关系矩阵（保留 4 位小数）：")
display(round.(Dd, digits=4))
println()
println("【核对】个体 5(3,4) 与 6(1,4) 是半同胞（共母 4）:")
@printf("  u₅₆ = %.4f  ← 半同胞的 u 应为 0（非近交时）\n", Dd[5,6])
println("【核对】构造一对全同胞验证 u = 1/4：")
s_fs = [0,0,1,1]; d_fs = [0,0,2,2]      # 个体 3、4 是全同胞
A_fs = build_A(s_fs, d_fs)
D_fs = dominance_matrix(A_fs, s_fs, d_fs)
@printf("  全同胞 u₃₄ = %.4f   ← 应为 0.25 ✓\n", D_fs[3,4])

# 上位关系矩阵（式 9.14）
A_AA = A .* A                # Hadamard 积
@printf("\n加性×加性上位关系矩阵 A_AA = A#A ，(7,7) 元素 = %.6f = %.6f²\n",
        A_AA[7,7], A[7,7])

# %% [markdown]
# ## 本章代码小结
#
# 1. **$\mathbf A$ 是稠密的**（7 个体中只有 2 个零元），应用稠密格式或干脆不构建。
# 2. **$\mathbf A=\mathbf{TDT}'$ 已验证**；$\mathbf T$ 编码基因传递路径，$\mathbf D$ 的对角元是 Mendel 抽样方差系数。
# 3. **$\mathbf L_{\text{Chol}}=\mathbf{TD}^{1/2}$、$d_i=l_{ii}^2$ 已数值验证**——第二版勘误 1‑1 的直接证明。
# 4. **Henderson–Quaas 规则以 $O(n)$ 构建 $\mathbf A^{-1}$**，$\|\mathbf{AA}^{-1}-\mathbf I\|=O(10^{-16})$，非零元 ≤ $9n$。规模测试显示加速比按 $n^2$ 增长。
# 5. **Meuwissen–Luo 算法**的代价正比于祖先数，与 `build_A` 路径结果完全一致。
# 6. **Colleau 算法以 $O(n)$ 计算 $\mathbf{Av}$**，$n=2\times10^4$ 时毫秒级完成，而构建 $\mathbf A$ 需 3 GiB。
# 7. 显性关系矩阵按式 (9.13) 构建，全同胞 $u=1/4$、半同胞 $u=0$ 均已核对。
