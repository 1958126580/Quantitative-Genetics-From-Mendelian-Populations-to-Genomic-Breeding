# 本脚本由 tools/nb2jl.py 从同目录的 ch35.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 35

# %% [markdown]
# # 第三十五章　遗传改良体系的整体优化与前沿展望 —— 配套代码
#
# **内容**
#
# 1. **$\Delta G=\boldsymbol\pi'\mathbf s$**（正文式 35.6）：平稳分布与渐近进展
# 2. **遗传滞后**的计算（正文式 35.5、35.7），两层与三层体系
# 3. 参考群体投资的边际回报与最优规模（正文式 35.9–35.12）
# 4. 最优选择年龄（正文式 35.14）
# 5. 多阶段决策的动态规划示例（正文式 35.15）与滚动规划
# 6. ROH 长度与近交时间（正文式 35.16）
# 7. **联邦求解 MME 的精确性**（正文式 35.19）

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %%
"""按系谱递推构造 A（第九章）。"""
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

# %% [markdown]
# ## 1　$\Delta G=\boldsymbol\pi'\mathbf s$ 与遗传滞后（正文式 35.2–35.8）

# %%
"""行随机矩阵 P 的平稳分布 π（π'P = π'，π'1 = 1）。"""
function stationary(P::Matrix{Float64})
    ev = eigen(Matrix(P'))
    k = argmin(abs.(ev.values .- 1))
    pi_ = real.(ev.vectors[:, k])
    return pi_ ./ sum(pi_)
end

"""正文式 (35.5)–(35.7)：渐近进展与各组滞后。"""
function lag_analysis(P::Matrix{Float64}, s::Vector{Float64})
    pi_ = stationary(P)
    dG = dot(pi_, s)                                   # 式 (35.6)
    q = size(P, 1)
    # 解 (I-P)d = s - dG·1，附加约束 π'd = 0（增广最小二乘）
    Aaug = vcat(I - P, pi_')
    baug = vcat(s .- dG, 0.0)
    d = Aaug \ baug
    return dG, d, pi_
end

"""直接迭代 m_{t+1} = P m_t + s 以验证。"""
function iterate_flow(P, s; T=400)
    m = zeros(size(P,1))
    for _ in 1:T; m = P*m .+ s; end
    m2 = P*m .+ s
    return m2 .- m, m
end

# 两层例子（正文式 35.8）
P2 = [1.0 0.0; 0.5 0.5]; s2 = [1.0, 0.0]
dG2, d2, pi2 = lag_analysis(P2, s2)
@printf("两层：π = %s ， ΔG = %.4f ， 滞后 d_N - d_C = %.4f （理论 2ΔG = %.4f）\n",
        string(round.(pi2, digits=4)), dG2, d2[1]-d2[2], 2dG2)
inc, _ = iterate_flow(P2, s2)
check("迭代的渐近增量 = π's", inc, fill(dG2, 2); tol=1e-8)

# 三层体系：核心(N)、扩繁(M)、商品(C)，每层分公母
#  顺序：N♂, N♀, M♂, M♀, C♂, C♀
P3 = zeros(6, 6)
P3[1, [1,2]] .= 0.5                  # 核心：自我更新
P3[2, [1,2]] .= 0.5
P3[3, [1,2]] .= 0.5                  # 扩繁公：来自核心
P3[4, 1] = 0.5; P3[4, 4] = 0.5       # 扩繁母：父本核心公、母本扩繁母
P3[5, 3] = 0.5; P3[5, 6] = 0.5       # 商品公：父本扩繁公
P3[6, 3] = 0.5; P3[6, 6] = 0.5       # 商品母：父本扩繁公、母本商品母
s3 = [1.2, 0.4, 0, 0, 0, 0]
dG3, d3, pi3 = lag_analysis(P3, s3)
@printf("\n三层：π = %s\n", string(round.(pi3, digits=4)))
@printf("ΔG = π's = %.4f （每“时间单位”）\n", dG3)
labels = ["核心♂", "核心♀", "扩繁♂", "扩繁♀", "商品♂", "商品♀"]
dN = mean(d3[1:2])
for k in 1:6
    @printf("  %-8s 相对核心的滞后 = %.2f 个时间单位\n", labels[k], (dN - d3[k])/dG3)
end
inc3, _ = iterate_flow(P3, s3)
check("三层：迭代的渐近增量 = π's", inc3, fill(dG3, 6); tol=1e-8)
println("\n=> 商品群的 π = 0：在商品群施加选择不影响体系的长期进展（正文 §35.1.3）。")

# %% [markdown]
# ## 2　参考群体投资的边际回报（正文式 35.9–35.12）

# %%
acc(N, h2, Me) = sqrt(N*h2/(N*h2 + Me))
dacc(N, h2, Me) = (1/(2acc(N,h2,Me)))*Me*h2/(N*h2 + Me)^2     # 式 (35.9)

"""式 (35.11)：边际 NPV（单位：元/头参考个体）。"""
function marginal_npv(N; h2=0.3, Me=640.0, i=2.0, sA=1.0, L=4.0, v=300.0,
                      Ncomm=1e6, rate=0.05, lag=3, T=15)
    dG = i*sA/L*dacc(N, h2, Me)
    disc = sum((t - lag)/(1+rate)^t for t in lag+1:T)
    return v*dG*Ncomm*disc
end

"""式 (35.12)：二分法求最优规模 N*。"""
function optimal_N(cost; kw...)
    lo, hi = 10.0, 1e7
    for _ in 1:200
        mid = sqrt(lo*hi)
        marginal_npv(mid; kw...) > cost ? (lo = mid) : (hi = mid)
    end
    return (lo + hi)/2
end

cost = 150.0 + 40.0          # 表型 + 基因型（元/头）
@printf("%-16s%-16s%-14s\n", "商品群规模", "最优 N*", "对应准确性")
for Nc in (1e4, 1e5, 1e6, 1e7)
    Ns = optimal_N(cost; Ncomm=Nc)
    @printf("%-16.0e%-16.0f%-14.3f\n", Nc, Ns, acc(Ns, 0.3, 640.0))
end
println("\n=> 最优参考群体规模由下游商品群规模决定（正文 §35.2.1）。")

# %% [markdown]
# ## 3　最优选择年龄（正文式 35.14）

# %%
"""年进展 i r(t) / L(t) 关于选择年龄 t 的函数。"""
annual_gain(t; a=0.8, r0=0.0, L0=1.5, i=1.8) =
    i*sqrt(r0^2 + (1 - r0^2)*(1 - exp(-a*t)))/(L0 + t)

println("最优选择年龄 t*（年）\n")
@printf("%-26s%-12s%-16s\n", "情形", "t*", "最大年进展")
for (nm, r0) in ("传统（出生时 r = 0.3）" => 0.3, "基因组（出生时 r = 0.7）" => 0.7)
    ts = range(0.0, 8.0; length=801)
    g = [annual_gain(t; r0=r0) for t in ts]
    k = argmax(g)
    @printf("%-26s%-12.2f%-16.4f\n", nm, ts[k], g[k])
end
println("\n=> 基因组选择使 r(0) 升高，最优选择年龄前移（正文式 35.14）。")

# %% [markdown]
# ## 4　多阶段决策：动态规划与滚动规划（正文式 35.15）

# %%
"""两状态（遗传水平 u、近交 F）、单决策（每代留种公畜数 k）的动态规划。

回报 = u − κ·衰退(F)；状态转移用确定性近似：
  u' = u + i(k)·r·σ_A(F)，F' = F + ΔF(k)，σ_A(F) = σ_A0·sqrt(1 - F)。
"""
function dp_breeding(; T=10, kgrid=[2, 5, 10, 20, 40], nF=41, Fmax=0.4,
                       kappa=4.0, beta=0.95, ncand=100, ndam=100, r=0.6, sA0=1.0)
    Fgrid = range(0.0, Fmax; length=nF)
    ik(k) = (p = k/ncand; x = quantile(Normal(), 1-p); pdf(Normal(), x)/p)   # 公畜选择强度
    dF(k) = 1/(8k) + 1/(8ndam)                                            # 式 (34.2) 的近似
    V = zeros(nF)                      # 终端价值（与 u 线性可分，只需对 F 做 DP）
    pol = zeros(Int, T, nF)
    for t in T:-1:1
        Vn = similar(V)
        for (a, F) in enumerate(Fgrid)
            best = -Inf; bk = 0
            for k in kgrid
                F2 = min(F + dF(k)*(1 - F), Fmax)
                gain = ik(k)*r*sA0*sqrt(1 - F)
                # 线性插值 V(F2)
                pos = (F2 - Fgrid[1])/(Fgrid[2] - Fgrid[1]) + 1
                lo = clamp(floor(Int, pos), 1, nF-1); w = pos - lo
                Vf = (1-w)*V[lo] + w*V[lo+1]
                val = gain - kappa*(F2 - F) + beta*Vf
                val > best && (best = val; bk = k)
            end
            Vn[a] = best; pol[t, a] = bk
        end
        V = Vn
    end
    return pol, Fgrid, V
end

pol, Fgrid, V = dp_breeding()
println("动态规划给出的最优留种公畜数（行：世代，列：当前近交 F）\n")
@printf("%-8s", "世代")
for F in (0.0, 0.1, 0.2, 0.3); @printf("%-10s", "F=$(F)"); end
println()
for t in 1:size(pol,1)
    @printf("%-8d", t)
    for F in (0.0, 0.1, 0.2, 0.3)
        a = argmin(abs.(Fgrid .- F)); @printf("%-10d", pol[t, a])
    end
    println()
end
println("\n=> 近交越高、离终点越远，最优策略越保守（留更多公畜）。")
println("   这就是正文式 (35.15) 的“状态依赖决策”——固定规则无法做到。")

# %% [markdown]
# ## 5　ROH 长度与近交时间（正文式 35.16）

# %%
"""模拟：共同祖先在 g 代前，IBD 片段长度（cM）的分布。"""
function ibd_segment_lengths(g::Int; nrep=100_000, rng=Random.default_rng())
    # 两条路径共 2g 次减数分裂，片段长度 ~ Exp(rate = 2g / 100 cM)
    return rand(rng, Exponential(100/(2g)), nrep)
end

@printf("%-10s%-18s%-18s%-20s\n", "g（代）", "模拟平均长度 cM", "式(35.16) 100/(2g)", "P(长度>10 cM)")
for g in (1, 2, 5, 10, 20, 50)
    L_ = ibd_segment_lengths(g; rng=Xoshiro(g))
    @printf("%-10d%-18.2f%-18.2f%-20.4f\n", g, mean(L_), 100/(2g), mean(>(10), L_))
end
println("\n=> 长 ROH（>10 cM）几乎只来自 5 代以内的共同祖先——据此区分近期管理与历史瓶颈。")

# %% [markdown]
# ## 6　联邦求解 MME 的精确性（正文式 35.19）

# %%
"""把数据按"机构"切分，各方只提供 C_k = W_k'W_k 与 r_k = W_k'y_k。"""
let rng = Xoshiro(3500), n = 600, nk = 3
    # 一个简单的动物模型：y = 1μ + u + e，u ~ N(0, A σ²_u)
    sire = vcat(zeros(Int, 60), rand(rng, 1:30, n-60))
    dam  = vcat(zeros(Int, 60), rand(rng, 31:60, n-60))
    A = build_A(sire, dam)
    u = cholesky(Symmetric(A)).L*randn(rng, n).*sqrt(0.3)
    y = 10.0 .+ u .+ randn(rng, n).*sqrt(0.7)
    lam = 0.7/0.3
    Ainv = inv(Symmetric(A))
    X = ones(n, 1); W = Matrix{Float64}(I, n, n)
    # 集中式
    Cfull = [X'X X'W; W'X W'W .+ lam .* Ainv]
    rfull = [X'y; W'y]
    sol_c = Cfull \ rfull
    # 联邦式：各机构持有不相交的个体子集的记录
    parts = [collect(k:nk:n) for k in 1:nk]
    Csum = zeros(size(Cfull)); rsum = zeros(length(rfull))
    for idx in parts
        Xk = X[idx, :]; Wk = W[idx, :]; yk = y[idx]
        Ck = [Xk'Xk Xk'Wk; Wk'Xk Wk'Wk]         # 本地计算，只共享这个
        rk = [Xk'yk; Wk'yk]
        Csum .+= Ck; rsum .+= rk
    end
    Csum[2:end, 2:end] .+= lam .* Ainv          # 系谱部分由协调方加入
    sol_f = Csum \ rsum
    check("式 (35.19)：联邦求解 = 集中求解", sol_f, sol_c; tol=1e-10)
    global fed_ok = relerr(sol_f, sol_c) < 1e-10
end

# %% [markdown]
# ## 7　自检汇总

# %%
ok = Bool[]
push!(ok, check("两层 ΔG = π's", dG2, 1.0; tol=1e-10))
push!(ok, check("两层滞后 = 2ΔG", d2[1]-d2[2], 2dG2; tol=1e-8))
push!(ok, check("三层迭代 = π's", inc3, fill(dG3, 6); tol=1e-8))
push!(ok, abs(pi3[5]) < 1e-10 && abs(pi3[6]) < 1e-10)
@printf("商品群的长期遗传贡献 π = (%.2e, %.2e) ✔\n", pi3[5], pi3[6])
push!(ok, fed_ok)
push!(ok, optimal_N(cost; Ncomm=1e6) > optimal_N(cost; Ncomm=1e4))
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
