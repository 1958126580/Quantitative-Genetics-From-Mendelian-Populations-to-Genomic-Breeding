# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_textnums.py    依赖：仅标准库
# prints the rounded forms used in the text of §35.1.5-6
import json
r = json.load(open('s1_lag.json'))
d = r['rand_NS']['gapC'] - r['best_AI']['gapC']
print('steady diff 3dp: %.3f' % d)
print('AI saves (2dp): best %.2f  rand %.2f' % (r['best_NS']['lagC'] - r['best_AI']['lagC'], r['rand_NS']['lagC'] - r['rand_AI']['lagC']))
sn = json.load(open('s1_sens.json'))
ai = [a for a in sn['actions'] if a['name'] == 'comm NS->AI'][0]
print('AI lag reduction 2dp: %.2f' % (sn['base']['lagC'] - ai['lagC']))
print('AI NPV yi: %.1f' % (ai['npv20'] / 1e4))
print('Etau C AI %.2f NS %.2f' % (r['best_AI']['EtC'], r['best_NS']['EtC']))
