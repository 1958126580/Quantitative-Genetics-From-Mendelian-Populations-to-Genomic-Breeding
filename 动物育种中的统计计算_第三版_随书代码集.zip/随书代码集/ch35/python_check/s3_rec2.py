# -*- coding: utf-8 -*-
"""§35.3.6 recessive lethal management (deterministic, infinite population), corrected accounting.
State: H = carrier fraction among live candidates (q = H/2 = allele frequency among live animals).
EBV of a candidate = u + delta*c, u ~ N(0,1) (polygenic, standardized), c = carrier indicator;
delta = merit of a favourable allele tightly linked to the defect (0 = independent).
Genetic level = mean(u) + delta*H.  Sires: top 5 %, dams: top 30 % on EBV (or on EBV - pen*c)."""
import numpy as np, sys
from scipy.stats import norm
from scipy.optimize import brentq

pm, pf = 0.05, 0.30

def select(H, p, delta, mode, pen=0.0):
    """returns (carrier fraction among selected, mean EBV of selected)"""
    if mode == 'exclude':
        if p > 1 - H: raise ValueError('not enough non-carriers')
        x = norm.isf(p / (1 - H))
        return 0.0, norm.pdf(x) / norm.sf(x)
    shift = delta - pen
    x = brentq(lambda x: H * norm.sf(x - shift) + (1 - H) * norm.sf(x) - p, -20, 20, xtol=1e-14)
    ps = norm.sf(x - shift)
    hc = H * ps / p
    m = (H * (shift * ps + norm.pdf(x - shift) + pen * ps) + (1 - H) * norm.pdf(x)) / p
    return hc, m

def mate(hs, hd, avoid):
    mcc = hs * hd if not avoid else max(0.0, hs + hd - 1)
    if not avoid:
        paa = hs * hd / 4
        pAa = (hs + hd) / 2 - hs * hd / 2
    else:
        paa = mcc / 4
        pAa = (hs - mcc) / 2 + (hd - mcc) / 2 + mcc / 2
    return paa, pAa / (1 - paa)

STRATS = [('A', 'none', dict(sire='trunc', dam='trunc', avoid=False)),
          ('B', 'cull carrier sires', dict(sire='exclude', dam='trunc', avoid=False)),
          ('B2', 'cull all carriers', dict(sire='exclude', dam='exclude', avoid=False)),
          ('C', 'avoid CxC', dict(sire='trunc', dam='trunc', avoid=True)),
          ('D', 'penalty 0.5', dict(sire='pen', dam='pen', avoid=False, pen=0.5))]

def step(H, delta, s):
    def sel(p, mode):
        return select(H, p, delta, 'exclude' if mode == 'exclude' else 'trunc' if mode == 'trunc' else 'pen',
                      s.get('pen', 0.0) if mode == 'pen' else 0.0)
    hs, ms = sel(pm, s['sire']); hd, md = sel(pf, s['dam'])
    Su_m, Su_f = ms - delta * hs, md - delta * hd          # polygenic selection differentials
    paa, Hn = mate(hs, hd, s['avoid'])
    dG = 0.5 * (Su_m + Su_f) + delta * (Hn - H)
    return dict(hs=hs, hd=hd, paa=paa, Hn=Hn, dG=dG, feas=(not s['avoid']) or hs + hd <= 1)

deltas = [float(x) for x in sys.argv[1:]] or [0.0, 0.2, 0.5]
for delta in deltas:
    print('=== delta %.1f : one generation ===' % delta)
    for q in (0.01, 0.05, 0.10, 0.20, 0.30):
        H = 2 * q
        A = step(H, delta, STRATS[0][2])
        for code, name, s in STRATS:
            try: o = step(H, delta, s)
            except ValueError: print('  q %.2f %-3s infeasible' % (q, code)); continue
            print('  q %.2f H %.2f %-3s %-20s dG=%.4f loss=%6.2f%% affected/1e4=%7.2f q_next=%.4f hs=%.4f hd=%.4f feas=%s' % (
                q, H, code, name, o['dG'], 100 * (1 - o['dG'] / A['dG']), o['paa'] * 1e4, o['Hn'] / 2, o['hs'], o['hd'], o['feas']))
    print('=== delta %.1f : 10 generations ===' % delta)
    for q0 in (0.05, 0.20):
        base = None
        for code, name, s in STRATS:
            H = 2 * q0; G = 0.0; aff = 0.0; qs = [q0]; firstinf = None
            for g in range(1, 11):
                o = step(H, delta, s)
                if not o['feas'] and firstinf is None: firstinf = g
                G += o['dG']; aff += o['paa']; H = o['Hn']; qs.append(H / 2)
            if base is None: base = G
            print('  q0 %.2f %-3s %-20s q5=%.4f q10=%.4f mean affected/1e4/gen=%8.2f G10=%.4f (%.2f%% of A) first infeasible gen=%s' % (
                q0, code, name, qs[5], qs[10], aff / 10 * 1e4, G, 100 * G / base, firstinf))
