# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_ocs_an.py    依赖：numpy
import json, numpy as np
d = json.load(open('s3_ocs_res.json'))
g = np.arange(1, 15)
man = (g >= 5)   # managed generations 5..14
print('theory random (34.2): Ne = %.1f, dF = %.4f' % (4 * 10 * 40 / 50, 1 / (2 * 4 * 10 * 40 / 50)))
res = {}
for st in ('R', 'E', 'O'):
    F = np.array(d[st]['F']); C = np.array(d[st]['C'])
    # per-replicate regression of ln(1-C) on generation over managed gens (5..14), and including g4 as start
    sl = []; slF = []
    for r in range(C.shape[0]):
        x = g[3:]; y = np.log(1 - C[r, 3:]); b = np.polyfit(x, y, 1)[0]; sl.append(1 - np.exp(b))
        yF = np.log(1 - F[r, 3:]); bF = np.polyfit(x, yF, 1)[0]; slF.append(1 - np.exp(bF))
    sl = np.array(sl); slF = np.array(slF)
    Cm = C.mean(0); Fm = F.mean(0)
    bm = np.polyfit(g[3:], np.log(1 - Cm[3:]), 1)[0]; dF = 1 - np.exp(bm)
    bFm = np.polyfit(g[3:], np.log(1 - Fm[3:]), 1)[0]; dFF = 1 - np.exp(bFm)
    c0 = np.mean([c[0] for c in d[st]['contrib']])
    res[st] = dict(dF=dF, Ne=1 / (2 * dF), dFF=dFF, NeF=1 / (2 * dFF), C14=Cm[-1], F14=Fm[-1], c0=c0,
                   sd=sl.std(ddof=1), se=sl.std(ddof=1) / np.sqrt(len(sl)), meanrep=sl.mean())
    print('%s: C4=%.4f C14=%.4f F14=%.4f  dF(C)=%.4f Ne=%.1f | dF(F)=%.4f Ne=%.1f | per-rep dF mean %.4f sd %.4f se %.4f | first decision c\'Ac/2=%.4f' % (
        st, Cm[3], Cm[-1], Fm[-1], dF, 1 / (2 * dF), dFF, 1 / (2 * dFF), sl.mean(), sl.std(ddof=1), sl.std(ddof=1) / np.sqrt(len(sl)), c0))
print('Ne ratio E/R %.4f O/R %.4f O/E %.4f' % (res['E']['Ne'] / res['R']['Ne'], res['O']['Ne'] / res['R']['Ne'], res['O']['Ne'] / res['E']['Ne']))
L = d['O']['logs']
for k in ('C_all', 'free', 'relaxed', 'rounded', 'final', 'swaps', 'nfree_m', 'nfree_f'):
    v = np.array([l[k] for l in L], dtype=float)
    print('O first decision %-8s mean %.4f  min %.4f max %.4f' % (k, v.mean(), v.min(), v.max()))
v = np.array([(l['final'] - l['free']) / l['free'] for l in L]); print('gap final vs free %.4f' % v.mean())
v = np.array([(l['rounded'] - l['final']) for l in L]); print('swap gain %.4f' % v.mean())
# self-coancestry term with 10+40 equal use
print('self term 10+40: %.5f' % ((10 * (0.05) ** 2 + 40 * (1 / 80) ** 2) / 2))
json.dump(res, open('s3_ocs_summary.json', 'w'), indent=1)
