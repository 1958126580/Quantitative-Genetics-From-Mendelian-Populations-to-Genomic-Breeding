# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4_scale.py    依赖：numpy
"""§35.4.9 order-of-magnitude scale analysis for five of the ten open problems. All hardware numbers are example assumptions."""
import numpy as np

FLOPS_NODE = 1e12      # sustained double precision, one node
FLOPS_1T = 2e9         # sustained, single thread
MEM = 1e12             # bytes (1 TB)
BW = 200e9             # bytes/s
B8 = 8.0

def fmt_time(s):
    if s < 1: return '%.0f ms' % (s * 1000)
    if s < 60: return '%.1f s' % s
    if s < 3600: return '%.1f min' % (s / 60)
    if s < 86400: return '%.1f h' % (s / 3600)
    if s < 365 * 86400: return '%.1f d' % (s / 86400)
    return '%.1f yr' % (s / 86400 / 365)

def fmt_bytes(b):
    for u, f in (('TB', 1e12), ('GB', 1e9), ('MB', 1e6)):
        if b >= f: return '%.1f %s' % (b / f, u)
    return '%.0f B' % b

print('=== Problem 1: explicit dense A22^-1 vs APY (n_c = 15000) ===')
nc = 15000
for n2 in (1e5, 1e6, 1e7):
    dense_mem = n2 ** 2 * B8
    dense_t = n2 ** 3 / FLOPS_NODE                   # ~ n^3 flops (Cholesky + inverse)
    nn = n2 - nc
    apy_mem = (nc ** 2 + nn * nc) * B8               # core inverse + P = G_nc G_cc^-1
    apy_build = (nn * nc ** 2 + nc ** 3) / FLOPS_NODE
    apy_apply = 2 * (nn * nc + nc ** 2) / FLOPS_NODE  # one product G_APY^-1 v
    print('n2=%.0e  dense: %s, %s | APY: %s, build %s, apply %s  (dense/APY memory ratio %.0f)' % (
        n2, fmt_bytes(dense_mem), fmt_time(dense_t), fmt_bytes(apy_mem), fmt_time(apy_build), fmt_time(apy_apply), dense_mem / apy_mem))

print('=== Problem 2: exact AI-REML (dense, genomic) vs Hutchinson + PCG ===')
m = 5e4; S = 30; it_pcg = 100; it_reml = 20
for n in (1e5, 1e6, 1e7):
    exact_iter = n ** 3 / FLOPS_NODE                 # factorisation + selected inverse ~ n^3
    matvec = 4 * n * m                               # G v via Z (Z' v then Z w), 2 flops per multiply-add
    stoch_iter = (S + 1) * it_pcg * matvec / FLOPS_NODE
    print('n=%.0e  exact: per iter %s, total %s, memory %s | stochastic: per iter %s, total %s, genotypes %s' % (
        n, fmt_time(exact_iter), fmt_time(exact_iter * it_reml), fmt_bytes(n * n * B8),
        fmt_time(stoch_iter), fmt_time(stoch_iter * it_reml), fmt_bytes(n * m / 4)))
print('probes for 10x smaller MC error: %d (cost x %d)' % (S * 100, 100))

print('=== Problem 3: BayesR, n = m = 1e6, 20 000 iterations ===')
n = m3 = 1e6; iters = 20000
flops_iter = 4 * n * m3
geno_2bit = n * m3 / 4; geno_i8 = n * m3; geno_f64 = n * m3 * 8
print('flops/iter %.1e | genotypes 2-bit %s, int8 %s, float64 %s' % (flops_iter, fmt_bytes(geno_2bit), fmt_bytes(geno_i8), fmt_bytes(geno_f64)))
t1 = flops_iter / FLOPS_1T; tp = flops_iter / FLOPS_NODE; tb = geno_2bit / BW
print('single thread: %s/iter, chain %s | ideal node: %s/iter, chain %s | streaming 2-bit genotypes %s/iter' % (
    fmt_time(t1), fmt_time(t1 * iters), fmt_time(tp), fmt_time(tp * iters), fmt_time(tb)))
print('ratio single/ideal = %.0f ; sync points per iteration = %.0e' % (t1 / tp, m3))

print('=== Problem 4: G o G ===')
for nn_ in (1e5, 1e6):
    print('n=%.0e dense storage %s, factorisation %s' % (nn_, fmt_bytes(nn_ ** 2 * B8), fmt_time(nn_ ** 3 / 3 / FLOPS_NODE)))
for mm in (5e4, 6e5):
    print('m=%.0e  rank bound m(m+1)/2 = %.3e' % (mm, mm * (mm + 1) / 2))
rng = np.random.default_rng(35049)
for (nn_, mm) in ((300, 10), (300, 20), (300, 30)):
    p = rng.uniform(0.1, 0.5, mm)
    Z = rng.binomial(2, p, size=(nn_, mm)).astype(float) - 2 * p
    G = Z @ Z.T / (2 * np.sum(p * (1 - p)))
    H = G * G
    rG = np.linalg.matrix_rank(G, tol=1e-8 * np.linalg.norm(G, 2))
    rH = np.linalg.matrix_rank(H, tol=1e-8 * np.linalg.norm(H, 2))
    print('n=%d m=%d: rank(G)=%d  rank(G o G)=%d  bound min(n, m(m+1)/2)=%d' % (nn_, mm, rG, rH, min(nn_, mm * (mm + 1) // 2)))

print('=== Problem 8: dynamic programming grid ===')
k = 50; U = 20; T = 20
for cost, lab in ((1e-3, 'deterministic 1 ms'), (10.0, 'stochastic simulation 10 s')):
    for d in (1, 2, 3, 4, 6):
        states = k ** d
        t = T * states * U * cost
        print('%-26s d=%d states=%.3e total=%s' % (lab, d, states, fmt_time(t)))
print('notebook example: 41 states x 5 actions x 10 stages = %d evaluations' % (41 * 5 * 10))

print('=== Problem 7: joint mate selection ===')
ns, nd = 1e3, 1e4
print('binary variables %.0e ; log10(number of sire assignments) = %.0f' % (ns * nd, nd * np.log10(ns)))
print('=== 2-decimal checks ===')
for n in (1e5, 1e6, 1e7):
    print('genotypes 2-bit n=%.0e m=5e4: %.2f GB' % (n, n * 5e4 / 4 / 1e9))
print('BayesR streaming 2-bit per iteration: %.2f s ; ideal compute %.2f s' % (1e6 * 1e6 / 4 / BW, 4e12 / FLOPS_NODE))
print('dense A22 n2=1e6 memory / node memory = %.0f' % (1e12 * 8 / MEM))
print('BayesR chain single thread: %.2f yr' % (4e12 / FLOPS_1T * 20000 / 86400 / 365))
