# 第 35 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch35/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `s1_early.py` | 数值复核 | numpy, scipy | 1.6 | `outputs/s1_early.out` |
| `s1_extra.py` | 数值复核 | numpy, scipy | 1.3 | `outputs/s1_extra.out` |
| `s1_sens.py` | §35.1.6 bottleneck sensitivity: one change at a time relative to baseline (2nd-tier boars to multiplier, natural service). | numpy, scipy | 1.8 | `outputs/s1_sens.out` |
| `s1_textnums.py` | prints the rounded forms used in the text of §35.1.5-6 | 标准库 | 0.0 | `outputs/s1_textnums.out` |
| `s1_traj.py` | §35.1.5 year-by-year transmission from a start with all cohort means 0 (selection starts at t=0). | numpy, scipy | 1.5 | `outputs/s1_traj.out` |
| `s2_geno2.py` | optimal selective genotyping under different commercial sizes (LD chip) | numpy, scipy | 29.2 | `outputs/s2_geno2.out` |
| `s2_ref_tab.py` | 数值复核 | numpy, scipy | 1.6 | `outputs/s2_ref_tab.out` |
| `s3_ocs_an.py` | per-replicate regression of ln(1-C) on generation over managed gens (5..14), and including g4 as start | numpy | 0.3 | `outputs/s3_ocs_an.out` |
| `s3_rec.py` | §35.3.6 recessive lethal: cull carriers vs avoid carrier x carrier matings vs index penalty (deterministic, infinite population). | numpy, scipy | 2.9 | `outputs/s3_rec.out` |
| `s3_rec3.py` | 数值复核 | numpy, scipy | 2.8 | `outputs/s3_rec3.out` |
| `s4_scale.py` | §35.4.9 order-of-magnitude scale analysis for five of the ten open problems. All hardware numbers are example assumptions. | numpy | 0.3 | `outputs/s4_scale.out` |

公共函数模块（被上列脚本导入，不单独运行）：`pyramid.py`、`s1_lag.py`、`s2_geno.py`、`s2_ref.py`、`s3_rec2.py`。
