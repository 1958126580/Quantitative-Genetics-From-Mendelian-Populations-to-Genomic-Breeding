# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_traj.py    依赖：numpy
"""§35.1.5 year-by-year transmission from a start with all cohort means 0 (selection starts at t=0)."""
import numpy as np
from pyramid import *
import s1_lag as S

for key in (('rand', 'NS'), ('best', 'AI')):
    P, s, idx = build(S.scen(*key))
    o = lag_analysis(P, s, idx)
    tr = iterate(P, s, np.zeros(len(s)), 40)
    n0, m0, c0 = idx[('N', 0)], idx[('M', 0)], idx[('C', 0)]
    print(key, 'dG', round(o['dG'], 4), 'steady gaps N-M', round(o['lag'][m0] * o['dG'], 4), 'N-C', round(o['lag'][c0] * o['dG'], 4))
    for t in list(range(1, 11)) + [15, 20, 40]:
        N, M, C = tr[t][n0], tr[t][m0], tr[t][c0]
        print(f'  t={t:2d}  N0={N:.4f}  M0={M:.4f}  C0={C:.4f}  N-C={N-C:.4f}  (N-C)/dG={(N-C)/o["dG"]:.4f}  incN={tr[t][n0]-tr[t-1][n0]:.4f} incC={tr[t][c0]-tr[t-1][c0]:.4f}')

# economic translation (example assumption values)
v = 20.0      # yuan per sigma_A per slaughter pig
Ncomm = 1e6   # slaughter pigs per year
g1 = S.res['rand_NS']['gapC']; g2 = S.res['best_AI']['gapC']
print('gap rand_NS %.4f best_AI %.4f diff %.4f  value/yr = %.1f wan yuan  per pig %.2f yuan' % (g1, g2, g1 - g2, (g1 - g2) * v * Ncomm / 1e4, (g1 - g2) * v))
for k, r in S.res.items():
    print(k, 'gapC %.4f value vs rand_NS per pig %.2f yuan, total %.1f wan' % (r['gapC'], (g1 - r['gapC']) * v, (g1 - r['gapC']) * v * Ncomm / 1e4))
