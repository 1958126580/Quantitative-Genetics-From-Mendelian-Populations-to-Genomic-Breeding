# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_extra.py    依赖：numpy
import json, numpy as np
from pyramid import *
import s1_lag as S
r = S.res; Lbar = (1.30 + 1.85) / 2
print('Lbar', Lbar)
for k, v in r.items():
    print(k, 'lagM %.4f lagC %.4f lagC/Lbar %.4f gapC %.4f gapM %.4f' % (v['lagM'], v['lagC'], v['lagC'] / Lbar, v['gapC'], v['lagM'] * v['dG']))
print('ratio worst/best lagC %.4f' % (r['rand_NS']['lagC'] / r['best_AI']['lagC']))
for m in ('best', '2nd', 'rand'):
    print(m, 'AI saves %.4f years' % (r[m + '_NS']['lagC'] - r[m + '_AI']['lagC']))
print('mult best vs rand saves %.4f years (=S/dG %.4f)' % (r['rand_AI']['lagM'] - r['best_AI']['lagM'], S.SNm / r['best_AI']['dG']))
print('commercial: best vs rand, AI %.4f NS %.4f' % (r['rand_AI']['lagC'] - r['best_AI']['lagC'], r['rand_NS']['lagC'] - r['best_NS']['lagC']))
# year-10 fraction of steady gap
for key in (('rand', 'NS'), ('best', 'AI')):
    P, s, idx = build(S.scen(*key)); o = lag_analysis(P, s, idx)
    tr = iterate(P, s, np.zeros(len(s)), 40)
    n0, c0 = idx[('N', 0)], idx[('C', 0)]
    g = o['lag'][c0] * o['dG']
    for t in (5, 10, 15):
        print(key, 't', t, 'gap frac %.4f' % ((tr[t][n0] - tr[t][c0]) / g), 'incC/dG %.4f' % ((tr[t][c0] - tr[t - 1][c0]) / o['dG']))
# closed-form (35.8b) check
dG = r['best_AI']['dG']
lM = 1.30 + 1.85 - S.SNm / dG
lC_AI = 0.5 * (0 + 1.30 - S.SNm / dG) + 0.5 * (lM + 2.15)
lC_NS = 0.5 * (lM + 1.85 - S.SNS / dG) + 0.5 * (lM + 2.15)
print('closed form: lM %.4f lC_AI %.4f lC_NS %.4f  S_NS/dG %.4f S/dG %.4f' % (lM, lC_AI, lC_NS, S.SNS / dG, S.SNm / dG))
print('gene-age cdf AI', np.round(r['best_AI']['cdfC'], 4))
print('gene-age cdf NS', np.round(r['best_NS']['cdfC'], 4))
