# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_early.py    依赖：numpy
import numpy as np
from pyramid import *
import s1_lag as S
tr = {}
for key in (('rand', 'NS'), ('best', 'AI')):
    P, s, idx = build(S.scen(*key)); tr[key] = iterate(P, s, np.zeros(len(s)), 60)
c0 = idx[('C', 0)]
steady = S.res['rand_NS']['gapC'] - S.res['best_AI']['gapC']
for t in (1, 3, 5, 10):
    d = tr[('best', 'AI')][t][c0] - tr[('rand', 'NS')][t][c0]
    print('t', t, 'commercial diff %.4f  frac of steady %.4f  steady %.4f' % (d, d / steady, steady))
print('ratio 3dp %.2f' % (S.res['rand_NS']['lagC'] / S.res['best_AI']['lagC']))
