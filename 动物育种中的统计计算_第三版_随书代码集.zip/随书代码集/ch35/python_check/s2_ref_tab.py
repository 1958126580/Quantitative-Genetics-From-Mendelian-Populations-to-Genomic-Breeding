# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_ref_tab.py    依赖：仅标准库
from s2_ref import *
print('=== sensitivity table ===')
base = Nstar()
def row(lbl, n_, rr):
    print('%-28s N*=%7.0f r=%.4f ratio=%.4f' % (lbl, n_, rr, n_ / base))
row('base', base, r(base))
for Nc in (1e4, 1e5, 1e7):
    n_ = Nstar(Ncomm=Nc); row('Ncomm %.0e' % Nc, n_, r(n_))
for hh in (0.10, 0.50):
    n_ = Nstar(h2=hh); row('h2 %.2f' % hh, n_, r(n_, hh))
for c in (225.0, 900.0, 1800.0):
    n_ = Nstar(cost=c); row('cost %.0f' % c, n_, r(n_))
n_ = Nstar(Me=Me_H); row('Me Hayes', n_, r(n_, Me=Me_H))
f = lambda lnN: v * iL * dr(np.exp(lnN)) * Ncomm * D2 - cost
n_ = float(np.exp(brentq(f, 0, np.log(1e9)))); row('lag 1.2832', n_, r(n_))
print('Ncomm 1e4 net %.1f wan' % ((benefit(Nstar(Ncomm=1e4), Ncomm=1e4) - cost * Nstar(Ncomm=1e4)) / 1e4))
