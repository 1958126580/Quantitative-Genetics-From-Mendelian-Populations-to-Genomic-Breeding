# -*- coding: utf-8 -*-
"""§35.2.7 reference population: marginal return curve and optimum (eqs 35.9-35.12), example values."""
import numpy as np, json
from scipy.optimize import brentq
from pyramid import i_trunc

h2 = 0.30
Ne, Lg = 100, 25.0
Me_G = 2 * Ne * Lg / np.log(4 * Ne * Lg)       # eq 20.32 (Goddard)
Me_H = 2 * Ne * Lg                              # eq 20.31 (Hayes)
iL = (i_trunc(0.05) + i_trunc(0.30)) / (1.30 + 1.85)   # i / Lbar from §35.1.5 nucleus
v = 20.0          # yuan per sigma_A per commercial pig
Ncomm = 1e6
rho = 0.05
T = 15
lag = 3.4841      # commercial lag of baseline system (§35.1.6)
cost = 450.0      # phenotype 300 + genotype 150

def D(lag=lag, T=T, rho=rho):
    return sum((t - lag) / (1 + rho) ** t for t in range(1, T + 1) if t > lag)

def r(N, h2=h2, Me=Me_G):
    return np.sqrt(N * h2 / (N * h2 + Me))

def dr(N, h2=h2, Me=Me_G):
    return 1 / (2 * r(N, h2, Me)) * Me * h2 / (N * h2 + Me) ** 2

def benefit(N, h2=h2, Me=Me_G, Ncomm=Ncomm):
    return v * iL * r(N, h2, Me) * Ncomm * D()

def mbenefit(N, h2=h2, Me=Me_G, Ncomm=Ncomm):
    return v * iL * dr(N, h2, Me) * Ncomm * D()

def Nstar(h2=h2, Me=Me_G, Ncomm=Ncomm, cost=cost):
    f = lambda lnN: mbenefit(np.exp(lnN), h2, Me, Ncomm) - cost
    lo, hi = np.log(1.0), np.log(1e9)
    if f(lo) < 0: return 0.0
    return float(np.exp(brentq(f, lo, hi, xtol=1e-12)))

print('Me Goddard %.1f  Hayes %.0f  i/Lbar %.4f  D %.4f' % (Me_G, Me_H, iL, D()))
print('value of +1 sigma_A/yr in dG sustained: v*Ncomm*D = %.1f wan yuan' % (v * Ncomm * D() / 1e4))
rows = []
for N in (1000, 2000, 5000, 10000, 20000, 30000, 50000, 100000):
    B = benefit(N); mB = mbenefit(N)
    rows.append((N, r(N), iL * r(N), mB, B / 1e4, (B - cost * N) / 1e4, B / N))
    print('N=%6d r=%.4f dG=%.4f margNPV/animal=%9.1f  B=%.1f wan  net=%.1f wan  avg/animal=%.1f' % rows[-1])
Ns = Nstar()
print('N* = %.0f  r(N*) = %.4f  dG = %.4f  B = %.1f wan  net = %.1f wan  avg B/N* = %.1f  cost*N* = %.1f wan' % (
    Ns, r(Ns), iL * r(Ns), benefit(Ns) / 1e4, (benefit(Ns) - cost * Ns) / 1e4, benefit(Ns) / Ns, cost * Ns / 1e4))
# check it is the max of net
grid = np.exp(np.linspace(np.log(1000), np.log(200000), 20001))
net = benefit(grid) - cost * grid
print('grid argmax N = %.0f (net %.1f wan)' % (grid[np.argmax(net)], net.max() / 1e4))
# sensitivity
print('--- N* sensitivity ---')
for Nc in (1e4, 1e5, 1e6, 1e7):
    n_ = Nstar(Ncomm=Nc); print('Ncomm %.0e  N* %.0f  r %.4f  net %.1f wan' % (Nc, n_, r(n_) if n_ > 0 else 0, (benefit(n_, Ncomm=Nc) - cost * n_) / 1e4 if n_ > 0 else 0))
for hh in (0.10, 0.30, 0.50):
    n_ = Nstar(h2=hh); print('h2 %.2f N* %.0f r %.4f' % (hh, n_, r(n_, hh)))
n_ = Nstar(Me=Me_H); print('Me Hayes N* %.0f r %.4f net %.1f wan' % (n_, r(n_, Me=Me_H), (benefit(n_, Me=Me_H) - cost * n_) / 1e4))
for c in (225.0, 900.0, 1800.0):
    n_ = Nstar(cost=c); print('cost %.0f N* %.0f r %.4f' % (c, n_, r(n_)))
print('ratio N*(1e7)/N*(1e6) = %.4f ; N*(1e6)/N*(1e5) = %.4f' % (Nstar(Ncomm=1e7) / Nstar(Ncomm=1e6), Nstar(Ncomm=1e6) / Nstar(Ncomm=1e5)))
# using the reference population N* chosen with Goddard Me, but truth is Hayes Me: realized net
n_g = Ns
print('if truth is Hayes Me but N* chosen with Goddard: r_true %.4f  net_true %.1f wan ; optimum under Hayes net %.1f wan' % (
    r(n_g, Me=Me_H), (benefit(n_g, Me=Me_H) - cost * n_g) / 1e4, (benefit(Nstar(Me=Me_H), Me=Me_H) - cost * Nstar(Me=Me_H)) / 1e4))
# lag sensitivity: best+AI lag
lag2 = 1.2832
D2 = sum((t - lag2) / (1 + rho) ** t for t in range(1, T + 1) if t > lag2)
f = lambda lnN: v * iL * dr(np.exp(lnN)) * Ncomm * D2 - cost
print('D with lag 1.2832 = %.4f ; N* = %.0f' % (D2, np.exp(brentq(f, 0, np.log(1e9)))))
json.dump(dict(Me_G=Me_G, iL=iL, D=D(), Nstar=Ns), open('s2_ref.json', 'w'))
print('--- extra ---')
netf = lambda N, Me=Me_G: benefit(N, Me=Me) - cost * N
Nmax = netf(Ns)
for fac in (0.25, 0.5, 2.0, 4.0):
    print('net at %.2f N* = %.1f wan, loss vs max %.2f%%' % (fac, netf(fac * Ns) / 1e4, 100 * (1 - netf(fac * Ns) / Nmax)))
# average-return rule: B(N)/N = cost
g = lambda lnN: benefit(np.exp(lnN)) / np.exp(lnN) - cost
Navg = np.exp(brentq(g, np.log(1e3), np.log(1e9)))
print('avg rule N = %.0f  net = %.1f wan  r = %.4f' % (Navg, netf(Navg) / 1e4, r(Navg)))
print('marg at N*: %.1f ; avg/marg = %.1f' % (mbenefit(Ns), benefit(Ns) / Ns / mbenefit(Ns)))
print('cost x2 ratio N* %.4f ; Me ratio %.4f ; Me_H/Me_G %.4f' % (Nstar(cost=900.) / Ns, Nstar(Me=Me_H) / Ns, Me_H / Me_G))
print('loss from Me misspec %.1f wan = %.2f%%' % (((benefit(Nstar(Me=Me_H), Me=Me_H) - cost * Nstar(Me=Me_H)) - (benefit(Ns, Me=Me_H) - cost * Ns)) / 1e4,
      100 * (1 - (benefit(Ns, Me=Me_H) - cost * Ns) / (benefit(Nstar(Me=Me_H), Me=Me_H) - cost * Nstar(Me=Me_H)))))
print('lag ratio N* %.4f  D ratio %.4f' % (48580 / Ns, D2 / D()))
print('first 10000 animals: B(10000)=%.1f wan vs B(N*)=%.1f wan, share %.4f' % (benefit(10000) / 1e4, benefit(Ns) / 1e4, benefit(10000) / benefit(Ns)))
