# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_geno2.py    依赖：numpy, scipy
import numpy as np
from scipy.optimize import brentq
from s2_geno import two_stage, i_trunc, rPA, rG, pm, pf, S_path, Lm, Lf, nm, nf, imp, cLD, ann
full = i_trunc(pm)
for rho in (rPA / rG, 0.5):
    f = lambda k: 1 - two_stage(pm, k * pm, rho)[0] / full - 0.05
    k5 = brentq(f, 1.01, 19.9, xtol=1e-6)
    print('rho %.4f : loss=5%% at phi/p = %.3f (phi = %.4f)' % (rho, k5, k5 * pm))
# optimal selective genotyping under different commercial sizes (LD chip)
base = (rPA * i_trunc(pm) + rPA * i_trunc(pf)) / (Lm + Lf)
rg = rG * imp
phis_m = [0.05, 0.075, 0.10, 0.125, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50, 0.70, 1.0]
phis_f = [0.0, 0.30, 0.40, 0.50, 0.60, 0.80, 1.0]
Sm = {ph: S_path(pm, ph, rg) for ph in phis_m}
Sf = {ph: (S_path(pf, ph, rg) if ph > 0 else rPA * i_trunc(pf)) for ph in phis_f}
for Nc in (1e5, 3e5, 1e6):
    vD = 20.0 * Nc * 41.6340
    best = None
    for a in phis_m:
        for b in phis_f:
            dG = (Sm[a] + Sf[b]) / (Lm + Lf)
            net = (dG - base) * vD - (nm * a + nf * b) * cLD * ann
            if best is None or net > best[0]: best = (net, a, b, dG)
    allnet = ((Sm[1.0] + Sf[1.0]) / (Lm + Lf) - base) * vD - (nm + nf) * cLD * ann
    print('Ncomm %.0e: best phi_m=%.3f phi_f=%.2f dG=%.4f net=%.1f wan ; LD-all net=%.1f wan' % (Nc, best[1], best[2], best[3], best[0] / 1e4, allnet / 1e4))
