# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_rec3.py    依赖：仅标准库
import sys
sys.argv = ['x', '0.0']
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    from s3_rec2 import step, STRATS
CD = dict(sire='pen', dam='pen', avoid=True, pen=0.5)
for delta in (0.0, 0.2):
    for q0 in (0.05, 0.20):
        base = None
        for name, s in (('A', STRATS[0][2]), ('D', STRATS[4][2]), ('C', STRATS[3][2]), ('D+C', CD)):
            H = 2 * q0; G = 0.0; aff = 0.0; qs = [q0]; firstinf = None
            for g in range(1, 11):
                o = step(H, delta, s)
                if not o['feas'] and firstinf is None: firstinf = g
                G += o['dG']; aff += o['paa']; H = o['Hn']; qs.append(H / 2)
            if base is None: base = G
            print('delta %.1f q0 %.2f %-4s q5=%.4f q10=%.4f affected/1e4/gen=%8.2f G10 rel A=%.2f%% first infeasible=%s' % (
                delta, q0, name, qs[5], qs[10], aff / 10 * 1e4, 100 * G / base, firstinf))
