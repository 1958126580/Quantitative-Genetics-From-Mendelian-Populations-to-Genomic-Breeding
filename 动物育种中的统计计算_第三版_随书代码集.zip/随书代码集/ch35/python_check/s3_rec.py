# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_rec.py    依赖：numpy, scipy
"""§35.3.6 recessive lethal: cull carriers vs avoid carrier x carrier matings vs index penalty (deterministic, infinite population).
Candidates = live offspring (aa die). Carrier fraction H among candidates (both sexes). EBV ~ N(delta*carrier, 1).
Sires: top p_m=5%, dams: top p_f=30% (on EBV or penalised EBV).  Gain in EBV-sd units (x r sigma_A)."""
import numpy as np, json
from scipy.stats import norm
from scipy.optimize import brentq

pm, pf = 0.05, 0.30

def select(H, p, delta, mode, pen=0.0):
    """returns (carrier fraction among selected, selection differential relative to candidate mean)"""
    popmean = H * delta
    if mode == 'exclude':
        if p > 1 - H: raise ValueError('not enough non-carriers')
        x = norm.isf(p / (1 - H))
        return 0.0, norm.pdf(x) / norm.sf(x) - popmean
    shift = delta - pen   # score mean of carriers
    f = lambda x: H * norm.sf(x - shift) + (1 - H) * norm.sf(x) - p
    x = brentq(f, -20, 20, xtol=1e-14)
    hc = H * norm.sf(x - shift) / p
    # mean true EBV of selected: carriers' EBV = score + pen
    mc = H * (shift * norm.sf(x - shift) + norm.pdf(x - shift)) + H * pen * norm.sf(x - shift)
    mn = (1 - H) * norm.pdf(x)
    return hc, (mc + mn) / p - popmean

def mate(hs, hd, avoid):
    if not avoid:
        paa = hs * hd / 4
        pAa = (hs + hd) / 2 - hs * hd / 2
    else:
        mcc = max(0.0, hs + hd - 1)
        paa = mcc / 4
        pAa = (hs - mcc) / 2 + (hd - mcc) / 2 + mcc / 2
    return paa, pAa / (1 - paa)

STRATS = {
    'A none': dict(sire='trunc', dam='trunc', avoid=False),
    'B cull carrier sires': dict(sire='exclude', dam='trunc', avoid=False),
    'B2 cull all carriers': dict(sire='exclude', dam='exclude', avoid=False),
    'C avoid CxC matings': dict(sire='trunc', dam='trunc', avoid=True),
    'D penalty 0.5 (sires+dams)': dict(sire='pen', dam='pen', avoid=False, pen=0.5),
}

def one_gen(q, delta, st):
    H = 2 * q                 # q = allele frequency among live candidates (no aa alive), H = carrier fraction
    s = STRATS[st]
    def sel(p, mode):
        if mode == 'trunc': return select(H, p, delta, 'trunc')
        if mode == 'exclude': return select(H, p, delta, 'exclude')
        return select(H, p, delta, 'pen', s.get('pen', 0))
    hs, Sm = sel(pm, s['sire']); hd, Sf = sel(pf, s['dam'])
    paa, Hn = mate(hs, hd, s['avoid'])
    return dict(H=H, hs=hs, hd=hd, Sm=Sm, Sf=Sf, dG=0.5 * (Sm + Sf), paa=paa, qn=Hn / 2)

print('=== one generation ===')
tabA = []
for delta in (0.0, 0.5):
    base = {}
    for q in (0.01, 0.05, 0.10, 0.20, 0.30):
        A = one_gen(q, delta, 'A none')
        for st in STRATS:
            try:
                o = one_gen(q, delta, st)
            except ValueError:
                print('delta %.1f q %.2f %-28s infeasible' % (delta, q, st)); continue
            loss = 100 * (1 - o['dG'] / A['dG'])
            tabA.append((delta, q, st, o['dG'], loss, o['paa'] * 1e4, o['qn'], o['hs'], o['hd']))
            print('delta %.1f q %.2f H %.4f %-28s dG=%.4f loss=%6.2f%% affected/1e4=%7.2f q_next=%.4f hs=%.4f hd=%.4f' % (
                delta, q, o['H'], st, o['dG'], loss, o['paa'] * 1e4, o['qn'], o['hs'], o['hd']))

print('=== 10 generations ===')
def run(q0, delta, st, G=10):
    q = q0; cumG = 0; cumA = 0; traj = [q0]; feas = True
    s = STRATS[st]
    for g in range(G):
        H = 2 * q
        def sel(p, mode):
            if mode == 'trunc': return select(H, p, delta, 'trunc')
            if mode == 'exclude': return select(H, p, delta, 'exclude')
            return select(H, p, delta, 'pen', s.get('pen', 0))
        hs, Sm = sel(pm, s['sire']); hd, Sf = sel(pf, s['dam'])
        if s['avoid'] and hs + hd > 1: feas = False
        paa, Hn = mate(hs, hd, s['avoid'])
        cumG += 0.5 * (Sm + Sf); cumA += paa
        q = Hn / 2; traj.append(q)
    return dict(q=traj, cumG=cumG, affected=cumA / G * 1e4, feas=feas)
res = {}
for delta in (0.0, 0.5):
    for q0 in (0.05, 0.20):
        A = run(q0, delta, 'A none')
        for st in STRATS:
            o = run(q0, delta, st)
            res[(delta, q0, st)] = o
            print('delta %.1f q0 %.2f %-28s q5=%.4f q10=%.4f  mean affected/1e4 per gen=%7.2f  cumG=%.4f (%.2f%% of A) feasible=%s' % (
                delta, q0, st, o['q'][5], o['q'][10], o['affected'], o['cumG'], 100 * o['cumG'] / A['cumG'], o['feas']))
# when does avoidance become infeasible if carriers are favoured?  hs+hd vs 1
for delta in (0.5, 1.0):
    for q0 in (0.05, 0.20):
        q = q0
        for g in range(1, 41):
            H = 2 * q
            hs, _ = select(H, pm, delta, 'trunc'); hd, _ = select(H, pf, delta, 'trunc')
            paa, Hn = mate(hs, hd, True); q = Hn / 2
            if hs + hd > 1:
                print('delta %.1f q0 %.2f: avoidance infeasible from generation %d (hs+hd=%.4f, q=%.4f)' % (delta, q0, g, hs + hd, q)); break
        else:
            print('delta %.1f q0 %.2f: feasible for 40 generations, q40=%.4f hs+hd=%.4f' % (delta, q0, q, hs + hd))
