# -*- coding: utf-8 -*-
"""Three-tier (nucleus N / multiplier M / commercial C) yearly gene-flow model.

State = unselected birth-cohort means by age:  N0..N(A-1), M0..M(A-1), C0.
Parents of age a (years at offspring birth) at time t+1 are the cohort stored as (X, a-1) at time t.
Selection differentials of the parents (relative to their own birth cohort) enter s in the newborn rows.
"""
import numpy as np
from scipy.stats import norm

def i_trunc(p):
    """selection intensity for truncation selection, infinite population"""
    x = norm.isf(p)
    return norm.pdf(x) / p

def i_band2(p1, p2):
    x1, x2 = norm.isf(p1), norm.isf(p2)   # x1 > x2
    # E[Z | x2 < Z < x1] = (phi(x2) - phi(x1)) / (Phi(x1) - Phi(x2))
    return (norm.pdf(x2) - norm.pdf(x1)) / (p2 - p1)

AMAX = 4  # max parental age (years)

def build(par):
    """par: dict with keys
       Nm_age, Nf_age : dicts age->proportion (nucleus boars / sows)
       SNm, SNf       : selection differentials of nucleus boars / sows (sigma_A units)
       Mm_age, SMm    : ages of nucleus boars used in multiplier and their differential
       Mf_age, SMf    : ages of multiplier sows (multiplier-born), differential
       Cm_src ('N' or 'M'), Cm_age, SCm : commercial boars: source tier, ages, differential
       Cf_age, SCf    : commercial sows (multiplier-born), ages, differential
    returns P, s, index dict"""
    A = AMAX
    idx = {}
    k = 0
    for X in ('N', 'M'):
        for a in range(A):
            idx[(X, a)] = k; k += 1
    idx[('C', 0)] = k; k += 1
    q = k
    P = np.zeros((q, q)); s = np.zeros(q)
    # ageing
    for X in ('N', 'M'):
        for a in range(1, A):
            P[idx[(X, a)], idx[(X, a - 1)]] = 1.0
    def add(row, tier, ages, w):
        for age, f in ages.items():
            P[row, idx[(tier, age - 1)]] += w * f
    # nucleus births
    r = idx[('N', 0)]
    add(r, 'N', par['Nm_age'], 0.5); add(r, 'N', par['Nf_age'], 0.5)
    s[r] = 0.5 * (par['SNm'] + par['SNf'])
    # multiplier births: sire = nucleus boar, dam = multiplier sow
    r = idx[('M', 0)]
    add(r, 'N', par['Mm_age'], 0.5); add(r, 'M', par['Mf_age'], 0.5)
    s[r] = 0.5 * (par['SMm'] + par['SMf'])
    # commercial births
    r = idx[('C', 0)]
    add(r, par['Cm_src'], par['Cm_age'], 0.5); add(r, 'M', par['Cf_age'], 0.5)
    s[r] = 0.5 * (par['SCm'] + par['SCf'])
    assert np.allclose(P.sum(1), 1.0)
    return P, s, idx

def stationary(P):
    w, V = np.linalg.eig(P.T)
    k = np.argmin(np.abs(w - 1))
    pi = np.real(V[:, k]); pi = pi / pi.sum()
    return pi

def lag_analysis(P, s, idx):
    pi = stationary(P)
    dG = pi @ s
    q = len(s)
    Aaug = np.vstack([np.eye(q) - P, pi[None, :]])
    baug = np.concatenate([s - dG, [0.0]])
    d, *_ = np.linalg.lstsq(Aaug, baug, rcond=None)
    res = np.linalg.norm((np.eye(q) - P) @ d - (s - dG))
    ref = d[idx[('N', 0)]]
    lag = (ref - d) / dG
    return dict(pi=pi, dG=dG, d=d, lag=lag, resid=res)

def iterate(P, s, m0, T):
    out = [m0.copy()]
    m = m0.copy()
    for _ in range(T):
        m = P @ m + s
        out.append(m.copy())
    return np.array(out)

def backward_decomp(P, s, idx, dG, start, tmax=200):
    """Backward random walk from `start` until first arrival at N0.
    Returns distribution of arrival time tau (years), E[tau], E[sum of s picked up on the way] (excluding s[N0])."""
    q = len(s)
    n0 = idx[('N', 0)]
    x = np.zeros(q); x[start] = 1.0
    w = np.zeros(tmax + 1)
    Es = 0.0
    # the walk starting at `start`: at step 0 we are at start; moving one step back = one year
    # s picked up: the s of every visited state before absorption (including start), except N0
    for t in range(1, tmax + 1):
        Es += x @ s  # s of current states (they are not N0, since N0 absorbed/removed)
        x = x @ P
        w[t] = x[n0]
        x[n0] = 0.0
    Etau = np.sum(np.arange(tmax + 1) * w)
    return w, Etau, Es, 1 - w.sum()
