# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 35 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_sens.py    依赖：numpy
"""§35.1.6 bottleneck sensitivity: one change at a time relative to baseline (2nd-tier boars to multiplier, natural service)."""
import numpy as np, json, copy
from pyramid import *
import s1_lag as S

def base_par():
    return dict(r_m=0.60, r_f=0.60, pm=0.05, pf=0.30,
                Nm_age={1: 0.70, 2: 0.30}, Nf_age={1: 0.40, 2: 0.35, 3: 0.25},
                Mm_age={1: 0.70, 2: 0.30}, mult='2nd', Mf_age={1: 0.40, 2: 0.35, 3: 0.25},
                comm='NS', Cf_age={1: 0.35, 2: 0.30, 3: 0.20, 4: 0.15})

def to_model(q):
    SNm = i_trunc(q['pm']) * q['r_m']; SNf = i_trunc(q['pf']) * q['r_f']
    par = dict(Nm_age=q['Nm_age'], Nf_age=q['Nf_age'], SNm=SNm, SNf=SNf,
               Mm_age=q['Mm_age'], Mf_age=q['Mf_age'], SMf=0.0, Cf_age=q['Cf_age'], SCf=0.0)
    par['SMm'] = {'best': SNm, '2nd': i_band2(0.05, 0.20) * q['r_m'], 'rand': 0.0}[q['mult']]
    if q['comm'] == 'AI':
        par.update(Cm_src='N', Cm_age={1: 0.70, 2: 0.30}, SCm=SNm)
    else:
        par.update(Cm_src='M', Cm_age={1: 0.40, 2: 0.35, 3: 0.25}, SCm=i_trunc(0.20) * 0.45)
    return par

v, Ncomm, rho = 20.0, 1e6, 0.05
b = base_par()
Pb, sb, idx = build(to_model(b)); ob = lag_analysis(Pb, sb, idx)
c0 = idx[('C', 0)]; n0 = idx[('N', 0)]
print('baseline dG %.4f lagC %.4f gapC %.4f' % (ob['dG'], ob['lag'][c0], ob['lag'][c0] * ob['dG']))
actions = [
    ('r_m 0.60->0.66', dict(r_m=0.66)),
    ('r_f 0.60->0.66', dict(r_f=0.66)),
    ('pm 5%->3%', dict(pm=0.03)),
    ('Nm_age ->0.9/0.1', dict(Nm_age={1: 0.90, 2: 0.10})),
    ('Nf_age ->0.50/0.35/0.15', dict(Nf_age={1: 0.50, 2: 0.35, 3: 0.15})),
    ('mult 2nd->best', dict(mult='best')),
    ('Mf_age faster', dict(Mf_age={1: 0.50, 2: 0.35, 3: 0.15})),
    ('comm NS->AI', dict(comm='AI')),
    ('Cf_age faster', dict(Cf_age={1: 0.45, 2: 0.30, 3: 0.15, 4: 0.10})),
]
out = []
T = 20
for name, ch in actions:
    q = copy.deepcopy(b); q.update(ch)
    P, s, _ = build(to_model(q)); o = lag_analysis(P, s, idx)
    # dynamic: start from baseline steady state m(0)=d_base, apply new policy
    tr = iterate(P, s, ob['d'].copy(), T)
    base_tr = np.array([ob['d'] + t * ob['dG'] for t in range(T + 1)])
    adv = tr[:, c0] - base_tr[:, c0]
    npv = sum(adv[t] * v * Ncomm / (1 + rho) ** t for t in range(1, T + 1))
    L_m = sum(a * f for a, f in q['Nm_age'].items()); L_f = sum(a * f for a, f in q['Nf_age'].items())
    rec = dict(name=name, dG=o['dG'], dGpct=100 * (o['dG'] / ob['dG'] - 1), lagC=o['lag'][c0],
               adv3=adv[3], adv5=adv[5], adv10=adv[10], adv20=adv[20], npv20=npv / 1e4, Lm=L_m, Lf=L_f)
    out.append(rec)
    print(f"{name:26s} dG={o['dG']:.4f} ({rec['dGpct']:+.2f}%) lagC={o['lag'][c0]:.4f} (d {o['lag'][c0]-ob['lag'][c0]:+.4f}) "
          f"adv3={adv[3]:.4f} adv5={adv[5]:.4f} adv10={adv[10]:.4f} adv20={adv[20]:.4f} NPV20={npv/1e4:.1f}wan Lm={L_m:.2f} Lf={L_f:.2f}")
# elasticities of dG (analytic): dG=(Sm+Sf)/(Lm+Lf)
SNm = i_trunc(0.05) * 0.6; SNf = i_trunc(0.30) * 0.6; Lm, Lf = 1.30, 1.85
print('elasticities: Sm %.4f Sf %.4f Lm %.4f Lf %.4f' % (SNm / (SNm + SNf), SNf / (SNm + SNf), -Lm / (Lm + Lf), -Lf / (Lm + Lf)))
print('i(0.03)=%.4f' % i_trunc(0.03))
json.dump(dict(base=dict(dG=ob['dG'], lagC=ob['lag'][c0]), actions=out), open('s1_sens.json', 'w'), indent=1, ensure_ascii=False)

# ---- extra: year-1 advantage, long-run gap, crossover years ----
T2 = 60
trs = {}
for name, ch in actions:
    q = copy.deepcopy(b); q.update(ch)
    P, s, _ = build(to_model(q)); o = lag_analysis(P, s, idx)
    tr = iterate(P, s, ob['d'].copy(), T2)
    base_tr = np.array([ob['d'] + t * ob['dG'] for t in range(T2 + 1)])
    trs[name] = tr[:, c0] - base_tr[:, c0]
    print(f"{name:26s} adv1={trs[name][1]:.4f} adv2={trs[name][2]:.4f} gap(lag*dG)={o['lag'][c0]*o['dG']:.4f} dgap={o['lag'][c0]*o['dG']-ob['lag'][c0]*ob['dG']:+.4f} -dG*dlag={-ob['dG']*(o['lag'][c0]-ob['lag'][c0]):.4f}")
def cross(a, b_):
    d = trs[a] - trs[b_]
    for t in range(1, T2 + 1):
        if d[t] > 0: return t
    return None
print('r_m overtakes mult-best at year', cross('r_m 0.60->0.66', 'mult 2nd->best'))
print('r_m overtakes comm-AI at year', cross('r_m 0.60->0.66', 'comm NS->AI'))
print('pm overtakes mult-best at year', cross('pm 5%->3%', 'mult 2nd->best'))
print('r_m overtakes Mf faster at', cross('r_m 0.60->0.66', 'Mf_age faster'), ' Cf faster at', cross('r_m 0.60->0.66', 'Cf_age faster'))
