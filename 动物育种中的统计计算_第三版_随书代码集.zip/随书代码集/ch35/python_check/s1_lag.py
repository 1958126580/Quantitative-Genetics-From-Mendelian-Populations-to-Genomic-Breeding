# -*- coding: utf-8 -*-
"""§35.1.5  three-tier pyramid: yearly gene flow, steady-state lags, scenarios."""
import numpy as np, json
from pyramid import *

r_N = 0.60                       # accuracy of nucleus selection (GS), both sexes
pm, pf = 0.05, 0.30              # nucleus selected proportions boars / sows
iNm, iNf = i_trunc(pm), i_trunc(pf)
SNm, SNf = iNm * r_N, iNf * r_N
# second-tier boars: ranked 5%..20%
i_2nd = i_band2(0.05, 0.20)
S_2nd = i_2nd * r_N
# commercial natural-service boars: multiplier-born, own-performance selection, p=0.20, r=0.45
iNS = i_trunc(0.20); SNS = iNS * 0.45

Nm_age = {1: 0.70, 2: 0.30}
Nf_age = {1: 0.40, 2: 0.35, 3: 0.25}
Mf_age = {1: 0.40, 2: 0.35, 3: 0.25}
Cf_age = {1: 0.35, 2: 0.30, 3: 0.20, 4: 0.15}
NS_age = {1: 0.40, 2: 0.35, 3: 0.25}
L = lambda d: sum(a * f for a, f in d.items())
print('i: boar %.4f sow %.4f 2nd-tier %.4f NS %.4f' % (iNm, iNf, i_2nd, iNS))
print('S: boar %.4f sow %.4f 2nd %.4f NS %.4f' % (SNm, SNf, S_2nd, SNS))
print('L: Nm %.2f Nf %.2f Mf %.2f Cf %.2f NS %.2f' % (L(Nm_age), L(Nf_age), L(Mf_age), L(Cf_age), L(NS_age)))
print('four-path check dG=(Sm+Sf)/(Lm+Lf)=%.4f' % ((SNm + SNf) / (L(Nm_age) + L(Nf_age))))

def scen(mult, comm):
    par = dict(Nm_age=Nm_age, Nf_age=Nf_age, SNm=SNm, SNf=SNf,
               Mm_age=Nm_age, Mf_age=Mf_age, SMf=0.0,
               Cf_age=Cf_age, SCf=0.0)
    par['SMm'] = {'best': SNm, '2nd': S_2nd, 'rand': 0.0}[mult]
    if comm == 'AI':
        par.update(Cm_src='N', Cm_age=Nm_age, SCm=SNm)
    else:
        par.update(Cm_src='M', Cm_age=NS_age, SCm=SNS)
    return par

res = {}
rows = []
for mult in ('best', '2nd', 'rand'):
    for comm in ('AI', 'NS'):
        P, s, idx = build(scen(mult, comm))
        o = lag_analysis(P, s, idx)
        nm0, nc0 = idx[('M', 0)], idx[('C', 0)]
        wC, EtC, EsC, remC = backward_decomp(P, s, idx, o['dG'], nc0)
        wM, EtM, EsM, remM = backward_decomp(P, s, idx, o['dG'], nm0)
        # verify decomposition
        lagC_dec = EtC - EsC / o['dG']; lagM_dec = EtM - EsM / o['dG']
        # iterate check
        traj = iterate(P, s, np.zeros(len(s)), 400)
        inc = traj[-1] - traj[-2]
        gapC = traj[-1][idx[('N', 0)]] - traj[-1][nc0]
        piN0 = o['pi'][idx[('N', 0)]]
        rows.append((mult, comm, o['dG'], o['lag'][nm0], o['lag'][nc0], EtM, EsM / o['dG'], EtC, EsC / o['dG'],
                     o['lag'][nc0] * o['dG'], np.cumsum(wC)[:6]))
        print(f"{mult:5s} {comm:3s} dG={o['dG']:.4f} piN0={piN0:.4f} 1/Lbar={2/(L(Nm_age)+L(Nf_age)):.4f} "
              f"lagM={o['lag'][nm0]:.4f} (dec {lagM_dec:.4f}; Etau {EtM:.4f}, Es/dG {EsM/o['dG']:.4f}) "
              f"lagC={o['lag'][nc0]:.4f} (dec {lagC_dec:.4f}; Etau {EtC:.4f}, Es/dG {EsC/o['dG']:.4f}) "
              f"gapC={o['lag'][nc0]*o['dG']:.4f} iter_gap={gapC:.4f} inc_range={inc.min():.6f},{inc.max():.6f} resid={o['resid']:.1e} rem={remC:.1e}")
        print('    commercial gene-age cdf (tau<=1..6):', np.round(np.cumsum(wC)[1:7], 4))
        res[mult + '_' + comm] = dict(dG=o['dG'], lagM=o['lag'][nm0], lagC=o['lag'][nc0], EtM=EtM, EsM=EsM / o['dG'],
                                      EtC=EtC, EsC=EsC / o['dG'], gapC=o['lag'][nc0] * o['dG'],
                                      cdfC=list(np.cumsum(wC)[:9]))

# two-tier check against eq (35.8)
P2 = np.array([[1.0, 0.0], [0.5, 0.5]]); s2 = np.array([1.0, 0.0])
pi2 = stationary(P2); dG2 = pi2 @ s2
Aaug = np.vstack([np.eye(2) - P2, pi2[None, :]]); d2 = np.linalg.lstsq(Aaug, np.concatenate([s2 - dG2, [0]]), rcond=None)[0]
print('two-tier: pi', pi2, 'dG', dG2, 'dN-dC', d2[0] - d2[1])

json.dump(res, open('s1_lag.json', 'w'), indent=1, ensure_ascii=False)
