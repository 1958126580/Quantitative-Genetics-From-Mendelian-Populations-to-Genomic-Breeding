# -*- coding: utf-8 -*-
"""§35.2.8 genotyping strategies: two-stage (PA -> genotype top phi -> GEBV) selection, exact bivariate-normal response."""
import numpy as np, json
from scipy.stats import norm, multivariate_normal
from scipy.integrate import quad
from scipy.optimize import brentq
from pyramid import i_trunc

rG = 0.60                          # GEBV accuracy (as in §35.1.5)
rPA = 0.5 * np.sqrt(rG**2 + rG**2) # parent average from two parents with GEBV accuracy 0.60
rho = rPA / rG

def two_stage(p, phi, rho):
    """E[Z2 | Z1 > x1, Z2 > x2] with P(Z1>x1)=phi, P(Z1>x1,Z2>x2)=p. Returns (mean, x2)."""
    if phi <= p + 1e-15:
        # all genotyped individuals selected: selection effectively on Z1 only
        x1 = norm.isf(p)
        return rho * norm.pdf(x1) / p, -np.inf
    x1 = norm.isf(phi)
    s = np.sqrt(1 - rho**2)
    joint = lambda x2: quad(lambda z: norm.pdf(z) * norm.sf((x1 - rho * z) / s), x2, np.inf, epsabs=1e-13, epsrel=1e-12)[0]
    x2 = brentq(lambda x: joint(x) - p, -10, 10, xtol=1e-13)
    m = quad(lambda z: z * norm.pdf(z) * norm.sf((x1 - rho * z) / s), x2, np.inf, epsabs=1e-13, epsrel=1e-12)[0] / p
    return m, x2

def check_mc(p, phi, rho, n=4_000_000, seed=358):
    rng = np.random.default_rng(seed)
    z1 = rng.standard_normal(n); z2 = rho * z1 + np.sqrt(1 - rho**2) * rng.standard_normal(n)
    k1 = int(round(phi * n)); k = int(round(p * n))
    idx1 = np.argpartition(-z1, k1 - 1)[:k1]
    sub = z2[idx1]
    top = np.partition(-sub, k - 1)[:k]
    return -top.mean()

pm, pf = 0.05, 0.30
print('rG %.4f rPA %.4f rho %.4f  i(0.05) %.4f i(0.30) %.4f' % (rG, rPA, rho, i_trunc(pm), i_trunc(pf)))
full = i_trunc(pm)
print('--- male path, p=5%: selective genotyping ---')
tab = []
for k in (1, 1.5, 2, 3, 4, 6, 10, 20):
    phi = min(1.0, k * pm)
    m, x2 = two_stage(pm, phi, rho)
    m5, _ = two_stage(pm, phi, 0.5)
    S = rG * m
    tab.append((k, phi, S, 100 * (1 - m / full), 100 * (1 - m5 / full)))
    print('phi/p=%4.1f phi=%.3f  S_m=%.4f  loss(rho=%.4f)=%.2f%%  loss(rho=0.5)=%.2f%%' % (k, phi, S, rho, tab[-1][3], tab[-1][4]))
print('MC check phi=0.10:', round(check_mc(pm, 0.10, rho), 4), 'exact', round(two_stage(pm, 0.10, rho)[0], 4))
print('MC check phi=0.15:', round(check_mc(pm, 0.15, rho), 4), 'exact', round(two_stage(pm, 0.15, rho)[0], 4))

# ---- strategy comparison (both sexes) ----
Lm, Lf = 1.30, 1.85
nm = nf = 5000
imp = 0.98          # accuracy ratio LD+imputation / HD  (example assumption)
cHD, cLD = 400.0, 150.0
vD = 20.0 * 1e6 * 41.6340     # value of +1 sigma_A/yr sustained (from §35.2.7), yuan
ann = sum(1 / 1.05**t for t in range(1, 16))
def S_path(p, phi, r_g):
    """selection differential when genotyping top phi by PA then selecting p by GEBV with accuracy r_g"""
    rr = rPA / r_g
    if phi == 0: return rPA * i_trunc(p)
    m, _ = two_stage(p, phi, rr) if phi < 1 else (i_trunc(p), None)
    return r_g * m
strategies = [
    ('none', 0, 0, None),
    ('HD all', 1.0, 1.0, 'HD'),
    ('LD all', 1.0, 1.0, 'LD'),
    ('LD males only', 1.0, 0, 'LD'),
    ('LD sel m 3p, f all', 0.15, 1.0, 'LD'),
    ('LD sel m 3p, f 2p', 0.15, 0.60, 'LD'),
    ('LD sel m 2p, f 2p', 0.10, 0.60, 'LD'),
]
res = {}
base_dG = None
for name, phm, phf, chip in strategies:
    rg = rG if chip == 'HD' else rG * imp
    Sm = S_path(pm, phm, rg) if phm > 0 else rPA * i_trunc(pm)
    Sf = S_path(pf, phf, rg) if phf > 0 else rPA * i_trunc(pf)
    dG = (Sm + Sf) / (Lm + Lf)
    ngeno = nm * phm + nf * phf
    cost_y = ngeno * (cHD if chip == 'HD' else cLD)
    if base_dG is None: base_dG = dG
    val = (dG - base_dG) * vD
    net = val - cost_y * ann
    res[name] = dict(Sm=Sm, Sf=Sf, dG=dG, ngeno=ngeno, cost_y=cost_y, val=val, net=net)
    print('%-20s Sm=%.4f Sf=%.4f dG=%.4f (%.2f%% of HD) n_geno=%5.0f cost/yr=%6.1f wan  value=%8.1f wan  cost15=%7.1f wan  net=%8.1f wan' % (
        name, Sm, Sf, dG, 0, ngeno, cost_y / 1e4, val / 1e4, cost_y * ann / 1e4, net / 1e4))
hd = res['HD all']['dG']
for k, v in res.items():
    print('%-20s dG/HD = %.4f' % (k, v['dG'] / hd))
print('annuity 15y 5%% = %.4f' % ann)
# break-even genotyping cost for LD all (per animal) : value == cost
v = res['LD all']
print('break-even LD cost per animal: %.1f yuan' % (v['val'] / (v['ngeno'] * ann)))
json.dump(dict(tab=tab, res=res), open('s2_geno.json', 'w'), indent=1)
print('--- formatted strategy table ---')
for k, v in res.items():
    print('%-20s n=%5.0f dG=%.4f rel=%.4f cost_y=%.2f wan value15=%.1f cost15=%.1f net=%.1f' % (
        k, v['ngeno'], v['dG'], v['dG'] / hd, v['cost_y'] / 1e4, v['val'] / 1e4, v['cost_y'] * ann / 1e4, v['net'] / 1e4))
print('HD/LD price ratio %.2f' % (cHD / cLD))
