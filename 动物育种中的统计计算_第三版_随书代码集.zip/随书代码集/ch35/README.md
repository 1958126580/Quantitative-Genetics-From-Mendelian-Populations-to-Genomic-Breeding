# 第三十五章　遗传改良体系的整体优化与前沿展望 —— 配套代码

**所属**：第八篇　育种规划与遗传改良优化　　**对应正文**：第三十五章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch35.ipynb` | IJulia 笔记本：9 个代码单元，约 215 行 Julia 代码，穿插与正文对应的说明 |
| `ch35.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 11 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　$\Delta G=\boldsymbol\pi'\mathbf s$ 与遗传滞后（正文式 35.2–35.8）
- 2　参考群体投资的边际回报（正文式 35.9–35.12）
- 3　最优选择年龄（正文式 35.14）
- 4　多阶段决策：动态规划与滚动规划（正文式 35.15）
- 5　ROH 长度与近交时间（正文式 35.16）
- 6　联邦求解 MME 的精确性（正文式 35.19）
- 7　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 35
```

或在 Jupyter 中打开 `ch35/ch35.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
