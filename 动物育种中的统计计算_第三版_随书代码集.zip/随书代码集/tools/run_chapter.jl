# run_chapter.jl —— 运行某一章（或附录）的配套脚本
#
# 用法（在 code/ 目录下，先执行一次 Pkg.instantiate()）：
#   julia --project=. tools/run_chapter.jl 05        # 第 5 章（运行 ch05/ch05.jl）
#   julia --project=. tools/run_chapter.jl 05 06     # 依次运行多章
#   julia --project=. tools/run_chapter.jl appA      # 附录 A
#   julia --project=. tools/run_chapter.jl all       # 全部 37 个（耗时较长）
#
# 每个脚本在自己的目录下、自己的模块里运行，互不污染变量；
# 笔记本末尾的"自检汇总"单元会打印 ✔/✘。

const ROOT = dirname(@__DIR__)

chapter_dirs() = sort(filter(d -> occursin(r"^(ch\d\d|app[AB])$", d), readdir(ROOT)))

resolve(arg) = occursin(r"^\d+$", arg) ? "ch" * lpad(arg, 2, '0') : arg

function run_one(ch)
    f = joinpath(ROOT, ch, ch * ".jl")
    isfile(f) || error("找不到 $f")
    println("=" ^ 72)
    println("运行 ", ch, "  ", f)
    println("=" ^ 72)
    t0 = time()
    m = Module(Symbol(ch))
    cd(() -> Base.include(m, f), dirname(f))
    println("\n[", ch, "] 完成，用时 ", round(time() - t0; digits = 1), " s")
end

if isempty(ARGS)
    println("用法：julia --project=. tools/run_chapter.jl <章号|appA|appB|all> ...")
else
    targets = ARGS == ["all"] ? chapter_dirs() : resolve.(ARGS)
    for ch in targets
        ch in chapter_dirs() || error("未知章节：$ch（可选：" * join(chapter_dirs(), " ") * "）")
        run_one(ch)
    end
end
