#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""nb2jl.py —— 把 IJulia 笔记本导出为"百分号格式"的 Julia 脚本（# %% 分隔单元，Jupytext 兼容）。

用法（在 code/ 目录下）：
    python3 tools/nb2jl.py ch05            # 由 ch05/ch05.ipynb 写出 ch05/ch05.jl
    python3 tools/nb2jl.py --all           # 处理全部章与附录

修改笔记本之后运行一次本脚本，即可让 .jl 与 .ipynb 保持同步（test/test_fast.jl 会检查二者是否一致）。
"""
import io, json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def convert(name):
    path = os.path.join(ROOT, name, name + '.ipynb')
    nb = json.load(io.open(path, encoding='utf-8'))
    title = nb.get('metadata', {}).get('title', name)
    run = name[2:] if name.startswith('ch') else name
    out = ['# 本脚本由 tools/nb2jl.py 从同目录的 %s.ipynb 自动导出（"百分号格式"，# %%%% 分隔单元，Jupytext 兼容），内容与笔记本一致。' % name,
           '# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl %s' % run,
           '']
    for cell in nb['cells']:
        src = ''.join(cell['source']).rstrip('\n')
        if cell['cell_type'] == 'markdown':
            out.append('# %% [markdown]')
            out.extend(('# ' + l).rstrip() for l in src.split('\n'))
        else:
            out.append('# %%')
            out.append(src)
        out.append('')
    text = '\n'.join(out).rstrip('\n') + '\n'
    io.open(os.path.join(ROOT, name, name + '.jl'), 'w', encoding='utf-8').write(text)
    return name


def all_names():
    return sorted(d for d in os.listdir(ROOT) if re.match(r'^(ch\d\d|app[A-Z])$', d))


if __name__ == '__main__':
    args = sys.argv[1:]
    if not args or args == ['--help']:
        print(__doc__); sys.exit(0)
    names = all_names() if args == ['--all'] else [('ch%02d' % int(a)) if a.isdigit() else a for a in args]
    for n in names:
        print('wrote', convert(n) + '.jl')
