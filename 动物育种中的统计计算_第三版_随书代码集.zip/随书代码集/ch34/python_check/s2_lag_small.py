# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_lag_small.py    依赖：cvxpy, numpy
"""§34.2.8 (cont.)  small example + random sub-problems: where does greedy removal fail?"""
import numpy as np, cvxpy as cp, json, sys
from common import pop34034, ocs_socp
from s2_lag import meuwissen, lag_on_set

P = pop34034(); a, Ac, nM = P['a'], P['Ac'], P['nM']; n = len(a)
male = np.r_[np.ones(nM, bool), np.zeros(n - nM, bool)]
L = np.linalg.cholesky(Ac + 1e-10 * np.eye(n))
out = {}
# ---- (0) the marginal candidate at Ct=0.060 / 0.080 in the SOCP solution ----
for Ct in (0.060, 0.080):
    cs, obj, st, du = ocs_socp(a, Ac, nM, Ct, L=L)
    r = meuwissen(a, Ac, male, Ct)
    tiny = np.where((cs > 1e-7) & (r['c'] == 0))[0]
    lam_k = np.where(male, r['lam'][0], r['lam'][1])
    g = a - r['lam0'] * (Ac @ r['c']) - lam_k
    for k in tiny:
        print(f'Ct={Ct}: cand {k} ({"M" if male[k] else "F"}) SOCP c={cs[k]:.3e}, Lagrange c=0, reduced gain g={g[k]:.3e}, EBV={a[k]:.4f}')
    print(f'  SOCP count c>1e-6: {(cs>1e-6).sum()}  c>1e-7: {(cs>1e-7).sum()}  c>1e-5: {(cs>1e-5).sum()} c>1e-4: {(cs>1e-4).sum()};  Lagrange count {(r["c"]>0).sum()} (males {(r["c"][:nM]>0).sum()})')
    out[f'tiny_{Ct}'] = [dict(k=int(k), male=bool(male[k]), c_socp=float(cs[k]), g=float(g[k])) for k in tiny]

# ---- (1) small example: top-6 males + top-6 females by EBV ----
def small_example(nm, nf, Ct, verbose=True):
    im = np.argsort(-a[:nM])[:nm]; jf = nM + np.argsort(-a[nM:])[:nf]
    sub = np.r_[im, jf]
    a_s = a[sub]; A_s = Ac[np.ix_(sub, sub)]; male_s = male[sub]
    S = np.arange(len(sub)); hist = []
    while True:
        cS, lam0, lam, ok = lag_on_set(a_s, A_s, male_s, S, Ct)
        if not ok:
            hist.append(('infeasible', S.copy())); break
        c_full = np.full(len(sub), np.nan); c_full[S] = cS
        hist.append((lam0, c_full.copy()))
        if (cS < 0).any():
            S = S[cS >= 0]
        else:
            break
    cs, obj, st, du = ocs_socp(a_s, A_s, nm, Ct)
    return sub, a_s, A_s, hist, cs, obj


for Ct in (0.10, 0.12, 0.15):
    sub, a_s, A_s, hist, cs, obj = small_example(6, 6, Ct)
    print(f'\n--- small example 6+6, Ct={Ct} ---')
    # min coancestry for this set
    cmin = cp.Variable(12)
    Ls = np.linalg.cholesky(A_s)
    pr = cp.Problem(cp.Minimize(0.5 * cp.sum_squares(Ls.T @ cmin)), [cp.sum(cmin[:6]) == .5, cp.sum(cmin[6:]) == .5, cmin >= 0]); pr.solve(solver=cp.CLARABEL)
    print('C_min(set)=', round(pr.value, 5), ' mean coanc among the 12:', round(A_s.sum() / 144 / 2, 5))
    print('EBV:', np.round(a_s, 4))
    print('F  :', np.round(np.diag(A_s) - 1, 4))
    for h in hist:
        if h[0] == 'infeasible':
            print('infeasible'); continue
        print(f'lam0={h[0]:.4f}  c=', np.array2string(h[1], precision=4, suppress_small=True))
    print('SOCP c=', np.array2string(cs, precision=4, suppress_small=True), ' obj', round(obj, 6))
    last = hist[-1][1]
    print('Lagrange final obj', round(np.nansum(last * a_s), 6), ' max|dc|', np.nanmax(np.abs(np.nan_to_num(last) - cs)))
print('\nA among the 12 (x2 coancestry):')
sub, a_s, A_s, hist, cs, obj = small_example(6, 6, 0.12)
print(np.round(A_s, 3))
print('ids', sub)
json.dump(out, open('s2_lag_small.json', 'w'), indent=1, default=float)
