# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_gocs_sum.py    依赖：numpy
import json, numpy as np
R = json.load(open('gocs_rep.json')); R = sorted(R, key=lambda r: r['seed'])
print('reps', len(R), [r['seed'] for r in R][:3], '...')
se = lambda v: np.std(v, ddof=1) / np.sqrt(len(v))
out = {}
print('mean Cbar by matrix:', {k: round(np.mean([r['Cbar'][k] for r in R]), 5) for k in R[0]['Cbar']}, 'IBD', round(np.mean([r['CbarIBD'] for r in R]), 5))
print('corr with IBD:', {k: round(np.mean([r['corr'][k] for r in R]), 4) for k in R[0]['corr']})
print('acc GEBV %.4f  EBV_A %.4f' % (np.mean([r['accG'] for r in R]), np.mean([r['accA'] for r in R])))
for dF in (0.005, 0.01, 0.02):
    line = f'nominal dF*={dF*100:.1f}%: '
    for lab in ('P', 'A', 'G', 'G05', 'Gcur'):
        v = np.array([r['nom'][f'{lab}_{dF}']['dFibd'] for r in R]); g = np.array([r['nom'][f'{lab}_{dF}']['dbv'] for r in R])
        npar = np.mean([r['nom'][f'{lab}_{dF}']['npar'] for r in R]); ns = np.mean([r['nom'][f'{lab}_{dF}']['nsire'] for r in R])
        line += f'{lab}: dFibd {v.mean()*100:.3f}±{se(v)*100:.3f}% dBV {g.mean():.4f}±{se(g):.4f} npar {npar:.1f}({ns:.1f}) | '
        out[f'nom_{lab}_{dF}'] = dict(dFibd=v.mean(), dFibd_se=se(v), dbv=g.mean(), dbv_se=se(g), npar=npar, nsire=ns)
    print(line)
print()
for t in (0.005, 0.01, 0.02):
    vals = {lab: np.array([r['match'][f'{lab}_dbv_{t}'] for r in R], dtype=float) for lab in ('P', 'A', 'G')}
    vg = {lab: np.array([r['match'][f'{lab}_dg_{t}'] for r in R], dtype=float) for lab in ('A', 'G')}
    ok = np.all([~np.isnan(vals[l]) for l in vals], axis=0)
    dGA = vals['G'][ok] - vals['A'][ok]; dGP = vals['G'][ok] - vals['P'][ok]; dAP = vals['A'][ok] - vals['P'][ok]
    dg = vg['G'][ok] - vg['A'][ok]
    print(f'matched IBD dF={t*100:.1f}% (n={ok.sum()}): dBV P {vals["P"][ok].mean():.4f} A {vals["A"][ok].mean():.4f} G {vals["G"][ok].mean():.4f} | '
          f'G-A {dGA.mean():.4f}±{se(dGA):.4f} ({dGA.mean()/vals["A"][ok].mean()*100:+.1f}%) G-P {dGP.mean():.4f}±{se(dGP):.4f} ({dGP.mean()/vals["P"][ok].mean()*100:+.1f}%) A-P {dAP.mean():.4f}±{se(dAP):.4f} | '
          f'GEBV-scale G-A {dg.mean():.4f}±{se(dg):.4f} ({dg.mean()/vg["A"][ok].mean()*100:+.1f}%), G>A in {np.sum(dGA>0)}/{ok.sum()} reps')
    out[f'match_{t}'] = dict(n=int(ok.sum()), P=vals['P'][ok].mean(), A=vals['A'][ok].mean(), G=vals['G'][ok].mean(), GA=dGA.mean(), GA_se=se(dGA),
                             GP=dGP.mean(), GP_se=se(dGP), AP=dAP.mean(), AP_se=se(dAP), dg=dg.mean(), dg_se=se(dg), dgA=vg['A'][ok].mean(), nGA=int(np.sum(dGA > 0)))
json.dump(out, open('s2_gocs_sum.json', 'w'), indent=1, default=float)
