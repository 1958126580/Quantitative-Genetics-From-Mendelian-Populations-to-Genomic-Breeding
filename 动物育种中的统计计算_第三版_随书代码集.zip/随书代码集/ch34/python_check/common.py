# -*- coding: utf-8 -*-
"""Common helpers for ch34 expansion.  pop34034() reproduces EXACTLY the population of
§34.2.7 (ch34me/ocs.py, seed 34034): same RNG call sequence."""
import numpy as np, cvxpy as cp

H2 = 0.30; SA2 = H2; SE2 = 1 - H2


def buildA(sire, dam):
    n = len(sire); A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i] - 1, dam[i] - 1
        for j in range(i):
            v = 0.0
            if s >= 0: v += 0.5 * A[j, s]
            if d >= 0: v += 0.5 * A[j, d]
            A[i, j] = A[j, i] = v
        A[i, i] = 1.0 + (0.5 * A[s, d] if (s >= 0 and d >= 0) else 0.0)
    return A


def buildA_fast(sire, dam):
    """Vectorised tabular method (row-wise); identical result to buildA."""
    n = len(sire); A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i] - 1, dam[i] - 1
        row = np.zeros(i)
        if s >= 0: row += 0.5 * A[:i, s] if s < i else 0
        if d >= 0: row += 0.5 * A[:i, d] if d < i else 0
        A[i, :i] = row; A[:i, i] = row
        A[i, i] = 1.0 + (0.5 * A[s, d] if (s >= 0 and d >= 0) else 0.0)
    return A


def pop34034():
    rng = np.random.default_rng(34034)
    sire = [0] * 120; dam = [0] * 120; sex = ['M'] * 20 + ['F'] * 100; gen = [0] * 120
    tbv = list(rng.normal(0, np.sqrt(SA2), 120))
    parents_m = list(range(1, 21)); parents_f = list(range(21, 121))
    for g in (1, 2, 3):
        nm, nf = 200, 200
        for k in range(nm + nf):
            s = int(rng.choice(parents_m)); d = int(rng.choice(parents_f))
            sire.append(s); dam.append(d); sex.append('M' if k < nm else 'F'); gen.append(g)
            ms = rng.normal(0, np.sqrt(0.5 * SA2))
            tbv.append(0.5 * (tbv[s - 1] + tbv[d - 1]) + ms)
        ids = [i + 1 for i in range(len(sire)) if gen[i] == g]
        y = np.array(tbv) + rng.normal(0, np.sqrt(SE2), len(tbv))
        if g < 3:
            males = [i for i in ids if sex[i - 1] == 'M']; females = [i for i in ids if sex[i - 1] == 'F']
            parents_m = sorted(males, key=lambda i: -y[i - 1])[:20]
            parents_f = sorted(females, key=lambda i: -y[i - 1])[:100]
    n = len(sire); tbv = np.array(tbv)
    A = buildA_fast(sire, dam)
    y = tbv + rng.normal(0, np.sqrt(SE2), n)
    lam = SE2 / SA2
    Ai = np.linalg.inv(A)
    X = np.ones((n, 1))
    C = np.block([[X.T @ X, X.T], [X, np.eye(n) + Ai * lam]])
    rhs = np.concatenate([X.T @ y, y])
    sol = np.linalg.solve(C, rhs); ebv = sol[1:]
    cand = [i for i in range(n) if gen[i] == 3]
    M = [i for i in cand if sex[i] == 'M']; F = [i for i in cand if sex[i] == 'F']
    idx = M + F; nM = len(M)
    a = ebv[idx]; Ac = A[np.ix_(idx, idx)]
    return dict(sire=np.array(sire), dam=np.array(dam), sex=np.array(sex), gen=np.array(gen),
                tbv=tbv, y=y, ebv=ebv, A=A, idx=np.array(idx), nM=nM, a=a, Ac=Ac, mu=sol[0], rng=rng)


def ocs_socp(a, Ac, nM, Ct, extra=None, ub_f=None, ub_m=None, L=None, solver=cp.CLARABEL, qform=False):
    """max a'c s.t. c'Ac/2<=Ct, sum males=.5, sum females=.5, c>=0.  Returns c, obj, status, dual(lambda0)."""
    n = len(a)
    if L is None:
        L = np.linalg.cholesky(Ac + 1e-10 * np.eye(n))
    c = cp.Variable(n)
    cons = [cp.sum(c[:nM]) == 0.5, cp.sum(c[nM:]) == 0.5, c >= 0]
    if qform:
        kcon = 0.5 * cp.sum_squares(L.T @ c) <= Ct
    else:
        kcon = cp.sum_squares(L.T @ c) <= 2 * Ct
    cons.append(kcon)
    if ub_f is not None: cons.append(c[nM:] <= ub_f)
    if ub_m is not None: cons.append(c[:nM] <= ub_m)
    if extra: cons += extra(c)
    prob = cp.Problem(cp.Maximize(a @ c), cons)
    prob.solve(solver=solver)
    v = np.array(c.value).ravel()
    dual = kcon.dual_value
    return v, prob.value, prob.status, dual


if __name__ == '__main__':
    import json, os
    P = pop34034()
    a, Ac, nM = P['a'], P['Ac'], P['nM']
    print('mean F cand', np.mean(np.diag(Ac) - 1).round(4), 'mean coanc', (Ac.sum() / len(a) ** 2 / 2).round(4))
    acc = np.corrcoef(P['ebv'][P['idx']], P['tbv'][P['idx']])[0, 1]
    print('acc', acc)
    ref = json.load(open(os.path.join(os.path.dirname(__file__), '..', 'ch34me', 'ocs_res.json')))
    for row in ref['ocs']:
        Ct = row[0]
        c, obj, st, du = ocs_socp(a, Ac, nM, Ct)
        c[c < 1e-7] = 0
        print(Ct, round(float(c @ a), 4), row[1], round(c @ Ac @ c / 2, 4), int((c > 1e-6).sum()), row[3], st)
