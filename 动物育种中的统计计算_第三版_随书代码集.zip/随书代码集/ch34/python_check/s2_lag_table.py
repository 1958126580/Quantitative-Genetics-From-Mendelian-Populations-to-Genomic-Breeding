# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_lag_table.py    依赖：numpy
import numpy as np, json
from common import pop34034, ocs_socp
from s2_lag import lag_on_set
P = pop34034(); a, Ac, nM = P['a'], P['Ac'], P['nM']; n = len(a)
male = np.r_[np.ones(nM, bool), np.zeros(n - nM, bool)]
im = np.argsort(-a[:nM])[:6]; jf = nM + np.argsort(-a[nM:])[:6]
sub = np.r_[im, jf]; a_s = a[sub]; A_s = Ac[np.ix_(sub, sub)]; male_s = male[sub]
Ct = 0.12
S = np.arange(12); hist = []
while True:
    cS, lam0, lam, ok = lag_on_set(a_s, A_s, male_s, S, Ct)
    cf = np.full(12, np.nan); cf[S] = cS; hist.append((lam0, cf, lam))
    if (cS < 0).any(): S = S[cS >= 0]
    else: break
cs, obj, st, du = ocs_socp(a_s, A_s, 6, Ct, qform=True)
labels = [f'公{i+1}' for i in range(6)] + [f'母{i+1}' for i in range(6)]
def f(x):
    if np.isnan(x): return '—'
    return f'{x:.4f}' if abs(x) >= 5e-5 else '0'
for k in range(12):
    row = [labels[k], f'{a_s[k]:.4f}'] + [f(h[1][k]) for h in hist] + [f(cs[k]) if cs[k] > 1e-7 else '0']
    print('| ' + ' | '.join(row) + ' |')
print('lam0', [round(h[0], 4) for h in hist], 'dual', np.ravel(du)[0])
cfin = np.nan_to_num(hist[-1][1])
print('obj lagr %.6f socp %.6f  diff %.2e  max|dc| %.2e' % (cfin @ a_s, obj, cfin @ a_s - obj, np.abs(cfin - cs).max()))
print('coanc lagr %.6f' % (cfin @ A_s @ cfin / 2))
# reduced gains of excluded in the final
lam = hist[-1][2]; lam0 = hist[-1][0]
g = a_s - lam0 * (A_s @ cfin) - np.where(male_s, lam[0], lam[1])
print('reduced gains:', {labels[k]: round(g[k], 4) for k in range(12)})
print('mean coanc 12: %.4f' % (A_s.mean() / 2))
# equal contributions (6+6) gain & coanc
ce = np.full(12, 1 / 12)
print('equal: gain %.4f coanc %.4f' % (ce @ a_s, ce @ A_s @ ce / 2))
