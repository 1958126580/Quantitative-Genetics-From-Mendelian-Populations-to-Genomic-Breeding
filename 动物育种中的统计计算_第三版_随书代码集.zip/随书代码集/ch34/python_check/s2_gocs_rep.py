# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_gocs_rep.py    依赖：cvxpy, numpy
"""§34.2.9 replicated: 20 independent genotyped populations (seeds 34290..34309).
For each: nominal OCS at dF* in {0.5,1,2}% with P (EBV_A + A), A (GEBV + A), G (GEBV + Gbase), G05, Gcur;
frontiers of P/A/G and matched comparison on realised IBD coancestry."""
import os
os.environ.setdefault('OMP_NUM_THREADS', '1'); os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import numpy as np, cvxpy as cp, json, sys, time
from gsim import simulate

NREP = int(sys.argv[1]) if len(sys.argv) > 1 else 20
fn = 'gocs_rep.json'
res = json.load(open(fn)) if os.path.exists(fn) else []
done = {r['seed'] for r in res}


def chol(K):
    w, V = np.linalg.eigh(K); w = np.clip(w, 0, None)
    return V * np.sqrt(w)


for r in range(NREP):
    seed = 34290 + r
    if seed in done: continue
    t0 = time.time()
    D = simulate(seed)
    idx, nM = D['idx'], int(D['nM']); n = len(idx)
    Mc = D['Mc'].astype(float); p0 = D['p0']; q0 = 1 - p0; mk = D['markers']
    Zb = Mc[:, mk] - 2 * p0[mk]; Gb = Zb @ Zb.T / (2 * np.sum(p0[mk] * q0[mk]))
    Z5 = Mc[:, mk] - 1.0; G05 = Z5 @ Z5.T / (len(mk) / 2)
    pc = Mc[:, mk].mean(0) / 2; Zc = Mc[:, mk] - 2 * pc; Gc = Zc @ Zc.T / (2 * np.sum(pc * (1 - pc)))
    mats = dict(A=D['A'] / 2, Gbase=Gb / 2, G05=G05 / 2, Gcur=Gc / 2)
    Phi = D['Phi']; BV = D['BV']; gebv = D['gebv']; ebvA = D['ebvA']
    CI = Phi.mean(); bvbar = BV.mean(); gbar = gebv.mean()
    Rs = {k: chol(K) for k, K in mats.items()}
    iu = np.triu_indices(n, 1)
    rec = dict(seed=seed, CbarIBD=float(CI), Cbar={k: float(K.mean()) for k, K in mats.items()},
               corr={k: float(np.corrcoef(K[iu], Phi[iu])[0, 1]) for k, K in mats.items()},
               accG=float(np.corrcoef(gebv, BV)[0, 1]), accA=float(np.corrcoef(ebvA, BV)[0, 1]))

    def ocs(ebv, k, Cstar):
        c = cp.Variable(n)
        cons = [cp.sum(c[:nM]) == 0.5, cp.sum(c[nM:]) == 0.5, c >= 0, cp.sum_squares(Rs[k].T @ c) <= Cstar]
        prob = cp.Problem(cp.Maximize(ebv @ c), cons); prob.solve(solver=cp.CLARABEL)
        v = np.array(c.value).ravel(); v[v < 1e-7] = 0
        return v, prob.status

    def ev(c):
        CIc = float(c @ Phi @ c)
        return dict(dFibd=(CIc - CI) / (1 - CI), dbv=float(c @ BV - bvbar), dg=float(c @ gebv - gbar), npar=int((c > 1e-6).sum()),
                    nsire=int((c[:nM] > 1e-6).sum()))

    nom = {}
    for dF in (0.005, 0.01, 0.02):
        for lab, ebv, k in (('P', ebvA, 'A'), ('A', gebv, 'A'), ('G', gebv, 'Gbase'), ('G05', gebv, 'G05'), ('Gcur', gebv, 'Gcur')):
            Cb = mats[k].mean()
            Cstar = dF if k == 'Gcur' else Cb + dF * (1 - Cb)
            c, st = ocs(ebv, k, Cstar)
            e = ev(c); e['st'] = st
            nom[f'{lab}_{dF}'] = e
    rec['nom'] = nom
    grid = [0.0, 0.0025, 0.005, 0.0075, 0.01, 0.0125, 0.015, 0.02, 0.025, 0.03, 0.035]
    fr = {}
    for lab, ebv, k in (('P', ebvA, 'A'), ('A', gebv, 'A'), ('G', gebv, 'Gbase')):
        Cb = mats[k].mean(); pts = []
        for dF in grid:
            c, st = ocs(ebv, k, Cb + dF * (1 - Cb))
            pts.append(ev(c))
        fr[lab] = pts
    rec['fr'] = fr
    mt = {}
    for target in (0.005, 0.01, 0.02):
        for lab in ('P', 'A', 'G'):
            x = np.array([p['dFibd'] for p in fr[lab]]); o = np.argsort(x)
            for key in ('dbv', 'dg'):
                yv = np.array([p[key] for p in fr[lab]])
                mt[f'{lab}_{key}_{target}'] = float(np.interp(target, x[o], yv[o])) if x.min() <= target <= x.max() else None
    rec['match'] = mt
    res.append(rec)
    json.dump(res, open(fn, 'w'), indent=1, default=float)
    print(seed, f'{time.time()-t0:.0f}s', 'nominal1pct: dFibd P %.4f A %.4f G %.4f | match1pct dbv P %s A %s G %s' % (
        nom['P_0.01']['dFibd'], nom['A_0.01']['dFibd'], nom['G_0.01']['dFibd'], mt['P_dbv_0.01'], mt['A_dbv_0.01'], mt['G_dbv_0.01']), flush=True)
