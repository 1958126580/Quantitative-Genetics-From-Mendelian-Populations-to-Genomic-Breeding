# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_assort2.py    依赖：numpy
"""§34.3.7  Assortative vs random vs disassortative mating: offspring variance, next-round response, inbreeding.
Population: §34.2.7 (seed 34034).  Parents: top-20 sires, top-100 dams by EBV; 5 dams per sire; 4 offspring per mating
(2 M + 2 F) -> 400 offspring.  Offspring selected on own phenotype (h2 = 0.30): top 20 of 200 males, top 100 of 200 females.
2 000 replicates (seed 34307), common random numbers across strategies."""
import numpy as np, json
from common import pop34034, SA2, SE2

P = pop34034(); a, Ac, nM = P['a'], P['Ac'], P['nM']; n = len(a)
tbv = P['tbv'][P['idx']]
Fc = np.diag(Ac) - 1
sires = np.argsort(-a[:nM])[:20]                      # sorted by EBV, best first
dams = nM + np.argsort(-a[nM:])[:100]


def pairing(kind, rng=None, pred=None):
    ss = sires[np.argsort(-pred[sires])]; dd = dams[np.argsort(-pred[dams])]
    if kind == 'pos':
        d = dd.copy()                                    # best dams to best sire (by pred)
    elif kind == 'neg':
        d = dd[::-1].copy()                              # worst dams to best sire
    else:
        ss = sires; d = rng.permutation(dams)
    s = np.repeat(ss, 5)
    return s, d


NREP = 2000
PRED = PRED_NAME = None
import sys
mode = sys.argv[1] if len(sys.argv) > 1 else 'ebv'
if mode == 'ebv':
    PRED = a
elif mode == 'tbv':
    PRED = tbv
else:
    rr = float(mode)
    noise = np.random.default_rng(34308).normal(0, 1, n)
    PRED = tbv + noise * np.sqrt(np.var(tbv) * (1 / rr ** 2 - 1))
print('mode', mode, 'corr(pred, TBV) all candidates %.4f ; within selected sires %.4f dams %.4f ; EBV within sires %.4f dams %.4f' % (
    np.corrcoef(PRED, tbv)[0, 1], np.corrcoef(PRED[sires], tbv[sires])[0, 1], np.corrcoef(PRED[dams], tbv[dams])[0, 1],
    np.corrcoef(a[sires], tbv[sires])[0, 1], np.corrcoef(a[dams], tbv[dams])[0, 1]))
rng_master = np.random.default_rng(34307)
res = {k: dict(rS_ebv=[], rS_tbv=[], var_pred=[], var_sim=[], F=[], dG=[], coan_sel=[], mean_off=[]) for k in ('rand', 'pos', 'neg')}
for rep in range(NREP):
    ms = rng_master.normal(0, 1, 400); env = rng_master.normal(0, 1, 400)
    rp = np.random.default_rng(rng_master.integers(1 << 32))
    for kind in ('rand', 'pos', 'neg'):
        s, d = pairing(kind, rp, PRED)
        so = np.repeat(s, 4); do = np.repeat(d, 4)       # 400 offspring, 4 per mating: 2 M then 2 F
        male = np.tile([True, True, False, False], 100)
        Fpar = 0.5 * (Fc[so] + Fc[do])
        msv = 0.5 * SA2 * (1 - Fpar)
        mid = 0.5 * (tbv[so] + tbv[do])
        to = mid + ms * np.sqrt(msv)
        yo = to + env * np.sqrt(SE2)
        Foff = 0.5 * Ac[so, do]
        # predicted variance (eq. 34.29c) over matings
        ms_ = 0.5 * (tbv[s] + tbv[d])
        vpred = 0.25 * np.var(tbv[s]) + 0.25 * np.var(tbv[d]) + 0.5 * np.cov(tbv[s], tbv[d], bias=True)[0, 1] + np.mean(0.5 * SA2 * (1 - 0.5 * (Fc[s] + Fc[d])))
        # selection among offspring on phenotype
        mi = np.where(male)[0]; fi = np.where(~male)[0]
        sm = mi[np.argsort(-yo[mi])[:20]]; sf = fi[np.argsort(-yo[fi])[:100]]
        dG = 0.5 * (to[sm].mean() + to[sf].mean())       # expected mean of the next generation
        # coancestry among selected offspring (equal contributions) = expected F of grand-offspring
        sel = np.r_[sm, sf]
        ps = so[sel]; pd = do[sel]
        A4 = 0.25 * (Ac[np.ix_(ps, ps)] + Ac[np.ix_(ps, pd)] + Ac[np.ix_(pd, ps)] + Ac[np.ix_(pd, pd)])
        # full sibs etc. handled by formula; self terms: A_kk = 1 + F_k
        same = np.equal.outer(sel, sel)
        A4[same] = 1 + Foff[sel]
        c = np.r_[np.full(20, 0.5 / 20), np.full(100, 0.5 / 100)]
        R = res[kind]
        R['rS_ebv'].append(np.corrcoef(PRED[s], PRED[d])[0, 1]); R['rS_tbv'].append(np.corrcoef(tbv[s], tbv[d])[0, 1])
        R['var_pred'].append(vpred); R['var_sim'].append(np.var(to)); R['F'].append(Foff.mean()); R['dG'].append(dG)
        R['coan_sel'].append(c @ A4 @ c / 2); R['mean_off'].append(to.mean())
out = {}
se = lambda v: np.std(v, ddof=1) / np.sqrt(len(v))
for kind in ('rand', 'pos', 'neg'):
    R = res[kind]
    o = {k: float(np.mean(v)) for k, v in R.items()}
    o.update({k + '_se': float(se(v)) for k, v in R.items()})
    out[kind] = o
    print(f"{kind:5s} r(EBV) {o['rS_ebv']:+.4f} r(TBV) {o['rS_tbv']:+.4f} | Var(off) pred {o['var_pred']:.5f} sim {o['var_sim']:.5f}±{o['var_sim_se']:.5f} | mean off {o['mean_off']:.5f} | F_off {o['F']:.5f} | next-gen mean {o['dG']:.5f}±{o['dG_se']:.5f} | coanc among selected {o['coan_sel']:.5f}")
for kind in ('pos', 'neg'):
    d = np.array(res[kind]['dG']) - np.array(res['rand']['dG'])
    v = np.array(res[kind]['var_sim']) / np.array(res['rand']['var_sim'])
    print(f"{kind} - rand: next-gen mean {d.mean():+.5f} ± {se(d):.5f} ; response ratio {(np.mean(res[kind]['dG'])-np.mean(res[kind]['mean_off']))/(np.mean(res['rand']['dG'])-np.mean(res['rand']['mean_off'])):.4f} ; var ratio {np.mean(res[kind]['var_sim'])/np.mean(res['rand']['var_sim']):.4f}")
    out[kind + '_diff'] = dict(dG=float(d.mean()), dG_se=float(se(d)))
print('SA2 base %.3f ; parents: var TBV sires %.5f dams %.5f ; MS var mean %.5f' % (SA2, np.var(tbv[sires]), np.var(tbv[dams]), np.mean(0.5 * SA2 * (1 - 0.5 * (Fc[np.repeat(sires, 5)] + Fc[dams])))))
json.dump(out, open(f's3_assort_{mode}.json', 'w'), indent=1)
