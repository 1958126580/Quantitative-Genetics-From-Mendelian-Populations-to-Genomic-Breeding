# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5_knee2.py    依赖：numpy
import json, numpy as np
d = json.load(open('s5_knee.json'))
rows = d['rows']; Cbar = d['Cbar']; abar = d['abar']
dFa = np.array([r['dF'] for r in rows]); G = np.array([r['G'] for r in rows]); lam = np.array([r['lam0'] for r in rows])
per = lam * (1 - Cbar) * 0.01
out = {}
for kappa in (0.02, 0.04, 0.08, 0.16):
    ok = np.where((per >= kappa) & (dFa >= 0))[0]; k = ok.max()
    print(f'kappa={kappa}: dF*={dFa[k]*100:.2f}%  G={G[k]:.4f}  npar={rows[k]["npar"]} ({rows[k]["nsire"]})  marginal {per[k]:.5f}  next {per[k+1]:.5f}')
    out[str(kappa)] = dict(dF=float(dFa[k]), G=float(G[k]), npar=rows[k]['npar'], nsire=rows[k]['nsire'])
# variance-loss part of kappa for a horizon T at given dF: 0.01*(G_T - R0)
for T in (10, 20):
    for dF in (0.01, 0.02):
        k = int(np.argmin(np.abs(dFa - dF))); R0 = G[k] - abar
        GT = R0 * (1 - (1 - dF) ** T) / dF
        print(f'T={T} dF={dF}: R0={R0:.4f} G_T={GT:.4f} kappa_var=0.01*(G_T-R0)={0.01*(GT-R0):.4f}')
# R0/dF ratio (Robertson) as a 'criterion' -> monotone?
pos = dFa > 0
ratio = (G[pos] - abar) / dFa[pos]
print('R0/dF at dF=0.05%%: %.1f, 0.5%%: %.1f, 1%%: %.1f, 2%%: %.1f, 5%%: %.1f; monotone decreasing: %s' % (
    ratio[np.argmin(abs(dFa[pos]-0.0005))], ratio[np.argmin(abs(dFa[pos]-0.005))], ratio[np.argmin(abs(dFa[pos]-0.01))], ratio[np.argmin(abs(dFa[pos]-0.02))], ratio[np.argmin(abs(dFa[pos]-0.05))], bool(np.all(np.diff(ratio) < 0))))
json.dump(out, open('s5_knee2.json', 'w'), indent=1)
