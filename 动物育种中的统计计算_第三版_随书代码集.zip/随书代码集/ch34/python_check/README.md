# 第 34 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch34/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `ocs.py` | ---- simulate a small pedigree: base 20 sires, 100 dams; 3 generations of selection ---- | cvxpy, numpy | 8.7 | `outputs/ocs.out` |
| `s1_numbers.py` | 数值复核 | numpy | 0.1 | `outputs/s1_numbers.out` |
| `s2_genome.py` | Genotyped population for §34.2.9, §34.2.10, §34.3.6 (seed 34290). | cvxpy, numpy, scipy | 16.8 | `outputs/s2_genome.out` |
| `s2_gocs_rep.py` | §34.2.9 replicated: 20 independent genotyped populations (seeds 34290..34309). | cvxpy, numpy, scipy | 1.8 | `outputs/s2_gocs_rep.out` |
| `s2_gocs_sum.py` | 数值复核 | numpy | 0.1 | `outputs/s2_gocs_sum.out` |
| `s2_lag_small.py` | §34.2.8 (cont.)  small example + random sub-problems: where does greedy removal fail? | cvxpy, numpy | 3.3 | `outputs/s2_lag_small.out` |
| `s2_lag_table.py` | 数值复核 | cvxpy, numpy | 2.0 | `outputs/s2_lag_table.out` |
| `s3_assort.py` | §34.3.7  Assortative vs random vs disassortative mating: offspring variance, next-round response, inbreeding. | cvxpy, numpy | 10.8 | `outputs/s3_assort.out` |
| `s3_assort2.py` | §34.3.7  Assortative vs random vs disassortative mating: offspring variance, next-round response, inbreeding. | cvxpy, numpy | 10.0 | `outputs/s3_assort2.out` |
| `s5_knee2.py` | variance-loss part of kappa for a horizon T at given dF: 0.01*(G_T - R0) | numpy | 0.2 | `outputs/s5_knee2.out` |
| `s5_knee3.py` | 数值复核 | numpy | 0.2 | `outputs/s5_knee3.out` |

公共函数模块（被上列脚本导入，不单独运行）：`common.py`、`gsim.py`、`s2_lag.py`。
