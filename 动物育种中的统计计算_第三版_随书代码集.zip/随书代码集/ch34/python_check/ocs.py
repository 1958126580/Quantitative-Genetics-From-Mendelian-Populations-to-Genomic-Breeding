# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ocs.py    依赖：cvxpy, numpy
import numpy as np, cvxpy as cp, json
rng=np.random.default_rng(34034)
h2=0.30; sA2=h2; sE2=1-h2
# ---- simulate a small pedigree: base 20 sires, 100 dams; 3 generations of selection ----
sire=[0]*120; dam=[0]*120; sex=['M']*20+['F']*100; gen=[0]*120
N=120
def buildA(sire,dam):
    n=len(sire); A=np.zeros((n,n))
    for i in range(n):
        s,d=sire[i]-1,dam[i]-1
        for j in range(i):
            v=0.0
            if s>=0: v+=0.5*A[j,s]
            if d>=0: v+=0.5*A[j,d]
            A[i,j]=A[j,i]=v
        A[i,i]=1.0+(0.5*A[s,d] if (s>=0 and d>=0) else 0.0)
    return A
tbv=list(rng.normal(0,np.sqrt(sA2),120))
parents_m=list(range(1,21)); parents_f=list(range(21,121))
for g in (1,2,3):
    nm,nf=200,200
    for k in range(nm+nf):
        s=int(rng.choice(parents_m)); d=int(rng.choice(parents_f))
        sire.append(s); dam.append(d); sex.append('M' if k<nm else 'F'); gen.append(g)
        ms=rng.normal(0,np.sqrt(0.5*sA2))  # Mendelian sampling (ignoring F for simplicity in simulation)
        tbv.append(0.5*(tbv[s-1]+tbv[d-1])+ms)
    ids=[i+1 for i in range(len(sire)) if gen[i]==g]
    y=np.array(tbv)+rng.normal(0,np.sqrt(sE2),len(tbv))
    # truncation on phenotype within sex to produce next parents (not for last gen)
    if g<3:
        males=[i for i in ids if sex[i-1]=='M']; females=[i for i in ids if sex[i-1]=='F']
        parents_m=sorted(males,key=lambda i:-y[i-1])[:20]
        parents_f=sorted(females,key=lambda i:-y[i-1])[:100]
n=len(sire); tbv=np.array(tbv)
A=buildA(sire,dam)
y=tbv+rng.normal(0,np.sqrt(sE2),n)
# BLUP EBV with all records (animal model, known h2): (I + A^-1 lambda) u = y - mu
lam=sE2/sA2
Ai=np.linalg.inv(A)
mu=y.mean()
# solve mixed model with mean fixed effect
X=np.ones((n,1)); Zm=np.eye(n)
C=np.block([[X.T@X, X.T],[X, np.eye(n)+Ai*lam]])
rhs=np.concatenate([X.T@y, y])
sol=np.linalg.solve(C,rhs); ebv=sol[1:]
cand=[i for i in range(n) if gen[i]==3]
M=[i for i in cand if sex[i]=='M']; F=[i for i in cand if sex[i]=='F']
idx=M+F; nM=len(M)
a=ebv[idx]; Ac=A[np.ix_(idx,idx)]
print('n=',n,' candidates',len(idx),' mean F cand',np.mean(np.diag(Ac)-1).round(4),' mean coancestry cand',(Ac.sum()/len(idx)**2/2).round(4))
acc=np.corrcoef(ebv[idx],tbv[idx])[0,1]; print('EBV accuracy among candidates',round(acc,4))
# ---- truncation selection: top 10 males, top 50 females, equal contributions ----
def trunc(nm,nf):
    order_m=sorted(range(nM),key=lambda k:-a[k])[:nm]; order_f=sorted(range(nM,len(idx)),key=lambda k:-a[k])[:nf]
    c=np.zeros(len(idx)); c[order_m]=0.5/nm; c[order_f]=0.5/nf
    return c
def summarize(c):
    return float(c@a), float(c@Ac@c/2), int((c>1e-6).sum()), int((c[:nM]>1e-6).sum())
C0=float(np.ones(len(idx))@Ac@np.ones(len(idx))/len(idx)**2/2)
res={}
for nm in (5,10,20,40):
    c=trunc(nm,50); g_,cc,nsel,nm_=summarize(c)
    res[f'trunc_{nm}m']=dict(gain=g_,coanc=cc,nsel=nsel,nmales=nm_)
    print(f'truncation {nm:2d} males/50 females: c\'a={g_:.4f}  c\'Ac/2={cc:.4f}  selected={nsel}')
# ---- OCS: maximize c'a s.t. c'Ac/2 <= Ct, male sum 0.5, female sum 0.5, c>=0 ----
L=np.linalg.cholesky(Ac+1e-10*np.eye(len(idx)))
def ocs(Ct):
    c=cp.Variable(len(idx))
    cons=[cp.sum(c[:nM])==0.5, cp.sum(c[nM:])==0.5, c>=0, cp.sum_squares(L.T@c)<=2*Ct]
    prob=cp.Problem(cp.Maximize(a@c),cons); prob.solve(solver=cp.CLARABEL)
    v=np.array(c.value).ravel(); v[v<1e-7]=0
    return v, prob.status
out=[]
for Ct in (0.030,0.035,0.040,0.045,0.050,0.060,0.080):
    c,st=ocs(Ct); g_,cc,nsel,nm_=summarize(c)
    out.append((Ct,g_,cc,nsel,nm_))
    print(f'OCS Ct={Ct:.3f}: c\'a={g_:.4f} c\'Ac/2={cc:.4f} selected={nsel} (males {nm_}) max male contrib={c[:nM].max():.4f} status={st}')
res['ocs']=out
res['C0']=C0; res['acc']=acc
# truncation 10 males: find OCS with same coancestry
c10=trunc(10,50); g10,cc10,_,_=summarize(c10)
c_same,_=ocs(cc10); g_same,cc_s,nsel,nm_=summarize(c_same)
print(f'\nSame coancestry as truncation-10 ({cc10:.4f}): OCS gain {g_same:.4f} vs truncation {g10:.4f} (+{100*(g_same/g10-1):.1f}%), OCS selects {nsel} ({nm_} males)')
# same gain, lower coancestry: minimize coancestry s.t. c'a >= g10
c=cp.Variable(len(idx))
prob=cp.Problem(cp.Minimize(cp.sum_squares(L.T@c)/2),[cp.sum(c[:nM])==0.5,cp.sum(c[nM:])==0.5,c>=0,a@c>=g10]); prob.solve(solver=cp.CLARABEL)
v=np.array(c.value).ravel(); v[v<1e-7]=0
print(f'Same gain as truncation-10: OCS coancestry {v@Ac@v/2:.4f} vs {cc10:.4f} ({100*(1-(v@Ac@v/2)/cc10):.1f}% lower)')
res['same_coanc']=dict(trunc_gain=g10,trunc_coanc=cc10,ocs_gain=g_same,nsel=nsel,nmales=nm_)
res['same_gain']=dict(ocs_coanc=float(v@Ac@v/2))
json.dump(res,open('ocs_res.json','w'),indent=1)
