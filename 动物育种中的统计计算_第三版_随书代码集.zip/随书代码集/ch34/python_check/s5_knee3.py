# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5_knee3.py    依赖：numpy
import json, numpy as np
d = json.load(open('s5_knee.json')); rows = d['rows']; Cbar = d['Cbar']; abar = d['abar']
dF = np.array([r['dF'] for r in rows]); G = np.array([r['G'] for r in rows]); lam = np.array([r['lam0'] for r in rows])
m = lam * (1 - Cbar) * 0.01; R0 = G - abar
res = {}
for T in (10, 20):
    pos = dF > 0
    kv = np.full(len(dF), np.nan)
    kv[pos] = 0.01 * (R0[pos] * (1 - (1 - dF[pos]) ** T) / dF[pos] - R0[pos])
    ok = np.where(pos & (m >= kv))[0]; k = ok.max()
    print(f'T={T}: fixed point dF*={dF[k]*100:.2f}%  marginal {m[k]:.4f}  kappa_var {kv[k]:.4f}  (next: {m[k+1]:.4f} vs {kv[k+1]:.4f})  npar {rows[k]["npar"]} ({rows[k]["nsire"]})')
    res[T] = dict(dF=float(dF[k]), m=float(m[k]), kv=float(kv[k]))
    # adding inbreeding depression of 0.01 per pct
    ok = np.where(pos & (m >= kv + 0.01))[0]; k = ok.max()
    print(f'   + depression 0.01/pct: dF*={dF[k]*100:.2f}%')
    res[f'{T}_dep'] = float(dF[k])
print('ratio chord knees 2.50/0.95 =', 2.50 / 0.95)
json.dump(res, open('s5_knee3.json', 'w'), indent=1)
