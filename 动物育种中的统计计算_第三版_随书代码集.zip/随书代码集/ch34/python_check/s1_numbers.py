# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_numbers.py    依赖：numpy
import json, numpy as np
c = json.load(open('s1_conv.json')); l = json.load(open('s1_long.json'))
Cbar = c['Cbar']; Cmin = c['Cmin']
print('dF at Cmin: %.4f%%' % ((Cmin - Cbar) / (1 - Cbar) * 100))
print('per-gen dF if a 1%%/round constraint is applied annually with L=5: %.4f%%; L=2.5 -> %.4f%%' % ((1 - 0.99 ** 5) * 100, (1 - 0.99 ** 2.5) * 100))
r = {row['Nm']: row for row in l['rows']}
best20 = l['opt']['var_20']['GT']
for Nm in (5, 10, 25, 100):
    print('Nm=%d G20/opt = %.1f%%' % (Nm, r[Nm]['G20'] / best20 * 100))
for Nm in (5, 25, 100):
    s = l['stoch'][str(Nm)]
    print('Nm=%d: dF stoch/det = %.3f ; G20 stoch/det = %.3f ; sa2: stoch %.3f det %.3f' % (Nm, s['dF'] / r[Nm]['dF'], s['G20'] / r[Nm]['G20'], s['sa2_20'], r[Nm]['rem20']))
print('dF N=200 exact', r[200]['dF'] * 100)
