# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 34 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_genome.py    依赖：numpy, scipy
"""Genotyped population for §34.2.9, §34.2.10, §34.3.6 (seed 34290).
Same demographic design as §34.2.7: founders 20 M + 100 F, 3 generations x (200 M + 200 F), phenotypic truncation
(top 20 M, top 100 F) in generations 1 and 2; candidates = generation 3.
Genome: 10 chromosomes x 100 cM, 1500 loci each (15 000), founder LE, p ~ U(0.05,0.95); Haldane crossovers.
300 polygenic QTL (a ~ N(0,1), d = delta*|a|, delta ~ N(0.3,0.3)) + 1 additive major QTL on chr 1 near 50 cM
explaining 10% of base additive variance.  h2 = 0.30 (base), phenotype = genotypic value + e."""
import os
os.environ.setdefault('OMP_NUM_THREADS', '1'); os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import numpy as np, scipy.sparse as sp, json
from common import buildA_fast

rng = np.random.default_rng(34290)
NCHR, LEN, NPER = 10, 100.0, 1500
NLOC = NCHR * NPER
pos = np.concatenate([np.sort(rng.uniform(0, LEN, NPER)) for _ in range(NCHR)])
chrom = np.repeat(np.arange(NCHR), NPER)
p_true = rng.uniform(0.05, 0.95, NLOC)
NF0M, NF0F = 20, 100; NF0 = NF0M + NF0F
hap = np.zeros((NF0, 2, NLOC), np.int8)
ori = np.zeros((NF0, 2, NLOC), np.int16)
for i in range(NF0):
    for h in range(2):
        hap[i, h] = (rng.random(NLOC) < p_true).astype(np.int8)
        ori[i, h] = 2 * i + h
p0 = hap.reshape(-1, NLOC).mean(0)            # founder (base) sample frequencies
# ---- QTL ----
cand_q = np.where((p0 > 0.02) & (p0 < 0.98))[0]
qtl = np.sort(rng.choice(cand_q, 300, replace=False))
# major QTL: locus on chr 0 closest to 50 cM with base MAF >= 0.3, not already a QTL
c0 = np.where((chrom == 0) & (np.minimum(p0, 1 - p0) >= 0.3))[0]
c0 = np.setdiff1d(c0, qtl)
major = c0[np.argmin(np.abs(pos[c0] - 50.0))]
a_eff = np.zeros(NLOC); d_eff = np.zeros(NLOC)
a_eff[qtl] = rng.normal(0, 1, len(qtl))
d_eff[qtl] = rng.normal(0.3, 0.3, len(qtl)) * np.abs(a_eff[qtl])
q0 = 1 - p0
alpha = a_eff + d_eff * (q0 - p0)                  # average effect of allele 1 (coded allele)
vA_poly = np.sum(2 * p0[qtl] * q0[qtl] * alpha[qtl] ** 2)
s = np.sqrt(0.27 / vA_poly)
a_eff *= s; d_eff *= s; alpha = a_eff + d_eff * (q0 - p0)
a_eff[major] = np.sqrt(0.03 / (2 * p0[major] * q0[major])); d_eff[major] = 0.0
alpha[major] = a_eff[major]
QTL = np.sort(np.r_[qtl, major])
vA = np.sum(2 * p0[QTL] * q0[QTL] * alpha[QTL] ** 2)
vD = np.sum((2 * p0[QTL] * q0[QTL] * d_eff[QTL]) ** 2)
vE = 1.0 - vA - vD
b_id = -2 * np.sum(p0[QTL] * q0[QTL] * d_eff[QTL])     # inbreeding depression per unit F (eq 27.18)
print(f'vA={vA:.4f} vD={vD:.4f} vE={vE:.4f}  major QTL locus {major} chr1 pos {pos[major]:.2f} cM p0={p0[major]:.3f} share {2*p0[major]*q0[major]*alpha[major]**2/vA:.3f}  b_ID={b_id:.4f}')
nonq = np.setdiff1d(np.arange(NLOC), QTL)
markers = np.sort(rng.choice(nonq, 6000, replace=False))


def geno_values(M):
    x = M[:, QTL].astype(float)
    het = (M[:, QTL] == 1).astype(float)
    Gv = (x - 1) @ a_eff[QTL] + het @ d_eff[QTL]
    BV = (x - 2 * p0[QTL]) @ alpha[QTL]
    return Gv, BV


def gamete(ph, po):
    gh = np.empty(NLOC, np.int8); go = np.empty(NLOC, np.int16)
    for c in range(NCHR):
        sl = slice(c * NPER, (c + 1) * NPER)
        nco = rng.poisson(LEN / 100.0)
        co = np.sort(rng.uniform(0, LEN, nco))
        which = (rng.integers(2) + np.searchsorted(co, pos[sl])) % 2
        cols = np.arange(c * NPER, (c + 1) * NPER)
        gh[sl] = ph[which, cols]; go[sl] = po[which, cols]
    return gh, go


sire = [0] * NF0; dam = [0] * NF0; sex = ['M'] * NF0M + ['F'] * NF0F; gen = [0] * NF0
HAP = [hap[i] for i in range(NF0)]; ORI = [ori[i] for i in range(NF0)]
M0 = hap.sum(1)
Gv0, BV0 = geno_values(M0)
Gv = list(Gv0); BV = list(BV0)
y = list(np.array(Gv) + rng.normal(0, np.sqrt(vE), NF0))
parents_m = list(range(1, NF0M + 1)); parents_f = list(range(NF0M + 1, NF0 + 1))
for g in (1, 2, 3):
    newM = []
    for k in range(400):
        s_ = int(rng.choice(parents_m)); d_ = int(rng.choice(parents_f))
        h1, o1 = gamete(HAP[s_ - 1], ORI[s_ - 1]); h2, o2 = gamete(HAP[d_ - 1], ORI[d_ - 1])
        HAP.append(np.stack([h1, h2])); ORI.append(np.stack([o1, o2]))
        sire.append(s_); dam.append(d_); sex.append('M' if k < 200 else 'F'); gen.append(g)
        newM.append(h1 + h2)
    newM = np.array(newM)
    gv, bv = geno_values(newM)
    Gv += list(gv); BV += list(bv)
    y += list(gv + rng.normal(0, np.sqrt(vE), 400))
    if g < 3:
        ids = [i + 1 for i in range(len(sire)) if gen[i] == g]
        yy = np.array(y)
        males = [i for i in ids if sex[i - 1] == 'M']; females = [i for i in ids if sex[i - 1] == 'F']
        parents_m = sorted(males, key=lambda i: -yy[i - 1])[:20]
        parents_f = sorted(females, key=lambda i: -yy[i - 1])[:100]
n = len(sire)
HAP = np.array(HAP); ORI = np.array(ORI)
Mall = HAP.sum(1).astype(np.int8)
A = buildA_fast(sire, dam)
Gv = np.array(Gv); BV = np.array(BV); y = np.array(y)
gen = np.array(gen); sex = np.array(sex)
# ---- G (VanRaden 1) with base (founder) frequencies, all animals, markers only ----
Z = Mall[:, markers].astype(float) - 2 * p0[markers]
k = 2 * np.sum(p0[markers] * q0[markers])
Gall = Z @ Z.T / k
print('G_all diag mean %.4f  A diag mean %.4f' % (np.diag(Gall).mean(), np.diag(A).mean()))
# ---- GBLUP (G_w = 0.98 G + 0.02 A) and pedigree BLUP; h2 = 0.30 ----
lam = (1 - 0.30) / 0.30
def mme(K):
    Ki = np.linalg.inv(K)
    X = np.ones((n, 1))
    C = np.block([[X.T @ X, X.T], [X, np.eye(n) + Ki * lam]])
    sol = np.linalg.solve(C, np.concatenate([X.T @ y, y]))
    return sol[1:]
gebv = mme(0.98 * Gall + 0.02 * A)
ebvA = mme(A)
cand = np.where(gen == 3)[0]
Mi = cand[sex[cand] == 'M']; Fi = cand[sex[cand] == 'F']
idx = np.r_[Mi, Fi]; nM = len(Mi)
print('candidates', len(idx), 'nM', nM)
print('acc GEBV %.4f  acc EBV_A %.4f' % (np.corrcoef(gebv[idx], BV[idx])[0, 1], np.corrcoef(ebvA[idx], BV[idx])[0, 1]))
# ---- realised IBD coancestry among candidates (all 15 000 loci) ----
def ibd_coanc(ids, loci):
    O = ORI[ids][:, :, loci]                          # (nc, 2, L)
    nc, _, Ln = O.shape
    rows = np.repeat(np.arange(nc), 2 * Ln)
    cols = (np.tile(np.arange(Ln), 2 * nc) * (2 * NF0) + O.reshape(nc, -1).ravel().astype(np.int64))
    E = sp.csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(nc, Ln * 2 * NF0))
    return (E @ E.T).toarray() / (4 * Ln)
Phi = ibd_coanc(idx, np.arange(NLOC))
np.savez_compressed('genome.npz', idx=idx, nM=nM, A=A[np.ix_(idx, idx)], Phi=Phi, Mc=Mall[idx], p0=p0, pos=pos, chrom=chrom,
                    markers=markers, QTL=QTL, major=major, a_eff=a_eff, d_eff=d_eff, alpha=alpha, gebv=gebv[idx], ebvA=ebvA[idx],
                    BV=BV[idx], Gv=Gv[idx], y=y[idx], ORIc=ORI[idx], vA=vA, vD=vD, vE=vE, b_id=b_id, sire=np.array(sire), dam=np.array(dam))
json.dump(dict(vA=vA, vD=vD, vE=vE, b_id=b_id, major=int(major), major_pos=float(pos[major]), major_p0=float(p0[major])), open('genome_meta.json', 'w'), indent=1)
print('saved')
