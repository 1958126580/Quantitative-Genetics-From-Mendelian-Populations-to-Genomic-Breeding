# -*- coding: utf-8 -*-
"""§34.2.8  Meuwissen (1997) Lagrange iteration vs SOCP (cvxpy/Clarabel)."""
import numpy as np, cvxpy as cp, json, time
from common import pop34034, ocs_socp


def lag_on_set(a, A, male, S, Cstar):
    """Lagrange solution (eqs 34.12-34.17) on index set S. Returns c_S, lam0, lam(2), feasible flag."""
    AS = A[np.ix_(S, S)]; aS = a[S]
    Q = np.zeros((len(S), 2)); Q[male[S], 0] = 1; Q[~male[S], 1] = 1
    s = np.array([0.5, 0.5])
    if Q[:, 0].sum() == 0 or Q[:, 1].sum() == 0:
        return None, None, None, False
    Ainv = np.linalg.inv(AS)
    AiQ = Ainv @ Q; M = np.linalg.inv(Q.T @ AiQ)
    Aia = Ainv @ aS
    PQa = Aia - AiQ @ (M @ (Q.T @ Aia))
    num = aS @ PQa; den = 2 * Cstar - s @ M @ s
    if den <= 0:
        return None, None, None, False
    lam0 = np.sqrt(num / den)
    c = PQa / lam0 + AiQ @ (M @ s)
    lam = M @ (Q.T @ Aia - lam0 * s)
    return c, lam0, lam, True


def meuwissen(a, A, male, Cstar, reentry=False, remove='all', maxit=2000):
    """Algorithm 34.1 (remove negatives) and, with reentry=True, algorithm 34.2 (KKT re-entry check)."""
    n = len(a); S = np.arange(n); it = 0; n_rem = 0; n_add = 0; seen = set()
    while it < maxit:
        it += 1
        cS, lam0, lam, ok = lag_on_set(a, A, male, S, Cstar)
        if not ok:
            return dict(ok=False, it=it, S=S)
        neg = cS < 0
        if neg.any():
            if remove == 'all':
                S = S[~neg]; n_rem += int(neg.sum())
            else:
                S = np.delete(S, np.argmin(cS)); n_rem += 1
            continue
        c = np.zeros(n); c[S] = cS
        # KKT reduced gains of excluded candidates:  g_k = a_k - lam0 (Ac)_k - lam_sex(k)
        Ac_ = A @ c
        lam_k = np.where(male, lam[0], lam[1])
        g = a - lam0 * Ac_ - lam_k
        excl = np.setdiff1d(np.arange(n), S)
        gmax = g[excl].max() if len(excl) else -np.inf
        if reentry and gmax > 1e-9:
            k = excl[np.argmax(g[excl])]
            key = tuple(sorted(np.r_[S, k]))
            if key in seen:
                return dict(ok=False, it=it, S=S, cycle=True)
            seen.add(key)
            S = np.sort(np.r_[S, k]); n_add += 1
            continue
        return dict(ok=True, it=it, c=c, lam0=lam0, lam=lam, gmax=gmax, n_rem=n_rem, n_add=n_add, S=S)
    return dict(ok=False, it=it, S=S)


if __name__ == '__main__':
    P = pop34034(); a, Ac, nM = P['a'], P['Ac'], P['nM']; n = len(a)
    male = np.r_[np.ones(nM, bool), np.zeros(n - nM, bool)]
    L = np.linalg.cholesky(Ac + 1e-10 * np.eye(n))
    out = {'full': []}
    print('=== 400 candidates: Lagrange (alg 34.1 / 34.2) vs SOCP ===')
    for Ct in (0.030, 0.035, 0.040, 0.045, 0.050, 0.060, 0.080):
        t0 = time.time(); r1 = meuwissen(a, Ac, male, Ct); t1 = time.time() - t0
        r2 = meuwissen(a, Ac, male, Ct, reentry=True)
        cs, obj, st, du = ocs_socp(a, Ac, nM, Ct, L=L, qform=True)
        cs_clip = cs.copy(); cs_clip[cs_clip < 1e-7] = 0
        row = dict(Ct=Ct)
        for lab, r in (('A1', r1), ('A2', r2)):
            if r['ok']:
                c = r['c']
                row[lab] = dict(obj=float(c @ a), coanc=float(c @ Ac @ c / 2), npar=int((c > 0).sum()), it=r['it'],
                                n_rem=r['n_rem'], n_add=r['n_add'], gmax=float(r['gmax']), lam0=float(r['lam0']),
                                dobj=float(c @ a - obj), dc=float(np.abs(c - cs).max()))
            else:
                row[lab] = dict(ok=False)
        row['socp'] = dict(obj=float(obj), coanc=float(cs @ Ac @ cs / 2), npar=int((cs_clip > 0).sum()), dual=float(np.ravel(du)[0]), status=st,
                           minc=float(cs.min()))
        # finite-difference marginal gain
        h = 1e-5
        cp_, objp, _, _ = ocs_socp(a, Ac, nM, Ct + h, L=L, qform=True)
        cm_, objm, _, _ = ocs_socp(a, Ac, nM, Ct - h, L=L, qform=True)
        row['fd'] = (objp - objm) / (2 * h)
        out['full'].append(row)
        A1 = row['A1']; A2 = row['A2']; S_ = row['socp']
        print(f"Ct={Ct:.3f}: A1 obj={A1.get('obj',np.nan):.6f} it={A1.get('it')} rem={A1.get('n_rem')} npar={A1.get('npar')} gmax={A1.get('gmax',np.nan):.2e} | "
              f"A2 obj={A2.get('obj',np.nan):.6f} add={A2.get('n_add')} npar={A2.get('npar')} | SOCP obj={S_['obj']:.6f} npar={S_['npar']} "
              f"| dobj(A1)={A1.get('dobj',np.nan):.2e} dc(A1)={A1.get('dc',np.nan):.2e} dobj(A2)={A2.get('dobj',np.nan):.2e} dc(A2)={A2.get('dc',np.nan):.2e} "
              f"| lam0={A2.get('lam0',np.nan):.5f} dual={S_['dual']:.5f} fd={row['fd']:.5f}  time A1 {t1:.2f}s")
    json.dump(out, open('s2_lag_full.json', 'w'), indent=1, default=float)
