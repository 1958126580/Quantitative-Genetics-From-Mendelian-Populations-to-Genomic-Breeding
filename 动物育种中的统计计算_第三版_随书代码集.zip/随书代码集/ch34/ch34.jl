# 本脚本由 tools/nb2jl.py 从同目录的 ch34.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 34

# %% [markdown]
# # 第三十四章　优化贡献选择与配种设计 —— 配套代码
#
# **内容**
#
# 1. OCS 的 **Lagrange 解**（正文式 34.12–34.17）与 Meuwissen 迭代剔除（算法 34.1）
# 2. 式 (34.16) 两个恒等式的数值验证
# 3. **OCS 作为 SOCP**：一个不依赖外部求解器的投影梯度实现（原理实现）
# 4. JuMP + Clarabel 的锥优化实现（优化实现，需安装 JuMP、Clarabel）
# 5. 遗传进展—近交的 Pareto 前沿
# 6. **配种分配是运输问题**：LP 松弛的整数性验证（正文式 34.27–34.28）、匈牙利算法
# 7. 与截断选择的多世代对照

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %%
"""按系谱递推构造 A（第九章）。"""
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

# %% [markdown]
# ## 1　OCS 的 Lagrange 解（正文式 34.12–34.17）

# %%
"""正文式 (34.14)–(34.17)：不含非负约束的 Lagrange 解。"""
function ocs_lagrange(a::Vector{Float64}, A::Matrix{Float64}, Q::Matrix{Float64},
                      s::Vector{Float64}, Cstar::Float64)
    Ai = inv(Symmetric(A))
    Mm = inv(Symmetric(Q'*Ai*Q))
    PQ = Ai - Ai*Q*Mm*Q'*Ai                          # 式 (34.14)
    cmin = 0.5*dot(s, Mm*s)                          # 可达的最小平均亲缘
    Cstar <= cmin && error("约束过紧：C* 必须大于 $(round(cmin, digits=5))")
    lam0 = sqrt(dot(a, PQ*a)/(2Cstar - dot(s, Mm*s)))   # 式 (34.17)
    c = PQ*a./lam0 .+ Ai*Q*Mm*s                      # 式 (34.15)
    return c, lam0, cmin, PQ
end

"""算法 34.1：Meuwissen (1997) 的迭代剔除。"""
function ocs_meuwissen(a, A, sexM::BitVector, Cstar; maxit=200)
    n = length(a); active = trues(n); c = zeros(n)
    for it in 1:maxit
        idx = findall(active)
        Q = hcat(Float64.(sexM[idx]), Float64.(.!sexM[idx]))
        s = [0.5, 0.5]
        cc, _, _, _ = ocs_lagrange(a[idx], A[idx,idx], Q, s, Cstar)
        neg = cc .< 0
        if !any(neg)
            c .= 0; c[idx] .= cc
            return c, it
        end
        active[idx[neg]] .= false
    end
    error("未收敛")
end

# 构造一个两代的系谱与 EBV
rng = Xoshiro(3401)
nb = 40; n1 = 160
sire = vcat(zeros(Int, nb), rand(rng, 1:20, n1))
dam  = vcat(zeros(Int, nb), rand(rng, 21:40, n1))
A = build_A(sire, dam)
cand = nb+1:nb+n1
Ac = A[cand, cand]
sexM = BitVector([isodd(i) for i in 1:n1])
# EBV 与家系相关（模拟共选择）
u = cholesky(Symmetric(Ac + 1e-9I)).L*randn(rng, n1)
ebv = u .+ 0.5.*randn(rng, n1)

Cbar_t = mean(Ac)/2
Cstar = Cbar_t + 0.01*(1 - Cbar_t)                    # 式 (34.10)，ΔF* = 1%
c, it = ocs_meuwissen(ebv, Ac, sexM, Cstar)
@printf("当前平均共祖 C̄_t = %.4f ， 目标 C* = %.4f\n", Cbar_t, Cstar)
@printf("Meuwissen 算法 %d 轮收敛\n", it)
@printf("获得正贡献的公畜 %d 头、母畜 %d 头\n",
        count(>(1e-8), c[sexM]), count(>(1e-8), c[.!sexM]))
@printf("贡献和：公 %.4f ， 母 %.4f\n", sum(c[sexM]), sum(c[.!sexM]))
@printf("½c'Ac = %.5f （约束 C* = %.5f）\n", 0.5*dot(c, Ac*c), Cstar)
@printf("c'â = %.4f\n", dot(c, ebv))

# %% [markdown]
# ## 2　式 (34.16) 的恒等式

# %%
Q = hcat(Float64.(sexM), Float64.(.!sexM)); s = [0.5, 0.5]
_, _, cmin, PQ = ocs_lagrange(ebv, Ac, Q, s, Cstar + 0.05)
check("P_Q A P_Q = P_Q", PQ*Ac*PQ, PQ; tol=1e-8)
@printf("‖P_Q Q‖ = %.2e （应为 0）%s\n", norm(PQ*Q), norm(PQ*Q) < 1e-8 ? "✔" : "✘")
@printf("可达的最小平均亲缘 ½s'Ms = %.5f （约束必须大于它）\n", cmin)

# %% [markdown]
# ## 3　OCS 作为 SOCP：投影梯度的原理实现
#
# 目标 $\max\ \mathbf c'\hat{\mathbf a}$，可行集 = {性别和、非负、$\tfrac12\mathbf c'\mathbf{Ac}\le C^*$}。
# 用**罚函数 + 投影到单纯形**的一阶方法求解，演示其全局最优性（凸问题），并与算法 34.1 比较。

# %%
"""把向量投影到 {x ≥ 0, sum(x) = z}（Duchi 等 2008）。"""
function proj_simplex(v::AbstractVector, z::Float64)
    n = length(v); u = sort(v; rev=true)
    css = cumsum(u); rho = 0
    for j in 1:n
        u[j] - (css[j] - z)/j > 0 && (rho = j)
    end
    theta = (css[rho] - z)/rho
    return max.(v .- theta, 0.0)
end

"""OCS 的罚函数投影梯度法（原理实现；凸问题 ⇒ 收敛到全局最优）。"""
function ocs_projgrad(a, A, sexM::BitVector, Cstar; iters=20_000, eta=1e-3, mu=2e3)
    n = length(a); c = zeros(n)
    c[sexM] .= 0.5/count(sexM); c[.!sexM] .= 0.5/count(.!sexM)
    for t in 1:iters
        viol = 0.5*dot(c, A*c) - Cstar
        g = a .- (viol > 0 ? mu*viol : 0.0) .* (A*c)        # 最大化 a'c - μ/2·max(0,viol)²
        c .+= eta .* g
        c[sexM]   .= proj_simplex(c[sexM], 0.5)
        c[.!sexM] .= proj_simplex(c[.!sexM], 0.5)
    end
    return c
end

cpg = ocs_projgrad(ebv, Ac, sexM, Cstar)
@printf("投影梯度：c'â = %.4f ， ½c'Ac = %.5f （C* = %.5f）\n",
        dot(cpg, ebv), 0.5*dot(cpg, Ac*cpg), Cstar)
@printf("Meuwissen：c'â = %.4f\n", dot(c, ebv))
@printf("两者贡献向量的相关 = %.4f\n", cor(cpg, c))
println("（罚函数法对约束只近似满足；生产中请用下一节的锥优化求解器。）")

# %% [markdown]
# ## 4　JuMP + Clarabel 的锥优化实现（优化实现）
#
# 这是正文式 (34.18)–(34.19) 的逐行翻译：约束 $\tfrac12\mathbf c'\mathbf{Ac}\le C^*$ 写成二阶锥 $\|\mathbf L'\mathbf c\|\le\sqrt{2C^*}$（$\mathbf A=\mathbf{LL}'$）。
# 需要可选环境 `envs/opt`（JuMP + Clarabel + HiGHS，见附录 E），默认 `RUN_JUMP = false`。
#
# **两个技术细节**：① JuMP 的宏（`@variable` 等）在代码**展开时**就需要 JuMP 已加载，所以函数定义放在 `@eval` 里，只有开关打开时才展开；② 定义与调用分放两个单元，避免"方法比当前世界更新"（world age）错误。

# %%
RUN_JUMP = false            # 先实例化可选环境 envs/opt（附录 E），再改为 true
if RUN_JUMP
    let env = joinpath(dirname(Base.active_project()), "envs", "opt")
        isdir(env) || (env = normpath(joinpath(pwd(), "..", "envs", "opt")))
        env in LOAD_PATH || push!(LOAD_PATH, env)   # 叠加可选环境（附录 E）
    end
    import JuMP, Clarabel, HiGHS
end

# %%
if RUN_JUMP
    @eval function ocs_socp(a_hat, A, sexM::BitVector, Cstar; cmax = 1.0)
        n = length(a_hat)
        L = cholesky(Symmetric(A + 1e-10I)).L
        model = JuMP.Model(Clarabel.Optimizer); JuMP.set_silent(model)
        JuMP.@variable(model, 0 <= c[1:n] <= cmax)
        JuMP.@objective(model, Max, sum(a_hat[i]*c[i] for i in 1:n))
        JuMP.@constraint(model, sum(c[i] for i in 1:n if sexM[i])  == 0.5)
        JuMP.@constraint(model, sum(c[i] for i in 1:n if !sexM[i]) == 0.5)
        JuMP.@constraint(model, [sqrt(2Cstar); L' * c] in JuMP.SecondOrderCone())   # 式 (34.18)
        JuMP.optimize!(model)
        stt = JuMP.termination_status(model)
        stt in (JuMP.OPTIMAL, JuMP.ALMOST_OPTIMAL) || error("求解失败：$stt")
        cv = JuMP.value.(c)
        return cv, JuMP.objective_value(model)
    end
end

# %%
if RUN_JUMP
    c_socp, obj = ocs_socp(ebv, Ac, sexM, Cstar)
    @printf("SOCP     ：c'â = %.4f ， ½c'Ac = %.5f （C* = %.5f）\n",
            obj, 0.5*dot(c_socp, Ac*c_socp), Cstar)
    @printf("Meuwissen：c'â = %.4f\n", dot(c, ebv))
    # §34.4.4 的可行性检查：求解器报告"最优"不等于约束真的满足
    @printf("可行性：½c'Ac - C* = %.2e （应 ≤ 1e-6）%s\n",
            0.5*dot(c_socp, Ac*c_socp) - Cstar,
            0.5*dot(c_socp, Ac*c_socp) <= Cstar + 1e-6 ? " ✔" : " ✘")
    @printf("全局最优性：SOCP 目标 - Meuwissen 目标 = %.2e （应 ≥ -1e-6）\n",
            obj - dot(c, ebv))
else
    println("RUN_JUMP = false：跳过 JuMP + Clarabel（正文 §34.4.1）。")
end

# %% [markdown]
# ## 5　遗传进展—近交的 Pareto 前沿

# %%
println("OCS 前沿：不同 ΔF* 下的最优 c'â\n")
@printf("%-12s%-14s%-14s%-14s%-12s\n", "ΔF*", "C*", "c'â", "公畜数", "母畜数")
front = Tuple{Float64,Float64}[]
for dF in (0.002, 0.005, 0.01, 0.02, 0.04, 0.08)
    Cs = Cbar_t + dF*(1 - Cbar_t)
    try
        cc, _ = ocs_meuwissen(ebv, Ac, sexM, Cs)
        push!(front, (dF, dot(cc, ebv)))
        @printf("%-12.3f%-14.5f%-14.4f%-14d%-12d\n", dF, Cs, dot(cc, ebv),
                count(>(1e-8), cc[sexM]), count(>(1e-8), cc[.!sexM]))
    catch err
        @printf("%-12.3f%-14.5f%-14s\n", dF, Cs, "不可行（约束过紧）")
    end
end
# 截断选择作为对照：每性别选前 k 个等贡献
let km = 5, kf = 20
    ct = zeros(n1)
    mi = findall(sexM); fi = findall(.!sexM)
    ct[mi[sortperm(ebv[mi]; rev=true)[1:km]]] .= 0.5/km
    ct[fi[sortperm(ebv[fi]; rev=true)[1:kf]]] .= 0.5/kf
    Ct = 0.5*dot(ct, Ac*ct); dFt = (Ct - Cbar_t)/(1 - Cbar_t)
    @printf("\n截断选择（%d 公 × %d 母）：ΔF = %.4f ， c'â = %.4f\n", km, kf, dFt, dot(ct, ebv))
    # 同样 ΔF 下 OCS 的 c'â
    cc, _ = ocs_meuwissen(ebv, Ac, sexM, Cbar_t + dFt*(1 - Cbar_t))
    @printf("同 ΔF 下 OCS：c'â = %.4f （提高 %.1f%%）\n", dot(cc, ebv),
            100*(dot(cc, ebv)/dot(ct, ebv) - 1))
end

# %% [markdown]
# ## 6　配种分配：运输问题与匈牙利算法（正文式 34.22–34.28）

# %%
"""匈牙利算法（Kuhn–Munkres），O(n³)，求最小权完美匹配。"""
function hungarian(Cm::Matrix{Float64})
    n = size(Cm, 1); @assert size(Cm, 2) == n
    u = zeros(n+1); v = zeros(n+1); p = zeros(Int, n+1); way = zeros(Int, n+1)
    for i in 1:n
        p[1] = i; j0 = 1
        minv = fill(Inf, n+1); used = falses(n+1)
        while true
            used[j0] = true; i0 = p[j0]; delta = Inf; j1 = 0
            for j in 2:n+1
                if !used[j]
                    cur = Cm[i0, j-1] - u[i0+1] - v[j]
                    if cur < minv[j]; minv[j] = cur; way[j] = j0; end
                    if minv[j] < delta; delta = minv[j]; j1 = j; end
                end
            end
            for j in 1:n+1
                if used[j]; u[p[j]+1] += delta; v[j] -= delta
                else; minv[j] -= delta; end
            end
            j0 = j1
            p[j0] == 0 && break
        end
        while true
            j1 = way[j0]; p[j0] = p[j1]; j0 = j1
            j0 == 1 && break
        end
    end
    assign = zeros(Int, n)
    for j in 2:n+1; p[j] != 0 && (assign[p[j]] = j-1); end
    return assign
end

# 把 OCS 的贡献换算成使用次数，并用"复制公畜"化为指派问题
mi = findall(sexM); fi = findall(.!sexM)
used_f = fi[c[fi] .> 1e-6]
nd = length(used_f)
nuse = [round(Int, 2*c[i]*nd) for i in mi]
while sum(nuse) != nd                                  # 舍入修正
    k = argmax(c[mi] .* 2nd .- nuse)
    sum(nuse) < nd ? (nuse[k] += 1) : (nuse[argmax(nuse)] -= 1)
end
slots = vcat([fill(mi[k], nuse[k]) for k in eachindex(mi)]...)
@printf("使用的公畜 %d 头、母畜 %d 头；配种槽 %d 个\n",
        count(>(0), nuse), nd, length(slots))

# 权重：后代近交 F_ij = a_ij / 2（式 34.23）
W = [Ac[slots[r], used_f[j]]/2 for r in eachindex(slots), j in 1:nd]
assign = hungarian(W)
F_opt = mean(W[r, assign[r]] for r in eachindex(slots))
F_rand = mean(W[r, randperm(Xoshiro(1), nd)[r]] for r in eachindex(slots))
@printf("后代平均近交：最优配种 %.5f ，随机配种 %.5f\n", F_opt, F_rand)

# 验证式 (34.28)：运输问题 LP 的全单模性——用贪心 + 交换检验匈牙利解的最优性
let best = sum(W[r, assign[r]] for r in eachindex(slots)), better = false, rg = Xoshiro(2)
    for _ in 1:5000
        a2 = copy(assign); i, j = rand(rg, 1:length(a2), 2)
        a2[i], a2[j] = a2[j], a2[i]
        sum(W[r, a2[r]] for r in eachindex(slots)) < best - 1e-12 && (better = true; break)
    end
    println(better ? "✘ 找到更好的交换——实现有误" : "✔ 5000 次随机交换均未改进：匈牙利解是最优的")
    global hung_ok = !better
end

# 纯加性下配对方式不影响后代均值（正文式 34.24 的注）
mean_off(asg) = mean(0.5*(ebv[slots[r]] + ebv[used_f[asg[r]]]) for r in eachindex(slots))
@printf("\n纯加性下后代期望均值：最优近交配种 %.6f ，随机配种 %.6f （应相等）\n",
        mean_off(assign), mean_off(randperm(Xoshiro(3), nd)))

# %% [markdown]
# ### 6.1　LP 松弛的整数性：JuMP + HiGHS（可选，正文式 34.27–34.28）
#
# 把指派问题写成运输问题的线性规划：$0\le x_{rj}\le1$，行和、列和都等于 1，**不加整数约束**。约束矩阵是二部图的关联矩阵，全单模，所以单纯形法返回的**顶点解必然是 0/1**——这就是正文式 (34.28) 的含义，也是配种分配可以用 LP（而不必用 MIP）求解的原因。下面用 HiGHS 的单纯形法验证两点：LP 最优值等于匈牙利算法的最优值；LP 解是整数。
#
# （为什么指定单纯形法：本例的权重矩阵有大量相同的零元，最优解不唯一；不带交叉（crossover）的内点法可能返回多个最优顶点的凸组合，看起来"不是整数"，但那并不违背全单模性。）

# %%
if RUN_JUMP
    @eval function assign_lp(W::Matrix{Float64})
        n = size(W, 1)
        model = JuMP.Model(HiGHS.Optimizer)
        JuMP.set_silent(model)
        JuMP.set_attribute(model, "solver", "simplex")
        JuMP.@variable(model, 0 <= x[1:n, 1:n] <= 1)            # 连续变量：LP 松弛
        JuMP.@objective(model, Min, sum(W[r, j]*x[r, j] for r in 1:n, j in 1:n))
        JuMP.@constraint(model, [r in 1:n], sum(x[r, j] for j in 1:n) == 1)
        JuMP.@constraint(model, [j in 1:n], sum(x[r, j] for r in 1:n) == 1)
        JuMP.optimize!(model)
        JuMP.termination_status(model) == JuMP.OPTIMAL || error("LP 未达最优")
        return JuMP.value.(x), JuMP.objective_value(model)
    end
end

# %%
if RUN_JUMP
    xlp, obj_lp = assign_lp(W)
    obj_h = sum(W[r, assign[r]] for r in eachindex(slots))
    dist01 = maximum(min.(abs.(xlp), abs.(xlp .- 1)))          # 与最近的 0/1 的最大距离
    @printf("LP 松弛最优值 = %.8f ，匈牙利最优值 = %.8f ，差 = %.2e\n",
            obj_lp, obj_h, obj_lp - obj_h)
    @printf("LP 解与 0/1 的最大距离 = %.2e  %s\n", dist01,
            dist01 < 1e-6 ? "✔ 顶点解是整数（全单模性，式 34.28）" : "✘")
else
    println("RUN_JUMP = false：跳过 LP 松弛的整数性验证（正文式 34.28）。")
end

# %% [markdown]
# ## 7　与截断选择的多世代对照（简化随机模拟）

# %%
"""用 A 矩阵与 BLUP 近似的多世代模拟：比较截断选择与 OCS。"""
function multi_gen(method::Symbol; ngen=6, nf0=30, nm0=10, noff=4, h2=0.3, dF=0.01, seed=1)
    rng = Xoshiro(seed)
    n0 = nf0 + nm0
    sire = zeros(Int, n0); dam = zeros(Int, n0)
    tbv = randn(rng, n0).*sqrt(h2)
    sexm = vcat(trues(nm0), falses(nf0))
    genv = zeros(Int, n0)
    res = NamedTuple[]
    cur = collect(1:n0)
    for g in 1:ngen
        A = build_A(sire, dam)
        Ac = A[cur, cur]
        y = tbv[cur] .+ randn(rng, length(cur)).*sqrt(1-h2)
        ebv = y                                        # 简化：个体表型作为 EBV
        sm = sexm[cur]
        if method === :trunc
            cc = zeros(length(cur))
            mi_ = findall(sm); fi_ = findall(.!sm)
            km = max(2, length(mi_) ÷ 5); kf = max(4, length(fi_) ÷ 2)
            cc[mi_[sortperm(ebv[mi_]; rev=true)[1:km]]] .= 0.5/km
            cc[fi_[sortperm(ebv[fi_]; rev=true)[1:kf]]] .= 0.5/kf
        else
            Cb = mean(Ac)/2
            Cs = Cb + dF*(1 - Cb)
            cc = nothing
            for _ in 1:20                           # 约束过紧时逐步放松（§34.2.2 可行性条件）
                try
                    cc, _ = ocs_meuwissen(ebv, Ac, BitVector(sm), Cs); break
                catch
                    Cs = Cb + 1.5*(Cs - Cb)
                end
            end
        end
        push!(res, (gen=g, mean_tbv=mean(tbv[cur]), F=mean(diag(Ac)) - 1))
        # 按贡献产生后代
        nnew = length(cur)
        dams_ = cur[.!sm]; sires_ = cur[sm]
        wf = cc[.!sm]; wm = cc[sm]
        newid = Int[]
        for k in 1:nnew
            d = dams_[rand(rng, Categorical(max.(wf, 0)./sum(max.(wf, 0))))]
            s = sires_[rand(rng, Categorical(max.(wm, 0)./sum(max.(wm, 0))))]
            push!(sire, s); push!(dam, d)
            ms = randn(rng)*sqrt(h2/2)
            push!(tbv, 0.5*(tbv[s] + tbv[d]) + ms)
            push!(sexm, isodd(k)); push!(genv, g)
            push!(newid, length(sire))
        end
        cur = newid
    end
    return res
end

rT = [multi_gen(:trunc; seed=s) for s in 1:8]
rO = [multi_gen(:ocs; seed=s) for s in 1:8]          # 共同种子：配对比较
@printf("%-8s%-16s%-16s%-14s%-14s\n", "世代", "截断 ū", "OCS ū", "截断 F", "OCS F")
for g in 1:length(rT[1])
    @printf("%-8d%-16.4f%-16.4f%-14.4f%-14.4f\n", g,
            mean(r[g].mean_tbv for r in rT), mean(r[g].mean_tbv for r in rO),
            mean(r[g].F for r in rT), mean(r[g].F for r in rO))
end
println("\n=> OCS 以较低的近交获得相近或更高的长期进展（正文 §34.5.3）。")

# %% [markdown]
# ## 8　自检汇总

# %%
ok = Bool[]
push!(ok, check("OCS 性别贡献 = (0.5, 0.5)", [sum(c[sexM]), sum(c[.!sexM])], [0.5, 0.5]; tol=1e-10))
push!(ok, 0.5*dot(c, Ac*c) <= Cstar + 1e-8)
@printf("OCS 约束满足：½c'Ac = %.6f ≤ C* = %.6f ✔\n", 0.5*dot(c, Ac*c), Cstar)
push!(ok, all(c .>= -1e-12))
push!(ok, check("P_Q A P_Q = P_Q", PQ*Ac*PQ, PQ; tol=1e-8))
push!(ok, hung_ok)
push!(ok, check("纯加性下配对不影响后代均值",
                mean_off(assign), mean_off(randperm(Xoshiro(3), nd)); tol=1e-12))
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
