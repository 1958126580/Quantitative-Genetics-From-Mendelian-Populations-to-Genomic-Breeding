# 第三十四章　优化贡献选择与配种设计 —— 配套代码

**所属**：第八篇　育种规划与遗传改良优化　　**对应正文**：第三十四章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch34.ipynb` | IJulia 笔记本：14 个代码单元，约 343 行 Julia 代码，穿插与正文对应的说明 |
| `ch34.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 11 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　OCS 的 Lagrange 解（正文式 34.12–34.17）
- 2　式 (34.16) 的恒等式
- 3　OCS 作为 SOCP：投影梯度的原理实现
- 4　JuMP + Clarabel 的锥优化实现（优化实现）
- 5　遗传进展—近交的 Pareto 前沿
- 6　配种分配：运输问题与匈牙利算法（正文式 34.22–34.28）
  - 6.1　LP 松弛的整数性：JuMP + HiGHS（可选，正文式 34.27–34.28）
- 7　与截断选择的多世代对照（简化随机模拟）
- 8　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 34
```

或在 Jupyter 中打开 `ch34/ch34.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 可选单元

- 开关 `RUN_JUMP`（默认 `false`）：JuMP + Clarabel + HiGHS（凸优化与整数规划）；需先实例化 `envs/opt`：`julia --project=envs/opt -e 'using Pkg; Pkg.instantiate()'`，再把笔记本中的开关改为 `true`。
- 开关关闭时只打印一行提示并跳过，不影响其余单元（见 `../README.md` 与正文附录 E）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
