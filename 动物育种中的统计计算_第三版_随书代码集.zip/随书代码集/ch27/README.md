# 第二十七章　稀有变异、非加性效应与复杂遗传结构 —— 配套代码

**所属**：第六篇　关联分析与统计基因组学　　**对应正文**：第二十七章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch27.ipynb` | IJulia 笔记本：10 个代码单元，约 470 行 Julia 代码，穿插与正文对应的说明 |
| `ch27.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 11 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　加权卡方混合的尾概率
- 2　模拟稀有变异数据
- 3　负荷检验与 SKAT
- 4　三种检验在不同效应结构下的功效
- 5　Hill–Goddard–Visscher：方差的"加性化"（正文式 27.22–27.23）
- 6　显性与上位关系矩阵、非加性模型的预测
- 7　杂种优势公式的验证（正文式 27.25）
- 8　印记效应模型（正文式 27.26–27.28）
- 9　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 27
```

或在 Jupyter 中打开 `ch27/ch27.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
