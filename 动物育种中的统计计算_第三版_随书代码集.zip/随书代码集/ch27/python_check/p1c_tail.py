# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 p1c_tail.py    依赖：numpy, scipy
# §27.1.6 极小 MAC 下的 I 型错误：取决于残差分布的尾部
# 统计量（N 很大、携带者均为杂合子时）t ≈ S_k / sqrt(k)，S_k = k 个标准化残差之和
import numpy as np
from scipy import stats, integrate
thr = 5e-8
c = stats.norm.isf(thr / 2)
print('two-sided z threshold: %.4f' % c)

# (1) 污染正态：1-eps 为 N(0,1)，eps 为 N(0, s^2)；整体标准化
def contam(k, eps=0.01, s=5.0):
    v = (1 - eps) + eps * s * s
    j = np.arange(0, k + 1)
    pj = stats.binom.pmf(j, k, eps)
    var_j = ((k - j) * 1.0 + j * s * s) / v
    return np.sum(pj * 2 * stats.norm.sf(c * np.sqrt(k) / np.sqrt(var_j)))

# (2) 标准化 t5：特征函数 phi(u) = exp(-sqrt3|u|)(1+sqrt3|u|+u^2)
def phi_t5(u):
    x = np.sqrt(3.0) * np.abs(u)
    return np.exp(-x) * (1 + x + u * u)

def tail_sum_t5(k):
    y = c * np.sqrt(k)
    if k == 1:
        return 2 * stats.t.sf(y * np.sqrt(5.0 / 3.0), 5)
    f = lambda u: phi_t5(u) ** k * np.sin(u * y) / u
    # 被积函数在 u 大时按 exp(-sqrt3 k u) 衰减；分段积分
    upper = 60.0 / k ** 0.5 + 40.0 / k
    edges = np.linspace(1e-12, upper, 4001)
    tot = 0.0
    for a, b in zip(edges[:-1], edges[1:]):
        v, e = integrate.quad(f, a, b, epsabs=1e-15, epsrel=1e-12, limit=200)
        tot += v
    return 1 - 2 / np.pi * tot

# 蒙特卡洛核对（中等尾部）
rng = np.random.default_rng(27106)
def mc_t5(k, y, R=2_000_000):
    s = np.zeros(R)
    for _ in range(k):
        s += rng.standard_t(5, R) / np.sqrt(5 / 3)
    return np.mean(np.abs(s) > y)

print('\nk | normal | contaminated(1%%, sd5) | t5 standardized | inflation(contam) | inflation(t5)')
for k in (1, 2, 5, 10, 20, 50, 100, 1000):
    pc = contam(k)
    pt = tail_sum_t5(k)
    print('%5d | %.2e | %.3e | %.3e | %.1f | %.1f' % (k, thr, pc, pt, pc / thr, pt / thr))

# numerical check of the inversion at moderate threshold (e.g. y=3*sqrt(k)) against MC
print('\ncheck of inversion vs MC at z=3 threshold')
for k in (2, 5, 20):
    y = 3.0 * np.sqrt(k)
    f = lambda u: phi_t5(u) ** k * np.sin(u * y) / u
    edges = np.linspace(1e-12, 60.0 / k ** 0.5 + 40.0 / k, 2001)
    tot = sum(integrate.quad(f, a, b, epsabs=1e-15, epsrel=1e-12, limit=200)[0] for a, b in zip(edges[:-1], edges[1:]))
    print(k, 'inversion %.5e' % (1 - 2 / np.pi * tot), 'MC %.5e' % mc_t5(k, y))

print('\nMC check with z-scores (R=4e6, seed 27106 continues)')
for k in (2, 5, 20):
    y = 3.0 * np.sqrt(k)
    f = lambda u: phi_t5(u) ** k * np.sin(u * y) / u
    edges = np.linspace(1e-12, 60.0 / k ** 0.5 + 40.0 / k, 2001)
    tot = sum(integrate.quad(f, a, b, epsabs=1e-15, epsrel=1e-12, limit=200)[0] for a, b in zip(edges[:-1], edges[1:]))
    pinv = 1 - 2 / np.pi * tot
    pm = np.mean([mc_t5(k, y, R=2_000_000) for _ in range(2)])
    se = np.sqrt(pinv * (1 - pinv) / 4e6)
    print(k, 'inv %.5e MC %.5e  z=%.2f' % (pinv, pm, (pm - pinv) / se))
