# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 qf.py    依赖：mpmath, numpy, scipy
# 加权卡方和 Q = sum_k lam_k * chi2_1 的尾概率：多种方法
import numpy as np
from scipy import stats, optimize, integrate
import mpmath as mp


def cumulants(lam):
    lam = np.asarray(lam, float)
    return lam.sum(), (lam ** 2).sum(), (lam ** 3).sum(), (lam ** 4).sum()


def satterthwaite(q, lam):
    c1, c2, _, _ = cumulants(lam)
    g = c2 / c1; h = c1 * c1 / c2
    return stats.chi2.sf(q / g, h)


def liu(q, lam, variant='skew'):
    """Liu, Tang & Zhang (2009) 矩匹配。中心二次型恒有 s1^2 <= s2（Cauchy-Schwarz），
    故走 delta=0 分支：variant='skew' 用 l=1/s1^2（匹配偏度，原始论文）；
    variant='kurt' 用 l=1/s2（匹配峰度的变体）。"""
    c1, c2, c3, c4 = cumulants(lam)
    s1 = c3 / c2 ** 1.5; s2 = c4 / c2 ** 2
    if s1 * s1 > s2:
        a = 1 / (s1 - np.sqrt(s1 * s1 - s2)); d = s1 * a ** 3 - a * a; l = a * a - 2 * d
    else:
        d = 0.0
        if variant == 'skew':
            a = 1 / s1; l = 1 / s1 ** 2
        else:
            l = 1 / s2; a = np.sqrt(l)
    muQ = c1; sigQ = np.sqrt(2 * c2)
    muX = l + d; sigX = np.sqrt(2) * a
    t = (q - muQ) / sigQ * sigX + muX
    return stats.ncx2.sf(t, l, d) if d > 0 else stats.chi2.sf(t, l)


def saddlepoint(q, lam):
    lam = np.asarray(lam, float)
    K = lambda t: -0.5 * np.sum(np.log1p(-2 * lam * t))
    K1 = lambda t: np.sum(lam / (1 - 2 * lam * t))
    K2 = lambda t: np.sum(2 * lam ** 2 / (1 - 2 * lam * t) ** 2)
    tmax = 1 / (2 * lam.max())
    if abs(q - lam.sum()) < 1e-8 * lam.sum():
        return 0.5
    lo = -1e6 / lam.max() if q < lam.sum() else 0.0
    hi = tmax * (1 - 1e-15) if q > lam.sum() else 0.0
    # K1 单调递增
    if q > lam.sum():
        th = optimize.brentq(lambda t: K1(t) - q, 0.0, hi, xtol=1e-300, rtol=1e-15, maxiter=500)
    else:
        a = -1.0 / lam.max()
        while K1(a) > q:
            a *= 2
        th = optimize.brentq(lambda t: K1(t) - q, a, 0.0, xtol=1e-300, rtol=1e-15, maxiter=500)
    w = np.sign(th) * np.sqrt(2 * (th * q - K(th)))
    v = th * np.sqrt(K2(th))
    return stats.norm.sf(w) + stats.norm.pdf(w) * (1 / v - 1 / w)


def cf(u, lam):
    # phi(u) = prod (1 - 2 i lam u)^(-1/2)
    z = 1 - 2j * np.outer(u, lam)
    return np.exp(-0.5 * np.log(z).sum(axis=1))


def chernoff_upper(y, lam):
    # P(Q>y) <= min_t exp(-t y) M(t)
    lam = np.asarray(lam, float)
    tmax = 1 / (2 * lam.max())
    f = lambda t: -t * y - 0.5 * np.sum(np.log1p(-2 * lam * t))
    res = optimize.minimize_scalar(f, bounds=(0, tmax * (1 - 1e-12)), method='bounded', options={'xatol': 1e-14 * tmax})
    return np.exp(min(res.fun, 0.0))


def davies_like(q, lam, acc=1e-6, return_info=False):
    """Davies (1973) 的特征函数梯形（中点）反演：
    P(Q>q) = 1/2 + sum_k Im[phi(u_k) e^{-i u_k q}] / (pi (k+1/2)),  u_k=(k+1/2)Delta。
    按目标绝对误差 acc 选取积分步长（混叠误差 <= acc/2，用 Chernoff 界）与截断项数（截断误差 <= acc/2）。"""
    lam = np.asarray(lam, float)
    # 1) 混叠：取周期 L=2pi/Delta，使 P(Q > q+L) <= acc/2 且 q-L < 0
    lo, hi = lam.sum(), lam.sum() + 10.0
    while chernoff_upper(hi, lam) > acc / 2:
        hi = lo + 2 * (hi - lo)
    y = optimize.brentq(lambda t: chernoff_upper(t, lam) - acc / 2, lo, hi, xtol=1e-10)
    L = max(q * 1.0001, y - q) * 1.0001
    delta = 2 * np.pi / L
    # 2) 截断：sum_{k>K} |phi(u_k)|/(pi(k+1/2)) <= acc/2
    absphi = lambda u: np.exp(-0.25 * np.sum(np.log1p(4 * np.outer(np.atleast_1d(u), lam) ** 2), axis=1))
    # 逐块累积尾和（先生成足够长的序列）
    K = 1024
    while True:
        k = np.arange(K)
        terms = absphi((k + 0.5) * delta) / (np.pi * (k + 0.5))
        # 尾部用积分界：sum_{k>=K} <= (1/pi) int_{(K-1/2)... } 近似以最后一项的衰减率外推
        tail_int = integrate.quad(lambda u: absphi(u)[0] / (np.pi * u), (K - 0.5) * delta, np.inf, limit=500)[0]
        if tail_int <= acc / 2:
            break
        K *= 2
    # 精确截断位置：找到最小 K' 使 sum_{k>=K'} terms + tail_int <= acc/2
    cs = np.cumsum(terms[::-1])[::-1] + tail_int
    Kp = int(np.argmax(cs <= acc / 2)) if np.any(cs <= acc / 2) else K
    Kp = max(Kp, 1)
    k = np.arange(Kp)
    u = (k + 0.5) * delta
    ph = cf(u, lam)
    s = np.sum(np.imag(ph * np.exp(-1j * u * q)) / (np.pi * (k + 0.5)))
    p = 0.5 + s
    if return_info:
        return p, Kp, delta
    return p


def imhof_mp(q, lam, dps=40, nsub=None):
    """高精度 Imhof 积分（mpmath）：P(Q>q) = 1/2 + (1/pi) int_0^inf sin(theta(u)) / (u rho(u)) du"""
    mp.mp.dps = dps
    lamn = np.asarray(lam, float)
    sc = lamn.max()
    L = [mp.mpf(float(l / sc)) for l in lamn]
    x = mp.mpf(float(q / sc))
    m = len(L)

    def f(u):
        if u == 0:
            return (mp.fsum(L) - x) / 2
        th = mp.fsum([mp.atan(l * u) for l in L]) / 2 - x * u / 2
        lr = mp.fsum([mp.log(1 + (l * u) ** 2) for l in L]) / 4
        return mp.sin(th) / (u * mp.exp(lr))
    # 积分上限：|integrand| <= prod (l u)^{-1/2} / u；取 U 使尾部 < 10^{-(dps-5)}
    lmin = min(L)
    # 保守地找 U
    U = mp.mpf(10)
    while True:
        lr = mp.fsum([mp.log(1 + (l * U) ** 2) for l in L]) / 4
        bound = mp.exp(-lr) / (mp.mpf(m) / 2)  # ∫_U^∞ u^{-1-m/2}... 近似界
        if bound < mp.mpf(10) ** (-(dps - 5)):
            break
        U *= 2
    # 按振荡半周期切分
    per = 2 * mp.pi / max(x / 2, mp.mpf('1e-3'))
    n = int(mp.ceil(U / per * 2)) + 1 if nsub is None else nsub
    n = min(max(n, 50), 20000)
    pts = [U * mp.mpf(i) / n for i in range(n + 1)]
    val = mp.quad(f, pts, method='gauss-legendre')
    return mp.mpf('0.5') + val / mp.pi


def tail_contour(x, lam):
    """精确尾概率：Bromwich 反演积分沿过鞍点的竖直线 Re t = t_hat 计算
    P(Q>x) = (1/2 pi i) int M(t) e^{-t x} dt / t,  t = t_hat + i y
    被积函数在 y=0 附近不振荡、量级即为尾概率本身，因此在极端尾部也有相对精度。"""
    lam = np.asarray(lam, float)
    c1 = lam.sum()
    assert x > c1
    K = lambda t: -0.5 * np.sum(np.log1p(-2 * lam * t))
    K1 = lambda t: np.sum(lam / (1 - 2 * lam * t))
    K2 = lambda t: np.sum(2 * lam ** 2 / (1 - 2 * lam * t) ** 2)
    hi = 1 / (2 * lam.max())
    th = optimize.brentq(lambda t: K1(t) - x, 0.0, hi * (1 - 1e-15), xtol=1e-300, rtol=1e-15, maxiter=1000)
    base = K(th) - th * x
    s = 1 / np.sqrt(K2(th))

    def g(y):
        t = th + 1j * y
        lm = -0.5 * np.sum(np.log(1 - 2 * lam * t))
        return (np.exp(lm - t * x - base) / t).real
    # 分段：鞍点尺度 s 的倍数，再到无穷
    edges = [0.0] + [s * k for k in (0.5, 1, 2, 4, 8, 16, 32, 64, 128)]
    ea = 1e-16 * s / th  # 绝对容差：相对于主峰面积 ~ s/t_hat 的 1e-16
    I = 0.0
    for a, b in zip(edges[:-1], edges[1:]):
        I += integrate.quad(g, a, b, epsabs=ea, epsrel=1e-13, limit=500)[0]
    I += integrate.quad(g, edges[-1], np.inf, epsabs=ea, epsrel=1e-12, limit=2000)[0]
    return np.exp(base) * I / np.pi


def tail_pairs_exact(x, mu):
    """每个特征值恰出现两次（chi2_2 混合）时的闭式：P(Q>x)=sum_k A_k exp(-x/(2 mu_k))"""
    mu = np.asarray(mu, float)
    tot = 0.0
    for k in range(len(mu)):
        A = np.prod([mu[k] / (mu[k] - mu[j]) for j in range(len(mu)) if j != k])
        tot += A * np.exp(-x / (2 * mu[k]))
    return tot
