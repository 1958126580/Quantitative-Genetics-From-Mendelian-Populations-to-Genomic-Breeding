# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 p2d_contour_check.py    依赖：numpy
# 核对 Bromwich 过鞍点积分（tail_contour）与 chi2_2 混合闭式解
import sys, warnings
import numpy as np
warnings.filterwarnings('ignore')
sys.path.insert(0, '.')
from qf import tail_contour, tail_pairs_exact
mu = np.array([1.0, 0.6, 0.35, 0.2, 0.1])
lam = np.repeat(mu, 2)
worst = 0
for x in [5, 10, 20, 40, 60, 80]:
    pe = tail_pairs_exact(x, mu); pc = tail_contour(x, lam)
    worst = max(worst, abs(pc / pe - 1))
    print('x=%g exact %.12e contour %.12e rel.err %.2e' % (x, pe, pc, abs(pc / pe - 1)))
print('max rel err %.2e' % worst)
