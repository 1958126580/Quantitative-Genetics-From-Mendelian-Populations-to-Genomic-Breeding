# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 p2_skatnull.py    依赖：numpy, scipy
# §27.1.7  SKAT 零分布：各种尾概率方法的数值对照
import sys, time
import numpy as np
from scipy import stats
sys.path.insert(0, '.')
import warnings
warnings.filterwarnings('ignore')
from qf import satterthwaite, liu, saddlepoint, davies_like, tail_contour, cumulants

def region(seed, n=2000, m=30, lo=0.001, hi=0.01, weight='beta'):
    rng = np.random.default_rng(seed)
    maf = rng.uniform(lo, hi, m)
    G = rng.binomial(2, maf, size=(n, m)).astype(float)
    Gc = G - G.mean(0)
    if weight == 'beta':
        w = stats.beta.pdf(maf, 1, 25)
    else:
        w = np.ones(m)
    GW = Gc * w
    lam = np.linalg.eigvalsh(GW.T @ GW)
    lam = lam[lam > 1e-8 * lam.max()]
    return np.sort(lam)[::-1], G

which = sys.argv[1] if len(sys.argv) > 1 else 'A'
if which == 'A':
    lam, G = region(27107)
    print('Region A: n=2000, 30 variants MAF~U(0.001,0.01), Beta(1,25) weights, seed 27107')
elif which == 'B':
    # 一个低频变异主导：等权，29 个稀有变异 + 1 个 MAF=0.04 变异
    rng = np.random.default_rng(27108)
    n, m = 2000, 30
    maf = np.r_[rng.uniform(0.001, 0.01, m - 1), 0.04]
    Gm = rng.binomial(2, maf, size=(n, m)).astype(float)
    Gc = Gm - Gm.mean(0)
    lam = np.linalg.eigvalsh(Gc.T @ Gc)
    lam = np.sort(lam[lam > 1e-8 * lam.max()])[::-1]
    print('Region B: n=2000, 29 variants MAF~U(0.001,0.01) + 1 variant MAF=0.04, equal weights, seed 27108')
lam = lam / lam.sum()  # 归一化：E(Q)=1（尾概率与尺度无关）
c1, c2, c3, c4 = cumulants(lam)
print('number of eigenvalues', len(lam))
print('lam (normalized to sum 1): max %.4f min %.5f  ratio max/min %.1f' % (lam.max(), lam.min(), lam.max() / lam.min()))
print('effective df c1^2/c2 = %.2f; skew s1=%.4f kurt s2=%.4f' % (c1 * c1 / c2, c3 / c2 ** 1.5, c4 / c2 ** 2))
print('largest eigenvalue share %.4f' % (lam.max() / lam.sum()))

targets = [1e-2, 1e-4, 1e-6, 1e-8, 1e-10, 1e-12, 1e-14]
from scipy import optimize
rows = []
for pt in targets:
    q = optimize.brentq(lambda t: saddlepoint(t, lam) - pt, c1 * 1.0001, c1 + 400 * np.sqrt(2 * c2))
    pex = tail_contour(q, lam)
    res = dict(q=q, exact=pex, sat=satterthwaite(q, lam), liu_s=liu(q, lam, 'skew'),
               liu_k=liu(q, lam, 'kurt'), spa=saddlepoint(q, lam),
               dav6=davies_like(q, lam, acc=1e-6), dav10=davies_like(q, lam, acc=1e-10))
    rows.append(res)
    print('target %.0e q=%.5f (in units of E(Q)) exact=%.6e' % (pt, q, pex))
    for k in ('sat', 'liu_s', 'liu_k', 'spa', 'dav6', 'dav10'):
        print('    %-6s p=% .6e  ratio=% .4f' % (k, res[k], res[k] / pex))
    sys.stdout.flush()

# 蒙特卡洛核对两个最大的 p
rng = np.random.default_rng(271071)
R = 10_000_000
cnt = np.zeros(2)
qs = [rows[0]['q'], rows[1]['q']]
for chunk in range(R // 1_000_000):
    Q = np.zeros(1_000_000)
    for l in lam:
        Q += l * rng.chisquare(1, 1_000_000)
    cnt[0] += np.sum(Q > qs[0]); cnt[1] += np.sum(Q > qs[1])
for i in range(2):
    pm = cnt[i] / R
    se = np.sqrt(rows[i]['exact'] * (1 - rows[i]['exact']) / R)
    print('MC (1e7) at q=%.5f: %.6e  exact %.6e  z=%.2f' % (qs[i], pm, rows[i]['exact'], (pm - rows[i]['exact']) / se))
