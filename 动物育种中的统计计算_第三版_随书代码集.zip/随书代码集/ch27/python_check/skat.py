# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 skat.py    依赖：numpy, scipy
import numpy as np
from scipy import stats
def liu_pvalue(q, lam):
    c1=lam.sum(); c2=(lam**2).sum(); c3=(lam**3).sum(); c4=(lam**4).sum()
    s1=c3/c2**1.5; s2=c4/c2**2
    muQ=c1; sigQ=np.sqrt(2*c2)
    if s1**2>s2:
        a=1/(s1-np.sqrt(s1**2-s2)); d=s1*a**3-a**2; l=a**2-2*d
    else:
        a=1/np.sqrt(s2); d=0; l=1/s2
    muX=l+d; sigX=np.sqrt(2)*a
    t=(q-muQ)/sigQ*sigX+muX
    return stats.ncx2.sf(t, l, d) if d>0 else stats.chi2.sf(t, l)
def tests(G, y, w):
    n=len(y); yc=y-y.mean(); s2=yc.var(ddof=1)
    Gc=G-G.mean(0)
    # burden
    b=Gc@w
    if b.std()==0: pb=1.0
    else:
        r=np.corrcoef(b,y)[0,1]; t=r*np.sqrt((n-2)/(1-r*r)); pb=2*stats.t.sf(abs(t),n-2)
    # SKAT: Q = yc' G W^2 G' yc / s2 ; null ~ sum lam chi2_1, lam = eig(W G_c' G_c W)
    GW=Gc*w
    Q=np.sum((GW.T@yc)**2)/s2
    lam=np.linalg.eigvalsh(GW.T@GW); lam=lam[lam>1e-10]
    ps=liu_pvalue(Q, lam)
    return pb, ps
rng=np.random.default_rng(27027)
n,m=2000,30; R=1000; alpha=1e-3
def scen(kind, c):
    maf=rng.uniform(0.001,0.01,m)
    G=rng.binomial(2,maf,size=(n,m)).astype(float)
    w=stats.beta.pdf(maf,1,25)
    beta=np.zeros(m)
    if kind!='null':
        frac={'all_pos':0.5,'mixed':0.5,'sparse_pos':0.1}[kind]
        k=max(1,int(round(frac*m))); causal=rng.choice(m,k,replace=False)
        size=c*np.abs(np.log10(maf[causal]))
        if kind=='mixed': size*=rng.choice([-1,1],k)
        beta[causal]=size
    y=G@beta+rng.normal(0,1,n)
    return G,y,w
for kind,c in (('null',0),('all_pos',0.15),('mixed',0.15),('sparse_pos',0.35)):
    rb=rs=rc=0
    for r in range(R):
        G,y,w=scen(kind,c); pb,ps=tests(G,y,w)
        rb+=pb<alpha; rs+=ps<alpha; rc+=min(1,2*min(pb,ps))<alpha
    print(f'{kind:11s} c={c:.2f}  burden={rb/R:.3f}  SKAT={rs/R:.3f}  min-p Bonferroni={rc/R:.3f}')
# type I at 0.05 as well
rb=rs=0
for r in range(R):
    G,y,w=scen('null',0); pb,ps=tests(G,y,w); rb+=pb<0.05; rs+=ps<0.05
print('null @0.05: burden=%.3f SKAT=%.3f'%(rb/R,rs/R))
