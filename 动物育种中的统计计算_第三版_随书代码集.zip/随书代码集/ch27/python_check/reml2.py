# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 reml2.py    依赖：numpy, scipy
# 稳健版 AI-REML：对数似然线搜索 + 边界上的投影步
import numpy as np
from scipy import linalg


def _eval(theta, y, X, mats, need_deriv=True):
    n = len(y)
    V = sum(t * K for t, K in zip(theta, mats))
    try:
        L = linalg.cho_factor(V, lower=True, check_finite=False)
    except linalg.LinAlgError:
        return None
    Vi = linalg.cho_solve(L, np.eye(n), check_finite=False)
    ViX = Vi @ X
    XViX = X.T @ ViX
    XViXi = np.linalg.inv(XViX)
    P = Vi - ViX @ XViXi @ ViX.T
    Py = P @ y
    logdetV = 2 * np.sum(np.log(np.diag(L[0])))
    logdetX = np.linalg.slogdet(XViX)[1]
    logL = -0.5 * (logdetV + logdetX + y @ Py)
    out = dict(logL=logL, P=P, Py=Py, Vi=Vi, ViX=ViX, XViXi=XViXi)
    if need_deriv:
        KPy = [K @ Py for K in mats]
        PKPy = [P @ v for v in KPy]
        k = len(mats)
        out['grad'] = np.array([-0.5 * (np.sum(P * K) - Py @ v) for K, v in zip(mats, KPy)])
        out['AI'] = np.array([[0.5 * KPy[i] @ PKPy[j] for j in range(k)] for i in range(k)])
    return out


def aireml(y, X, Ks, init=None, maxit=200, tol=1e-8, min_frac=1e-8, unconstrained=None):
    n = len(y)
    mats = list(Ks) + [np.eye(n)]
    k = len(mats)
    vy = np.var(y, ddof=1)
    lo = min_frac * vy
    theta = np.array(init, float) if init is not None else np.full(k, vy / k)
    unc = np.zeros(k, bool) if unconstrained is None else np.r_[np.asarray(unconstrained, bool), False]
    if unconstrained is not None and init is None:
        theta[unc] = 0.0
    lov = np.where(unc, -np.inf, lo)
    cur = _eval(theta, y, X, mats)
    conv = False
    for it in range(maxit):
        g, AI = cur['grad'], cur['AI']
        # 活动集：处在下界且梯度指向外侧的分量固定不动
        free = ~((theta <= lo * 1.0000001) & (g < 0) & ~unc)
        step = np.zeros(k)
        step[free] = np.linalg.solve(AI[np.ix_(free, free)], g[free])
        lam = 1.0
        improved = False
        for _ in range(30):
            new = np.maximum(theta + lam * step, lov)
            nxt = _eval(new, y, X, mats)
            if nxt is not None and nxt['logL'] >= cur['logL'] - 1e-10:
                improved = True
                break
            lam *= 0.5
        if not improved:
            conv = True
            break
        dl = nxt['logL'] - cur['logL']
        theta, cur = new, nxt
        if abs(dl) < tol and np.max(np.abs(lam * step)) < 1e-6 * vy:
            conv = True
            break
    AI = cur['AI']
    free = (theta > lo * 1.0000001) | unc
    se = np.full(k, np.nan)
    try:
        C = np.linalg.inv(AI[np.ix_(free, free)])
        se[free] = np.sqrt(np.maximum(np.diag(C), 0))
    except np.linalg.LinAlgError:
        pass
    b = cur['XViXi'] @ (cur['ViX'].T @ y)
    return dict(theta=theta, se=se, logL=cur['logL'], it=it, converged=conv, b=b, Py=cur['Py'], P=cur['P'], at_bound=~free)
