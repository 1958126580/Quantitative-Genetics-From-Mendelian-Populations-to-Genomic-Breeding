# 第 27 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch27/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `p1_power.py` | §27.1.6  单变异检验功效的解析计算 | numpy, scipy | 1.4 | `outputs/p1_power.out` |
| `p1b_mac.py` | §27.1.6 携带者数的随机性：期望 ncp 下的功效 vs 对基因型计数取平均的功效 | numpy, scipy | 1.4 | `outputs/p1b_mac.out` |
| `p1c_tail.py` | §27.1.6 极小 MAC 下的 I 型错误：取决于残差分布的尾部 | numpy, scipy | 11.4 | `outputs/p1c_tail.out` |
| `p2_skatnull.py` | §27.1.7  SKAT 零分布：各种尾概率方法的数值对照 | mpmath, numpy, scipy | 23.2 | `outputs/p2_skatnull.out` |
| `p2_table.py` | 生成表 27.5 的格式化行 | 标准库 | 0.0 | `outputs/p2_table.out` |
| `p2d_contour_check.py` | 核对 Bromwich 过鞍点积分（tail_contour）与 chi2_2 混合闭式解 | mpmath, numpy, scipy | 4.8 | `outputs/p2d_contour_check.out` |
| `p7b_summary.py` | 汇总 §27.3.5 印记模拟 | numpy | 0.2 | `outputs/p7b_summary.out` |
| `p8_cnv.py` | §27.3.6  CNV 关联的编码问题：精确的群体 R^2 -> 非中心参数 -> 功效 | numpy, scipy | 1.4 | `outputs/p8_cnv.out` |
| `reml.py` | 多核 AI-REML（平均信息 REML），用于本章的方差组分估计 | numpy, scipy | 0.4 | `outputs/reml.out` |
| `reml2.py` | 稳健版 AI-REML：对数似然线搜索 + 边界上的投影步 | numpy, scipy | 0.4 | `outputs/reml2.out` |
| `skat.py` | 数值复核 | numpy, scipy | 27.3 | `outputs/skat.out` |

公共函数模块（被上列脚本导入，不单独运行）：`qf.py`。
