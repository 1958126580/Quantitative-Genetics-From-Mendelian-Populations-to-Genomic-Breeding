# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 p2_table.py    依赖：仅标准库
# 生成表 27.5 的格式化行
import re
def fmt(r):
    if 0.1 <= r < 10: return '%.3f' % r
    if 10 <= r < 1000: return '%.3g' % r if r < 100 else '%.0f' % r
    if r >= 1000:
        e = int(__import__('math').floor(__import__('math').log10(r))); m = r / 10 ** e
        return '$%.1f\\times10^{%d}$' % (m, e)
    if r >= 0.001: return '%.2g' % r if r >= 0.01 else '%.1g' % r if False else ('%.4f' % r).rstrip('0')
    e = int(__import__('math').floor(__import__('math').log10(r))); m = r / 10 ** e
    return '$%.1f\\times10^{%d}$' % (m, e)
def pfmt(p):
    e = int(__import__('math').floor(__import__('math').log10(p))); m = p / 10 ** e
    return '$%.2f\\times10^{%d}$' % (m, e)
for fn, lab in (('out_p2_A.txt', 'A'), ('out_p2_B.txt', 'B')):
    txt = open(fn).read()
    blocks = re.findall(r'target (\S+) q=\S+ \(in units of E\(Q\)\) exact=(\S+)\n((?:    .*\n){6})', txt)
    for t, ex, body in blocks:
        if t == '1e-14': continue
        d = dict(re.findall(r'    (\S+)\s+p=\s*\S+\s+ratio=\s*(\S+)', body))
        # 重新从 p 与 exact 计算比值（避免 4 位小数截断）
        ps = dict(re.findall(r'    (\S+)\s+p=\s*(\S+)', body))
        exv = float(ex)
        cells = [fmt(float(ps[k]) / exv) for k in ('sat', 'liu_s', 'liu_k', 'spa', 'dav6', 'dav10')]
        print('| %s | %s | ' % (lab, pfmt(exv)) + ' | '.join(cells) + ' |')
