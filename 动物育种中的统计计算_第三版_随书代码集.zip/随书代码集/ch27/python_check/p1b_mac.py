# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 p1b_mac.py    依赖：numpy, scipy
# §27.1.6 携带者数的随机性：期望 ncp 下的功效 vs 对基因型计数取平均的功效
import numpy as np
from scipy import stats, optimize
from scipy.special import gammaln
thr = 5e-8
c = stats.chi2.isf(thr, 1)
ncp80 = optimize.brentq(lambda t: stats.ncx2.sf(c, 1, t) - 0.8, 1e-6, 500)

def avg_power(N, p, a, n2max=8, pad=14):
    q = 1 - p
    lp0, lp1, lp2 = 2 * np.log(q), np.log(2 * p * q), 2 * np.log(p)
    mu = 2 * N * p * q
    n1max = int(mu + pad * np.sqrt(mu) + 40)
    tot = 0.0; pw = 0.0; p_le = 0.0
    for n2 in range(0, n2max + 1):
        n1 = np.arange(0, n1max + 1)
        n0 = N - n1 - n2
        ok = n0 >= 0
        n1 = n1[ok]; n0 = n0[ok]
        lpm = gammaln(N + 1) - gammaln(n0 + 1) - gammaln(n1 + 1) - gammaln(n2 + 1) + n0 * lp0 + n1 * lp1 + n2 * lp2
        pr = np.exp(lpm)
        sxx = n1 + 4 * n2 - (n1 + 2 * n2) ** 2 / N
        pwk = np.where(sxx <= 0, 0.0, stats.ncx2.sf(c, 1, np.maximum(sxx, 1e-12) * a * a))
        tot += pr.sum(); pw += (pr * pwk).sum()
    return pw / tot, tot

p = 0.001
print('MAF fixed at 0.001; power at 5e-8')
print('ncp_target | E(MAC) | N | alpha | P(MAC=0) | P(MAC<=E/2) | power@ncp | avg power | ratio')
for ncp_t in (20.0, ncp80):
    for emac in (4, 10, 20, 50, 200):
        N = int(round(emac / (2 * p)))
        a = np.sqrt(ncp_t / (N * 2 * p * (1 - p)))
        pw_mean = stats.ncx2.sf(c, 1, N * 2 * p * (1 - p) * a * a)
        pw_avg, tot = avg_power(N, p, a)
        p0 = (1 - p) ** (2 * N)
        ple = stats.binom.cdf(emac // 2, 2 * N, p)
        print('%6.2f | %4d | %6d | %.3f | %.3g | %.3f | %.4f | %.4f | %.3f  mass=%.10f' % (
            ncp_t, emac, N, a, p0, ple, pw_mean, pw_avg, pw_avg / pw_mean, tot))
