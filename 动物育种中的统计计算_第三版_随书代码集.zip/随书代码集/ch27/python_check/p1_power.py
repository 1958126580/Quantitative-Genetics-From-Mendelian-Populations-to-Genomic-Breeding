# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 p1_power.py    依赖：numpy, scipy
# §27.1.6  单变异检验功效的解析计算
import numpy as np
from scipy import stats, optimize
from scipy.special import gammaln

thr = 5e-8
c = stats.chi2.isf(thr, 1)
print('chi2 crit at 5e-8: %.4f' % c)
for target in (0.5, 0.8, 0.9):
    ncp = optimize.brentq(lambda t: stats.ncx2.sf(c, 1, t) - target, 1e-6, 500)
    print('ncp for power %.1f : %.4f' % (target, ncp))
ncp80 = optimize.brentq(lambda t: stats.ncx2.sf(c, 1, t) - 0.8, 1e-6, 500)

mafs = [0.001, 0.002, 0.005, 0.01, 0.02, 0.05]
effs = [0.25, 0.5, 1.0]
Ns = [1000, 5000, 20000, 100000]
print('\nTable: power at 5e-8 (sigma_e=1), ncp = N*2pq*alpha^2')
print('MAF | alpha | h2_j | ' + ' | '.join(str(n) for n in Ns) + ' | N80')
for p in mafs:
    for a in effs:
        h2 = 2 * p * (1 - p) * a * a
        pw = [stats.ncx2.sf(c, 1, n * h2) for n in Ns]
        n80 = ncp80 / h2
        print('%.3f | %.2f | %.2e | ' % (p, a, h2) + ' | '.join('%.3f' % x for x in pw) + ' | %.0f' % n80)

print('\nExpected MAC = 2Np')
for p in mafs:
    print(p, [2 * n * p for n in Ns], ['P(MAC=0)=%.3g' % ((1 - p) ** (2 * n)) for n in Ns])

# exact averaging over multinomial genotype counts (HWE)
def avg_power(N, p, a, n2max=8, pad=12):
    q = 1 - p
    lp0, lp1, lp2 = 2 * np.log(q), np.log(2 * p * q), 2 * np.log(p)
    mu = 2 * N * p * q
    n1max = int(mu + pad * np.sqrt(mu) + 30)
    tot = 0.0; pw = 0.0; pw_le = {}
    for n2 in range(0, n2max + 1):
        n1 = np.arange(0, n1max + 1)
        n0 = N - n1 - n2
        ok = n0 >= 0
        n1 = n1[ok]; n0 = n0[ok]
        lpm = gammaln(N + 1) - gammaln(n0 + 1) - gammaln(n1 + 1) - gammaln(n2 + 1) + n0 * lp0 + n1 * lp1 + n2 * lp2
        pr = np.exp(lpm)
        sxx = n1 + 4 * n2 - (n1 + 2 * n2) ** 2 / N
        pwk = stats.ncx2.sf(c, 1, sxx * a * a)
        pwk = np.where(sxx <= 0, thr, pwk)
        tot += pr.sum(); pw += (pr * pwk).sum()
    return pw / tot, tot

print('\nPower at expected ncp vs averaged over genotype counts')
cases = [(0.001, 1.0, 5000), (0.001, 1.0, 20000), (0.001, 0.5, 100000), (0.002, 0.5, 20000),
         (0.005, 0.5, 5000), (0.005, 0.25, 20000), (0.001, 1.0, 10000), (0.002, 1.0, 5000),
         (0.005, 0.5, 10000), (0.001, 0.5, 50000)]
for p, a, N in cases:
    h2 = 2 * p * (1 - p) * a * a
    ncp_mean = (N - 1) * h2
    pw_mean = stats.ncx2.sf(c, 1, ncp_mean)
    pw_avg, tot = avg_power(N, p, a)
    print('MAF=%.3f a=%.2f N=%6d E(MAC)=%.0f  ncp=%.2f  power@E(ncp)=%.4f  avg power=%.4f  (mass=%.8f)  P(MAC=0)=%.3g' % (
        p, a, N, 2 * N * p, ncp_mean, pw_mean, pw_avg, tot, (1 - p) ** (2 * N)))
