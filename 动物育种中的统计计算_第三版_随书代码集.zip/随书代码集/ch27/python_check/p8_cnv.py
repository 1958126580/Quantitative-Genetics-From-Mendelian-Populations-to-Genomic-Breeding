# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 p8_cnv.py    依赖：numpy, scipy
# §27.3.6  CNV 关联的编码问题：精确的群体 R^2 -> 非中心参数 -> 功效
import numpy as np
from scipy import stats
from itertools import combinations_with_replacement

f = {'del': 0.10, 'norm': 0.80, 'dup': 0.10}   # 单倍型拷贝状态频率
cn_h = {'del': 0, 'norm': 1, 'dup': 2}
# 二倍体基因型（无序单倍型对）及其 HWE 频率
G = []
for h1, h2 in combinations_with_replacement(['del', 'norm', 'dup'], 2):
    pr = f[h1] * f[h2] * (1 if h1 == h2 else 2)
    G.append(dict(h=(h1, h2), p=pr, cn=cn_h[h1] + cn_h[h2], ndel=(h1 == 'del') + (h2 == 'del'), ndup=(h1 == 'dup') + (h2 == 'dup')))
P = np.array([g['p'] for g in G]); CN = np.array([g['cn'] for g in G]); NDEL = np.array([g['ndel'] for g in G]); NDUP = np.array([g['ndup'] for g in G])
print('genotypes:', [(g['h'], round(g['p'], 4), g['cn']) for g in G])
for c in range(5):
    print('P(CN=%d)=%.4f' % (c, P[CN == c].sum()))
print('P(del/dup) = %.4f, share of CN=2 that is del/dup = %.4f' % (P[(NDEL == 1) & (NDUP == 1)].sum(), P[(NDEL == 1) & (NDUP == 1)].sum() / P[CN == 2].sum()))

# 真实模型（遗传值）
truth = {
    'T1 剂量线性': CN - 2.0,
    'T2 缺失隐性': (NDEL == 2).astype(float),
    'T3 缺失显性（单倍剂量不足）': (NDEL >= 1).astype(float),
    'T4 U 形（缺失与重复都有害）': np.abs(CN - 2.0),
}

def misclass(eps):
    """观测 CN：以概率 eps 移到相邻状态（两侧各 eps/2；边界状态移向内侧）"""
    Mx = np.zeros((5, 5))
    for c in range(5):
        if eps == 0:
            Mx[c, c] = 1; continue
        Mx[c, c] = 1 - eps
        if c == 0: Mx[c, 1] += eps
        elif c == 4: Mx[c, 3] += eps
        else:
            Mx[c, c - 1] += eps / 2; Mx[c, c + 1] += eps / 2
    return Mx

def r2_of(gvals, coding, eps):
    """群体（精确）R^2：g 对编码 X(obs CN) 的线性回归；联合分布 = 基因型 × 观测 CN"""
    Mx = misclass(eps)
    rows = []  # (prob, g, obs_cn, ndel)
    for k in range(len(G)):
        for o in range(5):
            w = P[k] * Mx[CN[k], o]
            if w > 0:
                rows.append((w, gvals[k], o, NDEL[k]))
    w = np.array([r[0] for r in rows]); g = np.array([r[1] for r in rows]); o = np.array([r[2] for r in rows]); nd = np.array([r[3] for r in rows])
    if coding == 'C1 拷贝数线性':
        Xc = o[:, None].astype(float)
    elif coding == 'C2 拷贝数分类':
        Xc = np.stack([(o == c).astype(float) for c in range(1, 5)], 1)
    elif coding == 'C3 缺失携带（CN<2）':
        Xc = (o < 2).astype(float)[:, None]
    elif coding == 'C4 重复携带（CN>2）':
        Xc = (o > 2).astype(float)[:, None]
    elif coding == 'C5 |CN-2|':
        Xc = np.abs(o - 2.0)[:, None]
    elif coding == 'C6 缺失标签 SNP（加性）':
        Xc = nd[:, None].astype(float)
    Xd = np.c_[np.ones(len(w)), Xc]
    Wm = np.diag(w)
    beta = np.linalg.pinv(Xd.T @ Wm @ Xd) @ (Xd.T @ Wm @ g)
    fit = Xd @ beta
    mg = np.sum(w * g)
    vg = np.sum(w * (g - mg) ** 2)
    vf = np.sum(w * (fit - mg) ** 2)
    df = np.linalg.matrix_rank(Xd.T @ Wm @ Xd) - 1
    return vf / vg, df

codings = ['C1 拷贝数线性', 'C2 拷贝数分类', 'C3 缺失携带（CN<2）', 'C4 重复携带（CN>2）', 'C5 |CN-2|', 'C6 缺失标签 SNP（加性）']
N = 5000; h2 = 0.01; thr = 5e-8
print('\nN=%d, locus h2=%.3f (of phenotypic variance), alpha=%.0e; ncp = N*R2*h2/(1-h2)' % (N, h2, thr))
for eps in (0.0, 0.1):
    print('\n== calling error eps=%.2f' % eps)
    print('true model | ' + ' | '.join(codings))
    for tn, gv in truth.items():
        cells = []
        for cd in codings:
            if cd.startswith('C6') and eps > 0:
                cells.append('   -  '); continue
            r2, df = r2_of(gv, cd, eps)
            ncp = N * r2 * h2 / (1 - h2)
            pw = stats.ncx2.sf(stats.chi2.isf(thr, df), df, ncp)
            cells.append('R2=%.3f df=%d pw=%.3f' % (r2, df, pw))
        print(tn, ' | '.join(cells))
# 缺失标签 SNP 与拷贝数的 r^2
r2t, _ = r2_of(CN - 2.0, 'C6 缺失标签 SNP（加性）', 0.0)
fd, fu = f['del'], f['dup']
theo = (2 * fd * (1 - fd) + 2 * fd * fu) ** 2 / (2 * fd * (1 - fd) * 2 * (fu * (1 - fu) + fd * (1 - fd) + 2 * fd * fu))
print('\nr2(deletion-tag SNP, CN) = %.4f (formula %.4f)' % (r2t, theo))
