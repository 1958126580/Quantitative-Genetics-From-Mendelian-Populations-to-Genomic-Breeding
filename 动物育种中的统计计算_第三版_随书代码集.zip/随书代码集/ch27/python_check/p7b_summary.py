# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 p7b_summary.py    依赖：numpy
# 汇总 §27.3.5 印记模拟
import re, sys, numpy as np
files = sys.argv[1:]
for f in files:
    L = [l for l in open(f) if ' rep ' in l]
    head = open(f).readline().strip()
    g = lambda l, pat: float(re.search(pat, l).group(1))
    A = np.array([[g(l, r'A-only A=([\d.]+)'), g(l, r'phased A=([\d.]+)'), g(l, r'\| phased A=[\d.]+\([\w.]+\) I=([\d.]+)'),
                   g(l, r'\| phased .*? share=([\d.]+)'), g(l, r'\| phased .*? p=([\d.e-]+)'),
                   g(l, r'parent-phased A=[\d.]+ I=([\d.]+)'), g(l, r'parent-phased .*? share=([\d.]+)'), g(l, r'parent-phased .*? p=([\d.e-]+)'),
                   g(l, r'unresolved frac of het=([\d.]+)')] for l in L])
    print(head, ' R=%d' % len(A))
    nm = ['Aonly_A', 'ph_A', 'ph_I', 'ph_share', 'ph_p', 'pp_I', 'pp_share', 'pp_p', 'unres']
    for i, n in enumerate(nm):
        if n.endswith('_p'):
            print('  %-9s  rejections at 0.05: %d/%d  (at 0.01: %d)' % (n, (A[:, i] < 0.05).sum(), len(A), (A[:, i] < 0.01).sum()))
        else:
            print('  %-9s mean %.4f sd %.4f' % (n, A[:, i].mean(), A[:, i].std(ddof=1)))
    print('  I at boundary (phased): %d ; (parent-phased): %d' % ((A[:, 2] < 1e-4).sum(), (A[:, 5] < 1e-4).sum()))
    d = A[:, 1] - A[:, 0]
    print('  phased A - A-only A: mean %.4f sd %.4f' % (d.mean(), d.std(ddof=1)))
    dg = [re.search(r'diagGI=([\d.]+) diagGI2=([\d.]+)', l) for l in L]
    if all(dg):
        D = np.array([[float(m.group(1)), float(m.group(2))] for m in dg])
        print('  mean diag GI %.4f GI2 %.4f ; implied VI (phased) %.4f (sd %.4f) ; implied VI (parent-phased) %.4f (sd %.4f)' % (
            D[:, 0].mean(), D[:, 1].mean(), (A[:, 2] * D[:, 0]).mean(), (A[:, 2] * D[:, 0]).std(ddof=1), (A[:, 5] * D[:, 1]).mean(), (A[:, 5] * D[:, 1]).std(ddof=1)))
    if 'S2' in f:
        x = [l for l in L if '3-kernel' in l]
        B = np.array([[g(l, r'3-kernel A=([\d.]+)'), g(l, r'3-kernel .*? I=([\d.]+)'), g(l, r'cov=([-\d.]+)'), g(l, r'3-kernel .*? share=([\d.]+)'), g(l, r'3-kernel .*? logL=([-\d.]+)'), g(l, r'logL2k=([-\d.]+)')] for l in x])
        print('  3-kernel: A %.4f I %.4f cov %.4f (sd %.4f) share %.4f (sd %.4f) ; mean logL gain over 2-kernel %.3f' % (
            B[:, 0].mean(), B[:, 1].mean(), B[:, 2].mean(), B[:, 2].std(ddof=1), B[:, 3].mean(), B[:, 3].std(ddof=1), (B[:, 4] - B[:, 5]).mean()))
