# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 27 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 reml.py    依赖：numpy, scipy
# 多核 AI-REML（平均信息 REML），用于本章的方差组分估计
import numpy as np
from scipy import linalg


def aireml(y, X, Ks, init=None, maxit=100, tol=1e-7, verbose=False, min_frac=1e-6):
    """y = X b + sum_k u_k + e,  u_k ~ N(0, K_k s_k),  e ~ N(0, I s_e)
    返回 dict(theta=[s_1..s_K, s_e], se, logL, it, converged, b, P_y 等)"""
    n = len(y)
    Ks = list(Ks)
    nk = len(Ks)
    vy = np.var(y, ddof=1)
    theta = np.array(init, float) if init is not None else np.full(nk + 1, vy / (nk + 1))
    mats = Ks + [np.eye(n)]
    logL_old = -np.inf
    conv = False
    for it in range(maxit):
        V = sum(t * K for t, K in zip(theta, mats))
        L = linalg.cho_factor(V, lower=True, check_finite=False)
        Vi = linalg.cho_solve(L, np.eye(n), check_finite=False)
        ViX = Vi @ X
        XViX = X.T @ ViX
        XViXi = np.linalg.inv(XViX)
        P = Vi - ViX @ XViXi @ ViX.T
        Py = P @ y
        logdetV = 2 * np.sum(np.log(np.diag(L[0])))
        sign, logdetX = np.linalg.slogdet(XViX)
        logL = -0.5 * (logdetV + logdetX + y @ Py)
        KPy = [K @ Py for K in mats]
        PKPy = [P @ v for v in KPy]
        grad = np.array([-0.5 * (np.sum(P * K) - Py @ v) for K, v in zip(mats, KPy)])
        AI = np.array([[0.5 * KPy[i] @ PKPy[j] for j in range(nk + 1)] for i in range(nk + 1)])
        if verbose:
            print(it, theta, logL)
        if abs(logL - logL_old) < tol and it > 0:
            conv = True
            break
        logL_old = logL
        step = np.linalg.solve(AI, grad)
        new = theta + step
        # 边界处理：负值截断到很小的正数
        lo = min_frac * vy
        if np.any(new < lo):
            new = np.maximum(new, lo)
        theta = new
    try:
        cov = np.linalg.inv(AI)
        se = np.sqrt(np.maximum(np.diag(cov), 0))
    except np.linalg.LinAlgError:
        cov = None; se = np.full(nk + 1, np.nan)
    b = XViXi @ (ViX.T @ y)
    return dict(theta=theta, se=se, cov=cov, logL=logL, it=it, converged=conv, b=b, Py=Py, P=P, Vi=Vi)


def blup(res, Ks_pred, k):
    """预测：u_k(pred) = K_k(pred, train) P y * s_k"""
    return res['theta'][k] * (Ks_pred @ res['Py'])
