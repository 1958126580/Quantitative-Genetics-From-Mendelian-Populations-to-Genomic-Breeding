# 本脚本由 tools/nb2jl.py 从同目录的 ch27.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 27

# %% [markdown]
# # 第二十七章　稀有变异、非加性效应与复杂遗传结构 —— 配套代码
#
# 本 Notebook 对应第二十七章。
#
# **内容**
#
# 1. 加权卡方混合分布的尾概率：**鞍点近似**与 **Liu 矩匹配**（正文式 27.11）
# 2. **负荷检验**（正文式 27.3–27.6）
# 3. **SKAT**（正文式 27.7–27.12）
# 4. **SKAT-O**（正文式 27.13）
# 5. 三种检验在不同效应结构下的功效比较
# 6. Hill–Goddard–Visscher：低频等位基因如何使方差"加性化"（正文式 27.22–27.23）
# 7. 显性与上位关系矩阵、非加性模型的预测比较
# 8. 杂种优势公式的数值验证（正文式 27.25）
# 9. 印记效应模型（正文式 27.26–27.28）

# %%
using LinearAlgebra, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %% [markdown]
# ## 1　加权卡方混合的尾概率
#
# $$Q\ \sim\ \sum_k\lambda_k\chi^2_{1,k}$$
#
# 本笔记本实现两种方法（正文式 27.11a 及其后的方法表）：
#
# - **鞍点近似（Lugannani–Rice，正文式 27.11a）**：对任意 $K$ 都稳健，极端尾部的**相对**误差仍然很小；
# - **Liu 矩匹配**：用（非中心）$\chi^2$ 匹配前四阶矩，$K=1$ 时精确。
#
# Imhof/Davies 的特征函数数值反演是精确方法（SKAT 软件包的默认），但精度以**绝对**误差为准，且实现需要仔细处理积分截断与步长（$K$ 很小时被积函数衰减缓慢）。这里用 $K=1$ 的精确 $\chi^2_1$ 与大样本蒙特卡洛作为基准；生产中可再调用 Davies 的成熟实现交叉核对。

# %%
"""累积量母函数及其一、二阶导（Q = Σ λ_k χ²_{1,k}）。"""
cgf_K(t, lam)   = -0.5*sum(log1p.(-2 .* lam .* t))
cgf_K1(t, lam)  = sum(lam ./ (1 .- 2 .* lam .* t))
cgf_K2(t, lam)  = sum(2 .* lam.^2 ./ (1 .- 2 .* lam .* t).^2)

"""简单稳健的二分法求根。"""
function bisect(f, a::Float64, b::Float64; tol=1e-14, maxit=300)
    fa, fb = f(a), f(b)
    fa*fb > 0 && error("区间端点同号")
    for _ in 1:maxit
        c = 0.5*(a+b); fc = f(c)
        (abs(fc) < 1e-300 || (b-a) < tol*max(1.0, abs(c))) && return c
        fa*fc < 0 ? (b, fb = c, fc) : (a, fa = c, fc)
    end
    return 0.5*(a+b)
end

"""鞍点近似（Lugannani–Rice）求 P(Q > q)。"""
function saddlepoint_sf(q::Float64, lam::Vector{Float64})
    l = filter(>(1e-12), lam)
    isempty(l) && return q > 0 ? 0.0 : 1.0
    mu = sum(l)
    abs(q - mu) < 1e-10*max(1.0, mu) && return 0.5
    hi = 1/(2*maximum(l))
    f(t) = cgf_K1(t, l) - q
    that = if q > mu
        bisect(f, 0.0, hi*(1 - 1e-12))
    else
        a = -1.0
        while f(a) > 0; a *= 2; a < -1e12 && break; end
        bisect(f, a, 0.0)
    end
    w = sign(that)*sqrt(max(2*(that*q - cgf_K(that, l)), 0.0))
    v = that*sqrt(cgf_K2(that, l))
    (abs(w) < 1e-9 || abs(v) < 1e-9) && return 0.5
    return ccdf(Normal(), w + log(v/w)/w)
end

"""Liu 等 (2009) 的四阶矩匹配。"""
function liu_sf(q::Float64, lam::Vector{Float64})
    c = [sum(lam.^k) for k in 1:4]
    muQ = c[1]; sigQ = sqrt(2*c[2])
    s1 = c[3]/c[2]^1.5; s2 = c[4]/c[2]^2
    if s1^2 > s2
        a = 1/(s1 - sqrt(s1^2 - s2)); d = s1*a^3 - a^2; l = a^2 - 2d
    else
        a = 1/s1; d = 0.0; l = 1/s1^2
    end
    muX = l + d; sigX = sqrt(2)*a
    Qs = (q - muQ)/sigQ*sigX + muX
    return d > 0 ? ccdf(NoncentralChisq(l, d), Qs) : ccdf(Chisq(l), Qs)
end

# 蒙特卡洛验证
println("加权卡方混合尾概率的验证\n")
for lam in ([1.0], [1.0,1.0,1.0], [5.0,2.0,1.0,0.5,0.1], collect(range(0.1, 3.0; length=30)))
    l = Vector{Float64}(lam)
    rng = Xoshiro(2701)
    mc = [sum(l .* rand(rng, Chisq(1), length(l))) for _ in 1:200_000]
    @printf("λ = %s%s\n", string(round.(l[1:min(5,end)], digits=2)), length(l) > 5 ? " ..." : "")
    for pct in (50, 90, 99, 99.9)
        q = quantile(mc, pct/100)
        @printf("   q=%9.3f  MC=%.5f  鞍点=%.5f  Liu=%.5f\n",
                q, mean(>(q), mc), saddlepoint_sf(q, l), liu_sf(q, l))
    end
end
println("\n深尾与 χ²₁ 精确值对照（λ = [1]）：")
for q in (10.0, 20.0, 30.0, 40.0)
    @printf("  q=%4.0f  精确=%.4e  鞍点=%.4e  Liu=%.4e\n",
            q, ccdf(Chisq(1), q), saddlepoint_sf(q, [1.0]), liu_sf(q, [1.0]))
end

# %% [markdown]
# ## 2　模拟稀有变异数据

# %%
"""模拟一个"基因"内的稀有变异集合与表型。

`pattern` 控制效应结构：:same（全同号）、:mixed（符号混杂）、:sparse（少数有效应）、:null（全零）。
"""
function sim_rare(; n=2000, mw=30, maf_lo=0.001, maf_hi=0.02,
                    pattern::Symbol=:same, h2_set=0.01, rng=Random.default_rng())
    p = maf_lo .+ (maf_hi - maf_lo) .* rand(rng, mw)
    Mg = zeros(n, mw)
    @inbounds for j in 1:mw, i in 1:n
        Mg[i,j] = Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j])
    end
    keep = findall(j -> 0 < sum(view(Mg,:,j)) < 2n, 1:mw)
    Mg = Mg[:, keep]; p = p[keep]; mw = length(keep)
    a = zeros(mw)
    if pattern === :same
        a .= 1.0
    elseif pattern === :mixed
        a .= rand(rng, (-1.0, 1.0), mw)
    elseif pattern === :sparse
        idx = randperm(rng, mw)[1:max(1, mw ÷ 6)]
        a[idx] .= 1.0
    end
    g = Mg*a
    if std(g) > 0 && pattern !== :null
        g .*= sqrt(h2_set)/std(g)
    else
        g .= 0.0
    end
    y = 10.0 .+ g .+ randn(rng, n).*sqrt(1 - (pattern === :null ? 0.0 : h2_set))
    return (y=y, G=Mg, p=p, a=a, mw=mw)
end

Dr = sim_rare(; n=2000, mw=30, pattern=:same, rng=Xoshiro(2710))
@printf("变异数 = %d ，MAF 范围 [%.4f, %.4f]\n", Dr.mw, minimum(Dr.p), maximum(Dr.p))
@printf("携带者总数（每个变异）中位数 = %.0f\n",
        median([count(>(0), view(Dr.G,:,j)) for j in 1:Dr.mw]))
println("\n单变异检验的最小 p 值（说明为什么必须聚合）：")
let n = length(Dr.y), yc = Dr.y .- mean(Dr.y)
    ps = Float64[]
    for j in 1:Dr.mw
        z = view(Dr.G,:,j) .- mean(view(Dr.G,:,j))
        zz = dot(z,z); zz < 1e-10 && continue
        a = dot(z,yc)/zz; s2 = (dot(yc,yc) - a^2*zz)/(n-2)
        push!(ps, ccdf(Chisq(1), a^2*zz/s2))
    end
    @printf("  最小 p = %.4f ，Bonferroni 阈值 = %.4f  →  %s\n",
            minimum(ps), 0.05/Dr.mw, minimum(ps) < 0.05/Dr.mw ? "检出" : "未检出")
end

# %% [markdown]
# ## 3　负荷检验与 SKAT

# %%
"""正文式 (27.15)：SKAT 默认的 Beta(1,25) 权重。"""
function beta_weights(p::Vector{Float64}; a1=1.0, a2=25.0)
    pm = min.(p, 1 .- p)
    return [pdf(Beta(a1, a2), x) for x in pm]
end

"""正文式 (27.3)–(27.4)：负荷检验。"""
function burden_test(y::Vector{Float64}, Gm::Matrix{Float64}, X::Matrix{Float64},
                     w::Vector{Float64})
    n = length(y)
    B = Gm*w
    Xa = hcat(X, B)
    bh = (Xa'Xa + 1e-10I) \ (Xa'y)
    r  = y .- Xa*bh
    s2 = dot(r,r)/(n - size(Xa,2))
    V  = inv(Symmetric(Xa'Xa + 1e-10I)) .* s2
    t2 = bh[end]^2/V[end,end]
    return t2, ccdf(Chisq(1), t2), bh[end]
end

"""正文式 (27.10)：SKAT 统计量与 (27.11)–(27.12) 的零分布。"""
function skat_test(y::Vector{Float64}, Gm::Matrix{Float64}, X::Matrix{Float64},
                   w::Vector{Float64}; method::Symbol=:saddlepoint)
    n = length(y)
    P0 = I - X*((X'X + 1e-12I)\X')            # 零模型的投影
    res = P0*y
    s2  = dot(res,res)/(n - size(X,2))
    Gw  = Gm .* w'
    Q   = dot(res, Gw*(Gw'res))/s2            # 标准化到 σ² = 1 的尺度
    # 式 (27.12)：只需 |S|×|S| 的矩阵
    A = Gw'*(P0*Gw)
    lam = filter(>(1e-10), eigvals(Symmetric(A)))
    p = method === :liu ? liu_sf(Q, lam) : saddlepoint_sf(Q, lam)
    return Q, p, lam
end

"""正文式 (27.13)：SKAT-O。用一族 ρ 并对最小 p 做校正（这里用参数自助校正）。"""
function skato_test(y::Vector{Float64}, Gm::Matrix{Float64}, X::Matrix{Float64},
                    w::Vector{Float64}; rhos=0.0:0.1:1.0, nboot::Int=2000,
                    rng=Random.default_rng())
    n = length(y)
    P0 = I - X*((X'X + 1e-12I)\X')
    Gw = Gm .* w'
    s2 = dot(P0*y, P0*y)/(n - size(X,2))

    """给定 ρ 的核矩阵：R_ρ = (1-ρ)*I + ρ 11'。"""
    kern(rho) = begin
        mw = size(Gw,2)
        Rr = (1-rho) .* Matrix(I, mw, mw) .+ rho .* ones(mw, mw)
        Fc = cholesky(Symmetric(Rr + 1e-12I))
        Gw*Fc.L
    end
    Qs = Float64[]; lams = Vector{Vector{Float64}}(); ps = Float64[]
    res = P0*y
    for rho in rhos
        Gr = kern(rho)
        Q  = dot(res, Gr*(Gr'res))/s2
        A  = Gr'*(P0*Gr)
        lam = filter(>(1e-10), eigvals(Symmetric(A)))
        push!(Qs, Q); push!(lams, lam); push!(ps, saddlepoint_sf(Q, lam))
    end
    pmin = minimum(ps)
    # 参数自助：在零模型下重抽残差，得到 p_min 的零分布
    cnt = 0
    for _ in 1:nboot
        yb = X*((X'X + 1e-12I)\(X'y)) .+ randn(rng, n).*sqrt(s2)
        rb = P0*yb
        s2b = dot(rb,rb)/(n - size(X,2))
        pmb = 1.0
        for (k, rho) in enumerate(rhos)
            Gr = kern(rho)
            Qb = dot(rb, Gr*(Gr'rb))/s2b
            pmb = min(pmb, saddlepoint_sf(Qb, lams[k]))
        end
        cnt += (pmb <= pmin)
    end
    return pmin, (cnt + 1)/(nboot + 1), ps
end

X1 = ones(length(Dr.y), 1)
w  = beta_weights(Dr.p)
@printf("Beta(1,25) 权重： MAF=0.001 → %.1f ， MAF=0.01 → %.1f ， MAF=0.05 → %.1f\n",
        pdf(Beta(1,25), 0.001), pdf(Beta(1,25), 0.01), pdf(Beta(1,25), 0.05))

tb, pb, gb = burden_test(Dr.y, Dr.G, X1, w)
Qs, ps_, lam = skat_test(Dr.y, Dr.G, X1, w)
@printf("\n效应全同号的集合：\n")
@printf("  负荷检验： χ² = %.2f ， p = %.3e ， γ̂ = %+.5f\n", tb, pb, gb)
@printf("  SKAT    ： Q  = %.2f ， p = %.3e ， 特征值个数 %d\n", Qs, ps_, length(lam))
@printf("  SKAT（Liu 方法）： p = %.3e\n", skat_test(Dr.y, Dr.G, X1, w; method=:liu)[2])

# %% [markdown]
# ## 4　三种检验在不同效应结构下的功效

# %%
function power_study(pattern::Symbol; nrep=120, n=2000, mw=30, h2=0.012, alpha=0.05,
                     seed=3000)
    hb = hs = ho = 0
    for rep in 1:nrep
        D = sim_rare(; n=n, mw=mw, pattern=pattern, h2_set=h2, rng=Xoshiro(seed+rep))
        X = ones(length(D.y), 1); w = beta_weights(D.p)
        _, pb, _ = burden_test(D.y, D.G, X, w)
        _, pss, _ = skat_test(D.y, D.G, X, w)
        pmin, po, _ = skato_test(D.y, D.G, X, w; rhos=0.0:0.25:1.0, nboot=300,
                                 rng=Xoshiro(seed+10_000+rep))
        hb += (pb < alpha); hs += (pss < alpha); ho += (po < alpha)
    end
    return hb/nrep, hs/nrep, ho/nrep
end

println("三种检验的功效（α = 0.05，n = 2000，30 个稀有变异）\n")
@printf("%-16s%-14s%-14s%-14s\n", "效应结构", "负荷", "SKAT", "SKAT-O")
for pat in (:null, :same, :mixed, :sparse)
    b, s, o = power_study(pat; nrep=80, seed=pat === :null ? 5000 : 3000)
    @printf("%-16s%-14.3f%-14.3f%-14.3f\n",
            pat === :null ? "全零（Type I）" : string(pat), b, s, o)
end
println("\n=> 与正文 §27.1.4 的表一致：")
println("   全同号时负荷最优；符号混杂或稀疏时 SKAT 最优；SKAT-O 两头都接近最优。")
println("   :null 一行给出实际的 Type I 错误率，应接近 0.05。")

# %% [markdown]
# ## 5　Hill–Goddard–Visscher：方差的"加性化"（正文式 27.22–27.23）

# %%
"""正文式 (27.22)：单位点的加性方差与显性方差。"""
var_add(p, a, d) = 2*p*(1-p)*(a + d*((1-p) - p))^2
var_dom(p, a, d) = (2*p*(1-p)*d)^2

println("σ_D²/σ_A² 随等位基因频率与显性度的变化（正文式 27.23）\n")
@printf("%-12s", "p")
for da in (0.5, 1.0, 2.0); @printf("%-16s", "d/a=$(da)"); end
println()
for p in (0.05, 0.10, 0.20, 0.30, 0.50, 0.70, 0.90)
    @printf("%-12.2f", p)
    for da in (0.5, 1.0, 2.0)
        a = 1.0; d = da*a
        @printf("%-16.4f", var_dom(p,a,d)/var_add(p,a,d))
    end
    println()
end
@printf("\n=> 即使完全显性（d/a = 1），p = 0.1 时 σ_D²/σ_A² 只有 %.4f（正文 §27.2.3）。\n",
        var_dom(0.1, 1.0, 1.0)/var_add(0.1, 1.0, 1.0))

# 全基因组层面的模拟验证
println("\n全基因组模拟：100 个位点，全部完全显性（d=a），频率由 U(0.05,0.95) 抽取")
let rng = Xoshiro(2720), n = 5000, m = 100
    p = 0.05 .+ 0.9 .* rand(rng, m)
    a = randn(rng, m); d = copy(a)                 # 完全显性
    Mg = [Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j]) for i in 1:n, j in 1:m]
    # 基因型值：G = a(x-1) + d(1 - |x-1|)  （x = 0,1,2）
    Gv = zeros(n)
    for j in 1:m, i in 1:n
        x = Mg[i,j]
        Gv[i] += a[j]*(x - 1) + d[j]*(1 - abs(x - 1))
    end
    # 用回归分解加性与显性
    Za = Mg .- 2 .* p'
    Wd = [let x = Mg[i,j], pj = p[j], qj = 1-p[j]
              x == 2 ? -2*qj^2 : x == 1 ? 2*pj*qj : -2*pj^2
          end for i in 1:n, j in 1:m]
    ba = (Za'Za + 1e-8I) \ (Za'Gv)
    ua = Za*ba
    rd = Gv .- ua
    bd = (Wd'Wd + 1e-8I) \ (Wd'rd)
    ud = Wd*bd
    @printf("  Var(G)  = %.4f\n", var(Gv))
    @printf("  Var(加性部分) = %.4f  （占 %.1f%%）\n", var(ua), 100*var(ua)/var(Gv))
    @printf("  Var(显性部分) = %.4f  （占 %.1f%%）\n", var(ud), 100*var(ud)/var(Gv))
    @printf("  理论 Σσ_A² = %.4f ， Σσ_D² = %.4f （比值 %.3f）\n",
            sum(var_add.(p, a, d)), sum(var_dom.(p, a, d)),
            sum(var_dom.(p, a, d))/sum(var_add.(p, a, d)))
    println("  => 即使基因作用完全显性，群体方差仍以加性为主（正文 §27.2.3）。")
end

# %% [markdown]
# ## 6　显性与上位关系矩阵、非加性模型的预测

# %%
"""正文式 (21.44)、(21.47)：显性编码与 D 矩阵。"""
function dominance_matrix(Mg::AbstractMatrix, p::AbstractVector)
    n, m = size(Mg); q = 1 .- p
    Wd = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        g = Mg[i,j]
        Wd[i,j] = g == 2 ? -2*q[j]^2 : g == 1 ? 2*p[j]*q[j] : -2*p[j]^2
    end
    return (Wd*Wd') ./ sum((2 .* p .* q).^2), Wd
end

"""正文式 (27.19)：上位关系矩阵（Hadamard 幂 + 迹标准化）。"""
function hadamard_epi(A::AbstractMatrix, B::AbstractMatrix)
    C = A .* B
    return C .* (size(C,1)/tr(C))
end

"""多随机效应的 BLUP（方差组分已知）。"""
function multi_blup(y, X, Ks::Vector{<:AbstractMatrix}, s2s::Vector{Float64}, s2e::Float64)
    n = length(y)
    V = s2e .* Matrix(I, n, n)
    for (K, s) in zip(Ks, s2s); V .+= s .* K; end
    Vi = inv(cholesky(Symmetric(V)))
    b  = (X'Vi*X) \ (X'Vi*y)
    r  = Vi*(y .- X*b)
    return [s .* (K*r) for (K, s) in zip(Ks, s2s)], b
end

# 模拟一个有显性的性状
let rng = Xoshiro(2730), n = 900, m = 800
    p = 0.1 .+ 0.8 .* rand(rng, m)
    Mg = [Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j]) for i in 1:n, j in 1:m]
    Za = Mg .- 2 .* p'
    Dm, Wd = dominance_matrix(Mg, p)
    Gm = (Za*Za') ./ (2*sum(p .* (1 .- p)))
    Gm .= 0.98 .* Gm .+ 0.02 .* Matrix(I, n, n)
    Dm .= 0.98 .* Dm .+ 0.02 .* Matrix(I, n, n)

    h2a, h2d = 0.30, 0.10
    ua = cholesky(Symmetric(Gm)).L*randn(rng, n); ua .*= sqrt(h2a)/std(ua)
    ud = cholesky(Symmetric(Dm)).L*randn(rng, n); ud .*= sqrt(h2d)/std(ud)
    Gtot = ua .+ ud
    y = 10.0 .+ Gtot .+ randn(rng, n).*sqrt(1 - h2a - h2d)
    X = ones(n,1)

    tr_ = 1:700; va = 701:n
    Xt = ones(length(tr_),1)
    function fit_predict(Ks, s2s)
        Ktr = [K[tr_, tr_] for K in Ks]
        us, b = multi_blup(y[tr_], Xt, Ktr, s2s, 1 - sum(s2s))
        # 预测验证集：u_va = K[va,tr] V⁻¹ (y-Xb)
        n_ = length(tr_)
        V = (1-sum(s2s)) .* Matrix(I, n_, n_)
        for (K, s) in zip(Ktr, s2s); V .+= s .* K; end
        r = inv(cholesky(Symmetric(V)))*(y[tr_] .- Xt*b)
        return sum(s .* (K[va, tr_]*r) for (K, s) in zip(Ks, s2s))
    end

    pA  = fit_predict([Gm], [h2a + h2d])
    pAD = fit_predict([Gm, Dm], [h2a, h2d])
    Gaa = hadamard_epi(Gm, Gm)
    pAE = fit_predict([Gm, Gaa], [h2a, h2d])

    @printf("非加性模型的预测比较（h²_A = %.2f, h²_D = %.2f）\n\n", h2a, h2d)
    @printf("%-22s%-20s%-20s\n", "模型", "预测基因型值 r", "预测育种值 r")
    @printf("%-22s%-20.4f%-20.4f\n", "A 模型",   cor(pA,  Gtot[va]), cor(pA,  ua[va]))
    @printf("%-22s%-20.4f%-20.4f\n", "A+D 模型", cor(pAD, Gtot[va]), cor(pAD, ua[va]))
    @printf("%-22s%-20.4f%-20.4f\n", "A+AA 模型", cor(pAE, Gtot[va]), cor(pAE, ua[va]))
    println("\n=> 加入显性提高了对**基因型值**的预测，但对**育种值**的预测无增益")
    println("   （显性离差不通过配子传递，正文式 27.17）。")
end

# %% [markdown]
# ## 7　杂种优势公式的验证（正文式 27.25）
#
# $$H_{AB}=\sum_j d_j\left(p_j^{(A)}-p_j^{(B)}\right)^2$$

# %%
let rng = Xoshiro(2740), m = 300, n = 20_000
    pA = rand(rng, m); pB = rand(rng, m)
    a  = randn(rng, m); d = 0.6 .* abs.(randn(rng, m))    # 显性方向一致（正）
    gval(x, aj, dj) = aj*(x - 1) + dj*(1 - abs(x - 1))
    draw(p) = Float64(rand(rng) < p)                      # 一个配子
    # 亲本群体 A、B 的均值
    muA = sum(pA[j]^2*gval(2,a[j],d[j]) + 2pA[j]*(1-pA[j])*gval(1,a[j],d[j]) +
              (1-pA[j])^2*gval(0,a[j],d[j]) for j in 1:m)
    muB = sum(pB[j]^2*gval(2,a[j],d[j]) + 2pB[j]*(1-pB[j])*gval(1,a[j],d[j]) +
              (1-pB[j])^2*gval(0,a[j],d[j]) for j in 1:m)
    # F1（父本来自 A、母本来自 B）的均值
    muF1 = sum(pA[j]*pB[j]*gval(2,a[j],d[j]) +
               (pA[j]*(1-pB[j]) + (1-pA[j])*pB[j])*gval(1,a[j],d[j]) +
               (1-pA[j])*(1-pB[j])*gval(0,a[j],d[j]) for j in 1:m)
    H_obs = muF1 - (muA + muB)/2
    H_the = sum(d[j]*(pA[j]-pB[j])^2 for j in 1:m)
    @printf("亲本 A 均值 = %.4f ， 亲本 B 均值 = %.4f ， F1 均值 = %.4f\n", muA, muB, muF1)
    @printf("杂种优势（观测）   H = %.6f\n", H_obs)
    @printf("式 (27.25) 的理论值 H = %.6f\n", H_the)
    @printf("相对误差 = %.3e\n", abs(H_obs - H_the)/abs(H_the))
    println("\n=> 杂种优势正比于亲本群体频率差异的平方——品种间杂交优于品系间。")
end

# %% [markdown]
# ## 8　印记效应模型（正文式 27.26–27.28）

# %%
"""模拟一个印记位点（父源表达）并用式 (27.26) 的模型检验。"""
function sim_imprinting(; n=3000, p=0.3, alpha_p=0.5, alpha_m=0.0, h2rest=0.2,
                          rng=Random.default_rng())
    zp = [Float64(rand(rng) < p) for _ in 1:n]     # 父源等位基因
    zm = [Float64(rand(rng) < p) for _ in 1:n]     # 母源等位基因
    y  = 10.0 .+ zp .* alpha_p .+ zm .* alpha_m .+
         randn(rng, n).*sqrt(1 - h2rest) .+ randn(rng, n).*sqrt(h2rest)
    return zp, zm, y
end

"""式 (27.27) 的两个检验：整体效应（2 df）与印记（1 df）。"""
function imprint_tests(zp, zm, y)
    n = length(y)
    X0 = ones(n,1)
    X2 = hcat(X0, zp, zm)                         # 式 (27.26)
    X1 = hcat(X0, zp .+ zm)                       # 忽略印记的加性模型
    rss(X) = begin
        b = (X'X + 1e-10I) \ (X'y); r = y .- X*b
        dot(r,r), b
    end
    r0, _  = rss(X0); r2, b2 = rss(X2); r1, b1 = rss(X1)
    F_overall = ((r0 - r2)/2)/(r2/(n-3))
    F_imprint = ((r1 - r2)/1)/(r2/(n-3))
    ap, am = b2[2], b2[3]
    return (F_overall=F_overall, p_overall=ccdf(FDist(2, n-3), F_overall),
            F_imprint=F_imprint, p_imprint=ccdf(FDist(1, n-3), F_imprint),
            alpha_p=ap, alpha_m=am,
            alpha=(ap+am)/2, imprint=(ap-am)/2,          # 式 (27.28)
            alpha_naive=b1[2])
end

println("印记效应的检测（真值 α_p = 0.5，α_m = 0，即完全父源表达）\n")
zp, zm, yi = sim_imprinting(; n=3000, alpha_p=0.5, alpha_m=0.0, rng=Xoshiro(2750))
t = imprint_tests(zp, zm, yi)
@printf("  α̂_p = %+.4f ， α̂_m = %+.4f\n", t.alpha_p, t.alpha_m)
@printf("  α̂ = (α̂_p+α̂_m)/2 = %+.4f ， î = (α̂_p-α̂_m)/2 = %+.4f  （式 27.28）\n",
        t.alpha, t.imprint)
@printf("  整体效应检验 F(2,·) = %.2f ， p = %.3e\n", t.F_overall, t.p_overall)
@printf("  印记检验     F(1,·) = %.2f ， p = %.3e\n", t.F_imprint, t.p_imprint)
@printf("\n  忽略印记的加性模型： α̂ = %+.4f\n", t.alpha_naive)
@printf("  => 效应被“稀释”到真值的 %.0f%%（正文 §27.3.1 的 IGF2 教训）\n",
        100*t.alpha_naive/0.5)

println("\n不同印记程度下的比较：")
@printf("%-24s%-14s%-14s%-14s%-14s\n", "(α_p, α_m)", "α̂_p", "α̂_m", "印记 p 值", "朴素 α̂")
for (ap, am) in ((0.5,0.0), (0.5,0.25), (0.25,0.25), (0.5,-0.5))
    zp2, zm2, y2 = sim_imprinting(; n=3000, alpha_p=ap, alpha_m=am, rng=Xoshiro(2760))
    tt = imprint_tests(zp2, zm2, y2)
    @printf("%-24s%-14.4f%-14.4f%-14.3e%-14.4f\n",
            "($(ap), $(am))", tt.alpha_p, tt.alpha_m, tt.p_imprint, tt.alpha_naive)
end
println("=> 最后一行（α_p = -α_m）：朴素加性模型完全看不到信号，而印记检验显著。")

# %% [markdown]
# ## 9　自检汇总

# %%
ok = Bool[]
push!(ok, check("鞍点法在 λ=[1] 处 ≈ χ²₁（q=5）",
                saddlepoint_sf(5.0, [1.0]), ccdf(Chisq(1), 5.0); tol=0.05))
push!(ok, check("Liu 法在 λ=[1] 处 = χ²₁（q=20）",
                liu_sf(20.0, [1.0]), ccdf(Chisq(1), 20.0); tol=1e-8))
push!(ok, check("λ = 全 1 时 Q ~ χ²_K（K=5, q=11）",
                liu_sf(11.0, ones(5)), ccdf(Chisq(5), 11.0); tol=1e-6))
# SKAT 的 Q 与式 (27.10) 右边一致
let X = ones(length(Dr.y),1), w = beta_weights(Dr.p)
    P0 = I - X*((X'X)\X'); res = P0*Dr.y
    s2 = dot(res,res)/(length(Dr.y) - 1)
    Q1 = dot(res, (Dr.G .* w')*((Dr.G .* w')'res))/s2
    Q2 = sum(w[j]^2*dot(view(Dr.G,:,j), res)^2 for j in 1:Dr.mw)/s2
    push!(ok, check("式 (27.10) 两种写法一致", Q1, Q2; tol=1e-10))
end
# 式 (27.12)：两个矩阵的非零特征值相同
let X = ones(length(Dr.y),1), w = beta_weights(Dr.p)
    P0 = I - X*((X'X)\X'); Gw = Dr.G .* w'
    l1 = sort(filter(>(1e-8), eigvals(Symmetric(P0*(Gw*Gw')*P0))); rev=true)
    l2 = sort(filter(>(1e-8), eigvals(Symmetric(Gw'*(P0*Gw)))); rev=true)
    k = min(length(l1), length(l2))
    push!(ok, check("式 (27.12) 非零特征值相同", l1[1:k], l2[1:k]; tol=1e-6))
end
# 显性编码的方差与正交性
let rng = Xoshiro(1), n = 100_000, p = 0.3
    x = [Float64(rand(rng) < p) + Float64(rand(rng) < p) for _ in 1:n]
    wd = [g == 2 ? -2*(1-p)^2 : g == 1 ? 2*p*(1-p) : -2*p^2 for g in x]
    za = x .- 2p
    @printf("显性编码： E(W)=%+.4e （理论 0）， Var(W)=%.5f （理论 %.5f）\n",
            mean(wd), var(wd; corrected=false), (2*p*(1-p))^2)
    @printf("          Cov(Z,W)=%+.4e （理论 0）\n", cov(za, wd; corrected=false))
    push!(ok, abs(mean(wd)) < 0.01 && abs(cov(za, wd; corrected=false)) < 0.01)
end
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
