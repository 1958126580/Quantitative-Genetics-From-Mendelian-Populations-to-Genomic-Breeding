# 第二十九章　统计机器学习基础 —— 配套代码

**所属**：第七篇　机器学习与深度学习在动物遗传育种中的应用　　**对应正文**：第二十九章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch29.ipynb` | IJulia 笔记本：16 个代码单元，约 648 行 Julia 代码，穿插与正文对应的说明 |
| `ch29.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 11 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　偏差—方差分解的数值验证（正文式 29.4–29.7）
- 2　有效自由度与正则化路径（正文式 29.11）
- 3　岭回归 ≡ GBLUP（定理 29.1）
- 4　LASSO 的坐标下降（正文式 29.20、算法 29.2）
- 5　弹性网络的分组效应（正文式 29.23）
- 6　核方法：核岭回归 ≡ GBLUP（定理 29.2）
- 7　树、随机森林与梯度提升的从零实现
- 8　随机森林的方差公式（正文式 29.43）
- 9　嵌套交叉验证（算法 29.1）与单层 CV 的乐观程度
- 10　六种方法在同一基因组数据上的公平比较
- 11　MLJ.jl 统一接口的对照（可选）
- 12　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 29
```

或在 Jupyter 中打开 `ch29/ch29.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 可选单元

- 开关 `RUN_MLJ`（默认 `false`）：MLJ、Flux、Lux 等（机器学习栈）；需先实例化 `envs/ml`：`julia --project=envs/ml -e 'using Pkg; Pkg.instantiate()'`，再把笔记本中的开关改为 `true`。
- 开关关闭时只打印一行提示并跳过，不影响其余单元（见 `../README.md` 与正文附录 E）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
