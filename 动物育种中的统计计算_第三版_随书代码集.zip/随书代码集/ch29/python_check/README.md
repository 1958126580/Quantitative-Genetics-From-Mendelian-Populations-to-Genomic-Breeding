# 第 29 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch29/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `ana_ncv.py` | 数值复核 | numpy | 0.2 | `outputs/ana_ncv.out` |
| `ana_pen.py` | 数值复核 | numpy | 0.1 | `outputs/ana_pen.out` |
| `ana_sub.py` | 数值复核 | numpy | 0.1 | `outputs/ana_sub.out` |
| `bv.py` | §29.1.5/§29.1.6: bias-variance decomposition of ridge, analytic vs Monte Carlo; | numpy, scipy | 8.3 | `outputs/bv.out` |
| `df.py` | §29.1.6: effective degrees of freedom tr(H) of GBLUP vs h2 / lambda, for several n. | numpy, scipy | 16.1 | `outputs/df.out` |
| `df2.py` | §29.1.6 addendum: mean reliability of training GEBVs vs df: Rbar = 1 - lam*df/tr(G) (ratio of sums), | numpy, scipy | 3.1 | `outputs/df2.out` |
| `gauss_chk.py` | 数值复核 | numpy, scipy | 4.6 | `outputs/gauss_chk.out` |
| `krr.py` | §29.3.6: kernel ridge regression == GBLUP == SNP-BLUP, four implementations; plus common scale pitfalls. | numpy, scipy, sklearn | 11.1 | `outputs/krr.out` |
| `lstab_marg.py` | Check eq. (29.26a): P(causal marker has the largest \|marginal r\| in its block) ~ Phi(delta/tau)^(K-1), | numpy, scipy | 14.7 | `outputs/lstab_marg.out` |
| `rf_gblup.py` | GBLUP reference on exactly the datasets of rf.py (same seeds/draw order) | numpy, scipy | 3.1 | `outputs/rf_gblup.out` |
| `test_grp.py` | singleton groups vs sklearn Lasso on standardized X | numpy, scipy, sklearn | 17.2 | `outputs/test_grp.out` |

公共函数模块（被上列脚本导入，不单独运行）：`common.py`、`grplasso.py`。
