# -*- coding: utf-8 -*-
"""Group LASSO by block coordinate descent with within-group orthonormalisation (eq. 29.25),
strong-rule screening and KKT checks.  Objective:
    (1/(2n)) ||y - mu - Xt theta||^2 + lam * sum_g sqrt(p_g) ||theta_g||,
where Xt_g = X_g V_g S_g^{-1} sqrt(n) satisfies Xt_g'Xt_g/n = I."""
import numpy as np


class GroupLasso:
    def __init__(self, groups):
        self.groups = groups  # list of index arrays

    def setup(self, X):
        n = X.shape[0]
        self.n = n
        self.xm = X.mean(0)
        Xc = X - self.xm
        self.T = []      # per-group transform: Xt_g = Xc_g @ T_g
        self.Xt = []
        self.pg = []
        for idx in self.groups:
            U, s, Vt = np.linalg.svd(Xc[:, idx], full_matrices=False)
            keep = s > 1e-8 * max(s[0], 1e-300)
            Tg = Vt[keep].T / s[keep] * np.sqrt(n)
            self.T.append(Tg)
            self.Xt.append(Xc[:, idx] @ Tg)
            self.pg.append(np.sqrt(len(idx)))
        self.pg = np.array(self.pg)
        self.Xall = np.hstack(self.Xt)
        self.slices = []
        o = 0
        for xt in self.Xt:
            self.slices.append(slice(o, o + xt.shape[1])); o += xt.shape[1]
        return self

    def grad_norms(self, r):
        c = self.Xall.T @ r / self.n
        return np.array([np.linalg.norm(c[sl]) for sl in self.slices])

    def lam_max(self, y):
        r = y - y.mean()
        return float(np.max(self.grad_norms(r) / self.pg))

    def path(self, y, lams, tol=1e-6, max_sweeps=5000):
        """returns list of theta vectors (concatenated) along lams (decreasing)."""
        n = self.n
        mu = y.mean()
        r = y - mu
        theta = np.zeros(self.Xall.shape[1])
        active = set()
        out = []
        lam_prev = lams[0]
        for lam in lams:
            c = self.grad_norms(r)
            strong = set(np.where(c >= self.pg * (2 * lam - lam_prev))[0]) | active
            while True:
                S = sorted(strong)
                for sweep in range(max_sweeps):
                    dmax = 0.0
                    for g in S:
                        sl = self.slices[g]
                        xg = self.Xt[g]
                        old = theta[sl]
                        z = old + xg.T @ r / n
                        nz = np.linalg.norm(z)
                        thr = lam * self.pg[g]
                        new = (1 - thr / nz) * z if nz > thr else np.zeros_like(z)
                        dlt = new - old
                        if np.any(dlt != 0):
                            r -= xg @ dlt
                            theta[sl] = new
                            dmax = max(dmax, float(np.max(np.abs(dlt))))
                    if dmax < tol:
                        break
                # KKT check on the rest
                c = self.grad_norms(r)
                viol = [g for g in range(len(self.groups)) if g not in strong and c[g] > lam * self.pg[g] * (1 + 1e-9)]
                if not viol:
                    break
                strong |= set(viol)
            active = {g for g in range(len(self.groups)) if np.any(theta[self.slices[g]] != 0)}
            out.append(theta.copy())
            lam_prev = lam
        self.mu = mu
        return out

    def predict(self, Xnew, theta):
        Xc = Xnew - self.xm
        f = np.full(Xnew.shape[0], self.mu)
        for g, idx in enumerate(self.groups):
            th = theta[self.slices[g]]
            if np.any(th != 0):
                f += Xc[:, idx] @ (self.T[g] @ th)
        return f

    def n_groups(self, theta):
        return sum(1 for sl in self.slices if np.any(theta[sl] != 0))


class GroupLassoGMD:
    """Non-orthonormalised group LASSO, penalty lam*sum_g sqrt(p_g)||beta_g|| on the given (standardised) X,
    objective (1/(2n))||y - mu - Xc beta||^2 + penalty; groupwise majorisation descent with
    L_g = largest eigenvalue of Xc_g'Xc_g/n."""
    def __init__(self, groups):
        self.groups = groups

    def setup(self, X):
        self.n = X.shape[0]; self.xm = X.mean(0); self.Xc = X - self.xm
        self.Xg = [self.Xc[:, idx] for idx in self.groups]
        self.L = np.array([np.linalg.eigvalsh(xg.T @ xg / self.n)[-1] for xg in self.Xg])
        self.pg = np.array([np.sqrt(len(idx)) for idx in self.groups])
        return self

    def lam_max(self, y):
        r = y - y.mean()
        return float(max(np.linalg.norm(xg.T @ r / self.n) / pg for xg, pg in zip(self.Xg, self.pg)))

    def path(self, y, lams, tol=1e-5, max_sweeps=20000):
        n = self.n; self.mu = y.mean(); r = y - self.mu
        beta = [np.zeros(len(idx)) for idx in self.groups]
        out = []
        for lam in lams:
            for sweep in range(max_sweeps):
                dmax = 0.0
                for g, xg in enumerate(self.Xg):
                    old = beta[g]
                    u = old + xg.T @ r / (n * self.L[g])
                    nu = np.linalg.norm(u); thr = lam * self.pg[g] / self.L[g]
                    new = (1 - thr / nu) * u if nu > thr else np.zeros_like(u)
                    dlt = new - old
                    if np.any(dlt != 0):
                        r -= xg @ dlt; beta[g] = new
                        dmax = max(dmax, float(np.max(np.abs(dlt))))
                if dmax < tol:
                    break
            out.append([b.copy() for b in beta])
        return out

    def predict(self, Xnew, beta):
        Xc = Xnew - self.xm
        f = np.full(Xnew.shape[0], self.mu)
        for idx, b in zip(self.groups, beta):
            if np.any(b != 0):
                f += Xc[:, idx] @ b
        return f
