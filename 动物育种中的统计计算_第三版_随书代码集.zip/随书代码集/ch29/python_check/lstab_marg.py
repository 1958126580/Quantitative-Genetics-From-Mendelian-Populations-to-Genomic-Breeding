# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 lstab_marg.py    依赖：numpy, scipy
"""Check eq. (29.26a): P(causal marker has the largest |marginal r| in its block) ~ Phi(delta/tau)^(K-1),
delta/tau = rho_c * sqrt(n (1-r)/(1+r)), r = r(causal, proxy).  Same generating model as lassostab.py.
(a) the 20 datasets used in Table (seeds [29207, 1000*eps, rep]) ; (b) 2000 fresh datasets (seeds [29208, 1000*eps, rep])."""
import numpy as np, json
from scipy.stats import norm
from common import sim_geno
n = 500; q2 = 0.05; pc = 0.3; K = 10


def sim(rng, eps, full=True):
    if full:
        Xn, _ = sim_geno(n, 19, 10, 0.9, rng)
    G = np.zeros((n, K))
    for _ in range(2):
        hc = (rng.random(n) < pc).astype(float)
        H = np.empty((n, K)); H[:, 0] = hc
        for k in range(1, K):
            keep = rng.random(n) < 1 - eps
            fresh = (rng.random(n) < pc).astype(float)
            H[:, k] = np.where(keep, hc, fresh)
        G += H
    z = (G[:, 0] - G[:, 0].mean()) / G[:, 0].std()
    y = np.sqrt(q2) * z + rng.standard_normal(n) * np.sqrt(1 - q2)
    return G, y


out = {}
for eps in [0.3, 0.15, 0.05, 0.02]:
    top20 = []
    for rep in range(20):
        rng = np.random.default_rng([29207, int(round(eps * 1000)), rep])
        G, y = sim(rng, eps)
        r = np.array([np.corrcoef(G[:, k], y)[0, 1] for k in range(K)])
        top20.append(int(np.argmax(np.abs(r)) == 0))
    top = []; rcp = []
    for rep in range(2000):
        rng = np.random.default_rng([29208, int(round(eps * 1000)), rep])
        G, y = sim(rng, eps, full=False)
        r = np.array([np.corrcoef(G[:, k], y)[0, 1] for k in range(K)])
        top.append(int(np.argmax(np.abs(r)) == 0))
        C = np.corrcoef(G.T); rcp.append(np.mean(C[0, 1:]))
    rr = float(np.mean(rcp))
    dt = np.sqrt(q2) * np.sqrt(n * (1 - rr) / (1 + rr))
    pred = float(norm.cdf(dt) ** (K - 1))
    out[eps] = dict(top20=int(sum(top20)), top2000=float(np.mean(top)), se=float(np.sqrt(np.mean(top) * (1 - np.mean(top)) / 2000)),
                    r_cp=rr, dt=float(dt), pred=pred)
    print(eps, out[eps], flush=True)
print('limit 2^-(K-1) =', 2.0 ** -(K - 1))
json.dump(out, open('lstab_marg.json', 'w'), indent=1)
