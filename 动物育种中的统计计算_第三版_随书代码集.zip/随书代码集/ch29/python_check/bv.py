# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 bv.py    依赖：numpy
"""§29.1.5/§29.1.6: bias-variance decomposition of ridge, analytic vs Monte Carlo;
in-sample optimism 2*sigma2*df/n."""
import numpy as np, json
from common import sim_geno, adj_r2

SEED = 2901
rng = np.random.default_rng(SEED)
n, n0 = 200, 2000
nb, bs, phi = 50, 10, 0.9
X_all, p = sim_geno(n + n0, nb, bs, phi, rng)
m = X_all.shape[1]
Z_all = X_all - 2 * p              # centred by population frequency, no intercept
Z, Z0 = Z_all[:n], Z_all[n:]
beta = rng.standard_normal(m)
g0 = Z0 @ beta
sc = np.sqrt(np.var(g0))
beta /= sc
f0 = Z0 @ beta                      # f*(x0) at test points
f_tr = Z @ beta
sigma2 = 1.0
h2 = 0.5
s2pq = float(np.sum(2 * p * (1 - p)))
lam_ref = s2pq * (1 - h2) / h2      # eq. (20.9)
print('m', m, 'adj r2', round(adj_r2(X_all, bs), 4), 'sum2pq', round(s2pq, 3),
      'lam_ref', round(lam_ref, 3), 'var f0', np.var(f0), 'var f_tr', np.var(f_tr))

U, d, Vt = np.linalg.svd(Z, full_matrices=False)   # Z = U diag(d) Vt, rank n
V = Vt.T
# null-space part of beta
beta_par = V @ (Vt @ beta)
beta_perp = beta - beta_par
floor = float(np.mean((Z0 @ beta_perp) ** 2))
print('null-space bias^2 floor', floor, 'share of var f0', floor / np.var(f0))

R = 4000
E = rng.standard_normal((n, R)) * np.sqrt(sigma2)    # training noise
Y = f_tr[:, None] + E
UtY = U.T @ Y
Z0V = Z0 @ V
E0 = rng.standard_normal((n0, R)) * np.sqrt(sigma2)  # test noise
Y0 = f0[:, None] + E0
Enew = rng.standard_normal((n, R)) * np.sqrt(sigma2) # new noise at training x (in-sample)
Ynew = f_tr[:, None] + Enew
UtF = U.T @ f_tr

mults = [0.0, 0.01, 0.1, 0.3, 1.0, 3.0, 10.0, 100.0]
rows = []
for mu in mults:
    lam = mu * lam_ref
    if lam == 0:
        sh = 1.0 / d                    # min-norm least squares (ridgeless)
        sfit = np.ones_like(d)
    else:
        sh = d / (d ** 2 + lam)
        sfit = d ** 2 / (d ** 2 + lam)
    # analytic
    Ebhat = V @ (sh * UtF)             # E beta_hat = A Z beta
    bias = Z0 @ Ebhat - f0
    bias2_a = float(np.mean(bias ** 2))
    var_a = float(sigma2 * np.mean(np.sum((Z0V * sh) ** 2, axis=1)))
    epe_a = sigma2 + bias2_a + var_a
    df = float(np.sum(sfit))
    # MC
    F = Z0V @ (sh[:, None] * UtY)      # n0 x R predictions
    fbar = F.mean(1)
    bias2_mc = float(np.mean((fbar - f0) ** 2))
    var_mc = float(np.mean(F.var(1)))
    epe_mc = float(np.mean((Y0 - F) ** 2))
    # in-sample optimism
    Fit = U @ (sfit[:, None] * UtY)    # fitted values at training x
    err_tr = np.mean((Y - Fit) ** 2, axis=0)
    err_in = np.mean((Ynew - Fit) ** 2, axis=0)
    opt_mc = float(np.mean(err_in - err_tr))
    opt_se = float(np.std(err_in - err_tr, ddof=1) / np.sqrt(R))
    opt_th = 2 * sigma2 * df / n
    # accuracy r(fhat, f*) averaged over reps
    Fc = F - F.mean(0)
    f0c = f0 - f0.mean()
    racc = float(np.mean((Fc * f0c[:, None]).sum(0) / np.sqrt((Fc ** 2).sum(0) * (f0c ** 2).sum())))
    rows.append(dict(mult=mu, lam=lam, df=df, bias2_a=bias2_a, var_a=var_a, epe_a=epe_a,
                     bias2_mc=bias2_mc, var_mc=var_mc, epe_mc=epe_mc,
                     err_tr=float(err_tr.mean()), err_in=float(err_in.mean()),
                     opt_mc=opt_mc, opt_se=opt_se, opt_th=opt_th, racc=racc))
    print(f"mult {mu:7.2f} lam {lam:9.3f} df {df:7.2f} | bias2 {bias2_a:.4f}/{bias2_mc:.4f} "
          f"var {var_a:.4f}/{var_mc:.4f} EPE {epe_a:.4f}/{epe_mc:.4f} | r {racc:.4f} | "
          f"tr {err_tr.mean():.4f} in {err_in.mean():.4f} opt {opt_mc:.4f}({opt_se:.4f}) th {opt_th:.4f}")
# lambda -> infinity
rows.append(dict(mult='inf', bias2_a=float(np.mean(f0 ** 2)), var_a=0.0,
                 epe_a=sigma2 + float(np.mean(f0 ** 2))))
print('inf: bias2', np.mean(f0 ** 2), 'EPE', sigma2 + np.mean(f0 ** 2))
# fine search of optimum lambda (analytic)
grid = np.exp(np.linspace(np.log(0.01), np.log(100), 2001)) * lam_ref
best = None
for lam in grid:
    sh = d / (d ** 2 + lam)
    bias = Z0 @ (V @ (sh * UtF)) - f0
    epe = sigma2 + np.mean(bias ** 2) + sigma2 * np.mean(np.sum((Z0V * sh) ** 2, axis=1))
    if best is None or epe < best[1]:
        best = (lam, epe)
print('analytic optimum lam', best[0], 'mult', best[0] / lam_ref, 'EPE', best[1])
json.dump(dict(seed=SEED, n=n, n0=n0, m=m, R=R, s2pq=s2pq, lam_ref=lam_ref, floor=floor,
               adj_r2=adj_r2(X_all, bs), rows=rows, opt_lam=best[0], opt_mult=best[0] / lam_ref,
               opt_epe=best[1]), open('bv.json', 'w'), indent=1)
