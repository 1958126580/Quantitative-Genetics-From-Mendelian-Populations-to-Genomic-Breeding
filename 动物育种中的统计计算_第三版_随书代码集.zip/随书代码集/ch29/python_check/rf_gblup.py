# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 rf_gblup.py    依赖：numpy
# GBLUP reference on exactly the datasets of rf.py (same seeds/draw order)
import numpy as np, json
from common import sim_geno, reml_eig, gblup_eig
n, n0 = 300, 200
rng0 = np.random.default_rng(2946)
X0, p = sim_geno(n0, 20, 10, 0.9, rng0)
m = X0.shape[1]
qtl = rng0.choice(m, 20, replace=False); a = rng0.standard_normal(20)
Xref, _ = sim_geno(5000, 20, 10, 0.9, rng0, p=p)
sg = np.std((Xref[:, qtl] - 2 * p[qtl]) @ a); a = a / sg * np.sqrt(0.5)
g0 = (X0[:, qtl] - 2 * p[qtl]) @ a
acc = []; mse = []; P = []
for rep in range(100):
    rng = np.random.default_rng([2946, rep])
    X, _ = sim_geno(n, 20, 10, 0.9, rng, p=p)
    y = (X[:, qtl] - 2 * p[qtl]) @ a + rng.standard_normal(n) * np.sqrt(0.5)
    pf = X.mean(0) / 2; Z = X - 2 * pf; Z0 = X0 - 2 * pf; s = np.sum(2 * pf * (1 - pf))
    G = Z @ Z.T / s; d, U = np.linalg.eigh(G); d = np.clip(d, 0, None)
    h2, _, _ = reml_eig(y, d, U)
    al, mu = gblup_eig(y, d, U, (1 - h2) / h2)
    pr = Z0 @ Z.T / s @ al + mu
    P.append(pr); acc.append(np.corrcoef(pr, g0)[0, 1])
P = np.array(P)
out = dict(acc=float(np.mean(acc)), acc_se=float(np.std(acc, ddof=1) / 10), bias2=float(np.mean((P.mean(0) - g0) ** 2)),
           var=float(P.var(0, ddof=1).mean()), mse=float(np.mean((P - g0) ** 2)))
print(out); json.dump(out, open('rf_gblup.json', 'w'))
