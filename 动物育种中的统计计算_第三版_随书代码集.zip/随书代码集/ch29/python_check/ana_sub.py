# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ana_sub.py    依赖：numpy
import json, sys, numpy as np
for n in sys.argv[1:]:
    d = json.load(open(f'ncvsub_{n}.json')); res = d['res']; R = len(res)
    print('n', n, 'R', R, 'mean candidate true r (full n)', np.mean([r['mean_true_n'] for r in res]).round(4), 'sd across candidates', np.mean([r['sd_true_n'] for r in res]).round(4))
    se = lambda x: x.std(ddof=1) / np.sqrt(len(x))
    for K in ['1', '5', '20', '100']:
        A = {k: np.array([r[K][k] for r in res]) for k in ['single', 'single_true08', 'true_n', 'nested', 'true_08', 'best_true']}
        o = A['single'] - A['single_true08']; b = A['nested'] - A['true_08']
        print(f"  K={K:>3} single {A['single'].mean():.4f} true08 {A['single_true08'].mean():.4f} opt {o.mean():+.4f}({se(o):.4f}) | nested {A['nested'].mean():.4f} true08 {A['true_08'].mean():.4f} bias {b.mean():+.4f}({se(b):.4f}) | selected-refit true_n {A['true_n'].mean():.4f} best_true {A['best_true'].mean():.4f} single-true_n {(A['single']-A['true_n']).mean():+.4f}")
