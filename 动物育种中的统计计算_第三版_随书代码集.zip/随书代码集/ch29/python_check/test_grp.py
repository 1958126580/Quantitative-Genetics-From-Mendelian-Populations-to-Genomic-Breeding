# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 test_grp.py    依赖：numpy, sklearn
import numpy as np, time
from sklearn.linear_model import Lasso
from grplasso import GroupLasso
from common import sim_geno
rng = np.random.default_rng(1)
X, p = sim_geno(300, 30, 10, 0.95, rng)
y = X[:, [3, 55, 120]] @ np.array([1., -1., 0.5]) + rng.standard_normal(300)
# singleton groups vs sklearn Lasso on standardized X
gl = GroupLasso([np.array([j]) for j in range(X.shape[1])]).setup(X)
lmax = gl.lam_max(y); lams = lmax * np.logspace(0, -2, 20)
t = time.time(); th = gl.path(y, lams, tol=1e-10); print('time', time.time() - t)
Xs = (X - X.mean(0)) / X.std(0)
for k in [5, 12, 19]:
    m = Lasso(alpha=lams[k], tol=1e-12, max_iter=100000).fit(Xs, y)
    print(k, np.max(np.abs(m.coef_ - th[k])), np.sum(th[k] != 0), np.sum(m.coef_ != 0))
# blocks of 10: KKT check
gl = GroupLasso([np.arange(b * 10, b * 10 + 10) for b in range(30)]).setup(X)
lmax = gl.lam_max(y); lams = lmax * np.logspace(0, -2, 20)
t = time.time(); th = gl.path(y, lams, tol=1e-10); print('time', time.time() - t)
k = 15; theta = th[k]; lam = lams[k]
r = y - gl.mu - gl.Xall @ theta
c = gl.Xall.T @ r / gl.n
for g, sl in enumerate(gl.slices):
    if np.any(theta[sl] != 0):
        # gradient condition: c_g = lam*pg*theta_g/||theta_g||
        err = np.max(np.abs(c[sl] - lam * gl.pg[g] * theta[sl] / np.linalg.norm(theta[sl])))
        print('active', g, err)
    else:
        assert np.linalg.norm(c[sl]) <= lam * gl.pg[g] * (1 + 1e-6)
print('ngroups', gl.n_groups(theta))
pred = gl.predict(X, theta); print('pred check', np.max(np.abs(pred - (gl.mu + gl.Xall @ theta))))
