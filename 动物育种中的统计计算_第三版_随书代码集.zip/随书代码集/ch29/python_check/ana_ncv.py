# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ana_ncv.py    依赖：numpy
import json, sys, numpy as np
for n in sys.argv[1:]:
    d = json.load(open(f'ncv_{n}.json'))
    R = len(d['res'])
    print('n', n, 'R', R)
    for K in ['1', '5', '20', '100']:
        A = {k: np.array([r[K][k] for r in d['res']]) for k in ['single', 'true_n', 'single_true08', 'nested', 'true_08', 'best_true', 'lam_sel']}
        sel_opt = A['single'] - A['single_true08']
        rep_gap = A['single'] - A['true_n']
        nest_b = A['nested'] - A['true_08']
        nest_gap = A['nested'] - A['true_n']
        se = lambda x: x.std(ddof=1) / np.sqrt(len(x))
        print(f" K={K:>3}: single {A['single'].mean():.4f} true_n {A['true_n'].mean():.4f} true08(single) {A['single_true08'].mean():.4f} nested {A['nested'].mean():.4f} true08(nested) {A['true_08'].mean():.4f} | "
              f"selopt {sel_opt.mean():+.4f}({se(sel_opt):.4f}) single-true_n {rep_gap.mean():+.4f}({se(rep_gap):.4f}) nested-true08 {nest_b.mean():+.4f}({se(nest_b):.4f}) nested-true_n {nest_gap.mean():+.4f}({se(nest_gap):.4f}) best_true {A['best_true'].mean():.4f}")
