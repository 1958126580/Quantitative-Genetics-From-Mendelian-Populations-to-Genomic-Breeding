# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 krr.py    依赖：numpy, sklearn
"""§29.3.6: kernel ridge regression == GBLUP == SNP-BLUP, four implementations; plus common scale pitfalls.
Seed 2936."""
import numpy as np, json
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import Ridge
from common import sim_geno, reml_eig, cor, slope

rng = np.random.default_rng(2936)
n, nt = 1000, 500
nb, bs, phi = 200, 10, 0.9
X, p = sim_geno(n + nt, nb, bs, phi, rng)
m = X.shape[1]
qtl = rng.choice(m, 200, replace=False); a = rng.standard_normal(200)
g = (X[:, qtl] - 2 * p[qtl]) @ a
h2 = 0.3
g = g / np.std(g) * np.sqrt(h2)
y = 10.0 + g + rng.standard_normal(n + nt) * np.sqrt(1 - h2)   # nonzero mean on purpose
Xtr, Xte, ytr, gte = X[:n], X[n:], y[:n], g[n:]
pf = Xtr.mean(0) / 2
Z = Xtr - 2 * pf; Zt = Xte - 2 * pf
s = float(np.sum(2 * pf * (1 - pf)))
G = Z @ Z.T / s; Gt = Zt @ Z.T / s
d, U = np.linalg.eigh(G); d = np.clip(d, 0, None)
h2hat, s2, b = reml_eig(ytr, d, U)
lamG = (1 - h2hat) / h2hat
lamS = lamG * s
print('h2hat', h2hat, 'lamG', lamG, 'lamSNP', lamS, 's', s)

# (1) SNP-BLUP via Henderson MME (m+1 equations)
C = np.zeros((m + 1, m + 1)); C[0, 0] = n; C[0, 1:] = Z.sum(0); C[1:, 0] = Z.sum(0)
C[1:, 1:] = Z.T @ Z + lamS * np.eye(m)
rhs = np.concatenate([[ytr.sum()], Z.T @ ytr])
sol = np.linalg.solve(C, rhs); mu1, alpha1 = sol[0], sol[1:]
p1_tr = mu1 + Z @ alpha1; p1_te = mu1 + Zt @ alpha1
# (2) GBLUP, V-form with GLS intercept
Vinv = np.linalg.inv(G + lamG * np.eye(n))
one = np.ones(n)
mu2 = (one @ Vinv @ ytr) / (one @ Vinv @ one)
c2 = Vinv @ (ytr - mu2)
p2_tr = mu2 + G @ c2; p2_te = mu2 + Gt @ c2
# (3) sklearn KernelRidge, precomputed G, alpha = lamG, on y - mean
kr = KernelRidge(alpha=lamG, kernel='precomputed').fit(G, ytr - ytr.mean())
p3_tr = ytr.mean() + kr.predict(G); p3_te = ytr.mean() + kr.predict(Gt)
# (4) sklearn Ridge, alpha = lamSNP, centred genotypes, intercept fitted
rd = Ridge(alpha=lamS, fit_intercept=True, solver='svd').fit(Z, ytr)
p4_tr = rd.predict(Z); p4_te = rd.predict(Zt)
P = {'MME': (p1_tr, p1_te), 'V': (p2_tr, p2_te), 'KRR': (p3_tr, p3_te), 'Ridge': (p4_tr, p4_te)}
names = list(P)
maxdiff = {}
for i in range(4):
    for j in range(i + 1, 4):
        a_, b_ = P[names[i]], P[names[j]]
        md = max(np.max(np.abs(a_[0] - b_[0])), np.max(np.abs(a_[1] - b_[1])))
        maxdiff[f'{names[i]}-{names[j]}'] = float(md)
        print(names[i], names[j], md)
print('mu1 mu2 ybar', mu1, mu2, ytr.mean())
print('GBLUP acc', cor(p2_te, gte), 'b1', slope(gte, p2_te), 'sd pred', np.std(p2_te))

# pitfalls
ref = p2_te
pit = []
def add(name, pred):
    md = float(np.max(np.abs(pred - ref)))
    rr = dict(name=name, maxdiff=md, cor_ref=cor(pred, ref), acc=cor(pred, gte), b1=slope(gte, pred),
              sd_ratio=float(np.std(pred) / np.std(ref)))
    pit.append(rr); print(rr)
add('GBLUP (reference)', ref)
# (a) KernelRidge with marker-scale lambda (lamS on G-scale kernel)
kra = KernelRidge(alpha=lamS, kernel='precomputed').fit(G, ytr - ytr.mean())
add('KRR alpha=lamSNP on G', ytr.mean() + kra.predict(Gt))
# (b) Ridge on centred markers with G-scale lambda
rdb = Ridge(alpha=lamG, fit_intercept=True, solver='svd').fit(Z, ytr)
add('Ridge alpha=lamG on Z', rdb.predict(Zt))
# (c) Ridge on standardized markers with lamSNP (should be m*lamG)
sd = Z.std(0); sd[sd == 0] = 1
rdc = Ridge(alpha=lamS, fit_intercept=True, solver='svd').fit(Z / sd, ytr)
add('Ridge std markers alpha=lamSNP', rdc.predict(Zt / sd))
rdc2 = Ridge(alpha=m * lamG, fit_intercept=True, solver='svd').fit(Z / sd, ytr)
add('Ridge std markers alpha=m*lamG (VanRaden-2)', rdc2.predict(Zt / sd))
# (d) KernelRidge without removing the mean (no intercept)
krd = KernelRidge(alpha=lamG, kernel='precomputed').fit(G, ytr)
add('KRR on raw y (no intercept)', krd.predict(Gt))
# (d2) G centred by base-population frequencies p (not training), KRR without intercept
Zp = Xtr - 2 * p; Ztp = Xte - 2 * p; sp = float(np.sum(2 * p * (1 - p)))
Gp = Zp @ Zp.T / sp; Gtp = Ztp @ Zp.T / sp
krd2 = KernelRidge(alpha=lamG, kernel='precomputed').fit(Gp, ytr)
add('KRR on raw y, G centred by base freq (no intercept)', krd2.predict(Gtp))
# (e) Ridge on raw 0/1/2 genotypes without intercept
rde = Ridge(alpha=lamS, fit_intercept=False, solver='svd').fit(Xtr, ytr)
add('Ridge raw 012, no intercept', rde.predict(Xte))
# (f) ElasticNet-style scaling: sklearn ElasticNet(l1_ratio=0) objective has 1/(2n): alpha=lamS -> lambda = n*lamS
rdf = Ridge(alpha=n * lamS, fit_intercept=True, solver='svd').fit(Z, ytr)
add('Ridge alpha=n*lamSNP (1/(2n) convention mixed up)', rdf.predict(Zt))
json.dump(dict(seed=2936, n=n, nt=nt, m=m, h2=h2, h2hat=h2hat, lamG=lamG, lamS=lamS, s2pq=s, maxdiff=maxdiff,
               mu=[float(mu1), float(mu2), float(ytr.mean())], pitfalls=pit), open('krr.json', 'w'), indent=1)
