# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ana_pen.py    依赖：numpy
import json, glob, numpy as np
meths = ['ridge', 'lasso', 'lasso1se', 'enet', 'glasso']
for scen in ['sparse', 'block', 'dense']:
    res = []
    for f in sorted(glob.glob(f'pen_{scen}_*.json')):
        res += json.load(open(f))['res']
    if not res: continue
    R = len(res); print(scen, 'R', R)
    base = np.array([r['ridge']['r'] for r in res])
    for mth in meths:
        r_ = np.array([x[mth]['r'] for x in res]); b1 = np.array([x[mth]['b1'] for x in res])
        nnz = np.array([x[mth]['nnz'] for x in res]); nblk = np.array([x[mth]['nblk'] for x in res])
        d = r_ - base
        hit = [x[mth].get('hit') for x in res]
        extra = ''
        if mth == 'enet': extra = ' l1_ratio ' + str([x[mth]['l1_ratio'] for x in res])
        if mth in ('lasso', 'lasso1se', 'enet', 'glasso'):
            extra += ' edge ' + str(sum(bool(x[mth].get('at_edge')) for x in res))
        print(f"  {mth:9s} r {r_.mean():.4f} (sd {r_.std(ddof=1):.4f}) d_vs_ridge {d.mean():+.4f} (se {d.std(ddof=1)/np.sqrt(R):.4f}) b1 {np.median(b1):.3f} nnz {nnz.mean():.1f} nblk {nblk.mean():.1f} "
              f"hit {np.mean(hit) if hit[0] is not None else '-'}{extra}")
