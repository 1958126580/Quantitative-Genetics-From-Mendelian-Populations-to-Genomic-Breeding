# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 gauss_chk.py    依赖：numpy
import numpy as np, json
from common import sim_geno
out = {}
npairs = []
for rep in range(10):
    rng = np.random.default_rng([2937, rep])
    X, p = sim_geno(1500, 200, 10, 0.9, rng)
    m = X.shape[1]
    qa = rng.choice(m, 200, replace=False); a = rng.standard_normal(200)
    pairs = rng.choice(m, (100, 2), replace=True)
    pairs = pairs[pairs[:, 0] != pairs[:, 1]]
    npairs.append(len(pairs))
    if rep == 0:
        n = 1000
        pf = X[:n].mean(0) / 2; Z = X[:n] - 2 * pf; s = np.sum(2 * pf * (1 - pf))
        G = Z @ Z.T / s
        iu = np.triu_indices(n, 1)
        Me = 1 / np.var(G[iu]); GG = G * G
        MeAA = 1 / np.var(GG[iu])
        out = dict(Me=float(Me), MeAA=float(MeAA), meanGGdiag=float(np.mean(np.diag(GG))), meanGGoff=float(np.mean(GG[iu])))
print('pairs per rep', npairs)
print(out)
# Daetwyler-type expectation for the AxA part: r2 = N h2 / (N h2 + Me)
for nm, Me_, h2 in [('A', out['Me'], 0.15), ('AA', out['MeAA'], 0.15)]:
    r2 = 1000 * h2 / (1000 * h2 + Me_)
    print(nm, 'Me', round(Me_, 1), 'r2', r2, 'r', np.sqrt(r2))
json.dump(dict(npairs=npairs, **out), open('gauss_chk.json', 'w'))
