# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 df2.py    依赖：numpy
"""§29.1.6 addendum: mean reliability of training GEBVs vs df: Rbar = 1 - lam*df/tr(G) (ratio of sums),
checked against direct computation; same data/seed as df.py (seed 2902)."""
import numpy as np, json
from common import sim_geno
SEED = 2902
rng = np.random.default_rng(SEED)
X_all, p = sim_geno(4000, 200, 10, 0.9, rng)
n = 1000
X = X_all[:n]; pf = X.mean(0) / 2; Z = X - 2 * pf; s = np.sum(2 * pf * (1 - pf))
G = Z @ Z.T / s
mu, Q = np.linalg.eigh(G); mu = np.clip(mu, 0, None)
out = []
for h2 in [0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9]:
    lam = (1 - h2) / h2
    df = np.sum(mu / (mu + lam))
    Rbar_id = 1 - lam * df / np.trace(G)
    VarG = (Q * (mu ** 2 / (mu + lam))) @ Q.T       # G (G+lam I)^-1 G
    Rbar_dir = np.trace(VarG) / np.trace(G)
    rel_i = np.diag(VarG) / np.diag(G)
    out.append(dict(h2=h2, df=float(df), Rbar_identity=float(Rbar_id), Rbar_direct=float(Rbar_dir),
                    mean_rel_i=float(rel_i.mean())))
    print(f'h2 {h2:.2f} df {df:.1f} Rbar(identity) {Rbar_id:.4f} Rbar(direct) {Rbar_dir:.4f} mean_i rel {rel_i.mean():.4f}')
json.dump(out, open('df2.json', 'w'), indent=1)
