# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 29 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 df.py    依赖：numpy
"""§29.1.6: effective degrees of freedom tr(H) of GBLUP vs h2 / lambda, for several n."""
import numpy as np, json
from common import sim_geno, adj_r2

SEED = 2902
rng = np.random.default_rng(SEED)
nb, bs, phi = 200, 10, 0.9
nmax = 4000
X_all, p = sim_geno(nmax, nb, bs, phi, rng)
m = X_all.shape[1]
print('m', m, 'adj r2', round(adj_r2(X_all[:2000], bs), 4))
h2s = [0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9]
out = {}
for n in [500, 1000, 2000, 4000]:
    X = X_all[:n]
    pf = X.mean(0) / 2
    Z = X - 2 * pf
    s = float(np.sum(2 * pf * (1 - pf)))
    G = Z @ Z.T / s
    mu = np.linalg.eigvalsh(G)
    mu = np.clip(mu, 0, None)
    off = G[np.triu_indices(n, 1)]
    Me = 1.0 / np.var(off)
    rank = int(np.sum(mu > 1e-8))
    res = []
    for h2 in h2s:
        lg = (1 - h2) / h2
        df = float(np.sum(mu / (mu + lg)))
        res.append(dict(h2=h2, lam_G=lg, lam_snp=s * lg, lam_std=m * lg, df=df, df_n=df / n))
    out[n] = dict(s2pq=s, Me=Me, rank=rank, trG=float(np.trace(G)), res=res,
                  mu_top=[float(x) for x in mu[::-1][:5]])
    print(f'n {n} sum2pq {s:.2f} rank {rank} trG {np.trace(G):.2f} Me(1/var offdiag) {Me:.1f} top eig {mu[::-1][:3]}')
    for r in res:
        print(f"   h2 {r['h2']:.2f} lamG {r['lam_G']:.4f} lamSNP {r['lam_snp']:.1f} lamStd {r['lam_std']:.1f} df {r['df']:.1f} df/n {r['df_n']:.4f}")
json.dump(dict(seed=SEED, m=m, out=out), open('df.json', 'w'), indent=1)
