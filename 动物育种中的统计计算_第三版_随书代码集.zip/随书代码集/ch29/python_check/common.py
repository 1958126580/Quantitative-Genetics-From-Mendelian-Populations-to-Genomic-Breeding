# -*- coding: utf-8 -*-
"""Shared helpers for ch29 expansion simulations."""
import numpy as np
from scipy.stats import norm
from scipy.optimize import minimize_scalar


def sim_geno(n, n_blocks, bsize, phi, rng, p=None, maf=(0.05, 0.5)):
    """Genotypes 0/1/2 with LD inside blocks (latent Gaussian AR(1) per haplotype,
    thresholded so that P(allele=1)=p_j); blocks independent.
    Returns X (n x m) and allele frequencies p."""
    m = n_blocks * bsize
    if p is None:
        p = rng.uniform(maf[0], maf[1], m)
    thr = norm.ppf(p).reshape(n_blocks, bsize)
    X = np.zeros((n, n_blocks, bsize))
    s = np.sqrt(1 - phi ** 2)
    for _ in range(2):
        e = rng.standard_normal((n, n_blocks, bsize))
        U = np.empty_like(e)
        U[:, :, 0] = e[:, :, 0]
        for k in range(1, bsize):
            U[:, :, k] = phi * U[:, :, k - 1] + s * e[:, :, k]
        X += (U < thr[None, :, :])
    return X.reshape(n, m), p


def adj_r2(X, bsize):
    """mean r^2 between adjacent markers within blocks"""
    n, m = X.shape
    r2 = []
    for j in range(m - 1):
        if (j + 1) % bsize == 0:
            continue
        a, b = X[:, j], X[:, j + 1]
        if a.std() == 0 or b.std() == 0:
            continue
        r2.append(np.corrcoef(a, b)[0, 1] ** 2)
    return float(np.mean(r2))


def cor(a, b):
    return float(np.corrcoef(a, b)[0, 1])


def slope(g, ghat):
    c = np.cov(g, ghat)
    return float(c[0, 1] / c[1, 1])


def reml_eig(y, d, U, X=None):
    """REML for y = Xb + g + e, Var = s2*(h2*K + (1-h2)I), K = U diag(d) U'.
    X defaults to intercept. Returns h2 (kernel scale), s2, b."""
    n = len(y)
    if X is None:
        X = np.ones((n, 1))
    ys = U.T @ y
    Xs = U.T @ X
    q = X.shape[1]

    def parts(h2):
        w = h2 * d + (1 - h2)
        XtWX = (Xs / w[:, None]).T @ Xs
        XtWy = (Xs / w[:, None]).T @ ys
        b = np.linalg.solve(XtWX, XtWy)
        r = ys - Xs @ b
        rwr = np.sum(r * r / w)
        return w, XtWX, b, rwr

    def negll(h2):
        w, XtWX, b, rwr = parts(h2)
        s2 = rwr / (n - q)
        ll = -0.5 * ((n - q) * np.log(s2) + np.sum(np.log(w)) + np.linalg.slogdet(XtWX)[1])
        return -ll

    res = minimize_scalar(negll, bounds=(1e-5, 1 - 1e-5), method='bounded',
                          options={'xatol': 1e-8})
    h2 = res.x
    w, XtWX, b, rwr = parts(h2)
    return h2, rwr / (n - q), b


def gblup_eig(y, d, U, lam):
    """GBLUP (kernel ridge with GLS intercept) for kernel K = U diag(d) U'.
    Returns (alpha, mu) with prediction for new rows: K_new,train @ alpha + mu."""
    n = len(y)
    ys = U.T @ y
    xs = U.T @ np.ones(n)
    w = d + lam
    mu = np.sum(xs * ys / w) / np.sum(xs * xs / w)
    alpha = U @ ((ys - xs * mu) / w)
    return alpha, mu
