# 本脚本由 tools/nb2jl.py 从同目录的 ch29.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 29

# %% [markdown]
# # 第二十九章　统计机器学习基础 —— 配套代码
#
# 本 Notebook 对应第二十九章。
#
# **内容**
#
# 1. 偏差—方差分解的数值验证（正文式 29.4–29.7）
# 2. 有效自由度（正文式 29.11）与正则化路径
# 3. **岭回归 ≡ GBLUP** 的数值验证（定理 29.1）
# 4. **LASSO 的坐标下降从零实现**（正文式 29.20、算法 29.2）
# 5. 弹性网络与分组效应（正文式 29.21–29.23）
# 6. **核岭回归 ≡ GBLUP**（定理 29.2）与高斯核的 $h\to0$ 极限（正文式 29.33）
# 7. 回归树、随机森林、梯度提升的从零实现
# 8. 随机森林方差公式的验证（正文式 29.43）
# 9. **嵌套交叉验证**（算法 29.1）与"单层 CV"乐观程度的量化
# 10. 六种方法在同一基因组数据上的公平比较
# 11. **MLJ.jl 统一接口**：DecisionTree.jl 随机森林与 EvoTrees.jl 梯度提升（可选）

# %%
using LinearAlgebra, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %%
"""模拟基因组数据。`arch` 指定遗传结构。

- :additive     纯加性（第三十一章 §31.1.2 限制一的检验场景）
- :epistatic    加性 + 位点对交互
- :oligogenic   少数大效应位点
"""
function sim_geno(n::Int, m::Int, h2::Float64; arch::Symbol=:additive,
                  eps2::Float64=0.0, rng=Random.default_rng())
    p = 0.05 .+ 0.45 .* rand(rng, m)
    Mg = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        Mg[i,j] = Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j])
    end
    Z = Mg .- 2 .* p'
    sum2pq = 2*sum(p .* (1 .- p))
    alpha = randn(rng, m)
    glin = Z*alpha; glin .*= 1/std(glin)
    gnl = zeros(n)
    if arch === :epistatic && eps2 > 0
        npair = 60
        j1 = rand(rng, 1:m, npair); j2 = rand(rng, 1:m, npair)
        w  = randn(rng, npair)
        for k in 1:npair
            gnl .+= w[k] .* (view(Z,:,j1[k]) .* view(Z,:,j2[k]))
        end
        gnl .*= 1/std(gnl)
    elseif arch === :oligogenic
        idx = randperm(rng, m)[1:max(5, m ÷ 200)]
        alpha .= 0.0; alpha[idx] .= randn(rng, length(idx))
        glin = Z*alpha; glin .*= 1/std(glin)
    end
    # 标度：线性部分解释 h2 - eps2，非线性解释 eps2（均为表型方差比例）
    sd_lin = sqrt(max(h2 - eps2, 0.0)); sd_nl = sqrt(eps2)
    g = sd_lin .* glin .+ sd_nl .* gnl
    y = 10.0 .+ g .+ randn(rng, n).*sqrt(1 - h2)
    return (y=y, Z=Z, Mg=Mg, p=p, g=g, glin=sd_lin .* glin, gnl=sd_nl .* gnl,
            alpha=alpha, sum2pq=sum2pq, h2=h2, eps2=eps2)
end

"""标准化基因型列（均值 0、方差 1），返回 (Zs, 均值, 标准差)。"""
function standardize(Z::AbstractMatrix)
    mu = vec(mean(Z; dims=1)); sd = vec(std(Z; dims=1))
    sd[sd .< 1e-12] .= 1.0
    return (Z .- mu') ./ sd', mu, sd
end
apply_standardize(Z, mu, sd) = (Z .- mu') ./ sd'

"""GBLUP / 岭回归（在标记效应尺度上求解，返回预测函数）。"""
function ridge_fit(X::Matrix{Float64}, y::Vector{Float64}, lambda::Float64)
    n, p = size(X)
    yc = y .- mean(y); ybar = mean(y)
    if p <= n
        b = (X'X + lambda*I) \ (X'yc)
    else                                  # Woodbury：O(n²p) 而非 O(p³)
        K = X*X'
        a = (K + lambda*I) \ yc
        b = X'a
    end
    return b, ybar
end
ridge_predict(X, b, ybar) = X*b .+ ybar

# %% [markdown]
# ## 1　偏差—方差分解的数值验证（正文式 29.4–29.7）

# %%
"""在固定的测试点上重复抽训练集，分解 EPE 为噪声 + 偏差² + 方差。"""
function bias_variance_demo(; n=120, p=20, sigma=1.0, nrep=600, lambdas=(0.0, 1.0, 10.0, 100.0))
    rngX = Xoshiro(2901)
    Xte = randn(rngX, 200, p)
    beta = randn(rngX, p) ./ sqrt(p)
    fte = Xte*beta
    rows = NamedTuple[]
    for lam in lambdas
        preds = zeros(nrep, 200)
        for r in 1:nrep
            rg = Xoshiro(3000 + r)
            Xtr = randn(rg, n, p)
            ytr = Xtr*beta .+ sigma.*randn(rg, n)
            b = (Xtr'Xtr + (lam == 0 ? 1e-10 : lam)*I) \ (Xtr'ytr)
            preds[r, :] .= Xte*b
        end
        fbar = vec(mean(preds; dims=1))
        bias2 = mean((fbar .- fte).^2)
        varv  = mean(vec(var(preds; dims=1)))
        push!(rows, (lambda=lam, noise=sigma^2, bias2=bias2, var=varv,
                     epe=sigma^2 + bias2 + varv))
    end
    return rows
end

@printf("%-12s%-14s%-14s%-14s%-14s\n", "λ", "噪声 σ²", "偏差²", "方差", "EPE")
for r in bias_variance_demo()
    @printf("%-12.1f%-14.4f%-14.4f%-14.4f%-14.4f\n", r.lambda, r.noise, r.bias2, r.var, r.epe)
end
println("\n=> λ 增大：偏差² 单调上升、方差单调下降，EPE 在中间取最小（正文式 29.7）。")

# %% [markdown]
# ## 2　有效自由度与正则化路径（正文式 29.11）

# %%
"""正文式 (29.11)：岭回归的有效自由度。"""
df_ridge(d::Vector{Float64}, lambda::Float64) = sum(d.^2 ./ (d.^2 .+ lambda))

D29 = sim_geno(600, 1000, 0.4; arch=:additive, rng=Xoshiro(2910))
Zs, mu_, sd_ = standardize(D29.Z)
sv = svd(Zs).S

@printf("%-14s%-16s%-16s\n", "λ", "df(λ)", "df/rank")
for lam in (0.0, 1.0, 10.0, 100.0, 1e3, 1e4, 1e5)
    @printf("%-14.0f%-16.2f%-16.4f\n", lam, df_ridge(sv, lam), df_ridge(sv, lam)/length(sv))
end
@printf("\n矩阵秩 = %d ， n = %d ， m = %d\n", count(>(1e-8), sv), size(Zs,1), size(Zs,2))
# 与"有效独立片段数"的对照
lam_opt = (1 - D29.h2)/D29.h2 * D29.sum2pq
@printf("λ_GBLUP = σe²/σα² = (1-h²)/h² × 2Σpq = %.1f  →  df = %.1f\n",
        lam_opt, df_ridge(sv, lam_opt))
println("（正文 §29.1.3 的注：df(λ) 在基因组预测中近似等于 Me）")

# %% [markdown]
# ## 3　岭回归 ≡ GBLUP（定理 29.1）

# %%
"""GBLUP：用 G 矩阵求解（育种值模型）。"""
function gblup_predict(Ztr, ytr, Zte, h2, sum2pq)
    n = size(Ztr,1)
    G = (Ztr*Ztr') ./ sum2pq
    lam = (1-h2)/h2
    ybar = mean(ytr)
    a = (G + lam*I) \ (ytr .- ybar)
    # 新个体：g_te = G_te,tr a
    Gte = (Zte*Ztr') ./ sum2pq
    return Gte*a .+ ybar, a
end

tr_ = 1:450; te = 451:600
b_ridge, ybar = ridge_fit(D29.Z[tr_,:], D29.y[tr_], (1-D29.h2)/D29.h2 * D29.sum2pq)
pred_ridge = ridge_predict(D29.Z[te,:], b_ridge, ybar)
pred_gblup, _ = gblup_predict(D29.Z[tr_,:], D29.y[tr_], D29.Z[te,:], D29.h2, D29.sum2pq)

check("定理 29.1：岭回归 = GBLUP", pred_ridge, pred_gblup; tol=1e-6)
@printf("cor(岭, 真值 g) = %.4f ；cor(GBLUP, 真值 g) = %.4f\n",
        cor(pred_ridge, D29.g[te]), cor(pred_gblup, D29.g[te]))

# %% [markdown]
# ## 4　LASSO 的坐标下降（正文式 29.20、算法 29.2）

# %%
"""正文式 (29.20)：软阈值算子。"""
@inline soft_threshold(z::Float64, lam::Float64) = sign(z)*max(abs(z) - lam, 0.0)

"""算法 29.2：弹性网络（α=1 为 LASSO，α=0 为岭）的坐标下降。

X 的列假定已标准化（均值 0、方差 1）；y 已中心化。
"""
function enet_coord(X::Matrix{Float64}, y::Vector{Float64}, lambda::Float64;
                    alpha::Float64=1.0, beta0::Union{Nothing,Vector{Float64}}=nothing,
                    maxit::Int=1000, tol::Float64=1e-8)
    n, p = size(X)
    beta = beta0 === nothing ? zeros(p) : copy(beta0)
    r = y .- X*beta
    xx = [dot(view(X,:,j), view(X,:,j))/n for j in 1:p]
    for it in 1:maxit
        maxchg = 0.0
        @inbounds for j in 1:p
            bj = beta[j]
            zj = dot(view(X,:,j), r)/n + xx[j]*bj
            bn = soft_threshold(zj, lambda*alpha)/(xx[j] + lambda*(1-alpha))
            d = bn - bj
            if d != 0.0
                @simd for i in 1:n; r[i] -= X[i,j]*d; end
                beta[j] = bn
                maxchg = max(maxchg, abs(d))
            end
        end
        maxchg < tol && break
    end
    return beta
end

"""正文式 (29.26)：λ_max。"""
lambda_max(X, y, alpha) = maximum(abs.(X'y))/(size(X,1)*max(alpha, 1e-3))

"""沿 λ 从大到小热启动求解正则化路径。"""
function enet_path(X, y; alpha=1.0, nlam=60, eps=1e-3)
    lmax = lambda_max(X, y, alpha)
    lams = exp.(range(log(lmax), log(eps*lmax); length=nlam))
    B = zeros(size(X,2), nlam)
    b = zeros(size(X,2))
    for (k, lam) in enumerate(lams)
        b = enet_coord(X, y, lam; alpha=alpha, beta0=b, maxit=150)
        B[:, k] .= b
    end
    return lams, B
end

Xtr = Zs[tr_, :]; ytr_c = D29.y[tr_] .- mean(D29.y[tr_])
lams, B = enet_path(Xtr, ytr_c; alpha=1.0, nlam=40)
nz = [count(!=(0.0), view(B,:,k)) for k in 1:size(B,2)]
@printf("LASSO 正则化路径（λ_max = %.4f）\n\n", lams[1])
@printf("%-14s%-16s%-16s\n", "λ", "非零系数数", "训练 R²")
for k in (1, 5, 10, 20, 30, 40)
    pred = Xtr*view(B,:,k)
    @printf("%-14.5f%-16d%-16.4f\n", lams[k], nz[k], 1 - var(ytr_c .- pred)/var(ytr_c))
end
@printf("\n最大非零系数数 = %d ， 训练样本数 n = %d （LASSO 在 p>n 时至多选 n 个，正文 §29.2.2）\n",
        maximum(nz), length(tr_))

# 软阈值的性质验证
@printf("\n软阈值： S(3, 1) = %.1f ， S(-3, 1) = %.1f ， S(0.5, 1) = %.1f\n",
        soft_threshold(3.0,1.0), soft_threshold(-3.0,1.0), soft_threshold(0.5,1.0))

# %% [markdown]
# ## 5　弹性网络的分组效应（正文式 29.23）

# %%
# 构造两个 r = 0.99 的高度相关特征，看 LASSO 与弹性网络如何处理
let rng = Xoshiro(2920), n = 300
    x1 = randn(rng, n)
    x2 = 0.99 .* x1 .+ sqrt(1-0.99^2).*randn(rng, n)
    Xc = hcat(x1, x2, randn(rng, n, 8))
    Xc = (Xc .- mean(Xc; dims=1)) ./ std(Xc; dims=1)
    yv = 1.0 .* x1 .+ 1.0 .* x2 .+ 0.5.*randn(rng, n)
    yv .-= mean(yv)
    @printf("x1 与 x2 的相关 = %.4f\n\n", cor(x1, x2))
    @printf("%-16s%-14s%-14s%-16s\n", "方法", "β̂₁", "β̂₂", "|β̂₁-β̂₂|")
    for (nm, al) in ("LASSO (α=1)"=>1.0, "弹性网 (α=0.5)"=>0.5, "弹性网 (α=0.2)"=>0.2, "岭 (α=0)"=>0.0)
        b = enet_coord(Xc, yv, 0.05; alpha=al)
        @printf("%-16s%-14.4f%-14.4f%-16.4f\n", nm, b[1], b[2], abs(b[1]-b[2]))
    end
    println("\n=> LASSO 把两个几乎相同的特征中的一个压到零（任意选择）；")
    println("   弹性网络的 ℓ₂ 项使系数接近（正文式 29.23 的分组效应）。")
    # 扰动稳定性
    println("\n对数据做微小扰动后重新拟合（10 次）：")
    for (nm, al) in ("LASSO"=>1.0, "弹性网 α=0.5"=>0.5)
        picks = Int[]
        for r in 1:10
            yp = yv .+ 0.02.*randn(Xoshiro(4000+r), n)
            b = enet_coord(Xc, yp, 0.05; alpha=al)
            push!(picks, abs(b[1]) > abs(b[2]) ? 1 : 2)
        end
        @printf("  %-14s 选中 x1 的次数 = %d / 10\n", nm, count(==(1), picks))
    end
end

# %% [markdown]
# ## 6　核方法：核岭回归 ≡ GBLUP（定理 29.2）

# %%
"""线性核与高斯核。"""
linear_kernel(A, B, s) = (A*B') ./ s
function gaussian_kernel(A::AbstractMatrix, B::AbstractMatrix, h::Float64)
    m = size(A,2)
    sa = vec(sum(abs2, A; dims=2)); sb = vec(sum(abs2, B; dims=2))
    D2 = (sa .+ sb' .- 2 .* (A*B')) ./ m
    return exp.(-h .* max.(D2, 0.0))
end

"""正文式 (29.31)：核岭回归。"""
function krr_fit(K::Matrix{Float64}, y::Vector{Float64}, lambda::Float64)
    ybar = mean(y)
    c = (K + lambda*I) \ (y .- ybar)
    return c, ybar
end
krr_predict(Kte, c, ybar) = Kte*c .+ ybar

Ztr29 = D29.Z[tr_,:]; Zte29 = D29.Z[te,:]
Klin_tr = linear_kernel(Ztr29, Ztr29, D29.sum2pq)
Klin_te = linear_kernel(Zte29, Ztr29, D29.sum2pq)
c_lin, yb = krr_fit(Klin_tr, D29.y[tr_], (1-D29.h2)/D29.h2)
pred_krr = krr_predict(Klin_te, c_lin, yb)
check("定理 29.2：核岭（线性核） = GBLUP", pred_krr, pred_gblup; tol=1e-8)

# 高斯核在 h→0 时退化为线性核（正文式 29.33）
println("\n高斯核 → 线性核的极限（正文式 29.33）")
@printf("%-14s%-24s%-20s\n", "h", "cor(预测, GBLUP预测)", "cor(预测, 真值 g)")
for h in (5.0, 1.0, 0.3, 0.1, 0.03, 0.01, 0.003)
    Ktr = gaussian_kernel(Ztr29, Ztr29, h)
    Kte_ = gaussian_kernel(Zte29, Ztr29, h)
    # 用与 GBLUP 等效的 λ（按核的对角尺度缩放）
    lam_h = (1-D29.h2)/D29.h2 * mean(diag(Ktr))
    c, yb2 = krr_fit(Ktr, D29.y[tr_], lam_h)
    pr = krr_predict(Kte_, c, yb2)
    @printf("%-14.3f%-24.5f%-20.4f\n", h, cor(pr, pred_gblup), cor(pr, D29.g[te]))
end
println("\n=> h → 0 时高斯核预测与 GBLUP 趋于一致（正文思考题 9）。")

# %% [markdown]
# ## 7　树、随机森林与梯度提升的从零实现

# %%
"""回归树的一个节点。"""
struct TreeNode
    isleaf::Bool
    value::Float64
    feature::Int
    threshold::Float64
    left::Int
    right::Int
end

"""正文式 (29.40)：在候选特征上找最优切分（最大方差缩减）。"""
function best_split(X::Matrix{Float64}, y::Vector{Float64}, idx::Vector{Int},
                    feats::Vector{Int}, minleaf::Int)
    n = length(idx)
    n < 2*minleaf && return (0, 0.0, -Inf)
    bestj = 0; bestt = 0.0; bestgain = -Inf
    ysum = sum(view(y, idx))
    for j in feats
        vals = [X[i, j] for i in idx]
        o = sortperm(vals)
        sv = vals[o]; sy = [y[idx[k]] for k in o]
        cl = 0.0
        @inbounds for k in 1:n-1
            cl += sy[k]
            (k < minleaf || n-k < minleaf) && continue
            sv[k] == sv[k+1] && continue
            nl = k; nr = n - k
            ml = cl/nl; mr = (ysum - cl)/nr
            gain = nl*nr/n*(ml - mr)^2                 # 式 (29.40)
            if gain > bestgain
                bestgain = gain; bestj = j; bestt = 0.5*(sv[k] + sv[k+1])
            end
        end
    end
    return (bestj, bestt, bestgain)
end

"""训练一棵回归树。返回节点向量（1 为根）。"""
function fit_tree(X::Matrix{Float64}, y::Vector{Float64};
                  maxdepth::Int=6, minleaf::Int=5, mtry::Int=size(X,2),
                  rng=Random.default_rng())
    nodes = TreeNode[]
    function build(idx::Vector{Int}, depth::Int)
        push!(nodes, TreeNode(true, mean(view(y, idx)), 0, 0.0, 0, 0))
        me = length(nodes)
        (depth >= maxdepth || length(idx) < 2*minleaf) && return me
        feats = mtry >= size(X,2) ? collect(1:size(X,2)) :
                randperm(rng, size(X,2))[1:mtry]
        j, t, gain = best_split(X, y, idx, feats, minleaf)
        (j == 0 || gain <= 0) && return me
        li = [i for i in idx if X[i,j] <= t]
        ri = [i for i in idx if X[i,j] >  t]
        (isempty(li) || isempty(ri)) && return me
        l = build(li, depth+1); r = build(ri, depth+1)
        nodes[me] = TreeNode(false, nodes[me].value, j, t, l, r)
        return me
    end
    build(collect(1:size(X,1)), 0)
    return nodes
end

function predict_tree(nodes::Vector{TreeNode}, x::AbstractVector)
    k = 1
    while !nodes[k].isleaf
        k = x[nodes[k].feature] <= nodes[k].threshold ? nodes[k].left : nodes[k].right
    end
    return nodes[k].value
end
predict_tree(nodes, X::AbstractMatrix) = [predict_tree(nodes, view(X,i,:)) for i in axes(X,1)]

"""随机森林。"""
function fit_forest(X, y; ntree=100, mtry=max(1, size(X,2) ÷ 3),
                    maxdepth=10, minleaf=5, rng=Random.default_rng())
    n = size(X,1)
    trees = Vector{Vector{TreeNode}}()
    oob = [Int[] for _ in 1:n]
    for b in 1:ntree
        bs = rand(rng, 1:n, n)
        push!(trees, fit_tree(X[bs,:], y[bs]; maxdepth=maxdepth, minleaf=minleaf,
                              mtry=mtry, rng=rng))
        for i in setdiff(1:n, unique(bs)); push!(oob[i], b); end
    end
    return trees, oob
end
predict_forest(trees, X) = mean(predict_tree(t, X) for t in trees)

"""梯度提升（平方损失；正文式 29.45–29.46）。"""
function fit_gbm(X, y; ntree=300, eta=0.05, maxdepth=3, minleaf=5,
                 subsample=0.8, mtry=size(X,2), rng=Random.default_rng())
    n = size(X,1)
    F0 = mean(y)
    trees = Vector{Vector{TreeNode}}()
    F = fill(F0, n)
    for b in 1:ntree
        r = y .- F                                   # 式 (29.45)：平方损失的负梯度
        idx = subsample >= 1 ? collect(1:n) : randperm(rng, n)[1:round(Int, subsample*n)]
        t = fit_tree(X[idx,:], r[idx]; maxdepth=maxdepth, minleaf=minleaf,
                     mtry=mtry, rng=rng)
        push!(trees, t)
        F .+= eta .* predict_tree(t, X)              # 式 (29.46)
    end
    return (F0=F0, trees=trees, eta=eta)
end
predict_gbm(m, X) = m.F0 .+ m.eta .* sum(predict_tree(t, X) for t in m.trees)

# 在一个低维、有真实非线性的问题上检验实现是否正确
let rng = Xoshiro(2930), n = 800
    Xt = randn(rng, n, 5)
    ft = 2 .* Xt[:,1] .* Xt[:,2] .+ sin.(3 .* Xt[:,3])
    yt = ft .+ 0.3.*randn(rng, n)
    tri = 1:600; tei = 601:n
    tree = fit_tree(Xt[tri,:], yt[tri]; maxdepth=6)
    trees, _ = fit_forest(Xt[tri,:], yt[tri]; ntree=100, mtry=3, rng=Xoshiro(1))
    gbm = fit_gbm(Xt[tri,:], yt[tri]; ntree=300, eta=0.05, maxdepth=3, rng=Xoshiro(2))
    bl = (hcat(ones(600), Xt[tri,:]) \ yt[tri])
    @printf("低维非线性问题（真函数 = 2x₁x₂ + sin(3x₃)）\n")
    @printf("  线性回归   ： cor = %.4f\n", cor(hcat(ones(200), Xt[tei,:])*bl, ft[tei]))
    @printf("  单棵树     ： cor = %.4f\n", cor(predict_tree(tree, Xt[tei,:]), ft[tei]))
    @printf("  随机森林   ： cor = %.4f\n", cor(predict_forest(trees, Xt[tei,:]), ft[tei]))
    @printf("  梯度提升   ： cor = %.4f\n", cor(predict_gbm(gbm, Xt[tei,:]), ft[tei]))
    println("  => 在低维、高信噪比、真非线性的问题上，树方法压倒线性模型。")
end

# %% [markdown]
# ## 8　随机森林的方差公式（正文式 29.43）
#
# $$\mathrm{Var}\left(\bar f\right)=\rho\sigma^2+\frac{1-\rho}{B}\sigma^2$$

# %%
# 用不同的 mtry 改变树间相关 ρ，验证式 (29.43)
let rng = Xoshiro(2940), n = 400, p = 12
    Xt = randn(rng, n, p)
    ft = Xt*randn(rng, p)
    yt = ft .+ 0.8.*randn(rng, n)
    Xte_ = randn(rng, 300, p)
    @printf("%-10s%-14s%-14s%-18s%-18s\n", "mtry", "ρ̂(树间相关)", "σ̂²(单树方差)",
            "实测 Var(平均)", "式(29.43) 预测")
    for mt in (1, 3, 6, 12)
        B = 60
        P = zeros(B, 300)
        trees, _ = fit_forest(Xt, yt; ntree=B, mtry=mt, maxdepth=8, rng=Xoshiro(50+mt))
        for b in 1:B; P[b, :] .= predict_tree(trees[b], Xte_); end
        s2 = mean(vec(var(P; dims=1)))
        # 树间相关（在测试点上平均）
        cors = Float64[]
        for a in 1:B-1, b in a+1:min(B, a+5)
            push!(cors, cor(view(P,a,:), view(P,b,:)))
        end
        rho = mean(cors)
        var_obs = var(vec(mean(P; dims=1)))
        # 式 (29.43) 预测的"平均预测的方差"（相对单树方差的比例）
        pred_ratio = rho + (1-rho)/B
        @printf("%-10d%-14.4f%-14.4f%-18.4f%-18.4f\n", mt, rho, s2, var_obs/s2, pred_ratio)
    end
    println("\n=> 最后两列应接近：mtry 越小，ρ 越小，平均后的方差越低（正文式 29.43）。")
    println("   注意 mtry=p 时 ρ 最大——这正是随机森林要随机选特征的理由。")
end

# %% [markdown]
# ## 9　嵌套交叉验证（算法 29.1）与单层 CV 的乐观程度

# %%
"""单层 CV：用同一个 CV 既选 λ 又报告误差（**错误做法**）。"""
function single_cv(X, y; lams=exp.(range(log(1e-2), log(1e4); length=25)), k=5,
                   rng=Random.default_rng())
    n = length(y); perm = randperm(rng, n)
    folds = [perm[i:k:end] for i in 1:k]
    best = (Inf, NaN)
    for lam in lams
        errs = Float64[]
        for f in folds
            tr = setdiff(1:n, f)
            b, yb = ridge_fit(X[tr,:], y[tr], lam)
            push!(errs, mean((y[f] .- ridge_predict(X[f,:], b, yb)).^2))
        end
        m = mean(errs)
        m < best[1] && (best = (m, lam))
    end
    return best[1], best[2]            # 报告的"误差"与选中的 λ
end

"""算法 29.1：嵌套 CV（**正确做法**）。"""
function nested_cv(X, y; lams=exp.(range(log(1e-2), log(1e4); length=25)),
                   kout=5, kin=5, rng=Random.default_rng())
    n = length(y); perm = randperm(rng, n)
    outer = [perm[i:kout:end] for i in 1:kout]
    errs = Float64[]; chosen = Float64[]
    for f in outer
        tr = setdiff(1:n, f)
        # 内层只用外层训练集
        inner_perm = randperm(rng, length(tr))
        inner = [tr[inner_perm[i:kin:end]] for i in 1:kin]
        best = (Inf, NaN)
        for lam in lams
            e = Float64[]
            for g in inner
                tr2 = setdiff(tr, g)
                b, yb = ridge_fit(X[tr2,:], y[tr2], lam)
                push!(e, mean((y[g] .- ridge_predict(X[g,:], b, yb)).^2))
            end
            m = mean(e); m < best[1] && (best = (m, lam))
        end
        b, yb = ridge_fit(X[tr,:], y[tr], best[2])
        push!(errs, mean((y[f] .- ridge_predict(X[f,:], b, yb)).^2))
        push!(chosen, best[2])
    end
    return mean(errs), chosen
end

# 一次生成 2300 头：前 300 头做 CV，后 2000 头作为"真实泛化误差"的大测试集
D_all = sim_geno(2300, 600, 0.4; rng=Xoshiro(2950))
cvi = 1:300; bigte = 301:2300
Zcv, mu_cv, sd_cv = standardize(D_all.Z[cvi, :])
ycv = D_all.y[cvi]
e_single, lam_sel = single_cv(Zcv, ycv; rng=Xoshiro(11))
e_nested, chosen  = nested_cv(Zcv, ycv; rng=Xoshiro(11))
b_full, yb_full = ridge_fit(Zcv, ycv, lam_sel)
Zte_std = apply_standardize(D_all.Z[bigte, :], mu_cv, sd_cv)
e_true = mean((D_all.y[bigte] .- ridge_predict(Zte_std, b_full, yb_full)).^2)

@printf("单层 CV 报告的 MSE   = %.4f   （选中 λ = %.2f）\n", e_single, lam_sel)
@printf("嵌套 CV 报告的 MSE   = %.4f   （各折选中 λ = %s）\n", e_nested,
        string(round.(chosen, digits=1)))
@printf("大独立测试集的 MSE   = %.4f\n", e_true)
@printf("\n单层 CV 的乐观程度 = %.1f%% ； 嵌套 CV = %.1f%%\n",
        100*(e_true/e_single - 1), 100*(e_true/e_nested - 1))
println("=> 单层 CV 系统性低估泛化误差（正文 §29.1.4）。")

# %% [markdown]
# ## 10　六种方法在同一基因组数据上的公平比较
#
# 按第二十四章与第三十一章 §31.1.4 的要求：同一划分、多次重复、报告 $r$ 与 $b_1$。

# %%
"""计时辅助：返回 (函数值, 秒)。"""
function timed(f)
    t0 = time_ns(); v = f(); return v, (time_ns() - t0)/1e9
end

"""在给定划分上评估一组方法，返回 (名称 => (r, b1, 秒)) 的向量。"""
function compare_methods(D; tr, te, rng=Random.default_rng())
    Ztr = D.Z[tr,:]; Zte = D.Z[te,:]
    ytr = D.y[tr]; gte = D.g[te]
    Zs_tr, mu, sd = standardize(Ztr); Zs_te = apply_standardize(Zte, mu, sd)
    ytr_c = ytr .- mean(ytr); ybar = mean(ytr)
    n_ = length(tr); perm = randperm(rng, n_)
    folds = [perm[i:5:end] for i in 1:5]
    ev(p) = (cor(p, gte), cov(gte, p)/var(p))
    out = Pair{String,NTuple{3,Float64}}[]

    p1, t1 = timed() do
        lam = (1 - D.h2)/D.h2 * D.sum2pq
        b, yb = ridge_fit(Ztr, ytr, lam)
        ridge_predict(Zte, b, yb)
    end
    push!(out, "GBLUP" => (ev(p1)..., t1))

    p2, t2 = timed() do
        lams = exp.(range(log(1e-1), log(1e5); length=15))
        best = (Inf, lams[1])
        for lam in lams
            e = Float64[]
            for f in folds
                t2i = setdiff(1:n_, f)
                bb, yy = ridge_fit(Ztr[t2i,:], ytr[t2i], lam)
                push!(e, mean((ytr[f] .- ridge_predict(Ztr[f,:], bb, yy)).^2))
            end
            m = mean(e); m < best[1] && (best = (m, lam))
        end
        b, yb = ridge_fit(Ztr, ytr, best[2])
        ridge_predict(Zte, b, yb)
    end
    push!(out, "岭（CV 调 λ）" => (ev(p2)..., t2))

    p3, t3 = timed() do
        lmax = lambda_max(Zs_tr, ytr_c, 1.0)
        lams = exp.(range(log(lmax), log(5e-2*lmax); length=12))
        best = (Inf, lams[1]); warm = Dict{Int,Vector{Float64}}()
        for lam in lams
            e = Float64[]
            for (fi, f) in enumerate(folds)
                t2i = setdiff(1:n_, f)
                w0 = get(warm, fi, zeros(size(Zs_tr,2)))
                bb = enet_coord(Zs_tr[t2i,:], ytr_c[t2i], lam; alpha=1.0,
                                beta0=w0, maxit=80)
                warm[fi] = bb
                push!(e, mean((ytr_c[f] .- Zs_tr[f,:]*bb).^2))
            end
            m = mean(e); m < best[1] && (best = (m, lam))
        end
        bb = enet_coord(Zs_tr, ytr_c, best[2]; alpha=1.0, maxit=300)
        Zs_te*bb .+ ybar
    end
    push!(out, "LASSO" => (ev(p3)..., t3))

    p4, t4 = timed() do
        bb = enet_coord(Zs_tr, ytr_c, 0.02; alpha=0.5, maxit=300)
        Zs_te*bb .+ ybar
    end
    push!(out, "弹性网络" => (ev(p4)..., t4))

    p5, t5 = timed() do
        Kt = gaussian_kernel(Zs_tr, Zs_tr, 1.0)
        Ke = gaussian_kernel(Zs_te, Zs_tr, 1.0)
        c, yb = krr_fit(Kt, ytr, (1-D.h2)/D.h2*mean(diag(Kt)))
        krr_predict(Ke, c, yb)
    end
    push!(out, "核岭（高斯核）" => (ev(p5)..., t5))

    p6, t6 = timed() do
        trees, _ = fit_forest(Zs_tr, ytr; ntree=40,
                              mtry=max(1, size(Zs_tr,2) ÷ 10), maxdepth=8, rng=rng)
        predict_forest(trees, Zs_te)
    end
    push!(out, "随机森林" => (ev(p6)..., t6))

    p7, t7 = timed() do
        gbm = fit_gbm(Zs_tr, ytr; ntree=150, eta=0.05, maxdepth=3,
                      mtry=max(1, size(Zs_tr,2) ÷ 10), rng=rng)
        predict_gbm(gbm, Zs_te)
    end
    push!(out, "梯度提升" => (ev(p7)..., t7))
    return out
end

println("纯加性结构（h² = 0.4，n = 500，m = 400）\n")
Dc = sim_geno(500, 400, 0.4; arch=:additive, rng=Xoshiro(2960))
res = compare_methods(Dc; tr=1:380, te=381:500, rng=Xoshiro(7))
@printf("%-18s%-12s%-12s%-12s\n", "方法", "r(ĝ,g)", "b1", "秒")
for (nm, (r, b1, tt)) in res
    @printf("%-18s%-12.4f%-12.3f%-12.2f\n", nm, r, b1, tt)
end
println("\n=> 在纯加性结构下 GBLUP 最优——这是第三十一章 §31.1.2 限制一的数值确认。")

# %%
println("含上位效应的结构（ε² = 0.10）\n")
De = sim_geno(500, 400, 0.4; arch=:epistatic, eps2=0.10, rng=Xoshiro(2970))
res_e = compare_methods(De; tr=1:380, te=381:500, rng=Xoshiro(7))
@printf("%-18s%-12s%-12s%-12s\n", "方法", "r(ĝ,g)", "b1", "秒")
for (nm, (r, b1, tt)) in res_e
    @printf("%-18s%-12.4f%-12.3f%-12.2f\n", nm, r, b1, tt)
end

println("\n寡基因结构\n")
Do = sim_geno(500, 400, 0.4; arch=:oligogenic, rng=Xoshiro(2980))
res_o = compare_methods(Do; tr=1:380, te=381:500, rng=Xoshiro(7))
@printf("%-18s%-12s%-12s%-12s\n", "方法", "r(ĝ,g)", "b1", "秒")
for (nm, (r, b1, tt)) in res_o
    @printf("%-18s%-12.4f%-12.3f%-12.2f\n", nm, r, b1, tt)
end
println("\n=> 寡基因结构下 LASSO/弹性网络的稀疏性开始显出价值（对应第二十二章 §22.4.2）。")

# %% [markdown]
# ## 11　MLJ.jl 统一接口的对照（可选）
#
# §7 从零实现了树、随机森林与梯度提升，目的是看清原理。生产中应使用成熟实现：**DecisionTree.jl**（随机森林）与 **EvoTrees.jl**（直方图梯度提升，思想同 XGBoost/LightGBM），并通过 **MLJ.jl** 的统一接口调用——同一套 `machine / fit! / predict / evaluate` 适用于全部模型，重采样、调参、流水线都不必重写。
#
# 需要可选环境 `envs/ml`（MLJ、MLJDecisionTreeInterface、EvoTrees，见附录 E），默认 `RUN_MLJ = false`。数据沿用 §10 的上位效应场景 `De`（同一划分）。`@load` 是宏，所以放在 `@eval` 中，只在开关打开时展开。

# %%
RUN_MLJ = false            # 先实例化可选环境 envs/ml（附录 E），再改为 true
if RUN_MLJ
    let env = joinpath(dirname(Base.active_project()), "envs", "ml")
        isdir(env) || (env = normpath(joinpath(pwd(), "..", "envs", "ml")))
        env in LOAD_PATH || push!(LOAD_PATH, env)   # 叠加可选环境（附录 E）
    end
    using MLJ
end

# %%
if RUN_MLJ
    RFModel  = @eval @load RandomForestRegressor pkg=DecisionTree verbosity=0
    EvoModel = @eval @load EvoTreeRegressor pkg=EvoTrees verbosity=0
    trm, tem = 1:380, 381:500
    Xtr_t = MLJ.table(De.Z[trm, :]); Xte_t = MLJ.table(De.Z[tem, :])
    ytr_m = De.y[trm]; gte_m = De.g[tem]

    rf  = RFModel(n_trees = 500, n_subfeatures = 40, max_depth = 8,
                  sampling_fraction = 0.7, rng = Xoshiro(2990))
    evo = EvoModel(nrounds = 300, eta = 0.05, max_depth = 4,
                   rowsample = 0.8, colsample = 0.5, rng = 2991)
    for (nm, mdl) in ("随机森林（DecisionTree.jl）" => rf, "梯度提升（EvoTrees.jl）" => evo)
        mach = machine(mdl, Xtr_t, ytr_m)
        fit!(mach; verbosity = 0)
        pm = predict(mach, Xte_t)
        @printf("%-30s r(ĝ,g) = %.4f   b1 = %.3f\n", nm, cor(pm, gte_m), cov(gte_m, pm)/var(pm))
    end
    # 统一接口的价值：一行代码完成 5 折交叉验证
    ev = evaluate(rf, Xtr_t, ytr_m;
                  resampling = CV(nfolds = 5, shuffle = true, rng = Xoshiro(2992)),
                  measure = rms, verbosity = 0)
    @printf("\n随机森林的 5 折 CV RMSE = %.4f\n", ev.measurement[1])
    println("对照 §10 的从零实现：结论应一致——加性为主时树模型不占优（正文 §29.4.4）。")
else
    println("RUN_MLJ = false：跳过 MLJ 对照（正文 §29.4、§30.5.3）。")
end

# %% [markdown]
# ## 12　自检汇总

# %%
ok = Bool[]
push!(ok, check("定理 29.1：岭 = GBLUP", pred_ridge, pred_gblup; tol=1e-6))
push!(ok, check("定理 29.2：核岭（线性核）= GBLUP", pred_krr, pred_gblup; tol=1e-8))
push!(ok, check("软阈值 S(z,0) = z", soft_threshold(3.7, 0.0), 3.7; tol=0))
push!(ok, check("软阈值在 |z|<λ 处为 0", soft_threshold(0.5, 1.0), 0.0; tol=0))
# α=0 的弹性网络 = 岭回归
let Xq = Zs[1:200, 1:50], yq = D29.y[1:200] .- mean(D29.y[1:200]), lam = 0.3
    b_en = enet_coord(Xq, yq, lam; alpha=0.0, maxit=5000, tol=1e-12)
    b_rg = (Xq'Xq ./ size(Xq,1) + lam*I) \ (Xq'yq ./ size(Xq,1))
    push!(ok, check("α=0 的弹性网络 = 岭回归", b_en, b_rg; tol=1e-6))
end
# df(λ) 的单调性与边界
push!(ok, check("df(0) = rank", df_ridge(sv, 0.0), Float64(count(>(1e-8), sv)); tol=1e-8))
push!(ok, df_ridge(sv, 1e12) < 1e-6)
@printf("df(1e12) = %.3e （应趋于 0）\n", df_ridge(sv, 1e12))
# 嵌套 CV 比单层 CV 更接近真值
@printf("|嵌套 CV - 真值| = %.4f ； |单层 CV - 真值| = %.4f\n",
        abs(e_nested - e_true), abs(e_single - e_true))
push!(ok, abs(e_nested - e_true) <= abs(e_single - e_true) + 0.05)
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
