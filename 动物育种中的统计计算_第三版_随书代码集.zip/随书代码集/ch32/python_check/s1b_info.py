# §32.1.4 part B: r_IH vs information amount (traits x full-sib number), identities, canonical bounds
from common import *
from scipy.linalg import sqrtm, eigh
I = I10
v = v3
C = G3


def info_mats(T, n, P=P3, G=G3):
    """own phenotypes of traits T plus mean of n full sibs (same traits T).  c^2 = 0.
    returns Pext (Var x), Gext (Cov(x, a'))  [rows ordered: own T, sibmean T]"""
    T = list(T)
    Pm = P[np.ix_(T, T)]
    Gm = G[np.ix_(T, T)]       # Cov among traits (genetic) restricted
    Gx = G[T, :]               # Cov(own x_T, a')  (len(T) x 3)
    if n == 0:
        return Pm, Gx
    R = 0.5 * Gm               # Cov(own x, sib x) = 1/2 G
    if np.isinf(n):
        Vs = 0.5 * Gm
    else:
        Vs = (Pm + (n - 1) * R) / n
    Pe = np.block([[Pm, R], [R, Vs]])
    Ge = np.vstack([Gx, 0.5 * Gx])
    return Pe, Ge


def analyse(T, n):
    Pe, Ge = info_mats(T, n)
    b, g = hazel(Pe, Ge, v)
    varI = b @ Pe @ b
    covIH = b @ g
    sH = np.sqrt(v @ C @ v)
    r_def = covIH / (np.sqrt(varI) * sH)
    A = Ge.T @ np.linalg.solve(Pe, Ge)
    vAv = v @ A @ v
    return dict(b=b, varI=varI, covIH=covIH, r=r_def, r2a=varI / sH**2, r2b=covIH / sH**2, r2c=vAv / sH**2, sH=sH, A=A,
                dH=I * r_def * sH, da=I / np.sqrt(varI) * (Ge.T @ b))

sets = {'ADG': [0], 'ADG+BF': [0, 2], 'ADG+FCR+BF': [0, 1, 2]}
ns = [0, 1, 2, 5, 10, 20, 50, 200, np.inf]
print('r_IH grid (rows n sibs; cols trait sets)')
tab = {}
for n in ns:
    row = []
    for nm, T in sets.items():
        a = analyse(T, n)
        row.append(a['r'])
        tab[(n, nm)] = a
    print('n=%5s  ' % n, '  '.join('%.4f' % x for x in row))
# check large finite n -> inf
a1 = analyse([0, 1, 2], 1e7); a2 = analyse([0, 1, 2], np.inf)
print('n=1e7 vs inf (3 traits): %.6f %.6f' % (a1['r'], a2['r']))
# dH grid
print('\ndH (yuan/gen, i=1.755)')
for n in ns:
    print('n=%5s  ' % n, '  '.join('%.2f' % tab[(n, nm)]['dH'] for nm in sets))
# relative to n=0 3-trait
base = tab[(0, 'ADG+FCR+BF')]['r']
print('\n3-trait: gain relative to n=0:')
for n in ns:
    print('n=%5s  r=%.4f  ratio=%.4f   dr from previous' % (n, tab[(n, 'ADG+FCR+BF')]['r'], tab[(n, 'ADG+FCR+BF')]['r'] / base))
# identity check
print('\n--- identity checks (relative differences) ---')
worst = 0
for n in ns:
    for nm, T in sets.items():
        a = tab[(n, nm)]
        d = max(abs(a['r2a'] - a['r2b']), abs(a['r2a'] - a['r2c']), abs(a['r2a'] - a['r'] ** 2))
        worst = max(worst, d / a['r2a'])
        if n in (0, 5, np.inf):
            print('n=%5s %-11s varI=%.6f covIH=%.6f vAv=%.6f r2=%.8f  r=%.6f  maxreldiff %.2e' % (n, nm, a['varI'], a['covIH'], a['r2c'] * a['sH']**2, a['r']**2, a['r'], d / a['r2a']))
print('worst relative discrepancy over all %d info sets: %.3e' % (len(ns) * len(sets), worst))
