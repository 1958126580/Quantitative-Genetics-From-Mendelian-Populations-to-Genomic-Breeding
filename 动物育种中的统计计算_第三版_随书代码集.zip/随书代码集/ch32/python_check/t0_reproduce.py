# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 t0_reproduce.py    依赖：仅标准库
from common import *
print('i(0.10)=%.6f' % I10)
print('sdA3', sdA3)
print('v3', v3)
C = G3
sH = np.sqrt(v3 @ C @ v3)
print('sigma_H = %.4f' % sH)
for lab, idx in (('ADG+FCR+BF', [0, 1, 2]), ('ADG+BF', [0, 2]), ('ADG', [0]), ('BF', [2])):
    P = P3[np.ix_(idx, idx)]; G = G3[idx, :]
    b, g = hazel(P, G, v3)
    s = stats(b, P, G, C, v3)
    print(lab, np.round(b, 4), 'r=%.4f' % s['r'], 'da=', np.round(s['da'], 4), 'dH=%.2f' % s['dH'])
# E3 psd?
print('eig E3', np.linalg.eigvalsh(E3))
print('eig P3', np.linalg.eigvalsh(P3), 'eig G3', np.linalg.eigvalsh(G3))
