# -*- coding: utf-8 -*-
"""2-trait dairy example: milk yield (kg/lactation) and methane (kg CH4/cow/yr). Assumed values."""
import numpy as np
sdP = np.array([1200.0, 20.0])
h2 = np.array([0.30, 0.25])
rg = 0.40
rp = 0.30
sdA = sdP * np.sqrt(h2)
G = np.array([[sdA[0]**2, rg * sdA[0] * sdA[1]], [rg * sdA[0] * sdA[1], sdA[1]**2]])
P = np.array([[sdP[0]**2, rp * sdP[0] * sdP[1]], [rp * sdP[0] * sdP[1], sdP[1]**2]])
vM = 1.5            # yuan per kg milk (net of marginal feed cost), assumed
GWP = 27.0
I = 1.755


def vch4(C):
    """shadow price per kg CH4 for carbon price C (yuan / t CO2e)"""
    return -C * GWP / 1000.0


def C_from_v(v2):
    return -v2 * 1000.0 / GWP


def resp(b):
    sI = np.sqrt(b @ P @ b)
    return I / sI * (G @ b), sI


def hazel(v):
    return np.linalg.solve(P, G @ v)
