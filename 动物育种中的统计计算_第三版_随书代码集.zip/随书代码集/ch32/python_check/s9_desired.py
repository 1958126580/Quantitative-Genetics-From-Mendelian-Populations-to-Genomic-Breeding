# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s9_desired.py    依赖：numpy
# §32.3.6 desired gains index: derivation check + numerical example (ch10 pig parameters)
import numpy as np
from common import *

I = 1.755
bH = np.linalg.solve(P3, G3 @ v3)
sH = index_stats(bH, P3, G3, v3, G3, I)
print('Hazel: b', bH, 'da', sH['da'], 'dH', sH['dH'])


def desired(d, P, G):
    """general: b = P^-1 G (G'P^-1G)^-1 d ; v* = (G'P^-1G)^-1 d"""
    M = G.T @ np.linalg.solve(P, G)
    vstar = np.linalg.solve(M, d)
    b = np.linalg.solve(P, G @ vstar)
    return b, vstar


def show(name, d):
    b, vs = desired(d, P3, G3)
    # check special case b = G^-1 d
    b2 = np.linalg.solve(G3, d)
    assert np.allclose(b, b2)
    st = index_stats(b, P3, G3, v3, G3, I)
    scale = st['da'] / d
    vsn = vs * (-180.0 / vs[1])          # scale so v*_FCR = -180
    re = st['r'] / sH['r']
    print('%-22s d=%s' % (name, np.round(d, 5)))
    print('    b=%s  da=%s  achieved/d=%s' % (np.round(b, 4), np.round(st['da'], 5), np.round(scale, 4)))
    print('    dH(true v)=%.4f  RE=%.5f  implied v*(FCR=-180)=%s' % (st['dH'], re, np.round(vsn, 4)))
    return st, vsn, re


# (i) d = Hazel responses -> must reproduce Hazel index, v* prop v
show('(i) d = Hazel response', sH['da'])
# (ii) equal standardized favourable gains
show('(ii) equal std gains', np.array([sdA3[0], -sdA3[1], -sdA3[2]]))
# (iii) BF unchanged
show('(iii) BF zero', np.array([sdA3[0], -sdA3[1], 0.0]))
# (iv) ADG only emphasised with FCR/BF held
show('(iv) ADG+, FCR 0, BF 0', np.array([sdA3[0], 0.0, 0.0]))
# (v) strong fat reduction
show('(v) BF -2 std', np.array([sdA3[0], -sdA3[1], -2 * sdA3[2]]))
# (vi) ADG +1, FCR -1 , BF +0.5 (allow fat)
show('(vi) BF +0.5', np.array([sdA3[0], -sdA3[1], 0.5 * sdA3[2]]))

# p<k case: x=(ADG,BF) only, goal 3 traits -> M singular
idx = [0, 2]
P2 = P3[np.ix_(idx, idx)]
G2 = G3[idx, :]
M2 = G2.T @ np.linalg.solve(P2, G2)
print('\nrank of M2 = %d, eigen %s' % (np.linalg.matrix_rank(M2), np.linalg.eigvalsh(M2)))
# reachable responses: da = G2' b  (span of 2 columns of G2')
B = G2.T                     # 3x2
d = np.array([sdA3[0], -sdA3[1], -sdA3[2]])
coef, *_ = np.linalg.lstsq(B, d, rcond=None)
proj = B @ coef
cosang = proj @ d / np.linalg.norm(proj) / np.linalg.norm(d)
# do the comparison in standardized units (divide by sdA)
ds = d / sdA3
Bs = B / sdA3[:, None]
coef_s, *_ = np.linalg.lstsq(Bs, ds, rcond=None)
proj_s = Bs @ coef_s
cos_s = proj_s @ ds / np.linalg.norm(proj_s) / np.linalg.norm(ds)
print('std units: desired (1,-1,-1) nearest reachable direction =', np.round(proj_s / np.max(np.abs(proj_s)), 4), ' cos = %.4f angle = %.2f deg' % (cos_s, np.degrees(np.arccos(cos_s))))
# the index that achieves nearest direction: b = coef_s (since da = G2' b up to scale)
bb = coef_s
st = index_stats(bb, P2, G2, v3, G3, I)
print('that index: b=%s da=%s (std units %s)' % (np.round(bb, 5), np.round(st['da'], 5), np.round(st['da'] / sdA3, 4)))
# normal vector of reachable plane in std units
nvec = np.cross(Bs[:, 0], Bs[:, 1])
print('normal of reachable plane (std units):', np.round(nvec / np.linalg.norm(nvec), 4))
