# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1c_mc_canon.py    依赖：scipy
# §32.1.4 part C: Monte Carlo check of the sib-information construction; canonical heritabilities as bounds on r_IH^2
from common import *
from scipy.linalg import sqrtm
from s1b_info import info_mats, analyse
import sys
v = v3; C = G3
# ---- MC check, 3 traits, n = 5 full sibs
seed = 32101
rng = np.random.default_rng(seed)
n = 5
a = analyse([0, 1, 2], n)
b = a['b']
Lg = np.linalg.cholesky(G3); Le = np.linalg.cholesky(E3); Lm = np.linalg.cholesky(0.5 * G3)
NF = 400000
chunk = 100000
Is = []; Hs = []
for _ in range(NF // chunk):
    asr = rng.standard_normal((chunk, 3)) @ Lg.T
    adm = rng.standard_normal((chunk, 3)) @ Lg.T
    mid = 0.5 * (asr + adm)
    aj = mid[:, None, :] + rng.standard_normal((chunk, n + 1, 3)) @ Lm.T
    ej = rng.standard_normal((chunk, n + 1, 3)) @ Le.T
    xj = aj + ej
    xown = xj[:, 0, :]
    xs = xj[:, 1:, :].mean(axis=1)
    x = np.hstack([xown, xs])
    I_ = x @ b
    H_ = aj[:, 0, :] @ v
    Is.append(I_); Hs.append(H_)
Is = np.concatenate(Is); Hs = np.concatenate(Hs)
rho = np.corrcoef(Is, Hs)[0, 1]
slope = np.cov(Hs, Is)[0, 1] / Is.var(ddof=1)
print('MC (seed %d, %d families, n=%d sibs): corr(I,H)=%.4f (theory %.4f); Var(I)=%.2f (theory %.2f); slope H on I=%.4f' % (seed, NF, n, rho, a['r'], Is.var(ddof=1), a['varI'], slope))
print('SE of corr approx %.4f' % ((1 - a['r']**2) / np.sqrt(NF)))
# ---- canonical heritabilities
P, G = P3, G3
lam = np.sort(np.linalg.eigvals(np.linalg.solve(P, G)).real)[::-1]
print('\ncanonical heritabilities (eig of P^-1 G):', lam)
# via ch14 generalized eig (G, R) with R = E3 : lambda/(1+lambda)
from scipy.linalg import eigh
w = eigh(G, E3, eigvals_only=True)[::-1]
print('via G v = lam E v: lam', w, ' lam/(1+lam):', w / (1 + w))
print('single-trait h2:', h2_3)
# r^2 for the economic v
r2 = (v @ G @ np.linalg.solve(P, G) @ v) / (v @ G @ v)
print('r2 for v3 = %.6f (r=%.4f)' % (r2, np.sqrt(r2)))
# extreme directions: u eigenvectors of G^{1/2} P^-1 G^{1/2}
Gh = np.real(sqrtm(G))
M = Gh @ np.linalg.solve(P, Gh)
M = 0.5 * (M + M.T)
ev, U = np.linalg.eigh(M)
print('eig of G^1/2 P^-1 G^1/2:', ev[::-1])
for nm, k in (('best (max)', 2), ('worst (min)', 0)):
    uvec = U[:, k]
    vv = np.linalg.solve(Gh, uvec)
    vv = vv / np.abs(vv * sdA3).sum()      # normalise sum |v sdA| = 1
    sign = np.sign(vv[np.argmax(np.abs(vv))]); vv *= sign
    rr2 = (vv @ G @ np.linalg.solve(P, G) @ vv) / (vv @ G @ vv)
    print(nm, 'v*sdA (share of sum|.|):', np.round(vv * sdA3, 4), ' r2=%.6f  r=%.4f' % (rr2, np.sqrt(rr2)))
# random v test of bounds
rng2 = np.random.default_rng(3213)
V = rng2.standard_normal((200000, 3))
num = np.einsum('ij,jk,ik->i', V, G @ np.linalg.solve(P, G), V)
den = np.einsum('ij,jk,ik->i', V, G, V)
rr = num / den
print('random v (seed 3213, 2e5): r2 min %.6f max %.6f ; bounds %.6f %.6f' % (rr.min(), rr.max(), lam.min(), lam.max()))
# do the economic v3 relative to bounds: r in [sqrt(lam_min), sqrt(lam_max)]
print('r bounds: %.4f  %.4f ; r(v3)=%.4f' % (np.sqrt(lam.min()), np.sqrt(lam.max()), np.sqrt(r2)))
# with n=inf sibs: bounds from generalized eigen of (A, C)
for n_ in (0, 10, np.inf):
    Pe, Ge = info_mats([0, 1, 2], n_)
    A = Ge.T @ np.linalg.solve(Pe, Ge)
    w2 = np.sort(eigh(A, C, eigvals_only=True))[::-1]
    print('n=%s: eig(C^-1 A) = %s ; r bounds %.4f %.4f' % (n_, w2, np.sqrt(w2.min()), np.sqrt(w2.max())))
