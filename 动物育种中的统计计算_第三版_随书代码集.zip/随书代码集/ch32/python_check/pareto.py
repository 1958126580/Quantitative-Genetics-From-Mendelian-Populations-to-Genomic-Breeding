# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 pareto.py    依赖：numpy, scipy
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq
def ii(p): x=norm.isf(p); return norm.pdf(x)/p
i=ii(0.10)
# ASSUMED example parameters: milk (kg/305d), methane (g/d)
sdP=np.array([900.0,45.0]); h2=np.array([0.30,0.20])
rg=0.35; rp=0.30
sdA=sdP*np.sqrt(h2)
G=np.array([[sdA[0]**2, rg*sdA[0]*sdA[1]],[rg*sdA[0]*sdA[1], sdA[1]**2]])
P=np.array([[sdP[0]**2, rp*sdP[0]*sdP[1]],[rp*sdP[0]*sdP[1], sdP[1]**2]])
vM=0.30   # yuan per kg milk (profit)
print('sdA',sdA)
def resp(lam):
    v=np.array([vM,-lam]); b=np.linalg.solve(P,G@v); sI=np.sqrt(b@P@b)
    return i*(G@b)/sI   # dA milk, dA CH4
print('lambda   dMilk(kg)  dCH4(g/d)  profit(yuan)  profit loss%')
base=resp(0.0); pbase=vM*base[0]
for lam in (0,1,2,4,6,8,10,15,20,40,100):
    d=resp(lam); print(f'{lam:6.1f}  {d[0]:9.2f}  {d[1]:9.3f}  {vM*d[0]:10.3f}  {100*(1-vM*d[0]/pbase):7.2f}')
lam0=brentq(lambda l: resp(l)[1], 0.01, 1000)
d0=resp(lam0)
print('CH4-neutral shadow price lambda*=%.4f  dMilk=%.2f (%.1f%% of unconstrained) dCH4=%.2e'%(lam0,d0[0],100*d0[0]/base[0],d0[1]))
# marginal cost of CH4 reduction along frontier: d(profit)/d(CH4) = -lambda (envelope theorem)
for target in (-1.0,-2.0,-3.0):
    l=brentq(lambda l: resp(l)[1]-target, 0.01, 1e4)
    d=resp(l); print(f'target dCH4={target}: lambda={l:.3f}, dMilk={d[0]:.2f}, profit={vM*d[0]:.3f}')
