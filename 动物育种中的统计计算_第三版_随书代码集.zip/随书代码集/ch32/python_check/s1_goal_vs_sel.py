# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_goal_vs_sel.py    依赖：仅标准库
# §32.1.4  goal traits (ADG, FCR, BF) vs selection traits (ADG, BF only)
from common import *
I = 1.755
k = 3
# A: full info x=(ADG,FCR,BF)
bA = np.linalg.solve(P3, G3 @ v3)
sA = index_stats(bA, P3, G3, v3, G3, I)
# B: x=(ADG,BF), goal includes FCR
idx = [0, 2]
P2 = P3[np.ix_(idx, idx)]
G2 = G3[idx, :]           # Cov(x, a') 2x3
bB = np.linalg.solve(P2, G2 @ v3)
sB = index_stats(bB, P2, G2, v3, G3, I)
# C: x=(ADG,BF), goal ignores FCR (vFCR=0) -> evaluated vs TRUE H
vC = v3.copy(); vC[1] = 0.0
bC = np.linalg.solve(P2, G2 @ vC)
sC = index_stats(bC, P2, G2, v3, G3, I)   # evaluated against true v
# D: single trait ADG only
bD = np.array([1.0, 0.0])
sD = index_stats(bD, P2, G2, v3, G3, I)
def row(name, b, s, full=False):
    if full:
        bs = '%.4f | %.4f | %.4f' % tuple(b)
    else:
        bs = '%.4f | — | %.4f' % (b[0], b[1])
    return '| %s | %s | %.4f | %.4f | %+.4f | %+.5f | %+.4f |' % (name, bs, s['r'], s['dH'], s['da'][0], s['da'][1], s['da'][2])
print('sH = %.4f' % sA['sH'])
print(row('A', bA, sA, True))
print(row('B', bB, sB))
print(row('C', bC, sC))
print(row('D', bD, sD))
print('sI: A %.4f B %.4f C %.4f' % (sA['sI'], sB['sI'], sC['sI']))
print('RE of B relative to A (r_B/r_A) = %.4f ; dH loss = %.4f yuan (%.2f%%)' % (sB['r']/sA['r'], sA['dH']-sB['dH'], 100*(1-sB['dH']/sA['dH'])))
print('C vs B: RE = %.5f loss %.3f%%' % (sC['r']/sB['r'], 100*(1-sC['r']/sB['r'])))
print('D vs B: RE = %.5f' % (sD['r']/sB['r']))
# decomposition of bB by goal trait
print('decomposition of bB = sum_k v_k P2^-1 G2[:,k]')
tot = np.zeros(2)
for kk in range(3):
    part = np.linalg.solve(P2, G2[:, kk] * v3[kk])
    tot += part
    print('  from %s: ADG %.4f  BF %.4f' % (names3[kk], part[0], part[1]))
print('  total   : ADG %.4f  BF %.4f' % tuple(tot))
# FCR share of each weight
partF = np.linalg.solve(P2, G2[:, 1] * v3[1])
print('FCR share: ADG %.1f%%  BF %.1f%%' % (100*partF[0]/bB[0], 100*partF[1]/bB[1]))
# genetic regression of A_FCR on (ADG, BF) phenotypes: which part of FCR BV predicted
beta = np.linalg.solve(P2, G2[:, 1])
print('regression of A_FCR on x: ', beta, ' R2 (acc^2) of predicting A_FCR = %.4f, acc=%.4f' % (G2[:,1] @ beta / G3[1,1], np.sqrt(G2[:,1] @ beta / G3[1,1])))
# accuracy of predicting A_FCR from full information (own FCR phenotype + others)
betaA = np.linalg.solve(P3, G3[:, 1])
print('acc of A_FCR from full x: %.4f' % np.sqrt(G3[:,1] @ betaA / G3[1,1]))
# check: C index sign of FCR response
print('C FCR response %.5f vs B %.5f' % (sC['da'][1], sB['da'][1]))
# per 1000 pigs sold per year? the value of measuring FCR: difference in dH per generation per pig
print('dH A-B per pig per generation = %.4f' % (sA['dH']-sB['dH']))
