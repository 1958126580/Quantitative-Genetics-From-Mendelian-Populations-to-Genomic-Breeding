# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 pig2.py    依赖：numpy, scipy
import numpy as np
from scipy.stats import norm
np.set_printoptions(precision=5, suppress=True)
def ii(p): x=norm.isf(p); return norm.pdf(x)/p
sdP=np.array([50.0,0.18,2.2]); h2=np.array([0.30,0.25,0.45])
rg=np.array([[1,-0.55,0.15],[-0.55,1,0.30],[0.15,0.30,1]])
rp=np.array([[1,-0.35,0.10],[-0.35,1,0.20],[0.10,0.20,1]])
sdA=sdP*np.sqrt(h2); G=rg*np.outer(sdA,sdA); P=rp*np.outer(sdP,sdP)
v=np.array([0.13333333,-270.0,-27.0]); i=ii(0.10)
sH=np.sqrt(v@G@v)
print('i=%.4f sH=%.4f'%(i,sH))
def stats(idx):
    Pm=P[np.ix_(idx,idx)]; Gm=G[idx,:]
    b=np.linalg.solve(Pm,Gm@v); sI=np.sqrt(b@Pm@b)
    r=(b@Gm@v)/(sI*sH); da=i*(Gm.T@b)/sI
    return b,r,da,i*r*sH
for lab,idx in (('ADG+FCR+BF',[0,1,2]),('ADG+BF (FCR 不可测)',[0,2]),('仅 ADG',[0]),('仅 BF',[2])):
    b,r,da,dH=stats(idx)
    print(f'{lab:18s} b={np.round(b,4)} r_IH={r:.4f} dA=({da[0]:+.3f},{da[1]:+.5f},{da[2]:+.4f}) dH={dH:.3f}')
# decomposition: contributions of each goal trait to b for ADG+BF index
idx=[0,2]; Pm=P[np.ix_(idx,idx)]
for k,nm in enumerate(['ADG','FCR','BF']):
    part=np.linalg.solve(Pm,G[idx,k]*v[k]); print('  b from',nm,np.round(part,4))
# ---------- price sensitivity ----------
def RE(vuse,vtrue,idx=[0,1,2]):
    Pm=P[np.ix_(idx,idx)]; Gm=G[idx,:]
    b=np.linalg.solve(Pm,Gm@vuse); g=Gm@vtrue
    return (b@g)/np.sqrt((b@Pm@b)*(g@np.linalg.solve(Pm,g)))
print('\n---- sensitivity: one economic value wrong by factor f ----')
print('f      vADG     vFCR     vBF')
for f in (0.5,0.8,1.2,1.5,2.0,0.0,-1.0):
    row=[]
    for k in range(3):
        vw=v.copy(); vw[k]*=f; row.append(RE(vw,v))
    print(f'{f:5.2f}  '+'  '.join(f'{x:.4f}' for x in row))
# feed price shift: p_feed 3.0 -> 3.6 (+20%), 4.5 (+50%); affects vFCR only (vFCR=-90*pf)
print('\n---- feed price change (true) while index uses old price ----')
for pf in (2.4,3.6,4.5,6.0):
    vt=v.copy(); vt[1]=-90*pf
    print(f'feed price {pf:.1f}: RE={RE(v,vt):.4f}')
# ---------- desired gains (Pesek-Baker / Brascamp 1984) ----------
print('\n---- desired gains ----')
d=np.array([10.0,-0.05,0.0])      # desired proportional gains: +10 g/d, -0.05 FCR, 0 BF
Gt=G  # cov(x,a) with all 3 measured
b=np.linalg.solve(P,G)@np.linalg.solve(G.T@np.linalg.solve(P,G),d)
sI=np.sqrt(b@P@b); da=i*(G.T@b)/sI
print('b_desired',b,' realized dA',da,' ratio to d',da/d[:2].tolist()+[0] if False else '')
print('ratio dA/d for ADG,FCR:',da[0]/d[0],da[1]/d[1],' BF gain',da[2])
print('economic dH of desired-gains index:',v@da,' vs optimal', i*np.sqrt((G@v)@np.linalg.solve(P,G@v)))
