# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_biomodel.py    依赖：仅标准库
from pigmodel import *
th = dict(TH0)
mu = MU0.copy()
p = parts(mu, th)
for k in ['N', 'D', 'price', 'rev_pig', 'cvar', 'R', 'C', 'Pi', 'Q', 'margin']:
    print('%-8s %.4f' % (k, p[k]))
print('feed cost/pig %.2f  day cost/pig %.2f  nursery %.2f  sow cost per pig %.4f' % (
    th['pf'] * mu[2] * th['dW'], th['cd'] * p['D'], th['cn'], th['Cs'] / p['N']))
print('profit per pig %.4f ; profit/cost = %.4f ; profit/revenue = %.4f' % (
    p['Pi'] / p['N'], p['Pi'] / p['C'], p['Pi'] / p['R']))
va = v_analytic(mu, th)
vn = v_numeric(mu, th, 'sow')
print('v per sow-year analytic:', np.round(va, 4))
print('v per sow-year numeric :', np.round(vn, 4))
for base in ['pig', 'kg', 'cost']:
    print('v per %s numeric:' % base, v_numeric(mu, th, base))
N = p['N']
print('per-pig v_NBA analytic Cs/(N*NBA) = %.6f' % (th['Cs'] / (N * mu[0])))
pc0 = (p['C'] / p['N']) / th['Wc']
print('zero-profit pc* = %.6f yuan/kg' % pc0)
print('sdA4 =', sdA4)
