# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 geneflow.py    依赖：numpy
import numpy as np
np.set_printoptions(precision=4, suppress=True)
# ---------- population structure (ASSUMED example values) ----------
# males: M0..M5 ; females: F0..F7
M=list(range(6)); F=list(range(6,14)); q=14
iM=lambda a: a; iF=lambda a: 6+a
# cow numbers by age (per 1000 heifers entering at age 2), annual survival 0.80 from age 2 on
surv={2:1.0}
for a in range(3,8): surv[a]=surv[a-1]*0.80
ncow=np.array([surv[a] for a in range(2,8)])
dam_share=ncow/ncow.sum()                      # dams of calves by age 2..7
sire_share=np.array([0.40,0.30,0.20,0.10])     # AI sires by age 2..5
P=np.zeros((q,q))
for newborn in (iM(0),iF(0)):
    for k,a in enumerate(range(2,6)): P[newborn,iM(a)]+=0.5*sire_share[k]
    for k,a in enumerate(range(2,8)): P[newborn,iF(a)]+=0.5*dam_share[k]
for a in range(0,5): P[iM(a+1),iM(a)]=1.0
for a in range(0,7): P[iF(a+1),iF(a)]=1.0
print('row sums newborn:',P[iM(0)].sum(),P[iF(0)].sum())
print('dam_share',np.round(dam_share,4),' mean dam age',round((np.arange(2,8)*dam_share).sum(),3))
print('sire mean age',(np.arange(2,6)*sire_share).sum())
L=0.5*(np.arange(2,8)*dam_share).sum()+0.5*(np.arange(2,6)*sire_share).sum()
print('generation interval L=',round(L,4))
ev=np.max(np.abs(np.linalg.eigvals(P))); print('spectral radius',round(ev,6))
# ---------- expression vectors (per 1000 heifers/year entering; calves N = sum cows) ----------
Ncalves=ncow.sum()
qv={}
e=np.zeros(q); e[iM(0)]=Ncalves/2; e[iF(0)]=Ncalves/2; qv['犊牛成活率（出生时表达）']=e
e=np.zeros(q); e[iM(1)]=Ncalves/2*0.95; qv['肉用公犊胴体重（1 岁屠宰）']=e
e=np.zeros(q)
for a in range(2,8): e[iF(a)]=surv[a]
qv['产奶量（每胎表达）']=e
e=np.zeros(q); e[iF(2)]=1.0; qv['初产难易度（仅头胎表达）']=e
e=np.zeros(q)
for a in range(2,8):
    leave = surv[a]-(surv[a+1] if a+1<8 else 0.0)
    e[iF(a)]=leave
qv['生产寿命（淘汰时表达一次）']=e
def cde(qvec, j, r, T=None):
    Pd=P/(1+r)
    if T is None:
        S=np.linalg.inv(np.eye(q)-Pd)
        return float(qvec@S[:,j])
    acc=np.zeros(q); M_t=np.zeros(q); M_t[j]=1.0; tot=0.0
    for t in range(T+1):
        tot+=qvec@M_t/(1+r)**t
        M_t=P@M_t
    return float(tot)
j=iM(0)   # a unit of superiority in selected young bulls (newborn male cohort)
print()
res={}
for name,qvec in qv.items():
    row=[cde(qvec,j,0.05,25), cde(qvec,j,0.05,None), cde(qvec,j,0.03,25), cde(qvec,j,0.08,25), cde(qvec,j,0.0,25)]
    res[name]=row
ref=res['产奶量（每胎表达）']
print('%-22s %10s %10s %10s %10s %10s'%('trait','r5T25','r5Tinf','r3T25','r8T25','r0T25'))
for name,row in res.items():
    print('%-20s'%name, ' '.join('%10.4f'%x for x in row))
print()
print('relative to milk (per unit expression normalized by expressions/yr):')
for name,row in res.items():
    print('%-20s'%name, ' '.join('%8.4f'%(row[k]/ref[k]) for k in range(5)))
# first expression timing: year of first non-zero expression
print()
for name,qvec in qv.items():
    M_t=np.zeros(q); M_t[j]=1.0
    for t in range(40):
        if qvec@M_t>1e-12: print(name,'first expression year',t); break
        M_t=P@M_t

print('\n================ descendants only (exclude the selected cohort itself) ================')
A=P.copy(); A[iM(0),:]=0; A[iF(0),:]=0      # aging-only part
def cde_desc(qvec, j, r, T=None, Tinf=400):
    TT = Tinf if T is None else T
    tot=0.0; Pt=np.zeros(q); Pt[j]=1.0; At=np.zeros(q); At[j]=1.0
    for t in range(TT+1):
        tot+=qvec@(Pt-At)/(1+r)**t
        Pt=P@Pt; At=A@At
    return float(tot)
for j,lab in ((iM(0),'selected young bulls (M0)'),(iF(0),'selected heifers (F0)')):
    print('\ninjection:',lab)
    res={}
    for name,qvec in qv.items():
        res[name]=[cde_desc(qvec,j,0.05,25),cde_desc(qvec,j,0.05,None),cde_desc(qvec,j,0.03,25),cde_desc(qvec,j,0.08,25),cde_desc(qvec,j,0.0,25)]
    ref=res['产奶量（每胎表达）']
    print('%-20s %9s %9s %9s %9s %9s'%('trait','r5T25','r5Tinf','r3T25','r8T25','r0T25'))
    for name,row in res.items(): print('%-20s'%name,' '.join('%9.4f'%x for x in row))
    print('relative to milk:')
    for name,row in res.items(): print('%-20s'%name,' '.join('%9.4f'%(row[k]/ref[k]) for k in range(5)))
    for name,qvec in qv.items():
        Pt=np.zeros(q); Pt[j]=1.0; At=Pt.copy()
        for t in range(40):
            if qvec@(Pt-At)>1e-12: print('  first expr',name,t); break
            Pt=P@Pt; At=A@At
