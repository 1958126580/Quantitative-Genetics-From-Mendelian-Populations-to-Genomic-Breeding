# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_timescale.py    依赖：仅标准库
# §32.1.5 price forecast error over the horizon: v_T = v0 * exp(sigma*sqrt(T)*Z) (independent per trait)
from common import *
idx = [0, 2]
P2 = P3[np.ix_(idx, idx)]
G2 = G3[idx, :]
b0 = np.linalg.solve(P2, G2 @ v3)          # index B built with today's prices
M = G2.T @ np.linalg.solve(P2, G2)          # k x k
def RE_vec(b, V):
    # V: n x k matrix of true v's
    num = (b @ G2) @ V.T                    # n
    den = np.sqrt(b @ P2 @ b) * np.sqrt(np.einsum('ij,jk,ik->i', V, M, V))
    return num / den
rng = np.random.default_rng(20260924)
n = 400000
print('| T | sigma | mean rho | 5% q | 1% q | P(rho<0.95) | P(rho<0.99) |')
res = {}
for sig in [0.05, 0.10, 0.20]:
    for T in [5, 10, 15, 20]:
        Z = rng.standard_normal((n, 3))
        V = v3 * np.exp(sig * np.sqrt(T) * Z)
        r = RE_vec(b0, V)
        res[(sig, T)] = r
        print('| %d | %.2f | %.4f | %.4f | %.4f | %.4f | %.4f |' % (T, sig, r.mean(), np.quantile(r, 0.05), np.quantile(r, 0.01), (r < 0.95).mean(), (r < 0.99).mean()))
# log-sd of price ratio at horizon
for sig in [0.05, 0.10, 0.20]:
    for T in [5, 10, 20]:
        s = sig*np.sqrt(T)
        print('sig %.2f T %d: sd(log)=%.4f  90%% interval of price ratio [%.3f, %.3f]' % (sig, T, s, np.exp(-1.6449*s), np.exp(1.6449*s)))
# deterministic trend: feed price +3%/yr relative to others
for T in [5, 10, 15, 20]:
    vT = v3.copy(); vT[1] = v3[1] * 1.03**T
    print('trend feed +3%%/yr T=%d: vFCR=%.2f  RE=%.5f' % (T, vT[1], RE_vec(b0, vT[None, :])[0]))
# trend  +5%/yr
for T in [10, 20]:
    vT = v3.copy(); vT[1] = v3[1] * 1.05**T
    print('trend feed +5%%/yr T=%d: vFCR=%.2f  RE=%.5f' % (T, vT[1], RE_vec(b0, vT[None, :])[0]))
