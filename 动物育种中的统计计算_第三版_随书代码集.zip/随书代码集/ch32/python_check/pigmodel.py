# -*- coding: utf-8 -*-
"""Farrow-to-finish pig bio-economic model (ALL parameters are assumed example values)."""
import numpy as np
TH0 = dict(
    LS=2.2,      # litters per sow per year
    s=0.85,      # survival born-alive -> slaughter
    dW=75.0,     # kg live-weight gain in finishing (25 -> 100 kg)
    Wc=75.0,     # kg carcass per pig
    pc=16.0,     # yuan / kg carcass (base price at BF0)
    pL=0.12,     # yuan / kg carcass per mm backfat (grid slope)
    BF0=12.0,    # reference backfat (mm) = current mean
    pf=2.4,      # yuan / kg finishing feed
    cd=2.56,     # yuan / pig / day in finishing (housing, labour, interest)
    cn=150.0,    # yuan / pig: nursery & other per-pig costs (excl. sow)
    Cs=5000.0,   # yuan / sow / year (sow feed, housing, AI, replacement, labour)
)
MU0 = np.array([12.0, 800.0, 2.7, 12.0])   # NBA (piglets), ADG (g/d), FCR, BF (mm)
TR = ['NBA', 'ADG', 'FCR', 'BF']


def parts(mu, th):
    NBA, ADG, FCR, BF = mu
    N = th['LS'] * NBA * th['s']                      # pigs sold / sow / year
    D = 1000.0 * th['dW'] / ADG                       # days in finishing
    price = th['pc'] - th['pL'] * (BF - th['BF0'])    # yuan / kg carcass
    rev_pig = th['Wc'] * price
    cvar = th['pf'] * FCR * th['dW'] + th['cd'] * D + th['cn']
    R = N * rev_pig
    C = N * cvar + th['Cs']
    return dict(N=N, D=D, price=price, rev_pig=rev_pig, cvar=cvar, R=R, C=C, Pi=R - C,
                Q=N * th['Wc'], margin=rev_pig - cvar)


def profit(mu, th, base='sow'):
    p = parts(mu, th)
    if base == 'sow':
        return p['Pi']                 # per sow per year
    if base == 'kg':
        return p['Pi'] / p['Q']        # per kg carcass
    if base == 'pig':
        return p['Pi'] / p['N']        # per pig sold
    if base == 'cost':
        return p['Pi'] / p['C']        # per yuan of cost
    raise ValueError(base)


def v_analytic(mu, th):
    NBA, ADG, FCR, BF = mu
    p = parts(mu, th)
    N = p['N']
    vN = th['LS'] * th['s'] * p['margin']
    vA = N * th['cd'] * 1000.0 * th['dW'] / ADG**2
    vF = -N * th['pf'] * th['dW']
    vB = -N * th['Wc'] * th['pL']
    return np.array([vN, vA, vF, vB])


def v_numeric(mu, th, base='sow', h=None):
    h = h if h is not None else np.array([1e-4, 1e-3, 1e-6, 1e-5])
    out = np.zeros(4)
    for k in range(4):
        e = np.zeros(4)
        e[k] = h[k]
        out[k] = (profit(mu + e, th, base) - profit(mu - e, th, base)) / (2 * h[k])
    return out


# genetic parameters (assumed): NBA added to the ch10 (ADG, FCR, BF) set
sdP4 = np.array([3.0, 50.0, 0.18, 2.2])
h2_4 = np.array([0.10, 0.30, 0.25, 0.45])
rg4 = np.array([[1.00, -0.05, 0.05, 0.10],
                [-0.05, 1.00, -0.55, 0.15],
                [0.05, -0.55, 1.00, 0.30],
                [0.10, 0.15, 0.30, 1.00]])
rp4 = np.array([[1.00, 0.00, 0.00, 0.00],
                [0.00, 1.00, -0.35, 0.10],
                [0.00, -0.35, 1.00, 0.20],
                [0.00, 0.10, 0.20, 1.00]])
sdA4 = sdP4 * np.sqrt(h2_4)
G4 = rg4 * np.outer(sdA4, sdA4)
P4own = rp4 * np.outer(sdP4, sdP4)


def index_mats(n_dam=2, rep=0.15):
    """x = (dam's mean NBA over n_dam litters, own ADG, own FCR, own BF).
    Returns P (Var x), G (Cov(x, a'))."""
    P = np.zeros((4, 4))
    G = np.zeros((4, 4))
    P[0, 0] = sdP4[0]**2 * (1 + (n_dam - 1) * rep) / n_dam
    for k in range(1, 4):
        P[0, k] = P[k, 0] = 0.5 * G4[0, k]           # dam-offspring cross covariance
    P[1:, 1:] = P4own[1:, 1:]
    G[0, :] = 0.5 * G4[0, :]                         # Cov(dam NBA record, candidate BV)
    G[1:, :] = G4[1:, :]
    return P, G
