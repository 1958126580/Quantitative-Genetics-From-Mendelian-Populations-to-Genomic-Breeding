# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 pig.py    依赖：numpy, scipy
import numpy as np
from scipy.stats import norm
np.set_printoptions(precision=5, suppress=True)
def ii(p): x=norm.isf(p); return norm.pdf(x)/p
# genetic parameters (same as ch10 §10.2.7 case 2): ADG (g/d), FCR (kg/kg), BF (mm)
sdP=np.array([50.0,0.18,2.2]); h2=np.array([0.30,0.25,0.45])
rg=np.array([[1,-0.55,0.15],[-0.55,1,0.30],[0.15,0.30,1]])
rp=np.array([[1,-0.35,0.10],[-0.35,1,0.20],[0.10,0.20,1]])
sdA=sdP*np.sqrt(h2); G=rg*np.outer(sdA,sdA); P=rp*np.outer(sdP,sdP)
print('sdA',sdA)
# ---------------- bio-economic model (ASSUMED example prices) ----------------
W0,W1=30.0,120.0; dW=W1-W0          # kg live weight in / out
dress=0.75; CW=W1*dress             # carcass kg
p_meat=20.0                          # yuan / kg carcass (base)
prem=0.30                            # yuan/kg carcass lost per mm backfat above base
p_feed=3.0                           # yuan / kg feed
c_day=1.20                           # yuan / pig / day (housing, labour, capital)
c0=450.0                             # piglet + fixed per pig
ADG0,FCR0,BF0=900.0,2.60,12.0
def profit_pig(ADG,FCR,BF,pm=p_meat,pf=p_feed,cd=c_day):
    D=dW*1000/ADG
    R=CW*(pm-prem*(BF-BF0))
    F=FCR*dW*pf
    return R-F-cd*D-c0, R, F, D
Pi,R,F,D=profit_pig(ADG0,FCR0,BF0)
print('base: days %.2f revenue %.2f feed %.2f housing %.2f profit/pig %.2f'%(D,R,F,c_day*D,Pi))
def grad(fun,x,h=np.array([1e-3,1e-6,1e-4])):
    g=np.zeros(3)
    for k in range(3):
        e=np.zeros(3); e[k]=h[k]
        g[k]=(fun(*(x+e))-fun(*(x-e)))/(2*h[k])
    return g
x0=np.array([ADG0,FCR0,BF0])
v_pig=grad(lambda a,f,b: profit_pig(a,f,b)[0], x0)
print('v per pig (yuan per unit):',v_pig)
print('analytic: vADG=c_d*dW*1000/ADG^2 =',c_day*dW*1000/ADG0**2,' vFCR=-dW*pf =',-dW*p_feed,' vBF=-prem*CW =',-prem*CW)
# per pig-place-year basis: facility is the limiting input
def profit_place(ADG,FCR,BF,pm=p_meat,pf=p_feed,cd=c_day):
    D=dW*1000/ADG
    R=CW*(pm-prem*(BF-BF0)); F=FCR*dW*pf
    return 365.0/D*(R-F-c0) - 365.0*cd
v_place=grad(profit_place,x0)
print('profit per place-year %.2f'%profit_place(*x0))
print('v per place-year:',v_place)
# per kg carcass basis
v_kg=grad(lambda a,f,b: profit_pig(a,f,b)[0]/CW, x0)
print('v per kg carcass:',v_kg)
def rel(v): return v/np.abs(v[1])
print('relative (|vFCR|=1): pig',rel(v_pig),' place',rel(v_place),' kg',rel(v_kg))
# standardized economic value per genetic SD
print('value per sdA: pig',v_pig*sdA,' place',v_place*sdA*D/365)
# ---- Brascamp theorem check: set meat price so that profit = 0 ----
from scipy.optimize import brentq
pm0=brentq(lambda pm: profit_pig(ADG0,FCR0,BF0,pm=pm)[0], 1, 60)
print('\nzero-profit meat price %.4f'%pm0)
vp0=grad(lambda a,f,b: profit_pig(a,f,b,pm=pm0)[0], x0)
vq0=grad(lambda a,f,b: profit_place(a,f,b,pm=pm0), x0)
print('zero profit: v pig',vp0,' v place*D/365',vq0*D/365)
print('ratio place/pig at zero profit:',vq0/vp0,' D/365=',365/D)
print('relative pig',rel(vp0),' place',rel(vq0))
# index consequences
i=ii(0.10)
def index(v):
    b=np.linalg.solve(P,G@v); sI=np.sqrt(b@P@b); da=i*G@b/sI
    return b,da
for lab,v in (('per pig',v_pig),('per place',v_place)):
    b,da=index(v); print(lab,'b',b,' response dA',da)
def RE(vuse,vtrue):
    b=np.linalg.solve(P,G@vuse); g=G@vtrue
    return (b@g)/np.sqrt((b@P@b)*(g@np.linalg.solve(P,g)))
print('RE of per-pig index when truth is per-place: %.4f'%RE(v_pig,v_place))
print('RE of per-place index when truth is per-pig: %.4f'%RE(v_place,v_pig))
