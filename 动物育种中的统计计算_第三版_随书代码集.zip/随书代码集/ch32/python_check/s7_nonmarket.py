# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s7_nonmarket.py    依赖：numpy
# §32.3.4 three ways to include a non-market value (methane): shadow price / constraint / desired gains
import numpy as np
from dairy import *

print('sdA =', sdA, ' G=\n', G, '\nP=\n', P)
vmkt = np.array([vM, 0.0])
rows = []


def report(name, b, extra=''):
    da, sI = resp(b)
    # implied economic values: b = P^-1 G v*  ->  v* = G^-1 P b ; scale so v*_M = vM
    vstar = np.linalg.solve(G, P @ b)
    vstar = vstar * (vM / vstar[0])
    Cimp = C_from_v(vstar[1])
    mk = vM * da[0]
    rows.append((name, b / b[0], da, mk, Cimp, extra))
    return da, mk, Cimp


# 1 market only
b1 = hazel(vmkt)
da1, mk1, _ = report('market', b1)
# 2,3 shadow prices
for C in [100.0, 600.0]:
    b = hazel(np.array([vM, vch4(C)]))
    report('shadow C=%d' % C, b, 'v_CH4=%.2f' % vch4(C))
# 4 restricted index (32.18) with C = e2
Cm = np.array([[0.0], [1.0]])
Pinv = np.linalg.inv(P)
A = Cm.T @ G @ Pinv @ G @ Cm
bR = (np.eye(2) - Pinv @ G @ Cm @ np.linalg.solve(A, Cm.T @ G)) @ Pinv @ G @ vmkt
lam = np.linalg.solve(A, Cm.T @ G @ Pinv @ G @ vmkt)
vimp = vmkt - (Cm @ lam).ravel()
print('lambda =', lam, ' implied v* =', vimp, ' implied C* = %.4f' % C_from_v(vimp[1]))
print('check bR prop hazel(v*):', bR / hazel(vimp))
report('restricted dCH4=0', bR)
# 5 desired gains  b = G^-1 d
for d in [np.array([sdA[0], -0.10 * sdA[1]]), np.array([sdA[0], -0.25 * sdA[1]]), np.array([sdA[0], -0.5 * sdA[1]]),
          np.array([sdA[0], -1.0 * sdA[1]])]:
    b = np.linalg.solve(G, d)
    da, mk, Cimp = report('desired d=(%.1f,%.3f)' % (d[0], d[1]), b)
    print('desired d ratio CH4/M (sdA units) %.2f -> achieved scale %.4f of d per generation' % (d[1] / sdA[1] / (d[0] / sdA[0]), da[0] / d[0]))

print('\n| method | b_M:b_CH4 | dM | dCH4 | market gain | loss vs market | implied C |')
for name, bn, da, mk, Cimp, extra in rows:
    print('| %s | 1 : %.4f | %+.2f | %+.4f | %.2f | %.2f%% | %.1f | %s' % (
        name, bn[1], da[0], da[1], mk, 100 * (1 - mk / mk1), Cimp, extra))
# carbon value of methane change and total "social" value at C=600 for each method
print('\nsocial value at C=600 (vM dM + vch4 dCH4):')
for name, bn, da, mk, Cimp, extra in rows:
    print('%-25s %.2f' % (name, vM * da[0] + vch4(600) * da[1]))
print('\nper-cow annual CH4 reduction worth at C=600: %.4f yuan/kg' % (-vch4(600)))
