# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_variance_info.py    依赖：仅标准库
# §32.1.4 : Var(H) and genetic correlation; r_IH vs amount of information; identities; canonical bounds
from common import *
np.set_printoptions(precision=6, suppress=True, linewidth=140)
I = I10
v = v3
C = G3
# ---------- (A) decomposition of Var(H)
terms = (v * sdA3) ** 2
cov_terms = {}
for (a, b) in [(0, 1), (0, 2), (1, 2)]:
    cov_terms[(a, b)] = 2 * v[a] * v[b] * C[a, b]
sH2 = v @ C @ v
print('sigma_H^2 = %.4f  sigma_H = %.4f' % (sH2, np.sqrt(sH2)))
print('diag terms', terms, 'sum %.4f' % terms.sum())
print('cov terms', {k: round(x, 4) for k, x in cov_terms.items()}, 'sum %.4f' % sum(cov_terms.values()))
print('check sum = sH2: %.6f' % (terms.sum() + sum(cov_terms.values())))
print('sigma_H if all r_g=0: %.4f ; ratio %.4f' % (np.sqrt(terms.sum()), np.sqrt(sH2 / terms.sum())))
print('v*sdA (per genetic SD):', v * sdA3)
print('genetic cov G3:\n', C)
# ---------- (B) scale genetic correlations by kappa, E fixed
print('\n--- kappa scan (E fixed = P3-G3) ---')
print('kappa  rg(12,13,23)  sigma_H  covshare  r_IH  dH  dA(ADG,FCR,BF)  eigminP eigminG')
rows_kappa = []
for kap in (-1.0, -0.5, 0.0, 0.5, 1.0):
    rg = np.eye(3) + kap * (rg3 - np.eye(3))
    G = rg * np.outer(sdA3, sdA3)
    P = G + E3
    ev_G = np.linalg.eigvalsh(G).min(); ev_P = np.linalg.eigvalsh(P).min()
    b, g = hazel(P, G, v)
    s = stats(b, P, G, G, v, I)
    covshare = (s['sH'] ** 2 - terms.sum()) / s['sH'] ** 2
    rows_kappa.append((kap, rg[0, 1], rg[0, 2], rg[1, 2], s['sH'], covshare, s['r'], s['dH'], s['da']))
    print('%5.1f  (%.3f,%.3f,%.3f)  %.4f  %.4f  %.4f  %.3f  %s  %.5f %.5f' % (kap, rg[0, 1], rg[0, 2], rg[1, 2], s['sH'], covshare, s['r'], s['dH'], np.round(s['da'], 4), ev_P, ev_G))
    # phenotypic correlations implied
    sd = np.sqrt(np.diag(P)); print('     implied r_p', np.round((P / np.outer(sd, sd))[np.triu_indices(3, 1)], 4))
