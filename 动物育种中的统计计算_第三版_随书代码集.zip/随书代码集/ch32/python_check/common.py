# -*- coding: utf-8 -*-
"""Shared definitions for ch32 expansion (ch32e). ALL economic / genetic parameters are ILLUSTRATIVE values.
Pig three-trait set is the chapter's own (ch10 §10.2.7 case 2 + ch32 §32.1.3)."""
import os
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np
from scipy.stats import norm

np.set_printoptions(precision=6, suppress=True, linewidth=140)


def trunc_i(p):
    """selection intensity, truncation at upper proportion p, infinite population"""
    x = norm.isf(p)
    return norm.pdf(x) / p

# ---- chapter pig traits: ADG (g/d), FCR, BF (mm) ----
names3 = ['ADG', 'FCR', 'BF']
sdP3 = np.array([50.0, 0.18, 2.2])
h2_3 = np.array([0.30, 0.25, 0.45])
rg3 = np.array([[1, -0.55, 0.15], [-0.55, 1, 0.30], [0.15, 0.30, 1]])
rp3 = np.array([[1, -0.35, 0.10], [-0.35, 1, 0.20], [0.10, 0.20, 1]])
sdA3 = sdP3 * np.sqrt(h2_3)
G3 = rg3 * np.outer(sdA3, sdA3)
P3 = rp3 * np.outer(sdP3, sdP3)
E3 = P3 - G3          # implied residual covariance
# economic values per pig (ch32 eq 32.9b)
v3 = np.array([1.2 * 1000 * 90 / 900.0**2, -270.0, -27.0])
I10 = 1.755   # chapter value (exact 1.754983)


def hazel(P, G, v):
    """b = P^-1 G v ; returns b and g=Gv"""
    g = G @ v
    return np.linalg.solve(P, g), g


def stats(b, P, G, C, v, i=I10):
    """b: weights (p); P=Var(x) pxp; G=Cov(x,a') pxk; C=Var(a) kxk; v goal weights"""
    sI = np.sqrt(b @ P @ b)
    sH = np.sqrt(v @ C @ v)
    covIH = b @ G @ v
    r = covIH / (sI * sH)
    da = i / sI * (G.T @ b)
    dH = i * r * sH
    return dict(sI=sI, sH=sH, cov=covIH, r=r, da=da, dH=dH, varI=sI**2)
