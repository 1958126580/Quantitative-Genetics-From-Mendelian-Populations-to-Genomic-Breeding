# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s6_nonlinear.py    依赖：numpy, scipy
# §32.2.9 nonlinear profit functions: economic value depends on the population mean
import numpy as np
from scipy.stats import norm
from pigmodel import TH0

th = dict(TH0)
# (a) curvature from D = 1000 dW / ADG
print('(a) v_ADG per pig vs mean ADG')
for mu in [700, 750, 800, 850, 900, 1000]:
    v = th['cd'] * 1000 * th['dW'] / mu**2
    D = 1000 * th['dW'] / mu
    print('| %d | %.2f | %.4f | %.4f |' % (mu, D, v, v / 0.30))
true_gain = th['cd'] * 1000 * th['dW'] * (1 / 800 - 1 / 900)
print('800->900: exact saving %.4f  linear %.4f  over-estimate %.2f%%' % (true_gain, 0.30 * 100, 100 * (0.30 * 100 / true_gain - 1)))
print('v(900)/v(800) = %.4f  drop %.2f%%' % ((800 / 900)**2, 100 * (1 - (800 / 900)**2)))
# mid-point rule
vmid = th['cd'] * 1000 * th['dW'] / 850**2
print('v at midpoint 850 = %.4f ; x100 = %.4f ; exact %.4f' % (vmid, vmid * 100, true_gain))

# (b) carcass grading grid on backfat
thr = np.array([12.0, 15.0, 18.0, 21.0])
adj = np.array([0.40, 0.20, 0.00, -0.40, -1.00])      # yuan/kg carcass for classes (-inf,12],(12,15],(15,18],(18,21],(21,inf)
Wc = th['Wc']


def E_adj(mu, s):
    cuts = np.concatenate([[-np.inf], thr, [np.inf]])
    pr = norm.cdf((cuts[1:] - mu) / s) - norm.cdf((cuts[:-1] - mu) / s)
    return (adj * pr).sum(), pr


def v_grid(mu, s):
    dadj = np.diff(adj)                                   # change when crossing threshold upward
    return (dadj * norm.pdf((thr - mu) / s) / s).sum()    # d E / d mu  (yuan/kg per mm)


s = 2.2
print('\n(b) grid, sigma=%.1f' % s)
print('| mu | P(<=12) | P(12-15] | P(15-18] | P(18-21] | P(>21) | E adj (yuan/kg) | E per pig | v per pig (yuan/mm) |')
for mu in [10, 12, 14, 16, 18, 20, 22]:
    e, pr = E_adj(mu, s)
    v = v_grid(mu, s)
    # numeric check
    h = 1e-5
    vn = (E_adj(mu + h, s)[0] - E_adj(mu - h, s)[0]) / (2 * h)
    assert abs(v - vn) < 1e-7
    print('| %d | %s | %.4f | %.2f | %.4f |' % (mu, ' | '.join('%.3f' % x for x in pr), e, e * Wc, v * Wc))
# where is |v| maximal
grid = np.linspace(8, 24, 16001)
vv = np.array([v_grid(m, s) for m in grid]) * Wc
k = np.argmin(vv)
print('most negative v at mu=%.3f : %.4f' % (grid[k], vv[k]))
# linear approximation over 5 generations: mu 18 -> 12 (dBF = -1.2/gen)
e18 = E_adj(18, s)[0] * Wc
e12 = E_adj(12, s)[0] * Wc
v18 = v_grid(18, s) * Wc
print('from 18 to 12: exact gain %.4f  linear (v18*-6) %.4f  ratio %.4f' % (e12 - e18, v18 * -6, (v18 * -6) / (e12 - e18)))
e16 = E_adj(16, s)[0] * Wc
v16 = v_grid(16, s) * Wc
print('from 16 to 10: exact gain %.4f linear %.4f' % (E_adj(10, s)[0] * Wc - e16, v16 * -6))
# value of uniformity at mu=16: sigma 2.2 vs 1.8
for mu in [12, 16, 18]:
    a = E_adj(mu, 2.2)[0] * Wc
    b = E_adj(mu, 1.8)[0] * Wc
    print('mu=%d: E per pig sigma2.2 %.4f sigma1.8 %.4f diff %.4f' % (mu, a, b, b - a))
