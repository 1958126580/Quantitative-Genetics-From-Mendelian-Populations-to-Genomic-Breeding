# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s8_pareto.py    依赖：numpy
# §32.3.5 Pareto frontier: market genetic gain vs methane change (per generation)
import numpy as np
from dairy import *

M = G @ np.linalg.solve(P, G)          # response ellipse: da' M^-1 da = I^2
Minv = np.linalg.inv(M)
print('M =\n', M)
# endpoints
for name, w in [('max milk', np.array([1.0, 0.0])), ('min CH4', np.array([0.0, -1.0]))]:
    da, _ = resp(hazel(w))
    print('%s: dM=%.4f dCH4=%.4f' % (name, da[0], da[1]))
# C* for dCH4 = 0
Cstar = C_from_v(-M[1, 0] / M[1, 1] * vM)
print('C* (dCH4=0) = %.4f' % Cstar)
Cs = [0, 100, 300, 600, 1000, Cstar, 2000, 3000, 5000, 10000, 20000]
pts = []
for C in Cs:
    v = np.array([vM, vch4(C)])
    da, _ = resp(hazel(v))
    pts.append((C, da[0], da[1], vM * da[0]))
pts.append((np.inf, *resp(hazel(np.array([0.0, -1.0])))[0], 0))
pts[-1] = (np.inf, pts[-1][1], pts[-1][2], vM * pts[-1][1])
dmax = pts[0][3]
print('\n| C | v_CH4 | dM | dCH4 | market gain | loss% | slope (yuan per kg CH4) |')
prev = None
for C, dM, dC, mk in pts:
    slope = ''
    if prev is not None and np.isfinite(C) and np.isfinite(prev[0]):
        slope = '%.3f' % (-(mk - prev[3]) / (dC - prev[2]))
    vv = vch4(C) if np.isfinite(C) else -np.inf
    print('| %s | %s | %+.2f | %+.4f | %.2f | %.2f%% | %s |' % (
        ('%.1f' % C) if np.isfinite(C) else 'inf', ('%.2f' % vv) if np.isfinite(C) else '-inf', dM, dC, mk, 100 * (1 - mk / dmax), slope))
    prev = (C, dM, dC, mk)
# exact local slope along frontier equals -v_CH4 : check by tiny perturbation around C=600
for C in [100.0, 600.0, 2000.0]:
    h = 1e-3
    a = resp(hazel(np.array([vM, vch4(C - h)])))[0]
    b = resp(hazel(np.array([vM, vch4(C + h)])))[0]
    slope = -(vM * (b[0] - a[0])) / (b[1] - a[1])
    print('C=%.0f local slope %.6f  vs -v_CH4 = %.6f' % (C, slope, -vch4(C)))
# epsilon-constraint: for target dCH4 = eps, max dM on the ellipse
print('\n epsilon constraint')
for eps in [4.0, 2.0, 0.0, -2.0, -4.0]:
    # ellipse: [dM, eps] Minv [dM, eps]' = I^2  -> quadratic in dM
    a = Minv[0, 0]
    bq = 2 * Minv[0, 1] * eps
    c = Minv[1, 1] * eps**2 - I**2
    dM = (-bq + np.sqrt(bq**2 - 4 * a * c)) / (2 * a)
    # implied weights: normal vector Minv da
    nrm = Minv @ np.array([dM, eps])
    vimp2 = nrm[1] / nrm[0] * vM
    print('eps=%+.1f : max dM=%.4f market=%.2f  implied v_CH4=%.4f  implied C=%.2f' % (eps, dM, vM * dM, vimp2, C_from_v(vimp2)))
