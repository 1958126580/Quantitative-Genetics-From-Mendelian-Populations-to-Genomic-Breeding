# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4_bases.py    依赖：仅标准库
# §32.2.7 three profit bases: per sow-year, per kg carcass, per yuan cost
from pigmodel import *
th = dict(TH0)
mu = MU0.copy()


def table(th, label):
    p = parts(mu, th)
    print('==== %s: pc=%.4f  Pi/sow=%.4f  Pi/C=%.6f' % (label, th['pc'], p['Pi'], p['Pi'] / p['C']))
    res = {}
    for base in ['sow', 'kg', 'cost']:
        v = v_numeric(mu, th, base)
        vs = v * sdA4 * np.array([1, 1, -1, -1])      # favourable direction: +NBA,+ADG,-FCR,-BF
        rel = vs / vs[2]                              # relative to FCR
        res[base] = (v, vs, rel)
        print('base %-4s v =' % base, ' '.join('%.6g' % x for x in v))
        print('          v*sdA(fav) =', ' '.join('%.6g' % x for x in vs))
        print('          rel to FCR =', ' '.join('%.4f' % x for x in rel))
    return res


r1 = table(th, 'actual')
p = parts(mu, th)
pc0 = (p['C'] / p['N']) / th['Wc']
th0 = dict(th)
th0['pc'] = pc0
r0 = table(th0, 'zero profit')
# ratio of NBA relative weight per-sow vs per-kg equals 1 + Pi/Cs
print('ratio NBA rel (sow/kg) = %.6f ; 1+Pi/Cs = %.6f' % (r1['sow'][2][0] / r1['kg'][2][0], 1 + p['Pi'] / th['Cs']))
# per-cost basis details: analytic
C = p['C']
Pi = p['Pi']
va = v_analytic(mu, th)
dC = np.array([th['LS'] * th['s'] * p['cvar'], -va[1], -p['N'] * th['pf'] * th['dW'], 0.0])
vcost = (va * C - Pi * dC) / C**2
print('analytic per-cost v:', vcost)
# markdown rows
print()
print('| trait | sdA | sow v | sow rel | kg v | kg rel | cost v(x1e4) | cost rel | zero-profit rel |')
for k in range(4):
    print('| %s | %.4f | %.4f | %.4f | %.6f | %.4f | %.6f | %.4f | %.4f |' % (
        TR[k], sdA4[k], r1['sow'][0][k], r1['sow'][2][k], r1['kg'][0][k], r1['kg'][2][k],
        1e4 * r1['cost'][0][k], r1['cost'][2][k], r0['sow'][2][k]))
# check zero-profit: all bases equal
for base in ['kg', 'cost']:
    print('zero-profit max abs diff rel (%s vs sow) = %.3e' % (base, np.max(np.abs(r0[base][2] - r0['sow'][2]))))
# share of NBA in total sd-weighted value (sum of |v sdA|)
for base in ['sow', 'kg', 'cost']:
    vs = r1[base][1]
    print('NBA share of sum |v sdA| (%s) = %.4f' % (base, vs[0] / vs.sum()))
vs0 = r0['sow'][1]
print('NBA share zero-profit = %.4f' % (vs0[0] / vs0.sum()))
