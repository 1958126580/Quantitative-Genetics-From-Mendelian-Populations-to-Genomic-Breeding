# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 32 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5_geneflow.py    依赖：numpy
# §32.2.8 discounted gene flow: full computation
import numpy as np
from geneflow import *
from pigmodel import *

np.set_printoptions(precision=4, suppress=True)
P, Q, info = pig_structure()
print('pig info:', {k: (np.round(v, 4) if isinstance(v, np.ndarray) else round(v, 4)) for k, v in info.items()})
print('P =\n', P)
print('row sums', P.sum(1))
ev = np.linalg.eigvals(P)
print('eigenvalues', np.round(ev, 4), ' spectral radius %.6f' % np.max(np.abs(ev)))
# stationary distribution (left eigenvector)
w, V = np.linalg.eig(P.T)
k = np.argmin(np.abs(w - 1))
pi = np.real(V[:, k])
pi = pi / pi.sum()
print('stationary pi =', np.round(pi, 4))
# generation interval check: L = mean age of parents
f = info['f']
Ls = 1.0
Ld = (f * np.array([1, 2, 3])).sum()
print('Ls=%.4f Ld=%.4f  L=%.4f' % (Ls, Ld, (Ls + Ld) / 2))
# expression path first years
print('\nexpression paths (per unit in N at t=0), years 0..8:')
for tr in ['carcass', 'direct', 'NBA', 'maternal', 'longevity', 'boar']:
    E = expr_path(P, Q[tr], 8)
    print('%-10s' % tr, ' '.join('%.4f' % (x / Q[tr].sum()) for x in E))
m = np.zeros(5); m[0] = 1
print('\nm_t (class means) t=0..6:')
for t in range(7):
    print(t, np.round(m, 4))
    m = P @ m
print('limit of m_t ->', np.round(np.linalg.matrix_power(P, 400) @ np.eye(5)[0], 6))

# kappa = CDE / annual expressions
rates = [0.0, 0.03, 0.05, 0.08, 0.10]
print('\n| trait | first yr | Q/yr | kappa T=20 r=0 | r=3% | r=5% | r=8% | r=10% |')
kap = {}
for tr in ['carcass', 'direct', 'NBA', 'maternal', 'longevity', 'boar']:
    Qi = Q[tr].sum()
    E = expr_path(P, Q[tr], 30)
    first = int(np.argmax(E > 1e-12))
    vals = []
    for r in rates:
        if r == 0.0:
            vals.append(cde(P, Q[tr], 0.0, T=20) / Qi)
        else:
            vals.append(cde(P, Q[tr], r) / Qi)
    kap[tr] = vals
    print('| %s | %d | %.1f | %s |' % (tr, first, Qi, ' | '.join('%.4f' % x for x in vals)))
print('\nrelative to carcass:')
for tr in kap:
    print('%-10s' % tr, ' '.join('%.4f' % (a / b) for a, b in zip(kap[tr], kap['carcass'])))
# also T=20 with r=5% (finite) and T=inf
for tr in ['carcass', 'NBA', 'longevity']:
    Qi = Q[tr].sum()
    print('%s r=5%% T=20: %.4f  T=inf: %.4f' % (tr, cde(P, Q[tr], 0.05, T=20) / Qi, cde(P, Q[tr], 0.05) / Qi))
# durations (discount-weighted mean time of expression) r=5%
print('\ndurations r=5%:')
for tr in ['carcass', 'NBA', 'longevity']:
    print(tr, '%.4f' % duration(P, Q[tr], 0.05))
# share of discounted expressions within first 10 / 20 years (carcass)
d = 1 / 1.05
E = expr_path(P, Q['carcass'], 3000)
w = d ** np.arange(3001) * E
print('carcass disc share yrs 0-4: %.4f 0-9: %.4f 0-19: %.4f' % (w[:5].sum() / w.sum(), w[:10].sum() / w.sum(), w[:20].sum() / w.sum()))
E = expr_path(P, Q['NBA'], 3000)
w = d ** np.arange(3001) * E
print('NBA disc share yrs 0-4: %.4f 0-9: %.4f 0-19: %.4f' % (w[:5].sum() / w.sum(), w[:10].sum() / w.sum(), w[:20].sum() / w.sum()))

# ---- apply to the bio-economic weights (per sow-year) ----
th = dict(TH0)
v = v_analytic(MU0, th)
print('\nv per sow-year:', v)
Pm, Gm = index_mats()
I = 1.755
for r in [0.0, 0.03, 0.05, 0.08, 0.10]:
    j = rates.index(r)
    fac = kap['NBA'][j] / kap['carcass'][j]
    vd = v.copy()
    vd[0] = v[0] * fac
    b = np.linalg.solve(Pm, Gm @ vd)
    b_und = np.linalg.solve(Pm, Gm @ v)
    sI = np.sqrt(b @ Pm @ b)
    da = I / sI * (Gm.T @ b)
    g = Gm @ vd
    re = (b_und @ g) / np.sqrt((b_und @ Pm @ b_und) * (g @ np.linalg.solve(Pm, g)))
    vs = vd * sdA4 * np.array([1, 1, -1, -1])
    print('r=%.2f fac=%.4f vNBA=%.2f  NBA share=%.4f  b=%s  da=%s  RE(undiscounted idx)=%.6f' % (
        r, fac, vd[0], vs[0] / vs.sum(), np.round(b, 4), np.round(da, 5), re))

# ---- cattle comparison ----
print('\n==== cattle structure ====')
Pc, Qc, infoc = cattle_structure()
print('cattle info n=', np.round(infoc['n'], 3), ' slaughter=%.3f calves=%.1f' % (infoc['slaughter'], infoc['calves']))
print('row sums', Pc.sum(1))
print('spectral radius %.6f' % np.max(np.abs(np.linalg.eigvals(Pc))))
fc = infoc['f']
print('dam gen interval %.4f ; sire 2' % (fc * infoc['ages']).sum())
kc = {}
for tr in ['direct', 'carcass', 'calving', 'maternal', 'longevity']:
    Qi = Qc[tr].sum()
    E = expr_path(Pc, Qc[tr], 30)
    first = int(np.argmax(E > 1e-12))
    vals = []
    for r in rates:
        vals.append(cde(Pc, Qc[tr], 0.0, T=20) / Qi if r == 0 else cde(Pc, Qc[tr], r) / Qi)
    kc[tr] = vals
    print('%-10s first=%d ' % (tr, first), ' '.join('%.4f' % x for x in vals))
print('relative to carcass:')
for tr in kc:
    print('%-10s' % tr, ' '.join('%.4f' % (a / b) for a, b in zip(kc[tr], kc['carcass'])))
print('relative to direct:')
for tr in kc:
    print('%-10s' % tr, ' '.join('%.4f' % (a / b) for a, b in zip(kc[tr], kc['direct'])))
for tr in ['direct', 'carcass', 'maternal', 'longevity']:
    print('cattle duration r=5%% %s %.4f' % (tr, duration(Pc, Qc[tr], 0.05)))
