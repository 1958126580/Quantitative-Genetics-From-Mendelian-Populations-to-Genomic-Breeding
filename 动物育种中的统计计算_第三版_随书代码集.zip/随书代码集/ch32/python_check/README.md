# 第 32 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch32/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `pareto.py` | ASSUMED example parameters: milk (kg/305d), methane (g/d) | numpy, scipy | 1.3 | `outputs/pareto.out` |
| `pig.py` | genetic parameters (same as ch10 §10.2.7 case 2): ADG (g/d), FCR (kg/kg), BF (mm) | numpy, scipy | 1.4 | `outputs/pig.out` |
| `pig2.py` | 数值复核 | numpy, scipy | 1.3 | `outputs/pig2.out` |
| `s1_goal_vs_sel.py` | §32.1.4  goal traits (ADG, FCR, BF) vs selection traits (ADG, BF only) | numpy, scipy | 1.4 | `outputs/s1_goal_vs_sel.out` |
| `s1_variance_info.py` | §32.1.4 : Var(H) and genetic correlation; r_IH vs amount of information; identities; canonical bounds | numpy, scipy | 1.3 | `outputs/s1_variance_info.out` |
| `s1c_mc_canon.py` | §32.1.4 part C: Monte Carlo check of the sib-information construction; canonical heritabilities as bounds on r_IH^2 | numpy, scipy | 2.0 | `outputs/s1c_mc_canon.out` |
| `s2_timescale.py` | §32.1.5 price forecast error over the horizon: v_T = v0 * exp(sigma*sqrt(T)*Z) (independent per trait) | numpy, scipy | 2.2 | `outputs/s2_timescale.out` |
| `s3_biomodel.py` | 数值复核 | numpy | 0.2 | `outputs/s3_biomodel.out` |
| `s4_bases.py` | §32.2.7 three profit bases: per sow-year, per kg carcass, per yuan cost | numpy | 0.1 | `outputs/s4_bases.out` |
| `s5_geneflow.py` | §32.2.8 discounted gene flow: full computation | numpy | 0.3 | `outputs/s5_geneflow.out` |
| `s6_nonlinear.py` | §32.2.9 nonlinear profit functions: economic value depends on the population mean | numpy, scipy | 3.0 | `outputs/s6_nonlinear.out` |
| `s7_nonmarket.py` | §32.3.4 three ways to include a non-market value (methane): shadow price / constraint / desired gains | numpy | 0.1 | `outputs/s7_nonmarket.out` |
| `s8_pareto.py` | §32.3.5 Pareto frontier: market genetic gain vs methane change (per generation) | numpy | 0.1 | `outputs/s8_pareto.out` |
| `s9_desired.py` | §32.3.6 desired gains index: derivation check + numerical example (ch10 pig parameters) | numpy, scipy | 1.3 | `outputs/s9_desired.out` |
| `t0_reproduce.py` | 数值复核 | numpy, scipy | 1.3 | `outputs/t0_reproduce.out` |

公共函数模块（被上列脚本导入，不单独运行）：`common.py`、`dairy.py`、`geneflow.py`、`pigmodel.py`、`s1b_info.py`。
