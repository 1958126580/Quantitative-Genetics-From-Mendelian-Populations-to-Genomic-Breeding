# 本脚本由 tools/nb2jl.py 从同目录的 ch32.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 32

# %% [markdown]
# # 第三十二章　育种目标与经济加权 —— 配套代码
#
# **内容**
#
# 1. 生物经济模型与边际效益的数值计算（正文式 32.6–32.9）
# 2. 利润基准的影响：每头 vs 每单位产品（正文 §32.2.3）
# 3. **折现基因流**：基因流矩阵的构造与 CDE（正文式 32.10–32.16）
# 4. **选择指数 $\mathbf b=\mathbf P^{-1}\mathbf{Gv}$**（正文式 32.24）与相关反应表（式 32.27）
# 5. 受限指数与期望增益指数（正文式 32.18–32.19）
# 6. 敏感性分析：价格扰动下的排序稳健性（正文式 32.29–32.30）
# 7. Pareto 前沿：改变 $\mathbf v$ 扫出前沿（正文式 32.17）

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %% [markdown]
# ## 1　生物经济模型（正文式 32.6–32.9）

# %%
"""奶牛的简化利润函数（正文式 32.6–32.7），返回每头每年利润。"""
function dairy_profit(mu::NamedTuple, prices::NamedTuple)
    FI = prices.a0*mu.W^0.75 + prices.a1*mu.M + prices.a2*mu.F + prices.a3*mu.P
    incidence = prices.i0*exp(prices.i1*(mu.SCS - 3.0))
    return prices.pm*mu.M + prices.pf*mu.F + prices.pp*mu.P -
           prices.cf*FI - prices.ch*incidence - prices.c0 +
           (prices.s - prices.cr)/mu.L
end

"""正文式 (32.4)：用中心差分计算边际效益 v_i = ∂Π/∂μ_i。"""
function marginal_values(profit, mu::NamedTuple, prices; h=1e-4)
    ks = keys(mu); v = Dict{Symbol,Float64}()
    for k in ks
        up = merge(mu, NamedTuple{(k,)}((mu[k] + h,)))
        dn = merge(mu, NamedTuple{(k,)}((mu[k] - h,)))
        v[k] = (profit(up, prices) - profit(dn, prices))/(2h)
    end
    return v
end

mu0 = (M=9000.0, F=360.0, P=310.0, SCS=3.0, W=650.0, L=3.0)
pr0 = (pm=0.30, pf=4.0, pp=6.0,                       # 元/kg
       cf=2.2, a0=0.08, a1=0.33, a2=2.0, a3=2.5,      # 饲料（kg DM）与价格
       ch=1500.0, i0=0.25, i1=0.35,                   # 乳房炎：成本与发病率函数
       c0=6000.0, s=6000.0, cr=18000.0)               # 固定成本、残值、培育成本

v = marginal_values(dairy_profit, mu0, pr0)
@printf("基准利润 = %.1f 元/头·年\n\n", dairy_profit(mu0, pr0))
@printf("%-8s%-18s%-30s\n", "性状", "v_i（元/单位）", "解析值（式 32.8–32.9）")
@printf("%-8s%-18.4f%-30s\n", "M",   v[:M],   @sprintf("pm - cf·a1 = %.4f", pr0.pm - pr0.cf*pr0.a1))
@printf("%-8s%-18.4f%-30s\n", "F",   v[:F],   @sprintf("pf - cf·a2 = %.4f", pr0.pf - pr0.cf*pr0.a2))
@printf("%-8s%-18.4f%-30s\n", "P",   v[:P],   @sprintf("pp - cf·a3 = %.4f", pr0.pp - pr0.cf*pr0.a3))
@printf("%-8s%-18.2f%-30s\n", "SCS", v[:SCS], "-ch·∂I/∂SCS")
@printf("%-8s%-18.2f%-30s\n", "W",   v[:W],   "-cf·a0·0.75·W^(-0.25)")
@printf("%-8s%-18.2f%-30s\n", "L",   v[:L],   @sprintf("-(s-cr)/L² = %.2f", -(pr0.s-pr0.cr)/mu0.L^2))
println("\n=> 若忽略饲料成本，v_M 会被高估为 pm = $(pr0.pm)，高估 ",
        round(Int, 100*(pr0.pm/v[:M] - 1)), "%（正文 §32.2.2 要点 1）。")

# %% [markdown]
# ## 2　利润基准的影响（正文 §32.2.3）

# %%
"""每单位产品基准：固定总产奶量（配额）Q，牛头数 N = Q / M。"""
function profit_per_quota(mu, prices; Q=9.0e6)
    N = Q/mu.M
    return N*dairy_profit(mu, prices)            # 整个配额下的总利润
end

v_head  = marginal_values(dairy_profit, mu0, pr0)
v_quota = marginal_values((m,p) -> profit_per_quota(m, p), mu0, pr0)
Nq = 9.0e6/mu0.M
@printf("%-8s%-20s%-26s\n", "性状", "每头基准 v_i", "配额基准 v_i / 头数")
for k in (:M, :F, :P, :SCS, :L)
    @printf("%-8s%-20.4f%-26.4f\n", String(k), v_head[k], v_quota[k]/Nq)
end
@printf("\n配额下的基准利润 = %.1f 元/头\n", dairy_profit(mu0, pr0))
println("=> 配额约束下 M 的价值变化很大，这正是正文 §32.2.3 的警告：")
println("   除非当前利润为零，否则基准的选择实质性地改变经济权重。")

# %% [markdown]
# ## 3　折现基因流（正文式 32.10–32.16）

# %%
"""构造一个奶牛群体的基因流矩阵（年龄组 × 性别）。

雌性：年龄 0..nf-1；雄性（公牛）：年龄 0..nm-1。
新生组的基因一半来自公牛（按 sire_use 分布于各年龄），一半来自母牛（按 dam_use）。
"""
function gene_flow_matrix(; nf=6, nm=6, sire_use=[0,0,0.1,0.3,0.4,0.2],
                            dam_use=[0,0,0.3,0.3,0.25,0.15])
    q = nf + nm
    P = zeros(q, q)
    # 雌性新生（行 1）与雄性新生（行 nf+1）：父母各贡献一半
    for r in (1, nf+1)
        for a in 1:nm; P[r, nf+a] += 0.5*sire_use[a]; end
        for a in 1:nf; P[r, a]    += 0.5*dam_use[a];  end
    end
    # 老化
    for a in 2:nf; P[a, a-1] = 1.0; end
    for a in 2:nm; P[nf+a, nf+a-1] = 1.0; end
    return P
end

"""正文式 (32.13)：有限期 CDE。"""
function cde(P, q, j; r=0.05, T=25)
    s = 0.0; v = zeros(size(P,1)); v[j] = 1.0
    for t in 0:T
        s += dot(q, v)/(1+r)^t
        v = P*v
    end
    return s
end

"""正文式 (32.15)：无穷期闭式解。"""
cde_inf(P, q, j; r=0.05) = (q' * inv(I - P./(1+r)))[j]

P = gene_flow_matrix()
@printf("基因流矩阵 %d×%d ， 行和：%s\n", size(P)..., string(round.(vec(sum(P; dims=2)), digits=3)))
@printf("谱半径 ρ(P) = %.6f （稳定群体应为 1）\n", maximum(abs.(eigvals(P))))

nf, nm = 6, 6
# 性状的表达向量 q（正文 §32.2.4）
q_birth = zeros(nf+nm); q_birth[1] = 1.0; q_birth[nf+1] = 1.0      # 初生重：新生个体各表达一次
q_milk  = zeros(nf+nm); q_milk[3:nf] .= 1.0                         # 产奶量：2 岁以上母牛每年一次
q_life  = zeros(nf+nm); q_life[4] = 1.0                             # 生产寿命：约在 3 岁时"表达"一次
j0 = nf + 1                                                          # 选择施加于雄性新生组

@printf("\n%-14s%-14s%-14s%-14s\n", "性状", "CDE(r=3%)", "CDE(r=5%)", "CDE(r=8%)")
for (nm_, qv) in ("初生重"=>q_birth, "产奶量"=>q_milk, "生产寿命"=>q_life)
    @printf("%-14s%-14.3f%-14.3f%-14.3f\n", nm_,
            cde(P, qv, j0; r=0.03), cde(P, qv, j0; r=0.05), cde(P, qv, j0; r=0.08))
end
check("式 (32.13) T→∞ 与式 (32.15) 闭式解一致",
      cde(P, q_milk, j0; r=0.05, T=400), cde_inf(P, q_milk, j0; r=0.05); tol=1e-8)
println("\n=> 晚表达且只表达一次的性状（生产寿命）折现损失最大（正文 §32.2.4）。")

# %% [markdown]
# ## 4　选择指数与相关反应表（正文式 32.22–32.28）

# %%
"""正文式 (32.24)–(32.27)。"""
function selection_index(Pm, G, Cm, v; i=1.4)
    b = Pm \ (G*v)
    sI = sqrt(dot(b, Pm*b)); sH = sqrt(dot(v, Cm*v))
    rHI = dot(b, G*v)/(sI*sH)
    dH = i*rHI*sH
    da = i .* (G'*b) ./ sI
    return (b=b, rHI=rHI, dH=dH, da=da)
end

# 两性状例子（正文思考题 8）
h2 = [0.30, 0.10]; rg = -0.4; rp = -0.2; sP = [1.0, 1.0]
sA = sqrt.(h2) .* sP
Cm = [sA[1]^2 rg*sA[1]*sA[2]; rg*sA[1]*sA[2] sA[2]^2]      # Var(a)
Pm = [sP[1]^2 rp*sP[1]*sP[2]; rp*sP[1]*sP[2] sP[2]^2]      # Var(x)
G  = Cm                                                   # x = 表型，Cov(x,a') = Var(a)
v  = [1.0, 2.0]
si = selection_index(Pm, G, Cm, v)
@printf("b = %s ， r_HI = %.4f ， ΔH = %.4f\n", string(round.(si.b, digits=4)), si.rHI, si.dH)
@printf("相关反应 Δa = %s\n", string(round.(si.da, digits=4)))
println(any(si.da .< 0) ? "  ⚠ 有性状退步——正文 §32.4.1 要求必须报告这张表。" : "  所有性状同向改良。")

# 式 (32.28)：x 为目标性状的 EBV 时 b = v
let Pe = [0.20 0.03; 0.03 0.05]       # Var(â)，BLUP 下也等于 Cov(â, a')
    b_ebv = Pe \ (Pe*v)
    check("式 (32.28)：用 EBV 建指数时 b = v", b_ebv, v; tol=1e-12)
end

# %% [markdown]
# ## 5　受限指数与期望增益指数（正文式 32.18–32.19）

# %%
"""正文式 (32.18)：受限指数，约束 C' Δa = 0。"""
function restricted_index(Pm, G, v, Cr)
    Pi = inv(Pm)
    b0 = Pi*G*v
    K = Pi*G*Cr
    return (I - K*inv(Cr'*G'*Pi*G*Cr)*Cr'*G') * b0
end

Cr = reshape([0.0, 1.0], 2, 1)          # 限制性状 2 的反应为零
br = restricted_index(Pm, G, v, Cr)
sIr = sqrt(dot(br, Pm*br))
da_r = 1.4 .* (G'*br) ./ sIr
@printf("受限指数 b = %s\n", string(round.(br, digits=4)))
@printf("相关反应 Δa = %s  （性状 2 应为 0）\n", string(round.(da_r, digits=6)))
dH_r = 1.4*dot(br, G*v)/sIr
@printf("ΔH：无约束 %.4f → 受限 %.4f （损失 %.1f%%）\n", si.dH, dH_r, 100*(1 - dH_r/si.dH))

# 式 (32.19)：期望增益
d = [1.0, 1.0]
bd = G \ d
sId = sqrt(dot(bd, Pm*bd))
da_d = 1.4 .* (G'*bd) ./ sId
@printf("\n期望增益指数 b ∝ G⁻¹d = %s\n", string(round.(bd, digits=4)))
@printf("实际反应 Δa = %s ， 比例 %.3f : %.3f （期望 1 : 1）\n",
        string(round.(da_d, digits=4)), da_d[1]/da_d[1], da_d[2]/da_d[1])
@printf("cond(G) = %.1f （正文陷阱 1：G 病态时 G⁻¹d 数值不稳）\n", cond(G))

# %% [markdown]
# ## 6　敏感性分析：排序稳健性（正文式 32.29–32.30）

# %%
"""正文式 (32.30)：扰动经济权重后，前 top 比例个体的重叠率。"""
function ranking_robustness(EBV::Matrix{Float64}, v::Vector{Float64};
                            pert=0.3, nrep=200, top=0.1, rng=Random.default_rng())
    n = size(EBV, 1); k = max(1, round(Int, top*n))
    base = sortperm(EBV*v; rev=true)[1:k]
    ov = Float64[]; rk = Float64[]
    for _ in 1:nrep
        vp = v .* (1 .+ pert .* (2 .* rand(rng, length(v)) .- 1))
        sel = sortperm(EBV*vp; rev=true)[1:k]
        push!(ov, length(intersect(base, sel))/k)
        push!(rk, cor(EBV*v, EBV*vp))
    end
    return mean(ov), minimum(ov), mean(rk)
end

rng = Xoshiro(3200)
ntr = 6; nanim = 3000
Cg = let R = [1.0 0.4 0.3 -0.2 0.1 0.0; 0.4 1.0 0.5 -0.1 0.0 0.1; 0.3 0.5 1.0 0.0 0.1 0.0;
              -0.2 -0.1 0.0 1.0 0.2 0.3; 0.1 0.0 0.1 0.2 1.0 0.2; 0.0 0.1 0.0 0.3 0.2 1.0]
    R
end
EBV = randn(rng, nanim, ntr)*cholesky(Symmetric(Cg)).U
vv = [1.0, 0.8, 1.2, 0.6, 0.4, 0.5]
@printf("%-14s%-18s%-18s%-18s\n", "价格扰动", "前10%重叠(均值)", "前10%重叠(最差)", "指数值相关")
for pert in (0.1, 0.3, 0.5)
    o, omin, rkc = ranking_robustness(EBV, vv; pert=pert, rng=Xoshiro(1))
    @printf("±%-13.0f%-18.3f%-18.3f%-18.4f\n", 100*pert, o, omin, rkc)
end
# 符号错误的后果
vbad = copy(vv); vbad[4] = -vbad[4]
k = 300
ov_bad = length(intersect(sortperm(EBV*vv; rev=true)[1:k], sortperm(EBV*vbad; rev=true)[1:k]))/k
@printf("\n若把性状 4 的权重符号写反：前 10%% 重叠率 = %.3f\n", ov_bad)
println("=> 对幅度误差稳健，对符号错误不稳健（正文 §32.4.2）。")

# %% [markdown]
# ## 7　Pareto 前沿（正文式 32.17）

# %%
# 两性状：改变 v 的方向，扫出 (Δa₁, Δa₂) 的集合
println("改变经济权重的方向 θ（v = (cos θ, sin θ)），相关反应沿 Pareto 前沿移动：\n")
@printf("%-10s%-14s%-14s\n", "θ(度)", "Δa₁", "Δa₂")
front = Tuple{Float64,Float64}[]
for th in 0:15:90
    vv2 = [cosd(th), sind(th)]
    s2 = selection_index(Pm, G, Cm, vv2)
    push!(front, (s2.da[1], s2.da[2]))
    @printf("%-10d%-14.4f%-14.4f\n", th, s2.da[1], s2.da[2])
end
# 检验 Pareto 性：前沿上不存在两点互相支配
dominated = any(a[1] >= b[1] && a[2] >= b[2] && a != b for a in front for b in front)
println(dominated ? "\n存在被支配的点" : "\n=> 前沿上的点互不支配：选择指数就是多目标优化的标量化（正文式 32.17）。")

# %% [markdown]
# ## 8　自检汇总

# %%
ok = Bool[]
push!(ok, check("v_M 数值 = 解析", v[:M], pr0.pm - pr0.cf*pr0.a1; tol=1e-6))
push!(ok, check("v_F 数值 = 解析", v[:F], pr0.pf - pr0.cf*pr0.a2; tol=1e-6))
push!(ok, check("基因流矩阵行和 = 1", vec(sum(P; dims=2)), ones(size(P,1)); tol=1e-12))
push!(ok, check("ρ(P) = 1", maximum(abs.(eigvals(P))), 1.0; tol=1e-8))
push!(ok, check("CDE 有限期 → 闭式", cde(P, q_milk, j0; r=0.05, T=400),
                cde_inf(P, q_milk, j0; r=0.05); tol=1e-8))
push!(ok, abs(da_r[2]) < 1e-10)
@printf("受限指数：性状 2 反应 = %.2e （应为 0）✔\n", da_r[2])
# b = P⁻¹Gv 使 corr(H, I) 最大：随机扰动 b 不应超过
let best = si.rHI, rgn = Xoshiro(9)
    worse = all(1:2000) do _
        bb = si.b .+ 0.3 .* randn(rgn, 2)
        dot(bb, G*v)/(sqrt(dot(bb, Pm*bb))*sqrt(dot(v, Cm*v))) <= best + 1e-12
    end
    @printf("随机扰动 b 均未超过最优 r_HI = %.4f ： %s\n", best, worse ? "✔" : "✘")
    push!(ok, worse)
end
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
