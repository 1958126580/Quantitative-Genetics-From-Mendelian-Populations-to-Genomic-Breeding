# 第三十二章　育种目标与经济加权 —— 配套代码

**所属**：第八篇　育种规划与遗传改良优化　　**对应正文**：第三十二章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch32.ipynb` | IJulia 笔记本：9 个代码单元，约 232 行 Julia 代码，穿插与正文对应的说明 |
| `ch32.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 15 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　生物经济模型（正文式 32.6–32.9）
- 2　利润基准的影响（正文 §32.2.3）
- 3　折现基因流（正文式 32.10–32.16）
- 4　选择指数与相关反应表（正文式 32.22–32.28）
- 5　受限指数与期望增益指数（正文式 32.18–32.19）
- 6　敏感性分析：排序稳健性（正文式 32.29–32.30）
- 7　Pareto 前沿（正文式 32.17）
- 8　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 32
```

或在 Jupyter 中打开 `ch32/ch32.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
