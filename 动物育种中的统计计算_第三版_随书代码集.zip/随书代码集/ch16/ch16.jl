# 本脚本由 tools/nb2jl.py 从同目录的 ch16.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 16

# %% [markdown]
# # 第十六章　基于矩的方差组分估计 —— 配套代码
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | 二次型期望的统一框架 | §16.1 |
# | 2 | ANOVA：EMS、无偏性、负估计概率 | §16.2 |
# | 3 | 巢式设计与三种遗传力估计 | §16.2.2 |
# | 4 | Henderson 方法 I 的偏性演示 | §16.3.1 |
# | 5 | Henderson 方法 III（拟合常数法） | §16.3.3 |
# | 6 | MIVQUE 与 HE 回归 | §16.4–16.5 |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions
rng = Xoshiro(20260918)

# ── 全书通用工具（第九章）────────────────────────────────────────────
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        b = inv(delta)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

# %% [markdown]
# ## 1　二次型期望的统一框架（正文式 16.1、16.3）

# %%
# 数值验证 E(y'Ay) = tr(AV) + mu'A mu（第三章式 3.29）
n = 60
Vtrue = let Q = Matrix(qr(randn(Xoshiro(1), n, n)).Q)
    Q * Diagonal(range(0.5, 3.0; length=n)) * Q'
end
mu = randn(Xoshiro(2), n)
Am = let B = randn(Xoshiro(3), n, n); (B + B')/2 end

L = cholesky(Symmetric(Vtrue)).L
sims = [let y = mu .+ L*randn(Xoshiro(1000+k), n); (y'*Am*y) end for k in 1:200_000]
theo = tr(Am*Vtrue) + mu'*Am*mu
@printf("模拟 E(y'Ay) = %.4f\n", mean(sims))
@printf("理论 E(y'Ay) = %.4f   （tr(AV)=%.4f, mu'A mu=%.4f）\n", theo, tr(Am*Vtrue), mu'*Am*mu)
@printf("相对差 = %.4f%%\n", 100*abs(mean(sims)-theo)/abs(theo))
println("\n=> 式 (16.1) 是所有矩方法的出发点。")

# %% [markdown]
# ## 2　ANOVA：平衡单因子随机模型（正文 §16.2.1）

# %%
"""
    anova_one_way(y, grp, s, n) -> (sigma2_a, sigma2_e, MSA, MSE)

平衡单因子随机模型的 ANOVA 方差组分估计（式 16.9）。
"""
function anova_one_way(y::Vector{Float64}, grp::Vector{Int}, s::Int, n::Int)
    ybar  = mean(y)
    ybari = [mean(y[grp .== i]) for i in 1:s]
    SSA = n*sum((ybari .- ybar).^2)
    SSE = sum((y .- ybari[grp]).^2)
    MSA = SSA/(s-1); MSE = SSE/(s*(n-1))
    return ((MSA - MSE)/n, MSE, MSA, MSE)
end

"""按给定方差组分模拟平衡单因子数据。"""
function sim_one_way(s, n, s2a, s2e; rng=Random.default_rng())
    a = randn(rng, s) .* sqrt(s2a)
    grp = repeat(1:s, inner=n)
    y = 10.0 .+ a[grp] .+ randn(rng, s*n).*sqrt(s2e)
    return y, grp
end

s, n = 40, 8
s2a_true, s2e_true = 2.0, 8.0
R = 5000
est_a = Float64[]; est_e = Float64[]
for r in 1:R
    y, g = sim_one_way(s, n, s2a_true, s2e_true; rng=Xoshiro(hash((11,r))))
    ea, ee, _, _ = anova_one_way(y, g, s, n)
    push!(est_a, ea); push!(est_e, ee)
end
@printf("真值 sigma2_a = %.3f ,  ANOVA 均值 = %.4f   （无偏性检验）\n", s2a_true, mean(est_a))
@printf("真值 sigma2_e = %.3f ,  ANOVA 均值 = %.4f\n", s2e_true, mean(est_e))
@printf("负估计比例 = %.3f%%\n", 100*mean(est_a .< 0))

# %% [markdown]
# ### 2.1 负估计的概率（正文式 16.10）

# %%
"""P(sigma2_a_hat < 0) = P(F_{s-1, s(n-1)} < 1/(1 + n*sigma2_a/sigma2_e))（式 16.10）"""
p_negative(s, n, ratio) = cdf(FDist(s-1, s*(n-1)), 1/(1 + n*ratio))

println(rpad("s (组数)", 12), rpad("n (组内)", 12), rpad("s2a/s2e", 12), rpad("理论 P(<0)", 14), "模拟 P(<0)")
println("-"^66)
for (ss, nn, ratio) in ((40,8,0.25), (20,5,0.25), (10,5,0.25), (20,5,0.05), (10,3,0.05))
    theo = p_negative(ss, nn, ratio)
    cnt = 0; RR = 3000
    for r in 1:RR
        y, g = sim_one_way(ss, nn, ratio*8.0, 8.0; rng=Xoshiro(hash((22,ss,nn,r))))
        ea, _, _, _ = anova_one_way(y, g, ss, nn)
        ea < 0 && (cnt += 1)
    end
    @printf("%-12d%-12d%-12.3f%-14.4f%.4f\n", ss, nn, ratio, theo, cnt/RR)
end
println("\n=> 样本小、遗传力低时，负估计的概率不容忽视（正文 §16.2.1）。")

# %% [markdown]
# ## 3　巢式设计：三种遗传力估计（正文式 16.12–16.14）

# %%
"""两层巢式（公畜内母畜）设计的 ANOVA。"""
function nested_anova(y, sid, did, s, d, n)
    ybar = mean(y)
    ybar_s = [mean(y[sid .== i]) for i in 1:s]
    ybar_d = [mean(y[(sid .== i) .& (did .== j)]) for i in 1:s, j in 1:d]
    SSS = d*n*sum((ybar_s .- ybar).^2)
    SSD = n*sum((ybar_d[i,j] - ybar_s[i])^2 for i in 1:s, j in 1:d)
    SSE = sum((y[k] - ybar_d[sid[k], did[k]])^2 for k in eachindex(y))
    MSS = SSS/(s-1); MSD = SSD/(s*(d-1)); MSE = SSE/(s*d*(n-1))
    s2s = (MSS - MSD)/(n*d)
    s2d = (MSD - MSE)/n
    return s2s, s2d, MSE
end

# 模拟：sigma2_A = 4, sigma2_D = 2, sigma2_c（同窝）= 1, sigma2_e = 13
s, d, n = 60, 4, 6
s2A, s2D, s2c, s2e0 = 4.0, 2.0, 1.0, 13.0
s2s_true = 0.25*s2A
s2d_true = 0.25*s2A + 0.25*s2D + s2c
rr = Xoshiro(33)
svals = randn(rr, s) .* sqrt(s2s_true)
dvals = randn(rr, s, d) .* sqrt(s2d_true)
sid = repeat(1:s, inner=d*n)
did = repeat(repeat(1:d, inner=n), outer=s)
resid_var = s2A + s2D + s2c + s2e0 - s2s_true - s2d_true
y = [10.0 + svals[sid[k]] + dvals[sid[k], did[k]] + randn(rr)*sqrt(resid_var) for k in 1:s*d*n]

es, ed, ee = nested_anova(y, sid, did, s, d, n)
tot = es + ed + ee
@printf("sigma2_s = %.4f  (真值 %.4f)\n", es, s2s_true)
@printf("sigma2_d = %.4f  (真值 %.4f)\n", ed, s2d_true)
@printf("sigma2_e = %.4f\n\n", ee)
@printf("h2_sire  = 4*s2s/tot = %.4f   <- 只含加性方差，最“干净”\n", 4*es/tot)
@printf("h2_dam   = 4*s2d/tot = %.4f   <- 含显性与共同环境，通常高估\n", 4*ed/tot)
@printf("h2_s+d   = 2(s2s+s2d)/tot = %.4f\n", 2*(es+ed)/tot)
@printf("真实 h2  = sigma2_A / sigma2_P = %.4f\n", s2A/(s2A+s2D+s2c+s2e0))
println("\n=> h2_dam - h2_sire 提供了 sigma2_D + 4*sigma2_c 的信息，但无法进一步分离。")

# %% [markdown]
# ## 4　Henderson 方法 I 的偏性（正文 §16.3.1）
#
# **方法 I 不满足平移不变性 $\mathbf A_j\mathbf X=\mathbf 0$，因此对固定效应有偏。**

# %%
# 构造：随机效应 + 一个固定效应（场），故意让场与随机效应不平衡
function sim_with_fixed(s, n, s2a, s2e, herd_eff; rng=Random.default_rng())
    a = randn(rng, s) .* sqrt(s2a)
    grp = repeat(1:s, inner=n)
    # 场的分配与组相关（不平衡）：前一半组多在场 1，后一半多在场 2
    herd = [ (grp[k] <= s÷2) ? (rand(rng) < 0.8 ? 1 : 2) : (rand(rng) < 0.2 ? 1 : 2)
             for k in 1:s*n ]
    y = 10.0 .+ herd_eff[herd] .+ a[grp] .+ randn(rng, s*n).*sqrt(s2e)
    return y, grp, herd
end

s, n = 40, 8
s2a_true, s2e_true = 2.0, 8.0
println(rpad("场效应差", 14), rpad("方法 I 的 s2a", 18), "偏倚")
println("-"^50)
for diff in (0.0, 2.0, 5.0, 10.0)
    acc = Float64[]
    for r in 1:1500
        y, g, h = sim_with_fixed(s, n, s2a_true, s2e_true, [0.0, diff]; rng=Xoshiro(hash((44,r,diff))))
        # 方法 I：直接套用平衡设计的平方和，忽略场效应
        ea, _, _, _ = anova_one_way(y, g, s, n)
        push!(acc, ea)
    end
    @printf("%-14.1f%-18.4f%+.1f%%\n", diff, mean(acc), 100*(mean(acc)-s2a_true)/s2a_true)
end
println("\n=> 场效应越大，方法 I 的偏倚越大（因为场效应被错误地归入组间方差）。")
println("   这就是正文 §16.3.1 所说的「不满足平移不变性」的后果。")

# %% [markdown]
# ## 5　Henderson 方法 III（拟合常数法，正文 §16.3.3）

# %%
"""
    henderson3(y, X, Z) -> (sigma2_u, sigma2_e)

Henderson 方法 III：用顺序平方和 R(u | beta) 构造二次型。
由于 X 已被「拟合掉」，对应的 A 自动满足 AX = 0，故对固定效应无偏。
"""
function henderson3(y::Vector{Float64}, X::Matrix{Float64}, Z::Matrix{Float64})
    N = length(y)
    W = hcat(X, Z)
    H_x  = X*pinv(X'X)*X'
    H_xz = W*pinv(W'W)*W'
    r_x  = rank(X); r_xz = rank(W)
    R_u_given_b = y'*(H_xz - H_x)*y          # R(u | beta)
    SSE = y'*(I - H_xz)*y
    df_e = N - r_xz
    s2e = SSE/df_e
    # E[R(u|beta)] = (r_xz - r_x)*s2e + tr[(H_xz - H_x) Z Z'] * s2u
    trZZ = tr((H_xz - H_x)*(Z*Z'))
    s2u = (R_u_given_b - (r_xz - r_x)*s2e)/trZZ
    return s2u, s2e
end

# 与方法 I 在同一数据上对照
s, n = 30, 6
res1 = Float64[]; res3 = Float64[]
for r in 1:800
    y, g, h = sim_with_fixed(s, n, 2.0, 8.0, [0.0, 6.0]; rng=Xoshiro(hash((55,r))))
    N = length(y)
    Xm = hcat(ones(N), Float64.(h .== 2))
    Zm = zeros(N, s); for k in 1:N; Zm[k, g[k]] = 1.0; end
    e1, _, _, _ = anova_one_way(y, g, s, n)
    e3, _ = henderson3(y, Xm, Zm)
    push!(res1, e1); push!(res3, e3)
end
@printf("真值 sigma2_a       = %.4f\n", 2.0)
@printf("方法 I   均值 = %.4f   偏倚 %+.1f%%\n", mean(res1), 100*(mean(res1)-2)/2)
@printf("方法 III 均值 = %.4f   偏倚 %+.1f%%   <- 无偏\n", mean(res3), 100*(mean(res3)-2)/2)
println("\n=> 方法 III 的二次型满足 AX = 0，故对固定效应无偏（正文 §16.3.3）。")

# %% [markdown]
# ## 6　MIVQUE 与 HE 回归（正文 §16.4–16.5）

# %%
"""
    P_matrix(V, X) -> P

投影矩阵 P = V^-1 - V^-1 X (X'V^-1 X)^- X' V^-1（式 16.20）。
"""
function P_matrix(V::Matrix{Float64}, X::Matrix{Float64})
    Vi = inv(V)
    return Vi - Vi*X*pinv(X'*Vi*X)*X'*Vi
end

"""
    mivque(y, X, Vlist, theta0) -> theta_hat

MIVQUE(theta0)：在先验值 theta0 处求解式 (16.19)。
"""
function mivque(y::Vector{Float64}, X::Matrix{Float64},
                Vlist::Vector{Matrix{Float64}}, theta0::Vector{Float64})
    V = sum(Vlist[i]*theta0[i] for i in eachindex(theta0))
    P = P_matrix(V, X)
    k = length(theta0)
    Amat = [tr(P*Vlist[i]*P*Vlist[j]) for i in 1:k, j in 1:k]
    bvec = [y'*P*Vlist[i]*P*y for i in 1:k]
    return Amat \ bvec
end

# 验证：MIVQUE 迭代收敛到 REML（正文 §16.4.3）
s, n = 25, 6
N = s*n
y, g = sim_one_way(s, n, 2.0, 8.0; rng=Xoshiro(66))
Xm = ones(N, 1)
Zm = zeros(N, s); for k in 1:N; Zm[k, g[k]] = 1.0; end
Vlist = [Zm*Zm', Matrix(1.0I, N, N)]

println("MIVQUE 迭代轨迹（起始值 [1, 1]）：")
theta = [1.0, 1.0]
for it in 1:15
    theta_new = mivque(y, Xm, Vlist, theta)
    theta_new = max.(theta_new, 1e-8)
    @printf("  第 %2d 轮: sigma2_a = %.6f , sigma2_e = %.6f , 变化 = %.2e\n",
            it, theta_new[1], theta_new[2], norm(theta_new - theta)/norm(theta))
    norm(theta_new - theta)/norm(theta) < 1e-10 && (theta = theta_new; break)
    theta = theta_new
end
ea, ee, _, _ = anova_one_way(y, g, s, n)
@printf("\nANOVA（平衡设计，= REML）: sigma2_a = %.6f , sigma2_e = %.6f\n", ea, ee)
@printf("MIVQUE 收敛值与 ANOVA 的相对差 = %.3e\n",
        norm(theta - [ea, ee])/norm([ea, ee]))
println("\n=> 验证了正文 §16.4.3：MIVQUE 迭代收敛到 REML；")
println("   而平衡设计下 REML = ANOVA（第十七章定理）。")

# %% [markdown]
# ### 6.1 HE 回归（正文 §16.5）

# %%
"""
    he_regression(y, G; product=true) -> sigma2_a_hat

Haseman–Elston 回归。product=true 用中心化表型乘积（式 16.24，更有效），
否则用差平方（式 16.22）。
"""
function he_regression(y::Vector{Float64}, G::Matrix{Float64}; product::Bool=true)
    n = length(y)
    yc = y .- mean(y)
    xs = Float64[]; zs = Float64[]
    for i in 1:n-1, j in i+1:n
        push!(xs, G[i,j])
        push!(zs, product ? yc[i]*yc[j] : (y[i]-y[j])^2)
    end
    Xd = hcat(ones(length(xs)), xs)
    bhat = Xd \ zs
    return product ? bhat[2] : -bhat[2]/2
end

# 用系谱关系矩阵 A 做 HE 回归，与 ANOVA 对照
sire, dam = let nn = 500
    sv = zeros(Int, nn); dv = zeros(Int, nn)
    rr = Xoshiro(77)
    for i in 21:nn; sv[i] = rand(rr, 1:i-1); dv[i] = rand(rr, 1:i-1); end
    sv, dv
end
A = build_A(sire, dam)
nA = size(A, 1)
s2a_t, s2e_t = 3.0, 7.0
LA = cholesky(Symmetric(A + 1e-10I)).L
uA = LA*randn(Xoshiro(88), nA).*sqrt(s2a_t)
yA = 12.0 .+ uA .+ randn(Xoshiro(99), nA).*sqrt(s2e_t)

he_prod = he_regression(yA, A; product=true)
he_diff = he_regression(yA, A; product=false)
@printf("真值 sigma2_a          = %.4f\n", s2a_t)
@printf("HE 回归（乘积形式）    = %.4f\n", he_prod)
@printf("HE 回归（差平方形式）  = %.4f\n", he_diff)
println("\n=> 两种形式携带相同信息，但乘积形式的方差更小（Sham & Purcell 2001）。")

# 重复模拟比较两者的方差
pr = Float64[]; df = Float64[]
for r in 1:60
    u = LA*randn(Xoshiro(hash((111,r))), nA).*sqrt(s2a_t)
    yy = 12.0 .+ u .+ randn(Xoshiro(hash((222,r))), nA).*sqrt(s2e_t)
    push!(pr, he_regression(yy, A; product=true))
    push!(df, he_regression(yy, A; product=false))
end
@printf("\n60 次重复：乘积形式 sd = %.4f ; 差平方形式 sd = %.4f （比值 %.2f）\n",
        std(pr), std(df), std(df)/std(pr))

# %% [markdown]
# ## 本章代码小结
#
# 1. **式 (16.1) 的二次型期望已数值验证**，它是所有矩方法的共同出发点。
# 2. **ANOVA 在平衡设计下无偏**；**负估计的概率**由式 (16.10) 给出，模拟与理论吻合。
# 3. **半同胞法的 $h^2$ 只含加性方差**；全同胞（母畜）法含显性与共同环境，系统性高估。
# 4. **Henderson 方法 I 对固定效应有偏**，偏倚随固定效应的大小增加 —— 数值演示确认了正文的论断。
# 5. **方法 III（拟合常数法）无偏**，因为它的二次型自动满足 $\mathbf A\mathbf X=\mathbf 0$。
# 6. **MIVQUE 迭代收敛到 REML**，而平衡设计下 REML = ANOVA —— 三者在本笔记本中被串联验证。
# 7. **HE 回归的乘积形式方差小于差平方形式**，与 Sham & Purcell (2001) 的理论一致。
