# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s12_h3_final.py    依赖：numpy
"""§16.3 最终数值：方法 III 两种顺序（独立种子）+ 三法计算量（min of 3）。"""
import numpy as np, time
herd = np.array([0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,1,0,1,0,1,1,0])
sire = np.array([0,0,1,1,2,2,3, 0,1,1,2,3,3,4,4,4, 2,0,3,1,4,2,0,4])
year = np.array([0,1,0,2,1,3,2, 0,1,3,4,2,5,0,3,5, 5,4,1,2,3,4,5,2])
N=len(herd)
X=np.zeros((N,2)); X[np.arange(N),herd]=1
Z1=np.zeros((N,5)); Z1[np.arange(N),sire]=1
Z2=np.zeros((N,6)); Z2[np.arange(N),year]=1
V1,V2,V0 = Z1@Z1.T, Z2@Z2.T, np.eye(N)
s1,s2,s0 = 2.0,1.0,6.0; V = V1*s1+V2*s2+V0*s0
def H(*m):
    M=np.c_[tuple(m)]; return M@np.linalg.pinv(M)
HX,HX1,HX2,HX12 = H(X),H(X,Z1),H(X,Z2),H(X,Z1,Z2); I=np.eye(N)
AsA=[HX1-HX, HX12-HX1, I-HX12]
AsB=[HX12-HX2, HX2-HX, I-HX12]
CA=np.array([[np.trace(A@Vi) for Vi in (V1,V2,V0)] for A in AsA])
CB=np.array([[np.trace(A@Vi) for Vi in (V1,V2,V0)] for A in AsB])
print("秩: r(X)=%d r(X,Z1)=%d r(X,Z2)=%d r(X,Z1,Z2)=%d N=%d"
      % (np.linalg.matrix_rank(X),np.linalg.matrix_rank(np.c_[X,Z1]),
         np.linalg.matrix_rank(np.c_[X,Z2]),np.linalg.matrix_rank(np.c_[X,Z1,Z2]),N))
print("C_A ="); print(np.round(CA,4))
print("C_B ="); print(np.round(CB,4))
def ses(C,As):
    Ci=np.linalg.inv(C)
    return [np.sqrt(2*np.trace((sum(Ci[k,j]*As[j] for j in range(3)))@V@(sum(Ci[k,j]*As[j] for j in range(3)))@V)) for k in range(3)]
sA, sB = ses(CA,AsA), ses(CB,AsB)
print("理论 SE 顺序A: %s" % np.round(sA,4)); print("理论 SE 顺序B: %s" % np.round(sB,4))
print("σ_s² 的相对效率 B/A = %.4f" % ((sA[0]/sB[0])**2))
beta=np.array([20.0,24.0])
SD=19
rng=np.random.default_rng(SD)
y = X@beta + Z1@rng.normal(0,np.sqrt(s1),5) + Z2@rng.normal(0,np.sqrt(s2),6) + rng.normal(0,np.sqrt(s0),N)
for lab,As,C in (("A",AsA,CA),("B",AsB,CB)):
    q=np.array([y@A@y for A in As]); e=np.linalg.solve(C,q)
    print("种子%d 顺序%s: 二次型=%s  估计=%s" % (SD,lab,np.round(q,4),np.round(e,4)))
R=5000; SD2=20240401
r2=np.random.default_rng(SD2)
L=np.linalg.cholesky(V)
Y = (X@beta)[:,None] + (L@r2.standard_normal((N,R)))
EA=np.linalg.solve(CA, np.column_stack([np.einsum('ir,ij,jr->r',Y,A,Y) for A in AsA]).T).T
EB=np.linalg.solve(CB, np.column_stack([np.einsum('ir,ij,jr->r',Y,A,Y) for A in AsB]).T).T
print()
print("%d 次重复（种子 %d），真值 (%.1f,%.1f,%.1f)" % (R,SD2,s1,s2,s0))
print("顺序A 均值 %s  SD %s" % (np.round(EA.mean(0),4), np.round(EA.std(0,ddof=1),4)))
print("顺序B 均值 %s  SD %s" % (np.round(EB.mean(0),4), np.round(EB.std(0,ddof=1),4)))
print("负估计频率 A: σ_s² %.4f σ_y² %.4f σ_e² %.4f" % tuple((EA<0).mean(0)))
print("负估计频率 B: σ_s² %.4f σ_y² %.4f σ_e² %.4f" % tuple((EB<0).mean(0)))

# ---- 计算量 ----
print()
rng=np.random.default_rng(42)
p,q,Nn = 500,5000,100000
sire2 = rng.integers(0,q,Nn)
ts=[]
for _ in range(5):
    t=time.perf_counter(); ni=np.bincount(sire2,minlength=q); z=(ni.sum(),(ni**2).sum()); ts.append(time.perf_counter()-t)
t_I=min(ts)
k=p+q
Bm=rng.normal(size=(k,k+20)); C=Bm@Bm.T/k+np.eye(k)
tc=min([(lambda: (lambda t0: (np.linalg.cholesky(C), time.perf_counter()-t0)[1])(time.perf_counter()))() for _ in range(3)])
ti=min([(lambda: (lambda t0: (np.linalg.inv(C), time.perf_counter()-t0)[1])(time.perf_counter()))() for _ in range(3)])
print("p=%d q=%d N=%d; 方法I 统计量 %.5f 秒" % (p,q,Nn,t_I))
print("方法III 正规方程阶 %d: Cholesky %.4f 秒, 完整求逆 %.4f 秒, 比值 %.0f 倍" % (k,tc,ti,ti/t_I))
def fmt(x):
    return "%.1f 秒"%x if x<60 else ("%.1f 分"%(x/60) if x<3600 else ("%.1f 小时"%(x/3600) if x<86400 else "%.1f 天"%(x/86400)))
for kk in (1e4,5e4,1e5):
    print("  外推 p+q=%-8.0f Cholesky %s, 完整求逆 %s" % (kk, fmt(tc*(kk/k)**3), fmt(ti*(kk/k)**3)))
