# 第 16 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch16/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `s10_cost.py` | §16.3  三法计算量的量化；§16.5 加权 HE 的实际效果。 | numpy | 20.0 | `outputs/s10_cost.out` |
| `s11_varhat.py` | §16.1  矩估计量抽样方差的一般公式 Var(θ̂)=C^{-1} Σ C^{-T}, Σ_jk=2tr(A_jVA_kV) | numpy | 0.2 | `outputs/s11_varhat.out` |
| `s12_h3_final.py` | §16.3 最终数值：方法 III 两种顺序（独立种子）+ 三法计算量（min of 3）。 | numpy | 43.1 | `outputs/s12_h3_final.out` |
| `s13_timing_stable.py` | §16.3/§16.5 计算量：稳定化的实测 + 外推（锚点取 2 位有效数字，保证可复现）。 | numpy | 79.1 | `outputs/s13_timing_stable.out` |
| `s14_cost_table.py` | 正文两张计算量表：锚点取本机实测的量级（固定值），外推完全确定、可复现。 | 标准库 | 0.1 | `outputs/s14_cost_table.out` |
| `s15_derived.py` | 正文中由脚本输出再推出的派生量，逐个核对。 | numpy | 0.2 | `outputs/s15_derived.out` |
| `s1_quadvar.py` | §16.1  Var(y'Ay) 的一般公式与蒙特卡罗验证；不同二次型的效率对比。 | numpy | 1.6 | `outputs/s1_quadvar.out` |
| `s1b_unbal.py` | §16.1  不平衡设计下 ANOVA / MIVQUE / MIVQUE(0) 的效率差异。 | numpy | 0.3 | `outputs/s1b_unbal.out` |
| `s2_anova.py` | §16.2  平衡单因子（公畜模型）完整数值算例 + 1000 次重复。 | numpy, scipy | 1.7 | `outputs/s2_anova.out` |
| `s3_unbal_ems.py` | §16.2 三、不平衡设计下期望均方不唯一的小反例。 | numpy | 0.3 | `outputs/s3_unbal_ems.out` |
| `s4_henderson.py` | §16.3  Henderson 方法 I 的偏倚反例 + 方法 III 的顺序不唯一。 | numpy | 0.4 | `outputs/s4_henderson.out` |
| `s5_h3order.py` | §16.3  方法 III 的顺序不唯一：两个随机因子，两种拟合顺序给出不同估计量。 | numpy | 0.2 | `outputs/s5_h3order.out` |
| `s5b_pick.py` | 数值复核 | numpy | 0.2 | `outputs/s5b_pick.out` |
| `s6_mivque.py` | §16.4  MIVQUE = REML 的一次 Fisher 得分迭代；MIVQUE(0) 迭代收敛到 REML。 | numpy | 0.2 | `outputs/s6_mivque.out` |
| `s7_he.py` | §16.5  HE 回归三种形式与 REML 的模拟对比。 | numpy, scipy | 6.2 | `outputs/s7_he.out` |
| `s8_he_exact.py` | §16.5  HE 的二次型表示、精确抽样方差、与 MIVQUE/REML 的效率对照。 | numpy, scipy | 9.5 | `outputs/s8_he_exact.out` |
| `s9_timing.py` | §16.5  HE O(n^2) 与 GREML O(n^3) 的实测与外推。 | numpy | 25.9 | `outputs/s9_timing.out` |
| `s9b_timing.py` | 数值复核 | numpy | 20.3 | `outputs/s9b_timing.out` |
