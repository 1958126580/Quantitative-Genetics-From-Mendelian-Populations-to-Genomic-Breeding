# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1b_unbal.py    依赖：numpy
"""§16.1  不平衡设计下 ANOVA / MIVQUE / MIVQUE(0) 的效率差异。"""
import numpy as np
np.set_printoptions(precision=6, suppress=True)

ni = np.array([2, 2, 3, 5, 8, 20])      # 6 个家系，严重不平衡
s = len(ni); N = ni.sum()
print("家系含量:", ni.tolist(), " s=%d N=%d" % (s, N))
Z = np.zeros((N, s)); r = 0
for i, k in enumerate(ni):
    Z[r:r+k, i] = 1; r += k
X = np.ones((N, 1))
sa2, se2 = 2.0, 8.0
V1 = Z @ Z.T; V0 = np.eye(N); V = V1*sa2 + V0*se2

def P_of(M):
    Mi = np.linalg.inv(M)
    return Mi - Mi @ X @ np.linalg.inv(X.T @ Mi @ X) @ X.T @ Mi

HX = X @ np.linalg.pinv(X); HZ = Z @ np.linalg.pinv(Z)
A_SSA = HZ - HX; A_SSE = np.eye(N) - HZ

def calibrate(B1, B2):
    """在 a*B1+b*B2 中解 tr(AV1)=1, tr(AV0)=0."""
    M = np.array([[np.trace(B1@V1), np.trace(B2@V1)],
                  [np.trace(B1@V0), np.trace(B2@V0)]])
    ab = np.linalg.solve(M, np.array([1.0, 0.0]))
    return ab[0]*B1 + ab[1]*B2

A_h3 = calibrate(A_SSA, A_SSE)          # Henderson III / 拟合常数法
def mivque(Vp):
    P = P_of(Vp)
    S = np.array([[np.trace(P@Vi@P@Vj) for Vj in (V1,V0)] for Vi in (V1,V0)])
    Si = np.linalg.inv(S)
    return Si[0,0]*(P@V1@P) + Si[0,1]*(P@V0@P)
A_mv = mivque(V)
A_mv0 = mivque(np.eye(N))

# Henderson I 的"非加权"平方和：用组均值的未加权平方和
Zbar = Z / ni                            # 每列除以 n_i -> 取组均值
Mbar = Zbar.T                            # s x N, 行 i 为 (1/n_i) 指示
Jb = np.eye(s) - np.ones((s,s))/s
A_HI = Mbar.T @ Jb @ Mbar                # sum_i (ybar_i - mean of ybar)^2
A_h1 = calibrate(A_HI, A_SSE)

rows = [("Henderson III (拟合常数)", A_h3), ("MIVQUE(真值)", A_mv),
        ("MIVQUE(0)", A_mv0), ("未加权组均值法(校正后)", A_h1)]
print()
print("%-24s %10s %10s %10s" % ("二次型", "Var", "SE", "相对效率"))
vref = 2*np.trace(A_mv@V@A_mv@V)
for nm, A in rows:
    assert abs(np.trace(A@V1)-1) < 1e-9 and abs(np.trace(A@V0)) < 1e-9
    assert abs((X.T@A@X).item()) < 1e-9
    v = 2*np.trace(A@V@A@V)
    print("%-24s %10.4f %10.4f %10.4f" % (nm, v, np.sqrt(v), vref/v))
print()
print("(全部满足 tr(AV1)=1, tr(AV0)=0, X'AX=0，故都无偏且平移不变)")
