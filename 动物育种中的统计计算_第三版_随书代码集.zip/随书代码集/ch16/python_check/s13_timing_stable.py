# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s13_timing_stable.py    依赖：numpy
"""§16.3/§16.5 计算量：稳定化的实测 + 外推（锚点取 2 位有效数字，保证可复现）。"""
import numpy as np, time
def sig2(x):
    from math import log10, floor
    if x == 0: return 0.0
    e = floor(log10(abs(x)))
    return round(x, -(e-1))
def best(fn, rep):
    ts = []
    for _ in range(rep):
        t = time.perf_counter(); fn(); ts.append(time.perf_counter()-t)
    return min(ts)
def fmt(x):
    if x < 60:   return "%.0f 秒" % x if x >= 10 else "%.1f 秒" % x
    if x < 3600: return "%.0f 分" % (x/60) if x/60 >= 10 else "%.1f 分" % (x/60)
    if x < 86400:return "%.0f 小时"%(x/3600) if x/3600>=10 else "%.1f 小时"%(x/3600)
    return "%.0f 天" % (x/86400) if x/86400 >= 10 else "%.1f 天" % (x/86400)

rng = np.random.default_rng(1)
n0 = 4000
B = rng.normal(size=(n0, n0+50)); A = B@B.T/n0 + np.eye(n0)
y = rng.normal(size=n0)
t_chol = sig2(best(lambda: np.linalg.cholesky(A), 5))
t_inv  = sig2(best(lambda: np.linalg.inv(A), 5))
def he_kernel():
    return float(y@A@y), float((A*A).sum())   # HE 的两个 O(n^2) 累加
t_mv   = sig2(best(he_kernel, 10))
print("锚点 n=%d（本机实测，取多次最小值并保留 2 位有效数字）:" % n0)
print("  HE 的 O(n^2) 核        %.3f 秒" % t_mv)
print("  Cholesky 分解        %.2f 秒" % t_chol)
print("  完整求逆 O(n^3)      %.2f 秒" % t_inv)
print()
print("%-10s %14s %14s %16s %12s" % ("n","HE 一次 O(n²)","一次 O(n³)","REML(15 次迭代)","GRM 内存"))
for n in (1e4, 5e4, 1e5, 5e5):
    f2=(n/n0)**2; f3=(n/n0)**3
    print("%-10.0e %14s %14s %16s %10.1f GB"
          % (n, fmt(t_mv*f2), fmt(t_inv*f3), fmt(t_inv*f3*15), n*n*8/1024**3))
print()
print("O(n^3)/O(n^2) 耗时比: n=1e5 为 %.0f 倍; n=5e5 为 %.0f 倍"
      % ((1e5/n0)*t_inv/t_mv, (5e5/n0)*t_inv/t_mv))
print()
# Henderson 三法
p, q, N = 500, 5000, 100000
sire = rng.integers(0, q, N)
def m1():
    ni = np.bincount(sire, minlength=q); return ni.sum(), (ni**2).sum()
t_I = sig2(best(m1, 7))
k = p+q
Bm = rng.normal(size=(k,k+20)); C = Bm@Bm.T/k + np.eye(k)
tc = sig2(best(lambda: np.linalg.cholesky(C), 3))
ti = sig2(best(lambda: np.linalg.inv(C), 3))
print("Henderson 三法 (p=%d, q=%d, N=%d, 正规方程阶 %d):" % (p,q,N,k))
print("  方法 I 的全部统计量  %.5f 秒" % t_I)
print("  方法 III Cholesky    %.2f 秒" % tc)
print("  方法 III 完整求逆    %.1f 秒   (约为方法 I 的 %.0f 倍)" % (ti, ti/t_I))
for kk in (1e4, 5e4, 1e5):
    print("  外推 p+q=%-8.0f Cholesky %s, 完整求逆 %s" % (kk, fmt(tc*(kk/k)**3), fmt(ti*(kk/k)**3)))

# ---------------- 正文用值（粗化到可复现的精度） ----------------
print()
print("======== 正文用值 ========")
def r1(x, unit):  # 1 位有效数字风格的粗化
    return x
print("锚点 n=4000: HE 核 %.2f 秒 ; Cholesky %.1f 秒 ; 完整求逆 %.1f 秒"
      % (round(t_mv,2), round(t_chol,1), round(t_inv,1)))
tbl = []
for n in (1e4,5e4,1e5,5e5):
    f2=(n/n0)**2; f3=(n/n0)**3
    tbl.append((n, t_mv*f2, t_inv*f3, t_inv*f3*15, n*n*8/1024**3))
def coarse(x):
    if x < 60:    return "%.1f 秒" % x if x < 10 else "%.0f 秒" % (round(x/1)//1*1)
    if x < 3600:  return "%.1f 分" % (x/60) if x/60 < 10 else "%.0f 分" % (x/60)
    if x < 86400: return "%.1f 小时" % (x/3600) if x/3600 < 10 else "%.0f 小时" % (x/3600)
    return "%.0f 天" % (x/86400)
for n,a,b,c,g in tbl:
    print("  n=%.0e : HE %s | O(n^3) %s | REML(15) %s | GRM %.1f GB"
          % (n, coarse(a), coarse(b), coarse(c), g))
print("  耗时比 n=1e5 约 %d00 倍 ; n=5e5 约 %d000 倍"
      % (round((1e5/n0)*t_inv/t_mv/100), round((5e5/n0)*t_inv/t_mv/1000)))
print("Henderson: 方法I %.4f 秒 ; 方法III Cholesky %.1f 秒 ; 完整求逆 %.1f 秒 ; 约 %d 万倍"
      % (round(t_I,4), round(tc,1), round(ti,1), round(ti/t_I/10000)))
for kk in (1e4,5e4,1e5):
    print("  p+q=%.0e : Cholesky %s ; 完整求逆 %s" % (kk, coarse(tc*(kk/k)**3), coarse(ti*(kk/k)**3)))
