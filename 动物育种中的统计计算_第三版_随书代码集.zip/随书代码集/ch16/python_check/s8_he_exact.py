# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s8_he_exact.py    依赖：numpy, scipy
"""§16.5  HE 的二次型表示、精确抽样方差、与 MIVQUE/REML 的效率对照。"""
import numpy as np
from scipy.optimize import minimize_scalar

SEED = 20251001
rng = np.random.default_rng(SEED)
n, m = 500, 3000
h2, sp2 = 0.40, 1.0
sa2, se2 = h2*sp2, (1-h2)*sp2

frq = rng.uniform(0.05, 0.5, m)
Wg = rng.binomial(2, frq, size=(n, m)).astype(float)
Wc = (Wg - 2*frq)/np.sqrt(2*frq*(1-frq))
G = Wc @ Wc.T / m
evals, U = np.linalg.eigh(G); evals = np.maximum(evals, 0)
Lg = U @ np.diag(np.sqrt(evals)) @ U.T
V = G*sa2 + np.eye(n)*se2
X = np.ones((n,1))
M = np.eye(n) - np.ones((n,n))/n

iu = np.triu_indices(n,1)
g = G[iu]; gb = g.mean(); Sxx = ((g-gb)**2).sum()
print("n=%d m=%d seed=%d ; 非对角 g_ij: 均值 %.3e, SD %.6f, Sxx=%.4f" % (n,m,SEED,gb,g.std(),Sxx))

# --- 乘积 HE 的二次型矩阵 ---
Cm = np.zeros((n,n)); Cm[iu] = (g-gb)/(2*Sxx); Cm = Cm + Cm.T
A_cp = M @ Cm @ M
# --- 差平方 HE 的二次型矩阵 ---
cc = np.zeros((n,n)); cc[iu] = (g-gb)/Sxx; cc = cc + cc.T
L = np.diag(cc.sum(axis=1)) - cc
A_sd = -L/2
# --- MIVQUE(真值)，即 HE 的 GLS 极限 ---
Vi = np.linalg.inv(V)
P = Vi - Vi@X@np.linalg.inv(X.T@Vi@X)@X.T@Vi
Vs = (G, np.eye(n))
S = np.array([[np.trace(P@Va@P@Vb) for Vb in Vs] for Va in Vs])
Sinv = np.linalg.inv(S)
A_mv = Sinv[0,0]*(P@G@P) + Sinv[0,1]*(P@np.eye(n)@P)

print()
print("%-22s %12s %12s %12s %12s" % ("估计量","tr(AG)","tr(A)","1'A1","精确SE"))
rows = []
for nm, A in (("HE 乘积 (OLS)",A_cp), ("HE 差平方 (OLS)",A_sd), ("MIVQUE(真值)=GLS极限",A_mv)):
    se = np.sqrt(2*np.trace(A@V@A@V))
    print("%-22s %12.6f %12.3e %12.3e %12.4f" % (nm, np.trace(A@G), np.trace(A), (X.T@A@X).item(), se))
    rows.append((nm,A,se))
se_ref = rows[2][2]
print()
print("相对效率（以 MIVQUE 为 1）：")
for nm,A,se in rows:
    print("   %-22s SE=%.4f  相对效率=%.4f  SE 相对增幅 %+.1f%%" % (nm, se, (se_ref/se)**2, 100*(se/se_ref-1)))

# --- REML 的渐近 SE（期望信息阵）---
IE = 0.5*S
seR = np.sqrt(np.linalg.inv(IE)[0,0])
print()
print("REML 渐近 SE(σ_a²) = sqrt([½tr(PV_iPV_j)]^{-1}_{11}) = %.4f  (与 MIVQUE 相同: %.4f)" % (seR, se_ref))

# --- 模拟核验精确方差 ---
R = 4000
rng2 = np.random.default_rng(SEED+7)
Y = 5.0 + (Lg @ rng2.normal(0,np.sqrt(sa2),(n,R))) + rng2.normal(0,np.sqrt(se2),(n,R))
def qf(A):
    return np.einsum('ir,ij,jr->r', Y, A, Y)
print()
print("%-22s %10s %10s %10s %10s" % ("估计量","精确SE","模拟SD","模拟均值","负估计率"))
for nm,A,se in rows:
    q = qf(A)
    print("%-22s %10.4f %10.4f %10.4f %10.4f" % (nm, se, q.std(ddof=1), q.mean(), (q<0).mean()))
# REML
ty = U.T@Y; tx = U.T@np.ones(n)
def reml_col(k):
    yk = ty[:,k]
    def negl(h):
        lam = np.maximum(h*evals+(1-h),1e-10)
        a=(tx*tx/lam).sum(); b=(tx*yk/lam).sum(); q=(yk*yk/lam).sum()-b*b/a
        return 0.5*(np.log(lam).sum()+np.log(a)+(n-1)*np.log(q/(n-1)))
    r = minimize_scalar(negl, bounds=(1e-9,0.999999), method='bounded', options={'xatol':1e-9})
    h=r.x; lam=np.maximum(h*evals+(1-h),1e-10)
    a=(tx*tx/lam).sum(); b=(tx*yk/lam).sum(); st2=((yk*yk/lam).sum()-b*b/a)/(n-1)
    return h*st2
rr = np.array([reml_col(k) for k in range(R)])
print("%-22s %10.4f %10.4f %10.4f %10.4f" % ("REML(约束 h≥0)", seR, rr.std(ddof=1), rr.mean(), (rr<=1e-6).mean()))
