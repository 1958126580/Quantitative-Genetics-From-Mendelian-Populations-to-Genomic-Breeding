# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s9b_timing.py    依赖：numpy
import numpy as np, time
rng = np.random.default_rng(1)
n0 = 4000
B = rng.normal(size=(n0, n0+50)); A = B@B.T/n0 + np.eye(n0)
ts = []
for _ in range(3):
    t=time.perf_counter(); np.linalg.cholesky(A); ts.append(time.perf_counter()-t)
tc = min(ts)
ti = []
for _ in range(3):
    t=time.perf_counter(); np.linalg.inv(A); ti.append(time.perf_counter()-t)
tinv = min(ti)
y = rng.normal(size=n0); tq=[]
for _ in range(5):
    t=time.perf_counter(); s=(A*np.outer(y,y)).sum(); tq.append(time.perf_counter()-t)
tq = min(tq)
print("锚点 n=%d（同一台机器、单次实测取 3-5 次最小值）:" % n0)
print("  Cholesky      %.4f 秒" % tc)
print("  求逆(O(n^3))  %.4f 秒" % tinv)
print("  O(n^2) 扫描   %.5f 秒" % tq)
def fmt(s):
    if s<60: return "%.1f 秒"%s
    if s<3600: return "%.1f 分"%(s/60)
    if s<86400: return "%.1f 小时"%(s/3600)
    return "%.1f 天"%(s/86400)
print()
print("%-10s %14s %14s %16s %12s" % ("n","HE 一次 O(n²)","一次 O(n³)","REML(15 次迭代)","GRM 内存"))
for n in (1e4, 5e4, 1e5, 5e5):
    f2=(n/n0)**2; f3=(n/n0)**3
    print("%-10.0e %14s %14s %16s %10.1f GB"
          % (n, fmt(tq*f2), fmt(tinv*f3), fmt(tinv*f3*15), n*n*8/1024**3))
print()
print("比值 O(n^3)/O(n^2) 在 n=1e5: %.0f 倍；n=5e5: %.0f 倍" % ((1e5/n0)*tinv/tq, (5e5/n0)*tinv/tq))
