# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4_henderson.py    依赖：numpy
"""§16.3  Henderson 方法 I 的偏倚反例 + 方法 III 的顺序不唯一。"""
import numpy as np
np.set_printoptions(precision=6, suppress=True)

# ---------- 反例设计：2 个场（固定），4 头公畜（随机），公畜与场部分混杂 ----------
# 场 1: 公畜 1,1,1,2,2      场 2: 公畜 3,3,4,4,4
herd = np.array([0,0,0,0,0, 1,1,1,1,1])
sire = np.array([0,0,0,1,1, 2,2,3,3,3])
N = len(herd); s = 4
X = np.zeros((N,2)); X[np.arange(N), herd] = 1        # 场效应（固定）
Z = np.zeros((N,s)); Z[np.arange(N), sire] = 1
V1 = Z@Z.T; V0 = np.eye(N)
sa2, se2 = 3.0, 9.0
V = V1*sa2 + V0*se2
beta = np.array([10.0, 16.0])                          # 两个场的真实均值，差 6
print("设计: N=%d, 场=%s, 公畜=%s" % (N, herd.tolist(), sire.tolist()))
print("真值: sigma_s^2=%.1f sigma_e^2=%.1f beta=(%.1f,%.1f), 场间差=%.1f"
      % (sa2, se2, beta[0], beta[1], beta[1]-beta[0]))

ni = np.bincount(sire)
one = np.ones((N,1)); H1 = one@np.linalg.pinv(one)
HZ = Z@np.linalg.pinv(Z); HX = X@np.linalg.pinv(X)
HXZ = np.c_[X,Z]; HXZ = HXZ@np.linalg.pinv(HXZ)

# ---------- 方法 I：忽略场，按"只有总均值+公畜"的随机模型套平方和 ----------
A1_SSA = HZ - H1                 # SSA = Σ n_i (ȳ_i - ȳ_..)²
A1_SSE = np.eye(N) - HZ          # SSE
c11 = np.trace(A1_SSA@V1); c10 = np.trace(A1_SSA@V0)
c01 = np.trace(A1_SSE@V1); c00 = np.trace(A1_SSE@V0)
C = np.array([[c11,c10],[c01,c00]])
print()
print("方法 I 的系数矩阵 C (行=SSA,SSE; 列=σ_s²,σ_e²):"); print(C)
# 方法 I 估计量 = C^{-1} (SSA,SSE)'  —— 期望里还有 β'X'AXβ
bq_SSA = float(beta@X.T@A1_SSA@X@beta)
bq_SSE = float(beta@X.T@A1_SSE@X@beta)
print("β'X'A_SSA Xβ = %.6f ;  β'X'A_SSE Xβ = %.6f" % (bq_SSA, bq_SSE))
bias = np.linalg.solve(C, np.array([bq_SSA, bq_SSE]))
print("方法 I 的偏倚 (σ_s², σ_e²) = (%.6f, %.6f)" % (bias[0], bias[1]))
print("  => E(hat σ_s²) = %.4f + %.4f = %.4f  (真值 %.1f, 相对偏倚 %+.1f%%)"
      % (sa2, bias[0], sa2+bias[0], sa2, 100*bias[0]/sa2))

# 蒙特卡罗核验
rng = np.random.default_rng(31415)
R = 200000
Ls = np.linalg.cholesky(V)
acc = np.zeros(2)
B = 20000
for _ in range(R//B):
    Y = X@beta + rng.standard_normal((B,N))@Ls.T
    q = np.c_[np.einsum('ij,jk,ik->i',Y,A1_SSA,Y), np.einsum('ij,jk,ik->i',Y,A1_SSE,Y)]
    acc += q.sum(axis=0)
qbar = acc/R
est = np.linalg.solve(C, qbar)
print("  蒙特卡罗 (R=%d): E(hat σ_s²)=%.4f  E(hat σ_e²)=%.4f" % (R, est[0], est[1]))

# ---------- 方法 III：R(u|β) 自动无偏 ----------
A3_u = HXZ - HX                  # R(u | β)
A3_e = np.eye(N) - HXZ           # 残差
C3 = np.array([[np.trace(A3_u@V1), np.trace(A3_u@V0)],
               [np.trace(A3_e@V1), np.trace(A3_e@V0)]])
print()
print("方法 III 的系数矩阵 C3:"); print(C3)
print("β'X'A3_u Xβ = %.3e ; β'X'A3_e Xβ = %.3e  (均为 0 => 无偏)"
      % (float(beta@X.T@A3_u@X@beta), float(beta@X.T@A3_e@X@beta)))
C3i = np.linalg.inv(C3)
A3hat = C3i[0,0]*A3_u + C3i[0,1]*A3_e
print("方法 III 的 σ_s² 估计量: Var = %.4f, SE = %.4f" % (2*np.trace(A3hat@V@A3hat@V), np.sqrt(2*np.trace(A3hat@V@A3hat@V))))
print("自由度: r(X,Z)=%d, r(X)=%d, N-r(X,Z)=%d" % (np.linalg.matrix_rank(np.c_[X,Z]), np.linalg.matrix_rank(X), N-np.linalg.matrix_rank(np.c_[X,Z])))
