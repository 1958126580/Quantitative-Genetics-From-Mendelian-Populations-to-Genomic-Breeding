# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s14_cost_table.py    依赖：仅标准库
"""正文两张计算量表：锚点取本机实测的量级（固定值），外推完全确定、可复现。
   本机多次实测 (n=4000)：HE 的 O(n^2) 核 0.052-0.054 s；Cholesky 0.45-0.49 s；完整求逆 2.07-2.10 s
   本机多次实测 (k=5500)：Cholesky 0.91-1.00 s；完整求逆 4.69-4.94 s；方法 I 统计量 0.00012-0.00015 s
"""
def fmt(x):
    if x < 60:    return ("%.1f 秒" % x) if x < 10 else ("%.0f 秒" % x)
    if x < 3600:  return ("%.1f 分" % (x/60)) if x/60 < 10 else ("%.0f 分" % (x/60))
    if x < 86400: return ("%.1f 小时" % (x/3600)) if x/3600 < 10 else ("%.0f 小时" % (x/3600))
    return "%.0f 天" % (x/86400)

# ---- 表 1：HE 与 GREML ----
n0, t_he, t_chol, t_inv = 4000, 0.05, 0.48, 2.1
print("表 1 锚点 n=%d: HE 核 %.2f 秒, Cholesky %.2f 秒, 完整求逆 %.1f 秒" % (n0, t_he, t_chol, t_inv))
print("%-10s %12s %12s %14s %12s" % ("n","HE O(n²)","一次 O(n³)","REML 15 次","GRM 内存"))
for n in (1e4, 5e4, 1e5, 5e5):
    f2, f3 = (n/n0)**2, (n/n0)**3
    print("%-10.0e %12s %12s %14s %10.1f GB"
          % (n, fmt(t_he*f2), fmt(t_inv*f3), fmt(t_inv*f3*15), n*n*8/1024**3))
print("耗时比 O(n³)/O(n²): n=1e5 为 %.0f 倍, n=5e5 为 %.0f 倍"
      % ((1e5/n0)*t_inv/t_he, (5e5/n0)*t_inv/t_he))

# ---- 表 2：Henderson 三法 ----
k0, t_I, tc, ti = 5500, 0.00012, 0.98, 4.8
print()
print("表 2 锚点 p+q=%d: 方法I %.5f 秒, Cholesky %.2f 秒, 完整求逆 %.1f 秒, 倍数 %.0f"
      % (k0, t_I, tc, ti, ti/t_I))
print("%-10s %12s %12s" % ("p+q","Cholesky","完整求逆"))
for k in (1e4, 5e4, 1e5):
    f3 = (k/k0)**3
    print("%-10.0e %12s %12s" % (k, fmt(tc*f3), fmt(ti*f3)))
