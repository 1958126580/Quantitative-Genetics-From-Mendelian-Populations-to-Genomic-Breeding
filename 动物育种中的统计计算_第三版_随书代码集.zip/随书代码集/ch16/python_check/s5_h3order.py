# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5_h3order.py    依赖：numpy
"""§16.3  方法 III 的顺序不唯一：两个随机因子，两种拟合顺序给出不同估计量。"""
import numpy as np
rng = np.random.default_rng(777)

# 模型 y = X beta(2 场) + Z1 u1(5 公畜) + Z2 u2(6 年份) + e ，不平衡且交叉
herd = np.array([0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,1,0,1,0,1,1,0])
sire = np.array([0,0,1,1,2,2,3, 0,1,1,2,3,3,4,4,4, 2,0,3,1,4,2,0,4])
year = np.array([0,1,0,2,1,3,2, 0,1,3,4,2,5,0,3,5, 5,4,1,2,3,4,5,2])
N = len(herd)
X = np.zeros((N,2)); X[np.arange(N),herd]=1
Z1 = np.zeros((N,5)); Z1[np.arange(N),sire]=1
Z2 = np.zeros((N,6)); Z2[np.arange(N),year]=1
V1, V2, V0 = Z1@Z1.T, Z2@Z2.T, np.eye(N)
s1,s2,s0 = 2.0, 1.0, 6.0
V = V1*s1 + V2*s2 + V0*s0

def H(*mats):
    M = np.c_[tuple(mats)]
    return M@np.linalg.pinv(M)
HX   = H(X)
HX1  = H(X,Z1)
HX2  = H(X,Z2)
HX12 = H(X,Z1,Z2)
I = np.eye(N)

def solve(As, label):
    C = np.array([[np.trace(A@Vi) for Vi in (V1,V2,V0)] for A in As])
    bq = [float(np.ones(2)@np.zeros((2,)))]  # 不用
    print("%s  系数矩阵 C =" % label); print(np.round(C,4))
    Ci = np.linalg.inv(C)
    out = []
    for k in range(3):
        Ak = sum(Ci[k,j]*As[j] for j in range(3))
        v = 2*np.trace(Ak@V@Ak@V)
        out.append((v, Ak))
    print("   SE: sigma_s^2=%.4f  sigma_y^2=%.4f  sigma_e^2=%.4f"
          % tuple(np.sqrt([o[0] for o in out])))
    return C, out

print("N=%d, 2 场(固定), 5 公畜, 6 年份; 真值 s1=%.1f s2=%.1f s0=%.1f" % (N,s1,s2,s0))
print("秩: r(X)=%d r(X,Z1)=%d r(X,Z2)=%d r(X,Z1,Z2)=%d"
      % tuple(np.linalg.matrix_rank(m) for m in (X, np.c_[X,Z1], np.c_[X,Z2], np.c_[X,Z1,Z2])))
print()
# 顺序 A: R(u1|beta), R(u2|beta,u1), 残差
As_A = [HX1-HX, HX12-HX1, I-HX12]
CA, oA = solve(As_A, "顺序 A: R(u1|β), R(u2|β,u1), SSE")
print()
# 顺序 B: R(u2|beta), R(u1|beta,u2), 残差
As_B = [HX12-HX2, HX2-HX, I-HX12]
CB, oB = solve(As_B, "顺序 B: R(u1|β,u2), R(u2|β), SSE")
print()
# 在同一组数据上比较两种顺序的数值估计
u1 = rng.normal(0,np.sqrt(s1),5); u2 = rng.normal(0,np.sqrt(s2),6)
e = rng.normal(0,np.sqrt(s0),N)
beta = np.array([20.0, 24.0])
y = X@beta + Z1@u1 + Z2@u2 + e
for lab, As, C in (("顺序 A", As_A, CA), ("顺序 B", As_B, CB)):
    q = np.array([y@A@y for A in As])
    est = np.linalg.solve(C, q)
    print("%s  二次型 = %s" % (lab, np.round(q,4)))
    print("        估计 (σ_s²,σ_y²,σ_e²) = %s" % np.round(est,4))
print()
print("两种顺序在同一数据上给出不同估计 —— 这就是方法 III 的不唯一性。")

# 多次重复：两种顺序都无偏，但方差不同
R=4000
L = np.linalg.cholesky(V)
EA=np.empty((R,3)); EB=np.empty((R,3))
Y = X@beta + rng.standard_normal((R,N))@L.T
for lab,As,C,E in (("A",As_A,CA,EA),("B",As_B,CB,EB)):
    Q = np.column_stack([np.einsum('ij,jk,ik->i',Y,A,Y) for A in As])
    E[:] = np.linalg.solve(C, Q.T).T
print("重复 %d 次（seed 777）:" % R)
print("%-8s %9s %9s %9s" % ("", "σ_s²", "σ_y²", "σ_e²"))
print("%-8s %9.1f %9.1f %9.1f" % ("真值", s1,s2,s0))
for lab,E in (("顺序A 均值",EA),("顺序B 均值",EB)):
    print("%-8s %9.4f %9.4f %9.4f" % (lab, *E.mean(axis=0)))
for lab,E in (("顺序A  SD",EA),("顺序B  SD",EB)):
    print("%-8s %9.4f %9.4f %9.4f" % (lab, *E.std(axis=0,ddof=1)))
print("负估计频率 顺序A: σ_s² %.4f σ_y² %.4f" % ((EA[:,0]<0).mean(),(EA[:,1]<0).mean()))
print("负估计频率 顺序B: σ_s² %.4f σ_y² %.4f" % ((EB[:,0]<0).mean(),(EB[:,1]<0).mean()))
