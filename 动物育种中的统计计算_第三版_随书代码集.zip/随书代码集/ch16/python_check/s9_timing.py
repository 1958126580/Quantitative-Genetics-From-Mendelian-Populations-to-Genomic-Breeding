# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s9_timing.py    依赖：numpy
"""§16.5  HE O(n^2) 与 GREML O(n^3) 的实测与外推。"""
import numpy as np, time, platform, os

print("平台:", platform.platform())
print("numpy:", np.__version__, " BLAS 线程:", os.environ.get('OMP_NUM_THREADS','默认'))
rng = np.random.default_rng(1)

# ---- 实测 O(n^3): 特征分解 + Cholesky ----
print()
print("%-8s %14s %14s %14s" % ("n","eigh 秒","chol 秒","n^2 遍历 秒"))
data = []
for n in (500, 1000, 2000, 4000):
    B = rng.normal(size=(n, n+50)); A = B@B.T/n + np.eye(n)
    t0=time.perf_counter(); np.linalg.eigh(A); t1=time.perf_counter()
    t2=time.perf_counter(); np.linalg.cholesky(A); t3=time.perf_counter()
    y = rng.normal(size=n)
    t4=time.perf_counter()
    for _ in range(3):
        s = (A*np.outer(y,y)).sum()          # 典型 O(n^2) 的 HE 运算
    t5=time.perf_counter()
    data.append((n, t1-t0, t3-t2, (t5-t4)/3))
    print("%-8d %14.5f %14.5f %14.5f" % data[-1])

# ---- 外推 ----
n4, e4, c4, q4 = data[-1]
print()
print("以 n=%d 的实测为锚点外推（eigh %.4f s, chol %.4f s, O(n^2) 扫描 %.5f s）:" % (n4,e4,c4,q4))
print("%-12s %16s %16s %16s" % ("n","eigh 一次","chol 一次","O(n^2) 一次"))
for n in (1e4, 1e5, 5e5, 1e6):
    f3 = (n/n4)**3; f2 = (n/n4)**2
    def fmt(s):
        if s < 60: return "%.2f 秒" % s
        if s < 3600: return "%.1f 分" % (s/60)
        if s < 86400: return "%.2f 小时" % (s/3600)
        return "%.2f 天" % (s/86400)
    print("%-12.0e %16s %16s %16s" % (n, fmt(e4*f3), fmt(c4*f3), fmt(q4*f2)))

print()
print("REML 需要每次迭代一次 O(n^3) 分解；设 %d 次迭代：" % 15)
for n in (1e5, 5e5):
    tot = e4*(n/n4)**3*15
    print("  n=%.0e: 15 次 eigh/分解 ≈ %.1f 天（单次 %.2f 小时）" % (n, tot/86400, e4*(n/n4)**3/3600))
print()
print("内存: 存 n x n 双精度矩阵")
for n in (1e4,1e5,5e5,1e6):
    print("  n=%-9.0e  %8.2f GB" % (n, n*n*8/1024**3))
