# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_unbal_ems.py    依赖：numpy
"""§16.2 三、不平衡设计下期望均方不唯一的小反例。"""
import numpy as np
ni = np.array([2,3,5,10]); s=len(ni); N=ni.sum()
Z = np.zeros((N,s)); r=0
for i,k in enumerate(ni): Z[r:r+k,i]=1; r+=k
X = np.ones((N,1))
V1 = Z@Z.T; V0 = np.eye(N)
HX = X@np.linalg.pinv(X); HZ = Z@np.linalg.pinv(Z)

A_w = HZ - HX                                  # 加权：SSA_w = sum n_i (ybar_i - ybar_..)^2
Zb = Z/ni                                       # 组均值算子
Jb = np.eye(s)-np.ones((s,s))/s
A_u = Zb.T.T  # placeholder
A_u = (Zb).T.T
A_u = ( (Z/ni).T ).T
M = (Z/ni).T                                    # s x N, 行 i 给出 ybar_i
A_u = M.T @ Jb @ M                              # 未加权：SSA_u = sum (ybar_i - mean_i ybar_i)^2
A_e = np.eye(N)-HZ

print("n_i =", ni.tolist(), " s=%d  N=%d  sum n_i^2 = %d" % (s,N,(ni**2).sum()))
print()
print("%-28s %12s %12s" % ("平方和", "sigma_a^2 系数", "sigma_e^2 系数"))
for nm,A in [("SSA_w = Σ n_i(ȳ_i-ȳ_..)²", A_w), ("SSA_u = Σ(ȳ_i-ȳ̄)²", A_u), ("SSE", A_e)]:
    print("%-28s %12.6f %12.6f" % (nm, np.trace(A@V1), np.trace(A@V0)))
print()
print("校验: N - Σn_i²/N = %.4f" % (N-(ni**2).sum()/N))
print("      Σ(1/n_i) 相关量: (s-1) 与 Σ1/n_i - (1/s)Σ1/n_i = %.6f" % ((1-1/s)*np.sum(1/ni)))

# 两个无偏估计量
def calib(A1,A2):
    Mx = np.array([[np.trace(A1@V1),np.trace(A2@V1)],[np.trace(A1@V0),np.trace(A2@V0)]])
    ab = np.linalg.solve(Mx, np.array([1.0,0.0])); return ab[0]*A1+ab[1]*A2, ab
Aw_hat, abw = calib(A_w, A_e)
Au_hat, abu = calib(A_u, A_e)
sa2, se2 = 2.0, 8.0
V = V1*sa2+V0*se2
print()
print("两个都无偏的 σ_a² 估计量在真值 σ_a²=%.1f, σ_e²=%.1f 下的抽样方差：" % (sa2,se2))
for nm,A in [("基于 SSA_w", Aw_hat), ("基于 SSA_u", Au_hat)]:
    v = 2*np.trace(A@V@A@V)
    print("  %-12s Var=%8.4f  SE=%7.4f" % (nm, v, np.sqrt(v)))
vw = 2*np.trace(Aw_hat@V@Aw_hat@V); vu = 2*np.trace(Au_hat@V@Au_hat@V)
print("  相对效率 SSA_u / SSA_w = %.4f" % (vw/vu))
# 具体估计式
print()
print("估计式: hat sigma_a^2 = [SSA_w - %.6f * MSE_like] / %.6f  (加权)" % (abw[1]/abw[0]*-1 if False else 0, 1/abw[0]))
print("  a_w=%.8f b_w=%.8f ; a_u=%.8f b_u=%.8f" % (abw[0],abw[1],abu[0],abu[1]))
