# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5b_pick.py    依赖：numpy
import numpy as np
herd = np.array([0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,1,0,1,0,1,1,0])
sire = np.array([0,0,1,1,2,2,3, 0,1,1,2,3,3,4,4,4, 2,0,3,1,4,2,0,4])
year = np.array([0,1,0,2,1,3,2, 0,1,3,4,2,5,0,3,5, 5,4,1,2,3,4,5,2])
N=len(herd)
X=np.zeros((N,2)); X[np.arange(N),herd]=1
Z1=np.zeros((N,5)); Z1[np.arange(N),sire]=1
Z2=np.zeros((N,6)); Z2[np.arange(N),year]=1
V1,V2,V0=Z1@Z1.T,Z2@Z2.T,np.eye(N)
s1,s2,s0=2.0,1.0,6.0
def H(*m):
    M=np.c_[tuple(m)]; return M@np.linalg.pinv(M)
HX,HX1,HX2,HX12=H(X),H(X,Z1),H(X,Z2),H(X,Z1,Z2); I=np.eye(N)
AsA=[HX1-HX,HX12-HX1,I-HX12]; AsB=[HX12-HX2,HX2-HX,I-HX12]
CA=np.array([[np.trace(A@Vi) for Vi in (V1,V2,V0)] for A in AsA])
CB=np.array([[np.trace(A@Vi) for Vi in (V1,V2,V0)] for A in AsB])
beta=np.array([20.0,24.0])
for sd in range(1,80):
    rng=np.random.default_rng(sd)
    y=X@beta+Z1@rng.normal(0,np.sqrt(s1),5)+Z2@rng.normal(0,np.sqrt(s2),6)+rng.normal(0,np.sqrt(s0),N)
    qA=np.array([y@A@y for A in AsA]); qB=np.array([y@A@y for A in AsB])
    eA=np.linalg.solve(CA,qA); eB=np.linalg.solve(CB,qB)
    if min(eA.min(),eB.min())>0.15 and abs(eA[0]-eB[0])>0.35:
        print(sd, np.round(eA,4), np.round(eB,4), np.round(qA,4), np.round(qB,4))
