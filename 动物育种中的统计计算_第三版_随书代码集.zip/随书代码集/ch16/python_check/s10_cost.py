# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s10_cost.py    依赖：numpy
"""§16.3  三法计算量的量化；§16.5 加权 HE 的实际效果。"""
import numpy as np, time
rng = np.random.default_rng(42)

# ---------- Henderson 三法的计算量 ----------
print("=== Henderson 三法计算量（p=500 场, q=5000 公畜, N=100000）===")
p, q, N = 500, 5000, 100000
herd = rng.integers(0,p,N); sire = rng.integers(0,q,N)
t=time.perf_counter()
n_i = np.bincount(sire, minlength=q)
stat = (n_i.sum(), (n_i**2).sum())
t_m1 = time.perf_counter()-t
print("方法 I 需要的全部统计量（Σn_i, Σn_i²）: %.5f 秒" % t_m1)

# 方法 III：需要对 [X Z] 建立并求解正规方程（阶 p+q），并求其逆以算迹
k = p+q
t=time.perf_counter()
Bm = rng.normal(size=(k,k+20)); C = Bm@Bm.T/k + np.eye(k)
t_build = time.perf_counter()-t
t=time.perf_counter(); np.linalg.cholesky(C); t_ch = time.perf_counter()-t
t=time.perf_counter(); Ci = np.linalg.inv(C); t_inv = time.perf_counter()-t
print("方法 III 的正规方程阶数 p+q = %d" % k)
print("  Cholesky 分解 %.4f 秒；完整求逆（算迹所需）%.4f 秒" % (t_ch, t_inv))
print("  比值 方法III / 方法I ≈ %.0f 倍" % (t_inv/max(t_m1,1e-9)))
for kk in (1e4, 5e4, 1e5):
    f = (kk/k)**3
    s = t_inv*f
    u = "%.1f 秒"%s if s<60 else ("%.1f 分"%(s/60) if s<3600 else ("%.1f 小时"%(s/3600) if s<86400 else "%.1f 天"%(s/86400)))
    print("  外推 p+q=%-8.0f 完整求逆 %s" % (kk, u))

# ---------- 加权 HE 的实际效果 ----------
print()
print("=== 加权 HE：对角权重 1/(1+(h² g_ij)²) 的实际效果 ===")
SEED=20251001
r2 = np.random.default_rng(SEED)
n,m = 500,3000; h2=0.40
frq = r2.uniform(0.05,0.5,m)
Wg = r2.binomial(2,frq,size=(n,m)).astype(float)
Wc = (Wg-2*frq)/np.sqrt(2*frq*(1-frq)); G = Wc@Wc.T/m
ev,U = np.linalg.eigh(G); ev=np.maximum(ev,0); Lg = U@np.diag(np.sqrt(ev))@U.T
iu = np.triu_indices(n,1); g = G[iu]
print("权重范围: min=%.8f max=%.8f (极差 %.2e)" % ((1/(1+(h2*g)**2)).min(), (1/(1+(h2*g)**2)).max(), np.ptp(1/(1+(h2*g)**2))))
def cp(y,w=None):
    yc=y-y.mean(); pp=np.outer(yc,yc)[iu]
    if w is None: w=np.ones_like(g)
    sw=w.sum(); xb=(w*g).sum()/sw; yb=(w*pp).sum()/sw
    return (w*(g-xb)*(pp-yb)).sum()/((w*(g-xb)**2).sum())
R=500; r3=np.random.default_rng(SEED+7)
d=np.empty(R); a=np.empty(R); b=np.empty(R)
for i in range(R):
    y = 5.0 + Lg@r3.normal(0,np.sqrt(h2),n) + r3.normal(0,np.sqrt(1-h2),n)
    a[i]=cp(y); b[i]=cp(y,1/(1+(h2*g)**2)); d[i]=abs(a[i]-b[i])
print("500 次重复: 未加权 SD=%.6f  对角加权 SD=%.6f  最大绝对差 %.2e" % (a.std(ddof=1), b.std(ddof=1), d.max()))
print("=> 当所有 |g_ij| 都很小时，对角加权几乎没有作用。")
