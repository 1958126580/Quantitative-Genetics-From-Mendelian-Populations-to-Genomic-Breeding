# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s6_mivque.py    依赖：numpy
"""§16.4  MIVQUE = REML 的一次 Fisher 得分迭代；MIVQUE(0) 迭代收敛到 REML。"""
import numpy as np
np.set_printoptions(precision=6, suppress=True)
rng = np.random.default_rng(160404)

N, q, p = 60, 12, 3
X = np.c_[np.ones(N), rng.normal(size=(N,2))]
grp = rng.integers(0, q, N)
Z = np.zeros((N,q)); Z[np.arange(N), grp] = 1
V1, V0 = Z@Z.T, np.eye(N)
Vs = (V1, V0)
true = np.array([2.5, 7.5])
beta = np.array([10.0, 1.5, -0.8])
y = X@beta + Z@rng.normal(0, np.sqrt(true[0]), q) + rng.normal(0, np.sqrt(true[1]), N)

def Pmat(th):
    V = V1*th[0] + V0*th[1]
    Vi = np.linalg.inv(V)
    return Vi - Vi@X@np.linalg.inv(X.T@Vi@X)@X.T@Vi

def mivque(th0):
    P = Pmat(th0)
    S = np.array([[np.trace(P@Vi@P@Vj) for Vj in Vs] for Vi in Vs])
    qv = np.array([y@P@Vi@P@y for Vi in Vs])
    return np.linalg.solve(S, qv), S, qv, P

def fisher_step(th0):
    P = Pmat(th0)
    S = np.array([[np.trace(P@Vi@P@Vj) for Vj in Vs] for Vi in Vs])
    t = np.array([np.trace(P@Vi) for Vi in Vs])
    qv = np.array([y@P@Vi@P@y for Vi in Vs])
    score = 0.5*(qv - t)          # dl_R/dtheta
    IE = 0.5*S                    # 期望信息
    return th0 + np.linalg.solve(IE, score), t, S@th0

print("=== 1. MIVQUE(θ0) 与 REML 的一步 Fisher 得分迭代等价 ===")
for th0 in (np.array([1e-8, 1.0]), np.array([1.0, 1.0]), np.array([2.5, 7.5]), np.array([5.0, 3.0])):
    m,S,qv,_ = mivque(th0)
    f,t,Sth = fisher_step(th0)
    print("θ0=%-16s MIVQUE=%s  Fisher一步=%s  差=%.3e"
          % (np.array2string(th0, precision=3), np.array2string(m, precision=6),
             np.array2string(f, precision=6), np.abs(m-f).max()))
    print("    校验 S θ0 = tr(PV_i):  Sθ0=%s  tr(PV)=%s  差=%.3e"
          % (np.array2string(Sth, precision=4), np.array2string(t, precision=4), np.abs(Sth-t).max()))

print()
print("=== 2. MIVQUE(0) 及其迭代 ===")
th = np.array([1e-10, 1.0])
m0,_,_,_ = mivque(th)
print("MIVQUE(0) 估计 = %s   (真值 %s)" % (np.array2string(m0, precision=6), true))
th = m0.copy()
for it in range(1, 13):
    th_new,_,_,_ = mivque(th)
    d = np.abs(th_new-th).max()
    print("  第 %2d 次迭代: θ = %s   变化 %.3e" % (it, np.array2string(th_new, precision=6), d))
    th = th_new
    if d < 1e-12: break
# REML 直接求解（Fisher 得分从另一个起点出发）
th2 = np.array([1.0, 1.0])
for _ in range(200):
    P = Pmat(th2)
    S = np.array([[np.trace(P@Vi@P@Vj) for Vj in Vs] for Vi in Vs])
    t = np.array([np.trace(P@Vi) for Vi in Vs])
    qv = np.array([y@P@Vi@P@y for Vi in Vs])
    step = np.linalg.solve(0.5*S, 0.5*(qv-t))
    th2 = th2 + step
    if np.abs(step).max() < 1e-13: break
print("独立求得的 REML 解 = %s" % np.array2string(th2, precision=6))
print("REML 方程残差 tr(PV_i)-y'PV_iPy = %s" % np.array2string(
    np.array([np.trace(Pmat(th2)@Vi) for Vi in Vs]) - np.array([y@Pmat(th2)@Vi@Pmat(th2)@y for Vi in Vs]), precision=3))
print("迭代 MIVQUE 与 REML 的差 = %.3e" % np.abs(th-th2).max())

print()
print("=== 3. 不同先验下 MIVQUE 的抽样方差（真值 θ=%s）===" % true)
Vtrue = V1*true[0] + V0*true[1]
print("%-22s %10s %10s %10s" % ("先验 θ0", "SE(σ_a²)", "SE(σ_e²)", "相对效率"))
Pt = Pmat(true)
St = np.array([[np.trace(Pt@Vi@Pt@Vj) for Vj in Vs] for Vi in Vs])
Sti = np.linalg.inv(St)
A_ref = Sti[0,0]*(Pt@V1@Pt)+Sti[0,1]*(Pt@V0@Pt)
vref = 2*np.trace(A_ref@Vtrue@A_ref@Vtrue)
for lab, th0 in (("(0, 1)  [MIVQUE(0)]", np.array([1e-10,1.0])),
                 ("(1, 1)", np.array([1.0,1.0])),
                 ("(2.5, 7.5) [真值]", true),
                 ("(10, 2)  [很差的先验]", np.array([10.0,2.0]))):
    P = Pmat(th0)
    S = np.array([[np.trace(P@Vi@P@Vj) for Vj in Vs] for Vi in Vs])
    Si = np.linalg.inv(S)
    As = [Si[k,0]*(P@V1@P)+Si[k,1]*(P@V0@P) for k in (0,1)]
    ses = [np.sqrt(2*np.trace(A@Vtrue@A@Vtrue)) for A in As]
    v0 = 2*np.trace(As[0]@Vtrue@As[0]@Vtrue)
    print("%-22s %10.4f %10.4f %10.4f" % (lab, ses[0], ses[1], vref/v0))
