# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s7_he.py    依赖：numpy, scipy
"""§16.5  HE 回归三种形式与 REML 的模拟对比。"""
import numpy as np
from scipy.optimize import minimize_scalar

SEED = 20251001
rng = np.random.default_rng(SEED)
n, m = 500, 3000
h2_true, sp2 = 0.40, 1.0

# ---- 基因组关系矩阵（固定，全部重复共用）----
frq = rng.uniform(0.05, 0.5, m)
Wg = rng.binomial(2, frq, size=(n, m)).astype(float)
Wc = (Wg - 2*frq) / np.sqrt(2*frq*(1-frq))
G = Wc @ Wc.T / m
print("n=%d 个体, m=%d 个标记, 种子 %d" % (n, m, SEED))
print("G: 对角均值 %.4f, 非对角均值 %.6f, 非对角 SD %.6f"
      % (np.diag(G).mean(), G[np.triu_indices(n,1)].mean(), G[np.triu_indices(n,1)].std()))

evals, U = np.linalg.eigh(G)
evals = np.maximum(evals, 0)
Lg = U @ np.diag(np.sqrt(evals)) @ U.T      # G^{1/2}

iu = np.triu_indices(n, 1)
gij = G[iu]
x_c = gij - gij.mean()
Sxx = (x_c**2).sum()
one = np.ones(n)

def he_sd(y):
    """差平方 HE: (y_i-y_j)^2 对 g_ij 回归, sigma_a^2 = -b/2"""
    d = (y[:,None]-y[None,:])**2
    yy = d[iu]
    b = (x_c*(yy-yy.mean())).sum()/Sxx
    return -b/2

def he_cp(y):
    """乘积 HE: (y_i-ybar)(y_j-ybar) 对 g_ij 回归, sigma_a^2 = b"""
    yc = y - y.mean()
    pp = np.outer(yc, yc)[iu]
    return (x_c*(pp-pp.mean())).sum()/Sxx

W_w = None
def he_w(y, h2w):
    """加权乘积 HE: 权重 1/(1+rho_ij^2), rho_ij = h2w*g_ij"""
    yc = y - y.mean()
    pp = np.outer(yc, yc)[iu]
    w = 1.0/(1.0 + (h2w*gij)**2)
    sw = w.sum(); xb = (w*gij).sum()/sw; yb = (w*pp).sum()/sw
    return (w*(gij-xb)*(pp-yb)).sum()/((w*(gij-xb)**2).sum())

def reml(y):
    """一维 profile REML: V = st2 * (h*G + (1-h)*I), 固定效应只有截距"""
    ty = U.T@y; tx = U.T@one
    def negl(h):
        lam = h*evals + (1-h)
        lam = np.maximum(lam, 1e-10)
        a = (tx*tx/lam).sum()
        b = (tx*ty/lam).sum()
        q = (ty*ty/lam).sum() - b*b/a
        return 0.5*(np.log(lam).sum() + np.log(a) + (n-1)*np.log(q/(n-1)))
    r = minimize_scalar(negl, bounds=(1e-8, 0.999999), method='bounded',
                        options={'xatol':1e-9})
    h = r.x
    lam = h*evals + (1-h)
    a = (tx*tx/lam).sum(); b = (tx*ty/lam).sum()
    st2 = ((ty*ty/lam).sum() - b*b/a)/(n-1)
    return h*st2, (1-h)*st2, h

# ---- 单次演示 ----
g = Lg @ rng.normal(0, np.sqrt(h2_true*sp2), n)
e = rng.normal(0, np.sqrt((1-h2_true)*sp2), n)
y = 5.0 + g + e
print()
print("=== 单次实现（真值 sigma_a^2=%.2f, sigma_e^2=%.2f, h^2=%.2f）===" % (h2_true*sp2, (1-h2_true)*sp2, h2_true))
print("  HE 差平方  : sigma_a^2 = %.4f" % he_sd(y))
print("  HE 乘积    : sigma_a^2 = %.4f" % he_cp(y))
print("  HE 加权    : sigma_a^2 = %.4f" % he_w(y, h2_true))
ra, re_, rh = reml(y)
print("  REML       : sigma_a^2 = %.4f, sigma_e^2 = %.4f, h^2 = %.4f" % (ra, re_, rh))
print("  (差平方与乘积在同一数据上的差: %.3e)" % abs(he_sd(y)-he_cp(y)))

# ---- R 次重复 ----
R = 500
rng2 = np.random.default_rng(SEED+7)
res = np.empty((R,4))
for r in range(R):
    gg = Lg @ rng2.normal(0, np.sqrt(h2_true*sp2), n)
    ee = rng2.normal(0, np.sqrt((1-h2_true)*sp2), n)
    yy = 5.0 + gg + ee
    v = np.var(yy, ddof=1)
    res[r,0] = he_sd(yy); res[r,1] = he_cp(yy); res[r,2] = he_w(yy, h2_true)
    res[r,3] = reml(yy)[0]
print()
print("=== %d 次重复（种子 %d）：sigma_a^2 的估计（真值 %.2f）===" % (R, SEED+7, h2_true*sp2))
lab = ["HE 差平方(OLS)","HE 乘积(OLS)","HE 加权","REML"]
print("%-16s %10s %10s %10s %10s" % ("方法","均值","SD","相对SE","负估计"))
sd_reml = res[:,3].std(ddof=1)
for k in range(4):
    print("%-16s %10.4f %10.4f %10.3f %10.3f"
          % (lab[k], res[:,k].mean(), res[:,k].std(ddof=1),
             res[:,k].std(ddof=1)/sd_reml, (res[:,k]<0).mean()))
print()
print("差平方 HE 与乘积 HE 在 %d 次重复上的最大差异: %.3e" % (R, np.abs(res[:,0]-res[:,1]).max()))
print("相关系数 corr(HE乘积, REML) = %.4f" % np.corrcoef(res[:,1],res[:,3])[0,1])
