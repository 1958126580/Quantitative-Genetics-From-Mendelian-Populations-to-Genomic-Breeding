# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s11_varhat.py    依赖：numpy
"""§16.1  矩估计量抽样方差的一般公式 Var(θ̂)=C^{-1} Σ C^{-T}, Σ_jk=2tr(A_jVA_kV)
   与平衡 ANOVA 的封闭式对照。"""
import numpy as np
s, n0 = 25, 8; N = s*n0
sa2, se2 = 2.25, 33.75
Z = np.kron(np.eye(s), np.ones((n0,1))); X = np.ones((N,1))
V1, V0 = Z@Z.T, np.eye(N); V = V1*sa2+V0*se2
HX = X@np.linalg.pinv(X); HZ = Z@np.linalg.pinv(Z)
A = [ (HZ-HX)/(s-1), (np.eye(N)-HZ)/(N-s) ]     # MSA, MSE
C = np.array([[np.trace(Ai@Vj) for Vj in (V1,V0)] for Ai in A])
Sg = np.array([[2*np.trace(Ai@V@Aj@V) for Aj in A] for Ai in A])
Ci = np.linalg.inv(C)
Vth = Ci@Sg@Ci.T
print("C ="); print(np.round(C,6))
print("Σ (=2tr(A_jVA_kV)) ="); print(np.round(Sg,6))
print("Var(θ̂) ="); print(np.round(Vth,6))
print("SE(σ_a²)=%.6f  SE(σ_e²)=%.6f  Cov=%.6f  corr=%.4f"
      % (np.sqrt(Vth[0,0]), np.sqrt(Vth[1,1]), Vth[0,1], Vth[0,1]/np.sqrt(Vth[0,0]*Vth[1,1])))
EMSA = se2+n0*sa2
closed_a = (2*EMSA**2/(s-1) + 2*se2**2/(N-s))/n0**2
print("封闭式 Var(σ̂_a²) = [2(σ_e²+nσ_a²)²/(s-1) + 2σ_e⁴/(s(n-1))]/n² = %.6f  (SE=%.6f)" % (closed_a, np.sqrt(closed_a)))
print("封闭式 Cov(σ̂_a²,σ̂_e²) = -2σ_e⁴/[s(n-1)n] = %.6f" % (-2*se2**2/((N-s)*n0)))
# delta 法 h^2
sp = sa2+se2; d = np.array([4*se2/sp**2, -4*sa2/sp**2])
print("delta 法 SE(ĥ²) = %.6f" % np.sqrt(d@Vth@d))
