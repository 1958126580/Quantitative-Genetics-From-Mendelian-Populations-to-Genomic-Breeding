# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_anova.py    依赖：numpy, scipy
"""§16.2  平衡单因子（公畜模型）完整数值算例 + 1000 次重复。"""
import numpy as np
from scipy import stats

SEED = 20240316
s, n0 = 25, 8                 # 25 头公畜, 每头 8 个半同胞后代
N = s * n0
mu_true, h2_true = 30.0, 0.25
sp2 = 36.0
sa2 = h2_true/4*sp2           # 公畜方差 = h^2/4 * sigma_P^2
se2 = sp2 - sa2
print("真值: mu=%.1f  sigma_P^2=%.1f  h^2=%.2f  sigma_s^2=%.4f  sigma_e^2=%.4f"
      % (mu_true, sp2, h2_true, sa2, se2))
print("设计: s=%d 公畜 x n=%d 后代 = N=%d 条记录, 随机种子 %d" % (s, n0, N, SEED))

def gen(rng):
    a = rng.normal(0, np.sqrt(sa2), s)
    e = rng.normal(0, np.sqrt(se2), (s, n0))
    return mu_true + a[:, None] + e

def anova(Y):
    gm = Y.mean(); gi = Y.mean(axis=1)
    SSA = n0*((gi-gm)**2).sum(); SSE = ((Y-gi[:,None])**2).sum()
    dfa, dfe = s-1, s*(n0-1)
    MSA, MSE = SSA/dfa, SSE/dfe
    hs2 = (MSA-MSE)/n0
    return SSA, SSE, dfa, dfe, MSA, MSE, hs2, MSE

rng = np.random.default_rng(SEED)
Y = gen(rng)
SSA, SSE, dfa, dfe, MSA, MSE, hs2, he2 = anova(Y)
SST = ((Y-Y.mean())**2).sum()
print()
print("=== 单次实现的方差分析表 ===")
print("来源      df      SS          MS         EMS")
print("公畜   %5d  %11.4f %10.4f   sigma_e^2 + %d sigma_s^2" % (dfa, SSA, MSA, n0))
print("误差   %5d  %11.4f %10.4f   sigma_e^2" % (dfe, SSE, MSE))
print("总和   %5d  %11.4f" % (N-1, SST))
print("hat sigma_s^2 = (MSA-MSE)/n = (%.4f-%.4f)/%d = %.4f  (真值 %.4f)" % (MSA, MSE, n0, hs2, sa2))
print("hat sigma_e^2 = MSE = %.4f  (真值 %.4f)" % (he2, se2))
h2hat = 4*hs2/(hs2+he2)
print("hat h^2 = 4*%.4f/(%.4f+%.4f) = %.4f  (真值 %.2f)" % (hs2, hs2, he2, h2hat, h2_true))
F = MSA/MSE
print("F = MSA/MSE = %.4f, p = %.5f" % (F, stats.f.sf(F, dfa, dfe)))
print("组内相关 t = hat sigma_s^2/(hat sigma_s^2+hat sigma_e^2) = %.5f" % (hs2/(hs2+he2)))

# ---- 1000 次重复 ----
R = 1000
rng = np.random.default_rng(SEED+1)
est_a = np.empty(R); est_e = np.empty(R); est_h = np.empty(R)
for r in range(R):
    Yr = gen(rng)
    _,_,_,_,MA,ME,ha,he = anova(Yr)
    est_a[r]=ha; est_e[r]=he; est_h[r]=4*ha/(ha+he)
print()
print("=== %d 次重复（种子 %d）===" % (R, SEED+1))
print("%-16s %10s %10s %10s %10s" % ("量", "真值", "均值", "实测SD", "理论SE"))
# 理论: Var(MSA)=2(E MSA)^2/dfa, Var(MSE)=2(E MSE)^2/dfe
EMSA = se2 + n0*sa2
VarMSA = 2*EMSA**2/dfa; VarMSE = 2*se2**2/dfe
Var_sa = (VarMSA+VarMSE)/n0**2
Var_se = VarMSE
print("%-16s %10.4f %10.4f %10.4f %10.4f" % ("sigma_s^2", sa2, est_a.mean(), est_a.std(ddof=1), np.sqrt(Var_sa)))
print("%-16s %10.4f %10.4f %10.4f %10.4f" % ("sigma_e^2", se2, est_e.mean(), est_e.std(ddof=1), np.sqrt(Var_se)))
# h^2 的理论 SE：式 8.17a
t = h2_true/4
se_h_817a = 4*np.sqrt(2*(1-t)**2*(1+(n0-1)*t)**2/(n0*(n0-1)*(s-1)))
print("%-16s %10.4f %10.4f %10.4f %10.4f   <- 式(8.17a)" % ("h^2", h2_true, est_h.mean(), est_h.std(ddof=1), se_h_817a))
# delta 法 SE(h^2) 直接由 Var(sa),Var(se),Cov
Cov_ae = -VarMSE/n0
sp = sa2+se2
d_a = 4*se2/sp**2; d_e = -4*sa2/sp**2
var_h_delta = d_a**2*Var_sa + d_e**2*Var_se + 2*d_a*d_e*Cov_ae
print("%-16s %10s %10s %10s %10.4f   <- delta 法" % ("h^2", "", "", "", np.sqrt(var_h_delta)))

neg = (est_a < 0).sum()
print()
print("负估计次数: %d / %d = %.4f" % (neg, R, neg/R))
Fcrit = 1.0/(1+n0*sa2/se2)
p_theory = stats.f.cdf(Fcrit, dfa, dfe)
print("理论 P(hat sigma_s^2<0) = P(F_{%d,%d} < %.6f) = %.4f" % (dfa, dfe, Fcrit, p_theory))

# ---- 不同设计下的负估计概率表 ----
print()
print("=== 负估计概率表 P(F_{s-1,s(n-1)} < 1/(1+n*t/(1-t))), t=h^2/4 ===")
print("%-8s %-6s" % ("", "n=") + "".join("%9d" % n for n in (2,5,10,20)))
for h2 in (0.05, 0.10, 0.25, 0.40):
    for ss in (10, 25, 100):
        row = []
        for nn in (2,5,10,20):
            tt = h2/4
            fc = 1.0/(1+nn*tt/(1-tt))
            row.append(stats.f.cdf(fc, ss-1, ss*(nn-1)))
        print("h2=%.2f s=%-4d " % (h2, ss) + "".join("%9.4f" % v for v in row))
