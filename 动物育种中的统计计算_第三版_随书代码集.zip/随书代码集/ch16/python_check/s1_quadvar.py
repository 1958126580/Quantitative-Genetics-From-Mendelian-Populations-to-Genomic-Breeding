# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 16 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_quadvar.py    依赖：numpy
"""§16.1  Var(y'Ay) 的一般公式与蒙特卡罗验证；不同二次型的效率对比。"""
import numpy as np

rng = np.random.default_rng(20250916)
n = 6

# ---- 1. 随机构造 V（正定）、A（对称）、mu ----
L = rng.normal(size=(n, n))
V = L @ L.T / n + np.eye(n) * 0.5
A = rng.normal(size=(n, n)); A = (A + A.T) / 2
mu = rng.normal(size=n)

theo_mean = np.trace(A @ V) + mu @ A @ mu
theo_var = 2 * np.trace(A @ V @ A @ V) + 4 * mu @ A @ V @ A @ mu

R = 4_000_000
C = np.linalg.cholesky(V)
# 分块蒙特卡罗
s1 = 0.0; s2 = 0.0; B = 200_000
for _ in range(R // B):
    Y = mu + rng.standard_normal((B, n)) @ C.T
    q = np.einsum('ij,jk,ik->i', Y, A, Y)
    s1 += q.sum(); s2 += (q * q).sum()
mc_mean = s1 / R
mc_var = s2 / R - mc_mean ** 2

print("=== 1. Var(y'Ay) 公式验证 (n=6, seed=20250916, R=4e6) ===")
print("理论  E  = %.6f    蒙特卡罗 = %.6f" % (theo_mean, mc_mean))
print("理论 Var = %.6f    蒙特卡罗 = %.6f" % (theo_var, mc_var))
print("相对误差: E %.2e  Var %.2e" % (abs(mc_mean/theo_mean-1), abs(mc_var/theo_var-1)))
print("2tr(AVAV) = %.6f ; 4 mu'AVA mu = %.6f" % (2*np.trace(A@V@A@V), 4*mu@A@V@A@mu))

# ---- 2. 不同二次型的效率：平衡单因子 s=10, n0=4 ----
print()
print("=== 2. 不同二次型估计 sigma_a^2 的效率 (s=10, n0=4) ===")
s, n0 = 10, 4
N = s * n0
Z = np.kron(np.eye(s), np.ones((n0, 1)))
X = np.ones((N, 1))
sa2, se2 = 2.0, 8.0
V2 = Z @ Z.T * sa2 + np.eye(N) * se2
V1 = Z @ Z.T            # dV/dsigma_a^2
V0 = np.eye(N)          # dV/dsigma_e^2

def make_P(M):
    Mi = np.linalg.inv(M)
    return Mi - Mi @ X @ np.linalg.inv(X.T @ Mi @ X) @ X.T @ Mi

# (a) ANOVA: A_a = (H_Z - H_X)/n0 - (I - H_Z)/(n0*(N-s)) * (s-1) ... 直接由 MSA,MSE 构造
HX = X @ np.linalg.pinv(X)
HZ = Z @ np.linalg.pinv(Z)
A_SSA = HZ - HX                      # SSA = y'(HZ-HX)y
A_SSE = np.eye(N) - HZ               # SSE = y'(I-HZ)y
A_anova = (A_SSA / (s - 1) - A_SSE / (N - s)) / n0   # sigma_a^2 的 ANOVA 估计量

# (b) MIVQUE(真值): S theta = q
P = make_P(V2)
S = np.array([[np.trace(P @ Vi @ P @ Vj) for Vj in (V1, V0)] for Vi in (V1, V0)])
Sinv = np.linalg.inv(S)
A_miv = Sinv[0, 0] * (P @ V1 @ P) + Sinv[0, 1] * (P @ V0 @ P)

# (c) MIVQUE(0): 先验 sigma_a^2=0
P0 = make_P(np.eye(N))
S0 = np.array([[np.trace(P0 @ Vi @ P0 @ Vj) for Vj in (V1, V0)] for Vi in (V1, V0)])
S0inv = np.linalg.inv(S0)
A_miv0 = S0inv[0, 0] * (P0 @ V1 @ P0) + S0inv[0, 1] * (P0 @ V0 @ P0)

# (d) 一个"任意"的合法二次型：用 Z'y 的加权平方和，权重偏离最优
W = np.diag(np.r_[np.ones(s//2)*3.0, np.ones(s - s//2)*0.5])
Araw = HX @ np.zeros((N,N))  # placeholder
B_ = (np.eye(N) - HX) @ Z @ W @ Z.T @ (np.eye(N) - HX)
# 校正使之无偏：在 A = a*B + b*(I-HZ) 中解 tr(AV1)=1, tr(AV0)=0
M = np.array([[np.trace(B_ @ V1), np.trace(A_SSE @ V1)],
              [np.trace(B_ @ V0), np.trace(A_SSE @ V0)]])
ab = np.linalg.solve(M, np.array([1.0, 0.0]))
A_bad = ab[0] * B_ + ab[1] * A_SSE

names = ["ANOVA(=MIVQUE 真值?)", "MIVQUE(真值)", "MIVQUE(0)", "劣质加权二次型"]
for nm, Aj in zip(names, [A_anova, A_miv, A_miv0, A_bad]):
    bias1 = np.trace(Aj @ V1); bias0 = np.trace(Aj @ V0); bx = (X.T @ Aj @ X).item()
    var = 2 * np.trace(Aj @ V2 @ Aj @ V2)
    print("%-22s tr(AV1)=%7.4f tr(AV0)=%9.2e X'AX=%9.2e  Var=%9.4f  SE=%7.4f"
          % (nm, bias1, bias0, bx, var, np.sqrt(var)))

print()
print("相对效率 (MIVQUE 真值为基准):")
vref = 2 * np.trace(A_miv @ V2 @ A_miv @ V2)
for nm, Aj in zip(names, [A_anova, A_miv, A_miv0, A_bad]):
    v = 2 * np.trace(Aj @ V2 @ Aj @ V2)
    print("  %-22s Var=%9.4f  相对效率=%.4f" % (nm, v, vref / v))
