# 第十六章　基于矩的方差组分估计 —— 配套代码

**所属**：第四篇　方差组分估计　　**对应正文**：第十六章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch16.ipynb` | IJulia 笔记本：9 个代码单元，约 299 行 Julia 代码，穿插与正文对应的说明 |
| `ch16.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 18 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　二次型期望的统一框架（正文式 16.1、16.3）
- 2　ANOVA：平衡单因子随机模型（正文 §16.2.1）
  - 2.1 负估计的概率（正文式 16.10）
- 3　巢式设计：三种遗传力估计（正文式 16.12–16.14）
- 4　Henderson 方法 I 的偏性（正文 §16.3.1）
- 5　Henderson 方法 III（拟合常数法，正文 §16.3.3）
- 6　MIVQUE 与 HE 回归（正文 §16.4–16.5）
  - 6.1 HE 回归（正文 §16.5）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 16
```

或在 Jupyter 中打开 `ch16/ch16.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
