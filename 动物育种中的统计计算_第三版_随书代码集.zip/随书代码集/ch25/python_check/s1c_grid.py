# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1c_grid.py    依赖：numpy
"""Exact type I error grid for binary traits (exploration + final tables)."""
import numpy as np, json, sys
import binlib as B

alphas = [0.05, 1e-4, 5e-8]
out = {}
print('=== Table A: three tests, MAF x n, case fraction phi')
for phi in [0.5, 0.2]:
    for n in [500, 5000]:
        for maf in [0.5, 0.05, 0.01]:
            n0, n1, n2 = B.design(n, maf)
            A = int(round(phi * n))
            P = B.pmf_T(n0, n1, n2, A)
            pv, ex = B.all_pvalues(n0, n1, n2, A)
            row = {}
            s = f'phi={phi} n={n:5d} maf={maf:<5} design=({n0},{n1},{n2}) A={A}: '
            for t in ['wald', 'score', 'lrt', 'linear', 'spa']:
                row[t] = [B.type1(P, pv[t], a) for a in alphas]
            for t in ['wald', 'score', 'lrt', 'linear', 'spa']:
                s += f'\n    {t:6s} ' + '  '.join(f'{v:.4e}({v/a:.3f})' for v, a in zip(row[t], alphas))
            # probability of separation (T at boundary)
            psep = P[ex['Tmin']] + P[ex['Tmax']]
            s += f'\n    P(separation)={psep:.4e}  min attainable p: wald {pv["wald"].min():.3e} score {pv["score"].min():.3e} lrt {pv["lrt"].min():.3e}'
            print(s)
            out[f'A_{phi}_{n}_{maf}'] = dict(design=[n0, n1, n2], A=A, row=row, psep=psep)
sys.stdout.flush()
print('=== Table B: imbalance, n=5000 and 20000')
for n in [5000, 20000]:
    for maf in [0.05, 0.01, 0.005]:
        for phi in [0.5, 0.2, 0.1, 0.05, 0.02, 0.01]:
            n0, n1, n2 = B.design(n, maf)
            A = int(round(phi * n))
            P = B.pmf_T(n0, n1, n2, A)
            pv, ex = B.all_pvalues(n0, n1, n2, A)
            row = {t: [B.type1(P, pv[t], a) for a in alphas] for t in ['linear', 'score', 'lrt', 'wald', 'spa']}
            s = f'n={n} maf={maf} phi={phi} design=({n0},{n1},{n2}) A={A} expected minor alleles in cases={2*A*maf:.1f}:'
            for t in ['linear', 'score', 'lrt', 'wald', 'spa']:
                s += f'\n    {t:6s} ' + '  '.join(f'{v:.4e}({v/a:.3f})' for v, a in zip(row[t], alphas))
            print(s)
            sys.stdout.flush()
            out[f'B_{n}_{maf}_{phi}'] = dict(design=[n0, n1, n2], A=A, row=row)
json.dump(out, open('grid_binary.json', 'w'), indent=1)
