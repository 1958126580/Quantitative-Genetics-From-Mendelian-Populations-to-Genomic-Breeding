# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3b_aux.py    依赖：numpy, scipy
"""Auxiliary numbers for §25.3.7-8 text."""
import json, glob, numpy as np
from scipy import stats
a = json.load(open('analyze_s3_main.json'))
p1 = 1 - (1 - 5e-6) ** 5000
print('FWER if 5000 independent null tests at 5e-6: %.5f' % p1)
print('P(X>=2 | 30, p1) = %.4f' % stats.binom.sf(1, 30, p1))
k = a['desc']['kappa_null_mean']; kt = a['desc']['kappa_t_mean']
print('null: lam full/lomo = %.4f ; mean chi2 ratio = %.4f ; 1/(1+kappa_null) = %.4f' % (
    a['mlma']['lam'] / a['lomo']['lam'], a['mlma']['null_meanchi'] / a['lomo']['null_meanchi'], 1 / (1 + k)))
print('targets: full/lomo = %.4f ; 1/(1+kappa_t) = %.4f' % (a['thin_t1']['full_over_lomo'], 1 / (1 + kt)))
for t in ('t1', 't2', 't5'):
    r = a['thin_' + t]
    print(t, 'implied kappa (targets) = %.4f' % (1 / r['full_over_lomo'] - 1), r)
print('N h2 / M = %.4f' % (2000 * a['desc']['h2'] / 10000))
print('LD at 20cM / (1/1200) = %.2f' % (a['desc']['ld_mean']['200'] / (1 / 1200)))
# per-replicate lambda of none/pc to report relation with subpop structure
files = sorted(glob.glob('s3_main_rep_*.npz'))
lam_none = []; gd = []
for f in files:
    z = np.load(f)
    null = z['chrom'] >= 5
    lam_none.append(np.median(z['chi_none'][null]) / stats.chi2.ppf(0.5, 1)); gd.append(float(z['gdiff']))
print('corr(lambda_none, |gdiff|) = %.3f' % np.corrcoef(lam_none, np.abs(gd))[0, 1])
print('power LOCO 206/300 = %.4f ; full 140/300 = %.4f' % (206 / 300, 140 / 300))
