# 第 25 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch25/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `s1a_normal.py` | §25.2.4 Part A: normal linear model, y = mu + z*alpha + e, H0: alpha = 0. | numpy, scipy | 33.8 | `outputs/s1a_normal.out` |
| `s1b_validate.py` | Validate binlib: pmf, logistic fit vs scipy.optimize on individual data, SPA vs exact convolution. | numpy, scipy | 1.7 | `outputs/s1b_validate.out` |
| `s1c_grid.py` | Exact type I error grid for binary traits (exploration + final tables). | numpy, scipy | 15.3 | `outputs/s1c_grid.out` |
| `s1d_mc_check.py` | (i) individual-level check of Wald/LRT/score in an unbalanced rare design; | numpy, scipy | 12.5 | `outputs/s1d_mc_check.out` |
| `s1e_tables.py` | Final numbers for §25.2.4 and §25.2.5 (tables 25.1-25.3). | numpy, scipy | 6.8 | `outputs/s1e_tables.out` |
| `s1f_minmac.py` | Minimum attainable p-value vs number of (heterozygous) carriers c, n = 5000, 1:1 design (A = 2500). | numpy, scipy | 2.0 | `outputs/s1f_minmac.out` |
| `s1g_minmac_wald.py` | Smallest heterozygous-carrier count c for which the Wald test can reach p < 5e-8 (n=5000, A=2500). | numpy, scipy | 1.5 | `outputs/s1g_minmac_wald.out` |
| `s1h_tails.py` | Upper/lower tail split of linear-model false positives (alpha 5e-8), n = 5000, all imbalance rows; | numpy, scipy | 2.0 | `outputs/s1h_tails.out` |
| `s3b_aux.py` | Auxiliary numbers for §25.3.7-8 text. | numpy, scipy | 1.2 | `outputs/s3b_aux.out` |
| `s4a2_lijiN.py` | Li-Ji and Nyholt M_eff: sensitivity to sample size N (sampling noise in R). | numpy, scipy | 14.5 | `outputs/s4a2_lijiN.out` |
| `s4a3_nyholt_check.py` | Check: Nyholt M_eff = M - (mean in-sample LD score - 1), LD score l_j = sum_k r_jk^2 (incl. j). | numpy, scipy | 8.8 | `outputs/s4a3_nyholt_check.out` |
| `s4a_meff.py` | §25.4.4  Effective number of independent tests on a simulated LD marker set. | numpy, scipy | 18.3 | `outputs/s4a_meff.out` |
| `s5a_ncf.py` | Exact power of the t-test: noncentral F(1, n-2, ncp) with ncp = (n-1) 2pq a^2/se^2 = (n-1) q2/(1-q2) | scipy | 2.5 | `outputs/s5a_ncf.out` |

公共函数模块（被上列脚本导入，不单独运行）：`binlib.py`、`sim25.py`。
