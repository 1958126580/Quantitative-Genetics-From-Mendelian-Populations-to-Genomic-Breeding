# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1b_validate.py    依赖：numpy, scipy
"""Validate binlib: pmf, logistic fit vs scipy.optimize on individual data, SPA vs exact convolution."""
import numpy as np
from scipy import stats, optimize
from scipy.special import expit
import binlib as B

# 1. pmf
for n, maf, A in [(500, 0.5, 250), (5000, 0.01, 50), (5000, 0.05, 500)]:
    n0, n1, n2 = B.design(n, maf)
    P = B.pmf_T(n0, n1, n2, A)
    T = np.arange(len(P))
    print('design', (n0, n1, n2), 'A', A, 'sum P =', P.sum(), ' E(T)=', (T * P).sum(), ' theory', A * (n1 + 2 * n2) / n)

# 2. logistic fit vs generic optimizer, individual level
n0, n1, n2 = B.design(500, 0.05)
A = 100
pv, ex = B.all_pvalues(n0, n1, n2, A)
x = np.r_[np.zeros(n0), np.ones(n1), 2 * np.ones(n2)]
for T in [ex['Tmin'] + 1, 20, 35, ex['Tmax'] - 1]:
    # construct one data set with this T: fill cases
    # choose a2, a1 to give T; a0 = A - a1 - a2
    found = None
    for a2 in range(n2 + 1):
        a1 = T - 2 * a2
        a0 = A - a1 - a2
        if 0 <= a1 <= n1 and 0 <= a0 <= n0:
            found = (a0, a1, a2)
            break
    a0, a1, a2 = found
    y = np.r_[np.ones(a0), np.zeros(n0 - a0), np.ones(a1), np.zeros(n1 - a1), np.ones(a2), np.zeros(n2 - a2)]
    Xd = np.c_[np.ones(len(x)), x]

    def nll(b):
        eta = Xd @ b
        return -(y * eta - np.logaddexp(0, eta)).sum()

    def grad(b):
        return -Xd.T @ (y - expit(Xd @ b))

    r = optimize.minimize(nll, np.zeros(2), jac=grad, method='BFGS', options=dict(gtol=1e-10))
    mu = expit(Xd @ r.x)
    I = (Xd * (mu * (1 - mu))[:, None]).T @ Xd
    W = r.x[1] ** 2 / np.linalg.inv(I)[1, 1]
    ll1 = -r.fun
    ll0 = -nll(np.array([np.log(A / (len(y) - A)), 0.0]))
    LR = 2 * (ll1 - ll0)
    ybar = y.mean()
    U = ((x - x.mean()) * y).sum()
    S = U ** 2 / (ybar * (1 - ybar) * ((x - x.mean()) ** 2).sum())
    k = T
    print(f'T={T}: indiv  W={W:.6f} LR={LR:.6f} S={S:.6f}   lib W={stats.chi2.isf(pv["wald"][k],1):.6f} '
          f'LR={ex["lrt"][k]:.6f} S={ex["S"][k]:.6f}')
    # linear t
    sl = stats.linregress(x, y)
    print('     linear p indiv', sl.pvalue, ' lib', pv['linear'][k])

# 3. SPA vs exact unconditional distribution of U (independent Bernoulli)
for (n0, n1, n2), mu in [((4900, 99, 1), 0.01), ((4750, 238, 12), 0.02)]:
    counts = np.array([n0, n1, n2])
    n = counts.sum()
    # exact distribution of (a0,a1,a2) independent binomials -> U = T - xbar*Atot; compute P(U >= u)
    xbar = (n1 + 2 * n2) / n
    pa0 = stats.binom.pmf(np.arange(n0 + 1), n0, mu)
    pa1 = stats.binom.pmf(np.arange(n1 + 1), n1, mu)
    pa2 = stats.binom.pmf(np.arange(n2 + 1), n2, mu)
    # U = sum c_g a_g with c = x - xbar
    c = np.array([0, 1, 2]) - xbar
    vals, probs = [], []
    a0 = np.arange(n0 + 1)
    for a1 in range(n1 + 1):
        if pa1[a1] < 1e-30:
            continue
        for a2 in range(n2 + 1):
            if pa2[a2] < 1e-30:
                continue
            m = pa0 > 1e-30
            vals.append(c[0] * a0[m] + c[1] * a1 + c[2] * a2)
            probs.append(pa0[m] * pa1[a1] * pa2[a2])
    vals = np.concatenate(vals)
    probs = np.concatenate(probs)
    for ucheck in [3.0, 5.0, 8.0, -1.5]:
        ex_tail = probs[vals >= ucheck - 1e-9].sum() if ucheck > 0 else probs[vals <= ucheck + 1e-9].sum()
        spa_one = B.spa_pvalue(np.array([abs(ucheck)]), counts, mu, cutoff=-1)  # two-sided
        print(f'design {tuple(counts)} mu={mu} u={ucheck}: exact one-tail {ex_tail:.4e};  SPA two-sided {spa_one[0]:.4e}')
    # exact two-sided at a few u
    for ucheck in [4.0, 6.0, 9.0]:
        ex2 = probs[np.abs(vals) >= ucheck - 1e-9].sum()
        sp = B.spa_pvalue(np.array([ucheck]), counts, mu, cutoff=-1)[0]
        nm = 2 * stats.norm.sf(ucheck / np.sqrt(mu * (1 - mu) * (counts * c * c).sum()))
        print(f'   u={ucheck}: exact two-sided {ex2:.4e}  SPA {sp:.4e}  normal {nm:.4e}')
