# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 sim25.py    依赖：numpy, scipy
"""Structured population for §25.3: two subpopulations (Balding-Nichols F) + half-/full-sib families.

Genome: C chromosomes x 1 Morgan, mc equally spaced markers per chromosome.
Founder haplotypes: latent AR(1) Gaussian process along each chromosome thresholded at the
subpopulation allele frequency (gives LD decaying with distance; marginal freq exact).
Offspring: sire x dam matings, Haldane meiosis (Poisson(1) crossovers per chromosome).
"""
import numpy as np
from scipy import stats, optimize

CFG = dict(C=10, mc=1000, lam_cM=1.0, F_BN=0.05, pmin=0.05, pmax=0.95,
           sires=(30, 20), dams_per_sire=8, off_per_dam=5,
           n_poly=300, h2_poly=0.25, n_target=10, q2_target=0.015, delta_env=0.3, delta_total=0.2,
           qtl_chrom=(0, 1, 2, 3, 4))


def make_map(cfg):
    C, mc = cfg['C'], cfg['mc']
    pos = np.tile((np.arange(mc) + 0.5) / mc, C)          # Morgans within chromosome
    chrom = np.repeat(np.arange(C), mc)
    d_cM = 100.0 / mc
    rho = np.full(C * mc, np.exp(-d_cM / cfg['lam_cM']))
    rho[np.arange(C) * mc] = 0.0                          # chromosome starts
    return pos, chrom, rho


def founder_haps(nhap, pk, rho, rng):
    M = len(pk)
    thr = stats.norm.ppf(pk)
    H = np.empty((nhap, M), dtype=np.int8)
    u = rng.standard_normal(nhap)
    H[:, 0] = u < thr[0]
    eps = rng.standard_normal((nhap, M))
    sq = np.sqrt(1 - rho ** 2)
    for j in range(1, M):
        u = rho[j] * u + sq[j] * eps[:, j]
        H[:, j] = u < thr[j]
    return H


def gamete(h0, h1, pos, chrom, C, mc, rng):
    g = np.empty_like(h0)
    for c in range(C):
        sl = slice(c * mc, (c + 1) * mc)
        k = rng.poisson(1.0)
        start = rng.integers(2)
        if k == 0:
            g[sl] = h0[sl] if start == 0 else h1[sl]
            continue
        cx = np.sort(rng.random(k))
        sw = (np.searchsorted(cx, pos[sl]) + start) % 2
        g[sl] = np.where(sw == 0, h0[sl], h1[sl])
    return g


def simulate(seed, cfg=CFG):
    rng = np.random.default_rng(seed)
    pos, chrom, rho = make_map(cfg)
    M = len(pos)
    C, mc = cfg['C'], cfg['mc']
    F = cfg['F_BN']
    p_anc = rng.uniform(cfg['pmin'], cfg['pmax'], M)
    a, b = p_anc * (1 - F) / F, (1 - p_anc) * (1 - F) / F
    pk = np.vstack([rng.beta(a, b), rng.beta(a, b)])
    pk = np.clip(pk, 1e-4, 1 - 1e-4)
    geno, sub, sire_id, dam_id = [], [], [], []
    fam_offset = 0
    for k in range(2):
        S = cfg['sires'][k]
        D = S * cfg['dams_per_sire']
        H = founder_haps(2 * (S + D), pk[k], rho, rng)
        sires = [(H[2 * i], H[2 * i + 1]) for i in range(S)]
        dams = [(H[2 * (S + i)], H[2 * (S + i) + 1]) for i in range(D)]
        for s in range(S):
            for dd in range(cfg['dams_per_sire']):
                d = s * cfg['dams_per_sire'] + dd
                for o in range(cfg['off_per_dam']):
                    gp = gamete(*sires[s], pos, chrom, C, mc, rng)
                    gm = gamete(*dams[d], pos, chrom, C, mc, rng)
                    geno.append(gp + gm)
                    sub.append(k)
                    sire_id.append(fam_offset + s)
                    dam_id.append(fam_offset * 100 + d)
        fam_offset += S
    Xg = np.array(geno, dtype=np.int8)
    sub = np.array(sub)
    return dict(X=Xg, sub=sub, sire=np.array(sire_id), dam=np.array(dam_id), pk=pk, p_anc=p_anc,
                pos=pos, chrom=chrom, rng=rng)


def pooled_within_var(v, sub):
    out = 0.0
    n = len(v)
    for k in np.unique(sub):
        m = sub == k
        out += m.sum() / n * v[m].var()
    return out


def make_pheno(d, cfg=CFG):
    rng = d['rng']
    X, sub, chrom, pos = d['X'], d['sub'], d['chrom'], d['pos']
    N, M = X.shape
    phat = X.mean(0) / 2
    maf = np.minimum(phat, 1 - phat)
    qtl_ch = np.array(cfg['qtl_chrom'])
    # target QTL: 2 per QTL chromosome, near 25 and 75 cM, pooled MAF in [0.2, 0.5]
    targets = []
    for c in qtl_ch:
        for p0 in (0.25, 0.75):
            idx = np.where((chrom == c) & (maf >= 0.2))[0]
            j = idx[np.argmin(np.abs(pos[idx] - p0))]
            targets.append(j)
    targets = np.array(targets)
    cand = np.where(np.isin(chrom, qtl_ch) & (maf >= 0.01))[0]
    cand = np.setdiff1d(cand, targets)
    poly = rng.choice(cand, cfg['n_poly'], replace=False)
    Xf = X.astype(float)
    a_poly = rng.standard_normal(cfg['n_poly'])
    g_poly = Xf[:, poly] @ a_poly
    g_poly *= np.sqrt(cfg['h2_poly'] / pooled_within_var(g_poly, sub))
    a_t = np.empty(len(targets))
    signs = rng.choice([-1.0, 1.0], len(targets))
    for i, j in enumerate(targets):
        a_t[i] = signs[i] * np.sqrt(cfg['q2_target'] / pooled_within_var(Xf[:, j], sub))
    g_t = Xf[:, targets] @ a_t
    s2e = 1.0 - cfg['h2_poly'] - cfg['n_target'] * cfg['q2_target']
    e = rng.standard_normal(N) * np.sqrt(s2e)
    if cfg.get('delta_total') is not None:
        g = g_poly + g_t
        gdiff = g[sub == 1].mean() - g[sub == 0].mean()
        denv = cfg['delta_total'] - gdiff
    else:
        denv = cfg['delta_env']
    y = denv * (sub == 1) + g_poly + g_t + e
    y = y - y.mean()
    return dict(y=y, targets=targets, poly=poly, a_t=a_t, g_poly=g_poly, g_t=g_t, e=e, s2e=s2e, denv=denv)


# ---------------- analysis ----------------

def reml_eigen(lam, ystar, Xstar, grid=np.linspace(np.log(1e-3), np.log(1e3), 121)):
    """REML for V = sg2 (G + delta I) with G = U diag(lam) U'. Returns delta, sg2, se2."""
    N, p = Xstar.shape

    def negll(ld):
        dlt = np.exp(ld)
        dinv = 1.0 / (lam + dlt)
        XtHX = (Xstar * dinv[:, None]).T @ Xstar
        XtHy = (Xstar * dinv[:, None]).T @ ystar
        yHy = (ystar * dinv) @ ystar
        yPy = yHy - XtHy @ np.linalg.solve(XtHX, XtHy)
        sign, ldet = np.linalg.slogdet(XtHX)
        return 0.5 * ((N - p) * np.log(yPy) + np.log(lam + dlt).sum() + ldet)

    vals = np.array([negll(g) for g in grid])
    i = int(np.argmin(vals))
    lo, hi = grid[max(i - 1, 0)], grid[min(i + 1, len(grid) - 1)]
    r = optimize.minimize_scalar(negll, bounds=(lo, hi), method='bounded', options=dict(xatol=1e-8))
    dlt = np.exp(r.x)
    dinv = 1.0 / (lam + dlt)
    XtHX = (Xstar * dinv[:, None]).T @ Xstar
    XtHy = (Xstar * dinv[:, None]).T @ ystar
    yHy = (ystar * dinv) @ ystar
    yPy = yHy - XtHy @ np.linalg.solve(XtHX, XtHy)
    sg2 = yPy / (N - p)
    return dlt, sg2, dlt * sg2


def mlma_stats(lam, U, y, Zc, delta, sg2, Xmat=None):
    """chi2_j = (z'P y)^2 / (z'P z), P for V = sg2 (G + delta I). Returns chi2, zPz (in V units)."""
    N = len(y)
    if Xmat is None:
        Xmat = np.ones((N, 1))
    ys = U.T @ y
    Xs = U.T @ Xmat
    Zs = U.T @ Zc
    dinv = 1.0 / (sg2 * (lam + delta))
    XtVX = (Xs * dinv[:, None]).T @ Xs
    XtVy = (Xs * dinv[:, None]).T @ ys
    A = np.linalg.solve(XtVX, np.eye(Xs.shape[1]))
    ZtVy = (Zs * dinv[:, None]).T @ ys
    ZtVX = (Zs * dinv[:, None]).T @ Xs
    zPy = ZtVy - ZtVX @ (A @ XtVy)
    zVz = np.einsum('ij,ij,i->j', Zs, Zs, dinv)
    zPz = zVz - np.einsum('jk,kl,jl->j', ZtVX, A, ZtVX)
    return zPy ** 2 / zPz, zPz, zPy


def ols_stats(y, Zc, covars=None):
    """t-test of each marker given covariates; returns F=t^2 and df."""
    N = len(y)
    Xc = np.ones((N, 1)) if covars is None else np.c_[np.ones(N), covars]
    Q, _ = np.linalg.qr(Xc)
    yt = y - Q @ (Q.T @ y)
    Zt = Zc - Q @ (Q.T @ Zc)
    zz = np.einsum('ij,ij->j', Zt, Zt)
    zy = Zt.T @ yt
    yy = yt @ yt
    df = N - Xc.shape[1] - 1
    F = zy ** 2 * df / (zz * yy - zy ** 2)
    return F, df
