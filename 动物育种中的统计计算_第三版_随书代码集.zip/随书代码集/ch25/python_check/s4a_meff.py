# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4a_meff.py    依赖：numpy, scipy
"""§25.4.4  Effective number of independent tests on a simulated LD marker set.

Genotypes: N unrelated diploids, haplotypes from the latent AR(1) model of sim25.founder_haps
(one population, p ~ U(0.05,0.95)), 2 chromosomes x 1 Morgan x 1000 markers (0.1 cM spacing).
lam_cM (latent correlation length) given on the command line (default 1.0).
M_eff: Li & Ji (eq 25.22) and Nyholt (2004) from the eigenvalues of the marker correlation matrix;
empirical: B null phenotypes y ~ N(0, I), min p over markers, 5% quantile -> alpha*;
M_eff,emp = 0.05 / alpha*.  Thinned panels (every 2nd, 4th, 8th marker) reuse the same nulls.
"""
import sys, time, json
import numpy as np
from scipy import stats
import sim25 as S

lam_cM = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
seed = int(sys.argv[2]) if len(sys.argv) > 2 else 25401
N, C, mc, B = 3000, 2, 1000, 20000
rng = np.random.default_rng(seed)
cfg = dict(S.CFG); cfg.update(C=C, mc=mc, lam_cM=lam_cM)
pos, chrom, rho = S.make_map(cfg)
M = len(pos)
freq_ar = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
if freq_ar > 0:
    # thresholds follow an AR(1) along each chromosome (corr freq_ar per step, sd 0.6): adjacent
    # markers get similar allele frequencies -> block-like strong LD
    tj = np.empty(M)
    for ci in range(C):
        sl = slice(ci * mc, (ci + 1) * mc)
        e = rng.standard_normal(mc) * 0.6
        t = np.empty(mc); t[0] = e[0]
        for j in range(1, mc):
            t[j] = freq_ar * t[j - 1] + np.sqrt(1 - freq_ar ** 2) * e[j]
        tj[sl] = t
    p = stats.norm.cdf(tj)
else:
    p = rng.uniform(0.05, 0.95, M)
H = S.founder_haps(2 * N, p, rho, rng)
X = (H[0::2] + H[1::2]).astype(np.float64)
Xs = (X - X.mean(0)) / X.std(0)
t0 = time.time()
# null phenotypes and all marker correlations
Zt = Xs.T.astype(np.float32)          # M x N
minp_by_thin = {1: [], 2: [], 4: [], 8: []}
done = 0
while done < B:
    b = min(500, B - done)
    Y = rng.standard_normal((N, b))
    Y = (Y - Y.mean(0)) / Y.std(0)
    R = (Zt @ Y.astype(np.float32)).astype(np.float64) / N      # M x b correlations
    for th in minp_by_thin:
        rmax = np.abs(R[::th]).max(0)
        t = rmax * np.sqrt((N - 2) / (1 - rmax ** 2))
        minp_by_thin[th].append(2 * stats.t.sf(t, N - 2))
    done += b
print('null sims done in %.1fs' % (time.time() - t0))
out = {}
for th in (1, 2, 4, 8):
    idx = np.arange(0, M, th)
    Mt = len(idx)
    Rm = (Xs[:, idx].T @ Xs[:, idx]) / N
    ev = np.linalg.eigvalsh(Rm)
    ev = np.clip(ev, 0, None)
    lj = float((ev >= 1).sum() + (ev - np.floor(ev)).sum())
    varl = ((ev - ev.mean()) ** 2).sum() / (Mt - 1)
    ny = float(1 + (Mt - 1) * (1 - varl / Mt))
    minp = np.concatenate(minp_by_thin[th])
    astar = float(np.quantile(minp, 0.05))
    memp = 0.05 / astar
    # realised FWER of each threshold on the null replicates
    fw = {name: float((minp <= 0.05 / m).mean()) for name, m in [('bonf', Mt), ('lj', lj), ('nyholt', ny), ('emp', memp)]}
    r2adj = float(np.mean(np.diag(Rm, 1) ** 2)) if Mt > 1 else np.nan
    # mean r^2 at fixed physical distances (1 cM)
    lag1cM = int(round(1.0 / (100.0 / mc) / th))
    r2_1cM = float(np.mean(np.diag(Rm, lag1cM) ** 2)) if lag1cM < Mt else np.nan
    # bootstrap SE of alpha* (resample null replicates)
    bs = np.array([np.quantile(rng.choice(minp, len(minp)), 0.05) for _ in range(500)])
    out[th] = dict(M=Mt, spacing_cM=th * 100.0 / mc, r2adj=r2adj, r2_1cM=r2_1cM, meff_lj=lj, meff_nyholt=ny,
                   alpha_star=astar, alpha_star_se=float(bs.std()), meff_emp=memp,
                   meff_emp_ci=[float(0.05 / np.quantile(bs, 0.975)), float(0.05 / np.quantile(bs, 0.025))],
                   thr_bonf=0.05 / Mt, thr_lj=0.05 / lj, thr_ny=0.05 / ny, fwer=fw, n_ev_ge1=int((ev >= 1).sum()))
    print(f'lam={lam_cM} far={freq_ar} thin={th}: maf_mean={np.minimum(X.mean(0)/2,1-X.mean(0)/2)[idx].mean():.3f} M={Mt} spacing={th*100.0/mc:.1f}cM r2adj={r2adj:.3f} r2@1cM={r2_1cM:.3f} | '
          f'LiJi={lj:.1f} Nyholt={ny:.1f} emp={memp:.1f} (alpha*={astar:.3e}, SE {bs.std():.1e}) | '
          f'FWER bonf={fw["bonf"]:.4f} LJ={fw["lj"]:.4f} Ny={fw["nyholt"]:.4f} emp={fw["emp"]:.4f}')
json.dump(out, open(f's4a_meff_lam{lam_cM}_far{freq_ar}.json', 'w'), indent=1)
