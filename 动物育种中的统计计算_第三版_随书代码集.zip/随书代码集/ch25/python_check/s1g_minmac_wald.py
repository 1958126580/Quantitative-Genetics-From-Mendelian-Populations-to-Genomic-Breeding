# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1g_minmac_wald.py    依赖：numpy
"""Smallest heterozygous-carrier count c for which the Wald test can reach p < 5e-8 (n=5000, A=2500)."""
import numpy as np, warnings
import binlib as B
warnings.simplefilter('ignore')
n, A = 5000, 2500
for c in list(range(40, 101, 5)):
    pv, ex = B.all_pvalues(n - c, c, 0, A, spa=False)
    print(c, f"wald min p {pv['wald'].min():.3e} at T={int(np.argmin(pv['wald']))} of {c}")
