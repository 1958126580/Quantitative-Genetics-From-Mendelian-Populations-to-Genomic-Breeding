# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4a2_lijiN.py    依赖：numpy, scipy
"""Li-Ji and Nyholt M_eff: sensitivity to sample size N (sampling noise in R).
(a) independent markers (no LD), M = 2000, N = 3000 and 12000: true M_eff = M.
(b) strong-LD panel (lam 5 cM, freq AR 0.97, same generator as s4a), M = 2000, N = 3000 / 12000.
Empirical M_eff with B = 20000 null phenotypes (N = 3000 sample only for (b); for (a) theory = Sidak).
Seeds 25404-25407."""
import numpy as np, json
from scipy import stats
import sim25 as S

C, mc = 2, 1000
M = C * mc
out = {}


def meff(Xs):
    N = Xs.shape[0]
    Rm = Xs.T @ Xs / N
    ev = np.clip(np.linalg.eigvalsh(Rm), 0, None)
    lj = float((ev >= 1).sum() + (ev - np.floor(ev)).sum())
    varl = ((ev - ev.mean()) ** 2).sum() / (len(ev) - 1)
    ny = float(1 + (len(ev) - 1) * (1 - varl / len(ev)))
    return lj, ny, float(ev.max()), float((ev > 2).mean())


def std(X):
    return (X - X.mean(0)) / X.std(0)


for label, strong in (('indep', False), ('strong', True)):
    for N, seed in ((3000, 25404 if not strong else 25406), (12000, 25405 if not strong else 25407)):
        rng = np.random.default_rng(seed)
        if strong:
            cfg = dict(S.CFG); cfg.update(C=C, mc=mc, lam_cM=5.0)
            pos, chrom, rho = S.make_map(cfg)
            tj = np.empty(M)
            for ci in range(C):
                e = rng.standard_normal(mc) * 0.6
                t = np.empty(mc); t[0] = e[0]
                for j in range(1, mc):
                    t[j] = 0.97 * t[j - 1] + np.sqrt(1 - 0.97 ** 2) * e[j]
                tj[ci * mc:(ci + 1) * mc] = t
            p = stats.norm.cdf(tj)
            H = S.founder_haps(2 * N, p, rho, rng)
            X = (H[0::2] + H[1::2]).astype(float)
        else:
            p = rng.uniform(0.05, 0.95, M)
            X = rng.binomial(2, p, size=(N, M)).astype(float)
        lj, ny, evmax, frac2 = meff(std(X))
        out[f'{label}_{N}'] = dict(lj=lj, ny=ny, evmax=evmax, frac_ev_gt2=frac2)
        print(f'{label} N={N}: LiJi={lj:.0f} Nyholt={ny:.1f} max eigen={evmax:.2f} frac(eig>2)={frac2:.4f}', flush=True)
# Marchenko-Pastur upper edge for M/N
for N in (3000, 12000):
    g = M / N
    print(f'MP upper edge (1+sqrt(M/N))^2 for N={N}: {(1+np.sqrt(g))**2:.3f}')
json.dump(out, open('s4a2_lijiN.json', 'w'), indent=1)
