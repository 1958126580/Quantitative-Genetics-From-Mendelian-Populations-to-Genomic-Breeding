# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4a3_nyholt_check.py    依赖：numpy, scipy
"""Check: Nyholt M_eff = M - (mean in-sample LD score - 1), LD score l_j = sum_k r_jk^2 (incl. j).
Regenerates the strong-LD panel of s4a (seed 25403, lam 5 cM, freq AR 0.97) and the weak panel (seed 25401)."""
import numpy as np
from scipy import stats
import sim25 as S
for seed, lam, far in ((25403, 5.0, 0.97), (25401, 1.0, 0.0)):
    N, C, mc = 3000, 2, 1000
    rng = np.random.default_rng(seed)
    cfg = dict(S.CFG); cfg.update(C=C, mc=mc, lam_cM=lam)
    pos, chrom, rho = S.make_map(cfg); M = len(pos)
    if far > 0:
        tj = np.empty(M)
        for ci in range(C):
            e = rng.standard_normal(mc) * 0.6
            t = np.empty(mc); t[0] = e[0]
            for j in range(1, mc):
                t[j] = far * t[j - 1] + np.sqrt(1 - far ** 2) * e[j]
            tj[ci * mc:(ci + 1) * mc] = t
        p = stats.norm.cdf(tj)
    else:
        p = rng.uniform(0.05, 0.95, M)
    H = S.founder_haps(2 * N, p, rho, rng)
    X = (H[0::2] + H[1::2]).astype(float)
    Xs = (X - X.mean(0)) / X.std(0)
    Rm = Xs.T @ Xs / N
    ev = np.clip(np.linalg.eigvalsh(Rm), 0, None)
    varl = ((ev - ev.mean()) ** 2).sum() / (M - 1)
    ny = 1 + (M - 1) * (1 - varl / M)
    ell = (Rm ** 2).sum(1)
    print(f'seed {seed}: Nyholt {ny:.3f}  M-(mean LD score-1) = {M - (ell.mean()-1):.3f}  mean LD score {ell.mean():.3f}  '
          f'sampling-noise part (M-1)/N = {(M-1)/N:.3f}; #eig>=1 {int((ev>=1).sum())}, top eig {ev.max():.2f}')
