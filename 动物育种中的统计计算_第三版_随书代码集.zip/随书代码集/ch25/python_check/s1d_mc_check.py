# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1d_mc_check.py    依赖：numpy, scipy
"""(i) individual-level check of Wald/LRT/score in an unbalanced rare design;
(ii) Monte Carlo check (seed 25202) of exact type I errors: random case sets drawn
     with numpy's multivariate hypergeometric sampler, fixed genotype design."""
import numpy as np, warnings
from scipy import stats, optimize
from scipy.special import expit
import binlib as B
warnings.simplefilter('ignore')

n0, n1, n2 = B.design(5000, 0.01)
A = 50
pv, ex = B.all_pvalues(n0, n1, n2, A)
x = np.r_[np.zeros(n0), np.ones(n1), 2 * np.ones(n2)]
for T in [3, 6, 8]:
    a2 = 0; a1 = T; a0 = A - a1
    y = np.r_[np.ones(a0), np.zeros(n0 - a0), np.ones(a1), np.zeros(n1 - a1), np.zeros(n2)]
    Xd = np.c_[np.ones(len(x)), x]
    nll = lambda b: -(y * (Xd @ b) - np.logaddexp(0, Xd @ b)).sum()
    grad = lambda b: -Xd.T @ (y - expit(Xd @ b))
    r = optimize.minimize(nll, np.zeros(2), jac=grad, method='BFGS', options=dict(gtol=1e-10, maxiter=10000))
    mu = expit(Xd @ r.x)
    I = (Xd * (mu * (1 - mu))[:, None]).T @ Xd
    W = r.x[1] ** 2 / np.linalg.inv(I)[1, 1]
    print(f'T={T}: individual-level beta1={r.x[1]:.5f} SE={np.sqrt(np.linalg.inv(I)[1,1]):.5f} Wald p={stats.chi2.sf(W,1):.4e}'
          f'   lib Wald p={pv["wald"][T]:.4e}  LRT p={pv["lrt"][T]:.4e} score p={pv["score"][T]:.4e}')

rng = np.random.default_rng(25202)
alphas = [0.05, 1e-4]
for n, maf, phi, R in [(500, 0.05, 0.5, 10_000_000), (5000, 0.01, 0.05, 10_000_000), (5000, 0.05, 0.02, 10_000_000)]:
    n0, n1, n2 = B.design(n, maf)
    A = int(round(phi * n))
    P = B.pmf_T(n0, n1, n2, A)
    pv, ex = B.all_pvalues(n0, n1, n2, A)
    cnt = {t: np.zeros(2) for t in pv}
    done = 0
    while done < R:
        b = min(1_000_000, R - done)
        smp = rng.multivariate_hypergeometric(np.array([n0, n1, n2]), A, size=b)
        T = smp[:, 1] + 2 * smp[:, 2]
        for t in pv:
            p = pv[t][T]
            for i, a in enumerate(alphas):
                cnt[t][i] += (p <= a).sum()
        done += b
    print(f'MC n={n} maf={maf} phi={phi} R={R}:')
    for t in pv:
        exact = [B.type1(P, pv[t], a) for a in alphas]
        print(f'   {t:6s} MC {cnt[t][0]/R:.5f} {cnt[t][1]/R:.3e}   exact {exact[0]:.5f} {exact[1]:.3e}')
