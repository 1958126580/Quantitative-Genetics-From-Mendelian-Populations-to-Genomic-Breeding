# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1h_tails.py    依赖：numpy, scipy
"""Upper/lower tail split of linear-model false positives (alpha 5e-8), n = 5000, all imbalance rows;
first-order Cramer factor exp(gamma z^3/6); gamma formula (25.8b) vs exact."""
import numpy as np, warnings
from scipy import stats
import binlib as B
warnings.simplefilter('ignore')
z = np.sqrt(stats.chi2.isf(5e-8, 1))
print('z=%.4f z^3/6=%.4f  z(0.05)^3/6=%.4f' % (z, z ** 3 / 6, 1.959964 ** 3 / 6))
maxrel = 0
for maf in (0.05, 0.01):
    for phi in (0.5, 0.2, 0.1, 0.05, 0.02, 0.01):
        n = 5000
        n0, n1, n2 = B.design(n, maf); A = int(round(phi * n))
        P = B.pmf_T(n0, n1, n2, A); pv, ex = B.all_pvalues(n0, n1, n2, A, spa=False)
        T = np.arange(len(P)); ET = A * (n1 + 2 * n2) / n
        rej = pv['linear'] <= 5e-8
        up, lo = P[rej & (T > ET)].sum(), P[rej & (T < ET)].sum()
        counts = np.array([n0, n1, n2]); x = np.array([0, 1, 2.]); c = x - (counts * x).sum() / n; mu = A / n
        g = (1 - 2 * mu) * (counts * c ** 3).sum() / (np.sqrt(mu * (1 - mu)) * ((counts * c ** 2).sum()) ** 1.5)
        gf = (1 - 2 * phi) * (1 - 2 * maf) / np.sqrt(2 * n * maf * (1 - maf) * phi * (1 - phi))
        if g > 0:
            maxrel = max(maxrel, abs(gf - g) / g)
        print(f'maf={maf} phi={phi}: upper {up:.4e} (ratio to 2.5e-8: {up/2.5e-8:.2f})  lower {lo:.4e}  gamma {g:.4f} formula {gf:.4f}  exp(g z^3/6)={np.exp(g*z**3/6):.2f}')
print('max relative error of (25.8b):', maxrel)
