# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1a_normal.py    依赖：numpy, scipy
"""§25.2.4 Part A: normal linear model, y = mu + z*alpha + e, H0: alpha = 0.
Under H0 with normal errors and ANY fixed non-constant z, R^2 ~ Beta(1/2, (n-2)/2).
W  = n R^2/(1-R^2)   (Wald with ML variance SSE1/n)
LR = -n log(1-R^2)
S  = n R^2           (score with sigma0^2 = SSE0/n)
T2 = (n-2) R^2/(1-R^2)  (t^2 of eq 25.4 referred to chi2_1 as in eq 25.6)
Exact type I error of each chi2_1-referenced test = P(Beta > threshold).
Also Monte Carlo check (seed 25201) with a low-MAF genotype to show MAF irrelevance.
"""
import numpy as np
from scipy import stats

alphas = [0.05, 1e-4, 5e-8]
ns = [50, 100, 500, 5000]
print('chi2 crit:', {a: stats.chi2.isf(a, 1) for a in alphas})
res = {}
for n in ns:
    b = stats.beta(0.5, (n - 2) / 2)
    row = []
    for a in alphas:
        c = stats.chi2.isf(a, 1)
        thrW = c / (n + c)
        thrLR = -np.expm1(-c / n)
        thrS = c / n
        thrT2 = c / (n - 2 + c)
        eW, eLR, eS, eT2 = (b.sf(thrW), b.sf(thrLR), b.sf(thrS) if thrS < 1 else 0.0, b.sf(thrT2))
        row.append((a, eW, eLR, eS, eT2))
        print(f'n={n:5d} alpha={a:.0e}: W={eW:.4e} ({eW/a:.3f}x)  LR={eLR:.4e} ({eLR/a:.3f}x)  '
              f'S={eS:.4e} ({eS/a:.3f}x)  t2chi2={eT2:.4e} ({eT2/a:.3f}x)')
    res[n] = row

# Monte Carlo check: n=50, two genotype designs (MAF 0.5 and MAF 0.05), 2e6 reps each
rng = np.random.default_rng(25201)
for n, maf in [(50, 0.5), (50, 0.05), (500, 0.01)]:
    R = 2_000_000
    # genotype fixed per design (drawn once), phenotypes random
    while True:
        z = rng.binomial(2, maf, size=n).astype(float)
        if z.std() > 0:
            break
    zc = z - z.mean()
    Sxx = zc @ zc
    cnt = np.zeros((3, 4))
    done = 0
    while done < R:
        B = min(200_000, R - done)
        Y = rng.standard_normal((B, n))
        Yc = Y - Y.mean(axis=1, keepdims=True)
        Syy = np.einsum('ij,ij->i', Yc, Yc)
        Sxy = Yc @ zc
        R2 = Sxy ** 2 / (Sxx * Syy)
        W = n * R2 / (1 - R2)
        LR = -n * np.log1p(-R2)
        S = n * R2
        T2 = (n - 2) * R2 / (1 - R2)
        for i, a in enumerate(alphas[:2]):
            c = stats.chi2.isf(a, 1)
            cnt[i] += [(W > c).sum(), (LR > c).sum(), (S > c).sum(), (T2 > c).sum()]
        done += B
    print(f'MC n={n} maf={maf} carriers={int((z>0).sum())}: alpha=0.05 ->', np.round(cnt[0] / R, 5),
          ' alpha=1e-4 ->', cnt[1] / R)
