# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1e_tables.py    依赖：numpy, scipy
"""Final numbers for §25.2.4 and §25.2.5 (tables 25.1-25.3)."""
import numpy as np, json, warnings
from scipy import stats
import binlib as B
warnings.simplefilter('ignore')
alphas = [0.05, 1e-4, 5e-8]
res = {}

print('--- Table 25.1: normal linear model, exact (ratio actual/nominal)')
for n in [50, 100, 500, 5000]:
    b = stats.beta(0.5, (n - 2) / 2)
    cells = []
    for a in alphas:
        c = stats.chi2.isf(a, 1)
        W = b.sf(c / (n + c)); LR = b.sf(-np.expm1(-c / n)); S = b.sf(c / n) if c < n else 0.0
        T2 = b.sf(c / (n - 2 + c))
        cells.append((W / a, LR / a, S / a, T2 / a))
    print(f'n={n:5d} | ' + ' | '.join(f'W {w:.3f} LR {l:.3f} S {s:.3f} t2 {t:.3f}' for w, l, s, t in cells))
    res[f'normal_{n}'] = cells

print('--- Table 25.2: logistic, phi=0.5, three tests (ratio), min attainable p')
for n in [500, 5000]:
    for maf in [0.5, 0.05, 0.01]:
        n0, n1, n2 = B.design(n, maf)
        A = n // 2
        P = B.pmf_T(n0, n1, n2, A)
        pv, ex = B.all_pvalues(n0, n1, n2, A)
        cells = []
        for a in alphas:
            cells.append(tuple(B.type1(P, pv[t], a) / a for t in ['wald', 'score', 'lrt']))
        mins = {t: pv[t].min() for t in ['wald', 'score', 'lrt']}
        psep = P[ex['Tmin']] + P[ex['Tmax']]
        print(f'n={n} maf={maf} design=({n0},{n1},{n2}) A={A} | ' +
              ' | '.join('W %.3f S %.3f LR %.3f' % c for c in cells) +
              f' | min p W {mins["wald"]:.3e} S {mins["score"]:.3e} LR {mins["lrt"]:.3e} | P(sep) {psep:.3e}')
        res[f'logit_{n}_{maf}'] = dict(design=[n0, n1, n2], A=A, cells=cells, mins=mins, psep=psep)

print('--- Table 25.3: imbalance, n=5000, alpha=5e-8 (ratio), plus alpha=1e-4')
for maf in [0.05, 0.01]:
    for phi in [0.5, 0.2, 0.1, 0.05, 0.02, 0.01]:
        n = 5000
        n0, n1, n2 = B.design(n, maf)
        A = int(round(phi * n))
        P = B.pmf_T(n0, n1, n2, A)
        pv, ex = B.all_pvalues(n0, n1, n2, A)
        counts = np.array([n0, n1, n2]); x = np.array([0, 1, 2.])
        xbar = (counts * x).sum() / n; c = x - xbar
        mu = A / n
        gamma = (1 - 2 * mu) * (counts * c ** 3).sum() / (np.sqrt(mu * (1 - mu)) * ((counts * c ** 2).sum()) ** 1.5)
        gamma_formula = (1 - 2 * phi) * (1 - 2 * maf) / np.sqrt(2 * n * maf * (1 - maf) * phi * (1 - phi))
        r8 = {t: B.type1(P, pv[t], 5e-8) / 5e-8 for t in ['linear', 'score', 'lrt', 'wald', 'spa']}
        r4 = {t: B.type1(P, pv[t], 1e-4) / 1e-4 for t in ['linear', 'score', 'lrt', 'wald', 'spa']}
        r05 = {t: B.type1(P, pv[t], 0.05) / 0.05 for t in ['linear', 'score', 'lrt', 'wald', 'spa']}
        mac = 2 * A * maf
        print(f'maf={maf} phi={phi} A={A} MACcase={mac:.1f} gamma={gamma:.4f} (formula {gamma_formula:.4f}) | 5e-8: ' +
              ' '.join(f'{t} {r8[t]:.3g}' for t in r8) + ' | 1e-4: ' + ' '.join(f'{t} {r4[t]:.3g}' for t in r4)
              + ' | 0.05: ' + ' '.join(f'{t} {r05[t]:.3g}' for t in r05))
        res[f'imb_{maf}_{phi}'] = dict(design=[n0, n1, n2], A=A, mac=mac, gamma=gamma, gamma_formula=gamma_formula,
                                      r8=r8, r4=r4, r05=r05)
# where does the linear/score test put its false positives? upper vs lower tail, one example
n0, n1, n2 = B.design(5000, 0.01); A = 250
P = B.pmf_T(n0, n1, n2, A); pv, ex = B.all_pvalues(n0, n1, n2, A)
T = np.arange(len(P)); ET = A * (n1 + 2 * n2) / 5000
rej = pv['linear'] <= 5e-8
print('example maf=0.01 phi=0.05: E(T)=%.3f; rejections: upper tail mass %.4e (T>=%d), lower tail mass %.4e' % (
    ET, P[rej & (T > ET)].sum(), T[rej & (T > ET)].min(), P[rej & (T < ET)].sum()))
print('  normal-approx z at T=%d: %.3f ; exact P(T>=%d)=%.4e' % (T[rej & (T > ET)].min(),
      (T[rej & (T > ET)].min() - ET) / np.sqrt(((P * (T - ET) ** 2).sum())), T[rej & (T > ET)].min(), P[T >= T[rej & (T > ET)].min()].sum()))
json.dump(res, open('tables_s25_2.json', 'w'), indent=1, default=float)
