# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5a_ncf.py    依赖：scipy
"""Exact power of the t-test: noncentral F(1, n-2, ncp) with ncp = (n-1) 2pq a^2/se^2 = (n-1) q2/(1-q2)
(E(Sxx) = (n-1) 2pq under HWE), versus chi2 approximation with ncp = n q2/(1-q2)."""
import json
from scipy import stats
alpha = 5e-8
sim = json.load(open('s5a_power.json'))['sim']
for c in sim:
    n, q2 = c['n'], c['q2']
    Fc = stats.f.isf(alpha, 1, n - 2)
    ncp = (n - 1) * q2 / (1 - q2)
    pF = stats.ncf.sf(Fc, 1, n - 2, ncp)
    print(f"n={n} q2={q2} maf={c['maf']}: chi2-approx {c['analytic']:.4f}  exact-F {pF:.4f}  sim {c['empirical']:.4f} (SE {c['se']:.4f})  Fcrit {Fc:.3f}")
