# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 25 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1f_minmac.py    依赖：numpy, scipy
"""Minimum attainable p-value vs number of (heterozygous) carriers c, n = 5000, 1:1 design (A = 2500).
Exact: probability of the most extreme table P(T = c) (all carriers are cases), hypergeometric."""
import numpy as np, warnings
from scipy import stats
import binlib as B
warnings.simplefilter('ignore')
n, A = 5000, 2500
first = {}
for c in range(5, 41):
    n0, n1, n2 = n - c, c, 0
    pv, ex = B.all_pvalues(n0, n1, n2, A)
    P = B.pmf_T(n0, n1, n2, A)
    mins = {t: pv[t].min() for t in ('wald', 'score', 'lrt')}
    mins['exact'] = P[-1]
    for t, v in mins.items():
        if v < 5e-8 and t not in first:
            first[t] = c
    if c in (10, 20, 24, 25, 26, 30, 40):
        print(c, {k: f'{v:.3e}' for k, v in mins.items()})
print('smallest carrier count reaching p<5e-8:', first)
