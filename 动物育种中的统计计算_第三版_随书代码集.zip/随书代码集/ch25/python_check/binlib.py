# -*- coding: utf-8 -*-
"""Exact null distributions for single-SNP tests of a binary trait.

Design: genotype counts (n0, n1, n2) fixed (x = 0, 1, 2), number of cases A fixed
(case-control sampling / conditioning on the total).  Under H0 the cases are a
random subset of size A, so (a0, a1, a2) is multivariate hypergeometric and every
test statistic depends on the data only through T = a1 + 2 a2 (given A).
"""
import numpy as np
from scipy import stats
from scipy.special import gammaln, expit, log1p

X = np.array([0.0, 1.0, 2.0])


def design(n, maf):
    p = maf
    n2 = int(np.floor(n * p * p + 0.5))
    n1 = int(np.floor(2 * n * p * (1 - p) + 0.5))
    n0 = n - n1 - n2
    return n0, n1, n2


def lchoose(n, k):
    return gammaln(n + 1) - gammaln(k + 1) - gammaln(n - k + 1)


def pmf_T(n0, n1, n2, A):
    n = n0 + n1 + n2
    Tmax = n1 + 2 * n2
    P = np.zeros(Tmax + 1)
    a1 = np.arange(n1 + 1)
    lc = -lchoose(n, A)
    for a2 in range(0, n2 + 1):
        a0 = A - a1 - a2
        ok = (a0 >= 0) & (a0 <= n0)
        if not ok.any():
            continue
        lp = lchoose(n0, a0[ok]) + lchoose(n1, a1[ok]) + lchoose(n2, a2) + lc
        np.add.at(P, a1[ok] + 2 * a2, np.exp(lp))
    return P


def fill(A, counts, order):
    """cases filled into groups in the given order -> (a0,a1,a2)."""
    a = np.zeros(3, dtype=np.int64)
    left = A
    for g in order:
        take = min(left, counts[g])
        a[g] = take
        left -= take
    return a


def xlogy_safe(a, b):
    out = np.zeros_like(np.asarray(a, dtype=float))
    m = a > 0
    out[m] = a[m] * np.log(b[m] if np.ndim(b) else b)
    return out


def sat_loglik(a, counts):
    ll = 0.0
    for g in range(3):
        ng, ag = counts[g], a[g]
        if ng == 0:
            continue
        if 0 < ag < ng:
            ll += ag * np.log(ag / ng) + (ng - ag) * np.log(1 - ag / ng)
    return ll


def logistic_fit(counts, A, T, maxit=200, tol=1e-11):
    """Vectorised Newton with step-halving for grouped logistic regression.
    Only called for interior T (MLE exists)."""
    n = counts.sum()
    T = np.asarray(T, dtype=float)
    b0 = np.full(T.shape, np.log(A / (n - A)))
    b1 = np.zeros(T.shape)
    nc = counts.astype(float)

    def ll(b0, b1):
        eta = b0[:, None] + b1[:, None] * X[None, :]
        return b0 * A + b1 * T - (nc[None, :] * np.logaddexp(0, eta)).sum(1)

    cur = ll(b0, b1)
    for it in range(maxit):
        eta = b0[:, None] + b1[:, None] * X[None, :]
        mu = expit(eta)
        w = mu * (1 - mu)
        s0 = A - (nc * mu).sum(1)
        s1 = T - (nc * X * mu).sum(1)
        I00 = (nc * w).sum(1)
        I01 = (nc * X * w).sum(1)
        I11 = (nc * X * X * w).sum(1)
        det = I00 * I11 - I01 ** 2
        d0 = (I11 * s0 - I01 * s1) / det
        d1 = (-I01 * s0 + I00 * s1) / det
        step = np.ones(T.shape)
        for _ in range(60):
            nb0, nb1 = b0 + step * d0, b1 + step * d1
            new = ll(nb0, nb1)
            bad = ~(new >= cur - 1e-12)
            if not bad.any():
                break
            step = np.where(bad, step / 2, step)
        b0, b1, cur = nb0, nb1, new
        if max(np.abs(s0).max(), np.abs(s1).max()) < tol:
            break
    eta = b0[:, None] + b1[:, None] * X[None, :]
    mu = expit(eta)
    w = mu * (1 - mu)
    I00 = (nc * w).sum(1)
    I01 = (nc * X * w).sum(1)
    I11 = (nc * X * X * w).sum(1)
    var_b1 = I00 / (I00 * I11 - I01 ** 2)
    return b0, b1, var_b1, cur


def _newton_single(counts, A, T, b0, b1, maxit=500, tol=1e-11):
    nc = counts.astype(float)

    def ll(b0, b1):
        eta = b0 + b1 * X
        return b0 * A + b1 * T - (nc * np.logaddexp(0, eta)).sum()

    cur = ll(b0, b1)
    for it in range(maxit):
        eta = b0 + b1 * X
        mu = expit(eta)
        w = mu * (1 - mu)
        s0 = A - (nc * mu).sum()
        s1 = T - (nc * X * mu).sum()
        I00, I01, I11 = (nc * w).sum(), (nc * X * w).sum(), (nc * X * X * w).sum()
        det = I00 * I11 - I01 ** 2
        d0 = (I11 * s0 - I01 * s1) / det
        d1 = (-I01 * s0 + I00 * s1) / det
        st = 1.0
        for _ in range(80):
            nb0, nb1 = b0 + st * d0, b1 + st * d1
            new = ll(nb0, nb1)
            if new >= cur - 1e-12:
                break
            st /= 2
        b0, b1, cur = nb0, nb1, new
        if max(abs(s0), abs(s1)) < tol:
            break
    eta = b0 + b1 * X
    mu = expit(eta)
    w = mu * (1 - mu)
    I00, I01, I11 = (nc * w).sum(), (nc * X * w).sum(), (nc * X * X * w).sum()
    return b0, b1, I00 / (I00 * I11 - I01 ** 2), cur


def spa_pvalue(u, counts, mu, cutoff=2.0):
    """Two-sided saddlepoint p-value for U = sum_i c_i y_i, y_i ~ Bern(mu) indep.,
    c_i = x_i - xbar (Lugannani-Rice, as in SPAtest/SAIGE)."""
    n = counts.sum()
    xbar = (counts * X).sum() / n
    c = X - xbar
    nc = counts.astype(float)
    lo = np.log(mu) - np.log1p(-mu)
    var = mu * (1 - mu) * (nc * c * c).sum()
    u = np.asarray(u, dtype=float)

    def K(t):
        s = t[:, None] * c[None, :]
        return (nc * (np.log1p(-mu) + np.logaddexp(0, lo + s))).sum(1)

    def K1(t):
        s = t[:, None] * c[None, :]
        return (nc * c * expit(lo + s)).sum(1)

    def K2(t):
        s = t[:, None] * c[None, :]
        e = expit(lo + s)
        return (nc * c * c * e * (1 - e)).sum(1)

    # support limits of U (for bracketing)
    Umax = (nc * np.clip(c, 0, None)).sum()
    Umin = (nc * np.clip(c, None, 0)).sum()

    def tail(q):  # returns P(U >= q) if q>0 else P(U <= q)
        q = np.asarray(q, dtype=float)
        lo_t = np.full(q.shape, -1.0)
        hi_t = np.full(q.shape, 1.0)
        # expand bracket
        for _ in range(200):
            need = K1(hi_t) < q
            if not need.any():
                break
            hi_t = np.where(need, hi_t * 2, hi_t)
        for _ in range(200):
            need = K1(lo_t) > q
            if not need.any():
                break
            lo_t = np.where(need, lo_t * 2, lo_t)
        for _ in range(200):
            mid = (lo_t + hi_t) / 2
            f = K1(mid) - q
            lo_t = np.where(f < 0, mid, lo_t)
            hi_t = np.where(f >= 0, mid, hi_t)
        z = (lo_t + hi_t) / 2
        k1 = z * q - K(z)
        k2 = K2(z)
        w = np.sign(z) * np.sqrt(np.maximum(2 * k1, 0))
        v = z * np.sqrt(k2)
        with np.errstate(divide='ignore', invalid='ignore'):
            zt = w + np.log(v / w) / w
        p = np.where(zt > 0, stats.norm.sf(zt), stats.norm.cdf(zt))
        return p

    au = np.abs(u)
    zabs = au / np.sqrt(var)
    p = 2 * stats.norm.sf(zabs)
    use = (zabs > cutoff) & (au < min(Umax, -Umin) * (1 - 1e-12))
    if use.any():
        p1 = tail(au[use])
        p2 = tail(-au[use])
        p[use] = np.minimum(p1 + p2, 1.0)
    # beyond one side of the unconditional support: only the other tail is possible
    beyond = (zabs > cutoff) & ~use
    if beyond.any():
        pp = np.zeros(beyond.sum())
        ab = au[beyond]
        m_up = ab < Umax * (1 - 1e-12)
        m_lo = ab < -Umin * (1 - 1e-12)
        if m_up.any():
            pp[m_up] += tail(ab[m_up])
        if m_lo.any():
            pp[m_lo] += tail(-ab[m_lo])
        p[beyond] = np.minimum(pp, 1.0)
    return p


def all_pvalues(n0, n1, n2, A, spa=True):
    counts = np.array([n0, n1, n2], dtype=np.int64)
    n = counts.sum()
    Tvals = np.arange(n1 + 2 * n2 + 1)
    xbar = (n1 + 2 * n2) / n
    Sxx = n1 + 4 * n2 - n * xbar ** 2
    SSy = A * (1 - A / n)
    Sxy = Tvals - A * xbar
    r2 = Sxy ** 2 / (Sxx * SSy)
    out = {}
    # score (Cochran-Armitage trend, variance with n)
    S = n * r2
    out['score'] = stats.chi2.sf(S, 1)
    # linear regression t-test on 0/1 (what an LMM does without relatedness)
    with np.errstate(divide='ignore'):
        t2 = (n - 2) * r2 / np.maximum(1 - r2, 1e-300)
    out['linear'] = 2 * stats.t.sf(np.sqrt(t2), n - 2)
    # support of T given A
    Tmin = fill(A, counts, [0, 1, 2]) @ np.array([0, 1, 2])
    Tmax = fill(A, counts, [2, 1, 0]) @ np.array([0, 1, 2])
    ll0 = A * np.log(A / n) + (n - A) * np.log(1 - A / n)
    wald = np.ones(Tvals.shape)
    lrt = np.zeros(Tvals.shape)
    inner = (Tvals > Tmin) & (Tvals < Tmax)
    b0, b1, vb1, llmax = logistic_fit(counts, A, Tvals[inner])
    # robust fallback: warm-started sequential Newton for entries that failed (extreme T, prob < 1e-60)
    badm = ~np.isfinite(b1) | ~np.isfinite(vb1) | ~np.isfinite(llmax)
    if badm.any():
        Ti = Tvals[inner]
        good = np.where(~badm)[0]
        for k in np.where(badm)[0]:
            j = good[np.argmin(np.abs(good - k))]
            bb0, bb1 = b0[j], b1[j]
            # walk from j to k one T at a time
            stepdir = 1 if k > j else -1
            for kk in range(j + stepdir, k + stepdir, stepdir):
                bb0, bb1, vv, ll = _newton_single(counts, A, Ti[kk], bb0, bb1)
            b0[k], b1[k], vb1[k], llmax[k] = bb0, bb1, vv, ll
    W = b1 ** 2 / vb1
    wald[inner] = stats.chi2.sf(W, 1)
    lrt[inner] = 2 * (llmax - ll0)
    for Tb, order in [(Tmin, [0, 1, 2]), (Tmax, [2, 1, 0])]:
        a = fill(A, counts, order)
        lrt[Tvals == Tb] = 2 * (sat_loglik(a, counts) - ll0)
    out['wald'] = wald  # separation -> Wald p = 1 (Hauck-Donner limit)
    out['lrt'] = stats.chi2.sf(np.maximum(lrt, 0), 1)
    if spa:
        out['spa'] = spa_pvalue(Sxy, counts, A / n)
    extras = dict(Tvals=Tvals, Tmin=Tmin, Tmax=Tmax, inner=inner, b1=b1, W=W, lrt=lrt, S=S)
    return out, extras


def type1(P, pv, alpha):
    return float(P[pv <= alpha].sum())
