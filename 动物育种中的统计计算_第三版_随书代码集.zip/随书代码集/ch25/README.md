# 第二十五章　全基因组关联分析 —— 配套代码

**所属**：第六篇　关联分析与统计基因组学　　**对应正文**：第二十五章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch25.ipynb` | IJulia 笔记本：13 个代码单元，约 504 行 Julia 代码，穿插与正文对应的说明 |
| `ch25.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 13 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　模拟数据：两个亚群 + 家系结构 + 少数真实 QTL
- 2　单标记检验（未校正）与 $\lambda_{GC}$
- 3　主成分校正及其局限
- 4　MLMA：特征分解加速的实现
- 5　LOCO：量化并消除 proximal contamination
- 6　GRAMMAR 与 GRAMMAR-Gamma（正文式 25.21）
- 7　多重检验
- 8　统计功效（正文式 25.26–25.31）
- 9　置换检验在家系资料中的失效（正文 §25.4.3）
- 10　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 25
```

或在 Jupyter 中打开 `ch25/ch25.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
