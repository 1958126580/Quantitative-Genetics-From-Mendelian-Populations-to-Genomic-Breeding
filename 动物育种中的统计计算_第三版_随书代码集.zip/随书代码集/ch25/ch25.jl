# 本脚本由 tools/nb2jl.py 从同目录的 ch25.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 25

# %% [markdown]
# # 第二十五章　全基因组关联分析 —— 配套代码
#
# 本 Notebook 对应第二十五章。
#
# **内容**
#
# 1. 模拟一个有群体结构与家系结构的关联分析数据集
# 2. 单标记检验：普通最小二乘（naive）——观察假阳性
# 3. $\lambda_{GC}$ 与 QQ 图（正文式 25.11）
# 4. 主成分校正与它的局限（正文 §25.3.3）
# 5. **MLMA 的从零实现**：特征分解加速（正文式 25.16–25.17）
# 6. **LOCO**：proximal contamination 的量化与消除（正文式 25.19–25.20）
# 7. GRAMMAR 与 GRAMMAR-Gamma（正文式 25.21）
# 8. 多重检验：Bonferroni、有效独立检验数、BH-FDR、Storey $q$ 值
# 9. 功效计算与模拟验证（正文式 25.26–25.31）
# 10. 置换检验在家系资料中的失效演示（正文 §25.4.3）

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %%
"""按系谱做配子传递的简化模拟（与第二十一、二十三章相同），返回基因型、系谱与世代。"""
function sim_pedigree_genotypes(nbase::Int, ngen::Int, nper::Int, m::Int;
                                nchr::Int=10, r::Float64=0.02,
                                maf_min::Float64=0.05, rng=Random.default_rng())
    n = nbase + ngen*nper
    p0 = maf_min .+ (1 - 2maf_min) .* rand(rng, m)
    H = Array{Int8,3}(undef, n, m, 2)
    @inbounds for i in 1:nbase, j in 1:m, k in 1:2
        H[i,j,k] = Int8(rand(rng) < p0[j])
    end
    sire = zeros(Int, n); dam = zeros(Int, n); gen = zeros(Int, n)
    mper = m ÷ nchr
    @inbounds for g in 1:ngen
        lo = nbase + (g-1)*nper + 1; hi = nbase + g*nper; pool = lo - 1
        for i in lo:hi
            gen[i] = g
            s = rand(rng, 1:pool); d = rand(rng, 1:pool)
            while d == s; d = rand(rng, 1:pool); end
            sire[i] = s; dam[i] = d
            for (par, k) in ((s,1), (d,2))
                for c in 1:nchr
                    cur = rand(rng, 1:2)
                    for jj in 1:mper
                        j = (c-1)*mper + jj; j > m && break
                        if jj > 1 && rand(rng) < r; cur = 3 - cur; end
                        H[i,j,k] = H[par,j,cur]
                    end
                end
            end
        end
    end
    Mg = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        Mg[i,j] = Float64(H[i,j,1]) + Float64(H[i,j,2])
    end
    chrom = [min(nchr, (j-1) ÷ mper + 1) for j in 1:m]
    return Mg, sire, dam, gen, chrom
end

# %% [markdown]
# ## 1　模拟数据：两个亚群 + 家系结构 + 少数真实 QTL

# %%
"""构造一个含群体分层、家系结构与若干真实 QTL 的 GWAS 数据集。"""
function sim_gwas(; nbase=100, ngen=5, nper=150, m=2000, nqtl=8,
                    h2_qtl=0.20, h2_poly=0.25, strat=1.0, rng=Random.default_rng())
    # 两个"亚群"：分别演化，最后合并
    M1, s1, d1, g1, chr = sim_pedigree_genotypes(nbase, ngen, nper, m; rng=rng)
    M2, s2, d2, g2, _   = sim_pedigree_genotypes(nbase, ngen, nper, m; rng=Xoshiro(rand(rng, UInt32)))
    n1 = size(M1,1); n2 = size(M2,1)
    Mg  = vcat(M1, M2)
    pop = vcat(fill(1, n1), fill(2, n2))
    gen = vcat(g1, g2)
    sire = vcat(s1, s2 .+ ifelse.(s2 .> 0, n1, 0))
    dam  = vcat(d1, d2 .+ ifelse.(d2 .> 0, n1, 0))
    n = n1 + n2

    p = vec(mean(Mg, dims=1)) ./ 2
    keep = findall(j -> 0.02 < p[j] < 0.98, 1:m)
    Mg = Mg[:, keep]; p = p[keep]; chr = chr[keep]; m = length(keep)
    Z = Mg .- 2 .* p'

    # 真实 QTL
    qtl = sort(randperm(rng, m)[1:nqtl])
    aq  = randn(rng, nqtl)
    gq  = Z[:, qtl]*aq
    gq .*= sqrt(h2_qtl)/std(gq)

    # 多基因背景
    ap  = randn(rng, m)
    gp  = Z*ap
    gp .*= sqrt(h2_poly)/std(gp)

    # 分层效应：亚群 2 的表型均值更高
    st = strat .* (pop .== 2)

    y = 10.0 .+ gq .+ gp .+ st .+ randn(rng, n).*sqrt(1 - h2_qtl - h2_poly)
    return (y=y, Z=Z, Mg=Mg, p=p, chrom=chr, qtl=qtl, aq=aq,
            pop=pop, gen=gen, sire=sire, dam=dam, n=n, m=m,
            h2_qtl=h2_qtl, h2_poly=h2_poly)
end

D = sim_gwas(; rng=Xoshiro(2501))
@printf("个体 n = %d （亚群 1: %d ，亚群 2: %d）\n", D.n, count(==(1), D.pop), count(==(2), D.pop))
@printf("标记 m = %d ，染色体 %d 条\n", D.m, maximum(D.chrom))
@printf("真实 QTL %d 个，位置：%s\n", length(D.qtl), string(D.qtl))
@printf("亚群间表型均值差 = %.3f σ_P\n",
        (mean(D.y[D.pop.==2]) - mean(D.y[D.pop.==1]))/std(D.y))

# %% [markdown]
# ## 2　单标记检验（未校正）与 $\lambda_{GC}$

# %%
"""普通最小二乘的单标记扫描（正文式 25.7）。返回 (α̂, χ², p)。"""
function gwas_ols(y::Vector{Float64}, Z::Matrix{Float64}, X::Matrix{Float64})
    n, m = size(Z)
    Mp = I - X*((X'X)\X')                     # 对协变量的正交投影
    yt = Mp*y
    df = n - size(X,2) - 1
    alpha = zeros(m); chi2v = zeros(m)
    s2y = dot(yt, yt)
    @inbounds for j in 1:m
        zt = Mp*view(Z,:,j)
        zz = dot(zt, zt)
        zz < 1e-10 && continue
        a  = dot(zt, yt)/zz
        sse = s2y - a^2*zz
        s2e = sse/df
        chi2v[j] = a^2*zz/s2e
        alpha[j] = a
    end
    pv = ccdf.(Chisq(1), chi2v)
    return alpha, chi2v, pv
end

"""正文式 (25.11)：基因组膨胀因子。"""
lambda_gc(chi2v) = median(chi2v)/0.4549364

X0 = ones(D.n, 1)
a0, c0, p0 = gwas_ols(D.y, D.Z, X0)
@printf("未校正：λ_GC = %.3f\n", lambda_gc(c0))
@printf("  p < 1e-5 的标记数 = %d （真实 QTL 只有 %d 个）\n",
        count(<(1e-5), p0), length(D.qtl))
@printf("  其中命中真实 QTL 的 = %d\n", count(j -> p0[j] < 1e-5, D.qtl))

# QQ 图的数值（可用任意绘图包作图）
"""返回 QQ 图的 (理论 -log10p, 观测 -log10p)。"""
function qq_points(pv::Vector{Float64})
    m = length(pv); o = sort(pv)
    e = ((1:m) .- 0.5) ./ m
    return -log10.(e), -log10.(o)
end
te, to = qq_points(p0)
println("\nQQ 图（未校正）关键分位：")
@printf("%-14s%-14s%-14s\n", "理论 -log10p", "观测 -log10p", "偏离")
for frac in (0.5, 0.1, 0.01, 0.001)
    k = max(1, round(Int, frac*length(te)))
    @printf("%-14.3f%-14.3f%+-14.3f\n", te[k], to[k], to[k]-te[k])
end
println("=> 整条线上移（低分位也偏离）是分层的典型特征（正文 §25.3.2）。")

# %% [markdown]
# ## 3　主成分校正及其局限

# %%
"""构造 G 矩阵（VanRaden 方法 1）。"""
function grm(Z::AbstractMatrix, p::AbstractVector)
    s = 2*sum(p .* (1 .- p))
    return (Z*Z') ./ s
end

G = grm(D.Z, D.p)
ev = eigen(Symmetric(G))
idx = sortperm(ev.values; rev=true)
lamG = ev.values[idx]; U = ev.vectors[:, idx]

@printf("G 的前 8 个特征值：%s\n", string(round.(lamG[1:8], digits=2)))
@printf("第一主成分与亚群指示的相关 = %.3f\n", abs(cor(U[:,1], Float64.(D.pop))))

println("\nPCA 校正的效果：")
@printf("%-10s%-14s%-18s%-18s\n", "k", "λ_GC", "p<1e-5 标记数", "命中 QTL 数")
for k in (0, 1, 2, 5, 10, 20)
    Xk = k == 0 ? ones(D.n,1) : hcat(ones(D.n), U[:, 1:k])
    _, ck, pk = gwas_ols(D.y, D.Z, Xk)
    @printf("%-10d%-14.3f%-18d%-18d\n", k, lambda_gc(ck),
            count(<(1e-5), pk), count(j -> pk[j] < 1e-5, D.qtl))
end
println("\n=> 第一主成分就消除了大部分分层（它对应两个亚群）；")
println("   但继续增加 k 收益递减——PCA 无法刻画连续的家系关系（正文 §25.3.3）。")

# %% [markdown]
# ## 4　MLMA：特征分解加速的实现
#
# 正文式 (25.13)–(25.17)。
#
# **两步：**
# 1. 在**不含标记**的模型下用 REML 估计 $\delta=\sigma_e^2/\sigma_g^2$（一维搜索）；
# 2. 对每个标记用式 (25.15) 计算统计量。

# %%
"""在旋转空间中计算 REML 对数似然（正文式 25.17）。

`yt = U'y`，`Xt = U'X`，`lam` 为 G 的特征值，`delta = σe²/σg²`。
"""
function reml_ll_rotated(delta::Float64, yt::Vector{Float64}, Xt::Matrix{Float64},
                         lam::Vector{Float64})
    n = length(yt); q = size(Xt,2)
    d = lam .+ delta                          # V/σg² 的对角元
    Xd = Xt ./ d
    XtX = Xt'Xd
    Fc = cholesky(Symmetric(XtX + 1e-12I))
    b  = Fc \ (Xd'yt)
    r  = yt .- Xt*b
    rss = sum(r.^2 ./ d)
    s2g = rss/(n - q)
    return -0.5*((n-q)*log(s2g) + sum(log, d) + logdet(Fc) + (n-q)), s2g, b
end

"""用黄金分割在 log δ 上做一维搜索，返回 (δ̂, σ̂g², σ̂e², β̂)。"""
function reml_1d(y::Vector{Float64}, X::Matrix{Float64}, U::Matrix{Float64},
                 lam::Vector{Float64}; lo=-10.0, hi=10.0, tol=1e-8)
    yt = U'y; Xt = U'X
    f(t) = -reml_ll_rotated(exp(t), yt, Xt, lam)[1]
    gr = (sqrt(5)-1)/2
    a, b = lo, hi
    c = b - gr*(b-a); d = a + gr*(b-a)
    fc, fd = f(c), f(d)
    while (b-a) > tol
        if fc < fd
            b, d, fd = d, c, fc
            c = b - gr*(b-a); fc = f(c)
        else
            a, c, fc = c, d, fd
            d = a + gr*(b-a); fd = f(d)
        end
    end
    t = (a+b)/2; delta = exp(t)
    _, s2g, beta = reml_ll_rotated(delta, yt, Xt, lam)
    return delta, s2g, s2g*delta, beta
end

"""MLMA：给定 G 的特征分解，扫描全部标记（正文式 25.15）。"""
function mlma(y::Vector{Float64}, Z::Matrix{Float64}, X::Matrix{Float64},
              U::Matrix{Float64}, lam::Vector{Float64})
    n, m = size(Z)
    delta, s2g, s2e, _ = reml_1d(y, X, U, lam)
    d  = lam .+ delta
    yt = U'y; Xt = U'X
    Xd = Xt ./ d
    XtXi = inv(Symmetric(Xt'Xd + 1e-12I))
    # Py = V⁻¹y - V⁻¹X (X'V⁻¹X)⁻¹ X'V⁻¹ y   （在旋转空间，V/σg² 的对角为 d）
    Vy  = yt ./ d
    Py_rot = Vy .- Xd*(XtXi*(Xt'Vy))
    Zt = U'Z
    alpha = zeros(m); chi2v = zeros(m)
    @inbounds for j in 1:m
        zj = view(Zt, :, j)
        Vz = zj ./ d
        Pz = Vz .- Xd*(XtXi*(Xt'Vz))
        zPz = dot(zj, Pz)
        zPz < 1e-12 && continue
        zPy = dot(zj, Py_rot)
        alpha[j] = zPy/zPz
        chi2v[j] = zPy^2/(zPz*s2g)            # 除以 σg² 恢复到 V 的真实尺度
    end
    return alpha, chi2v, ccdf.(Chisq(1), chi2v), (delta=delta, s2g=s2g, s2e=s2e)
end

aM, cM, pM, vc = mlma(D.y, D.Z, X0, U, lamG)
@printf("REML： δ = σe²/σg² = %.4f ， σg² = %.4f ， σe² = %.4f\n", vc.delta, vc.s2g, vc.s2e)
@printf("       估计的“总”遗传力 = %.3f （真值 h²_qtl + h²_poly = %.3f）\n",
        vc.s2g/(vc.s2g+vc.s2e), D.h2_qtl + D.h2_poly)
@printf("\nMLMA： λ_GC = %.3f\n", lambda_gc(cM))
@printf("  p < 1e-5 的标记数 = %d ， 命中真实 QTL = %d\n",
        count(<(1e-5), pM), count(j -> pM[j] < 1e-5, D.qtl))

println("\n三种方法的比较：")
@printf("%-18s%-12s%-16s%-16s\n", "方法", "λ_GC", "p<1e-5", "命中 QTL")
_, c1, p1 = gwas_ols(D.y, D.Z, hcat(ones(D.n), U[:,1:5]))
@printf("%-18s%-12.3f%-16d%-16d\n", "OLS（未校正）", lambda_gc(c0), count(<(1e-5), p0), count(j->p0[j]<1e-5, D.qtl))
@printf("%-18s%-12.3f%-16d%-16d\n", "PCA（k=5）",    lambda_gc(c1), count(<(1e-5), p1), count(j->p1[j]<1e-5, D.qtl))
@printf("%-18s%-12.3f%-16d%-16d\n", "MLMA",          lambda_gc(cM), count(<(1e-5), pM), count(j->pM[j]<1e-5, D.qtl))

# %% [markdown]
# ## 5　LOCO：量化并消除 proximal contamination
#
# 正文式 (25.19)–(25.20)。

# %%
"""正文式 (25.20)：由全基因组 G 与单染色体 G_c 得到 LOCO 的 G^{(-c)}。"""
function grm_loco(Z::AbstractMatrix, p::AbstractVector, chrom::Vector{Int}, c::Int)
    jj = findall(!=(c), chrom)
    s  = 2*sum(p[jj] .* (1 .- p[jj]))
    Zc = view(Z, :, jj)
    return (Zc*Zc') ./ s
end

"""LOCO-MLMA：对每条染色体用排除该染色体的 G。"""
function mlma_loco(D)
    m = D.m; alpha = zeros(m); chi2v = zeros(m)
    X = ones(D.n, 1)
    for c in sort(unique(D.chrom))
        Gc = grm_loco(D.Z, D.p, D.chrom, c)
        Gc .= 0.99 .* Gc .+ 0.01 .* Matrix(I, D.n, D.n)
        e = eigen(Symmetric(Gc)); o = sortperm(e.values; rev=true)
        Uc = e.vectors[:, o]; lc = e.values[o]
        jj = findall(==(c), D.chrom)
        aj, cj, _, _ = mlma(D.y, D.Z[:, jj], X, Uc, lc)
        alpha[jj] .= aj; chi2v[jj] .= cj
    end
    return alpha, chi2v, ccdf.(Chisq(1), chi2v)
end

aL, cL, pL = mlma_loco(D)
@printf("LOCO-MLMA： λ_GC = %.3f\n", lambda_gc(cL))
@printf("  p < 1e-5 的标记数 = %d ， 命中真实 QTL = %d\n",
        count(<(1e-5), pL), count(j -> pL[j] < 1e-5, D.qtl))

println("\n真实 QTL 位点上的统计量（越大越好）：")
@printf("%-10s%-14s%-14s%-14s%-14s\n", "QTL", "|真效应|", "OLS χ²", "MLMA χ²", "LOCO χ²")
for (k, j) in enumerate(D.qtl)
    @printf("%-10d%-14.3f%-14.2f%-14.2f%-14.2f\n", j, abs(D.aq[k]), c0[j], cM[j], cL[j])
end
@printf("\n真实 QTL 的平均 χ²： OLS %.2f ， MLMA %.2f ， LOCO %.2f\n",
        mean(c0[D.qtl]), mean(cM[D.qtl]), mean(cL[D.qtl]))
@printf("非 QTL 的中位 χ²  ： OLS %.3f ， MLMA %.3f ， LOCO %.3f （理论 0.455）\n",
        median(c0[setdiff(1:D.m, D.qtl)]), median(cM[setdiff(1:D.m, D.qtl)]),
        median(cL[setdiff(1:D.m, D.qtl)]))
println("\n=> MLMA 把真实 QTL 的信号也收缩了（proximal contamination，正文 §25.3.5）；")
println("   LOCO 恢复了这部分功效，同时保持 λ_GC 接近 1。")

# %% [markdown]
# ## 6　GRAMMAR 与 GRAMMAR-Gamma（正文式 25.21）

# %%
"""GRAMMAR：先做不含标记的 BLUP，再对残差做普通回归。"""
function grammar(D, U, lam)
    X = ones(D.n, 1)
    delta, s2g, s2e, _ = reml_1d(D.y, X, U, lam)
    d  = lam .+ delta
    yt = U'D.y; Xt = U'X
    Xd = Xt ./ d
    XtXi = inv(Symmetric(Xt'Xd + 1e-12I))
    Vy = yt ./ d
    Py = Vy .- Xd*(XtXi*(Xt'Vy))
    ehat = U*(Py .* s2e)                     # 残差 = R P y
    _, chi_raw, _ = gwas_ols(ehat, D.Z, X)
    # 正文式 (25.21) 的 γ 校正因子
    Zt = U'D.Z
    gam = 0.0
    for j in 1:D.m
        zj = view(Zt,:,j); Vz = zj ./ d
        Pz = Vz .- Xd*(XtXi*(Xt'Vz))
        gam += dot(zj, Pz)/dot(zj, zj)
    end
    gam /= D.m
    return chi_raw, chi_raw ./ gam, gam
end

cg_raw, cg_adj, gam = grammar(D, U, lamG)
@printf("GRAMMAR 的 γ 校正因子 = %.4f\n\n", gam)
@printf("%-22s%-12s%-16s%-16s\n", "方法", "λ_GC", "真 QTL 平均 χ²", "p<1e-5")
@printf("%-22s%-12.3f%-16.2f%-16d\n", "GRAMMAR（未校正）", lambda_gc(cg_raw), mean(cg_raw[D.qtl]), count(<(1e-5), ccdf.(Chisq(1), cg_raw)))
@printf("%-22s%-12.3f%-16.2f%-16d\n", "GRAMMAR-Gamma",    lambda_gc(cg_adj), mean(cg_adj[D.qtl]), count(<(1e-5), ccdf.(Chisq(1), cg_adj)))
@printf("%-22s%-12.3f%-16.2f%-16d\n", "MLMA（精确）",      lambda_gc(cM),     mean(cM[D.qtl]),     count(<(1e-5), pM))
@printf("\ncor(GRAMMAR-Gamma χ², MLMA χ²) = %.4f\n", cor(cg_adj, cM))
println("=> γ 校正把 GRAMMAR 的保守性基本修正，代价只有 O(Nm)（正文 §25.3.6）。")

# %% [markdown]
# ## 7　多重检验

# %%
"""正文式 (25.22)：Li & Ji (2005) 的有效独立检验数。"""
function meff_lj(R::AbstractMatrix)
    lams = eigvals(Symmetric(R))
    lams = max.(lams, 0.0)
    return sum(l -> (l >= 1 ? 1.0 : 0.0) + (l - floor(l)), lams)
end

"""Benjamini–Hochberg 过程，返回被拒绝的下标与阈值。"""
function bh_fdr(pv::Vector{Float64}, q::Float64)
    m = length(pv); o = sortperm(pv)
    ps = pv[o]
    k = 0
    for i in 1:m
        ps[i] <= i*q/m && (k = i)
    end
    return o[1:k], k == 0 ? 0.0 : ps[k]
end

"""Storey 的 π̂₀（正文式 25.24）与 q 值（式 25.25）。"""
function storey_q(pv::Vector{Float64}; lambda=0.5)
    m = length(pv)
    pi0 = min(1.0, count(>(lambda), pv)/(m*(1-lambda)))
    o = sortperm(pv); ps = pv[o]
    q = similar(ps)
    q[m] = pi0*ps[m]
    for i in m-1:-1:1
        q[i] = min(q[i+1], pi0*m*ps[i]/i)
    end
    out = similar(q); out[o] = q
    return out, pi0
end

# 标记相关矩阵（取一条染色体做演示，避免 m×m 过大）
jj = findall(==(1), D.chrom)
Zc = D.Z[:, jj]
Rc = cor(Zc)
Rc[isnan.(Rc)] .= 0.0
mef = meff_lj(Rc)
@printf("染色体 1 上标记数 = %d ， Li&Ji 有效独立检验数 = %.1f （比值 %.2f）\n",
        length(jj), mef, mef/length(jj))

# 全基因组阈值的三种取法
Ne_eff, Lgen = 100, 30.0
Me_theory = 2*Ne_eff*Lgen/log(4*Ne_eff*Lgen)
@printf("\n全基因组显著性阈值（α = 0.05）\n")
@printf("  Bonferroni（m = %d）          ： %.2e\n", D.m, 0.05/D.m)
@printf("  Li&Ji 外推（×%.2f）           ： %.2e\n", mef/length(jj), 0.05/(D.m*mef/length(jj)))
@printf("  用 Me = 2NeL/ln(4NeL) = %.0f  ： %.2e\n", Me_theory, 0.05/Me_theory)
@printf("  人类常用 5e-8                  ： %.2e （对家畜过度保守）\n", 5e-8)

rej, thr = bh_fdr(pL, 0.05)
qv, pi0 = storey_q(pL)
@printf("\nFDR 控制（LOCO 的 p 值）\n")
@printf("  BH (q=0.05)     ： 拒绝 %d 个，阈值 p = %.2e ，其中真 QTL %d 个\n",
        length(rej), thr, length(intersect(rej, D.qtl)))
@printf("  Storey π̂₀      ： %.4f\n", pi0)
@printf("  Storey q<0.05   ： 拒绝 %d 个，其中真 QTL %d 个\n",
        count(<(0.05), qv), count(j -> qv[j] < 0.05, D.qtl))
@printf("  Bonferroni      ： 拒绝 %d 个，其中真 QTL %d 个\n",
        count(<(0.05/D.m), pL), count(j -> pL[j] < 0.05/D.m, D.qtl))

# %% [markdown]
# ## 8　统计功效（正文式 25.26–25.31）

# %%
"""正文式 (25.30)：非中心参数。"""
ncp_gwas(N, r2, h2j) = N*r2*h2j/(1 - h2j)

"""给定 α 与 ncp 的功效。"""
power_gwas(ncp, alpha) = ccdf(NoncentralChisq(1, ncp), quantile(Chisq(1), 1-alpha))

"""由目标功效反解所需样本量。"""
function required_N(h2j, r2, alpha, target)
    lo, hi = 10.0, 1e9
    for _ in 1:200
        mid = sqrt(lo*hi)
        power_gwas(ncp_gwas(mid, r2, h2j), alpha) < target ? (lo = mid) : (hi = mid)
    end
    return (lo+hi)/2
end

println("达到 80% 功效所需的样本量（α = 1e-6）\n")
@printf("%-12s", "h²_j")
for r2 in (1.0, 0.8, 0.5); @printf("%-16s", "r²=$(r2)"); end
println()
for h2j in (0.05, 0.02, 0.01, 0.005, 0.001, 0.0005)
    @printf("%-12.4f", h2j)
    for r2 in (1.0, 0.8, 0.5)
        @printf("%-16.0f", required_N(h2j, r2, 1e-6, 0.8))
    end
    println()
end

# 模拟验证
println("\n功效公式的模拟验证（α = 1e-4）")
@printf("%-10s%-12s%-16s%-16s\n", "N", "h²_j", "公式功效", "模拟功效")
for (N, h2j) in ((500, 0.05), (1000, 0.03), (2000, 0.02), (5000, 0.01))
    thr = quantile(Chisq(1), 1-1e-4)
    hits = 0; nrep = 400
    for rep in 1:nrep
        rg = Xoshiro(6000 + rep)
        pj = 0.3
        z  = [Float64(rand(rg) < pj) + Float64(rand(rg) < pj) for _ in 1:N] .- 2pj
        z .-= mean(z)
        a  = sqrt(h2j/(2*pj*(1-pj)))
        yv = z.*a .+ randn(rg, N).*sqrt(1-h2j)
        zz = dot(z,z); ah = dot(z,yv)/zz
        s2 = (dot(yv,yv) - ah^2*zz)/(N-2)
        hits += (ah^2*zz/s2 > thr)
    end
    @printf("%-10d%-12.3f%-16.3f%-16.3f\n", N, h2j,
            power_gwas(ncp_gwas(N, 1.0, h2j), 1e-4), hits/nrep)
end

# %%
# 选择性基因分型的效率（正文式 25.31）
"""两尾各截取 ρ 时的效率 1 + x·i，其中 x = Φ⁻¹(1-ρ)、i = φ(x)/ρ（截断选择的选择强度）。"""
function selgeno_eff(rho)
    x = quantile(Normal(), 1 - rho)
    i = pdf(Normal(), x) / rho
    return x, i, 1 + x * i
end

println("选择性基因分型的效率（相对于随机抽取同样数量的个体）\n")
@printf("%-10s%-12s%-10s%-10s%-12s%-16s\n", "上下各 ρ", "分型比例", "x", "i", "效率 1+xi", "模拟 E(y²|入选)")
ysim = randn(Xoshiro(2531), 2_000_000)
for rho in (0.05, 0.10, 0.20, 0.30, 0.50)
    x, i, eff = selgeno_eff(rho)
    sel = abs.(ysim) .> x                  # 上下两尾各 ρ
    @printf("%-10.2f%-12.2f%-10.3f%-10.3f%-12.3f%-16.3f\n", rho, 2rho, x, i, eff, mean(abs2, ysim[sel]))
end
_, _, e10 = selgeno_eff(0.10)
@printf("\n=> ρ = 0.10 时基因分型 20%% 的个体，功效相当于随机抽取约 %.0f%% 的样本量；\n", 100 * 2 * 0.10 * e10)
println("   但有四个重要限制，见正文 §25.5.3。")

# %% [markdown]
# ## 9　置换检验在家系资料中的失效（正文 §25.4.3）
#
# 置换要求个体**可交换**。有亲缘关系时，打乱表型会破坏真实的协方差结构，使零分布过松、阈值被低估。

# %%
"""朴素置换：打乱表型，记录全基因组最大 χ²。"""
function permutation_max(D, X; nperm=200, rng=Random.default_rng())
    out = Float64[]
    for _ in 1:nperm
        yp = D.y[randperm(rng, D.n)]
        _, cp, _ = gwas_ols(yp, D.Z, X)
        push!(out, maximum(cp))
    end
    return out
end

"""参数自助：在估计的 V 下模拟表型，保留真实的遗传协方差结构。"""
function parametric_max(D, X, U, lam; nperm=200, rng=Random.default_rng())
    delta, s2g, s2e, beta = reml_1d(D.y, X, U, lam)
    sd = sqrt.(max.(lam, 0.0) .* s2g)
    out = Float64[]
    for _ in 1:nperm
        ysim = X*beta .+ U*(sd .* randn(rng, D.n)) .+ randn(rng, D.n).*sqrt(s2e)
        _, cp, _ = gwas_ols(ysim, D.Z, X)
        push!(out, maximum(cp))
    end
    return out
end

mperm = permutation_max(D, X0; nperm=150, rng=Xoshiro(2520))
mpara = parametric_max(D, X0, U, lamG; nperm=150, rng=Xoshiro(2521))

@printf("全基因组最大 χ² 的 95%% 分位（经验显著性阈值）\n")
@printf("  朴素置换      ： %.2f   → 对应 p 阈值 %.2e\n",
        quantile(mperm, 0.95), ccdf(Chisq(1), quantile(mperm, 0.95)))
@printf("  参数自助      ： %.2f   → 对应 p 阈值 %.2e\n",
        quantile(mpara, 0.95), ccdf(Chisq(1), quantile(mpara, 0.95)))
@printf("  Bonferroni    ： %.2f   → 对应 p 阈值 %.2e\n",
        quantile(Chisq(1), 1-0.05/D.m), 0.05/D.m)
println("\n=> 朴素置换给出的阈值明显偏低（假阳性会增加），")
println("   因为打乱表型破坏了家系与分层造成的相关结构（正文 §25.4.3）。")

# %% [markdown]
# ## 10　自检汇总

# %%
ok = Bool[]
push!(ok, check("χ²_1 的中位数 = 0.4549", quantile(Chisq(1), 0.5), 0.4549364; tol=1e-5))
push!(ok, check("λ_GC 对同分布数据 ≈ 1",
                lambda_gc(rand(Xoshiro(1), Chisq(1), 200_000)), 1.0; tol=0.02))
# MLMA 在 G = I 时应退化为 OLS
let Ui = Matrix{Float64}(I, D.n, D.n), li = fill(1.0, D.n)
    _, ci, _, _ = mlma(D.y, D.Z, X0, Ui, li)
    @printf("G = I 时 cor(MLMA χ², OLS χ²) = %.6f\n", cor(ci, c0))
    push!(ok, cor(ci, c0) > 0.999)
end
# BH 的性质：拒绝数随 q 单调不减
let ns = [length(bh_fdr(pL, q)[1]) for q in (0.01, 0.05, 0.10, 0.20)]
    @printf("BH 拒绝数随 q： %s （应单调不减）\n", string(ns))
    push!(ok, issorted(ns))
end
# 功效公式与 required_N 互逆
push!(ok, check("required_N 与 power 互逆",
                power_gwas(ncp_gwas(required_N(0.01,1.0,1e-6,0.8), 1.0, 0.01), 1e-6),
                0.8; tol=1e-6))
# LOCO 应提高真 QTL 的平均 χ²
@printf("LOCO 相对 MLMA 在真 QTL 上的 χ² 提升 = %+.1f%%\n",
        100*(mean(cL[D.qtl])/mean(cM[D.qtl]) - 1))
push!(ok, mean(cL[D.qtl]) >= mean(cM[D.qtl]))
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
