# 本脚本由 tools/nb2jl.py 从同目录的 ch17.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 17

# %% [markdown]
# # 第十七章　似然方法：ML 与 REML 的原理 —— 配套代码
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | 似然面的可视化 | §17.5.1 |
# | 2 | ML 的向下偏性 | §17.2 |
# | 3 | **REML = ANOVA（平衡设计）** —— 最灵敏的实现检验 | §17.3.4 |
# | 4 | 信息矩阵与标准误、delta 法 | §17.4 |
# | 5 | 方差组分 LRT 的非标准零分布 | §17.5.3 |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions
rng = Xoshiro(20260918)

# ── 全书通用工具（第九章）────────────────────────────────────────────
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        b = inv(delta)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

# %% [markdown]
# ## 1　似然函数的实现（正文式 17.5、17.13）

# %%
"""
    loglik(theta, y, X, Vlist; restricted) -> loglikelihood

混合模型的对数似然。restricted=true 给出 REML（式 17.13），false 给出 ML（式 17.5）。
两者唯一的差别是 REML 多了 -0.5*log|X' V^-1 X| 一项。
"""
function loglik(theta::Vector{Float64}, y::Vector{Float64}, X::Matrix{Float64},
                Vlist::Vector{Matrix{Float64}}; restricted::Bool=true)
    any(theta .<= 0) && return -Inf
    V = sum(Vlist[i]*theta[i] for i in eachindex(theta))
    Vc = cholesky(Symmetric(V))
    Vi = inv(Vc)
    XtVi = X'*Vi
    M = XtVi*X
    P = Vi - Vi*X*(M \ XtVi)
    ll = -0.5*(logdet(Vc) + y'*P*y)
    restricted && (ll -= 0.5*logdet(M))
    return ll
end

# 平衡单因子数据
s, n = 30, 6
N = s*n
rr = Xoshiro(101)
a = randn(rr, s) .* sqrt(2.0)
grp = repeat(1:s, inner=n)
y = 10.0 .+ a[grp] .+ randn(rr, N).*sqrt(8.0)
X = ones(N, 1)
Z = zeros(N, s); for k in 1:N; Z[k, grp[k]] = 1.0; end
Vlist = [Z*Z', Matrix(1.0I, N, N)]

@printf("在真值处: REML loglik = %.4f ,  ML loglik = %.4f\n",
        loglik([2.0,8.0], y, X, Vlist; restricted=true),
        loglik([2.0,8.0], y, X, Vlist; restricted=false))
@printf("两者之差 = -0.5*log|X'V^-1 X| = %.4f\n",
        loglik([2.0,8.0],y,X,Vlist;restricted=true) - loglik([2.0,8.0],y,X,Vlist;restricted=false))

# %% [markdown]
# ## 2　REML 与 ML 的比较，以及"REML = ANOVA"的验证（正文 §17.3.4）
#
# **这是第五章案例五所说的最灵敏的实现检验。**

# %%
using Optim

"""用 Nelder–Mead 在对数尺度上最大化似然（对数参数化保证正定）。"""
function fit_vc(y, X, Vlist; restricted=true, start=[1.0,1.0])
    obj(g) = -loglik(exp.(g), y, X, Vlist; restricted=restricted)
    res = Optim.optimize(obj, log.(start), NelderMead(),
                         Optim.Options(g_tol=1e-12, iterations=20_000))
    return exp.(Optim.minimizer(res)), -Optim.minimum(res)
end

function anova_one_way(y::Vector{Float64}, grp::Vector{Int}, s::Int, n::Int)
    ybar = mean(y); ybari = [mean(y[grp .== i]) for i in 1:s]
    MSA = n*sum((ybari .- ybar).^2)/(s-1)
    MSE = sum((y .- ybari[grp]).^2)/(s*(n-1))
    return (MSA-MSE)/n, MSE
end

th_reml, ll_reml = fit_vc(y, X, Vlist; restricted=true)
th_ml,   ll_ml   = fit_vc(y, X, Vlist; restricted=false)
ea, ee = anova_one_way(y, grp, s, n)

println(rpad("方法", 14), rpad("sigma2_a", 14), rpad("sigma2_e", 14), "h2")
println("-"^52)
@printf("%-14s%-14.6f%-14.6f%.4f\n", "真值",  2.0, 8.0, 0.2)
@printf("%-14s%-14.6f%-14.6f%.4f\n", "ANOVA", ea, ee, ea/(ea+ee))
@printf("%-14s%-14.6f%-14.6f%.4f\n", "REML",  th_reml[1], th_reml[2], th_reml[1]/sum(th_reml))
@printf("%-14s%-14.6f%-14.6f%.4f\n", "ML",    th_ml[1], th_ml[2], th_ml[1]/sum(th_ml))
println()
@printf("REML 与 ANOVA 的相对差: sigma2_a %.2e , sigma2_e %.2e   <- 应当 ~ 0\n",
        abs(th_reml[1]-ea)/ea, abs(th_reml[2]-ee)/ee)
@printf("ML   与 ANOVA 的相对差: sigma2_a %.2e , sigma2_e %.2e   <- ML 有固有偏性\n",
        abs(th_ml[1]-ea)/ea, abs(th_ml[2]-ee)/ee)
println("\n=> 若你的「REML」实现在平衡设计上不等于 ANOVA，它多半实际上是 ML。")

# %% [markdown]
# ### 2.1 ML 偏性随固定效应个数的变化（正文式 17.7）

# %%
println(rpad("固定效应数 r", 16), rpad("r/N", 10), rpad("ML 均值", 14), rpad("REML 均值", 14), "ML 偏倚")
println("-"^68)
s, n = 20, 5; N = s*n
for nfix in (1, 5, 10, 20)
    mls = Float64[]; rmls = Float64[]
    for rep in 1:60
        rr = Xoshiro(hash((303, nfix, rep)))
        aa = randn(rr, s).*sqrt(2.0)
        gg = repeat(1:s, inner=n)
        Xf = hcat(ones(N), randn(rr, N, nfix-1))
        bf = randn(rr, nfix)
        yy = Xf*bf .+ aa[gg] .+ randn(rr, N).*sqrt(8.0)
        Zf = zeros(N, s); for k in 1:N; Zf[k, gg[k]] = 1.0; end
        Vl = [Zf*Zf', Matrix(1.0I, N, N)]
        tm, _ = fit_vc(yy, Xf, Vl; restricted=false, start=[2.0,8.0])
        tr_, _ = fit_vc(yy, Xf, Vl; restricted=true,  start=[2.0,8.0])
        push!(mls, tm[2]); push!(rmls, tr_[2])     # 看剩余方差
    end
    @printf("%-16d%-10.3f%-14.4f%-14.4f%+.1f%%\n", nfix, nfix/N,
            mean(mls), mean(rmls), 100*(mean(mls)-8.0)/8.0)
end
println("\n=> ML 的向下偏性正比于 r/N（正文式 17.7）。育种模型中 r 可达数千。")

# %% [markdown]
# ## 3　似然面的形状（正文 §17.5.1）

# %%
# 在 (sigma2_a, sigma2_e) 网格上计算 REML 似然
s, n = 30, 6; N = s*n
rr = Xoshiro(101)
a = randn(rr, s).*sqrt(2.0); grp = repeat(1:s, inner=n)
y = 10.0 .+ a[grp] .+ randn(rr, N).*sqrt(8.0)
X = ones(N,1); Z = zeros(N,s); for k in 1:N; Z[k,grp[k]]=1.0; end
Vlist = [Z*Z', Matrix(1.0I,N,N)]

as = range(0.2, 6.0; length=25)
es = range(5.0, 12.0; length=25)
LL = [loglik([av, ev], y, X, Vlist; restricted=true) for av in as, ev in es]
LL .-= maximum(LL)

println("REML 对数似然面（相对最大值，越接近 0 越好）：")
println(rpad("s2a \\ s2e", 12), join([rpad(@sprintf("%.1f", ev), 8) for ev in es[1:4:end]]))
println("-"^60)
for (i, av) in enumerate(as)
    i % 4 == 1 || continue
    @printf("%-12.2f%s\n", av, join([@sprintf("%-8.1f", LL[i,j]) for j in 1:4:length(es)]))
end
imax = argmax(LL)
@printf("\n网格最大点: sigma2_a = %.2f , sigma2_e = %.2f\n", as[imax[1]], es[imax[2]])
@printf("优化器结果: sigma2_a = %.2f , sigma2_e = %.2f\n", th_reml[1], th_reml[2])

# %% [markdown]
# ## 4　信息矩阵、标准误与 delta 法（正文 §17.4）

# %%
"""期望（Fisher）信息矩阵 I_ij = 0.5*tr(P V_i P V_j)（式 17.21）。"""
function fisher_information(theta, X, Vlist)
    V = sum(Vlist[i]*theta[i] for i in eachindex(theta))
    Vi = inv(Symmetric(V)); XtVi = X'*Vi
    P = Vi - Vi*X*((XtVi*X) \ XtVi)
    k = length(theta)
    return [0.5*tr(P*Vlist[i]*P*Vlist[j]) for i in 1:k, j in 1:k]
end

Ie = fisher_information(th_reml, X, Vlist)
Vth = inv(Ie)
se = sqrt.(diag(Vth))
@printf("sigma2_a = %.4f  (SE %.4f)\n", th_reml[1], se[1])
@printf("sigma2_e = %.4f  (SE %.4f)\n", th_reml[2], se[2])
@printf("Cov(s2a, s2e) = %.4f   相关 = %+.3f  <- 通常负相关\n",
        Vth[1,2], Vth[1,2]/(se[1]*se[2]))

# delta 法（式 17.25）
s2a, s2e = th_reml
s2P = s2a + s2e
h2 = s2a/s2P
g = [s2e/s2P^2, -s2a/s2P^2]
var_h2 = g' * Vth * g
var_h2_nocov = g[1]^2*Vth[1,1] + g[2]^2*Vth[2,2]
@printf("\nh2 = %.4f\n", h2)
@printf("SE(h2) 含协方差项   = %.4f\n", sqrt(var_h2))
@printf("SE(h2) 忽略协方差项 = %.4f   <- 高估 %.1f%%\n",
        sqrt(var_h2_nocov), 100*(sqrt(var_h2_nocov)-sqrt(var_h2))/sqrt(var_h2))
println("\n=> 忽略协方差项会高估 SE(h2)（正文 §17.4.4）。")

# %% [markdown]
# ## 5　方差组分 LRT 的非标准零分布（正文式 17.27）
#
# **零假设 $\sigma_a^2=0$ 落在参数空间边界上，Wilks 定理不适用。**

# %%
"""在 H0: sigma2_a = 0 下模拟 LRT 统计量的零分布。"""
function lrt_null_dist(s, n; R=1500)
    N = s*n; Xn = ones(N,1)
    grp = repeat(1:s, inner=n)
    Zn = zeros(N,s); for k in 1:N; Zn[k,grp[k]] = 1.0; end
    Vl = [Zn*Zn', Matrix(1.0I,N,N)]
    out = Float64[]
    for r in 1:R
        yy = 10.0 .+ randn(Xoshiro(hash((404,r))), N).*sqrt(8.0)   # sigma2_a = 0
        th, ll1 = fit_vc(yy, Xn, Vl; restricted=true, start=[0.5, 8.0])
        # H0 下的似然：sigma2_a -> 0
        ll0 = loglik([1e-10, var(yy)], yy, Xn, Vl; restricted=true)
        ll0 = maximum([loglik([1e-10, v], yy, Xn, Vl; restricted=true)
                       for v in range(0.5*var(yy), 1.5*var(yy); length=60)])
        push!(out, max(0.0, 2*(ll1 - ll0)))
    end
    return out
end

L0 = lrt_null_dist(20, 5; R=800)
@printf("模拟零分布：P(Lambda = 0) = %.3f   <- 理论 0.5（式 17.27）\n", mean(L0 .< 1e-6))
@printf("\n临界值比较：\n")
@printf("  朴素（chi2_1, 0.95）      = %.3f\n", quantile(Chisq(1), 0.95))
@printf("  正确（0.5*chi2_0 + 0.5*chi2_1）= %.3f\n", quantile(Chisq(1), 0.90))
@printf("  模拟 95%% 分位数             = %.3f\n", quantile(L0, 0.95))
println("\n=> 用 chi2_1 的临界值 3.84 会使检验过于保守（真实水平约 0.025）。")
println("   正确的临界值是 chi2_1 的 0.90 分位数 = 2.71。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **REML 与 ML 的唯一差别是 $-\tfrac12\log|\mathbf X'\mathbf V^{-1}\mathbf X|$ 一项**，本笔记本直接计算了这个差。
# 2. **平衡设计上 REML 精确等于 ANOVA，而 ML 不等于** —— 这是验证 REML 实现最灵敏的检验（第五章案例五）。
# 3. **ML 的向下偏性正比于 $r/N$**，模拟确认了式 (17.7)。
# 4. **似然面的网格可视化**给出了优化结果的独立确认。
# 5. **遗传力标准误的 delta 法必须包含协方差项**，否则高估。
# 6. **方差组分 LRT 的零分布是 $\tfrac12\chi^2_0+\tfrac12\chi^2_1$**：模拟显示约 50% 的统计量取 0，正确的临界值是 2.71 而非 3.84。
