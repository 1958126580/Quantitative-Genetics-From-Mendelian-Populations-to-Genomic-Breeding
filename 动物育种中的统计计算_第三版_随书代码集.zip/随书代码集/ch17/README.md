# 第十七章　似然方法：ML 与 REML 的原理 —— 配套代码

**所属**：第四篇　方差组分估计　　**对应正文**：第十七章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch17.ipynb` | IJulia 笔记本：7 个代码单元，约 203 行 Julia 代码，穿插与正文对应的说明 |
| `ch17.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 18 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　似然函数的实现（正文式 17.5、17.13）
- 2　REML 与 ML 的比较，以及"REML = ANOVA"的验证（正文 §17.3.4）
  - 2.1 ML 偏性随固定效应个数的变化（正文式 17.7）
- 3　似然面的形状（正文 §17.5.1）
- 4　信息矩阵、标准误与 delta 法（正文 §17.4）
- 5　方差组分 LRT 的非标准零分布（正文式 17.27）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 17
```

或在 Jupyter 中打开 `ch17/ch17.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
