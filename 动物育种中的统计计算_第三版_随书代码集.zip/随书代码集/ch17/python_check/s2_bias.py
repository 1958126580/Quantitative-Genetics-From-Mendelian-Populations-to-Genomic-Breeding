# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_bias.py    依赖：numpy
import numpy as np

print("="*72)
print("A. 单方差组分固定效应模型 y~N(Xb, I s2):  精确解析")
print("="*72)
print(" n     p   p/n     E(ML)/s2   相对偏 %   Var(ML)/s4  Var(REML)/s4  MSE(ML)/s4 MSE(REML)/s4")
rows = [(20,1),(20,2),(20,5),(20,10),(100,1),(100,5),(100,20),(100,50),
        (1000,10),(1000,100),(1000,300)]
for n,p in rows:
    eml = (n-p)/n
    vml = 2*(n-p)/n**2
    vre = 2/(n-p)
    mml = vml + (p/n)**2
    mre = vre
    print("%5d %5d  %5.3f   %9.6f  %8.2f   %10.6f  %12.6f  %10.6f %11.6f"
          % (n,p,p/n,eml,100*(eml-1),vml,vre,mml,mre))

print()
print("="*72)
print("B. 平衡单因子随机模型: 精确解析 (内点解, 不截断)")
print("="*72)
print("E(sa2_ML) = (s-1)/s * sa2 - se2/(s n);  偏 = -(se2 + n sa2)/(s n)")
print("\n  t=sa2/(sa2+se2)=0.25, sP2=1 :")
print("   s     n    r/N      E(sa2_ML)   相对偏%   由(17.7)式的粗略预测%")
t=0.25; sa2=t; se2=1-t
for s in [5,10,20,50,100]:
    for n in [2,5,10]:
        bias = -(se2 + n*sa2)/(s*n)
        e = sa2 + bias
        print("%5d %5d  %7.4f  %11.6f  %8.2f  %14.2f" % (s,n,1/(s*n),e,100*bias/sa2,-100/(s*n)))
print("\n  不同 t (s=20, n=5):")
print("     t      sa2      se2    E(sa2_ML)  相对偏%   E(h2_ML)近似  真 t")
for t in [0.05,0.10,0.25,0.40,0.60]:
    sa2=t; se2=1-t; s=20; n=5
    bias=-(se2+n*sa2)/(s*n)
    e=sa2+bias
    print("%7.2f %8.4f %8.4f %10.6f %8.2f %12.6f %8.2f" % (t,sa2,se2,e,100*bias/sa2,e/(e+se2),t))
