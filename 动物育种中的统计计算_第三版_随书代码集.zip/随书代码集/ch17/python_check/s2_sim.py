# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_sim.py    依赖：numpy, scipy
import numpy as np
from scipy.optimize import minimize_scalar

rng = np.random.default_rng(20250917)

# ---------- A. 固定效应模型，单方差组分 ----------
def simA(n, p, s2, B):
    X = np.zeros((n, p))
    idx = np.arange(n) % p
    X[np.arange(n), idx] = 1.0            # p 个水平的单因子（满秩）
    H = X @ np.linalg.solve(X.T @ X, X.T)
    M = np.eye(n) - H
    ml = np.empty(B); re = np.empty(B)
    for b in range(B):
        y = X @ np.ones(p)*3.0 + rng.standard_normal(n)*np.sqrt(s2)
        sse = y @ M @ y
        ml[b] = sse/n; re[b] = sse/(n-p)
    return ml, re

print("="*78)
print("A. 固定效应模型模拟 (B=5000):  s2=4.0")
print("="*78)
print("   n    p   解析E(ML)   模拟均值(ML)  差      解析E(REML) 模拟均值(REML)  差")
for n,p in [(20,2),(20,5),(20,10),(100,20)]:
    ml,re = simA(n,p,4.0,5000)
    print("%5d %4d %10.6f %12.6f %8.4f %11.6f %12.6f %9.4f"
          % (n,p,4.0*(n-p)/n, ml.mean(), ml.mean()-4.0*(n-p)/n, 4.0, re.mean(), re.mean()-4.0))

# ---------- B. 平衡单因子随机模型 (ANOVA 形式，不截断) ----------
def simB(s, n, sa2, se2, B):
    N = s*n
    ml_a = np.empty(B); re_a = np.empty(B); ml_e = np.empty(B); re_e = np.empty(B)
    for b in range(B):
        a = rng.standard_normal(s)*np.sqrt(sa2)
        y = (a[:,None] + rng.standard_normal((s,n))*np.sqrt(se2))
        gm = y.mean(); rm = y.mean(1)
        SSA = n*((rm-gm)**2).sum(); SSE = ((y-rm[:,None])**2).sum()
        MSA = SSA/(s-1); MSE = SSE/(s*(n-1))
        re_a[b] = (MSA-MSE)/n;            re_e[b] = MSE
        ml_a[b] = ((1-1/s)*MSA-MSE)/n;    ml_e[b] = MSE
    return ml_a, re_a, ml_e, re_e

print()
print("="*78)
print("B. 平衡单因子随机模型模拟 (B=5000, sa2=0.25, se2=0.75)")
print("="*78)
print("   s    n  解析E(sa2_ML) 模拟均值  差       解析E(sa2_RE) 模拟均值  差     P(sa2_RE<0)")
for s,n in [(5,5),(10,5),(20,5),(50,5),(20,10)]:
    ml_a,re_a,ml_e,re_e = simB(s,n,0.25,0.75,5000)
    ana = 0.25 - (0.75+n*0.25)/(s*n)
    print("%5d %4d %12.6f %9.6f %8.5f %12.6f %9.6f %8.5f %9.4f"
          % (s,n,ana,ml_a.mean(),ml_a.mean()-ana,0.25,re_a.mean(),re_a.mean()-0.25,(re_a<0).mean()))

print("\n  截断到 0 之后的均值 (s=20,n=5, B=5000):")
ml_a,re_a,ml_e,re_e = simB(20,5,0.25,0.75,5000)
print("   REML 不截断均值 = %.6f   截断后均值 = %.6f   P(=0) = %.4f"
      % (re_a.mean(), np.maximum(re_a,0).mean(), (re_a<0).mean()))
print("   ML   不截断均值 = %.6f   截断后均值 = %.6f   P(=0) = %.4f"
      % (ml_a.mean(), np.maximum(ml_a,0).mean(), (ml_a<0).mean()))
print("   => 截断使 REML 变成向上偏；ML 的向下偏被截断部分抵消。")
