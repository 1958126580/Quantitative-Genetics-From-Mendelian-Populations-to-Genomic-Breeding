# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_invariance.py    依赖：numpy
import numpy as np, common, reml
from common import X, Z, Y, A, N, p
from numpy.linalg import slogdet, inv, qr
ld = lambda M: slogdet(M)[1]

V1 = Z @ A @ Z.T; V0 = np.eye(N); Vlist=[V1,V0]
r = np.linalg.matrix_rank(X)

# --- 三种 K ---
Q, _ = qr(X, mode='complete')
K1 = Q[:, r:]                                        # 正交规范基, K1'K1 = I
M  = np.eye(N) - X @ np.linalg.pinv(X)               # I - X(X'X)^-X'
# 取 M 的 N-r 个线性无关列
piv = qr(M, mode='r')  # 不给主元, 改用 SVD 选列
cols=[];Mi=np.zeros((N,0))
for j in range(N):
    T=np.hstack([Mi,M[:,[j]]])
    if np.linalg.matrix_rank(T,tol=1e-8)>Mi.shape[1]: Mi=T; cols.append(j)
    if Mi.shape[1]==N-r: break
K2 = Mi
rng = np.random.default_rng(99)
S  = rng.standard_normal((N-r, N-r))
K3 = K1 @ S                                          # K1 的任意非奇异变换

print("K1'X 最大绝对元 = %.2e ; K2'X = %.2e ; K3'X = %.2e ; 秩 = %d,%d,%d"
      % (np.abs(K1.T@X).max(), np.abs(K2.T@X).max(), np.abs(K3.T@X).max(),
         np.linalg.matrix_rank(K1), np.linalg.matrix_rank(K2), np.linalg.matrix_rank(K3)))

def lR_K(theta, K):
    V = sum(t*Vi for t,Vi in zip(theta,Vlist))
    KVK = K.T @ V @ K
    return -0.5*((N-r)*np.log(2*np.pi) + ld(KVK) + Y@K@np.linalg.solve(KVK, K.T@Y))

print("\n=== 变换不变性：三个 K 在四组 theta 上的 ell_R ===")
print(" sa2   se2     ell_R(K1)     ell_R(K2)     ell_R(K3)   K1-K2      K1-K3    式(17.13)")
thetas=[(2.0,6.0),(0.5,9.0),(4.0,3.0),(1.0,1.0)]
d12=[];d13=[]
for sa2,se2 in thetas:
    a=lR_K((sa2,se2),K1); b=lR_K((sa2,se2),K2); c=lR_K((sa2,se2),K3)
    V=sa2*V1+se2*V0; Vi=inv(V); XVX=X.T@Vi@X
    P=Vi-Vi@X@np.linalg.solve(XVX,X.T@Vi)
    core=-0.5*(ld(V)+ld(XVX)+Y@P@Y)
    d12.append(a-b); d13.append(a-c)
    print("%5.1f %5.1f %13.8f %13.8f %13.8f %10.6f %10.6f %12.8f"%(sa2,se2,a,b,c,a-b,a-c,core))
print("K1-K2 的四个差值的极差 = %.3e ; K1-K3 的极差 = %.3e"
      % (max(d12)-min(d12), max(d13)-min(d13)))
print("理论常数 -0.5*log(|K2'K2|/|K1'K1|) = %.8f ; 实测 = %.8f"
      % (-0.5*(ld(K2.T@K2)-ld(K1.T@K1)), -np.mean(d12)))
print("理论常数 -0.5*log(|K3'K3|/|K1'K1|) = %.8f ; 实测 = %.8f"
      % (-0.5*(ld(K3.T@K3)-ld(K1.T@K1)), -np.mean(d13)))

print("\n=== 恒等式 (17.11) 与 (17.12) 的数值验证 (sa2=2, se2=6) ===")
V=2.0*V1+6.0*V0; Vi=inv(V); XVX=X.T@Vi@X
P=Vi-Vi@X@np.linalg.solve(XVX,X.T@Vi)
for nm,K in [("K1",K1),("K2",K2),("K3",K3)]:
    KVK=K.T@V@K
    Q_=K@np.linalg.solve(KVK,K.T)
    lhs=ld(KVK); rhs=ld(V)+ld(XVX)-ld(X.T@X)+ld(K.T@K)
    print("  %s: max|K(K'VK)^-1K' - P| = %.3e ;  log|K'VK|: 左=%.8f 右=%.8f 差=%.2e"
          % (nm, np.abs(Q_-P).max(), lhs, rhs, lhs-rhs))
