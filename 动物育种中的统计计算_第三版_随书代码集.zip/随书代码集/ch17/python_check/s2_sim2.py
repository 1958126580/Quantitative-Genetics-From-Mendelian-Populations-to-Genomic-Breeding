# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_sim2.py    依赖：numpy, scipy
import numpy as np
from scipy.optimize import minimize_scalar
rng = np.random.default_rng(31415)

def simB(s, n, sa2, se2, B):
    re_a = np.empty(B); ml_a = np.empty(B)
    for b in range(B):
        a = rng.standard_normal(s)*np.sqrt(sa2)
        y = a[:,None] + rng.standard_normal((s,n))*np.sqrt(se2)
        gm = y.mean(); rm = y.mean(1)
        MSA = n*((rm-gm)**2).sum()/(s-1); MSE = ((y-rm[:,None])**2).sum()/(s*(n-1))
        re_a[b] = (MSA-MSE)/n; ml_a[b] = ((1-1/s)*MSA-MSE)/n
    return ml_a, re_a

B = 20000
print("="*86)
print("B. 平衡单因子随机模型：解析式 vs 模拟 (B=%d)，sP2=1" % B)
print("="*86)
print("   t     s   n  解析E(sa2_ML) 模拟均值±MCSE     解析E(sa2_RE) 模拟均值±MCSE    P(RE<0)")
for t,s,n in [(0.25,5,5),(0.25,20,5),(0.25,50,5),(0.05,20,5),(0.05,50,10)]:
    sa2=t; se2=1-t
    ml,re = simB(s,n,sa2,se2,B)
    ana = sa2 - (se2+n*sa2)/(s*n)
    print("%6.2f %4d %3d %12.6f  %9.6f±%.6f %12.6f  %9.6f±%.6f %8.4f"
          % (t,s,n,ana,ml.mean(),ml.std(ddof=1)/np.sqrt(B),
             sa2,re.mean(),re.std(ddof=1)/np.sqrt(B),(re<0).mean()))

# ------- C. 混合模型：固定效应个数 p 增长时 ML / REML 的偏性 -------
def profile_fit(y, X, Zgroups, s, n, kind):
    """balanced one-way random + arbitrary X. Profile out se2; 1-D search on gam=sa2/se2."""
    N = s*n; p = np.linalg.matrix_rank(X)
    ZZt_apply = lambda M: np.add.reduceat(M, np.arange(0,N,n), axis=0).repeat(n, axis=0)
    def neg(lg):
        gam = np.exp(lg)
        c = gam/(1+n*gam)
        Wi = lambda M: M - c*ZZt_apply(M)          # W^{-1} M
        WiX = Wi(X); Wiy = Wi(y)
        XWX = X.T @ WiX
        sgn, ldXWX = np.linalg.slogdet(XWX)
        sol = np.linalg.solve(XWX, X.T @ Wiy)
        q = y @ Wiy - (X.T @ Wiy) @ sol
        ldW = s*np.log(1+n*gam)
        if kind=='reml':
            return 0.5*((N-p)*np.log(q/(N-p)) + ldW + ldXWX)
        else:
            return 0.5*(N*np.log(q/N) + ldW)
    r = minimize_scalar(neg, bounds=(-25, 8), method='bounded',
                        options=dict(xatol=1e-10))
    gam = np.exp(r.x)
    c = gam/(1+n*gam)
    Wi = lambda M: M - c*ZZt_apply(M)
    WiX = Wi(X); Wiy = Wi(y); XWX = X.T @ WiX
    sol = np.linalg.solve(XWX, X.T @ Wiy)
    q = y @ Wiy - (X.T @ Wiy) @ sol
    se2 = q/((N-p) if kind=='reml' else N)
    if gam < 1e-8: gam = 0.0
    return gam*se2, se2

s, n = 20, 5; N = s*n
sa2t, se2t = 0.25, 0.75
perm = np.random.default_rng(7).permutation(N)
print()
print("="*86)
print("C. 混合模型模拟：s=20 家系 x n=5, sa2=0.25, se2=0.75, 固定效应水平数 p 增长 (B=2000)")
print("="*86)
print("    p   r/N  ML:mean(sa2) 偏%   REML:mean(sa2) 偏%   ML:mean(se2) 预测(N-p)/N*se2 REML:mean(se2)  ML:mean(h2) REML:mean(h2)  ML边界% REML边界%")
Bc = 2000
for p in [1,5,10,20,40]:
    X = np.zeros((N,p))
    lab = np.empty(N,dtype=int); lab[perm] = np.arange(N) % p
    X[np.arange(N), lab] = 1.0
    ma=[];ra=[];me=[];re_=[]
    rg = np.random.default_rng(1000+p)
    beta = rg.standard_normal(p)*2.0
    for b in range(Bc):
        a = rg.standard_normal(s)*np.sqrt(sa2t)
        y = X@beta + np.repeat(a,n) + rg.standard_normal(N)*np.sqrt(se2t)
        x1 = profile_fit(y,X,None,s,n,'ml'); x2 = profile_fit(y,X,None,s,n,'reml')
        ma.append(x1[0]); me.append(x1[1]); ra.append(x2[0]); re_.append(x2[1])
    ma=np.array(ma);ra=np.array(ra);me=np.array(me);re_=np.array(re_)
    h2m = ma/(ma+me); h2r = ra/(ra+re_)
    print("%5d %6.3f %11.6f %7.2f %13.6f %7.2f %12.6f %14.6f %13.6f %11.6f %12.6f %8.2f %9.2f"
          % (p,p/N,ma.mean(),100*(ma.mean()-sa2t)/sa2t,ra.mean(),
             100*(ra.mean()-sa2t)/sa2t,me.mean(),se2t*(N-p)/N,re_.mean(),
             h2m.mean(),h2r.mean(),100*(ma<1e-9).mean(),100*(ra<1e-9).mean()))
