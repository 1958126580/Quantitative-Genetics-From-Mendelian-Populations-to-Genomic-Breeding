# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s8_ident.py    依赖：numpy, scipy
"""数值验证：恒等式 (17.11)(17.12)、P 的性质、E(y'Py)=N-r、dP/dtheta"""
import numpy as np
from scipy.linalg import null_space
rng=np.random.default_rng(7)
N,r=12,3
X=rng.standard_normal((N,r))
B=rng.standard_normal((N,N)); V=B@B.T+N*np.eye(N)
V1=np.eye(N); B2=rng.standard_normal((N,N)); V2=B2@B2.T   # 两个"V_i"
Vi=np.linalg.inv(V); XtVi=X.T@Vi
P=Vi-XtVi.T@np.linalg.solve(XtVi@X,XtVi)
K=null_space(X.T)                    # N x (N-r), K'X=0, K'K=I
K2=K@np.linalg.qr(rng.standard_normal((N-r,N-r)))[0]@np.diag(rng.uniform(1,3,N-r))  # 另一组 K
print("rank(K)=%d, ||K'X||=%.2e"%(np.linalg.matrix_rank(K),np.abs(K.T@X).max()))
for nm,Kx in [("K (正交)",K),("K2 (一般)",K2)]:
    KVK=Kx.T@V@Kx
    P_K=Kx@np.linalg.solve(KVK,Kx.T)
    print("  %-10s ||K(K'VK)^-1K' - P||_max = %.3e"%(nm,np.abs(P_K-P).max()))
    lhs=np.linalg.slogdet(KVK)[1]
    rhs=(np.linalg.slogdet(V)[1]+np.linalg.slogdet(X.T@Vi@X)[1]
         -np.linalg.slogdet(X.T@X)[1]+np.linalg.slogdet(Kx.T@Kx)[1])
    print("  %-10s log|K'VK|=%.10f  右端=%.10f  差=%.2e"%(nm,lhs,rhs,lhs-rhs))
print("\nP 的性质：")
print("  ||PX||_max = %.3e"%np.abs(P@X).max())
print("  ||PVP-P||_max = %.3e"%np.abs(P@V@P-P).max())
print("  tr(PV) = %.10f   N-r = %d"%(np.trace(P@V),N-r))
y=rng.standard_normal(N)*2
bh=np.linalg.solve(X.T@Vi@X,X.T@Vi@y); eh=y-X@bh
print("  ||Py - V^-1 ehat||_max = %.3e"%np.abs(P@y-Vi@eh).max())
print("  y'Py - ehat'V^-1 ehat = %.3e"%(y@P@y-eh@Vi@eh))
# dP/dtheta = -P V_i P
def Pof(t):
    Vt=V+t*V2; Vit=np.linalg.inv(Vt); Xv=X.T@Vit
    return Vit-Xv.T@np.linalg.solve(Xv@X,Xv)
num=(Pof(1e-5)-Pof(-1e-5))/2e-5
print("  ||dP/dt - (-P V2 P)||_max = %.3e"%np.abs(num+P@V2@P).max())
# E(y'Py)=N-r 的蒙特卡洛
Lc=np.linalg.cholesky(V); R=200000
Y=X@rng.standard_normal(r)[:,None]+Lc@rng.standard_normal((N,R))
q=np.einsum('ij,ij->j',Y,P@Y)
print("  MC: E(y'Py)=%.4f (SE %.4f), N-r=%d"%(q.mean(),q.std()/np.sqrt(R),N-r))
# ML 得分与 REML 得分的差：tr(V^-1 V_i) - tr(P V_i) >= 0
for nm,Vx in [("V_i=I",V1),("V_i=ZAZ'型(半正定)",V2)]:
    d=np.trace(Vi@Vx)-np.trace(P@Vx)
    print("  %-18s tr(V^-1 V_i)-tr(P V_i)=%.6f  (=tr[(X'V^-1X)^-1 X'V^-1 V_i V^-1 X]=%.6f)"%
          (nm,d,np.trace(np.linalg.solve(X.T@Vi@X,X.T@Vi@Vx@Vi@X))))
