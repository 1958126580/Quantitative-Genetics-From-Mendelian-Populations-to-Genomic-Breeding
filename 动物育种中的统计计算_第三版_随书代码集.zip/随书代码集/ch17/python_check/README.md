# 第 17 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch17/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `c17b.py` | 数值复核 | numpy, scipy | 5.9 | `outputs/c17b.out` |
| `s10b.py` | 数值复核 | numpy, scipy | 41.1 | `outputs/s10b.out` |
| `s11_misc.py` | (a) \|V\| \|X'V^-1 X\| = \|R\| \|G\| \|C\| | numpy | 0.4 | `outputs/s11_misc.out` |
| `s1_balanced.py` | 平衡单因子随机模型：ML 与 REML 的解析解与数值验证 | numpy, scipy | 0.9 | `outputs/s1_balanced.out` |
| `s1_identities.py` | 数值复核 | numpy | 0.1 | `outputs/s1_identities.out` |
| `s2_bias.py` | 数值复核 | numpy | 0.1 | `outputs/s2_bias.out` |
| `s2_sim.py` | ---------- A. 固定效应模型，单方差组分 ---------- | numpy, scipy | 3.0 | `outputs/s2_sim.out` |
| `s2_sim2.py` | 数值复核 | numpy, scipy | 59.5 | `outputs/s2_sim2.out` |
| `s3_invariance.py` | --- 三种 K --- | numpy, scipy | 0.7 | `outputs/s3_invariance.out` |
| `s3_setup.py` | 数值复核 | numpy, scipy | 0.3 | `outputs/s3_setup.out` |
| `s3b_balanced.py` | 数值复核 | numpy, scipy | 4.7 | `outputs/s3b_balanced.out` |
| `s4_info.py` | 数值复核 | numpy, scipy | 1.2 | `outputs/s4_info.out` |
| `s4c_unbal.py` | 数值复核 | numpy, scipy | 2.9 | `outputs/s4c_unbal.out` |
| `s4d_boundary.py` | 边界解：sa2=0 时 se2 的闭式解 = y'P0y/(N-r) | numpy, scipy | 1.3 | `outputs/s4d_boundary.out` |
| `s5_profile.py` | 数值复核 | numpy, scipy | 1.2 | `outputs/s5_profile.out` |
| `s5b_lrt.py` | 数值复核 | numpy, scipy | 4.9 | `outputs/s5b_lrt.out` |
| `s5c_aic.py` | 数值复核 | numpy, scipy | 9.0 | `outputs/s5c_aic.out` |
| `s8_ident.py` | 数值验证：恒等式 (17.11)(17.12)、P 的性质、E(y'Py)=N-r、dP/dtheta | numpy, scipy | 0.5 | `outputs/s8_ident.out` |

公共函数模块（被上列脚本导入，不单独运行）：`amodel.py`、`common.py`、`reml.py`。
