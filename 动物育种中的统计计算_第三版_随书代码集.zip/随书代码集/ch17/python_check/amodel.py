# -*- coding: utf-8 -*-
"""小型动物模型：系谱、A 矩阵、基于特征分解的快速 REML/ML 剖面似然"""
import numpy as np

def build(seed=2024):
    rng = np.random.default_rng(seed)
    # 基础群 40 头（20 公 20 母），两个世代
    nsire0, ndam0 = 20, 20
    ped = [(0, 0)] * (nsire0 + ndam0)          # 0 表示未知
    sires = list(range(1, nsire0 + 1))
    dams  = list(range(nsire0 + 1, nsire0 + ndam0 + 1))
    g1 = []
    for k in range(200):                        # 第一世代 200 头
        s = sires[k % nsire0]; d = dams[rng.integers(ndam0)]
        ped.append((s, d)); g1.append(len(ped))
    g1_s = g1[:100]; g1_d = g1[100:]
    g2 = []
    for k in range(400):                        # 第二世代 400 头
        s = g1_s[k % 100]; d = g1_d[rng.integers(100)]
        ped.append((s, d)); g2.append(len(ped))
    return ped, g1, g2, rng

def amat(ped):
    m = len(ped); A = np.zeros((m, m))
    for i in range(m):
        s, d = ped[i]
        for j in range(i):
            asj = A[s - 1, j] if s else 0.0
            adj = A[d - 1, j] if d else 0.0
            A[i, j] = A[j, i] = 0.5 * (asj + adj)
        if s and d:
            A[i, i] = 1.0 + 0.5 * A[s - 1, d - 1]
        else:
            A[i, i] = 1.0
    return A

class Model:
    """V* = h2 * ZAZ' + (1-h2) * I ; 事先特征分解 ZAZ' 以便 O(N^2) 评估似然"""
    def __init__(self, A, rec, X):
        m = A.shape[0]; N = len(rec)
        Z = np.zeros((N, m)); Z[np.arange(N), np.array(rec) - 1] = 1.0
        self.G = Z @ A @ Z.T
        self.G = 0.5 * (self.G + self.G.T)
        w, U = np.linalg.eigh(self.G)
        self.w, self.U = w, U
        self.X = X; self.Xt = U.T @ X
        self.N = N; self.r = np.linalg.matrix_rank(X); self.Z = Z; self.A = A
    def prep(self, y):
        self.y = y; self.yt = self.U.T @ y
    def _core(self, h2):
        d = h2 * self.w + (1 - h2)                # V* 的特征值
        di = 1.0 / d
        XtD = self.Xt * di[:, None]
        M = self.Xt.T @ XtD                        # X'V*^-1 X
        sgn, ldM = np.linalg.slogdet(M)
        b = np.linalg.solve(M, XtD.T @ self.yt)
        resid = self.yt - self.Xt @ b
        q = float(resid @ (di * resid))            # y'P* y
        return np.log(d).sum(), ldM, q
    def lR(self, h2):
        ldV, ldM, q = self._core(h2)
        nr = self.N - self.r
        return -0.5 * (nr * np.log(q / nr) + ldV + ldM) - 0.5 * nr, q / nr
    def lR_at(self, h2, sP2):
        ldV, ldM, q = self._core(h2)
        nr = self.N - self.r
        return -0.5 * (nr * np.log(sP2) + ldV + ldM + q / sP2)
    def lML(self, h2):
        ldV, ldM, q = self._core(h2)
        N = self.N
        return -0.5 * (N * np.log(2*np.pi*q/N) + ldV) - 0.5 * N, q / N
    def fit(self, y, restricted=True, lo=0.0, hi=0.999):
        self.prep(y)
        f = (lambda h: -self.lR(h)[0]) if restricted else (lambda h: -self.lML(h)[0])
        # 黄金分割 + 边界检查
        from scipy.optimize import minimize_scalar
        r = minimize_scalar(f, bounds=(lo, hi), method='bounded',
                            options=dict(xatol=1e-10))
        cand = [(f(lo), lo), (r.fun, r.x)]
        val, h = min(cand)
        sP2 = (self.lR(h)[1] if restricted else self.lML(h)[1])
        return h, sP2, -val
