# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_setup.py    依赖：numpy
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import numpy as np, sys
sys.path.insert(0, os.path.join(HERE, 'ch17'))
from amodel import build, amat, Model
ped, g1, g2, rng = build()
A = amat(ped)
m = len(ped)
rec = g1 + g2                      # 600 条记录
N = len(rec)
rng2 = np.random.default_rng(99)
herd = rng2.integers(0, 10, N)
X = np.zeros((N, 10)); X[np.arange(N), herd] = 1.0
print("系谱 m=%d, 记录 N=%d, rank(X)=%d" % (m, N, np.linalg.matrix_rank(X)))
print("A 对角线均值 %.4f, 最大 %.4f; 近交个体数 %d" %
      (np.diag(A).mean(), np.diag(A).max(), (np.diag(A) > 1 + 1e-12).sum()))
np.save(os.path.join(HERE, 'A.npy'), A)
np.save(os.path.join(HERE, 'rec.npy'), np.array(rec))
np.save(os.path.join(HERE, 'X.npy'), X)
