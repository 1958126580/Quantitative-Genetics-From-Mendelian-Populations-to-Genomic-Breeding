# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5c_aic.py    依赖：numpy, scipy
import numpy as np
from scipy.optimize import minimize_scalar
from numpy.linalg import slogdet, solve
ld = lambda M: slogdet(M)[1]


def fitR(y, X, s, n, drop_XX=True):
    N = s * n
    p = np.linalg.matrix_rank(X)
    agg = lambda M: np.add.reduceat(M, np.arange(0, N, n), axis=0).repeat(n, axis=0)

    def parts(g):
        c = g / (1 + n * g)
        Wi = lambda M: M - c * agg(M)
        WiX = Wi(X); Wiy = Wi(y); XWX = X.T @ WiX
        sol = solve(XWX, X.T @ Wiy)
        q = y @ Wiy - (X.T @ Wiy) @ sol
        return q, s * np.log(1 + n * g), ld(XWX)

    def neg(lg):
        q, ldW, ldXWX = parts(np.exp(lg))
        return 0.5 * ((N - p) * np.log(q / (N - p)) + ldW + ldXWX)

    r = minimize_scalar(neg, bounds=(-25, 8), method='bounded', options=dict(xatol=1e-12))
    g = np.exp(r.x)
    q, ldW, ldXWX = parts(g)
    se2 = q / (N - p)
    sa2 = g * se2
    ell = -0.5 * ((N - p) * np.log(2 * np.pi) + (N - p) * np.log(q / (N - p)) + ldW + ldXWX + (N - p))
    if not drop_XX:
        ell += 0.5 * ld(X.T @ X)
    if g < 1e-8:
        sa2 = 0.0
    return sa2, se2, ell, p


s, n = 20, 5
N = s * n
rg = np.random.default_rng(2468)
a = rg.standard_normal(s) * 1.0
z = rg.standard_normal(N) * 3.0
y = np.round(50 + 2.0 * z + np.repeat(a, n) + rg.standard_normal(N) * 3.0, 3)

print("=" * 78)
print("(1) X scale change: estimates unchanged, reported ell_R changes")
X1 = np.column_stack([np.ones(N), z])
X2 = np.column_stack([np.ones(N), 10 * z])
for nm, X in [("z original", X1), ("z x 10   ", X2)]:
    sa2, se2, ell, p = fitR(y, X, s, n)
    print("  %s: sa2=%.10f se2=%.10f  ell_R(17.13 convention)=%.8f" % (nm, sa2, se2, ell))
d = fitR(y, X2, s, n)[2] - fitR(y, X1, s, n)[2]
print("  diff = %.8f ; theory -log(10) = %.8f ; residual = %.2e" % (d, -np.log(10), d + np.log(10)))
for nm, X in [("z original", X1), ("z x 10   ", X2)]:
    print("  %s: with +0.5 log|X'X| restored, ell = %.8f" % (nm, fitR(y, X, s, n, drop_XX=False)[2]))

print()
print("=" * 78)
print("(2) adding a pure-noise covariate to X (B=2000)")
B = 2000
diffs = []
rg2 = np.random.default_rng(13579)
for b in range(B):
    aa = rg2.standard_normal(s) * 1.0
    yy = 50 + np.repeat(aa, n) + rg2.standard_normal(N) * 3.0
    junk = rg2.standard_normal(N)
    XA = np.ones((N, 1))
    XB = np.column_stack([np.ones(N), junk])
    diffs.append(fitR(yy, XB, s, n)[2] - fitR(yy, XA, s, n)[2])
diffs = np.array(diffs)
print("  ell_R(with junk) - ell_R(without): mean %.4f sd %.4f median %.4f"
      % (diffs.mean(), diffs.std(ddof=1), np.median(diffs)))
print("  fraction positive = %.4f" % (diffs > 0).mean())
print("  range: [%.4f, %.4f]" % (diffs.min(), diffs.max()))
