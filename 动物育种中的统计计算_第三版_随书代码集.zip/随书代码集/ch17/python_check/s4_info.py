# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4_info.py    依赖：numpy
import numpy as np, common, reml
from common import X, Z, Y, A, N, q, p

V1 = Z @ A @ Z.T          # V_a
V0 = np.eye(N)            # V_e
Vlist = [V1, V0]

th_r, l_r = reml.fit(Y, Vlist, X, [2.0, 6.0], 'reml')
th_m, l_m = reml.fit(Y, Vlist, X, [2.0, 6.0], 'ml')
print("=== 小例的 REML 与 ML 估计（N=12, p=2, q=4）===")
print("REML: sa2 = %.6f  se2 = %.6f  h2 = %.6f  lR = %.6f"
      % (th_r[0], th_r[1], th_r[0]/(th_r[0]+th_r[1]), l_r))
print("ML  : sa2 = %.6f  se2 = %.6f  h2 = %.6f  lM = %.6f"
      % (th_m[0], th_m[1], th_m[0]/(th_m[0]+th_m[1]), l_m))
print("得分（REML 解处）=", reml.score(th_r, Y, Vlist, X))

O, E, AI = reml.infos(th_r, Y, Vlist, X)
print("\n=== 三种信息矩阵（在 REML 解处，顺序 sa2, se2）===")
for nm, M in [("观测 I^O", O), ("期望 I^E", E), ("平均 I^A", AI)]:
    print(nm, "=", np.array2string(M, precision=6, suppress_small=False))
print("\n检验 I^A = (I^O+I^E)/2 :", np.max(np.abs(AI - 0.5*(O+E))))

print("\n=== 由三种信息矩阵得到的方差—协方差与 SE ===")
for nm, M in [("I^O", O), ("I^E", E), ("I^A", AI)]:
    Cv = np.linalg.inv(M)
    print("%s: Var(sa2)=%.6f Var(se2)=%.6f Cov=%.6f | SE(sa2)=%.6f SE(se2)=%.6f 相关=%.6f"
          % (nm, Cv[0,0], Cv[1,1], Cv[0,1], np.sqrt(Cv[0,0]), np.sqrt(Cv[1,1]),
             Cv[0,1]/np.sqrt(Cv[0,0]*Cv[1,1])))

# delta 法
print("\n=== delta 法 SE(h2) ===")
sa2, se2 = th_r
sp = sa2 + se2
g = np.array([se2/sp**2, -sa2/sp**2])
for nm, M in [("I^O", O), ("I^E", E), ("I^A", AI)]:
    Cv = np.linalg.inv(M)
    v = g @ Cv @ g
    v_nocov = g[0]**2*Cv[0,0] + g[1]**2*Cv[1,1]
    print("%s: h2=%.6f  Var(h2)=%.8f SE=%.6f | 忽略协方差 SE=%.6f"
          % (nm, sa2/sp, v, np.sqrt(v), np.sqrt(v_nocov)))
