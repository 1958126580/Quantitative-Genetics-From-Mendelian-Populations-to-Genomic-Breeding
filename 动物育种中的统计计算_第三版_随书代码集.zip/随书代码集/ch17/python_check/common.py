# -*- coding: utf-8 -*-
"""Shared small example for chapter 17."""
import numpy as np

def amat(ped):
    """ped: list of (sire,dam) 1-based, 0 = unknown, animals in order."""
    n = len(ped)
    A = np.zeros((n, n))
    for i in range(n):
        s, d = ped[i]
        s -= 1; d -= 1
        for j in range(i):
            asj = A[s, j] if s >= 0 else 0.0
            adj = A[d, j] if d >= 0 else 0.0
            A[i, j] = A[j, i] = 0.5 * (asj + adj)
        asd = A[s, d] if (s >= 0 and d >= 0) else 0.0
        A[i, i] = 1.0 + 0.5 * asd
    return A

# ---- the running example: N=12 records, 2 fixed levels, 4 related sires ----
PED = [(0, 0), (0, 0), (1, 2), (1, 3)]      # 4 animals
A = amat(PED)

N, q, p = 12, 4, 2
# fixed factor: herd with 2 levels (cell-means coding)
herd = np.array([1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2])
X = np.zeros((N, p))
for i, h in enumerate(herd):
    X[i, h - 1] = 1.0
# each animal has 3 records
anim = np.array([1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4])
Z = np.zeros((N, q))
for i, a in enumerate(anim):
    Z[i, a - 1] = 1.0

# data (generated once with seed 17, rounded to 1 decimal -> printable in the book)
Y = np.array([17.8, 24.6, 20.4, 23.4, 18.7, 24.2,
              27.7, 25.2, 25.6, 24.8, 25.0, 23.0])

def VGR(sa2, se2):
    G = A * sa2
    R = np.eye(N) * se2
    V = Z @ G @ Z.T + R
    return V, G, R

def Pmat(V, X):
    Vi = np.linalg.inv(V)
    M = X.T @ Vi @ X
    return Vi - Vi @ X @ np.linalg.solve(M, X.T @ Vi), Vi, M

def Cmat(G, R, X, Z):
    Ri = np.linalg.inv(R)
    Gi = np.linalg.inv(G)
    C = np.block([[X.T @ Ri @ X, X.T @ Ri @ Z],
                  [Z.T @ Ri @ X, Z.T @ Ri @ Z + Gi]])
    rhs = np.concatenate([X.T @ Ri @ Y, Z.T @ Ri @ Y])
    return C, rhs, Ri, Gi
