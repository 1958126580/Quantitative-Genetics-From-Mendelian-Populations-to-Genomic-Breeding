# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_balanced.py    依赖：numpy, scipy
"""平衡单因子随机模型：ML 与 REML 的解析解与数值验证"""
import numpy as np
np.set_printoptions(precision=6, suppress=True)

def simulate(s, n, sa2, se2, rng):
    a = rng.normal(0, np.sqrt(sa2), s)
    e = rng.normal(0, np.sqrt(se2), (s, n))
    return 10.0 + a[:, None] + e

def sums(y):
    s, n = y.shape
    gm = y.mean(); rm = y.mean(axis=1)
    SSA = n * ((rm - gm) ** 2).sum()
    SSE = ((y - rm[:, None]) ** 2).sum()
    return SSA, SSE

def est(y):
    s, n = y.shape
    SSA, SSE = sums(y)
    MSA = SSA / (s - 1); MSE = SSE / (s * (n - 1))
    reml_a = (MSA - MSE) / n; reml_e = MSE
    ml_a = (SSA / s - MSE) / n;  ml_e = MSE
    return reml_a, reml_e, ml_a, ml_e

# ---- 1. 用一般公式（数值最大化 ell_R / ell_P）验证解析解 ----
def loglik(y, sa2, se2, restricted):
    s, n = y.shape; N = s * n
    l1 = se2 + n * sa2; l2 = se2
    SSA, SSE = sums(y)
    logdetV = s * np.log(l1) + s * (n - 1) * np.log(l2)
    quad = SSA / l1 + SSE / l2
    if restricted:
        # log|X'V^-1 X| = log(N/l1)
        return -0.5 * (logdetV + np.log(N / l1) + quad)
    return -0.5 * (N * np.log(2 * np.pi) + logdetV + quad)

def brute(y, restricted, lo=1e-6, hi=None):
    from scipy.optimize import minimize
    s, n = y.shape
    f = lambda p: -loglik(y, np.exp(p[0]), np.exp(p[1]), restricted)
    r = minimize(f, [0.0, 0.0], method='Nelder-Mead',
                 options=dict(xatol=1e-12, fatol=1e-14, maxiter=20000, maxfev=20000))
    return np.exp(r.x)

rng = np.random.default_rng(20240517)
s, n, sa2, se2 = 20, 5, 4.0, 16.0
y = simulate(s, n, sa2, se2, rng)
ra, re, ma, me = est(y)
SSA, SSE = sums(y)
print("=== 单个数据集 s=20 n=5 sa2=4 se2=16 ===")
print("SSA=%.6f SSE=%.6f MSA=%.6f MSE=%.6f" % (SSA, SSE, SSA/(s-1), SSE/(s*(n-1))))
print("ANOVA/REML 解析:  sa2=%.6f  se2=%.6f" % (ra, re))
print("ML 解析:          sa2=%.6f  se2=%.6f" % (ma, me))
print("数值最大化 REML:  ", brute(y, True))
print("数值最大化 ML:    ", brute(y, False))
print("ell_R at REML=%.6f  ell_R at ML=%.6f" % (loglik(y, ra, re, True), loglik(y, ma, me, True)))
print("ell_P at ML  =%.6f  ell_P at REML=%.6f" % (loglik(y, ma, me, False), loglik(y, ra, re, False)))
