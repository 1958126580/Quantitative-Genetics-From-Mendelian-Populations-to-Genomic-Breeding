# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3b_balanced.py    依赖：numpy
import numpy as np, reml
rng = np.random.default_rng(1703)

def make_balanced(s, n, sa2, se2, seed):
    rg = np.random.default_rng(seed)
    a = rg.standard_normal(s)*np.sqrt(sa2)
    y = 50.0 + a[:,None] + rg.standard_normal((s,n))*np.sqrt(se2)
    return np.round(y, 2)

def anova(y2):
    s, n = y2.shape; N=s*n
    gm=y2.mean(); rm=y2.mean(1)
    SSA=n*((rm-gm)**2).sum(); SSE=((y2-rm[:,None])**2).sum()
    MSA=SSA/(s-1); MSE=SSE/(s*(n-1))
    return SSA,SSE,MSA,MSE,(MSA-MSE)/n,MSE

for s,n,seed,tag in [(6,4,2024,'小例 s=6,n=4'),(20,5,2025,'例 s=20,n=5')]:
    y2 = make_balanced(s,n,4.0,12.0,seed)
    N=s*n; y=y2.ravel()
    X=np.ones((N,1))
    Zg=np.zeros((N,s));  Zg[np.arange(N), np.repeat(np.arange(s),n)]=1.0
    Vlist=[Zg@Zg.T, np.eye(N)]
    SSA,SSE,MSA,MSE,aa,ae = anova(y2)
    th_r,lr = reml.fit(y,Vlist,X,[4.0,12.0],'reml'); th_r = reml.polish(th_r,y,Vlist,X,'reml')
    th_m,lm = reml.fit(y,Vlist,X,[4.0,12.0],'ml');   th_m = reml.polish(th_m,y,Vlist,X,'ml')
    print("="*76); print(tag, " N=%d"%N)
    print("  SSA=%.6f SSE=%.6f MSA=%.6f MSE=%.6f"%(SSA,SSE,MSA,MSE))
    print("  ANOVA : sa2=%.10f  se2=%.10f"%(aa,ae))
    print("  REML  : sa2=%.10f  se2=%.10f   |差| = %.2e , %.2e"
          %(th_r[0],th_r[1],abs(th_r[0]-aa),abs(th_r[1]-ae)))
    ml_a=((1-1/s)*MSA-MSE)/n
    print("  ML解析: sa2=%.10f  se2=%.10f"%(ml_a,MSE))
    print("  ML数值: sa2=%.10f  se2=%.10f   |差| = %.2e , %.2e"
          %(th_m[0],th_m[1],abs(th_m[0]-ml_a),abs(th_m[1]-MSE)))
    print("  ML 与 ANOVA 在 sa2 上的相对差 = %.4f%%"%(100*(ml_a-aa)/aa))
    if s==6:
        print("  数据（%d 组 x %d）:"%(s,n))
        for i in range(s): print("    组%d: "%(i+1), list(y2[i]))
