# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c17b.py    依赖：numpy, scipy
import numpy as np
from scipy.optimize import minimize
np.set_printoptions(precision=6,suppress=True)
A=np.array([[1,0,.5,.75],[0,1,.5,.25],[.5,.5,1,.75],[.75,.25,.75,1.25]])
y=np.array([17.8,24.6,20.4,23.4,18.7,24.2,27.7,25.2,25.6,24.8,25.0,23.0])
Z=np.zeros((12,4));  [Z.__setitem__((i,i//3),1) for i in range(12)]
X=np.zeros((12,2)); X[:5,0]=1; X[5:,1]=1
N,q,r=12,4,2
Ai=np.linalg.inv(A)
def Pmat(sa,se):
    V=Z@(A*sa)@Z.T+np.eye(N)*se
    Vi=np.linalg.inv(V)
    return Vi-Vi@X@np.linalg.inv(X.T@Vi@X)@X.T@Vi
def negl(th):
    sa,se=np.exp(th)
    V=Z@(A*sa)@Z.T+np.eye(N)*se
    sV,ldV=np.linalg.slogdet(V); Vi=np.linalg.inv(V)
    M=X.T@Vi@X; sM,ldM=np.linalg.slogdet(M)
    P=Vi-Vi@X@np.linalg.inv(M)@X.T@Vi
    return 0.5*(ldV+ldM+y@P@y)
res=minimize(negl,np.log([2.0,6.0]),method='Nelder-Mead',options=dict(xatol=1e-12,fatol=1e-14,maxiter=20000))
sa,se=np.exp(res.x); print('REML sa2=%.6f se2=%.6f  h2=%.6f'%(sa,se,sa/(sa+se)))
# derivative matrices
V1=Z@A@Z.T   # dV/dsa
V2=np.eye(N) # dV/dse
P=Pmat(sa,se)
dl=np.array([-0.5*(np.trace(P@V1)-y@P@V1@P@y), -0.5*(np.trace(P@V2)-y@P@V2@P@y)])
print('score at REML sol:',dl)
Vd=[V1,V2]
AIm=np.zeros((2,2)); FI=np.zeros((2,2)); OI=np.zeros((2,2))
for i in range(2):
    for j in range(2):
        FI[i,j]=0.5*np.trace(P@Vd[i]@P@Vd[j])
        AIm[i,j]=0.5*(y@P@Vd[i]@P@Vd[j]@P@y)
        OI[i,j]=-0.5*np.trace(P@Vd[i]@P@Vd[j])+y@P@Vd[i]@P@Vd[j]@P@y
print('Fisher(expected)\n',FI); print('Average\n',AIm); print('Observed\n',OI)
for nm,M in (('expected',FI),('average',AIm),('observed',OI)):
    C=np.linalg.inv(M); se_=np.sqrt(np.diag(C))
    # delta method for h2
    g=np.array([se/(sa+se)**2, -sa/(sa+se)**2])
    print(f'{nm:9s} SE(sa2)={se_[0]:.4f} SE(se2)={se_[1]:.4f} corr={C[0,1]/np.sqrt(C[0,0]*C[1,1]):+.4f} SE(h2)={np.sqrt(g@C@g):.4f}')
# profile likelihood CI for h2
def prof_h2(h2):
    def f(lt):
        tot=np.exp(lt); return negl(np.log([h2*tot,(1-h2)*tot]))
    from scipy.optimize import minimize_scalar
    rr=minimize_scalar(f,bounds=(np.log(0.5),np.log(500)),method='bounded',options=dict(xatol=1e-12))
    return -rr.fun
l0=prof_h2(sa/(sa+se))
import scipy.stats as st
crit=st.chi2.ppf(0.95,1)/2
hs=np.linspace(0.0005,0.9995,2000)
vals=np.array([prof_h2(h) for h in hs])
inside=hs[vals>l0-crit]
print('profile 95%% CI for h2: [%.4f, %.4f]  (lmax=%.6f)'%(inside.min(),inside.max(),l0))
C=np.linalg.inv(AIm); g=np.array([se/(sa+se)**2,-sa/(sa+se)**2]); seh=np.sqrt(g@C@g)
h2=sa/(sa+se); print('Wald 95%% CI: [%.4f, %.4f]'%(h2-1.96*seh,h2+1.96*seh))
