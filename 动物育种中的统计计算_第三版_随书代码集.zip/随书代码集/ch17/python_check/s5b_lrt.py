# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5b_lrt.py    依赖：numpy, scipy
import numpy as np, reml
from scipy import stats
rng = np.random.default_rng(555)

def lam_reml(SSA,SSE,s,N):
    if SSA/(s-1) <= SSE/(N-s): return 0.0
    return ((N-1)*np.log((SSA+SSE)/(N-1)) - (s-1)*np.log(SSA/(s-1))
            - (N-s)*np.log(SSE/(N-s)))
def lam_ml(SSA,SSE,s,N):
    if SSA/s <= SSE/(N-s): return 0.0
    return (N*np.log((SSA+SSE)/N) - s*np.log(SSA/s) - (N-s)*np.log(SSE/(N-s)))

# --- 闭式 Lambda 与数值 REML 的核对 ---
print("闭式 Lambda 与数值 REML 的核对（3 个数据集）：")
for seed in [11,22,33]:
    s,n=20,5; N=s*n
    rg=np.random.default_rng(seed)
    y2 = 50 + rg.standard_normal((s,n))*np.sqrt(9.0)      # H0: 无公畜方差
    y=y2.ravel(); X=np.ones((N,1))
    Zg=np.zeros((N,s)); Zg[np.arange(N),np.repeat(np.arange(s),n)]=1.
    Vl=[Zg@Zg.T,np.eye(N)]
    th,l1=reml.fit(y,Vl,X,[1.0,9.0],'reml')
    l0=reml.lR(np.array([1e-12, (y@(np.eye(N)-X@np.linalg.solve(X.T@X,X.T))@y)/(N-1)]),y,Vl,X)
    gm=y2.mean(); rm=y2.mean(1)
    SSA=n*((rm-gm)**2).sum(); SSE=((y2-rm[:,None])**2).sum()
    print("  seed=%d 数值 2(l1-l0)=%.8f   闭式=%.8f   差=%.2e"
          %(seed,2*(l1-l0),lam_reml(SSA,SSE,s,N),2*(l1-l0)-lam_reml(SSA,SSE,s,N)))

# --- 大规模模拟 ---
B=200000
print("\n" + "="*80)
print("H0: sigma_s^2=0 下 LRT 统计量的零分布模拟 (B=%d，直接抽 chi^2)"%B)
print("="*80)
c1=stats.chi2.ppf(0.95,1); cm=stats.chi2.ppf(0.90,1)
print("chi2_{1,0.95} = %.6f ；混合分布 1/2chi2_0+1/2chi2_1 的 95%% 分位 = %.6f"%(c1,cm))
print("\n   s    n    N   P(Lambda=0) 理论P(F<=1)  用chi2_1(3.8415)的真实水平  用混合(2.7055)的真实水平  Lambda的0.95分位")
for s,n in [(10,5),(20,5),(50,5),(20,10),(100,10)]:
    N=s*n
    SSA=rng.chisquare(s-1,B); SSE=rng.chisquare(N-s,B)
    L=np.where(SSA/(s-1)>SSE/(N-s),
               (N-1)*np.log((SSA+SSE)/(N-1))-(s-1)*np.log(SSA/(s-1))-(N-s)*np.log(SSE/(N-s)),
               0.0)
    p0=(L<=0).mean(); pth=stats.f.cdf(1.0,s-1,N-s)
    a1=(L>c1).mean(); am=(L>cm).mean()
    print("%5d %4d %5d %11.5f %11.5f %20.5f %22.5f %14.5f"
          %(s,n,N,p0,pth,a1,am,np.quantile(L,0.95)))
print("\n（MC 标准误 ≈ %.5f）"%np.sqrt(0.05*0.95/B))

print("\n同样的模拟，但用 ML 似然比：")
print("   s    n    N   P(Lambda=0)  用chi2_1 的真实水平  用混合 的真实水平")
for s,n in [(20,5),(50,5),(100,10)]:
    N=s*n
    SSA=rng.chisquare(s-1,B); SSE=rng.chisquare(N-s,B)
    L=np.where(SSA/s>SSE/(N-s),
               N*np.log((SSA+SSE)/N)-s*np.log(SSA/s)-(N-s)*np.log(SSE/(N-s)), 0.0)
    print("%5d %4d %5d %11.5f %20.5f %18.5f"%(s,n,N,(L<=0).mean(),(L>c1).mean(),(L>cm).mean()))
