# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4c_unbal.py    依赖：numpy
import numpy as np, reml
rg = np.random.default_rng(1712)
s = 25
sizes = np.array([2,3,4,5,6,7,8,2,3,4,5,6,7,8,2,3,4,5,6,7,8,3,5,7,4])
N = sizes.sum(); nh = 4
sire = np.repeat(np.arange(s), sizes)
herd = (np.arange(N)*7) % nh
ss2t, se2t = 1.0, 15.0
a = rg.standard_normal(s)*np.sqrt(ss2t)
hb = np.array([6000., 6120., 5940., 6060.])
y = np.round(hb[herd] + a[sire] + rg.standard_normal(N)*np.sqrt(se2t), 1)
X = np.zeros((N, nh)); X[np.arange(N), herd] = 1.0
Zg = np.zeros((N, s)); Zg[np.arange(N), sire] = 1.0
Vlist = [Zg@Zg.T, np.eye(N)]
print("不平衡半同胞例：N=%d, 公畜数=%d (家系大小 %d–%d), 场数=%d"
      % (N, s, sizes.min(), sizes.max(), nh))

th,_ = reml.fit(y,Vlist,X,[1.0,15.0],'reml'); th = reml.polish(th,y,Vlist,X,'reml')
ss2,se2 = th
print("REML: ss2=%.8f se2=%.8f  h2=4t=%.8f" % (ss2,se2,4*ss2/(ss2+se2)))
print("得分 =", reml.score(th,y,Vlist,X))

for lbl, pt in [("REML 解处", th), ("起始值 (2.0, 12.0)", np.array([2.0,12.0])),
                ("起始值 (0.3, 18.0)", np.array([0.3,18.0]))]:
    O,E,AI = reml.infos(pt,y,Vlist,X)
    print("\n--- %s: theta = (%.4f, %.4f) ---" % (lbl, pt[0], pt[1]))
    for nm,M in [("I^O",O),("I^E",E),("I^A",AI)]:
        ev = np.linalg.eigvalsh(M)
        print("  %s = [[%12.6f, %10.6f],[%10.6f, %10.6f]]  特征值 %.6f, %.6f"
              %(nm,M[0,0],M[0,1],M[1,0],M[1,1],ev[0],ev[1]))
    if lbl.startswith("REML"):
        sp=ss2+se2; g=np.array([4*se2/sp**2,-4*ss2/sp**2])
        print("  由三种信息矩阵得到的 SE:")
        for nm,M in [("I^O",O),("I^E",E),("I^A",AI)]:
            Cv=np.linalg.inv(M); v=g@Cv@g; vn=g[0]**2*Cv[0,0]+g[1]**2*Cv[1,1]
            print("    %s: SE(ss2)=%.6f SE(se2)=%.6f corr=%.6f | SE(h2)=%.6f 忽略协方差=%.6f"
                  %(nm,np.sqrt(Cv[0,0]),np.sqrt(Cv[1,1]),Cv[0,1]/np.sqrt(Cv[0,0]*Cv[1,1]),
                    np.sqrt(v),np.sqrt(vn)))
        print("  三者的相对差: (I^O-I^E)/I^E 逐元 =",
              np.array2string((O-E)/E, precision=4))
