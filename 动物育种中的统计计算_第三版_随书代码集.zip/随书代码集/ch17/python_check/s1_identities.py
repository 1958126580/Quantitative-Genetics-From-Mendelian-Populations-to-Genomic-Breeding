# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_identities.py    依赖：numpy
import numpy as np, common
from common import X, Z, Y, A, N, q, p

sa2, se2 = 2.0, 6.0
V, G, R = common.VGR(sa2, se2)
P, Vi, XVX = common.Pmat(V, X)
C, rhs, Ri, Gi = common.Cmat(G, R, X, Z)

sl = np.linalg.slogdet
ld = lambda M: sl(M)[1]

print("=== 参数：sa2=%.1f se2=%.1f ===" % (sa2, se2))
print("log|V|            = %.10f" % ld(V))
print("log|R|            = %.10f" % ld(R))
print("log|G|            = %.10f" % ld(G))
print("log|C|            = %.10f" % ld(C))
print("log|X'V^-1X|      = %.10f" % ld(XVX))
print("log|G^-1+Z'R^-1Z| = %.10f" % ld(Gi + Z.T @ Ri @ Z))
print("log|X'R^-1X|      = %.10f" % ld(X.T @ Ri @ X))

# 恒等式 (a): |V| = |R||G||G^-1+Z'R^-1Z|
lhs = ld(V); rhsv = ld(R) + ld(G) + ld(Gi + Z.T @ Ri @ Z)
print("\n[a] log|V| = log|R|+log|G|+log|G^-1+Z'R^-1Z|")
print("    左 = %.10f   右 = %.10f   差 = %.3e" % (lhs, rhsv, lhs - rhsv))

# 恒等式 (b): |C| = |G^-1+Z'R^-1Z| * |X'V^-1X|
lhs = ld(C); rhsv = ld(Gi + Z.T @ Ri @ Z) + ld(XVX)
print("[b] log|C| = log|G^-1+Z'R^-1Z| + log|X'V^-1X|")
print("    左 = %.10f   右 = %.10f   差 = %.3e" % (lhs, rhsv, lhs - rhsv))

# 恒等式 (c): |V||X'V^-1X| = |R||G||C|
lhs = ld(V) + ld(XVX); rhsv = ld(R) + ld(G) + ld(C)
print("[c] log|V|+log|X'V^-1X| = log|R|+log|G|+log|C|")
print("    左 = %.10f   右 = %.10f   差 = %.3e" % (lhs, rhsv, lhs - rhsv))

# 恒等式 (d): |C| = |X'R^-1X| * |Z'SZ+G^-1|,  S = R^-1 - R^-1X(X'R^-1X)^-1X'R^-1
XRX = X.T @ Ri @ X
S = Ri - Ri @ X @ np.linalg.solve(XRX, X.T @ Ri)
lhs = ld(C); rhsv = ld(XRX) + ld(Z.T @ S @ Z + Gi)
print("[d] log|C| = log|X'R^-1X| + log|Z'SZ+G^-1|")
print("    左 = %.10f   右 = %.10f   差 = %.3e" % (lhs, rhsv, lhs - rhsv))

# ---- y'Py 的三种算法 ----
sol = np.linalg.solve(C, rhs)
bh, uh = sol[:p], sol[p:]
eh = Y - X @ bh - Z @ uh
yPy = Y @ P @ Y
f1 = Y @ Ri @ eh
f2 = eh @ Ri @ eh + uh @ Gi @ uh
f3 = Y @ Ri @ Y - sol @ rhs
print("\n=== y'Py 的四种算法 ===")
print("y'Py（直接）                 = %.10f" % yPy)
print("y'R^-1 ê                     = %.10f   差 = %.3e" % (f1, f1 - yPy))
print("ê'R^-1ê + û'G^-1û            = %.10f   差 = %.3e" % (f2, f2 - yPy))
print("y'R^-1y - [解]'[右端]        = %.10f   差 = %.3e" % (f3, f3 - yPy))
print("\n解：betahat =", np.round(bh, 6), " uhat =", np.round(uh, 6))
print("ê =", np.round(eh, 6))
print("Py 与 R^-1ê 的最大绝对差 = %.3e" % np.max(np.abs(P @ Y - Ri @ eh)))

# ---- 两种似然 ----
lR_direct = -0.5 * (ld(V) + ld(XVX) + yPy)
lR_mme    = -0.5 * (ld(R) + ld(G) + ld(C) + yPy)
lM_direct = -0.5 * (N * np.log(2 * np.pi) + ld(V) + yPy)
lM_mme    = -0.5 * (N * np.log(2*np.pi) + ld(R) + ld(G) + ld(Gi + Z.T@Ri@Z) + yPy)
print("\n=== 对数似然（剔除常数前） ===")
print("ell_R  直接式(17.13)         = %.10f" % lR_direct)
print("ell_R  MME 式               = %.10f   差 = %.3e" % (lR_mme, lR_mme - lR_direct))
print("ell_P(ML) 直接式(17.5)       = %.10f" % lM_direct)
print("ell_P(ML) MME 式            = %.10f   差 = %.3e" % (lM_mme, lM_mme - lM_direct))

# 换一组参数再验一次
print("\n=== 换参数 sa2=0.5 se2=9.0 再验一次 ===")
sa2b, se2b = 0.5, 9.0
Vb, Gb, Rb = common.VGR(sa2b, se2b)
Pb, Vib, XVXb = common.Pmat(Vb, X)
Cb, rhsb, Rib, Gib = common.Cmat(Gb, Rb, X, Z)
d1 = (ld(Vb) + ld(XVXb)) - (ld(Rb) + ld(Gb) + ld(Cb))
solb = np.linalg.solve(Cb, rhsb)
ehb = Y - X @ solb[:p] - Z @ solb[p:]
d2 = Y @ Rib @ ehb - Y @ Pb @ Y
print("  log|V|+log|X'V^-1X| = %.10f ; log|R|+log|G|+log|C| = %.10f ; 差 = %.3e"
      % (ld(Vb)+ld(XVXb), ld(Rb)+ld(Gb)+ld(Cb), d1))
print("  y'Py = %.10f ; y'R^-1ê = %.10f ; 差 = %.3e" % (Y@Pb@Y, Y@Rib@ehb, d2))
