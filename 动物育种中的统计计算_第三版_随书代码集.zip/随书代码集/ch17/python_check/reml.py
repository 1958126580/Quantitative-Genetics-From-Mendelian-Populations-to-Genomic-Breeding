# -*- coding: utf-8 -*-
"""Generic small-scale REML / ML for V = sum_i theta_i V_i."""
import numpy as np
from scipy.optimize import minimize

sl = np.linalg.slogdet
def ld(M): return sl(M)[1]

def Pof(theta, Vlist, X):
    V = sum(t * Vi for t, Vi in zip(theta, Vlist))
    Vi_ = np.linalg.inv(V)
    M = X.T @ Vi_ @ X
    P = Vi_ - Vi_ @ X @ np.linalg.solve(M, X.T @ Vi_)
    return V, Vi_, M, P

def lR(theta, y, Vlist, X):
    V, Vi_, M, P = Pof(theta, Vlist, X)
    N, r = X.shape[0], np.linalg.matrix_rank(X)
    return -0.5 * ((N - r) * np.log(2*np.pi) + ld(V) + ld(M) + y @ P @ y)

def lML(theta, y, Vlist, X):
    V, Vi_, M, P = Pof(theta, Vlist, X)
    N = X.shape[0]
    return -0.5 * (N * np.log(2*np.pi) + ld(V) + y @ P @ y)

def score(theta, y, Vlist, X):
    V, Vi_, M, P = Pof(theta, Vlist, X)
    Py = P @ y
    return np.array([-0.5*(np.trace(P @ Vi) - Py @ Vi @ Py) for Vi in Vlist])

def infos(theta, y, Vlist, X):
    """observed, expected, average information matrices."""
    V, Vi_, M, P = Pof(theta, Vlist, X)
    Py = P @ y
    k = len(Vlist)
    O = np.zeros((k, k)); E = np.zeros((k, k)); AI = np.zeros((k, k))
    PV = [P @ Vi for Vi in Vlist]
    for i in range(k):
        for j in range(k):
            O[i, j] = Py @ Vlist[i] @ P @ Vlist[j] @ Py - 0.5*np.trace(PV[i] @ PV[j])
            E[i, j] = 0.5*np.trace(PV[i] @ PV[j])
            AI[i, j] = 0.5*(Py @ Vlist[i] @ P @ Vlist[j] @ Py)
    return O, E, AI

def fit(y, Vlist, X, start, kind='reml', bounds=None, fixed=None):
    """fixed: dict {index: value} to profile out."""
    k = len(Vlist)
    fixed = fixed or {}
    free = [i for i in range(k) if i not in fixed]
    f = lR if kind == 'reml' else lML
    def full(z):
        th = np.empty(k)
        for i, v in fixed.items(): th[i] = v
        for a, i in enumerate(free): th[i] = z[a]
        return th
    def neg(z):
        th = full(z)
        if np.min(th) <= 1e-12: return 1e10
        V = sum(t*Vi for t, Vi in zip(th, Vlist))
        try:
            np.linalg.cholesky(V)
        except np.linalg.LinAlgError:
            return 1e10
        return -f(th, y, Vlist, X)
    bd = [(1e-10, None)]*len(free) if bounds is None else [bounds[i] for i in free]
    best = None
    for s in [np.array([start[i] for i in free]),
              np.array([start[i]*3 for i in free]),
              np.array([start[i]*0.2 for i in free])]:
        res = minimize(neg, s, method='L-BFGS-B', bounds=bd,
                       options=dict(ftol=1e-16, gtol=1e-12, maxiter=20000))
        if best is None or res.fun < best.fun: best = res
    return full(best.x), -best.fun

def scoreML(theta, y, Vlist, X):
    V, Vi_, M, P = Pof(theta, Vlist, X)
    Py = P @ y
    return np.array([-0.5*(np.trace(Vi_ @ Vi) - Py @ Vi @ Py) for Vi in Vlist])

def polish(theta, y, Vlist, X, kind='reml', it=60):
    """Newton polish on the score equations (observed information)."""
    th = np.array(theta, float)
    sc = score if kind == 'reml' else scoreML
    for _ in range(it):
        s = sc(th, y, Vlist, X)
        h = 1e-6 * np.maximum(np.abs(th), 1e-3)
        H = np.zeros((len(th), len(th)))
        for j in range(len(th)):
            tp = th.copy(); tp[j] += h[j]
            tm = th.copy(); tm[j] -= h[j]
            H[:, j] = (sc(tp, y, Vlist, X) - sc(tm, y, Vlist, X)) / (2*h[j])
        try:
            step = np.linalg.solve(H, s)
        except np.linalg.LinAlgError:
            break
        lam = 1.0
        while lam > 1e-8 and np.min(th - lam*step) <= 1e-12:
            lam *= 0.5
        new = th - lam*step
        if np.max(np.abs(new - th)) < 1e-14 * np.max(np.abs(th)): th = new; break
        th = new
    return th
