# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5_profile.py    依赖：numpy, scipy
import numpy as np
from scipy.optimize import brentq
from scipy import stats

def anova_from(y2):
    s,n=y2.shape; gm=y2.mean(); rm=y2.mean(1)
    SSA=n*((rm-gm)**2).sum(); SSE=((y2-rm[:,None])**2).sum()
    return s,n,s*n,SSA,SSE

def halfsib(s,n,ss2,se2,seed,mu=6000.):
    rg=np.random.default_rng(seed)
    a=rg.standard_normal(s)*np.sqrt(ss2)
    return np.round(mu+a[:,None]+rg.standard_normal((s,n))*np.sqrt(se2),1)

def lprof(t, s,n,N,SSA,SSE):
    """profile REML loglik (去掉与 t 无关的常数) ；t = 组内相关"""
    A=1+(n-1)*t; B=1-t
    q=SSA/A+SSE/B
    return -0.5*((N-1)*np.log(q/(N-1)) + (s-1)*np.log(A) + (N-s)*np.log(B) + (N-1))

for s0,n0,seed,tag in [(50,10,4417,'例 B: s=50 x n=10 (N=500)'),
                       (20,5,911,'例 C: s=20 x n=5  (N=100)')]:
    y2=halfsib(s0,n0,1.0,15.0,seed)
    s,n,N,SSA,SSE=anova_from(y2)
    MSA,MSE=SSA/(s-1),SSE/(N-s)
    that=(MSA-MSE)/(MSA+(n-1)*MSE)
    h2=4*that
    lmax=lprof(that,s,n,N,SSA,SSE)
    # Wald
    l1=MSA;l2=MSE
    Vl1=2*l1**2/(s-1);Vl2=2*l2**2/(N-s)
    ss2=(MSA-MSE)/n; se2=MSE; sp=ss2+se2
    g=np.array([4*se2/sp**2,-4*ss2/sp**2])
    Cv=np.array([[(Vl1+Vl2)/n**2, -Vl2/n],[-Vl2/n, Vl2]])
    seh=np.sqrt(g@Cv@g)
    print("="*80); print(tag)
    print("  MSA=%.6f MSE=%.6f  t_hat=%.8f  h2_hat=%.8f  SE(h2)=%.8f"%(MSA,MSE,that,h2,seh))
    print("  Wald 95%% CI: [%.6f, %.6f]  %s"%(h2-1.96*seh,h2+1.96*seh,
          "<- 下限为负！" if h2-1.96*seh<0 else ""))
    # profile CI
    crit=stats.chi2.ppf(0.95,1)
    f=lambda t: 2*(lmax-lprof(t,s,n,N,SSA,SSE))-crit
    lo = 0.0 if f(1e-12)<0 else brentq(f,1e-12,that,xtol=1e-14)
    hi = brentq(f,that,0.999999,xtol=1e-14)
    print("  profile 似然 95%% CI (t): [%.8f, %.8f]"%(lo,hi))
    print("  => h2: [%.6f, %.6f]  (临界 chi2_1,0.95=%.4f)"%(4*lo,4*hi,crit))
    print("  在 t=0 处 2*Delta ell = %.6f  (>%.4f? %s)"
          %(2*(lmax-lprof(1e-12,s,n,N,SSA,SSE)),crit,
            2*(lmax-lprof(1e-12,s,n,N,SSA,SSE))>crit))
    # 单侧混合分布临界值
    crit2=stats.chi2.ppf(0.90,1)
    f2=lambda t: 2*(lmax-lprof(t,s,n,N,SSA,SSE))-crit2
    lo2 = 0.0 if f2(1e-12)<0 else brentq(f2,1e-12,that,xtol=1e-14)
    hi2 = brentq(f2,that,0.999999,xtol=1e-14)
    print("  若用 1/2chi2_0+1/2chi2_1 的 95%% 临界值 %.4f: h2 CI = [%.6f, %.6f]"
          %(crit2,4*lo2,4*hi2))
    print("  似然曲线（t, h2=4t, 2*Delta ell）：")
    for tt in [0.0,0.01,0.02,that,0.08,0.10,0.15,0.20,0.25]:
        tt=max(tt,1e-12)
        print("     t=%.6f  h2=%.4f  2*Delta=%9.4f"%(tt,4*tt,2*(lmax-lprof(tt,s,n,N,SSA,SSE))))
