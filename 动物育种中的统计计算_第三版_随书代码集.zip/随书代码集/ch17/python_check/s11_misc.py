# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s11_misc.py    依赖：numpy
import numpy as np
rng=np.random.default_rng(3)
# (a) |V| |X'V^-1 X| = |R| |G| |C|
N,r,q=15,3,6
X=rng.standard_normal((N,r)); Z=rng.standard_normal((N,q))
Rm=np.diag(rng.uniform(1,3,N)); Gm=rng.standard_normal((q,q)); Gm=Gm@Gm.T+q*np.eye(q)
V=Z@Gm@Z.T+Rm; Vi=np.linalg.inv(V); Ri=np.linalg.inv(Rm); Gi=np.linalg.inv(Gm)
C=np.block([[X.T@Ri@X, X.T@Ri@Z],[Z.T@Ri@X, Z.T@Ri@Z+Gi]])
lhs=np.linalg.slogdet(V)[1]+np.linalg.slogdet(X.T@Vi@X)[1]
rhs=np.linalg.slogdet(Rm)[1]+np.linalg.slogdet(Gm)[1]+np.linalg.slogdet(C)[1]
print("log|V|+log|X'V^-1X| = %.10f ; log|R|+log|G|+log|C| = %.10f ; 差 %.2e"%(lhs,rhs,lhs-rhs))

# (b) 遗传相关的 delta 法公式核对（对 (s11,s12,s22) 的联合正态做 MC）
s11,s12,s22=30.0,12.0,25.0
rg=s12/np.sqrt(s11*s22)
Sig=np.array([[60.,15.,10.],[15.,40.,18.],[10.,18.,50.]])   # Var(hat sigma) 任取一个正定阵
def delta(s11,s12,s22,S):
    g=np.array([-0.5*s12/(s11**1.5*np.sqrt(s22)),
                1.0/np.sqrt(s11*s22),
                -0.5*s12/(np.sqrt(s11)*s22**1.5)])
    return g@S@g
v1=delta(s11,s12,s22,Sig)
# 教科书常见的"相对形式"
v2=rg**2*(Sig[1,1]/s12**2 + Sig[0,0]/(4*s11**2) + Sig[2,2]/(4*s22**2)
          - Sig[0,1]/(s12*s11) - Sig[1,2]/(s12*s22) + Sig[0,2]/(2*s11*s22))
print("delta 法 Var(rg): 直接梯度 %.8f ; 相对形式 %.8f ; 差 %.2e"%(v1,v2,v1-v2))
L=np.linalg.cholesky(Sig); R=2000000
d=L@rng.standard_normal((3,R))*0.1     # 缩小扰动以检验一阶近似
sm=np.array([s11,s12,s22])[:,None]+d
rr=sm[1]/np.sqrt(sm[0]*sm[2])
print("MC(扰动缩小10倍) Var(rg)=%.8f ; delta 预测 %.8f"%(rr.var(),v1*0.01))
print("rg=%.4f, SE(rg)=%.4f"%(rg,np.sqrt(v1)))
