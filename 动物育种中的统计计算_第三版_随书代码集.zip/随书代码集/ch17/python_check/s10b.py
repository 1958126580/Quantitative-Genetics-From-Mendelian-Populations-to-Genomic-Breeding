# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s10b.py    依赖：numpy, scipy
import numpy as np
from scipy import stats
sa2,se2=4.0,16.0; rho=sa2/(sa2+se2)
rng=np.random.default_rng(202405)
print("真值 sa2=%.1f se2=%.1f 组内相关 rho=%.2f ; 每格 200000 次重复"%(sa2,se2,rho))
print("%4s %4s %5s | %10s %10s %7s | %9s %9s | %9s %9s"%
      ("s","n","N","渐近SE(rho)","MC SD(rho)","比值","MC均值rho","P(rho=0)","覆盖率.95","MC SD(sa2)"))
for s,n in [(10,5),(20,5),(50,5),(100,5),(200,5),(500,5)]:
    l1=se2+n*sa2; l2=se2
    V1=2*l1**2/(s-1); V2=2*l2**2/(s*(n-1))
    Vaa=(V1+V2)/n**2; Vee=V2; Cae=-V2/n
    sP=sa2+se2; g=np.array([se2/sP**2,-sa2/sP**2])
    C=np.array([[Vaa,Cae],[Cae,Vee]]); seR=np.sqrt(g@C@g)
    R=200000; chunk=max(1,int(2e7/(s*n))); out=[]
    got=0
    while got<R:
        b=min(chunk,R-got); got+=b
        a=rng.normal(0,np.sqrt(sa2),(b,s)); e=rng.normal(0,np.sqrt(se2),(b,s,n))
        y=a[:,:,None]+e; rm=y.mean(axis=2); gm=y.mean(axis=(1,2))
        SSA=n*((rm-gm[:,None])**2).sum(axis=1); SSE=((y-rm[:,:,None])**2).sum(axis=(1,2))
        MSA=SSA/(s-1); MSE=SSE/(s*(n-1))
        ah=np.maximum((MSA-MSE)/n,0.0); eh=MSE
        out.append(np.vstack([ah,eh]))
    ah,eh=np.hstack(out); rh=ah/(ah+eh)
    l1h=eh+n*ah; V1h=2*l1h**2/(s-1); V2h=2*eh**2/(s*(n-1))
    Vaah=(V1h+V2h)/n**2; Caeh=-V2h/n; sPh=ah+eh
    g0=eh/sPh**2; g1=-ah/sPh**2
    seh=np.sqrt(np.maximum(g0**2*Vaah+g1**2*V2h+2*g0*g1*Caeh,0))
    cov=((rh-1.96*seh<=rho)&(rho<=rh+1.96*seh)).mean()
    print("%4d %4d %5d | %10.4f %10.4f %7.3f | %9.4f %9.4f | %9.4f %9.4f"%
          (s,n,s*n,seR,rh.std(ddof=1),seR/rh.std(ddof=1),rh.mean(),(ah<=0).mean(),cov,ah.std(ddof=1)))
sa,se_,cv=12.0,38.0,-4.2; SEa,SEe=3.5,2.1
sP=sa+se_; h2=sa/sP; g=np.array([se_/sP**2,-sa/sP**2])
C=np.array([[SEa**2,cv],[cv,SEe**2]]); v=g@C@g; v0=g[0]**2*C[0,0]+g[1]**2*C[1,1]
print("\n[思考题] h2=%.4f SE(h2)=%.5f ; 忽略协方差 SE=%.5f (低估 %.1f%%) ; corr=%.4f"%
      (h2,np.sqrt(v),np.sqrt(v0),100*(1-np.sqrt(v0/v)),cv/(SEa*SEe)))
print("[思考题] Lambda=3.2: p(chi2_1)=%.4f  p(mix)=%.4f"%(stats.chi2.sf(3.2,1),0.5*stats.chi2.sf(3.2,1)))
print("[参考] 若 Cov=+4.2 则 SE(h2)=%.5f"%np.sqrt(g@np.array([[SEa**2,4.2],[4.2,SEe**2]])@g))
