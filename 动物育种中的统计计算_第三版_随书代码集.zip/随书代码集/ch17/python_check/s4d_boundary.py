# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 17 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4d_boundary.py    依赖：numpy
import numpy as np, common, reml
from common import X, Z, Y, A, N
V1 = Z@A@Z.T; V0 = np.eye(N); Vlist=[V1,V0]
r = np.linalg.matrix_rank(X)

th,_ = reml.fit(Y,Vlist,X,[2.0,6.0],'reml')
print("例 17.A（N=12）REML 数值解： sa2=%.10f  se2=%.10f" % (th[0],th[1]))
# 边界解：sa2=0 时 se2 的闭式解 = y'P0y/(N-r)
P0 = np.eye(N) - X@np.linalg.solve(X.T@X, X.T)
se2b = Y@P0@Y/(N-r)
print("边界上 (sa2=0) 的闭式 REML 解： se2 = y'P0y/(N-r) = %.10f"%se2b)
theta0 = np.array([0.0, se2b])
print("在该点的 REML 得分 =", reml.score(theta0,Y,Vlist,X))
print("  -> 对 se2 的得分为 0，对 sa2 的得分为负 => 内部无解，最大值在边界上（KKT）")
print("对数似然 ellR(边界) = %.8f" % reml.lR(theta0,Y,Vlist,X))
for t in [0.01,0.05,0.2,0.5]:
    print("   ellR(sa2=%.2f, se2 剖面最大) : %.8f" %
          (t, reml.fit(Y,Vlist,X,[t,se2b],'reml',fixed={0:t})[1]))

O,E,AI = reml.infos(theta0,Y,Vlist,X)
print("\n在边界点 (0, %.6f) 的三种信息矩阵：" % se2b)
for nm,M in [("I^O",O),("I^E",E),("I^A",AI)]:
    ev=np.linalg.eigvalsh(M)
    print("  %s = [[%11.6f, %9.6f],[%9.6f, %9.6f]]  特征值 %.6f, %.6f  %s"
          %(nm,M[0,0],M[0,1],M[1,0],M[1,1],ev[0],ev[1],
            "正定" if ev[0]>0 else "不定 <-"))
print("\n由它们形式地算出的方差（形式上！）：")
for nm,M in [("I^O",O),("I^E",E),("I^A",AI)]:
    Cv=np.linalg.inv(M)
    f=lambda v: ("%.6f"%np.sqrt(v)) if v>0 else "无定义(负)"
    print("  %s: Var(sa2)=%11.6f -> SE=%s ;  Var(se2)=%.6f -> SE=%.6f"
          %(nm,Cv[0,0],f(Cv[0,0]),Cv[1,1],np.sqrt(Cv[1,1])))
print("\n三个 SE(sa2) 相差 %0.1f 倍 —— 边界上的标准误没有意义。"
      % (np.sqrt(np.linalg.inv(AI)[0,0])/np.sqrt(np.linalg.inv(E)[0,0])))
