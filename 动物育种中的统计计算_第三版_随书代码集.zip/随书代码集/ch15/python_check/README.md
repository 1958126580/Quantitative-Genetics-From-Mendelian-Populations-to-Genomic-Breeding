# 第 15 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch15/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `e3_repro.py` | 复现 §15.2.2 已有实验的系谱构造猜想：基础群 100 公 + 1000 母，其余 3900 头的父、母分别从基础群公、母中随机抽取（两代系谱） | numpy, scipy | 0.8 | `outputs/e3_repro.out` |
| `e3b.py` | 数值复核 | numpy, scipy | 0.7 | `outputs/e3b.out` |
| `e3c_repro_pcg.py` | 复现 §15.3.1 已有表：两代 5000 头系谱，仅动物效应 C = Z'Z + lam A^-1，随机右端项，相对残差 1e-8 | numpy, scipy | 5.7 | `outputs/e3c_repro_pcg.out` |
| `pev.py` | PEV: exact (LDL' + Takahashi), Monte Carlo, diagonal approximation, effective records. | numpy, scipy | 7.4 | `outputs/pev.out` |
| `prec.py` | 预条件子：Jacobi、块对角、SSOR、IC(0)。所有 apply 函数返回 M^{-1} r，三角解用 SuperLU（自然序、对角主元）在 C 层完成。 | numpy, scipy | 0.4 | `outputs/prec.out` |
| `sweep.py` | (a) kappa and PCG iterations vs h2; (b) multi-trait block preconditioner; (c) two-level. | numpy, scipy | 61.1 | `outputs/sweep.out` |
| `t_lib.py` | 1) A^{-1} check against dense A (tabular method) with inbreeding | numpy, scipy | 0.7 | `outputs/t_lib.out` |
| `t_lib2.py` | 数值复核 | numpy, scipy | 0.6 | `outputs/t_lib2.out` |
| `t_lib3.py` | random-valued SPD matrix with the same pattern | numpy, scipy | 0.9 | `outputs/t_lib3.out` |
| `t_spilu.py` | 数值复核 | numpy, scipy | 1.1 | `outputs/t_spilu.out` |
| `takahashi.py` | 稀疏选择求逆（Takahashi–Erisman–Tinney 递推）的 numpy 实现，用于 PEV 的精确值。 | numpy, scipy | 0.4 | `outputs/takahashi.out` |

公共函数模块（被上列脚本导入，不单独运行）：`common.py`、`fill.py`、`lib.py`、`precond.py`。
