# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 takahashi.py    依赖：numpy, scipy
"""稀疏选择求逆（Takahashi–Erisman–Tinney 递推）的 numpy 实现，用于 PEV 的精确值。
输入: 已置换的 SPD 稀疏矩阵 Cp。步骤: (1) SuperLU(NATURAL, 对角主元) 得 Cp = L U, D=diag(U), L 单位下三角;
(2) 由消去树合并列结构得到完整的符号结构 struct[j]（SuperLU 返回的 L 不存数值上恰为 0 的位置，而递推需要完整结构）;
(3) 按 j = N-1,...,0 递推: Z[S_j,j] = -Z[S_j,S_j] l_j,  Z_jj = 1/d_j - l_j' Z[S_j,j]。"""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl, time
from lib import _etree_upper


def ldl_factor(Cp):
    N = Cp.shape[0]
    lu = spl.splu(sp.csc_matrix(Cp), permc_spec='NATURAL', diag_pivot_thresh=0.0, options=dict(SymmetricMode=True))
    assert np.array_equal(lu.perm_r, np.arange(N)) and np.array_equal(lu.perm_c, np.arange(N))
    L = lu.L.tocsc()
    D = lu.U.diagonal()
    return lu, L, D


def symbolic_struct(Cp):
    """返回 struct[j]（j 列 L 的严格下三角行号，升序）。"""
    Cp = sp.csc_matrix(Cp)
    N = Cp.shape[0]
    U = sp.triu(Cp, format='csc')
    parent = _etree_upper(U.indptr.tolist(), U.indices.tolist(), N)
    Low = sp.tril(Cp, k=-1, format='csc')
    children = [[] for _ in range(N)]
    for j, pj in enumerate(parent):
        if pj != -1:
            children[pj].append(j)
    struct = [None] * N
    for j in range(N):
        parts = [Low.indices[Low.indptr[j]:Low.indptr[j + 1]]]
        for c in children[j]:
            parts.append(struct[c][1:])          # struct[c][0] == j
        struct[j] = np.unique(np.concatenate(parts)) if len(parts) > 1 else np.sort(parts[0])
    return struct, parent


def selected_inverse(Cp, return_all=False):
    """返回 (diagZ, info)。diagZ 为 Cp^{-1} 的对角元（Cp 的编号顺序）。"""
    t0 = time.perf_counter()
    lu, L, D = ldl_factor(Cp)
    t_fac = time.perf_counter() - t0
    t0 = time.perf_counter()
    struct, parent = symbolic_struct(Cp)
    t_sym = time.perf_counter() - t0
    N = Cp.shape[0]
    Lvals = [None] * N
    for j in range(N):
        S = struct[j]
        v = np.zeros(len(S))
        rows = L.indices[L.indptr[j]:L.indptr[j + 1]]; dat = L.data[L.indptr[j]:L.indptr[j + 1]]
        m = rows > j
        if m.any():
            pos = np.searchsorted(S, rows[m])
            assert np.array_equal(S[pos], rows[m])
            v[pos] = dat[m]
        Lvals[j] = v
    t0 = time.perf_counter()
    Zcol = [None] * N
    Zd = np.zeros(N)
    for j in range(N - 1, -1, -1):
        S = struct[j]; c = len(S)
        if c == 0:
            Zd[j] = 1.0 / D[j]; Zcol[j] = np.empty(0); continue
        W = np.empty((c, c))
        for a in range(c):
            k = S[a]
            W[a, a] = Zd[k]
            if a + 1 < c:
                idx = np.searchsorted(struct[k], S[a + 1:])
                vals = Zcol[k][idx]
                W[a, a + 1:] = vals; W[a + 1:, a] = vals
        l = Lvals[j]
        zc = -(W @ l)
        Zcol[j] = zc
        Zd[j] = 1.0 / D[j] - l @ zc
    t_rec = time.perf_counter() - t0
    nnzL = int(sum(len(s) for s in struct) + N)
    flops = float(sum((len(s) + 1.0) ** 2 for s in struct))
    info = dict(t_factor=t_fac, t_struct=t_sym, t_recursion=t_rec, nnzL=nnzL, flops=flops)
    if return_all:
        info.update(struct=struct, Zcol=Zcol, Lvals=Lvals, D=D, lu=lu)
    return Zd, info
