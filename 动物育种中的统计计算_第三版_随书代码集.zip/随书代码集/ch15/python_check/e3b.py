# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 e3b.py    依赖：numpy, scipy
import numpy as np, scipy.sparse as sp
from lib import *
sire, dam = gen_ped_two_gen(100, 1000, 3900, 1)
n = len(sire)
Ai = build_ainv(sire, dam)
rec = np.arange(1100, n)
Z = sp.csr_matrix((np.ones(len(rec)), (np.arange(len(rec)), rec)), shape=(len(rec), n))
C = (Z.T @ Z + 3.0 * Ai).tocsc()
tril = (C.nnz + n) // 2
off = np.arange(1100, n); sires = np.arange(0, 100); dams = np.arange(100, 1100)
def cnt(order, name):
    nz = symbolic_chol(C, np.concatenate(order))[0]
    print(f'{name:50s} nnz(L)={nz:9d}  x{nz/tril:7.2f}')
cnt([off[::-1], sires, dams], '后代倒序, 然后 公畜(升序) 在前, 母畜在后')
cnt([off[::-1], dams, sires], '后代倒序, 然后 母畜在前, 公畜在后')
cnt([off, sires, dams], '后代升序, 公畜在前')
cnt([off[::-1], sires[::-1], dams[::-1]], '全部倒序后代, 公畜降序, 母畜降序')
cnt([np.arange(n)[::-1]], '个体号全倒序（母畜先于公畜）')
cnt([off[::-1], np.arange(0,1100)], '后代倒序, 基础群按编号升序（公畜先于母畜）')
cnt([off[::-1], np.arange(0,1100)[::-1]], '后代倒序, 基础群按编号降序（母畜先于公畜）')
