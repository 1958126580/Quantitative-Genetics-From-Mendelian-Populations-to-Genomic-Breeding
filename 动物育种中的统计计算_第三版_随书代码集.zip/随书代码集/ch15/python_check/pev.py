# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 pev.py    依赖：numpy, scipy
"""PEV: exact (LDL' + Takahashi), Monte Carlo, diagonal approximation, effective records."""
import numpy as np, scipy.sparse as sp, scipy.linalg as sla, time
import common

# ---------- Takahashi selected inversion on a dense-but-sparse-pattern LDL' ----------
def ldl_chol(Cd):
    L = np.linalg.cholesky(Cd)
    dg = np.diag(L) ** 2
    Lunit = L / np.diag(L)[None, :]
    return Lunit, dg

def takahashi(Lunit, dg, pattern):
    """Z on the pattern of L only.  pattern: boolean lower-triangular mask (incl. diag)."""
    n = len(dg)
    Z = np.zeros((n, n))
    cols = [np.where(pattern[:, j])[0] for j in range(n)]     # rows k>j with l_kj != 0
    nops = 0
    for i in range(n - 1, -1, -1):
        ki = cols[i][cols[i] > i]                              # k > i with l_ki != 0
        js = sorted([x for x in range(i + 1, n) if pattern[x, i]], reverse=True) + [i]
        for j in js:
            s = (1.0 / dg[i]) if i == j else 0.0
            for k in ki:
                s -= Lunit[k, i] * (Z[k, j] if k >= j else Z[j, k])
                nops += 1
            Z[j, i] = Z[i, j] = s
    return Z, nops

def exact_pev(C):
    return np.linalg.inv(C.toarray())

# ---------- approximations ----------
def mc_pev(C, X, Z, Ainv, lam, rec_animals, S, seed=0, solver=None):
    """Monte-Carlo PEV with the same MME; returns per-animal PEV estimate."""
    rng = np.random.default_rng(seed)
    n = Ainv.shape[0]; p = X.shape[1]; nrec = X.shape[0]
    # sample u ~ N(0, A) via A = (I-P)^-1 D (I-P)^-T  -> use chol of A^-1 instead: solve L' u = z
    Ad = np.linalg.inv(Ainv.toarray())
    La = np.linalg.cholesky((Ad + Ad.T) / 2)
    lu = sla.lu_factor(C.toarray())
    acc = np.zeros(n)
    for s in range(S):
        u = La @ rng.normal(size=n)                       # var A  (in sigma_a^2 units)
        e = np.sqrt(lam) * rng.normal(size=nrec)          # var lam = sigma_e^2/sigma_a^2
        y = Z @ u + e                                      # fixed effects = 0 wlog
        rhs = np.concatenate([X.T @ y, Z.T @ y])
        sol = sla.lu_solve(lu, rhs)
        uh = sol[p:]
        acc += (uh - u) ** 2
    return acc / S          # in sigma_a^2 units; exact PEV/sigma_a^2 = lam * diag(Cinv)

def eff_records(sire, dam, nown, lam, npass=6):
    """Own two-pass 'effective records' approximation. Returns R2 per animal."""
    n = len(sire)
    R2 = np.zeros(n)
    for it in range(npass):
        # ancestor (downward) part
        Vm = np.ones(n)
        for i in range(n):
            s, d = sire[i], dam[i]
            if s and d: Vm[i] = 0.5 + 0.25*(1-R2[s-1]) + 0.25*(1-R2[d-1])
            elif s: Vm[i] = 0.75 + 0.25*(1-R2[s-1])
            elif d: Vm[i] = 0.75 + 0.25*(1-R2[d-1])
            else: Vm[i] = 1.0
        prec = 1.0/Vm + nown/lam                    # ancestors + own records
        # progeny (upward) part
        add = np.zeros(n)
        for k in range(n-1, -1, -1):
            s, d = sire[k], dam[k]
            nk = lam*(prec[k] - 1.0/Vm[k])          # progeny k's own-side information
            nk = max(nk, 1e-12)
            for (par, other) in ((s, d), (d, s)):
                if par:
                    Ro = R2[other-1] if other else 0.0
                    Vres = (0.75 - 0.25*Ro) + lam/nk
                    add[par-1] += 0.25/Vres
        prec_tot = prec + add
        R2 = 1.0 - 1.0/prec_tot
    return R2

if __name__ == '__main__':
    s, d = common.sim_pedigree(n_gen=8, n_per_gen=120, n_sires=8, n_dams=60, seed=0)
    C, b, p, info = common.build_mme(s, d, h2=0.25, rec_frac=0.6, seed=1)
    n = info['n']; lam = info['lam']; N = C.shape[0]
    Cd = C.toarray(); Cinv = np.linalg.inv(Cd)
    pev_exact = lam * np.diag(Cinv)[p:]                  # in sigma_a^2 units
    R2_exact = 1 - pev_exact
    print(f'N={N} n={n} nnz(C)={C.nnz} lam={lam} records={info["n_rec"]}')
    print(f'exact R2: mean={R2_exact.mean():.3f} min={R2_exact.min():.3f} max={R2_exact.max():.3f}')

    # --- Takahashi check (on an MMD-ordered matrix, as a real code would do) ---
    import fill
    perm = fill.mmd_order(C)
    P = sp.coo_matrix((np.ones(N), (np.arange(N), perm)), shape=(N, N)).tocsr()
    Cp = (P @ C @ P.T).toarray(); Cpinv = np.linalg.inv(Cp)
    Lunit, dg = ldl_chol(Cp)
    pat = (Lunit != 0)          # exact structural pattern; see note on truncation
    np.fill_diagonal(pat, True)
    t0 = time.time(); Zt, nops = takahashi(Lunit, dg, pat); tt = time.time()-t0
    dif = np.abs(np.diag(Zt) - np.diag(Cpinv)).max()
    err_pat = np.abs((Zt - Cpinv)[pat]).max()
    print(f'Takahashi: max |diag diff| = {dif:.3e}; max diff on L-pattern = {err_pat:.3e}; '
          f'entries computed = {int(pat.sum())} = {100*pat.sum()/(N*(N+1)/2):.1f}% of tril(C^-1); '
          f'inner ops = {nops}; N^3/3 = {N**3/3:.3e}; ratio = {nops/(N**3/3):.2e}')

    # --- diagonal approximation ---
    pev_diag = lam / Cd.diagonal()[p:]
    R2_diag = 1 - pev_diag
    err = R2_diag - R2_exact
    print(f'对角近似: 偏差 median={np.median(err):+.3f} mean={err.mean():+.3f} '
          f'|err| median={np.median(np.abs(err)):.3f} p90={np.percentile(np.abs(err),90):.3f} max={np.abs(err).max():.3f}')

    # --- effective records ---
    nown = np.zeros(n); nown[info['rec_animals']] = 1.0
    R2_er = eff_records(s, d, nown, lam)
    # with contemporary-group absorption: a record in a group of size m is worth 1-1/m
    grp = np.bincount(info['hy'], minlength=info['n_hy'])[info['hy']]
    nown_abs = np.zeros(n); nown_abs[info['rec_animals']] = 1.0 - 1.0/grp
    R2_er2 = eff_records(s, d, nown_abs, lam)
    e3 = R2_er2 - R2_exact
    print(f'有效记录数+同期群吸收: 偏差 median={np.median(e3):+.3f} |err| median={np.median(np.abs(e3)):.3f} '
          f'p90={np.percentile(np.abs(e3),90):.3f} max={np.abs(e3).max():.3f} corr={np.corrcoef(R2_er2,R2_exact)[0,1]:.4f}')
    print(f'   群体平均可靠性: 精确={R2_exact.mean():.4f} 对角近似={np.mean(1-lam/Cd.diagonal()[p:]):.4f} '
          f'有效记录数={R2_er2.mean():.4f}')
    # truncation experiment for Takahashi
    pat2 = np.abs(Lunit) > 1e-12
    np.fill_diagonal(pat2, True)
    Z2, _ = takahashi(Lunit, dg, pat2)
    print(f'   [截断实验] 丢弃 |l_ij|<=1e-12 后: 模式元素 {int(pat.sum())} -> {int(pat2.sum())}, '
          f'PEV 最大误差 {np.abs(np.diag(Zt)-np.diag(Cpinv)).max():.2e} -> {np.abs(np.diag(Z2)-np.diag(Cpinv)).max():.2e}')
    err2 = R2_er - R2_exact
    print(f'有效记录数: 偏差 median={np.median(err2):+.3f} mean={err2.mean():+.3f} '
          f'|err| median={np.median(np.abs(err2)):.3f} p90={np.percentile(np.abs(err2),90):.3f} max={np.abs(err2).max():.3f}')
    print(f'   corr(近似,精确): diag={np.corrcoef(R2_diag,R2_exact)[0,1]:.4f}  effrec={np.corrcoef(R2_er,R2_exact)[0,1]:.4f}')

    # --- Monte Carlo ---
    print('Monte Carlo PEV (relative RMSE over animals, vs exact):')
    for S in [10, 30, 100, 300, 1000]:
        est = mc_pev(C, info['X'], info['Z'], info['Ainv'], lam, info['rec_animals'], S, seed=100+S)
        rel = (est - pev_exact) / pev_exact
        print(f'  S={S:5d}: RMSE(rel)={np.sqrt((rel**2).mean()):.4f}  theory sqrt(2/S)={np.sqrt(2/S):.4f} '
              f' mean bias={rel.mean():+.4f}  group-mean rel.err={abs(est.mean()/pev_exact.mean()-1):.4f}')
