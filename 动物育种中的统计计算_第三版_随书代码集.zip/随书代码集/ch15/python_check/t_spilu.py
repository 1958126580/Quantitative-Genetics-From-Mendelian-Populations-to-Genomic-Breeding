# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 t_spilu.py    依赖：numpy, scipy
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl, time
from lib import *
sire, dam, sex, gen = gen_ped(10, 200, 5, 100, seed=11)
C, b, info = build_mme(sire, dam, sex, gen)
N = C.shape[0]
print('N', N, 'nnz', C.nnz)
for spec in ['COLAMD', 'MMD_AT_PLUS_A', 'MMD_ATA']:
    lu, t = lu_symmetric(C, spec)
    t0 = time.perf_counter()
    ilu = spl.spilu(sp.csc_matrix(C), drop_tol=0.5, fill_factor=1.5, permc_spec=spec)
    t1 = time.perf_counter() - t0
    print(spec, 'perm equal splu vs spilu:', np.array_equal(lu.perm_c, ilu.perm_c), ' t_splu', round(t, 4), ' t_spilu', round(t1, 4))
    perm = np.argsort(lu.perm_c)
    print('   symbolic nnz(L)', symbolic_chol(C, perm)[0], ' lu.L.nnz', lu.L.nnz)
# also what happens without SymmetricMode / diag_pivot_thresh (default partial pivoting)
t0 = time.perf_counter(); lu0 = spl.splu(sp.csc_matrix(C), permc_spec='COLAMD'); t0 = time.perf_counter() - t0
print('default splu COLAMD: L nnz', lu0.L.nnz, 'U nnz', lu0.U.nnz, 'perm_r==perm_c', np.array_equal(lu0.perm_r, lu0.perm_c), 'time', round(t0, 4))
