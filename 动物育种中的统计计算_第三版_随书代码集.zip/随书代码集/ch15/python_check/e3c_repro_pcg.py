# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 e3c_repro_pcg.py    依赖：numpy, scipy
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl, time
from lib import *
# 复现 §15.3.1 已有表：两代 5000 头系谱，仅动物效应 C = Z'Z + lam A^-1，随机右端项，相对残差 1e-8
def kappa_sparse(C):
    lmax = spl.eigsh(C, k=1, which='LA', return_eigenvectors=False)[0]
    lmin = spl.eigsh(C, k=1, sigma=0, which='LM', return_eigenvectors=False)[0]
    return lmin, lmax, lmax / lmin
for seed in [1, 2]:
    sire, dam = gen_ped_two_gen(100, 1000, 3900, seed)
    n = len(sire)
    Ai = build_ainv(sire, dam)
    rec = np.arange(1100, n)
    Z = sp.csr_matrix((np.ones(len(rec)), (np.arange(len(rec)), rec)), shape=(len(rec), n))
    print('seed', seed)
    for h2 in [0.5, 0.25, 0.1, 0.05]:
        lam = (1 - h2) / h2
        C = (Z.T @ Z + lam * Ai).tocsc()
        rng = np.random.default_rng(100 + seed)
        b = rng.standard_normal(n)
        lo, hi, kap = kappa_sparse(C)
        d = C.diagonal(); Minv = lambda r: r / d
        r0 = pcg(lambda v: C @ v, b, None, tol=1e-8)
        r1 = pcg(lambda v: C @ v, b, Minv, tol=1e-8)
        kb = 0.5 * np.sqrt(kap) * np.log(2 / 1e-8)
        print(f'  h2={h2:4.2f} lam={lam:5.1f}  kappa={kap:7.1f}  CG={r0["it"]:4d}  JacobiPCG={r1["it"]:4d}   bound 0.5*sqrt(kappa)*ln(2/eps)={kb:6.1f}')
