# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 prec.py    依赖：numpy, scipy
"""预条件子：Jacobi、块对角、SSOR、IC(0)。所有 apply 函数返回 M^{-1} r，三角解用 SuperLU（自然序、对角主元）在 C 层完成。"""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl, time
import scipy.linalg as sla


def tri_solver(Tcsc, lower=True):
    """返回 solve(r) 与 solveT(r)：分别解 T y = r 与 T' y = r（T 为三角阵）。"""
    lu = spl.splu(sp.csc_matrix(Tcsc), permc_spec='NATURAL', diag_pivot_thresh=0.0, options=dict(SymmetricMode=False))
    # 若 T 为下三角：SuperLU 因 diag_pivot_thresh=0 不换行；L=单位下三角部分，U=对角
    return (lambda r: lu.solve(r)), (lambda r: lu.solve(r, trans='T'))


def ic0(C, shift=0.0):
    """零填入不完全 Cholesky（按给定编号顺序）。C 为对称稀疏阵；对 C 的下三角模式做 Cholesky 并丢弃全部填入。
    shift 为 Manteuffel 对角偏移：分解 C + shift*diag(C)。返回下三角 L（CSR→CSC）。主元非正则抛出 ValueError。"""
    C = sp.csr_matrix(C)
    n = C.shape[0]
    Lw = sp.tril(C, format='csr')
    ip = Lw.indptr.tolist(); ii = Lw.indices.tolist(); vv = Lw.data.tolist()
    # 每行的列索引（升序）与数值；逐行计算
    rows_idx = [None] * n
    rows_val = [None] * n
    rows_map = [None] * n
    diag = [0.0] * n
    for i in range(n):
        cols = ii[ip[i]:ip[i + 1]]
        vals = vv[ip[i]:ip[i + 1]]
        order = sorted(range(len(cols)), key=cols.__getitem__)
        cols = [cols[k] for k in order]; vals = [vals[k] for k in order]
        mp = {}
        s_diag = 0.0
        a_ii = 0.0
        newv = []
        for c, a in zip(cols, vals):
            if c == i:
                a_ii = a * (1.0 + shift)
                continue
            # l_ic = (a_ic - sum_{k<c} l_ik l_ck) / l_cc ，k 取 row i 已算出且在 row c 中的列
            s = a
            rc = rows_map[c]
            if mp and rc:
                # 遍历较短者
                if len(mp) < len(rc):
                    for k, lik in mp.items():
                        lck = rc.get(k)
                        if lck is not None:
                            s -= lik * lck
                else:
                    for k, lck in rc.items():
                        lik = mp.get(k)
                        if lik is not None:
                            s -= lik * lck
            lic = s / diag[c]
            mp[c] = lic
            s_diag += lic * lic
        piv = a_ii - s_diag
        if not (piv > 1e-12 * max(a_ii, 1e-300)):
            raise ValueError('IC(0) breakdown at row %d (pivot %.3e, a_ii %.3e)' % (i, piv, a_ii))
        diag[i] = piv ** 0.5
        rows_map[i] = mp
    # 组装 L
    r_, c_, v_ = [], [], []
    for i in range(n):
        for c, v in rows_map[i].items():
            r_.append(i); c_.append(c); v_.append(v)
        r_.append(i); c_.append(i); v_.append(diag[i])
    L = sp.coo_matrix((v_, (r_, c_)), shape=(n, n)).tocsc()
    return L


def ic0_auto(C, shifts=(0.0, 1e-4, 1e-3, 5e-3, 1e-2, 2e-2, 5e-2, 0.1, 0.2, 0.5)):
    last = None
    for s in shifts:
        try:
            return ic0(C, s), s
        except ValueError as e:
            last = e
    raise last


class Prec:
    """封装预条件子：apply(r)->M^{-1}r；dense_factor() 给出稠密 Lm（M=Lm Lm'）用于精确谱计算。"""
    def __init__(self, kind, C, p, shift=None, omega=1.0):
        self.kind = kind; self.C = sp.csc_matrix(C); self.p = p; self.omega = omega
        N = C.shape[0]; self.N = N
        d = self.C.diagonal()
        self.d = d
        self.shift = 0.0
        if kind == 'none':
            self.apply = None
        elif kind == 'jacobi':
            inv = 1.0 / d
            self.apply = lambda r: inv * r
        elif kind in ('block1', 'block2'):
            Cff = self.C[:p, :p].toarray()
            self.Lff = np.linalg.cholesky(Cff)
            self.Cff_f = sla.cho_factor(Cff)
            if kind == 'block1':
                invd = 1.0 / d[p:]
                def ap(r):
                    z = np.empty_like(r)
                    z[:p] = sla.cho_solve(self.Cff_f, r[:p])
                    z[p:] = invd * r[p:]
                    return z
            else:
                Cuu = self.C[p:, p:].tocsc()
                self.Cuu_lu = spl.splu(Cuu, permc_spec='MMD_AT_PLUS_A', diag_pivot_thresh=0.0, options=dict(SymmetricMode=True))
                def ap(r):
                    z = np.empty_like(r)
                    z[:p] = sla.cho_solve(self.Cff_f, r[:p])
                    z[p:] = self.Cuu_lu.solve(r[p:])
                    return z
            self.apply = ap
        elif kind == 'ssor':
            w = omega
            Lw = sp.tril(self.C, k=-1, format='csc')
            T = (sp.diags(d / w) + Lw).tocsc()            # D/w + L  (lower)
            self.T = T
            f, fT = tri_solver(T)
            dd = d / w
            sc = w * (2 - w)
            # M = (1/(w(2-w))) (D/w+L) (D/w)^{-1} (D/w+L)'  => M^{-1} r = w(2-w) (D/w+L)^{-T} (D/w) (D/w+L)^{-1} r
            self.apply = lambda r: sc * fT(dd * f(r))
            self._ssor = (T, dd, sc)
        elif kind == 'ic0':
            L, s = ic0_auto(self.C) if shift is None else (ic0(self.C, shift), shift)
            self.L = L; self.shift = s
            f, fT = tri_solver(L)
            self.apply = lambda r: fT(f(r))
        else:
            raise ValueError(kind)

    def dense_factor(self):
        """返回稠密下三角 Lm，使 M = Lm Lm'。"""
        N = self.N; k = self.kind
        if k == 'none':
            return np.eye(N)
        if k == 'jacobi':
            return np.diag(np.sqrt(self.d))
        if k in ('block1', 'block2'):
            Lm = np.zeros((N, N)); p = self.p
            Lm[:p, :p] = self.Lff
            if k == 'block1':
                Lm[np.arange(p, N), np.arange(p, N)] = np.sqrt(self.d[p:])
            else:
                Cuu = self.C[p:, p:].toarray()
                Lm[p:, p:] = np.linalg.cholesky(Cuu)
            return Lm
        if k == 'ssor':
            T, dd, sc = self._ssor
            # M = (1/sc) T diag(1/dd) T' => Lm = T diag(1/sqrt(dd)) / sqrt(sc)
            return T.toarray() / np.sqrt(dd)[None, :] / np.sqrt(sc)
        if k == 'ic0':
            return self.L.toarray()


def kappa_dense(C, prec):
    """M^{-1}C 的极端特征值与条件数（稠密，N 不宜超过约 3000）。"""
    Cd = C.toarray()
    Lm = prec.dense_factor()
    if prec.kind == 'none':
        w = np.linalg.eigvalsh(Cd)
    else:
        Y = sla.solve_triangular(Lm, Cd, lower=True)
        W = sla.solve_triangular(Lm, Y.T, lower=True)
        W = (W + W.T) / 2
        w = np.linalg.eigvalsh(W)
    return float(w[0]), float(w[-1]), float(w[-1] / w[0]), w
