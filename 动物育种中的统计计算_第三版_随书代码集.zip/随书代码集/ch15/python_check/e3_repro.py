# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 e3_repro.py    依赖：numpy, scipy
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl
from scipy.sparse.csgraph import reverse_cuthill_mckee
from lib import *
# 复现 §15.2.2 已有实验的系谱构造猜想：基础群 100 公 + 1000 母，其余 3900 头的父、母分别从基础群公、母中随机抽取（两代系谱）
for seed in [1, 2, 3]:
    sire, dam = gen_ped_two_gen(100, 1000, 3900, seed)
    n = len(sire)
    lam = 3.0
    Ai = build_ainv(sire, dam)
    rec = np.arange(1100, n)
    Z = sp.csr_matrix((np.ones(len(rec)), (np.arange(len(rec)), rec)), shape=(len(rec), n))
    C = (Z.T @ Z + lam * Ai).tocsc()
    tril = (C.nnz + n) // 2
    nat = symbolic_chol(C)[0]
    rev = symbolic_chol(C, np.arange(n)[::-1])[0]            # 个体号由大到小
    rcm = reverse_cuthill_mckee(sp.csr_matrix(C), symmetric_mode=True)
    nrcm = symbolic_chol(C, rcm)[0]
    lu = spl.splu(C, permc_spec='MMD_AT_PLUS_A', diag_pivot_thresh=0.0, options=dict(SymmetricMode=True))
    mmd = symbolic_chol(C, np.argsort(lu.perm_c))[0]
    print(f'seed {seed}: tril(C)={tril}  natural={nat} ({nat/tril:.0f}x)  idrev={rev} ({rev/tril:.1f}x)  rcm={nrcm} ({nrcm/tril:.1f}x)  mmd={mmd} ({mmd/tril:.2f}x)  lu nnzL numeric={lu.L.nnz}')
