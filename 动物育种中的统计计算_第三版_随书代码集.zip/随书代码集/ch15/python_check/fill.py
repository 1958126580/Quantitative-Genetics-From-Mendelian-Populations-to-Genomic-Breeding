# -*- coding: utf-8 -*-
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl, time, sys
from scipy.sparse.csgraph import reverse_cuthill_mckee, laplacian, connected_components
import common

def nd_order(A, minsize=60, seed=0):
    """Recursive spectral-bisection nested dissection (own implementation)."""
    A = sp.csr_matrix(A)
    n = A.shape[0]
    order = []
    def rec(nodes):
        m = len(nodes)
        if m <= minsize:
            order.extend(nodes); return
        sub = A[nodes][:, nodes]
        sub = ((sub != 0).astype(float))
        sub.setdiag(0); sub.eliminate_zeros()
        L = laplacian(sub).astype(float)
        try:
            vals, vecs = spl.eigsh(L + 1e-8*sp.eye(m), k=2, sigma=-1e-3, which='LM')
            f = vecs[:, np.argsort(vals)[1]]
        except Exception:
            f = np.arange(m, dtype=float)          # fallback
        med = np.median(f)
        left = np.where(f <= med)[0]; right = np.where(f > med)[0]
        if len(left) == 0 or len(right) == 0:
            order.extend(nodes); return
        inleft = np.zeros(m, bool); inleft[left] = True
        # vertex separator: left-side endpoints of cut edges
        co = sub.tocoo()
        cut = co.row[inleft[co.row] & ~inleft[co.col]]
        sep = np.unique(cut)
        sepmask = np.zeros(m, bool); sepmask[sep] = True
        L2 = [nodes[i] for i in left if not sepmask[i]]
        R2 = [nodes[i] for i in right]
        S2 = [nodes[i] for i in sep]
        if not L2 or not R2 or len(S2) >= m - 1:
            order.extend(nodes); return
        rec(L2); rec(R2); order.extend(S2)
    rec(list(range(n)))
    return np.array(order)

def mmd_order(A):
    """Multiple minimum degree from SuperLU (permc_spec='MMD_AT_PLUS_A')."""
    lu = spl.splu(sp.csc_matrix(A), permc_spec='MMD_AT_PLUS_A',
                  diag_pivot_thresh=0.0, options=dict(SymmetricMode=True))
    return np.argsort(lu.perm_c)   # SuperLU perm_c is old->new

def report(name, C, perm, base=None):
    t = time.time()
    nnzL, fl, cj, par = common.symbolic_nnzL(C, perm)
    dt = time.time() - t
    r = nnzL / C.nnz
    line = f'{name:24s} nnz(L)={nnzL:10d}  nnz(L)/nnz(C)={r:7.2f}  flops={fl:10.3e}'
    if base: line += f'  fill x{nnzL/base:6.2f}'
    print(line, flush=True)
    return nnzL, fl

if __name__ == '__main__':
    npg = int(sys.argv[1]) if len(sys.argv) > 1 else 500
    ngen = int(sys.argv[2]) if len(sys.argv) > 2 else 12
    s, d = common.sim_pedigree(n_gen=ngen, n_per_gen=npg, n_sires=int(npg/20)+5,
                               n_dams=int(npg/2), seed=0)
    C, b, p, info = common.build_mme(s, d, h2=0.25, rec_frac=0.6, seed=1)
    N = C.shape[0]
    print(f'pedigree n={len(s)}  MME order N={N}  nnz(C)={C.nnz}  fixed p={p}  records={info["n_rec"]}')
    n_an = len(s)
    res = {}
    res['natural'] = report('自然顺序(个体号)', C, None)
    rev = np.concatenate([np.arange(p), p + np.arange(n_an)[::-1]])
    nat2 = np.concatenate([p + np.arange(n_an), np.arange(p)])
    res['nat_fixlast'] = report('个体号升序+固定效应最后', C, nat2)
    rev2 = np.concatenate([p + np.arange(n_an)[::-1], np.arange(p)])
    res['revgen'] = report('世代倒序+固定效应最后', C, rev2)
    t = time.time(); rcm = reverse_cuthill_mckee(sp.csc_matrix(C), symmetric_mode=True); trcm = time.time()-t
    res['rcm'] = report('RCM', C, rcm)
    t = time.time(); mmd = mmd_order(C); tmmd = time.time()-t
    res['mmd'] = report('最小度(MMD)', C, mmd)
    t = time.time(); nd = nd_order(C); tnd = time.time()-t
    res['nd'] = report('嵌套剖分(谱二分)', C, nd)
    print(f'ordering time: RCM {trcm:.2f}s  MMD {tmmd:.2f}s  ND {tnd:.2f}s')
    print('dense-equivalent nnz = %.3e ; N^3/3 flops = %.3e' % (N*(N+1)/2, N**3/3))
