# -*- coding: utf-8 -*-
"""Shared simulation helpers for ch15 numerical experiments."""
import numpy as np
import scipy.sparse as sp


def sim_pedigree(n_gen=10, n_per_gen=200, n_sires=10, n_dams=100, seed=0):
    """Random-mating pedigree. Returns sire, dam arrays (0 = unknown), 1-based ids."""
    rng = np.random.default_rng(seed)
    sire = [0] * (n_sires + n_dams)          # generation 0 founders
    dam = [0] * (n_sires + n_dams)
    males = list(range(1, n_sires + 1))
    females = list(range(n_sires + 1, n_sires + n_dams + 1))
    for g in range(n_gen):
        newm, newf = [], []
        for k in range(n_per_gen):
            s = males[rng.integers(len(males))]
            d = females[rng.integers(len(females))]
            sire.append(s); dam.append(d)
            i = len(sire)
            if k % 2 == 0: newm.append(i)
            else: newf.append(i)
        # next generation parents: replace a fraction of the parent pool
        males = newm[:n_sires] if len(newm) >= n_sires else newm + males
        females = newf[:n_dams] if len(newf) >= n_dams else newf + females
    return np.array(sire), np.array(dam)


def build_Ainv(sire, dam):
    """Henderson rules, no inbreeding. 0-based sparse matrix of order n."""
    n = len(sire)
    rows, cols, vals = [], [], []
    for i in range(n):
        s, d = sire[i], dam[i]
        if s and d: b = 2.0
        elif s or d: b = 4.0 / 3.0
        else: b = 1.0
        idx = [i]; coef = [1.0]
        if s: idx.append(s - 1); coef.append(-0.5)
        if d: idx.append(d - 1); coef.append(-0.5)
        for a in range(len(idx)):
            for c in range(len(idx)):
                rows.append(idx[a]); cols.append(idx[c]); vals.append(b * coef[a] * coef[c])
    return sp.csc_matrix(sp.coo_matrix((vals, (rows, cols)), shape=(n, n)))


def build_mme(sire, dam, h2=0.25, n_hy=None, rec_frac=0.5, seed=1, n_fixed_lv=None):
    """Single-trait animal model MME: fixed herd-year effect + animal effect.

    Returns C (csc, full rank via last HY level dropped), b, index of animal block start,
    plus the design info.
    """
    rng = np.random.default_rng(seed)
    n = len(sire)
    lam = (1 - h2) / h2
    # animals with a record: the youngest rec_frac fraction
    n_rec = int(n * rec_frac)
    rec_animals = np.arange(n - n_rec, n)          # 0-based
    n_hy = n_hy if n_hy else max(2, n_rec // 25)
    hy = rng.integers(0, n_hy, size=n_rec)
    y = rng.normal(size=n_rec)
    # X: drop last HY level for full rank
    p = n_hy - 1
    keep = hy < p
    X = sp.coo_matrix((np.ones(keep.sum()), (np.where(keep)[0], hy[keep])), shape=(n_rec, p)).tocsc()
    X = sp.hstack([np.ones((n_rec, 1)), X]).tocsc()      # intercept + p HY contrasts
    p = X.shape[1]
    Z = sp.coo_matrix((np.ones(n_rec), (np.arange(n_rec), rec_animals)), shape=(n_rec, n)).tocsc()
    Ainv = build_Ainv(sire, dam)
    C = sp.bmat([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * Ainv]]).tocsc()
    b = np.concatenate([X.T @ y, Z.T @ y])
    return C.tocsc(), b, p, dict(n=n, n_rec=n_rec, lam=lam, h2=h2, Ainv=Ainv, X=X, Z=Z, y=y,
                                 rec_animals=rec_animals, hy=hy, n_hy=n_hy)


def symbolic_nnzL(A, perm=None):
    """Symbolic Cholesky: returns (nnz(L) incl. diagonal, flops estimate, colcount, parent).

    Phase 1 builds the elimination tree (Davis 2006, cs_etree, with path compression);
    phase 2 walks the row subtrees (cs_ereach) to get row/column counts.
    """
    A = sp.csr_matrix(A)
    n = A.shape[0]
    if perm is not None:
        perm = np.asarray(perm)
        P = sp.coo_matrix((np.ones(n), (np.arange(n), perm)), shape=(n, n)).tocsr()
        A = (P @ A @ P.T).tocsr()
    indptr, indices = A.indptr, A.indices
    parent = np.full(n, -1, dtype=np.int64)
    ancestor = np.full(n, -1, dtype=np.int64)
    for k in range(n):
        for pos in range(indptr[k], indptr[k + 1]):
            i = indices[pos]
            if i >= k:
                continue
            while i != -1 and i < k:
                inext = ancestor[i]
                ancestor[i] = k
                if inext == -1:
                    parent[i] = k
                i = inext
    # phase 2: row subtrees
    colcount = np.zeros(n, dtype=np.int64)
    mark = np.full(n, -1, dtype=np.int64)
    par = parent
    for k in range(n):
        mark[k] = k
        for pos in range(indptr[k], indptr[k + 1]):
            i = indices[pos]
            if i >= k:
                continue
            while mark[i] != k:
                mark[i] = k
                colcount[i] += 1
                i = par[i]
                if i == -1:
                    break
    cj = colcount + 1                       # including diagonal
    nnzL = int(cj.sum())
    flops = float(np.sum(cj.astype(float) ** 2))
    return nnzL, flops, cj, parent
