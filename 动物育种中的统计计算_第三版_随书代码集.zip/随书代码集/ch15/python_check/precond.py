# -*- coding: utf-8 -*-
"""Condition numbers and iteration counts: no/Jacobi/block/IC(0) preconditioning."""
import numpy as np, scipy.sparse as sp, scipy.linalg as sla, time, sys
import common

def ic0(C):
    """Incomplete Cholesky IC(0) on the pattern of tril(C). Returns dense L."""
    A = sp.csr_matrix(sp.tril(C))
    n = A.shape[0]
    rows = [dict() for _ in range(n)]
    for i in range(n):
        cols = A.indices[A.indptr[i]:A.indptr[i+1]]
        vals = A.data[A.indptr[i]:A.indptr[i+1]]
        order = np.argsort(cols)
        for j, v in zip(cols[order], vals[order]):
            if j < i:
                s = v - sum(rows[i].get(k, 0.0) * rows[j].get(k, 0.0) for k in rows[j] if k < j)
                rows[i][j] = s / rows[j][j]
            elif j == i:
                s = v - sum(x * x for k, x in rows[i].items() if k < i)
                if s <= 0:
                    return None
                rows[i][i] = np.sqrt(s)
    L = np.zeros((n, n))
    for i in range(n):
        for j, v in rows[i].items():
            L[i, j] = v
    return L

def pcg(C, b, Minv, tol=1e-8, maxit=20000, x0=None, track=None, dtype=np.float64):
    C = C.astype(dtype)
    b = b.astype(dtype)
    x = np.zeros_like(b) if x0 is None else x0.astype(dtype).copy()
    r = b - C @ x
    nb = np.linalg.norm(b)
    z = Minv(r).astype(dtype); p = z.copy(); rz = r @ z
    hist = []
    for k in range(1, maxit + 1):
        Ap = (C @ p).astype(dtype)
        alpha = rz / (p @ Ap)
        xold = x.copy()
        x = x + alpha * p
        r = r - alpha * Ap
        rel = np.linalg.norm(r) / nb
        if track is not None:
            track.append((k, rel, np.linalg.norm(x - xold) / np.linalg.norm(x), x.copy()))
        hist.append(rel)
        if rel < tol:
            return x, k, hist
        z = Minv(r).astype(dtype); rznew = r @ z
        p = z + (rznew / rz) * p; rz = rznew
    return x, maxit, hist

def stationary(C, b, kind='jacobi', omega=1.0, tol=1e-8, maxit=200000):
    n = C.shape[0]; d = C.diagonal(); x = np.zeros(n); nb = np.linalg.norm(b)
    Cc = sp.csr_matrix(C)
    if kind == 'jacobi':
        for k in range(1, maxit + 1):
            x = x + (b - Cc @ x) / d
            if np.linalg.norm(b - Cc @ x) / nb < tol: return k
        return maxit
    L = sp.tril(Cc, 0).tocsc(); U = sp.triu(Cc, 1).tocsc()
    M = (sp.diags(d) / omega + sp.tril(Cc, -1)).tocsc()
    lu = sp.linalg.splu(M)
    for k in range(1, maxit + 1):
        x = x + lu.solve(b - Cc @ x)
        if np.linalg.norm(b - Cc @ x) / nb < tol: return k
    return maxit

def run(h2, npg=150, ngen=10, tol=1e-8, verbose=True):
    s, d = common.sim_pedigree(n_gen=ngen, n_per_gen=npg, n_sires=max(5, npg//20),
                               n_dams=npg//2, seed=0)
    C, b, p, info = common.build_mme(s, d, h2=h2, rec_frac=0.6, seed=1)
    N = C.shape[0]; Cd = C.toarray()
    ev = sla.eigvalsh(Cd); kap = ev[-1]/ev[0]
    out = {'N': N, 'nnz': C.nnz, 'p': p, 'lam': info['lam'], 'h2': h2, 'kappa': kap}
    if verbose:
        print(f'--- h2={h2}  lambda={info["lam"]:.1f}  N={N}  nnz={C.nnz}  kappa(C)={kap:.3e}')
    # no preconditioner
    _, k0, _ = pcg(C, b, lambda r: r, tol=tol)
    out['none'] = (kap, k0)
    # Jacobi
    dg = C.diagonal()
    M = np.diag(dg)
    evj = sla.eigvalsh(Cd, M); kj = evj[-1]/evj[0]
    _, k1, _ = pcg(C, b, lambda r: r/dg, tol=tol); out['jacobi'] = (kj, k1)
    # block diagonal: exact fixed-effect block + diagonal animal block
    Mb = np.zeros((N, N)); Mb[:p, :p] = Cd[:p, :p]
    Mb[p:, p:] = np.diag(dg[p:])
    lub = sla.lu_factor(Mb)
    evb = sla.eigvalsh(Cd, Mb); kb = evb[-1]/evb[0]
    _, k2, _ = pcg(C, b, lambda r: sla.lu_solve(lub, r), tol=tol); out['block'] = (kb, k2)
    # IC(0)
    t = time.time(); Lic = ic0(C); tic = time.time()-t
    if Lic is not None:
        Mic = Lic @ Lic.T
        evi = sla.eigvalsh(Cd, Mic); ki = evi[-1]/evi[0]
        f = lambda r: sla.solve_triangular(Lic.T, sla.solve_triangular(Lic, r, lower=True), lower=False)
        _, k3, _ = pcg(C, b, f, tol=tol)
        out['ic0'] = (ki, k3)
        out['ic0_nnz'] = int((np.abs(Lic) > 0).sum())
    if verbose:
        for nm in ['none','jacobi','block','ic0']:
            if nm in out:
                print(f'  {nm:8s} kappa={out[nm][0]:10.3e}  PCG iters(rel.res<{tol:g})={out[nm][1]:5d}'
                      f'   bound={0.5*np.sqrt(out[nm][0])*np.log(2/tol):8.0f}')
        print(f'  IC(0) nnz(L)={out.get("ic0_nnz")}  vs nnz(tril C)={sp.tril(C).nnz}   build {tic:.1f}s')
    return C, b, p, info, out

if __name__ == '__main__':
    for h2 in [0.25, 0.05]:
        C, b, p, info, out = run(h2)
        t=time.time(); kj = stationary(C, b, 'jacobi'); 
        print(f'  Jacobi(定常) iters={kj}   [{time.time()-t:.0f}s]')
        best=None
        for om in [1.0, 1.3, 1.5, 1.7, 1.9]:
            k = stationary(C, b, 'sor', omega=om, maxit=50000)
            print(f'  SOR omega={om}: iters={k}')
            best = k if best is None else min(best, k)
        print(f'  best SOR iters={best}')
