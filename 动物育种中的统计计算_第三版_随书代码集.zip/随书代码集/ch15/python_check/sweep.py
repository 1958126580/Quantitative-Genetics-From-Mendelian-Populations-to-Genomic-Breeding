# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 sweep.py    依赖：numpy, scipy
"""(a) kappa and PCG iterations vs h2; (b) multi-trait block preconditioner; (c) two-level."""
import numpy as np, scipy.sparse as sp, scipy.linalg as sla, time
import common, precond

def jacobi_scaled(Cd):
    dg = np.sqrt(np.diag(Cd))
    S = Cd / dg[:, None] / dg[None, :]
    ev = sla.eigvalsh(S)
    return ev[-1] / ev[0]

print('=== (a) h2 sweep, same pedigree/data, N fixed ===')
s, d = common.sim_pedigree(n_gen=12, n_per_gen=200, n_sires=10, n_dams=100, seed=0)
print('pedigree n =', len(s))
for h2 in [0.50, 0.25, 0.10, 0.05, 0.02]:
    C, b, p, info = common.build_mme(s, d, h2=h2, rec_frac=0.6, seed=1)
    Cd = C.toarray(); N = C.shape[0]
    ev = sla.eigvalsh(Cd); kap = ev[-1]/ev[0]
    kj = jacobi_scaled(Cd)
    dg = C.diagonal()
    _, k0, _ = precond.pcg(C, b, lambda r: r, tol=1e-8)
    _, k1, _ = precond.pcg(C, b, lambda r: r/dg, tol=1e-8)
    print(f'h2={h2:4.2f} lam={info["lam"]:5.1f} N={N} kappa(C)={kap:10.3e} kappa(D^-1C)={kj:10.3e} '
          f'PCG(no prec)={k0:4d} PCG(Jacobi)={k1:4d}')

print()
print('=== (b) multi-trait: diagonal vs t x t block-diagonal preconditioner ===')
def build_mt(sire, dam, G0, R0, rec_frac=0.6, n_hy=None, seed=1):
    rng = np.random.default_rng(seed)
    n = len(sire); t = G0.shape[0]
    Ainv = common.build_Ainv(sire, dam)
    n_rec = int(n*rec_frac); rec = np.arange(n-n_rec, n)
    R0i = np.linalg.inv(R0); G0i = np.linalg.inv(G0)
    n_hy = n_hy if n_hy else max(2, n_rec//25)
    hy = rng.integers(0, n_hy, size=n_rec)
    # fixed effects: hy x trait, animal-major u ordering (animal outer, trait inner)
    p = n_hy*t
    Xr, Xc, Xv = [], [], []
    Zr, Zc, Zv = [], [], []
    for r_i, a in enumerate(rec):
        for tr in range(t):
            Xr.append(r_i*t+tr); Xc.append(hy[r_i]*t+tr); Xv.append(1.0)
            Zr.append(r_i*t+tr); Zc.append(a*t+tr); Zv.append(1.0)
    m = n_rec*t
    X = sp.coo_matrix((Xv, (Xr, Xc)), shape=(m, p)).tocsc()
    Z = sp.coo_matrix((Zv, (Zr, Zc)), shape=(m, n*t)).tocsc()
    Rinv = sp.kron(sp.identity(n_rec), sp.csc_matrix(R0i)).tocsc()
    C = sp.bmat([[X.T@Rinv@X, X.T@Rinv@Z],
                 [Z.T@Rinv@X, Z.T@Rinv@Z + sp.kron(Ainv, sp.csc_matrix(G0i))]]).tocsc()
    y = rng.normal(size=m)
    b = np.concatenate([X.T@Rinv@y, Z.T@Rinv@y])
    # fix rank deficiency: drop last hy level's equations
    keep = np.ones(C.shape[0], bool); keep[p-t:p] = False
    C = C[keep][:, keep]; b = b[keep]
    return C.tocsc(), b, p-t, t, n

s2, d2 = common.sim_pedigree(n_gen=8, n_per_gen=80, n_sires=6, n_dams=40, seed=0)
t = 3
for rho in [0.0, 0.5, 0.85]:
    G0 = np.full((t, t), rho) + (1-rho)*np.eye(t)
    R0 = (np.full((t, t), rho*0.6) + (1-rho*0.6)*np.eye(t)) * 3.0
    C, b, p, t_, n = build_mt(s2, d2, G0, R0)
    Cd = C.toarray(); N = C.shape[0]; dg = C.diagonal()
    kap = sla.eigvalsh(Cd)[-1]/sla.eigvalsh(Cd)[0]
    # diagonal
    kd = jacobi_scaled(Cd)
    _, k1, _ = precond.pcg(C, b, lambda r: r/dg, tol=1e-8)
    # block diagonal: t x t blocks along the animal part, fixed block exact
    M = np.zeros((N, N)); M[:p, :p] = Cd[:p, :p]
    for i in range(n):
        sl = slice(p+i*t, p+(i+1)*t)
        M[sl, sl] = Cd[sl, sl]
    lub = sla.lu_factor(M)
    kb = sla.eigvalsh(Cd, M)
    kb = kb[-1]/kb[0]
    _, k2, _ = precond.pcg(C, b, lambda r: sla.lu_solve(lub, r), tol=1e-8)
    print(f'rho={rho:4.2f} t={t} N={N} nnz={C.nnz} kappa(C)={kap:9.3e} | Jacobi: kappa={kd:9.3e} it={k1:4d}'
          f' | {t}x{t}block: kappa={kb:9.3e} it={k2:4d}')

print()
print('=== (c) two-level (AMG-style) aggregation preconditioner ===')
C, b, p, info = common.build_mme(s, d, h2=0.25, rec_frac=0.6, seed=1)
N = C.shape[0]; n = info['n']; dg = C.diagonal(); Cd = C.toarray()
sire = s
for agg_kind in ['sire', 'gen']:
    if agg_kind == 'sire':
        key = np.where(sire > 0, sire, np.arange(1, n+1) + 10**7)
    else:
        # aggregate by birth-order blocks of 50 (proxy for generation groups)
        key = np.arange(n) // 50
    uniq, lab = np.unique(key, return_inverse=True)
    nc = len(uniq)
    P = sp.coo_matrix((np.ones(n), (p+np.arange(n), lab)), shape=(N, nc)).tocsc()
    P = sp.hstack([sp.vstack([sp.identity(p), sp.csc_matrix((N-p, p))]), P]).tocsc()  # keep fixed effects in coarse space
    Ac = (P.T @ C @ P).toarray()
    lua = sla.lu_factor(Ac)
    Pd = P.toarray()
    def Minv(r, Pd=Pd, lua=lua, dg=dg):
        return r/dg + Pd @ sla.lu_solve(lua, Pd.T @ r)
    M = np.linalg.inv(np.diag(1/dg) + Pd @ sla.lu_solve(lua, Pd.T))
    ev = sla.eigvalsh(Cd, M); k2l = ev[-1]/ev[0]
    _, kit, _ = precond.pcg(C, b, Minv, tol=1e-8)
    _, kj, _ = precond.pcg(C, b, lambda r: r/dg, tol=1e-8)
    print(f'aggregation={agg_kind}: coarse dim={P.shape[1]} ({100*P.shape[1]/N:.1f}% of N) '
          f'kappa(two-level)={k2l:9.3e} iters={kit}  (Jacobi alone: iters={kj})')
