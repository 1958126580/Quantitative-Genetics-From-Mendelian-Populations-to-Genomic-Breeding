# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 t_lib3.py    依赖：numpy, scipy
import numpy as np, scipy.sparse as sp
from scipy.sparse.csgraph import reverse_cuthill_mckee
from lib import *
sire, dam, sex, gen = gen_ped(8, 60, 4, 30, seed=5)
C, b, info = build_mme(sire, dam, sex, gen, h2=0.25, rec_gens=4, rec_per_hy=10)
N = C.shape[0]
# random-valued SPD matrix with the same pattern
rng = np.random.default_rng(3)
P = (C != 0).astype(float).tocoo()
vals = rng.uniform(0.2, 1.0, P.nnz)
R = sp.coo_matrix((vals, (P.row, P.col)), shape=(N, N)).tocsr()
R = (R + R.T) / 2
R = R + sp.diags(np.abs(R).sum(axis=1).A.ravel() + 1.0)
Rd = R.toarray()
rcm = reverse_cuthill_mckee(sp.csr_matrix(C), symmetric_mode=True)
lu, t = lu_symmetric(C, 'MMD_AT_PLUS_A')
mmd = np.argsort(lu.perm_c)
for name, perm in [('nat', np.arange(N)), ('rev', np.arange(N)[::-1]), ('rcm', rcm), ('mmd', mmd), ('rand1', rng.permutation(N)), ('rand2', rng.permutation(N))]:
    Ld = np.linalg.cholesky(Rd[np.ix_(perm, perm)])
    nzd = int((np.abs(Ld) > 0).sum())
    nzs, fl, cc, par = symbolic_chol(R, perm)
    # also column count vector equality
    lowmask = np.tril(np.abs(Ld) > 0)
    print(f'{name:6s} dense-structure nnz {nzd:7d}  symbolic {nzs:7d}  colcounts equal: {np.array_equal(lowmask.sum(axis=0), cc)}')
