# -*- coding: utf-8 -*-
"""ch15d 共用工具：系谱模拟、Henderson 规则 A^{-1}、动物模型 MME、符号 Cholesky（消去树+列计数）、PCG。"""
import os
for _v in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_v] = '1'
import time
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl


# ---------------------------------------------------------------- 系谱
def gen_ped(n_gen, n_per_gen, n_sires, n_dams, seed):
    """离散世代系谱。第 0 代为基础群（亲本未知）；第 g 代的父亲从第 g-1 代的 n_sires 头公畜中随机选，
    母亲从第 g-1 代的 n_dams 头母畜中随机选（放回，各亲本被选概率相同）。编号 1 基，0 表示未知。"""
    rng = np.random.default_rng(seed)
    n = n_gen * n_per_gen
    sire = np.zeros(n, dtype=np.int64)
    dam = np.zeros(n, dtype=np.int64)
    sex = rng.integers(0, 2, size=n)              # 0 公 1 母
    gen = np.repeat(np.arange(n_gen), n_per_gen)
    for g in range(1, n_gen):
        prev = np.arange((g - 1) * n_per_gen, g * n_per_gen)
        males = prev[sex[prev] == 0]
        females = prev[sex[prev] == 1]
        ss = rng.choice(males, size=min(n_sires, len(males)), replace=False)
        dd = rng.choice(females, size=min(n_dams, len(females)), replace=False)
        idx = np.arange(g * n_per_gen, (g + 1) * n_per_gen)
        sire[idx] = rng.choice(ss, size=len(idx)) + 1
        dam[idx] = rng.choice(dd, size=len(idx)) + 1
    return sire, dam, sex, gen


def gen_ped_recursive(n, n_base, seed):
    """随机递归系谱：个体 i>n_base 的父母从全部更早个体中均匀随机抽取（无世代结构）。"""
    rng = np.random.default_rng(seed)
    sire = np.zeros(n, dtype=np.int64)
    dam = np.zeros(n, dtype=np.int64)
    for i in range(n_base, n):                # 0 基下标 i，已有 i 个个体，ids 1..i
        sire[i] = rng.integers(1, i + 1)
        dam[i] = rng.integers(1, i + 1)
    return sire, dam


def gen_ped_two_gen(n_sires, n_dams, n_off, seed):
    """两代系谱：基础群 n_sires 头公畜 + n_dams 头母畜，其余每头后代的父亲、母亲分别从基础群公畜、母畜中随机抽取。"""
    rng = np.random.default_rng(seed)
    nb = n_sires + n_dams
    n = nb + n_off
    sire = np.zeros(n, dtype=np.int64)
    dam = np.zeros(n, dtype=np.int64)
    sire[nb:] = rng.integers(1, n_sires + 1, size=n_off)
    dam[nb:] = n_sires + rng.integers(1, n_dams + 1, size=n_off)
    return sire, dam


def inbreeding_ml(sire, dam):
    """Meuwissen-Luo 近交系数（只为核对"忽略近交"的影响，n<=1e4 时使用）。返回 F, d（d 为式 9.5 的 Mendel 抽样方差系数）。"""
    import heapq
    n = len(sire)
    F = np.zeros(n)
    d = np.zeros(n)
    s_l = sire.tolist(); d_l = dam.tolist()
    Fl = [0.0] * n; dl = [1.0] * n
    for i in range(n):
        s, dd = s_l[i], d_l[i]
        if s == 0 and dd == 0:
            Fl[i] = 0.0; dl[i] = 1.0; continue
        if s and dd:
            dl[i] = 0.5 - (Fl[s - 1] + Fl[dd - 1]) / 4.0
        else:
            p = s if s else dd
            dl[i] = 0.75 - Fl[p - 1] / 4.0
        L = {i: 1.0}
        H = [-i]
        acc = 0.0
        while H:
            j = -heapq.heappop(H)
            lj = L.pop(j)
            acc += lj * lj * dl[j]
            for p in (s_l[j], d_l[j]):
                if p:
                    q = p - 1
                    if q not in L:
                        L[q] = 0.0
                        heapq.heappush(H, -q)
                    L[q] += lj / 2.0
        Fl[i] = acc - 1.0
    return np.array(Fl), np.array(dl)


# ---------------------------------------------------------------- A^{-1}
def build_ainv(sire, dam, F=None):
    """Henderson 规则（含 Quaas 近交修正，F 缺省时视为 0）。返回稀疏 CSC（n×n）。"""
    n = len(sire)
    if F is None:
        F = np.zeros(n)
    s = sire; d = dam
    hs = s > 0; hd = d > 0
    idx = np.arange(n)
    Fs = np.where(hs, F[np.maximum(s - 1, 0)], 0.0)
    Fd = np.where(hd, F[np.maximum(d - 1, 0)], 0.0)
    dii = np.where(hs & hd, 0.5 - 0.25 * (Fs + Fd),
                   np.where(hs | hd, 0.75 - 0.25 * (Fs + Fd), 1.0))
    b = 1.0 / dii
    pos = [idx, s - 1, d - 1]
    ok = [np.ones(n, bool), hs, hd]
    q = [np.ones(n), -0.5 * np.ones(n), -0.5 * np.ones(n)]
    rows, cols, vals = [], [], []
    for a in range(3):
        for c in range(3):
            m = ok[a] & ok[c]
            rows.append(pos[a][m]); cols.append(pos[c][m]); vals.append((b * q[a] * q[c])[m])
    A = sp.coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(n, n))
    return A.tocsc()


def sim_tbv(sire, dam, sig2a, rng):
    """按 Mendel 抽样模拟真实育种值（忽略近交：d_i = 1/2, 3/4, 1）。"""
    n = len(sire)
    u = np.zeros(n)
    z = rng.standard_normal(n)
    for i in range(n):
        s, d = sire[i], dam[i]
        if s and d:
            u[i] = 0.5 * (u[s - 1] + u[d - 1]) + np.sqrt(0.5 * sig2a) * z[i]
        elif s or d:
            p = s if s else d
            u[i] = 0.5 * u[p - 1] + np.sqrt(0.75 * sig2a) * z[i]
        else:
            u[i] = np.sqrt(sig2a) * z[i]
    return u


# ---------------------------------------------------------------- MME
def build_mme(sire, dam, sex, gen, h2=0.25, rec_gens=5, rec_per_hy=25, seed=7, extra_fixed=True,
              ymean=0.0, F=None, only_animal=False):
    """单性状动物模型 MME：C = [X'X X'Z; Z'X Z'Z+lam A^-1]。
    记录：最后 rec_gens 个世代的全部个体各 1 条；固定效应 = 场-年(每 rec_per_hy 条记录 1 个水平的随机分配)
    + 性别 + 年龄组(3 级)。HY 水平的哑变量不含截距，故 X 满列秩（性别、年龄组各去掉 1 个水平）。
    only_animal=True 时去掉固定效应，系数阵仅含动物方程 Z'Z + lam A^-1 （Z 对有记录个体）。"""
    rng = np.random.default_rng(seed)
    n = len(sire)
    lam = (1 - h2) / h2
    sig2a = h2; sig2e = 1 - h2
    first_rec_gen = gen.max() + 1 - rec_gens
    rec = np.where(gen >= first_rec_gen)[0]
    nr = len(rec)
    n_hy = max(2, nr // rec_per_hy)
    hy = rng.integers(0, n_hy, size=nr)
    cols = [sp.csr_matrix((np.ones(nr), (np.arange(nr), hy)), shape=(nr, n_hy))]
    if extra_fixed:
        sx = sex[rec].astype(float)
        age = rng.integers(0, 3, size=nr)
        cols.append(sp.csr_matrix(sx.reshape(-1, 1)))
        cols.append(sp.csr_matrix((np.ones((age > 0).sum()), (np.where(age > 0)[0], age[age > 0] - 1)), shape=(nr, 2)))
    X = sp.hstack(cols).tocsc()
    p = X.shape[1]
    Z = sp.csr_matrix((np.ones(nr), (np.arange(nr), rec)), shape=(nr, n)).tocsc()
    Ainv = build_ainv(sire, dam, F)
    u = sim_tbv(sire, dam, sig2a, rng)
    hy_eff = rng.normal(0, 1.0, size=n_hy)
    y = ymean + hy_eff[hy] + 0.3 * (sex[rec] if extra_fixed else 0) + u[rec] + rng.normal(0, np.sqrt(sig2e), nr)
    if only_animal:
        C = (Z.T @ Z + lam * Ainv).tocsc()
        b = Z.T @ y
        p = 0
    else:
        C = sp.bmat([[X.T @ X, X.T @ Z], [Z.T @ X, Z.T @ Z + lam * Ainv]], format='csc')
        b = np.concatenate([X.T @ y, Z.T @ y])
    return C, b, dict(p=p, n=n, nr=nr, lam=lam, X=X, Z=Z, y=y, u=u, Ainv=Ainv, rec=rec, n_hy=n_hy)


# ---------------------------------------------------------------- 符号 Cholesky（Davis 2006 第 4 章）
def _etree_upper(Ucsc_indptr, Ucsc_indices, n):
    """输入对称矩阵上三角的 CSC（第 k 列含行 i<=k）。返回 parent 列表（根为 -1）。"""
    parent = [-1] * n
    ancestor = [-1] * n
    ip = Ucsc_indptr; ii = Ucsc_indices
    for k in range(n):
        for p in range(ip[k], ip[k + 1]):
            i = ii[p]
            while i != -1 and i < k:
                inext = ancestor[i]
                ancestor[i] = k
                if inext == -1:
                    parent[i] = k
                i = inext
    return parent


def _postorder(parent, n):
    head = [-1] * n
    nxt = [-1] * n
    for j in range(n - 1, -1, -1):
        p = parent[j]
        if p == -1:
            continue
        nxt[j] = head[p]
        head[p] = j
    post = []
    stack = []
    for j in range(n):
        if parent[j] != -1:
            continue
        stack.append(j)
        while stack:
            p = stack[-1]
            i = head[p]
            if i == -1:
                stack.pop()
                post.append(p)
            else:
                head[p] = nxt[i]
                stack.append(i)
    return post


def symbolic_chol(C, perm=None):
    """符号 Cholesky：返回 (nnzL（含对角）, 浮点运算数估计 sum c_j^2, 列计数 c_j, parent)。
    先做 B = P C P'，再用 etree + Gilbert-Ng-Peyton 列计数（Davis, cs_counts）。"""
    C = sp.csc_matrix(C)
    n = C.shape[0]
    if perm is not None:
        perm = np.asarray(perm)
        C = C[perm][:, perm].tocsc()
    # 上三角（含对角）的 CSC，用于 etree；下三角的 CSC（列 j 含行 i>=j）用于计数
    U = sp.triu(C, format='csc')
    parent = _etree_upper(U.indptr.tolist(), U.indices.tolist(), n)
    post = _postorder(parent, n)
    # 下三角的严格部分：第 j 列的行号 i>j。等价于 U 的转置的 CSC
    Lw = sp.tril(C, k=-1, format='csc')
    Lp = Lw.indptr.tolist(); Li = Lw.indices.tolist()
    first = [-1] * n
    maxfirst = [-1] * n
    prevleaf = [-1] * n
    ancestor = list(range(n))
    delta = [0] * n
    for k in range(n):
        j = post[k]
        delta[j] = 1 if first[j] == -1 else 0
        while j != -1 and first[j] == -1:
            first[j] = k
            j = parent[j]
    for k in range(n):
        j = post[k]
        if parent[j] != -1:
            delta[parent[j]] -= 1
        for p in range(Lp[j], Lp[j + 1]):
            i = Li[p]
            # cs_leaf(i, j, ...)
            if first[j] <= maxfirst[i]:
                continue
            maxfirst[i] = first[j]
            jprev = prevleaf[i]
            prevleaf[i] = j
            if jprev == -1:
                delta[j] += 1
            else:
                q = jprev
                while q != ancestor[q]:
                    q = ancestor[q]
                s = jprev
                while s != q:
                    sp_ = ancestor[s]
                    ancestor[s] = q
                    s = sp_
                delta[j] += 1
                delta[q] -= 1
        if parent[j] != -1:
            ancestor[j] = parent[j]
    colcount = delta[:]
    for j in range(n):
        if parent[j] != -1:
            colcount[parent[j]] += colcount[j]
    cc = np.array(colcount, dtype=np.int64)
    return int(cc.sum()), float(np.sum(cc.astype(float) ** 2)), cc, np.array(parent)


def lu_symmetric(C, spec, perm=None, dtype=np.float64):
    """SuperLU，对称模式、对角主元（diag_pivot_thresh=0），使结构等同 Cholesky 因子。spec 为 permc_spec。"""
    A = sp.csc_matrix(C, dtype=dtype)
    if perm is not None:
        A = A[perm][:, perm].tocsc()
    t0 = time.perf_counter()
    lu = spl.splu(A, permc_spec=spec, diag_pivot_thresh=0.0, options=dict(SymmetricMode=True))
    t = time.perf_counter() - t0
    return lu, t


# ---------------------------------------------------------------- PCG
def pcg(matvec, b, Minv=None, tol=1e-8, maxit=100000, x_true=None, Cmat=None, track_xchg=False, dtype=np.float64,
        x0=None, record_lanczos=False):
    """预条件共轭梯度。Minv(r) 返回 M^{-1} r（缺省为恒等）。返回 dict：x, it, res（相对残差历史）,
    errA（若给 x_true 与 Cmat，则为能量范数相对误差历史）, lan（Lanczos 三对角元素 alpha,beta）。"""
    b = np.asarray(b, dtype=dtype)
    n = len(b)
    x = np.zeros(n, dtype=dtype) if x0 is None else np.array(x0, dtype=dtype)
    r = b - matvec(x)
    z = r.copy() if Minv is None else Minv(r)
    p = z.copy()
    rz = r @ z
    nb = np.linalg.norm(b)
    res = [np.linalg.norm(r) / nb]
    errA = []
    xch = []
    if x_true is not None:
        e = x - x_true
        errA.append(float(np.sqrt(e @ (Cmat @ e))))
    alphas, betas = [], []
    it = 0
    for it in range(1, maxit + 1):
        Ap = matvec(p)
        alpha = rz / (p @ Ap)
        x += alpha * p
        r -= alpha * Ap
        rn = np.linalg.norm(r) / nb
        res.append(rn)
        if track_xchg:
            xch.append(np.linalg.norm(alpha * p) / max(np.linalg.norm(x), 1e-300))
        if x_true is not None:
            e = x - x_true
            errA.append(float(np.sqrt(e @ (Cmat @ e))))
        alphas.append(float(alpha))
        if rn < tol:
            break
        z = r.copy() if Minv is None else Minv(r)
        rz_new = r @ z
        beta = rz_new / rz
        betas.append(float(beta))
        p = z + beta * p
        rz = rz_new
    out = dict(x=x, it=it, res=np.array(res), alphas=alphas, betas=betas)
    if x_true is not None:
        out['errA'] = np.array(errA)
    if track_xchg:
        out['xchg'] = np.array(xch)
    return out


def lanczos_extremes(alphas, betas):
    """由 CG 系数构造 Lanczos 三对角阵，返回 (最小, 最大) Ritz 值。"""
    k = len(alphas)
    if k == 0:
        return None
    d = np.zeros(k); e = np.zeros(max(k - 1, 0))
    for j in range(k):
        d[j] = 1.0 / alphas[j] + (betas[j - 1] / alphas[j - 1] if j > 0 else 0.0)
    for j in range(k - 1):
        e[j] = np.sqrt(betas[j]) / alphas[j]
    from scipy.linalg import eigvalsh_tridiagonal
    w = eigvalsh_tridiagonal(d, e)
    return float(w[0]), float(w[-1])
