# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 t_lib.py    依赖：numpy, scipy
import numpy as np, scipy.sparse as sp, time
from lib import *
# 1) A^{-1} check against dense A (tabular method) with inbreeding
sire, dam, sex, gen = gen_ped(6, 40, 3, 15, seed=1)
n = len(sire)
A = np.zeros((n, n))
for i in range(n):
    s, d = sire[i], dam[i]
    for j in range(i):
        A[i, j] = A[j, i] = 0.5 * ((A[j, s - 1] if s else 0) + (A[j, d - 1] if d else 0))
    A[i, i] = 1 + (0.5 * A[s - 1, d - 1] if (s and d) else 0)
F, dd = inbreeding_ml(sire, dam)
print('max |F_ML - (a_ii-1)| =', np.abs(F - (np.diag(A) - 1)).max(), ' mean F', F.mean())
Ai = build_ainv(sire, dam, F).toarray()
print('||A^-1 - inv(A)|| max =', np.abs(Ai - np.linalg.inv(A)).max())
# 2) symbolic chol vs dense and vs splu
rng = np.random.default_rng(0)
C, b, info = build_mme(sire, dam, sex, gen, h2=0.25, rec_gens=3, rec_per_hy=10)
N = C.shape[0]
Ld = np.linalg.cholesky(C.toarray())
print('N', N, 'nnz dense chol (|l|>1e-14)', int((np.abs(Ld) > 1e-13).sum()))
nz, fl, cc, par = symbolic_chol(C)
print('symbolic nnz(L)', nz, 'flops', fl)
for spec in ['NATURAL', 'COLAMD', 'MMD_AT_PLUS_A']:
    lu, t = lu_symmetric(C, spec)
    print(spec, 'lu.L.nnz', lu.L.nnz, 'lu.U.nnz', lu.U.nnz, 'perm_c[:8]', lu.perm_c[:8], 'perm_r[:8]', lu.perm_r[:8])
    if spec != 'NATURAL':
        pc = lu.perm_c
        for name, perm in [('pc', pc), ('argsort(pc)', np.argsort(pc))]:
            nz2, fl2, cc2, _ = symbolic_chol(C, perm)
            print('   symbolic with', name, nz2)
# 3) check the cut where LU is wrt diag pivoting: does lu reproduce C?
lu, t = lu_symmetric(C, 'COLAMD')
Cd = C.toarray()
Pr = np.zeros((N, N)); Pr[lu.perm_r, np.arange(N)] = 1
Pc = np.zeros((N, N)); Pc[np.arange(N), lu.perm_c] = 1
print('||Pr C Pc - LU||', np.abs(Pr @ Cd @ Pc - (lu.L @ lu.U).toarray()).max())
