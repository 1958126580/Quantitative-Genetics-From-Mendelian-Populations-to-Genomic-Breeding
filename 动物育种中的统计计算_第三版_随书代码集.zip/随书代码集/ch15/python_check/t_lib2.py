# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 15 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 t_lib2.py    依赖：numpy, scipy
import numpy as np, scipy.sparse as sp
from lib import *
sire, dam, sex, gen = gen_ped(6, 40, 3, 15, seed=1)
C, b, info = build_mme(sire, dam, sex, gen, h2=0.25, rec_gens=3, rec_per_hy=10)
N = C.shape[0]
Cd = C.toarray()
for spec in ['COLAMD', 'MMD_AT_PLUS_A']:
    lu, t = lu_symmetric(C, spec)
    perm = np.argsort(lu.perm_c)
    Cp = Cd[np.ix_(perm, perm)]
    Ld = np.linalg.cholesky(Cp)
    print(spec, 'lu nnz', lu.L.nnz, 'dense chol nnz(>1e-13)', int((np.abs(Ld) > 1e-13).sum()), 'exact zeros count', int((np.abs(Ld) == 0).sum()), 'symbolic', symbolic_chol(C, perm)[0])
    # structural nonzero but numerically tiny
    nz, fl, cc, par = symbolic_chol(C, perm)
    low = np.tril(np.abs(Ld) > 1e-13)
    print('   lower nnz numeric', low.sum(), ' columns counts match?', np.array_equal(low.sum(axis=0), cc))
    # how small are the 'zeros'
    sm = np.abs(Ld)[np.tril_indices(N)]
    print('   smallest 5 abs L (nonzero-structure) ', np.sort(sm[sm>0])[:5])
