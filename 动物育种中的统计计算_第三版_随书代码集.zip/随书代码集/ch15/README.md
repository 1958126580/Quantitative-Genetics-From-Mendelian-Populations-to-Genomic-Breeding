# 第十五章　大规模混合模型方程组的求解 —— 配套代码

**所属**：第三篇　线性混合模型的理论与计算　　**对应正文**：第十五章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch15.ipynb` | IJulia 笔记本：7 个代码单元，约 252 行 Julia 代码，穿插与正文对应的说明 |
| `ch15.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 11 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　构造测试问题
- 2　PCG 求解器（正文式 15.4）
  - 2.1 与定常迭代法的对照
- 3　On-the-fly 矩阵乘（正文式 15.5）
- 4　PEV 的三种算法（正文 §15.2.4、§15.4）
- 5　育种专用停机准则（正文式 15.7）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 15
```

或在 Jupyter 中打开 `ch15/ch15.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
