# 本脚本由 tools/nb2jl.py 从同目录的 ch15.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 15

# %% [markdown]
# # 第十五章　大规模混合模型方程组的求解 —— 配套代码
#
# **本笔记本给出一个可用于生产的 PCG 求解器**，包含：预处理、
# on-the-fly 矩阵乘（不存储系数矩阵）、精确 PEV 与 Monte Carlo PEV、育种专用停机准则。

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions, BenchmarkTools
rng = Xoshiro(20260918)

# ── 全书通用工具（第九章）────────────────────────────────────────────
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        b = inv(delta)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

function random_pedigree(n::Int; nbase::Int=max(10,n÷50), rng=Random.default_rng())
    sire=zeros(Int,n); dam=zeros(Int,n)
    for i in nbase+1:n; sire[i]=rand(rng,1:i-1); dam[i]=rand(rng,1:i-1); end
    return sire, dam
end

# %% [markdown]
# ## 1　构造测试问题

# %%
function make_mme(nind::Int; nherd=200, h2=0.25, rng=Random.default_rng())
    sire, dam = random_pedigree(nind; rng=rng)
    F  = diag(build_A(sire, dam)) .- 1
    Ai = build_Ainv(sire, dam, F)
    recs = collect((nind÷20+1):nind)
    nr = length(recs)
    hd = rand(rng, 1:nherd, nr)
    X = sparse(1:nr, hd, ones(nr), nr, nherd)
    Z = sparse(1:nr, recs, ones(nr), nr, nind)
    y = 10 .+ randn(rng, nr).*3
    lam = (1-h2)/h2
    C = [X'X  X'Z; Z'X  Z'Z + lam*Ai]
    b = vcat(Vector(X'y), Vector(Z'y))
    return C, b, (sire=sire, dam=dam, F=F, Ai=Ai, X=X, Z=Z, y=y, lam=lam, nherd=nherd)
end

C, b, D = make_mme(3000; rng=Xoshiro(51))
@printf("MME 阶数 N = %d ,  非零元 = %d  (稀疏度 %.4f%%)\n",
        size(C,1), nnz(C), 100*nnz(C)/length(C))
@printf("条件数估计 kappa = %.2e\n", cond(Matrix(C)))

# %% [markdown]
# ## 2　PCG 求解器（正文式 15.4）
#
# **实现要点**：工作向量全部预分配，迭代中零分配；每步只需一次矩阵—向量乘。

# %%
"""
    pcg(A, b; M, tol, maxiter, x0) -> (x, iters, resnorms)

预处理共轭梯度法（式 15.4）。`M` 为预处理算子（支持 `M \ r`）。
"""
function pcg(A, b::Vector{Float64}; M = I, tol=1e-10, maxiter=20_000, x0=nothing)
    n = length(b)
    x  = x0 === nothing ? zeros(n) : copy(x0)
    r  = b - A*x
    z  = M === I ? copy(r) : M \ r
    p  = copy(z)
    Ap = similar(b)
    rz = dot(r, z); nb = norm(b)
    res = Float64[norm(r)/nb]
    k = 0
    for outer k in 1:maxiter
        mul!(Ap, A, p)
        alpha = rz / dot(p, Ap)
        @. x += alpha * p
        @. r -= alpha * Ap
        rn = norm(r)/nb
        push!(res, rn)
        rn < tol && break
        z = M === I ? r : M \ r
        rz_new = dot(r, z)
        beta = rz_new / rz
        @. p = z + beta * p
        rz = rz_new
    end
    return x, k, res
end

Mdiag = Diagonal(diag(C))
x_direct = Symmetric(C) \ b

println(rpad("预处理", 22), rpad("迭代次数", 12), rpad("相对残差", 14), "解的相对误差")
println("-"^64)
for (nm, Mp) in (("无（普通 CG）", I), ("对角 (Jacobi)", Mdiag))
    x, it, res = pcg(C, b; M=Mp, tol=1e-10)
    @printf("%-22s%-12d%-14.3e%.3e\n", nm, it, res[end], norm(x-x_direct)/norm(x_direct))
end
println("\n=> CG 的收敛依赖 sqrt(kappa) 而非 kappa（式 15.2）。")

# %% [markdown]
# ### 2.1 与定常迭代法的对照

# %%
function jacobi_solve(A, b; omega=1.0, tol=1e-8, maxiter=300_000)
    x = zeros(length(b)); d = diag(A); nb = norm(b); k = 0
    for outer k in 1:maxiter
        r = b - A*x
        norm(r)/nb < tol && break
        @. x += omega * r / d
    end
    return x, k
end

xj, kj = jacobi_solve(C, b; tol=1e-8)
xp, kp, _ = pcg(C, b; M=Mdiag, tol=1e-8)
@printf("Jacobi       : %7d 次迭代\n", kj)
@printf("PCG（对角）  : %7d 次迭代   （快 %.0f 倍）\n", kp, kj/max(kp,1))
@printf("两者解的相对差 = %.3e\n", norm(xj-xp)/norm(xp))

# %% [markdown]
# ## 3　On-the-fly 矩阵乘（正文式 15.5）
#
# **不存储系数矩阵**：每次从数据与系谱重新计算 $\mathbf{Ap}$，存储降为 $O(N)$。

# %%
"""矩阵无关的 MME 算子：只存数据与系谱，按需计算 C*p（式 15.5）。"""
struct MMEOperator
    X::SparseMatrixCSC{Float64,Int}
    Z::SparseMatrixCSC{Float64,Int}
    sire::Vector{Int}
    dam::Vector{Int}
    F::Vector{Float64}
    lam::Float64
    nf::Int
    nu::Int
end
Base.size(op::MMEOperator) = (op.nf+op.nu, op.nf+op.nu)
Base.size(op::MMEOperator, i::Int) = size(op)[i]
Base.eltype(::MMEOperator) = Float64

"""A^-1 * p，用 Henderson 规则逐个体计算，不存储 A^-1。"""
function ainv_mul(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64}, p::AbstractVector)
    n = length(sire); out = zeros(n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        bq = inv(delta)
        qp = 0.0
        for a in 1:3
            pos[a] > 0 && (qp += q[a]*p[pos[a]])
        end
        for a in 1:3
            pos[a] > 0 && (out[pos[a]] += q[a]*bq*qp)
        end
    end
    return out
end

function LinearAlgebra.mul!(y::AbstractVector, op::MMEOperator, p::AbstractVector)
    pb = @view p[1:op.nf]; pu = @view p[op.nf+1:end]
    t  = op.X*pb .+ op.Z*pu
    y[1:op.nf]     .= op.X' * t
    y[op.nf+1:end] .= op.Z' * t .+ op.lam .* ainv_mul(op.sire, op.dam, op.F, pu)
    return y
end
Base.:*(op::MMEOperator, p::AbstractVector) = mul!(similar(p), op, p)

op = MMEOperator(D.X, D.Z, D.sire, D.dam, D.F, D.lam, D.nherd, length(D.sire))
pv = randn(Xoshiro(60), size(C,1))
@printf("【对照验证】norm(op*p - C*p)/norm(C*p) = %.3e\n", norm(op*pv - C*pv)/norm(C*pv))

x_of, k_of, _ = pcg(op, b; M=Mdiag, tol=1e-10)
@printf("On-the-fly PCG : %d 次迭代，解的相对误差 %.3e\n", k_of, norm(x_of-x_direct)/norm(x_direct))
@printf("存储对比：稀疏矩阵 %.2f MiB  vs  算子 %.2f MiB\n",
        (nnz(C)*12+size(C,2)*8)/2^20,
        (nnz(D.X)*12+nnz(D.Z)*12+3*length(D.sire)*8)/2^20)

# %% [markdown]
# ## 4　PEV 的三种算法（正文 §15.2.4、§15.4）

# %%
s2e = 1.0; s2a = s2e/D.lam; n = length(D.sire)

# 方法一：精确
Cinv = inv(Matrix(C))
PEV_exact = diag(Cinv)[D.nherd+1:end] .* s2e

# 方法二：Monte Carlo（正文 §15.4.1）
"""
    mc_pev(Cmat, D, s2a, s2e; S)

Monte Carlo PEV：模拟 S 组「真值 + 表型」，用相同的 MME 求解，取预测误差的方差。
相对标准误约为 sqrt(2/S)。
"""
function mc_pev(Cmat, D, s2a, s2e; S::Int=200)
    n = length(D.sire); nr = length(D.y)
    Ls = cholesky(Symmetric(build_A(D.sire, D.dam) + 1e-10I)).L
    Cf = cholesky(Symmetric(Matrix(Cmat)))
    acc = zeros(n)
    for s in 1:S
        rr = Xoshiro(hash((909, s)))
        u_s = Ls * randn(rr, n) .* sqrt(s2a)
        e_s = randn(rr, nr) .* sqrt(s2e)
        y_s = D.X*ones(D.nherd) .+ D.Z*u_s .+ e_s
        b_s = vcat(Vector(D.X'y_s), Vector(D.Z'y_s))
        sol_s = Cf \ b_s
        acc .+= (sol_s[D.nherd+1:end] .- u_s).^2
    end
    return acc ./ S
end
PEV_mc = mc_pev(C, D, s2a, s2e; S=200)

# 方法三：有效记录数近似（正文 §15.4.2 的简化版）
function pev_effective_records(D, s2a, s2e)
    n = length(D.sire); lam = D.lam
    Zt = sparse(D.Z')
    cnt = [Zt.colptr[i+1] - Zt.colptr[i] for i in 1:n]
    neff = Float64.(cnt)
    for i in 1:n
        s, d = D.sire[i], D.dam[i]
        s > 0 && (neff[i] += cnt[s]/3)
        d > 0 && (neff[i] += cnt[d]/3)
    end
    R2 = neff ./ (neff .+ lam)
    return (1 .- R2) .* s2a
end
PEV_er = pev_effective_records(D, s2a, s2e)

println(rpad("方法", 24), rpad("与精确值的相关", 18), rpad("平均相对偏差", 16), "代价")
println("-"^78)
@printf("%-24s%-18s%-16s%s\n", "精确（求逆）", "1.0000", "0", "O(N^3) 或稀疏选择求逆")
@printf("%-24s%-18.4f%-16.1f%s\n", "Monte Carlo (S=200)",
        cor(PEV_mc, PEV_exact), 100*mean(abs.(PEV_mc .- PEV_exact)./PEV_exact), "200 次求解")
@printf("%-24s%-18.4f%-16.1f%s\n", "有效记录数（简化）",
        cor(PEV_er, PEV_exact), 100*mean(abs.(PEV_er .- PEV_exact)./PEV_exact), "O(n)")
@printf("\nMC 法的理论相对标准误 = sqrt(2/S) = %.1f%%\n", 100*sqrt(2/200))

# %% [markdown]
# ## 5　育种专用停机准则（正文式 15.7）

# %%
"""以「EBV 变化相对于其标准误」为停机准则（式 15.7）的 PCG。"""
function pcg_breeding(A, b::Vector{Float64}, sd_u::Vector{Float64}, nf::Int;
                      tol_ebv=0.01, tol_res=1e-6, maxiter=20_000, M=I)
    n = length(b); x = zeros(n); xold = similar(x)
    r = b - A*x; z = M === I ? copy(r) : M \ r; p = copy(z)
    Ap = similar(b); rz = dot(r,z); nb = norm(b); k = 0
    for outer k in 1:maxiter
        copyto!(xold, x)
        mul!(Ap, A, p)
        alpha = rz/dot(p,Ap); @. x += alpha*p; @. r -= alpha*Ap
        del = maximum(abs.(x[nf+1:end] .- xold[nf+1:end]) ./ sd_u)
        (del < tol_ebv && norm(r)/nb < tol_res) && break
        z = M === I ? r : M \ r
        rzn = dot(r,z); beta = rzn/rz; @. p = z + beta*p; rz = rzn
    end
    return x, k
end

sd_u = sqrt.(PEV_exact)
xb, kb = pcg_breeding(C, b, sd_u, D.nherd; tol_ebv=0.01, M=Mdiag)
xs, ks, _ = pcg(C, b; M=Mdiag, tol=1e-10)
@printf("育种准则（dEBV < 0.01 SE）: %5d 次迭代\n", kb)
@printf("严格残差准则（1e-10）      : %5d 次迭代\n", ks)
@printf("两者 EBV 的最大差 / SE     = %.4f\n",
        maximum(abs.(xb[D.nherd+1:end] .- xs[D.nherd+1:end]) ./ sd_u))
println("\n=> 育种准则直接对应「结果是否已足够稳定以支持决策」。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **PCG 求解器**：工作向量预分配、迭代中零分配、每步一次矩阵—向量乘。
# 2. **CG 的收敛依赖 $\sqrt\kappa$** —— 相对 Jacobi 的加速随 $\kappa$ 增大而扩大。
# 3. **On-the-fly 算子**与显式稀疏矩阵结果完全相同，而存储大幅降低；$\mathbf A^{-1}\mathbf p$ 只需系谱。
# 4. **PEV 的三种算法**：精确、Monte Carlo（$\sqrt{2/S}$ 精度）、有效记录数（$O(n)$）。
# 5. **育种专用停机准则**通常可提前停止而不影响决策。
