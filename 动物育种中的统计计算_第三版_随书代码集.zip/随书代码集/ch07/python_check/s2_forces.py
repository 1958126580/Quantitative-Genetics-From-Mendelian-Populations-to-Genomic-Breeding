# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 7 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_forces.py    依赖：numpy
"""Four forces: selection recursions, mutation-selection balance, migration, drift."""
import numpy as np

print('================ A. SELECTION ================')


def step(q, w11, w12, w22):
    p = 1 - q
    wbar = p*p*w11 + 2*p*q*w12 + q*q*w22
    qn = (q*q*w22 + p*q*w12)/wbar
    return qn, wbar


def traj(q0, w11, w12, w22, T):
    q = q0
    out = [q]
    for _ in range(T):
        q, _ = step(q, w11, w12, w22)
        out.append(q)
    return np.array(out)


s = 0.1
cases = {'h=0   (a2 完全隐性)': (1.0, 1.0, 1-s),
         'h=0.5 (加性)': (1.0, 1-s/2, 1-s),
         'h=1   (a2 完全显性)': (1.0, 1-s, 1-s),
         'h=2   (超显性 s1=s2=0.1)': (1-s, 1.0, 1-s)}
gens = [0, 5, 10, 20, 50, 100, 200, 500]
for q0 in (0.50, 0.05):
    print('--- q0 = %.2f , s = %.2f ---' % (q0, s))
    print('%-26s' % 'model' + ''.join('%10d' % g for g in gens))
    for name, (a, b, c) in cases.items():
        tr = traj(q0, a, b, c, max(gens))
        print('%-26s' % name + ''.join('%10.6f' % tr[g] for g in gens))

# overdominance equilibrium
s1, s2 = 0.20, 0.05
phat = s2/(s1+s2)
print('overdominance w11=1-%.2f, w12=1, w22=1-%.2f -> p_hat = %.6f, q_hat = %.6f'
      % (s1, s2, phat, 1-phat))
print('check by iteration from q0=0.05 and q0=0.95:')
for q0 in (0.05, 0.95):
    tr = traj(q0, 1-s1, 1.0, 1-s2, 400)
    print('   q0=%.2f -> q_400 = %.8f' % (q0, tr[-1]))
# mean fitness at equilibrium
p = phat; q = 1-p
print('   wbar at equilibrium = %.6f ; wbar at q=0 = %.4f ; at q=1 = %.4f'
      % (p*p*(1-s1) + 2*p*q + q*q*(1-s2), 1-s1, 1-s2))

# generations to reduce q for recessive lethal
print('--- 隐性致死 s=1 ---')
for q0, qt in [(0.05, 0.005), (0.01, 0.001)]:
    t_approx = 1/qt - 1/q0
    q = q0
    t = 0
    while q > qt:
        q, _ = step(q, 1.0, 1.0, 0.0)
        t += 1
    print('q0=%.3f -> qt=%.4f : 近似式 t=%.1f , 精确迭代 t=%d' % (q0, qt, t_approx, t))

print()
print('================ B. MUTATION-SELECTION BALANCE ================')
mu = 1e-5
print('%8s %10s %14s %14s %14s %12s' % ('h', 's', 'q_hat(sqrt)', 'q_hat(mu/hs)', 'q_hat(数值解)', 'load L'))


def qhat_num(mu, h, s):
    """solve mu*(1-q) = s*q*(1-q)*(h*(1-q)+ (1-h)*q)/wbar  -> iterate recursion"""
    q = 1e-4
    for _ in range(2000000):
        p = 1 - q
        w11, w12, w22 = 1.0, 1 - h*s, 1 - s
        wbar = p*p*w11 + 2*p*q*w12 + q*q*w22
        qsel = (q*q*w22 + p*q*w12)/wbar
        qn = qsel + mu*(1 - qsel)
        if abs(qn - q) < 1e-16:
            q = qn
            break
        q = qn
    return q


for h, s in [(0.0, 1.0), (0.0, 0.1), (0.01, 1.0), (0.02, 1.0), (0.05, 0.1), (0.2, 0.1)]:
    qa = np.sqrt(mu/s)
    qb = mu/(h*s) if h > 0 else np.inf
    qn = qhat_num(mu, h, s)
    p = 1-qn
    L = 1 - (p*p*1 + 2*p*qn*(1-h*s) + qn*qn*(1-s))
    print('%8.2f %10.2f %14.6e %14.6e %14.6e %12.3e' % (h, s, qa, qb, qn, L))
print('Haldane 载荷原理: 完全隐性 L = mu = %.3e ; 有杂合表达 L -> 2mu = %.3e' % (mu, 2*mu))

print()
print('================ C. MIGRATION ================')
m = 0.05
pM = 0.80
p = 0.20
print('m=%.2f, pM=%.2f, p0=%.2f' % (m, pM, p))
print('%6s %12s %12s' % ('t', 'p_t', '(1-m)^t*(p0-pM)+pM'))
for t in range(0, 61):
    if t in (0, 1, 2, 5, 10, 20, 30, 45, 60):
        print('%6d %12.8f %12.8f' % (t, p, (1-m)**t*(0.20-pM)+pM))
    p = (1-m)*p + m*pM
# half-life
import math
print('半衰期 t_1/2 = ln(0.5)/ln(1-m) = %.4f 代' % (math.log(0.5)/math.log(1-m)))

print('--- 岛屿模型 F_ST = 1/(1+4*Ne*m) ---')
print('%10s %10s %12s %12s' % ('Ne', 'm', 'Ne*m', 'F_ST'))
for Ne, mm in [(100, 0.01), (100, 0.001), (1000, 0.001), (100, 0.0025), (50, 0.02), (500, 0.002)]:
    print('%10d %10.4f %12.3f %12.6f' % (Ne, mm, Ne*mm, 1/(1+4*Ne*mm)))
print('一代一个个体 (Ne*m = 1): F_ST = %.4f' % (1/(1+4*1.0)))
for Nm in (0.25, 0.5, 1.0, 2.0, 5.0, 10.0):
    print('   Ne*m=%5.2f -> F_ST=%.4f' % (Nm, 1/(1+4*Nm)))

print()
print('================ D. DRIFT ================')
rng = np.random.default_rng(20250923)
N = 50
q0 = 0.30
R = 400000
k = rng.binomial(2*N, q0, size=R)
q1 = k/(2.0*N)
print('N=%d, q0=%.2f, R=%d' % (N, q0, R))
print('E(dq)  模拟 = %+.6f   理论 = 0' % (q1 - q0).mean())
print('Var(dq) 模拟 = %.8f   理论 pq/(2N) = %.8f'
      % ((q1 - q0).var(ddof=1), q0*(1-q0)/(2*N)))

# heterozygosity decay
T = 60
N2 = 25
R2 = 200000
q = np.full(R2, 0.5)
Hs = []
for t in range(T+1):
    Hs.append((2*q*(1-q)).mean())
    q = rng.binomial(2*N2, q)/(2.0*N2)
Hs = np.array(Hs)
print('杂合度衰减 N=%d, H0=0.5:' % N2)
print('%6s %14s %14s' % ('t', '模拟 H_t', '理论 H0(1-1/2N)^t'))
for t in (0, 5, 10, 20, 40, 60):
    print('%6d %14.6f %14.6f' % (t, Hs[t], 0.5*(1-1/(2*N2))**t))

# fixation probability & times
def absorb(N, p0, R, rng, maxgen=100000):
    q = np.full(R, p0)
    alive = np.ones(R, bool)
    tfix = np.zeros(R)
    fixed = np.zeros(R, bool)
    t = 0
    while alive.any() and t < maxgen:
        t += 1
        k = rng.binomial(2*N, q[alive])
        q[alive] = k/(2.0*N)
        done = alive & ((q == 0) | (q == 1))
        tfix[done] = t
        fixed[done] = q[done] == 1
        alive = alive & ~done
    return fixed, tfix


for (N3, p0, R3) in [(100, 0.20, 40000)]:
    fixed, tt = absorb(N3, p0, R3, rng)
    pf = fixed.mean()
    se = np.sqrt(pf*(1-pf)/R3)
    tf = tt[fixed].mean()
    tl = tt[~fixed].mean()
    ta = tt.mean()
    print('N=%d, p0=%.2f, R=%d' % (N3, p0, R3))
    print('  固定概率 模拟 = %.5f (se %.5f)  理论 = %.5f' % (pf, se, p0))
    print('  条件固定时间 模拟 = %.2f  扩散理论 = %.2f'
          % (tf, -4*N3*(1-p0)/p0*np.log(1-p0)))
    print('  条件丢失时间 模拟 = %.2f  扩散理论 = %.2f'
          % (tl, -4*N3*p0/(1-p0)*np.log(p0)))
    print('  平均吸收时间 模拟 = %.2f  扩散理论 = %.2f'
          % (ta, -4*N3*(p0*np.log(p0)+(1-p0)*np.log(1-p0))))
# new mutation
N4 = 100
print('新突变 p0=1/(2N)=%.4f, N=%d : 扩散近似 条件固定时间 ~ 4N = %d 代'
      % (1/(2*N4), N4, 4*N4))
