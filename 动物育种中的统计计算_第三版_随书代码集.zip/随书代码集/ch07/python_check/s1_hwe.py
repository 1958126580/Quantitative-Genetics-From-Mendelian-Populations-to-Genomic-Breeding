# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 7 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_hwe.py    依赖：numpy, scipy
"""HWE: chi2 / exact / LRT --- exact enumeration of type-I error and power."""
import numpy as np
from scipy.stats import chi2 as chi2d
from scipy.special import gammaln

LF = None
def setup(nmax):
    global LF
    LF = gammaln(np.arange(0, 2*nmax+3) + 1.0)

# ---------- exact conditional test (Haldane 1954 / Guo & Thompson 1992) ----------
_cache = {}
def exact_pvals(n, m):
    """dict h -> two-sided exact p-value, conditional on minor allele count m."""
    key = (n, m)
    if key in _cache: return _cache[key]
    hs = np.arange(m % 2, min(m, 2*n-m)+1, 2)
    nAA = (2*n - m - hs)//2
    naa = (m - hs)//2
    logp = hs*np.log(2.0) + LF[n] - LF[nAA] - LF[hs] - LF[naa] + LF[m] + LF[2*n-m] - LF[2*n]
    p = np.exp(logp - logp.max()); p = p/p.sum()
    order = np.argsort(p)
    ps = p[order]
    cum = np.cumsum(ps)
    idx = np.searchsorted(ps, p*(1+1e-7), side='right')
    pv = np.minimum(cum[idx-1], 1.0)
    d = dict(zip(hs.tolist(), pv.tolist()))
    _cache[key] = d
    return d

def stats_grid(n, nAA, nAa, naa):
    N = n
    phat = (2.0*nAA + nAa)/(2.0*N); qhat = 1.0 - phat
    EAA = N*phat**2; EAa = 2*N*phat*qhat; Eaa = N*qhat**2
    seg = (nAa + np.minimum(nAA, naa)) > 0
    X2 = np.where(seg, (nAA-EAA)**2/np.where(EAA > 0, EAA, 1) +
                        (nAa-EAa)**2/np.where(EAa > 0, EAa, 1) +
                        (naa-Eaa)**2/np.where(Eaa > 0, Eaa, 1), 0.0)
    def term(O, E):
        return np.where(O > 0, O*np.log(np.where(O > 0, O, 1)/np.where(E > 0, E, 1)), 0.0)
    G2 = np.where(seg, 2*(term(nAA, EAA)+term(nAa, EAa)+term(naa, Eaa)), 0.0)
    pchi = np.where(seg, chi2d.sf(X2, 1), 1.0)
    plrt = np.where(seg, chi2d.sf(G2, 1), 1.0)
    return pchi, plrt

def rates(n, q, F, alpha, logcut=-50.0):
    p = 1.0 - q
    P = np.array([p*p + F*p*q, 2*p*q*(1-F), q*q + F*p*q])
    P = np.clip(P, 1e-300, 1)
    iAA, iAa = np.meshgrid(np.arange(n+1), np.arange(n+1), indexing='ij')
    keep = (iAA + iAa) <= n
    nAA = iAA[keep]; nAa = iAa[keep]; naa = n - nAA - nAa
    lp = (LF[n] - LF[nAA] - LF[nAa] - LF[naa]
          + nAA*np.log(P[0]) + nAa*np.log(P[1]) + naa*np.log(P[2]))
    sel = lp > logcut
    nAA, nAa, naa, lp = nAA[sel], nAa[sel], naa[sel], lp[sel]
    w = np.exp(lp); tot = w.sum()
    pchi, plrt = stats_grid(n, nAA, nAa, naa)
    m = 2*naa + nAa
    pex = np.empty(len(m))
    for j, (mm, hh) in enumerate(zip(m.tolist(), nAa.tolist())):
        pex[j] = 1.0 if (mm == 0 or mm == 2*n) else exact_pvals(n, mm)[hh]
    return {'chi2': w[pchi <= alpha].sum()/tot,
            'lrt': w[plrt <= alpha].sum()/tot,
            'exact': w[pex <= alpha].sum()/tot,
            'mass': tot}

if __name__ == '__main__':
    n = 1000
    setup(n)
    mafs = [0.5, 0.3, 0.1, 0.05, 0.02, 0.01, 0.005]
    print('n =', n, ' alpha = 0.05   (exact enumeration)')
    print('== TYPE I ERROR (F=0) ==')
    print('%7s %8s %9s %9s %9s' % ('MAF', 'E[m]', 'chi2', 'LRT', 'exact'))
    for q in mafs:
        r = rates(n, q, 0.0, 0.05)
        print('%7.3f %8.1f %9.5f %9.5f %9.5f   mass=%.10f' %
              (q, 2*n*q, r['chi2'], r['lrt'], r['exact'], r['mass']))
    for F in (0.05, 0.10, 0.20):
        print('== POWER (F=%.2f) ==' % F)
        print('%7s %9s %9s %9s' % ('MAF', 'chi2', 'LRT', 'exact'))
        for q in mafs:
            r = rates(n, q, F, 0.05)
            print('%7.3f %9.5f %9.5f %9.5f' % (q, r['chi2'], r['lrt'], r['exact']))
