# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 7 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_ne.py    依赖：numpy
"""Effective population size: three definitions, formulas, and LD-based estimation."""
import numpy as np

rng = np.random.default_rng(7071068)

print('=========== A. 三种 Ne 定义：不等性比群体 ===========')
Nm, Nf = 5, 50
a = 1.0/Nm + 1.0/Nf
NeF1 = 4.0*Nm*Nf/(Nm+Nf)
print('Nm=%d, Nf=%d,  a = 1/Nm+1/Nf = %.6f' % (Nm, Nf, a))
print('一代近交有效含量 Ne_F = 4NmNf/(Nm+Nf) = %.6f' % NeF1)

# exact coancestry recursion  f_{t+1} = 1/4[(a/2)(1+f_{t-1}) + (4-a) f_t]
f = [0.0, 0.0]          # f_{-1}, f_0
for t in range(400):
    fn = 0.25*((a/2)*(1+f[-2]) + (4-a)*f[-1])
    f.append(fn)
f = np.array(f)
F = f[:-1]              # F_t = f_{t-1}
dF = (f[1:] - f[:-1])/(1 - f[:-1])
print('前几代:  f_1=%.8f  f_2=%.8f  f_3=%.8f' % (f[2], f[3], f[4]))
print('第一代 dF = %.8f -> 1/(2dF) = %.6f' % (f[2], 1/(2*f[2])))
g = 1 - f
lam_emp = g[-1]/g[-2]
lam = (( (1-a/4) + np.sqrt((1-a/4)**2 + 4*(a/8)) )/2)
print('渐近比 lambda 模拟递推 = %.10f ; 特征方程根 = %.10f' % (lam_emp, lam))
print('特征值(渐近) Ne = 1/(2(1-lambda)) = %.6f' % (1/(2*(1-lam))))
print('   相对差异 = %.3f%%' % (100*(1/(2*(1-lam)) - NeF1)/NeF1))

# variance Ne by simulation of the same structure
def sim_varne(Nm, Nf, p0, R, rng):
    """one generation: Nm sires + Nf dams -> Nm sires + Nf dams; p = (p_m+p_f)/2"""
    # start at HWE, unrelated
    sires = rng.binomial(1, p0, size=(R, Nm, 2))
    dams = rng.binomial(1, p0, size=(R, Nf, 2))
    pm = sires.mean(axis=(1, 2)); pf = dams.mean(axis=(1, 2))
    p_t = (pm+pf)/2
    # produce offspring
    def make(n):
        si = rng.integers(0, Nm, size=(R, n)); sa = rng.integers(0, 2, size=(R, n))
        di = rng.integers(0, Nf, size=(R, n)); da = rng.integers(0, 2, size=(R, n))
        ri = np.arange(R)[:, None]
        pat = sires[ri, si, sa]
        mat = dams[ri, di, da]
        return np.stack([pat, mat], axis=-1)
    ns = make(Nm); nd = make(Nf)
    pm2 = ns.mean(axis=(1, 2)); pf2 = nd.mean(axis=(1, 2))
    p_t1 = (pm2+pf2)/2
    return p_t, p_t1


p0 = 0.5
R = 300000
p_t, p_t1 = sim_varne(Nm, Nf, p0, R, rng)
d = p_t1 - p_t
# condition on p_t = p0 exactly is impossible; use theory: Var(dp | p_t) = (pm qm + pf qf)/4 * a/4
vd = np.var(d, ddof=1)
# the unconditional variance includes Var over p_t of the conditional mean (=0) -> fine
print('模拟 Var(dp) = %.8f ;  理论 pq*a/8 = %.8f' % (vd, p0*(1-p0)*a/8))
print('方差有效含量 Ne_v = pq/(2Var) = %.4f  (理论 4/a = %.4f)' % (p0*(1-p0)/(2*vd), 4/a))

print()
print('=========== B. 群体大小突变时三种 Ne 的分离 ===========')
N0, N1 = 500, 25
print('N0=%d 个亲本 -> N1=%d 个后代 -> 再回到 N0' % (N0, N1))
print('世代 1: dF = 1/(2*N0) = %.6f -> Ne_F = %.1f ; Var(dp) = pq/(2*N1) -> Ne_v = %.1f'
      % (1/(2*N0), N0, N1))
print('世代 2: dF = 1/(2*N1) = %.6f -> Ne_F = %.1f ; Var(dp) = pq/(2*N0) -> Ne_v = %.1f'
      % (1/(2*N1), N1, N0))
# verify by simulation
R2 = 200000
p0 = 0.5
k1 = rng.binomial(2*N1, p0, size=R2)/(2.0*N1)      # gen1 freq among N1 offspring
k2 = rng.binomial(2*N0, k1)/(2.0*N0)               # gen2 freq among N0 offspring
print('模拟 Var(dp) 世代1 = %.8f (理论 %.8f) -> Ne_v=%.2f'
      % (np.var(k1-p0, ddof=1), p0*(1-p0)/(2*N1), p0*(1-p0)/(2*np.var(k1-p0, ddof=1))))
v2 = np.mean(k1*(1-k1))/(2.0*N0)
print('模拟 E[Var(dp)|gen1] 世代2 = %.8f (理论 E[pq]/(2N0) = %.8f)'
      % (np.mean((k2-k1)**2), v2))
# harmonic mean over a cycle
cyc = [N0, N1]
hm = len(cyc)/sum(1.0/x for x in cyc)
print('调和平均 Ne = %.4f' % hm)
print('长期(特征值) Ne：逐代 1-F 连乘 ->')
onemF = 1.0
for t, Nt in enumerate([N0, N1]*20):
    onemF *= (1 - 1/(2.0*Nt))
lam_cycle = onemF**(1.0/40)
print('   每代平均 (1-1/2Ne) = %.8f -> Ne = %.4f' % (lam_cycle, 1/(2*(1-lam_cycle))))

print()
print('=========== C. Ne 的三个实用公式 ===========')
print('--- C1 不等性比 (Nf=1000) ---')
print('%8s %8s %12s %12s' % ('Nm', 'Nf', 'Ne', 'dF'))
for Nm_ in (5, 10, 20, 50, 100, 250, 500, 1000):
    Ne_ = 4.0*Nm_*1000/(Nm_+1000)
    print('%8d %8d %12.2f %12.6f' % (Nm_, 1000, Ne_, 1/(2*Ne_)))

print('--- C2 家系大小方差 (N=100, kbar=2) ---')
print('%10s %12s %10s' % ('sigma_k^2', 'Ne', 'Ne/N'))
N_ = 100
for sk2 in (0.0, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0):
    Ne_ = (4.0*N_-2)/(sk2+2)
    print('%10.1f %12.4f %10.4f' % (sk2, Ne_, Ne_/N_))

print('--- C2b 模拟验证：等量贡献 vs Poisson ---')
def dF_sim(N, mode, R, rng, T=1):
    """monoecious WF, N parents -> N offspring; measure realized coancestry of offspring
    by gene dropping distinct founder labels."""
    # each parent has 2 distinct alleles labelled 0..2N-1
    lab = np.tile(np.arange(2*N), (R, 1))          # R x 2N  (individual i alleles 2i,2i+1)
    # offspring: choose parents
    if mode == 'poisson':
        pa = rng.integers(0, N, size=(R, N)); pb = rng.integers(0, N, size=(R, N))
    else:  # equal contribution: each parent contributes exactly 2 gametes
        base = np.repeat(np.arange(N), 2)
        pa = np.empty((R, N), int); pb = np.empty((R, N), int)
        for r in range(R):
            perm = rng.permutation(base)
            pa[r] = perm[:N]; pb[r] = perm[N:]
    aa = rng.integers(0, 2, size=(R, N)); bb = rng.integers(0, 2, size=(R, N))
    ri = np.arange(R)[:, None]
    g1 = lab[ri, 2*pa+aa]
    g2 = lab[ri, 2*pb+bb]
    # F of offspring = P(g1 == g2)
    return (g1 == g2).mean()

for mode in ('poisson', 'equal'):
    F1 = dF_sim(60, mode, 4000, rng)
    print('  N=60 %-8s : 实测 dF = %.6f -> Ne = %.2f' % (mode, F1, 1/(2*F1) if F1 > 0 else np.inf))
print('  理论: Poisson (sigma_k^2=2) Ne=(4N-2)/4 = %.2f ; 等量贡献 (sigma_k^2=0) Ne=(4N-2)/2 = %.2f'
      % ((4*60-2)/4.0, (4*60-2)/2.0))

print('--- C3 世代重叠 (Hill 1979 简化式) ---')
print('Ne = 4*Nm*Nf*L/(Nm+Nf)   (每年进入繁殖群体的头数, L 年)')
for (nm, nf, L, name) in [(50, 1500, 5.0, '奶牛(理想)'), (30, 400, 1.5, '猪(理想)'),
                          (3, 1500, 5.0, '奶牛(实际公畜贡献极不均)')]:
    Ne_ = 4.0*nm*nf*L/(nm+nf)
    print('  %-22s Nm=%4d Nf=%5d L=%.1f -> Ne = %8.1f , dF/年 = %.5f'
          % (name, nm, nf, L, Ne_, 1/(2*Ne_*L)))
# back-solve effective sire number
Ne_target, nf, L = 60.0, 1500.0, 5.0
inv = 1.0/Ne_target - 1.0/(4*nf*L)
nm_eff = 1.0/(4*L*inv)
print('  反解：若实测 Ne=%.0f, Nf=%.0f/年, L=%.1f 年 -> 等效公畜数 Nm = %.3f 头/年'
      % (Ne_target, nf, L, nm_eff))

print()
print('=========== D. Sved 公式 E(r^2)=1/(1+4Nc) ===========')
print('--- D1 片段同源递推的精确不动点 ---')
print('%8s %8s %14s %14s %14s' % ('N', 'c', '4Nc', '精确不动点Q', '1/(1+4Nc)'))
for N in (100,):
    for c in (0.0025, 0.005, 0.01, 0.02, 0.05, 0.1, 0.25):
        al = (1-c)**2
        Q = al/(2*N*(1-al)+al)
        print('%8d %8.4f %14.3f %14.6f %14.6f' % (N, c, 4*N*c, Q, 1/(1+4*N*c)))

print('--- D2 片段同源的 Monte Carlo 验证 ---')
def sim_Q(N, c, T, R, rng):
    """2N haplotypes; each carries a 'segment identity' label. Recombinant gametes get a
    fresh label. Q = P(two random haplotypes share a label)."""
    M = 2*N
    lab = np.tile(np.arange(M), (R, 1))
    nxt = np.full(R, M)
    ri = np.arange(R)[:, None]
    for t in range(T):
        par = rng.integers(0, M, size=(R, M))
        new = lab[ri, par]
        rec = rng.random((R, M)) < c
        nrec = rec.sum(axis=1)
        for r in range(R):
            k = nrec[r]
            if k:
                new[r, rec[r]] = np.arange(nxt[r], nxt[r]+k)
                nxt[r] += k
        lab = new
    # Q over pairs
    Qs = []
    for r in range(R):
        u, cnt = np.unique(lab[r], return_counts=True)
        Qs.append((cnt*(cnt-1)).sum()/(M*(M-1)))
    return float(np.mean(Qs))


N = 100
for c in (0.005, 0.01, 0.05, 0.1):
    Qsim = sim_Q(N, c, 1500, 60, rng)
    al = (1-c)**2
    Qth = al/(2*N*(1-al)+al)
    print('  N=%d c=%.3f : 模拟 Q=%.5f ; 精确不动点=%.5f ; 1/(1+4Nc)=%.5f'
          % (N, c, Qsim, Qth, 1/(1+4*N*c)))

print('--- D3 由 r^2 估计 Ne ---')
for (r2, c) in [(0.30, 0.01), (0.10, 0.05), (0.05, 0.10), (0.20, 0.01)]:
    print('  r2=%.2f, c=%.3f -> Ne_hat = (1/r2 - 1)/(4c) = %.1f ; 对应 ~1/(2c)=%.0f 代前'
          % (r2, c, (1/r2-1)/(4*c), 1/(2*c)))
print('--- D4 标记密度 ---')
for (Ne_, r2) in [(100, 0.2), (100, 0.3), (50, 0.3), (10000, 0.3)]:
    c = (1/r2-1)/(4.0*Ne_)
    print('  Ne=%6d 目标 r2=%.2f -> 间距 c=%.6f M = %.4f cM ; 30 M 基因组需 %.0f 个标记'
          % (Ne_, r2, c, c*100, 30.0/c))
