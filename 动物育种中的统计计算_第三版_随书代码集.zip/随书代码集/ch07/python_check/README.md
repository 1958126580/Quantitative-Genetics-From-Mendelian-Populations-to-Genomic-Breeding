# 第 7 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch07/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `s1_hwe.py` | HWE: chi2 / exact / LRT --- exact enumeration of type-I error and power. | numpy, scipy | 12.5 | `outputs/s1_hwe.out` |
| `s2_forces.py` | Four forces: selection recursions, mutation-selection balance, migration, drift. | numpy | 14.7 | `outputs/s2_forces.out` |
| `s3_ne.py` | Effective population size: three definitions, formulas, and LD-based estimation. | numpy | 15.7 | `outputs/s3_ne.out` |
| `s4_inb_ld.py` | Inbreeding (path vs tabular), inbreeding depression, LD measures, LD decay. | numpy, scipy | 7.3 | `outputs/s4_inb_ld.out` |
