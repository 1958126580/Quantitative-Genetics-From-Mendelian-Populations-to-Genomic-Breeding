# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 7 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4_inb_ld.py    依赖：numpy, scipy
"""Inbreeding (path vs tabular), inbreeding depression, LD measures, LD decay."""
import numpy as np
from fractions import Fraction as Fr

print('=========== A. 系谱：通径法 vs 表格法 ===========')
# pedigree (0 = unknown). Order: H,E,F,G,C,D,A,B,X
names = ['H', 'E', 'F', 'G', 'C', 'D', 'A', 'B', 'X']
sire = {'H': None, 'E': 'H', 'F': None, 'G': 'H', 'C': 'E', 'D': 'F',
        'A': 'C', 'B': 'C', 'X': 'A'}
dam = {'H': None, 'E': None, 'F': None, 'G': None, 'C': 'F', 'D': 'G',
       'A': 'D', 'B': 'D', 'X': 'B'}
idx = {n: i for i, n in enumerate(names)}
n = len(names)
A = [[Fr(0) for _ in range(n)] for _ in range(n)]
for i, ni in enumerate(names):
    s = sire[ni]; d = dam[ni]
    si = idx[s] if s else None
    di = idx[d] if d else None
    # off-diagonals with all j < i
    for j in range(i):
        v = Fr(0)
        if si is not None: v += A[j][si]
        if di is not None: v += A[j][di]
        v = v/2
        A[i][j] = v; A[j][i] = v
    A[i][i] = Fr(1) + (A[si][di]/2 if (si is not None and di is not None) else Fr(0))
print('表格法 A 矩阵 (分数):')
hdr = '      ' + ''.join('%10s' % x for x in names)
print(hdr)
for i, ni in enumerate(names):
    print('%6s' % ni + ''.join('%10s' % str(A[i][j]) for j in range(n)))
print()
print('近交系数 F = a_ii - 1 :')
for i, ni in enumerate(names):
    Fi = A[i][i] - 1
    print('   F_%s = %-8s = %.6f' % (ni, str(Fi), float(Fi)))
print()
print('关键元素:')
print('   a_AB = %-8s = %.6f' % (str(A[idx['A']][idx['B']]), float(A[idx['A']][idx['B']])))
print('   f_AB = a_AB/2 = %-8s = %.6f' % (str(A[idx['A']][idx['B']]/2), float(A[idx['A']][idx['B']]/2)))
aAA = A[idx['A']][idx['A']]; aBB = A[idx['B']][idx['B']]
rAB = float(A[idx['A']][idx['B']])/float(aAA*aBB)**0.5
print('   r_AB = a_AB/sqrt(a_AA a_BB) = %.6f  (= 21/37 = %.6f)' % (rAB, 21/37))
print('   F_X  = %-8s = %.6f' % (str(A[idx['X']][idx['X']]-1), float(A[idx['X']][idx['X']]-1)))
print('   f_CD = %-8s' % str(A[idx['C']][idx['D']]/2))

print()
print('通径法核对:')
paths_A = [('C<-F->D', 'F', 3), ('C<-E<-H->G->D', 'H', 5)]
tot = Fr(0)
for nm, anc, L in paths_A:
    Fanc = A[idx[anc]][idx[anc]] - 1
    v = Fr(1, 2**L)*(1+Fanc)
    tot += v
    print('   %-16s 共祖 %s  (1/2)^%d (1+F=%s) = %s' % (nm, anc, L, str(Fanc), str(v)))
print('   F_A(通径) = %s = %.6f' % (str(tot), float(tot)))
paths_X = [('A<-C->B', 'C', 3), ('A<-D->B', 'D', 3),
           ('A<-C<-F->D->B', 'F', 5), ('A<-D<-F->C->B', 'F', 5),
           ('A<-C<-E<-H->G->D->B', 'H', 7), ('A<-D<-G<-H->E->C->B', 'H', 7)]
tot = Fr(0)
for nm, anc, L in paths_X:
    Fanc = A[idx[anc]][idx[anc]] - 1
    v = Fr(1, 2**L)*(1+Fanc)
    tot += v
    print('   %-22s 共祖 %s (1/2)^%d (1+%s) = %s' % (nm, anc, L, str(Fanc), str(v)))
print('   F_X(通径) = %s = %.6f' % (str(tot), float(tot)))

print()
print('相关系数定义的验证 (Monte-Carlo 基因流):')
rng = np.random.default_rng(31415926)
R = 2000000
p = 0.3
# gene drop: founders H,F,E(dam unknown),G(dam unknown) get independent alleles
def drop(R, rng, p):
    al = {}
    for f in ['H', 'F']:
        al[f] = rng.binomial(1, p, size=(R, 2))
    # E: sire H, dam unknown -> one allele from H, one new
    for ch, s, d in [('E', 'H', None), ('G', 'H', None), ('C', 'E', 'F'),
                     ('D', 'F', 'G'), ('A', 'C', 'D'), ('B', 'C', 'D'), ('X', 'A', 'B')]:
        a1 = al[s][np.arange(R), rng.integers(0, 2, R)] if s else rng.binomial(1, p, R)
        a2 = al[d][np.arange(R), rng.integers(0, 2, R)] if d else rng.binomial(1, p, R)
        al[ch] = np.stack([a1, a2], axis=1)
    return al
al = drop(R, rng, p)
for nm in ['A', 'X']:
    g = al[nm]
    Fhat = ((g[:, 0] == g[:, 1]).mean() - (p*p+(1-p)**2))/(1-(p*p+(1-p)**2))
    cor = np.corrcoef(g[:, 0], g[:, 1])[0, 1]
    print('   %s : 由相关系数 r(x1,x2) = %.5f ; 理论 F = %.6f'
          % (nm, cor, float(A[idx[nm]][idx[nm]]-1)))
gA = al['A'].mean(axis=1)*2; gB = al['B'].mean(axis=1)*2
covAB = np.cov(gA, gB)[0, 1]
print('   Cov(基因型计数 A,B)/(2pq) = %.5f ; 理论 a_AB = %.6f'
      % (covAB/(2*p*(1-p)), float(A[idx['A']][idx['B']])))

print()
print('=========== B. 近交衰退 ===========')
print('--- B1 隐性纯合子频率 ---')
print('%8s %10s %14s %14s %10s' % ('q', 'F', 'q^2+Fpq', 'q^2', '倍数'))
for q in (0.01, 0.005, 0.001):
    for F in (0.0, 0.0625, 0.125, 0.25):
        v = q*q + F*q*(1-q)
        print('%8.3f %10.4f %14.8f %14.8f %10.2f' % (q, F, v, q*q, v/(q*q)))
print('--- B2 delta 与致死当量 ---')
print('ln(S_F/S_0) = -B*F, B = 每配子致死当量数')
print('%8s %10s %12s %12s' % ('B', 'F', 'S_F/S_0', '相对衰退 %'))
for B in (0.5, 1.0, 1.5, 3.0):
    for F in (0.0625, 0.125, 0.25):
        S = np.exp(-B*F)
        print('%8.2f %10.4f %12.6f %12.3f' % (B, F, S, 100*(1-S)))
print('--- B3 数量性状：多位点 sum(2 p q d) ---')
rng2 = np.random.default_rng(2718281)
L = 1000
pl = rng2.uniform(0.05, 0.95, L)
d = np.full(L, 0.30)          # 每位点显性偏差（表型标准差单位的 0.30 只是示例前的原始尺度）
B0 = 2*np.sum(pl*(1-pl)*d)
print('L=%d 位点, d_i=%.2f, sum p_i q_i = %.4f -> 每单位 F 的均值下降 2*sum(pqd) = %.4f'
      % (L, 0.30, np.sum(pl*(1-pl)), B0))
print('每 1%% 近交的下降 = %.6f （同一尺度）' % (B0*0.01))
print('近交每代增量 dF=%.4f 时每代下降 = %.6f' % (0.01, B0*0.01))

print()
print('=========== C. D, D\' , r^2 ===========')
def ld(pAB, pAb, paB, pab):
    pA = pAB+pAb; pa = 1-pA; pB = pAB+paB; pb = 1-pB
    D = pAB - pA*pB
    if D > 0:
        Dmax = min(pA*pb, pa*pB)
    elif D < 0:
        Dmax = min(pA*pB, pa*pb)
    else:
        Dmax = 1.0
    Dp = abs(D)/Dmax if Dmax > 0 else float('nan')
    r2 = D*D/(pA*pa*pB*pb)
    return pA, pB, D, Dmax, Dp, r2


print('--- C1 一个 2x2 单倍型表 ---')
counts = np.array([[474, 142], [66, 318]], float)   # rows: A/a ; cols: B/b
tot = counts.sum()
pAB, pAb, paB, pab = counts[0, 0]/tot, counts[0, 1]/tot, counts[1, 0]/tot, counts[1, 1]/tot
pA, pB, D, Dmax, Dp, r2 = ld(pAB, pAb, paB, pab)
print('计数 AB=%d Ab=%d aB=%d ab=%d  N=%d' % (counts[0, 0], counts[0, 1], counts[1, 0], counts[1, 1], tot))
print('p_AB=%.6f p_Ab=%.6f p_aB=%.6f p_ab=%.6f' % (pAB, pAb, paB, pab))
print('p_A=%.6f  p_B=%.6f' % (pA, pB))
print('D = p_AB - p_A p_B = %.8f' % D)
print('D_max = %.8f ; D\' = %.6f' % (Dmax, Dp))
print('r^2 = D^2/(pA pa pB pb) = %.6f ; r = %.6f' % (r2, np.sqrt(r2)))
print('直接相关系数核对 = %.6f' % (np.corrcoef(
    np.repeat([1, 1, 0, 0], counts.flatten().astype(int)),
    np.repeat([1, 0, 1, 0], counts.flatten().astype(int)))[0, 1]))
chi2 = tot*r2
print('chi^2 = N r^2 = %.4f (df=1)' % chi2)

print('--- C2 |D\'|=1 但 r^2 随频率变化 ---')
print("完全 LD（缺失 ab 单倍型）: p_AB=p_B, p_Ab=p_A-p_B, p_aB=0, p_ab=1-p_A")
print('%8s %8s %10s %10s %10s' % ('p_A', 'p_B', 'D', "D'", 'r^2'))
for pA_, pB_ in [(0.5, 0.5), (0.5, 0.4), (0.5, 0.3), (0.5, 0.2), (0.5, 0.1),
                 (0.5, 0.05), (0.9, 0.1), (0.95, 0.05), (0.2, 0.1)]:
    if pB_ > pA_:
        continue
    pAB_ = pB_; pAb_ = pA_-pB_; paB_ = 0.0; pab_ = 1-pA_
    _, _, D_, Dmax_, Dp_, r2_ = ld(pAB_, pAb_, paB_, pab_)
    print('%8.2f %8.2f %10.5f %10.5f %10.5f' % (pA_, pB_, D_, Dp_, r2_))
print('--- C3 相同 r^2、不同 D\' ---')
for pA_, pB_, D_ in [(0.5, 0.5, 0.10), (0.3, 0.3, 0.10), (0.2, 0.8, -0.10)]:
    pAB_ = pA_*pB_ + D_
    pAb_ = pA_ - pAB_; paB_ = pB_ - pAB_; pab_ = 1 - pAB_ - pAb_ - paB_
    _, _, Dd, Dmax_, Dp_, r2_ = ld(pAB_, pAb_, paB_, pab_)
    print('   p_A=%.2f p_B=%.2f D=%+.3f -> D\'=%.4f  r^2=%.4f' % (pA_, pB_, Dd, Dp_, r2_))

print()
print('=========== D. LD 衰减 ===========')
print('D_t = (1-c)^t D_0 ; r^2_t = (1-c)^{2t} r^2_0 （频率不变时）')
print('%8s' % 'c' + ''.join('%11s' % ('t=%d' % t) for t in (1, 5, 10, 20, 50, 100, 500)) + '%12s' % '半衰期')
for c in (0.5, 0.2, 0.1, 0.05, 0.01, 0.001, 0.0):
    row = ''.join('%11.6f' % ((1-c)**t) for t in (1, 5, 10, 20, 50, 100, 500))
    hl = np.log(0.5)/np.log(1-c) if c > 0 else float('inf')
    print('%8.4f' % c + row + '%12.2f' % hl)
print('c=0（无性繁殖 / 同一位点）: (1-c)^t = 1 对任意 t —— D 永不衰减')

print()
print('=========== E. 多等位基因 HWE 与 F 统计量 ===========')
# 4-allele microsatellite example
obs = {(0, 0): 12, (0, 1): 40, (0, 2): 26, (0, 3): 14, (1, 1): 30, (1, 2): 38,
       (1, 3): 20, (2, 2): 18, (2, 3): 16, (3, 3): 6}
N = sum(obs.values())
k = 4
cnt = np.zeros(k)
for (i, j), c in obs.items():
    cnt[i] += c; cnt[j] += c
pf = cnt/(2.0*N)
print('N=%d 个体, k=%d 个等位基因' % (N, k))
print('等位基因频率 = ' + ' '.join('%.6f' % x for x in pf))
Hexp = 1 - np.sum(pf**2)
Hobs = sum(c for (i, j), c in obs.items() if i != j)/float(N)
print('H_obs = %.6f ; H_exp = 1 - sum p^2 = %.6f' % (Hobs, Hexp))
print('F = 1 - H_obs/H_exp = %.6f' % (1-Hobs/Hexp))
# chi2 test
chi = 0.0
for i in range(k):
    for j in range(i, k):
        o = obs.get((i, j), 0)
        e = N*(pf[i]**2 if i == j else 2*pf[i]*pf[j])
        chi += (o-e)**2/e
df = k*(k-1)//2
from scipy.stats import chi2 as chi2d
print('chi^2 = %.4f, df = k(k-1)/2 = %d, p = %.6f' % (chi, df, chi2d.sf(chi, df)))
ncell = k*(k+1)//2
print('基因型类数 = %d, 自由度 = %d - (%d-1) - 1 = %d' % (ncell, ncell, k, ncell-k))
# unbiased Nei
Hexp_u = 2*N/(2.0*N-1)*Hexp
print('Nei 无偏杂合度 = 2N/(2N-1) * H_exp = %.6f' % Hexp_u)
# F_IS / F_ST / F_IT on two subpopulations
print('--- Wahlund / F 统计量 三层分解 ---')
sub = [np.array([0.8, 0.2]), np.array([0.2, 0.8])]
Fis = 0.10
Hi = np.mean([2*s[0]*s[1]*(1-Fis) for s in sub])
Hs = np.mean([2*s[0]*s[1] for s in sub])
pbar = np.mean([s[0] for s in sub])
Ht = 2*pbar*(1-pbar)
print('两亚群 p = 0.8, 0.2 ; 亚群内 F_IS = %.2f' % Fis)
print('H_I=%.6f  H_S=%.6f  H_T=%.6f' % (Hi, Hs, Ht))
print('F_IS = 1-H_I/H_S = %.6f' % (1-Hi/Hs))
print('F_ST = 1-H_S/H_T = %.6f' % (1-Hs/Ht))
print('F_IT = 1-H_I/H_T = %.6f' % (1-Hi/Ht))
print('恒等式 (1-F_IT) = (1-F_IS)(1-F_ST) : %.8f vs %.8f'
      % (1-(1-Hi/Ht), (1-(1-Hi/Hs))*(1-(1-Hs/Ht))))
print('Var(p) = %.6f ; Var(p)/(pbar qbar) = %.6f' % (np.var([s[0] for s in sub]),
                                                     np.var([s[0] for s in sub])/(pbar*(1-pbar))))
