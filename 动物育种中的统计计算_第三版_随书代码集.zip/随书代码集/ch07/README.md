# 第七章　群体遗传学基础 —— 配套代码

**所属**：第二篇　数量遗传学原理　　**对应正文**：第七章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch07.ipynb` | IJulia 笔记本：8 个代码单元，约 181 行 Julia 代码，穿插与正文对应的说明 |
| `ch07.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 4 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　Hardy–Weinberg 平衡与检验
- 2　漂变：Wright–Fisher 模拟与杂合度衰减（正文式 7.18）
- 3　有效群体含量（正文式 7.21、7.22）
- 4　三个概念的严格区分（正文 §7.3.4，第二版勘误 2‑1）
- 5　连锁不平衡
  - 5.1 LD 的衰减（正文式 7.32）与无性繁殖的情形（第二版勘误 2‑2）
  - 5.2 有限群体中的 $E(r^2)$ 与 $N_e$ 估计（正文式 7.33、7.34）
  - 5.3 LD 衰减的模拟验证
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 07
```

或在 Jupyter 中打开 `ch07/ch07.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
