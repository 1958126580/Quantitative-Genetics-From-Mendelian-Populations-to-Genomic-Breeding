# 本脚本由 tools/nb2jl.py 从同目录的 ch07.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 07

# %% [markdown]
# # 第七章　群体遗传学基础 —— 配套代码
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | HWE 与其检验 | §7.1 |
# | 2 | 四种力：选择、突变、迁移、漂变 | §7.2 |
# | 3 | 有效群体含量 | §7.2.5 |
# | 4 | 三个概念的严格区分 | §7.3.4 |
# | 5 | 连锁不平衡：衰减、$E(r^2)$、$N_e$ 估计 | §7.4 |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions
rng = Xoshiro(20260918)

# %% [markdown]
# ## 1　Hardy–Weinberg 平衡与检验

# %%
using SpecialFunctions
lfact(n) = logabsgamma(n + 1)[1]

"""
    hwe_test(n11, n12, n22)

两等位基因位点的 Hardy–Weinberg 检验。返回 (χ², p_chisq, p_exact, F, p)。
精确检验在给定等位基因计数的条件下枚举所有可能的杂合子数。
"""
function hwe_test(n11::Int, n12::Int, n22::Int)
    N  = n11 + n12 + n22
    nA = 2n11 + n12                 # A 等位基因计数
    nB = 2N - nA
    p  = nA / (2N); q = 1 - p
    E  = (N*p^2, N*2p*q, N*q^2)
    O  = (n11, n12, n22)
    χ² = sum((O[k]-E[k])^2/E[k] for k in 1:3 if E[k] > 0)
    pchi = ccdf(Chisq(1), χ²)
    F  = p*q > 0 ? 1 - n12/(2N*p*q) : 0.0

    # 精确检验：P(h | nA, N) ∝ 2^h · N! / [((nA-h)/2)! h! ((nB-h)/2)!]
    hmin = isodd(nA) ? 1 : 0
    hs = [h for h in hmin:2:min(nA, nB)]
    logp = [h*log(2) + lfact(N) - lfact((nA-h)÷2) - lfact(h) - lfact((nB-h)÷2) for h in hs]
    logp .-= maximum(logp)
    pr = exp.(logp); pr ./= sum(pr)
    idx = findfirst(==(n12), hs)
    pexact = idx === nothing ? NaN : sum(pr[pr .<= pr[idx]*(1+1e-12)])
    return (χ²=χ², p_chisq=pchi, p_exact=pexact, F=F, p=p)
end

for (nm, g) in (("符合 HWE",      (250, 500, 250)),
                ("杂合子不足",    (350, 300, 350)),
                ("杂合子过剩",    (150, 700, 150)),
                ("低频等位基因",  (990, 9, 1)))
    r = hwe_test(g...)
    @printf("%-14s p=%.3f  F=%+.4f  χ²=%8.2f  p_chisq=%.2e  p_exact=%.2e\n",
            nm, r.p, r.F, r.χ², r.p_chisq, r.p_exact)
end
println()
println("→ 低频等位基因时卡方近似失效，必须用精确检验（正文 §7.1.3）。")

# %% [markdown]
# ## 2　漂变：Wright–Fisher 模拟与杂合度衰减（正文式 7.18）

# %%
"""Wright–Fisher 漂变模拟。返回 (代数 × 重复) 的频率矩阵。"""
function wright_fisher(p0::Float64, N::Int, T::Int, R::Int; rng=Random.default_rng())
    P = zeros(T+1, R); P[1, :] .= p0
    for r in 1:R, t in 1:T
        P[t+1, r] = rand(rng, Binomial(2N, P[t, r])) / (2N)
    end
    return P
end

N, T, R = 50, 200, 2000
P = wright_fisher(0.5, N, T, R; rng=rng)
H_sim  = [mean(2 .* P[t, :] .* (1 .- P[t, :])) for t in 1:T+1]
H_theo = [2*0.5*0.5 * (1 - 1/(2N))^(t-1) for t in 1:T+1]

println(rpad("代数", 8), rpad("模拟 H", 12), rpad("理论 H", 12), "固定比例")
println("-"^46)
for t in (1, 11, 51, 101, 201)
    fixed = mean((P[t, :] .≈ 0) .| (P[t, :] .≈ 1))
    @printf("%-8d%-12.5f%-12.5f%.3f\n", t-1, H_sim[t], H_theo[t], fixed)
end
@printf("\n模拟与理论的最大相对偏差 = %.3f%%\n",
        100*maximum(abs.(H_sim .- H_theo) ./ H_theo))
@printf("特征时间尺度 2N = %d 代；t=2N 时 H/H₀ = %.3f（理论 e⁻¹ = %.3f）\n",
        2N, H_sim[2N+1]/H_sim[1], exp(-1))

# %% [markdown]
# ## 3　有效群体含量（正文式 7.21、7.22）

# %%
Ne_sex(Nm, Nf)  = 4Nm*Nf/(Nm+Nf)
Ne_var(N, σ²k)  = (4N - 2)/(σ²k + 2)

println("【性别比对 Nₑ 的影响】（正文式 7.21）")
println(rpad("Nm", 8), rpad("Nf", 8), rpad("N总", 8), rpad("Nₑ", 10), "ΔF/代")
println("-"^46)
for (Nm, Nf) in ((500,500), (100,900), (50,950), (10,1000), (5,1000))
    Ne = Ne_sex(Nm, Nf)
    @printf("%-8d%-8d%-8d%-10.1f%.5f\n", Nm, Nf, Nm+Nf, Ne, 1/(2Ne))
end
println("\n→ Nₑ 由较少的那个性别主导。10 公 + 1000 母的群体，Nₑ ≈ 40。")

println("\n【家系大小方差对 Nₑ 的影响】（正文式 7.22）")
N = 500
for σ²k in (0.0, 1.0, 2.0, 4.0, 10.0)
    @printf("  σ²k = %5.1f  →  Nₑ = %7.1f  (Nₑ/N = %.2f)\n", σ²k, Ne_var(N, σ²k), Ne_var(N,σ²k)/N)
end
println("→ 等量贡献（σ²k = 0）使 Nₑ ≈ 2N —— 保种群管理的理论依据。")

# %% [markdown]
# ## 4　三个概念的严格区分（正文 §7.3.4，第二版勘误 2‑1）

# %%
# 三个概念的数值对照：全同胞 A、B，各自 F = 5/32
a_AA = 37/32; a_BB = 37/32; a_AB = 21/32
f_AB = a_AB / 2
r_AB = a_AB / sqrt(a_AA * a_BB)

println("全同胞 A、B（各自 F = 5/32 = 0.15625）：")
@printf("  共祖系数     f_AB = a_AB/2             = %.6f   (= 21/64)\n", f_AB)
@printf("  加性遗传关系 a_AB                       = %.6f   (= 21/32)\n", a_AB)
@printf("  亲缘相关系数 r_AB = a_AB/√(a_AA·a_BB)   = %.6f   (= 21/37)\n", r_AB)
println()
println("作为对照，非近交全同胞：")
@printf("  f = %.4f ， a = %.4f ， r = %.4f   ← 后两者相等，混用不被发现\n", 0.25, 0.5, 0.5)
println()
println("→ 第二版把三者统称「亲缘系数」，并把表中的 r 当作 f（勘误 2-1）。")
println("  本书全书统一：f 为共祖系数、a 为加性遗传关系、r 为亲缘相关系数。")

# %% [markdown]
# ## 5　连锁不平衡
#
# ### 5.1 LD 的衰减（正文式 7.32）与无性繁殖的情形（第二版勘误 2‑2）

# %%
"""LD 的确定性衰减 D_t = (1-c)^t D_0。"""
decay(D0, c, t) = D0 * (1 - c)^t

println(rpad("c", 10), rpad("半衰期(代)", 14), "100 代后剩余比例")
println("-"^46)
for c in (0.5, 0.1, 0.01, 0.001, 0.0)
    hl = c == 0 ? Inf : log(0.5)/log(1-c)
    @printf("%-10.4f%-14s%.4f\n", c, c == 0 ? "∞" : @sprintf("%.1f", hl), decay(1.0, c, 100))
end
println()
println("→ c = 0（无重组，如无性繁殖）时 D 永不衰减：")
println("  **无性繁殖群体表现为强而持久的连锁不平衡，而非连锁平衡。**")
println("  第二版第 9 章此处结论颠倒（勘误 2-2）。")

# %% [markdown]
# ### 5.2 有限群体中的 $E(r^2)$ 与 $N_e$ 估计（正文式 7.33、7.34）

# %%
Er2(Ne, c; n=0) = 1/(1 + 4*Ne*c) + (n > 0 ? 1/n : 0.0)
Ne_from_r2(r2, c; n=0) = (1/(r2 - (n>0 ? 1/n : 0.0)) - 1)/(4c)

println("【E(r²) 随距离与 Nₑ 的变化】")
println(rpad("c (M)", 10), rpad("Nₑ=50", 10), rpad("Nₑ=100", 10), rpad("Nₑ=1000", 10), "Nₑ=10000")
println("-"^52)
for c in (0.0001, 0.001, 0.01, 0.05, 0.1)
    @printf("%-10.4f%-10.3f%-10.3f%-10.3f%.4f\n", c,
            Er2(50,c), Er2(100,c), Er2(1000,c), Er2(10000,c))
end
println()
println("【不同距离反映不同历史时期的 Nₑ】")
for (c, r2) in ((0.01, 0.25), (0.05, 0.08), (0.1, 0.045))
    @printf("  c=%.3f, r²=%.3f  →  Nₑ ≈ %6.0f   （约反映 %.0f 代前）\n",
            c, r2, Ne_from_r2(r2, c), 1/(2c))
end
println()
println("【标记密度的设计】要使平均 r² 达到目标值：")
for (Ne, target) in ((100, 0.2), (100, 0.3), (1000, 0.2), (10000, 0.2))
    c = (1/target - 1)/(4Ne)
    genome_M = 30.0
    @printf("  Nₑ=%-6d 目标 r²=%.1f  →  标记间距 %.4f M = %.2f cM  →  30 M 基因组需 %.0f 个标记\n",
            Ne, target, c, c*100, genome_M/c)
end
println()
println("→ 家畜品种的小 Nₑ 是 50K 芯片即可有效的根本原因（正文 §7.4.4）。")

# %% [markdown]
# ### 5.3 LD 衰减的模拟验证

# %%
"""两位点 Wright–Fisher 模拟，追踪 D 与 r² 的衰减。"""
function ld_drift(N::Int, c::Float64, T::Int, R::Int; rng=Random.default_rng())
    r2 = zeros(T+1, R)
    for rep in 1:R
        # 初始：完全 LD，两种单倍型各占一半
        hap = vcat(fill((1,1), N), fill((0,0), N))   # 2N 个配子
        for t in 0:T
            # 计算当前 r²
            pA = mean(first.(hap)); pB = mean(last.(hap))
            pAB = mean([h[1]*h[2] for h in hap])
            D = pAB - pA*pB
            den = pA*(1-pA)*pB*(1-pB)
            r2[t+1, rep] = den > 1e-12 ? D^2/den : NaN
            t == T && break
            # 产生下一代：随机抽两个配子，以概率 c 重组
            newhap = similar(hap)
            for k in eachindex(newhap)
                h1 = hap[rand(rng, 1:2N)]
                if rand(rng) < c
                    h2 = hap[rand(rng, 1:2N)]
                    newhap[k] = (h1[1], h2[2])
                else
                    newhap[k] = h1
                end
            end
            hap = newhap
        end
    end
    return r2
end

N, c, T, R = 100, 0.02, 60, 300
r2m = ld_drift(N, c, T, R; rng=rng)
println(rpad("代数", 8), rpad("模拟 E(r²)", 14), "理论平衡值 1/(1+4Nₑc)")
println("-"^50)
theo = 1/(1 + 4N*c)
for t in (0, 5, 10, 20, 40, 60)
    v = mean(filter(!isnan, r2m[t+1, :]))
    @printf("%-8d%-14.4f%.4f\n", t, v, theo)
end
println()
println("→ 从完全 LD 出发，r² 因重组而衰减，最终在漂变—重组平衡处稳定。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **低频等位基因的 HWE 检验必须用精确检验**，卡方近似失效。
# 2. **杂合度按 $H_t=H_0(1-1/2N)^t$ 衰减**，模拟与理论吻合；特征时间尺度为 $2N$ 代。
# 3. **$N_e$ 由较少的性别主导**；等量贡献使 $N_e\approx2N$。
# 4. **共祖系数、加性遗传关系、亲缘相关系数三者在有近交时互不相同**（第二版勘误 2‑1）。
# 5. **$c=0$ 时 LD 永不衰减** —— 无性繁殖群体是强 LD 而非连锁平衡（第二版勘误 2‑2）。
# 6. **$E(r^2)\approx1/(1+4N_ec)$** 可用于估计历史 $N_e$、设计标记密度；家畜的小 $N_e$ 是 50K 芯片有效的原因。
