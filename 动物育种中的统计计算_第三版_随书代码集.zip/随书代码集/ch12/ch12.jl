# 本脚本由 tools/nb2jl.py 从同目录的 ch12.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 12

# %% [markdown]
# # 第十二章　混合线性模型与 Henderson 混合模型方程组 —— 配套代码
#
# **这是全书最核心的笔记本。** 它给出 MME 的三种装配方式、完整数值实例、PEV 与准确性的三种算法，以及吸收法。

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions, BenchmarkTools
rng = Xoshiro(20260918)

# 全书通用：由系谱构建 A 与 A⁻¹（第九章）
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); δ=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); δ=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); δ=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); δ=1.0
        end
        b = inv(δ)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

# %% [markdown]
# ## 1　数值实例（正文 §12.3.4）

# %%
# 正文的 10 个体两场数据
sire = [0,0,0,1,1,2,4,4,5,7]
dam  = [0,0,0,2,3,3,5,6,6,8]
herd = [0,0,0,1,1,2,1,2,2,1]          # 0 表示无记录
y_all= [0.,0.,0., 4.5, 2.9, 3.9, 3.5, 5.0, 4.0, 3.2]
haverec = herd .> 0
n = length(sire)

A = build_A(sire, dam); F = diag(A) .- 1
Ainv = build_Ainv(sire, dam, F)
h² = 0.25; λ = (1-h²)/h²

# 装配 MME
recs = findall(haverec)
nr   = length(recs)
y    = y_all[recs]
X    = sparse(1:nr, herd[recs], ones(nr), nr, 2)      # 2 个场
Z    = sparse(1:nr, recs, ones(nr), nr, n)

LHS = [Matrix(X'X)  Matrix(X'Z);
       Matrix(Z'X)  Matrix(Z'Z) + λ*Matrix(Ainv)]
RHS = vcat(Vector(X'y), Vector(Z'y))
sol = LHS \ RHS

@printf("h² = %.2f, λ = %.1f, MME 阶数 = %d\n\n", h², λ, size(LHS,1))
println("场效应：")
for k in 1:2; @printf("  场 %d : %8.4f\n", k, sol[k]); end
println("\n个体 EBV：")
println(rpad("个体",6), rpad("父",5), rpad("母",5), rpad("场",5), rpad("表型",9), rpad("F",9), "EBV")
println("-"^56)
for i in 1:n
    @printf("%-6d%-5d%-5d%-5s%-9s%-9.5f%+.5f\n", i, sire[i], dam[i],
            herd[i]>0 ? string(herd[i]) : "—",
            haverec[i] ? @sprintf("%.1f", y_all[i]) : "—", F[i], sol[2+i])
end

# %% [markdown]
# ## 2　PEV 与准确性（正文 §12.4）

# %%
σ²e = 1.0   # 以 σ²e 为单位；λ 已含方差比，故 C⁻¹ 的块需乘 σ²e
Cinv = inv(LHS)
Cuu  = Cinv[3:end, 3:end]
σ²a  = σ²e/λ

PEV = diag(Cuu) .* σ²e
rel = 1 .- PEV ./ ((1 .+ F) .* σ²a)          # 可靠性 R²（含 (1+F) 因子）
acc = sqrt.(max.(rel, 0.0))

println(rpad("个体",6), rpad("EBV",11), rpad("PEV",11), rpad("可靠性 R²",13), "准确性 r")
println("-"^56)
for i in 1:n
    @printf("%-6d%+-11.5f%-11.5f%-13.4f%.4f\n", i, sol[2+i], PEV[i], rel[i], acc[i])
end

# 有效后裔数（式 12.17）
edc = (4-h²)/h² .* rel ./ max.(1 .- rel, 1e-12)
println("\n有效后裔数 EDC = ", round.(edc, digits=2))

# 常见错误：忘记 (1+F) 因子
rel_wrong = 1 .- PEV ./ σ²a
println("\n【常见错误】忽略 (1+F) 因子：")
for i in findall(F .> 0)
    @printf("  个体 %d (F=%.4f)  正确 R²=%.4f ， 错误 R²=%.4f （低估 %.1f%%）\n",
            i, F[i], rel[i], rel_wrong[i], 100*(rel[i]-rel_wrong[i])/rel[i])
end

# %% [markdown]
# ## 3　BLUP 的退化检验（正文式 12.11，第五章的"免费测试用例"）

# %%
println("【退化检验 1】无亲缘、单记录、仅截距 ⇒ û = h²(y − ȳ)")
m = 200
yy = 10 .+ randn(Xoshiro(8), m).*4
for h2 in (0.1, 0.25, 0.5, 0.8)
    lam = (1-h2)/h2
    C = [Float64(m)  ones(m)'; ones(m)  Matrix((1.0+lam)*I, m, m)]
    r = vcat(sum(yy), yy)
    s = C \ r
    û = s[2:end]
    û_theory = h2 .* (yy .- s[1])
    @printf("  h² = %.2f : 最大偏差 = %.3e  %s\n", h2, maximum(abs, û - û_theory),
            maximum(abs, û - û_theory) < 1e-9 ? "✓" : "✗")
end

println("\n【退化检验 2】λ → 0 ⇒ BLUP 趋于最小二乘（无收缩）")
for lam in (1e0, 1e-2, 1e-4, 1e-6)
    C = [Matrix(X'X) Matrix(X'Z); Matrix(Z'X) Matrix(Z'Z)+lam*Matrix(Ainv)]
    s = C \ RHS
    @printf("  λ = %8.0e : max|û| = %.4f\n", lam, maximum(abs, s[3:end]))
end

println("\n【退化检验 3】λ → ∞ ⇒ û → 0（完全收缩）")
for lam in (1e2, 1e4, 1e6)
    C = [Matrix(X'X) Matrix(X'Z); Matrix(Z'X) Matrix(Z'Z)+lam*Matrix(Ainv)]
    s = C \ RHS
    @printf("  λ = %8.0e : max|û| = %.3e\n", lam, maximum(abs, s[3:end]))
end
println("\n→ 三个退化情形都是免费的测试用例（第五章 §5.3.1）。")

# %% [markdown]
# ## 4　MME 的三种装配方式与规模测试

# %%
"""【原理实现】稠密装配，可读但不可扩展。"""
function mme_dense(X, Z, Ainv, y, λ)
    LHS = [Matrix(X'X) Matrix(X'Z); Matrix(Z'X) Matrix(Z'Z)+λ*Matrix(Ainv)]
    return LHS, vcat(Vector(X'y), Vector(Z'y))
end

"""【优化实现】稀疏装配，保持稀疏结构。"""
function mme_sparse(X, Z, Ainv, y, λ)
    LHS = [X'X  X'Z; Z'X  Z'Z + λ*Ainv]
    return LHS, vcat(Vector(X'y), Vector(Z'y))
end

# 中等规模测试
function make_data(nind::Int; nherd=50, h²=0.25, rng=Random.default_rng())
    sire = zeros(Int, nind); dam = zeros(Int, nind)
    for i in 51:nind; sire[i]=rand(rng,1:i-1); dam[i]=rand(rng,1:i-1); end
    F = diag(build_A(sire, dam)) .- 1
    Ai = build_Ainv(sire, dam, F)
    recs = collect(51:nind)
    hd = rand(rng, 1:nherd, length(recs))
    y  = randn(rng, length(recs)) .* 3 .+ 10
    X = sparse(1:length(recs), hd, ones(length(recs)), length(recs), nherd)
    Z = sparse(1:length(recs), recs, ones(length(recs)), length(recs), nind)
    return X, Z, Ai, y, (1-h²)/h²
end

Xb, Zb, Aib, yb, λb = make_data(1500; rng=Xoshiro(12))
Ld, Rd = mme_dense(Xb, Zb, Aib, yb, λb)
Ls, Rs = mme_sparse(Xb, Zb, Aib, yb, λb)
@printf("【对照验证】两种装配的解相对差 = %.3e\n", norm((Ld\Rd) - (Ls\Rs))/norm(Ls\Rs))
@printf("稠密 : %7.2f ms   内存 %7.1f MiB\n",
        (@belapsed mme_dense($Xb,$Zb,$Aib,$yb,$λb))*1e3, sizeof(Ld)/2^20)
@printf("稀疏 : %7.2f ms   内存 %7.1f MiB   非零元 %d (%.3f%%)\n",
        (@belapsed mme_sparse($Xb,$Zb,$Aib,$yb,$λb))*1e3,
        (nnz(Ls)*12 + size(Ls,2)*8)/2^20, nnz(Ls), 100*nnz(Ls)/length(Ls))

# %% [markdown]
# ## 5　吸收法（正文 §12.5.1）

# %%
"""
    absorb(C, r, idx) -> (C*, r*)

把 `idx` 指定的方程吸收掉（Schur 补，式 12.19）。
"""
function absorb(C::Matrix, r::Vector, idx::Vector{Int})
    keep = setdiff(1:size(C,1), idx)
    C11 = C[keep,keep]; C12 = C[keep,idx]; C22 = C[idx,idx]
    r1 = r[keep]; r2 = r[idx]
    S = C12 * (C22 \ C12')
    return C11 - S, r1 - C12*(C22\r2)
end

# 把 2 个场效应吸收掉
Cstar, rstar = absorb(LHS, RHS, [1,2])
sol_abs = Cstar \ rstar
@printf("吸收前阶数 %d → 吸收后 %d\n", size(LHS,1), size(Cstar,1))
@printf("【对照验证】吸收后的解与原解相对差 = %.3e\n",
        norm(sol_abs - sol[3:end])/norm(sol[3:end]))

# 反演法：回代求被吸收的效应
C22 = LHS[[1,2],[1,2]]; C21 = LHS[[1,2], 3:end]
back = C22 \ (RHS[[1,2]] - C21*sol_abs)
@printf("反演法求得场效应 = (%.4f, %.4f)  原解 = (%.4f, %.4f)\n", back..., sol[1], sol[2])

# %% [markdown]
# ## 本章代码小结
#
# 1. **完整数值实例**：10 个体两场的 MME，给出场效应、EBV、PEV、可靠性与有效后裔数。
# 2. **准确性公式中的 $(1+F)$ 因子不可省略**——近交个体上忽略它会低估可靠性。
# 3. **三个退化检验**（$\hat u=h^2(y-\bar y)$、$\lambda\to0$、$\lambda\to\infty$）是验证任何 BLUP 实现的免费测试。
# 4. **稀疏装配在 $n=1500$ 时内存已优两个数量级**，且随 $n$ 增长差距扩大。
# 5. **吸收法**（Schur 补）与反演法验证通过：吸收后的解与原解完全一致。
