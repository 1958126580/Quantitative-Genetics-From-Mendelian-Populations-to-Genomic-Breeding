# 第十二章　混合线性模型与 Henderson 混合模型方程组 —— 配套代码

**所属**：第三篇　线性混合模型的理论与计算　　**对应正文**：第十二章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch12.ipynb` | IJulia 笔记本：6 个代码单元，约 181 行 Julia 代码，穿插与正文对应的说明 |
| `ch12.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |

## 笔记本内容

- 1　数值实例（正文 §12.3.4）
- 2　PEV 与准确性（正文 §12.4）
- 3　BLUP 的退化检验（正文式 12.11，第五章的"免费测试用例"）
- 4　MME 的三种装配方式与规模测试
- 5　吸收法（正文 §12.5.1）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 12
```

或在 Jupyter 中打开 `ch12/ch12.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 本章没有单独的 Python 复核脚本：正文中的解析数值已在写作时用 Python 逐一复算。
