# 第二十六章　贝叶斯 GWAS、窗口方差与精细定位 —— 配套代码

**所属**：第六篇　关联分析与统计基因组学　　**对应正文**：第二十六章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch26.ipynb` | IJulia 笔记本：12 个代码单元，约 508 行 Julia 代码，穿插与正文对应的说明 |
| `ch26.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 13 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　BayesC 抽样并收集 $\delta$ 与 $\alpha$
- 2　WPPA 与贝叶斯因子（正文式 26.3–26.4）
- 3　窗口遗传方差（正文式 26.5–26.8）
  - 3.1 窗口大小的稳健性
- 4　穷举式贝叶斯精细定位（正文式 26.10–26.12）
- 5　SuSiE：单效应回归与 IBSS（正文式 26.13–26.19、算法 26.1）
- 6　ABF 与第二十二章式 (22.26) 的等价性（正文思考题 5）
- 7　基于汇总统计量的精细定位与 LD 面板不匹配
- 8　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 26
```

或在 Jupyter 中打开 `ch26/ch26.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
