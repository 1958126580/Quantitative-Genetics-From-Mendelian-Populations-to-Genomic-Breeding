# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_ld_b.py    依赖：numpy
# (b) revisited: reference-panel sampling noise for a two-locus pair (same seeds as s2_ld.py)
import numpy as np
r = 0.95; p = 0.3; D = r * p * (1 - p)
hf = np.array([p * p + D, p - (p * p + D), p - (p * p + D), 1 - (p * p + D) - 2 * (p - (p * p + D))])
alle = np.array([[1, 1], [1, 0], [0, 1], [0, 0]])
def geno(rng, n):
    h1 = alle[rng.choice(4, n, p=hf)]; h2 = alle[rng.choice(4, n, p=hf)]
    return (h1 + h2).astype(float)
N = 5000
print('pop r=0.95, p=0.3; GWAS N=5000; 2000 reps')
for zt in [10.0, 20.0]:
    q = zt ** 2 / (N + zt ** 2)
    for nref in [0, 100, 500, 2000]:
        rng = np.random.default_rng(31 + int(zt) + nref)
        zc = []; rrs = []
        for rep in range(2000):
            G = geno(rng, N)
            xj, xk = G[:, 0] - G[:, 0].mean(), G[:, 1] - G[:, 1].mean()
            b = np.sqrt(q / xj.var())
            y = b * xj + rng.standard_normal(N) * np.sqrt(1 - q); y = y - y.mean()
            def z_of(x):
                bh = x @ y / (x @ x); res = y - bh * x
                return bh / np.sqrt(res @ res / (N - 2) / (x @ x))
            zj, zk = z_of(xj), z_of(xk)
            if nref == 0:
                rr = np.corrcoef(xj, xk)[0, 1]
            else:
                Gr = geno(rng, nref); rr = np.corrcoef(Gr[:, 0], Gr[:, 1])[0, 1]
            rrs.append(rr)
            zc.append((zk - rr * zj) / np.sqrt(1 - rr ** 2) if abs(rr) < 1 - 1e-12 else np.nan)
        zc = np.array(zc); rrs = np.array(rrs)
        ok = ~np.isnan(zc)
        mad = 1.4826 * np.median(np.abs(zc[ok] - np.median(zc[ok])))
        print(' z_j %.0f | %-12s | sd(r_ref) %.4f | P(r_ref=1) %.4f | among rest: sd %.3f robust sd %.3f P(|z|>3) %.4f P(|z|>5.45) %.4f' % (
            zt, 'in-sample' if nref == 0 else 'n_ref=%d' % nref, rrs.std(), 1 - ok.mean(), zc[ok].std(), mad, np.mean(np.abs(zc[ok]) > 3), np.mean(np.abs(zc[ok]) > 5.4513)))
