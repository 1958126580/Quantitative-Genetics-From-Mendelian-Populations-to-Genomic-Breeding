# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 check_data.py    依赖：numpy, scipy
import numpy as np
from scipy import stats
from sim import gen_data
D = gen_data(2026)
X, y = D['X'], D['y']
n, m = X.shape
p = X.mean(0)/2; maf = np.minimum(p, 1-p)
print('n,m', n, m, 'MAF mean %.3f min %.4f max %.3f' % (maf.mean(), maf.min(), maf.max()), 'n maf<0.01', (maf<0.01).sum())
Zc = X - X.mean(0)
C = np.corrcoef(Zc.T)
adj = np.array([C[j,j+1]**2 for j in range(m-1)])
print('adjacent r2 mean %.3f median %.3f frac>0.8 %.3f' % (adj.mean(), np.median(adj), (adj>0.8).mean()))
for d in [5,10,20,40]:
    print(' d', d, 'mean r2 %.3f' % np.mean([C[j,j+d]**2 for j in range(m-d)]))
print('var g %.4f var e %.4f var y %.4f realized h2 %.4f' % (D['g'].var(), D['e'].var(), y.var(), D['g'].var()/y.var()))
# QTL r2 with best marker, true window shares
Qc = D['Qc']
for i,k in enumerate(D['qk']):
    q = Qc[:, i]
    r = np.array([np.corrcoef(q, Zc[:, j])[0,1] for j in range(max(0,k-30), min(m,k+31))])
    js = np.arange(max(0,k-30), min(m,k+31))
    b = np.argmax(r**2)
    print('QTL', i+1, 'after marker', k, 'pos %.2f' % D['qpos'][i], 'maf %.3f' % min(Q:=Qc[:,i].var()/2, 1), 'eff %.4f' % D['eff'][i],
          'best marker', js[b], 'r2 %.3f' % (r[b]**2), 'flank r2 %.3f %.3f' % (np.corrcoef(q, Zc[:,k])[0,1]**2, np.corrcoef(q, Zc[:,k+1])[0,1]**2))
# single marker regression
Zs = Zc / Zc.std(0)
yc = y - y.mean()
r = Zs.T @ yc / (n * yc.std())
t = r*np.sqrt((n-2)/(1-r**2))
pv = 2*stats.t.sf(np.abs(t), n-2)
print('n sig p<2.5e-5:', (pv<0.05/m).sum())
for w in range(100):
    s = pv[20*w:20*w+20]
    if (s<0.05/m).any():
        print('window %d-%d Mb: nsig %d minp %.2e' % (w, w+1, (s<0.05/m).sum(), s.min()))
