# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_abf.py    依赖：numpy, scipy
# Wakefield ABF: worked example, W-dependence (Lindley), same p-value different N/MAF
import numpy as np
from scipy import stats
def log_abf(z, V, W):
    r = W / (V + W)
    return 0.5 * np.log(1 - r) + r * z * z / 2
print('== worked example: bhat=0.12, se=0.03, W=0.15^2')
b, se, W = 0.12, 0.03, 0.15 ** 2
V = se ** 2; z = b / se; r = W / (V + W)
print('z %.4f  V %.6f  r %.6f  sqrt(1-r) %.6f  exp(r z^2/2) %.3f  ABF %.3f  log10ABF %.4f' % (
    z, V, r, np.sqrt(1 - r), np.exp(r * z * z / 2), np.exp(log_abf(z, V, W)), log_abf(z, V, W) / np.log(10)))
print('posterior mean under H1 r*bhat %.4f, posterior sd %.4f' % (r * b, np.sqrt(r * V)))
p2 = 2 * stats.norm.sf(z)
print('two-sided p %.3e' % p2)
for pi1 in [1e-3, 1e-4, 1e-5]:
    PO = pi1 / (1 - pi1); B = np.exp(log_abf(z, V, W))
    print('  prior pi1=%.0e: PPA %.4f  BFDP %.4f' % (pi1, B * PO / (1 + B * PO), 1 - B * PO / (1 + B * PO)))
print('\n== ABF as function of W (z=4, se=0.03)')
for sW in [0.01, 0.02, 0.05, 0.1, 0.116, 0.15, 0.2, 0.5, 1.0, 10.0]:
    print(' sqrtW %.3f  ABF %.3f' % (sW, np.exp(log_abf(4.0, V, sW ** 2))))
print(' W* = V(z^2-1) -> sqrtW* %.4f ; max ABF = exp((z^2-1)/2)/|z| = %.3f' % (np.sqrt(V * 15), np.exp(7.5) / 4))
print('\n== max ABF over W for various z, vs 1/p')
for zz in [2.0, 3.0, 4.0, 5.0, 5.4513, 6.0]:
    p = 2 * stats.norm.sf(zz)
    print(' z %.4f p %.3e  maxABF %.4g  1/p %.4g' % (zz, p, np.exp((zz * zz - 1) / 2) / zz, 1 / p))
print('\n== same p = 5e-8 (z=%.4f), W=0.15^2, V=1/(2Npq)' % stats.norm.isf(2.5e-8))
z0 = stats.norm.isf(2.5e-8)
for maf in [0.05, 0.2, 0.5]:
    row = []
    for N in [1000, 10000, 100000, 1000000]:
        V = 1 / (2 * N * maf * (1 - maf))
        B = np.exp(log_abf(z0, V, W))
        PO = 1e-4 / (1 - 1e-4)
        row.append('N=%d: V=%.2e ABF=%.4g PPA=%.3f' % (N, V, B, B * PO / (1 + B * PO)))
    print(' maf %.2f | ' % maf + ' | '.join(row))
print('\n== standardized prior: W_j = s^2/(2pq), expected var explained 2pq W = s^2 ; with s^2=1e-3? ')
for N in [1000, 10000, 100000]:
    s2 = 0.15 ** 2 * 2 * 0.5 * 0.5  # match W=0.15^2 at maf .5
    rr = N * s2 / (1 + N * s2)
    print(' N %d r %.4f ABF(z=5.4513) %.4g (same for all MAF)' % (N, rr, np.exp(0.5 * np.log(1 - rr) + rr * z0 * z0 / 2)))
