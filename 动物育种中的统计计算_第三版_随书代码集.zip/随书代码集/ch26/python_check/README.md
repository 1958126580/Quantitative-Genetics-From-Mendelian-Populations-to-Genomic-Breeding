# 第 26 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch26/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `check_data.py` | 数值复核 | numpy, scipy | 3.7 | `outputs/check_data.out` |
| `ldtest.py` | 数值复核 | numpy, scipy | 2.9 | `outputs/ldtest.out` |
| `ldtest2.py` | 数值复核 | numpy, scipy | 3.0 | `outputs/ldtest2.out` |
| `misc1.py` | Miscellaneous numbers for the text (section 26.1 tables and 26.2/26.3 rules of thumb) | numpy | 1.0 | `outputs/misc1.out` |
| `region_check.py` | 数值复核 | numpy, scipy | 2.4 | `outputs/region_check.out` |
| `s2_abf.py` | Wakefield ABF: worked example, W-dependence (Lindley), same p-value different N/MAF | numpy, scipy | 2.0 | `outputs/s2_abf.out` |
| `s2_cs.py` | Single-causal-variant fine-mapping: PP_j = ABF_j / sum ABF, 95% credible sets vs LD strength. | numpy | 8.0 | `outputs/s2_cs.out` |
| `s2_ld_b.py` | (b) revisited: reference-panel sampling noise for a two-locus pair (same seeds as s2_ld.py) | numpy | 19.2 | `outputs/s2_ld_b.out` |
| `s3_coloc.py` | coloc (Giambartolomei et al. 2014) computed from ABFs; summary-level simulation. | numpy | 1.2 | `outputs/s3_coloc.out` |
| `s3_enrich.py` | Enrichment pitfalls under a TRUE null: (1) gene-length bias, (2) LD-clump (SNP counting) bias. | numpy, scipy | 21.3 | `outputs/s3_enrich.out` |
| `s3_enrich_b.py` | (1b) gene-length bias with "gene body +-10 kb" mapping (same genome and gene set as s3_enrich.py) | numpy, scipy | 10.9 | `outputs/s3_enrich_b.out` |
| `susie.py` | Minimal SuSiE (IBSS) on sufficient statistics (X'X, X'y, y'y, n). | numpy, scipy | 0.8 | `outputs/susie.out` |
| `timing.py` | 数值复核 | numpy | 0.8 | `outputs/timing.out` |

公共函数模块（被上列脚本导入，不单独运行）：`region.py`、`sim.py`。
