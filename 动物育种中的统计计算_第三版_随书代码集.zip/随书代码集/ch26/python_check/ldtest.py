# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ldtest.py    依赖：numpy, scipy
import numpy as np
from scipy.stats import norm
def sim_hap(rng, n, m, rho, p):
    thr = norm.ppf(p)
    U = np.empty((n, m))
    U[:, 0] = rng.standard_normal(n)
    s = np.sqrt(1 - rho**2)
    E = rng.standard_normal((n, m))
    for j in range(1, m):
        U[:, j] = rho[j] * U[:, j-1] + s[j] * E[:, j]
    return (U < thr).astype(np.int8)
for r0 in [0.9, 0.95, 0.97, 0.98]:
    rng = np.random.default_rng(1)
    m = 400; n = 2000
    rho = np.full(m, r0)
    p = rng.uniform(0.05, 0.5, m)
    G = sim_hap(rng, n, m, rho, p) + sim_hap(rng, n, m, rho, p)
    Z = G - G.mean(0)
    C = np.corrcoef(Z.T)
    adj = np.array([C[j, j+1]**2 for j in range(m-1)])
    d5 = np.array([C[j, j+5]**2 for j in range(m-5)])
    d10 = np.array([C[j, j+10]**2 for j in range(m-10)])
    d20 = np.array([C[j, j+20]**2 for j in range(m-20)])
    print(r0, 'adj r2 mean %.3f median %.3f; d5 %.3f d10 %.3f d20 %.3f; frac adj>0.8 %.3f' % (adj.mean(), np.median(adj), d5.mean(), d10.mean(), d20.mean(), (adj>0.8).mean()))
