# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ldtest2.py    依赖：numpy, scipy
import numpy as np
from scipy.stats import norm
def ar(rng, m, rho):
    x = np.empty(m); x[0] = rng.standard_normal()
    for j in range(1, m): x[j] = rho*x[j-1] + np.sqrt(1-rho**2)*rng.standard_normal()
    return x
def sim_hap(rng, n, m, rho, thr):
    U = np.empty((n, m))
    U[:, 0] = rng.standard_normal(n)
    E = rng.standard_normal((n, m))
    s = np.sqrt(1 - rho**2)
    for j in range(1, m):
        U[:, j] = rho * U[:, j-1] + s * E[:, j]
    return (U < thr).astype(np.int8)
for r0 in [0.95, 0.97, 0.98, 0.99]:
  for rt, sc in [(0.9,0.8),(0.97,0.8)]:
    rng = np.random.default_rng(1)
    m = 400; n = 2000
    thr = sc*ar(rng, m, rt)
    G = sim_hap(rng, n, m, r0, thr) + sim_hap(rng, n, m, r0, thr)
    p = G.mean(0)/2; maf = np.minimum(p, 1-p)
    Z = G - G.mean(0)
    C = np.corrcoef(Z.T)
    f = lambda d: np.array([C[j, j+d]**2 for j in range(m-d)])
    adj = f(1)
    print(r0, rt, sc, 'adj r2 mean %.3f med %.3f >0.8 %.3f; d5 %.3f d10 %.3f d20 %.3f d40 %.3f; maf mean %.3f min %.3f' % (adj.mean(), np.median(adj), (adj>0.8).mean(), f(5).mean(), f(10).mean(), f(20).mean(), f(40).mean(), maf.mean(), maf.min()))
