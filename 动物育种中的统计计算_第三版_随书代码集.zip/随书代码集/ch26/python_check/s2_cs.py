# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_cs.py    依赖：numpy
# Single-causal-variant fine-mapping: PP_j = ABF_j / sum ABF, 95% credible sets vs LD strength.
# Summary-level simulation: z ~ N(lambda * R[:, c], R), R_jk = rho^|j-k| (m=101, causal at centre).
import numpy as np
m = 101; c = 50; N = 2000; V = 1.0 / N; W = 0.15 ** 2; r = W / (V + W)
def cs_from_pp(pp, level=0.95):
    o = np.argsort(-pp); cs = np.cumsum(pp[o])
    k = int(np.searchsorted(cs, level) + 1)
    return o[:k]
def run(rho, lam, nrep=4000, seed=1):
    rng = np.random.default_rng(seed)
    idx = np.arange(m)
    R = rho ** np.abs(idx[:, None] - idx[None, :]) if rho > 0 else np.eye(m)
    Lc = np.linalg.cholesky(R + 1e-12 * np.eye(m))
    size = []; cover = []; ppc = []; top = []
    for _ in range(nrep):
        z = lam * R[:, c] + Lc @ rng.standard_normal(m)
        la = 0.5 * np.log(1 - r) + r * z * z / 2
        pp = np.exp(la - la.max()); pp /= pp.sum()
        cs = cs_from_pp(pp)
        size.append(len(cs)); cover.append(c in cs); ppc.append(pp[c]); top.append(np.argmax(pp) == c)
    size = np.array(size)
    return size.mean(), np.median(size), np.percentile(size, 90), np.mean(cover), np.mean(ppc), np.mean(top)
print('m=%d causal at %d, N=%d, W=0.15^2, r=%.4f, 4000 reps' % (m, c, N, r))
for lam in [5.0, 8.0, 12.0]:
    for rho in [0.0, 0.5, 0.8, 0.9, 0.95, 0.98, 0.99]:
        s = run(rho, lam, seed=int(rho * 1000) + int(lam))
        print('lam %.0f rho %.2f adj_r2 %.4f | CS mean %.2f median %.0f p90 %.0f | coverage %.4f | mean PP(causal) %.3f | top=causal %.3f' % ((lam, rho, rho ** 2) + s))
# One concrete realisation for the text: rho = 0.95, lam = 8
rng = np.random.default_rng(2612)
rho, lam = 0.95, 8.0
idx = np.arange(m); R = rho ** np.abs(idx[:, None] - idx[None, :])
z = lam * R[:, c] + np.linalg.cholesky(R) @ rng.standard_normal(m)
la = 0.5 * np.log(1 - r) + r * z * z / 2
pp = np.exp(la - la.max()); pp /= pp.sum()
o = np.argsort(-pp); cum = np.cumsum(pp[o])
print('\nrealisation rho=0.95 lam=8 seed 2612')
for i in range(12):
    j = o[i]
    print(' rank %d var %d (offset %+d) r2 with causal %.3f z %.3f log10ABF %.3f PP %.4f cum %.4f' % (i + 1, j, j - c, R[j, c] ** 2, z[j], la[j] / np.log(10), pp[j], cum[i]))
print(' CS size', len(cs_from_pp(pp)), 'contains causal', c in cs_from_pp(pp))
