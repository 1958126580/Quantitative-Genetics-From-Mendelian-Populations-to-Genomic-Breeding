# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_enrich.py    依赖：numpy, scipy
# Enrichment pitfalls under a TRUE null: (1) gene-length bias, (2) LD-clump (SNP counting) bias.
import numpy as np
from scipy import stats

rng = np.random.default_rng(3030)
# ---------------- (1) gene-length bias ----------------
G = 20000
glen = np.exp(rng.normal(np.log(25e3), 1.0, G))          # gene length (bp), lognormal
gap = rng.exponential(100e3, G + 1)                       # intergenic gaps
starts = np.cumsum(gap[:-1] + np.concatenate([[0], glen[:-1]]))
ends = starts + glen
genome = ends[-1] + gap[-1]
mid = (starts + ends) / 2
# nearest-gene territory: boundaries at midpoints between consecutive genes' facing ends
bnd = np.concatenate([[0], (ends[:-1] + starts[1:]) / 2, [genome]])
terr = np.diff(bnd)
print('(1) genome %.0f Mb, %d genes, median gene length %.1f kb, mean %.1f kb; mean territory %.1f kb' % (
    genome / 1e6, G, np.median(glen) / 1e3, glen.mean() / 1e3, terr.mean() / 1e3))
print('    corr(log gene length, log territory) %.3f' % np.corrcoef(np.log(glen), np.log(terr))[0, 1])
# gene set of 500 genes, sampled with probability proportional to length (a "long-gene" set)
K = 500
S = rng.choice(G, K, replace=False, p=glen / glen.sum())
inS = np.zeros(G, bool); inS[S] = True
print('    gene set: %d genes, median length %.1f kb (genome-wide %.1f kb); set share of genome territory %.4f vs share of genes %.4f' % (
    K, np.median(glen[S]) / 1e3, np.median(glen) / 1e3, terr[S].sum() / genome, K / G))
def hit_genes(rng, nhit):
    pos = rng.uniform(0, genome, nhit)
    g = np.searchsorted(bnd, pos) - 1
    return np.unique(g)
nhit = 200
# null distribution of k (hit genes in S) by simulation
null_k = np.array([inS[hit_genes(rng, nhit)].sum() for _ in range(20000)])
print('    null (random positions, nearest-gene mapping): mean k %.3f, 95%% quantile %.0f' % (null_k.mean(), np.quantile(null_k, 0.95)))
# one example replicate
hg = hit_genes(rng, nhit); k = inS[hg].sum(); nd = len(hg)
p_naive = stats.hypergeom.sf(k - 1, G, K, nd)
p_perm = (np.sum(null_k >= k) + 1) / (len(null_k) + 1)
print('    example: %d hits -> %d unique genes; k=%d in set; naive expectation %.3f, FE %.2f, hypergeom p %.2e; permutation expectation %.3f, perm p %.4f' % (
    nhit, nd, k, nd * K / G, k / (nd * K / G), p_naive, null_k.mean(), p_perm))
# type I error over replicates
rej_naive = 0; rej_perm = 0; R = 2000
for _ in range(R):
    hg = hit_genes(rng, nhit); k = inS[hg].sum(); nd = len(hg)
    rej_naive += stats.hypergeom.sf(k - 1, G, K, nd) < 0.05
    rej_perm += (np.sum(null_k >= k) + 1) / (len(null_k) + 1) < 0.05
print('    type I error at 0.05 over %d null replicates: naive hypergeometric %.4f, length-aware permutation %.4f' % (R, rej_naive / R, rej_perm / R))

# ---------------- (2) LD-clump bias ----------------
rng = np.random.default_rng(3131)
Lg = 2500e6
nseg = 1000; seglen = 50e3
f = nseg * seglen / Lg
segs = np.sort(rng.uniform(0, Lg - seglen, nseg))
# merge overlaps implicitly: membership test via any segment covering position
seg_s = segs; seg_e = segs + seglen
def in_annot(pos):
    i = np.searchsorted(seg_s, pos, side='right') - 1
    ok = i >= 0
    res = np.zeros(pos.shape, bool)
    res[ok] = pos[ok] < seg_e[i[ok]]
    return res
cover = np.mean(in_annot(rng.uniform(0, Lg, 2_000_000)))
print('\n(2) annotation: %d segments x %.0f kb = nominal fraction %.4f (Monte Carlo coverage %.4f)' % (nseg, seglen / 1e3, f, cover))
nloci = 30; meansnp = 30; half = 50e3
def gwas_hits(rng):
    centres = rng.uniform(half, Lg - half, nloci)
    ns = 1 + rng.poisson(meansnp - 1, nloci)
    pos = np.concatenate([c + rng.uniform(-half, half, n) for c, n in zip(centres, ns)])
    return centres, pos
def tests(rng, centres, pos, nshift=200):
    x = in_annot(pos).sum(); n = len(pos)
    p_snp = stats.binom.sf(x - 1, n, cover)
    xl = in_annot(centres).sum()
    p_lead = stats.binom.sf(xl - 1, nloci, cover)
    sh = rng.uniform(0, Lg, nshift)
    null = np.array([in_annot((pos + s) % Lg).sum() for s in sh])
    p_shift = (np.sum(null >= x) + 1) / (nshift + 1)
    return x, n, p_snp, xl, p_lead, p_shift, null
c0, p0 = gwas_hits(rng)
x, n, p_snp, xl, p_lead, p_shift, null = tests(rng, c0, p0, nshift=2000)
print('    example: %d loci, %d significant SNPs; %d SNPs in annotation (%.2f%% vs %.2f%% expected, FE %.2f); SNP-level binomial p %.2e' % (
    nloci, n, x, 100 * x / n, 100 * cover, (x / n) / cover, p_snp))
print('             lead SNPs in annotation %d of %d (expected %.2f), binomial p %.3f; circular-shift p %.4f (null mean %.2f, sd %.2f, binomial sd would be %.2f)' % (
    xl, nloci, nloci * cover, p_lead, p_shift, null.mean(), null.std(), np.sqrt(n * cover * (1 - cover))))
R = 1000; rs = np.zeros(3)
for _ in range(R):
    c, p = gwas_hits(rng)
    _, _, a, _, b, s, _ = tests(rng, c, p)
    rs += np.array([a < 0.05, b < 0.05, s < 0.05])
print('    type I error at 0.05 over %d null replicates: SNP-level binomial %.4f, lead-SNP binomial %.4f, circular shift %.4f' % (R, *(rs / R)))
