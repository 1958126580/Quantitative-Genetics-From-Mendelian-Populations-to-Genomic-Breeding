# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_enrich_b.py    依赖：numpy, scipy
# (1b) gene-length bias with "gene body +-10 kb" mapping (same genome and gene set as s3_enrich.py)
import numpy as np
from scipy import stats
rng = np.random.default_rng(3030)
G = 20000
glen = np.exp(rng.normal(np.log(25e3), 1.0, G))
gap = rng.exponential(100e3, G + 1)
starts = np.cumsum(gap[:-1] + np.concatenate([[0], glen[:-1]]))
ends = starts + glen
genome = ends[-1] + gap[-1]
K = 500
S = rng.choice(G, K, replace=False, p=glen / glen.sum())
inS = np.zeros(G, bool); inS[S] = True
fl = 10e3
ws, we = starts - fl, ends + fl
def hit_genes(rng, nhit):
    pos = rng.uniform(0, genome, nhit)
    out = set()
    i = np.searchsorted(ws, pos, side='right') - 1
    for p_, k in zip(pos, i):
        for kk in (k, k - 1):               # windows can overlap neighbours
            if 0 <= kk < G and ws[kk] <= p_ < we[kk]:
                out.add(kk)
    return np.array(sorted(out), dtype=int)
nhit = 200
foot = (we - ws)
print('footprint (gene+-10kb) share: set %.4f of genome vs genes share %.4f; ratio %.3f' % (foot[S].sum() / genome, K / G, (foot[S].sum() / foot.sum()) / (K / G)))
null = []; nds = []
for _ in range(20000):
    hg = hit_genes(rng, nhit); null.append(inS[hg].sum()); nds.append(len(hg))
null = np.array(null); nds = np.array(nds)
print('null: mean #hit genes %.2f, mean k in set %.3f, naive expectation %.3f (ratio %.3f), 95%% quantile of k %.0f' % (nds.mean(), null.mean(), nds.mean() * K / G, null.mean() / (nds.mean() * K / G), np.quantile(null, 0.95)))
rn = rp = 0; R = 2000
for _ in range(R):
    hg = hit_genes(rng, nhit); k = inS[hg].sum(); nd = len(hg)
    rn += stats.hypergeom.sf(k - 1, G, K, nd) < 0.05
    rp += (np.sum(null >= k) + 1) / (len(null) + 1) < 0.05
print('type I error at 0.05 (%d null reps): naive hypergeometric %.4f, permutation %.4f' % (R, rn / R, rp / R))
# example replicate: first null replicate in which the naive test rejects
rng2 = np.random.default_rng(55)
for t in range(1, 200):
    hg = hit_genes(rng2, nhit); k = inS[hg].sum(); nd = len(hg)
    pn = stats.hypergeom.sf(k - 1, G, K, nd)
    if pn < 0.05:
        pp = (np.sum(null >= k) + 1) / (len(null) + 1)
        print('example (null replicate #%d, seed 55): %d hit genes, k=%d, naive exp %.3f FE %.2f naive p %.4f | permutation exp %.3f perm p %.4f' % (
            t, nd, k, nd * K / G, k / (nd * K / G), pn, null.mean(), pp))
        break
