# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 timing.py    依赖：numpy
import numpy as np, time, math
rng = np.random.default_rng(0)
n, m = 2000, 2000
Z = np.asfortranarray(rng.standard_normal((n, m)))
e = rng.standard_normal(n)
a = np.zeros(m)
zz = (Z*Z).sum(0)
t0 = time.time()
for it in range(20):
    u = rng.random(m); nr = rng.standard_normal(m)
    ve, va = 1.0, 0.01
    for j in range(m):
        zj = Z[:, j]
        aj = a[j]
        rhs = zj @ e + zz[j]*aj
        C = zz[j] + ve/va
        lg = 4.6 - 0.5*math.log(va*C/ve) + rhs*rhs/(2*ve*C)
        if lg > 0: p1 = 1/(1+math.exp(-lg))
        else:
            t = math.exp(lg); p1 = t/(1+t)
        if u[j] < p1: new = rhs/C + math.sqrt(ve/C)*nr[j]
        else: new = 0.0
        if new != aj:
            e -= zj*(new-aj); a[j] = new
print('per iter %.4f s' % ((time.time()-t0)/20))
