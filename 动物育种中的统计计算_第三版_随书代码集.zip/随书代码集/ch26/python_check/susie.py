# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 susie.py    依赖：numpy, scipy
"""Minimal SuSiE (IBSS) on sufficient statistics (X'X, X'y, y'y, n).

Follows Wang et al. (2020): single-effect regression (SER) for each of L effects,
prior variance V_l estimated by maximising the SER marginal likelihood (V_l may be 0),
residual variance sigma^2 estimated from the expected residual sum of squares,
ELBO monitored; credible sets with purity filter (min |r| >= 0.5).
"""
import numpy as np
from scipy.optimize import minimize_scalar


def _lbf(bhat, s2, V):
    if V <= 0:
        return np.zeros_like(bhat)
    return 0.5 * np.log(s2 / (s2 + V)) + 0.5 * bhat ** 2 / s2 * V / (s2 + V)


def _logsumexp_w(lbf, logpi):
    x = lbf + logpi
    mx = x.max()
    return mx + np.log(np.exp(x - mx).sum())


def ser(XtR, d, sigma2, V, logpi, est_V=True):
    bhat = XtR / d
    s2 = sigma2 / d
    if est_V:
        f = lambda lv: -_logsumexp_w(_lbf(bhat, s2, np.exp(lv)), logpi)
        opt = minimize_scalar(f, bounds=(-30, 15), method='bounded')
        Vn = np.exp(opt.x)
        # compare with V = 0 (log BF of the model = 0)
        if -opt.fun <= 0:
            Vn = 0.0
        V = Vn
    lbf = _lbf(bhat, s2, V)
    lbf_model = _logsumexp_w(lbf, logpi)
    w = lbf + logpi
    alpha = np.exp(w - w.max()); alpha /= alpha.sum()
    if V > 0:
        post_var = 1.0 / (1.0 / V + d / sigma2)
        mu = post_var * XtR / sigma2
    else:
        post_var = np.zeros_like(d); mu = np.zeros_like(d)
    return alpha, mu, post_var, V, lbf, lbf_model


def susie_ss(XtX, Xty, yty, n, L=10, V_init=None, est_V=True, est_sigma2=True,
             sigma2=None, max_iter=100, tol=1e-3, trace=False, prior_w=None, init=None):
    p = len(Xty)
    d = np.diag(XtX).copy()
    if prior_w is None:
        logpi = np.full(p, -np.log(p))
    else:
        w = np.asarray(prior_w, float); w = w / w.sum()
        with np.errstate(divide='ignore'):
            logpi = np.log(w)
    if sigma2 is None:
        sigma2 = yty / (n - 1)
    if V_init is None:
        V_init = 0.2 * yty / (n - 1)
    alpha = np.full((L, p), 1.0 / p)
    mu = np.zeros((L, p)); pv = np.zeros((L, p)); V = np.full(L, V_init)
    if init is not None:
        alpha = init['alpha'].copy(); mu = init['mu'].copy(); pv = init['post_var'].copy()
        V = np.where(init['V'] > 0, init['V'], V_init).astype(float)
        sigma2 = init['sigma2']
    lbf_all = np.zeros((L, p)); lbf_model = np.zeros(L); KL = np.zeros(L)
    bbar = alpha * mu                     # L x p
    XtXb = XtX @ bbar.sum(0)
    elbo = [-np.inf]
    hist = []
    for it in range(max_iter):
        for l in range(L):
            XtXb_l = XtX @ bbar[l]
            XtR = Xty - XtXb + XtXb_l
            a, m_, v_, V[l], lbf_all[l], lbf_model[l] = ser(XtR, d, sigma2, V[l], logpi, est_V)
            alpha[l], mu[l], pv[l] = a, m_, v_
            newb = a * m_
            XtXb = XtXb - XtXb_l + XtX @ newb
            bbar[l] = newb
            Eb2 = a * (m_ ** 2 + v_)
            KL[l] = -lbf_model[l] + (2 * XtR @ newb - (d * Eb2).sum()) / (2 * sigma2)
        b = bbar.sum(0)
        ERSS = yty - 2 * b @ Xty + b @ XtXb
        for l in range(L):
            ERSS += (d * alpha[l] * (mu[l] ** 2 + pv[l])).sum() - bbar[l] @ (XtX @ bbar[l])
        e = -0.5 * n * np.log(2 * np.pi * sigma2) - ERSS / (2 * sigma2) - KL.sum()
        elbo.append(e)
        if trace:
            hist.append((it + 1, alpha.copy(), V.copy(), sigma2, e))
        if est_sigma2:
            sigma2 = ERSS / n
        if abs(elbo[-1] - elbo[-2]) < tol:
            break
    return dict(alpha=alpha, mu=mu, post_var=pv, V=V, sigma2=sigma2, elbo=np.array(elbo[1:]),
                niter=it + 1, lbf=lbf_all, lbf_model=lbf_model, hist=hist)


def get_cs(fit, R, coverage=0.95, min_abs_corr=0.5, Vtol=1e-9):
    out = []
    for l in range(fit['alpha'].shape[0]):
        if fit['V'][l] <= Vtol:
            continue
        a = fit['alpha'][l]
        o = np.argsort(-a); cs = np.cumsum(a[o])
        k = int(np.searchsorted(cs, coverage) + 1)
        S = np.sort(o[:k])
        if len(S) == 1:
            pur = 1.0
        else:
            sub = np.abs(R[np.ix_(S, S)])
            pur = sub[np.triu_indices(len(S), 1)].min()
        if pur >= min_abs_corr:
            if not any(set(S.tolist()) == set(x['cs'].tolist()) for x in out):
                out.append(dict(l=l, cs=S, purity=pur, cov=a[S].sum(), top=int(o[0])))
    return out


def pip(fit, Vtol=1e-9):
    keep = fit['V'] > Vtol
    if not keep.any():
        return np.zeros(fit['alpha'].shape[1])
    return 1 - np.prod(1 - fit['alpha'][keep], axis=0)


def ss_from_individual(X, y):
    Xc = X - X.mean(0)
    sd = Xc.std(0, ddof=1)
    Xs = Xc / sd
    yc = y - y.mean()
    return Xs.T @ Xs, Xs.T @ yc, yc @ yc, len(y), Xs, yc


def ss_from_z(z, R, n):
    """SuSiE-RSS style sufficient statistics from z-scores and an LD matrix
    (standardised y and X): r_j = z_j / sqrt(z_j^2 + n - 2)."""
    rj = z / np.sqrt(z ** 2 + n - 2)
    return (n - 1) * R, (n - 1) * rj, float(n - 1), n


def susie_refine(XtX, Xty, yty, n, L=5, R=None, max_rounds=5, **kw):
    """Mask-and-restart refinement: for every credible set of the current best fit,
    refit with those variables' prior weight set to zero, use that fit as the
    starting point of an unrestricted refit, keep it if the ELBO improves."""
    best = susie_ss(XtX, Xty, yty, n, L=L, **kw)
    p = len(Xty)
    for _ in range(max_rounds):
        improved = False
        for cs in get_cs(best, R):
            w = np.ones(p); w[cs['cs']] = 0.0
            f0 = susie_ss(XtX, Xty, yty, n, L=L, prior_w=w, **kw)
            f1 = susie_ss(XtX, Xty, yty, n, L=L, init=f0, **kw)
            if f1['elbo'][-1] > best['elbo'][-1] + 1e-6:
                best = f1; improved = True
                break
        if not improved:
            break
    return best
