# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 region_check.py    依赖：numpy
import numpy as np
from region import genos, A_, B_, T_, freqs
rng = np.random.default_rng(1)
X = genos(rng, 20000)
C = np.corrcoef(X.T)
p = X.mean(0)/2
print('freq T %.3f A %.3f B %.3f' % (p[T_], p[A_], p[B_]))
print('r(T,A) %.3f r(T,B) %.3f r(A,B) %.3f' % (C[T_,A_], C[T_,B_], C[A_,B_]))
print('r(20,22) %.3f r(5,45) %.3f r(10, T) %.3f r(10,15) %.3f' % (C[20,22], C[5,45], C[10,T_], C[10,15]))
print('adjacent r2 mean %.3f' % np.mean([C[j,j+1]**2 for j in range(49) if j not in (24,25)]))
print('r T with 24, 26: %.3f %.3f' % (C[T_,24], C[T_,26]))
