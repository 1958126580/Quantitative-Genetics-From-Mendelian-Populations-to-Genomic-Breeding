# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_coloc.py    依赖：numpy
# coloc (Giambartolomei et al. 2014) computed from ABFs; summary-level simulation.
import numpy as np
m = 100
idx = np.arange(m)
R = 0.9 ** np.abs(idx[:, None] - idx[None, :])
Lc = np.linalg.cholesky(R)
rngf = np.random.default_rng(606)
maf = rngf.uniform(0.05, 0.5, m)
N1, N2 = 5000, 500
V1 = 1 / (2 * N1 * maf * (1 - maf)); V2 = 1 / (2 * N2 * maf * (1 - maf))
W = 0.15 ** 2


def labf(z, V):
    r = W / (V + W)
    return 0.5 * np.log(1 - r) + r * z * z / 2


def lse(x):
    mx = np.max(x)
    return mx + np.log(np.sum(np.exp(x - mx)))


def coloc(l1, l2, p1=1e-4, p2=1e-4, p12=1e-5):
    lH = np.array([0.0,
                   np.log(p1) + lse(l1),
                   np.log(p2) + lse(l2),
                   0.0,
                   np.log(p12) + lse(l1 + l2)])
    a, b = lse(l1) + lse(l2), lse(l1 + l2)
    lH[3] = np.log(p1) + np.log(p2) + a + np.log1p(-np.exp(b - a))
    return np.exp(lH - lse(lH)), lH


def sim_z(rng, lams):
    """lams: dict variant -> NCP; z ~ N(R @ lam_vec, R)"""
    lam = np.zeros(m)
    for j, v in lams.items():
        lam[j] = v
    return R @ lam + Lc @ rng.standard_normal(m)


print('prior mass per hypothesis for m=%d (p1=p2=1e-4, p12=1e-5): H1=H2=%.4g, H3=%.4g, H4=%.4g, H0=%.6f; prior odds H4:H3 = %.3f' % (
    m, m * 1e-4, m * (m - 1) * 1e-8, m * 1e-5, 1 - 2 * m * 1e-4 - m * (m - 1) * 1e-8 - m * 1e-5, (m * 1e-5) / (m * (m - 1) * 1e-8)))

SC = {
    '(a) shared causal 50': ({50: 7.0}, {50: 8.0}),
    '(b) distinct 50 vs 20 (r=%.3f)' % R[50, 20]: ({50: 7.0}, {20: 8.0}),
    '(c) distinct 50 vs 51 (r=0.9)': ({50: 7.0}, {51: 8.0}),
    '(d) trait only': ({50: 7.0}, {}),
    '(e) shared, weak eQTL (NCP 3)': ({50: 7.0}, {50: 3.0}),
    '(f) trait 2 signals (50 NCP 9, 80 NCP 6); eQTL at 80': ({50: 9.0, 80: 6.0}, {80: 8.0}),
}
print('\nN1=%d (trait), N2=%d (eQTL), W=0.15^2, AR LD rho=0.9, 1000 reps each' % (N1, N2))
for si, (nm, (la1, la2)) in enumerate(SC.items()):
    rng = np.random.default_rng(1300 + si)
    P = []
    for rep in range(1000):
        z1, z2 = sim_z(rng, la1), sim_z(rng, la2)
        pp, _ = coloc(labf(z1, V1), labf(z2, V2))
        P.append(pp)
    P = np.array(P)
    print(' %-52s mean PP0-4: %s | P(PP4>0.8) %.3f P(PP3>0.8) %.3f' % (nm, ' '.join('%.3f' % x for x in P.mean(0)), np.mean(P[:, 4] > 0.8), np.mean(P[:, 3] > 0.8)))

# worked example: one realisation of (a)
print('\nworked example, scenario (a), seed 2614')
rng = np.random.default_rng(2614)
z1, z2 = sim_z(rng, {50: 7.0}), sim_z(rng, {50: 8.0})
l1, l2 = labf(z1, V1), labf(z2, V2)
S1, S2, S12 = np.exp(lse(l1)), np.exp(lse(l2)), np.exp(lse(l1 + l2))
print(' z1[50] %.3f z2[50] %.3f; argmax z1 %d, argmax z2 %d' % (z1[50], z2[50], np.argmax(np.abs(z1)), np.argmax(np.abs(z2))))
print(' sum ABF1 %.4e  sum ABF2 %.4e  sum ABF1*ABF2 %.4e  S1*S2 - S12 %.4e' % (S1, S2, S12, S1 * S2 - S12))
pp, lH = coloc(l1, l2)
w = np.exp(lH)
print(' weights w0..w4: ' + ' '.join('%.4e' % x for x in w))
print(' PP0..PP4: ' + ' '.join('%.4f' % x for x in pp))
share = np.exp(l1 + l2 - lse(l1 + l2))
o = np.argsort(-share)[:4]
print(' per-variant share of H4 (SNP.PP.H4): ' + ', '.join('%d:%.3f' % (j, share[j]) for j in o))
print(' S12/(S1*S2) = %.4f' % (S12 / (S1 * S2)))
# p12 sensitivity for this realisation and for a realisation of (c)
rngc = np.random.default_rng(2615)
z1c, z2c = sim_z(rngc, {50: 7.0}), sim_z(rngc, {51: 8.0})
l1c, l2c = labf(z1c, V1), labf(z2c, V2)
print('\np12 sensitivity (PP3, PP4):')
for p12 in [1e-6, 5e-6, 1e-5, 5e-5]:
    a, _ = coloc(l1, l2, p12=p12); c, _ = coloc(l1c, l2c, p12=p12)
    print(' p12=%.0e | (a) PP3 %.4f PP4 %.4f | (c) PP3 %.4f PP4 %.4f' % (p12, a[3], a[4], c[3], c[4]))
print(' (c) realisation: argmax |z1| %d, argmax |z2| %d, z1[50] %.2f z1[51] %.2f z2[50] %.2f z2[51] %.2f' % (
    np.argmax(np.abs(z1c)), np.argmax(np.abs(z2c)), z1c[50], z1c[51], z2c[50], z2c[51]))
