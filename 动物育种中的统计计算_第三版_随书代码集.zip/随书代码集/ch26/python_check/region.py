# -*- coding: utf-8 -*-
"""Region genotype simulator for the fine-mapping examples (section 26.2).

50 loci; haplotype latent AR(1) with rho=0.9; allele frequencies ~ U(0.15,0.5)
(fixed by `freq_seed`); locus 25 ("T") is a haplotype tag: T = A OR B where
A = locus 15 and B = locus 35 (T flipped with prob 0.02).
"""
import numpy as np
from scipy.stats import norm

M = 50
A_, B_, T_ = 15, 35, 25


def freqs(freq_seed=77):
    rng = np.random.default_rng(freq_seed)
    p = rng.uniform(0.15, 0.5, M)
    p[A_] = p[B_] = 0.25
    return p


def haps(rng, nh, rho=0.9, p=None):
    if p is None:
        p = freqs()
    thr = norm.ppf(p)
    U = np.empty((nh, M))
    U[:, 0] = rng.standard_normal(nh)
    s = np.sqrt(1 - rho ** 2)
    E = rng.standard_normal((nh, M))
    for j in range(1, M):
        U[:, j] = rho * U[:, j - 1] + s * E[:, j]
    H = (U < thr).astype(np.int8)
    t = (H[:, A_] | H[:, B_]).astype(np.int8)
    flip = rng.random(nh) < 0.02
    t[flip] = 1 - t[flip]
    H[:, T_] = t
    return H


def genos(rng, n, rho=0.9, p=None):
    return (haps(rng, n, rho, p) + haps(rng, n, rho, p)).astype(float)
