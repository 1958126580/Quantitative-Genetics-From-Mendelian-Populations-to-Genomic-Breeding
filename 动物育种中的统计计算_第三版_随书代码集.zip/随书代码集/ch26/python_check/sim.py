# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 sim.py    依赖：numpy
"""Shared simulator + simplified BayesC Gibbs sampler for ch26 (section 26.1 additions).

Genotypes: each haplotype has a latent Gaussian AR(1) along the chromosome
    u_j = rho * u_{j-1} + sqrt(1-rho^2) * eps_j ,  rho = 0.98
allele = 1(u_j < t_j), where the thresholds t_j are themselves a smooth AR(1)
series (corr 0.97, sd 0.8) so that neighbouring loci have similar frequencies.
Genotype = sum of two independent haplotypes.
"""
import math
import numpy as np


def ar_series(rng, m, rho, sd=1.0):
    x = np.empty(m)
    x[0] = rng.standard_normal()
    s = math.sqrt(1 - rho ** 2)
    for j in range(1, m):
        x[j] = rho * x[j - 1] + s * rng.standard_normal()
    return sd * x


def sim_hap(rng, n, m, rho, thr):
    U = np.empty((n, m))
    U[:, 0] = rng.standard_normal(n)
    E = rng.standard_normal((n, m))
    s = math.sqrt(1 - rho ** 2)
    for j in range(1, m):
        U[:, j] = rho * U[:, j - 1] + s * E[:, j]
    return (U < thr).astype(np.int8)


# QTL design: (after-marker index k, share of sigma_g^2, sign)
QTL_DESIGN = [
    (229, 0.30, +1),
    (709, 0.20, -1),
    (1159, 0.15, +1),   # exactly on the 58 Mb window boundary
    (1405, 0.10, +1),
    (1413, 0.10, +1),   # same 1-Mb window as the previous one
    (1609, 0.08, -1),
    (1769, 0.05, +1),
    (1909, 0.02, -1),
]


def gen_data(seed, n=2000, m=2000, rho=0.98, h2=0.30, design=QTL_DESIGN,
             thr_rho=0.97, thr_sd=0.6, spacing_mb=0.05):
    rng = np.random.default_rng(seed)
    after = {k: (s, g) for k, s, g in design}
    # locus sequence: marker k, then (if any) the QTL inserted after marker k
    kinds = []
    for k in range(m):
        kinds.append(('M', k))
        if k in after:
            kinds.append(('Q', k))
    L = len(kinds)
    thr = ar_series(rng, L, thr_rho, thr_sd)
    G = sim_hap(rng, n, L, rho, thr) + sim_hap(rng, n, L, rho, thr)
    midx = [i for i, t in enumerate(kinds) if t[0] == 'M']
    qidx = [i for i, t in enumerate(kinds) if t[0] == 'Q']
    X = G[:, midx].astype(float)
    Q = G[:, qidx].astype(float)
    Qc = Q - Q.mean(0)
    qk = [kinds[i][1] for i in qidx]
    shares = np.array([after[k][0] for k in qk])
    signs = np.array([after[k][1] for k in qk])
    eff = signs * np.sqrt(shares / Qc.var(0))
    g = Qc @ eff
    ve = g.var() * (1 - h2) / h2
    e = rng.standard_normal(n) * math.sqrt(ve)
    y = 10.0 + g + e
    pos = (np.arange(m) + 0.5) * spacing_mb          # marker positions (Mb)
    qpos = (np.array(qk) + 1.0) * spacing_mb          # QTL positions (Mb)
    return dict(X=X, y=y, g=g, e=e, Q=Q, Qc=Qc, eff=eff, qk=np.array(qk),
                qpos=qpos, pos=pos, shares=shares, ve_true=ve, h2=h2)


def bayesc(X, y, pi=0.99, niter=11000, burn=1000, seed=1, h2_prior=0.5,
           nu_a=4.0, nu_e=4.0, batch=500, store_alpha=True, verbose=True):
    """Simplified BayesC (fixed pi) with Gibbs sampling; returns posterior summaries."""
    rng = np.random.default_rng(seed)
    n, m = X.shape
    Z = np.asfortranarray(X - X.mean(0))
    zz = (Z * Z).sum(0)
    sum2pq = Z.var(0).sum()
    vy = y.var()
    va_mean = h2_prior * vy / ((1 - pi) * sum2pq)
    S_a = va_mean * (nu_a - 2) / nu_a
    S_e = (1 - h2_prior) * vy * (nu_e - 2) / nu_e
    va, ve = va_mean, (1 - h2_prior) * vy
    mu = y.mean()
    a = np.zeros(m)
    d = np.zeros(m, dtype=np.int8)
    e = y - mu
    lpo = math.log((1 - pi) / pi)
    nkeep = niter - burn
    alpha_s = np.zeros((nkeep, m), dtype=np.float32) if store_alpha else None
    pip_d = np.zeros(m)
    pip_rb = np.zeros(m)
    nb = nkeep // batch
    bm_d = np.zeros((nb, m))
    bm_rb = np.zeros((nb, m))
    tr_ve = np.zeros(niter); tr_va = np.zeros(niter); tr_m1 = np.zeros(niter, dtype=int)
    p1v = np.zeros(m)
    for it in range(niter):
        # intercept
        e += mu
        mu = e.mean() + math.sqrt(ve / n) * rng.standard_normal()
        e -= mu
        u = rng.random(m)
        nr = rng.standard_normal(m)
        for j in range(m):
            zj = Z[:, j]
            aj = a[j]
            rhs = zj @ e + zz[j] * aj
            C = zz[j] + ve / va
            lg = lpo - 0.5 * math.log(va * C / ve) + rhs * rhs / (2 * ve * C)
            if lg > 0:
                p1 = 1.0 / (1.0 + math.exp(-lg))
            else:
                t = math.exp(lg)
                p1 = t / (1.0 + t)
            p1v[j] = p1
            if u[j] < p1:
                new = rhs / C + math.sqrt(ve / C) * nr[j]
                d[j] = 1
            else:
                new = 0.0
                d[j] = 0
            if new != aj:
                e -= zj * (new - aj)
                a[j] = new
        m1 = int(d.sum())
        va = (float((a[d == 1] ** 2).sum()) + nu_a * S_a) / rng.chisquare(nu_a + m1)
        ve = (float(e @ e) + nu_e * S_e) / rng.chisquare(nu_e + n)
        tr_ve[it] = ve; tr_va[it] = va; tr_m1[it] = m1
        if it >= burn:
            k = it - burn
            if store_alpha:
                alpha_s[k] = a
            pip_d += d
            pip_rb += p1v
            b = k // batch
            if b < nb:
                bm_d[b] += d
                bm_rb[b] += p1v
        if verbose and (it + 1) % 1000 == 0:
            print('iter', it + 1, 'm1', m1, 've %.4f va %.6f' % (ve, va), flush=True)
    return dict(alpha=alpha_s, pip_d=pip_d / nkeep, pip_rb=pip_rb / nkeep,
                bm_d=bm_d / batch, bm_rb=bm_rb / batch, tr_ve=tr_ve, tr_va=tr_va,
                tr_m1=tr_m1, S_a=S_a, S_e=S_e, va_prior_mean=va_mean, burn=burn,
                niter=niter)


def window_props(Zc, alpha, size, offset=0):
    """Posterior samples of Var(Z_w a_w)/Var(Z a) for consecutive windows of
    `size` markers, the first window starting at marker `offset` (markers before
    `offset` form an extra leading partial window, index 0 when offset>0)."""
    T, m = alpha.shape
    lead = 1 if offset > 0 else 0
    W = lead + int(math.ceil((m - offset) / size))
    out = np.zeros((T, W), dtype=np.float32)
    for t in range(T):
        a = alpha[t].astype(float)
        nz = np.nonzero(a)[0]
        if nz.size == 0:
            continue
        contrib = Zc[:, nz] * a[nz]
        vt = contrib.sum(1).var()
        widx = np.where(nz < offset, 0, (nz - offset) // size + lead)
        uw, inv = np.unique(widx, return_inverse=True)
        Ind = np.zeros((nz.size, uw.size))
        Ind[np.arange(nz.size), inv] = 1.0
        gw = contrib @ Ind
        out[t, uw] = gw.var(0) / vt
    return out


def random_design(seed, m=2000, nqtl=20, mingap=5):
    """Random QTL design for calibration replicates: after-marker indices drawn
    uniformly (at least `mingap` markers apart), effects ~ N(0,1)."""
    rng = np.random.default_rng(seed + 100000)
    ks = []
    while len(ks) < nqtl:
        k = int(rng.integers(0, m - 1))
        if all(abs(k - x) >= mingap for x in ks):
            ks.append(k)
    ks.sort()
    return ks, rng.standard_normal(nqtl)


def gen_data_random(seed, n=2000, m=2000, rho=0.98, h2=0.30, nqtl=20,
                    thr_rho=0.97, thr_sd=0.6, spacing_mb=0.05):
    ks, beta = random_design(seed, m, nqtl)
    rng = np.random.default_rng(seed)
    kinds = []
    kset = set(ks)
    for k in range(m):
        kinds.append(('M', k))
        if k in kset:
            kinds.append(('Q', k))
    L = len(kinds)
    thr = ar_series(rng, L, thr_rho, thr_sd)
    G = sim_hap(rng, n, L, rho, thr) + sim_hap(rng, n, L, rho, thr)
    midx = [i for i, t in enumerate(kinds) if t[0] == 'M']
    qidx = [i for i, t in enumerate(kinds) if t[0] == 'Q']
    X = G[:, midx].astype(float)
    Q = G[:, qidx].astype(float)
    Qc = Q - Q.mean(0)
    g = Qc @ beta
    ve = g.var() * (1 - h2) / h2
    e = rng.standard_normal(n) * math.sqrt(ve)
    y = 10.0 + g + e
    return dict(X=X, y=y, g=g, Qc=Qc, eff=beta, qk=np.array(ks), h2=h2)
