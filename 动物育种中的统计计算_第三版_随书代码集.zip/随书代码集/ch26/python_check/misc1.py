# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 26 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 misc1.py    依赖：numpy
# Miscellaneous numbers for the text (section 26.1 tables and 26.2/26.3 rules of thumb)
import numpy as np
from sim import gen_data
D = gen_data(2026)
X = D['X']; Zc = X - X.mean(0); Qc = D['Qc']; qk = D['qk']; qpos = D['qpos']; pos = D['pos']
S = np.load('main_summary.npz')
pd1, pd2, pv = S['pd1'], S['pd2'], S['pv']
print('== per-QTL neighbourhood table (markers k-9..k+10)')
for i, k in enumerate(qk):
    js = np.arange(k - 9, k + 11)
    o = js[np.argsort(-pd1[js])][:2]
    parts = []
    for j in o:
        r2 = np.corrcoef(Qc[:, i], Zc[:, j])[0, 1] ** 2
        parts.append('m%d pos %.3f dist %+.3f Mb r2 %.3f PIP %.3f/%.3f p %.1e' % (j, pos[j], pos[j] - qpos[i], r2, pd1[j], pd2[j], pv[j]))
    nsig = (pv[js] < 0.05 / 2000).sum()
    print('Q%d (%.2f Mb): sumPIP %.3f | %s | nsig(+-10) %d | n PIP>0.5 in +-10: %d' % (i + 1, qpos[i], pd1[js].sum(), ' ; '.join(parts), nsig, (pd1[js] > 0.5).sum()))
print('\n== prior WPPA baseline by window size (pi=0.99)')
for s in [5, 10, 20, 50]:
    print(' size %d: %.4f' % (s, 1 - 0.99 ** s))
print('\n== resolution rule: r2 threshold = 1 - 2 ln 19 / (r_W * lam^2), r_W = W/(V+W), N=2000, W=0.15^2')
rW = 0.15 ** 2 / (1 / 2000 + 0.15 ** 2)
print(' r_W %.4f, 2ln19 %.4f, 2ln19/r_W %.4f' % (rW, 2 * np.log(19), 2 * np.log(19) / rW))
for lam in [5, 8, 12]:
    print(' lam %d: r2* = %.4f' % (lam, 1 - 2 * np.log(19) / rW / lam ** 2))
print('\n== S4 expected marginal z ratio from population r: (0.646+0.642)/(1+0.063) = %.4f' % ((0.646 + 0.642) / (1 + 0.063)))
print('\n== chain products')
for v in [(0.8, 0.8, 0.8), (0.6, 0.8), (0.95, 0.9, 0.7), (0.9, 0.9, 0.9, 0.9)]:
    print(' ', v, '%.4f' % np.prod(v))
print('\n== reference panel variance approx: 1 + z^2 var(r)/(1-r^2), r=0.95')
for z, sds in [(10, [0.0256, 0.0113, 0.0056]), (20, [0.0255, 0.0111, 0.0056])]:
    print(' z %d: ' % z + ', '.join('sd_r %.4f -> var %.3f sd %.3f' % (s, 1 + z * z * s * s / (1 - 0.9025), np.sqrt(1 + z * z * s * s / (1 - 0.9025))) for s in sds))
print(' Var(r_hat) ~ (1-r^2)^2/n (bivariate normal): n=100 sd %.4f, 500 %.4f, 2000 %.4f' % tuple((1 - 0.9025) / np.sqrt(n) for n in [100, 500, 2000]))
print('\n== LD clump design effect: (15.31/4.07)^2 = %.3f; mean SNPs per locus 862/30 = %.3f; implied rho_intra = %.3f' % ((15.31 / 4.07) ** 2, 862 / 30, ((15.31 / 4.07) ** 2 - 1) / (862 / 30 - 1)))
print('\n== coloc prior odds H4:H3 = p12/((m-1) p1 p2): m=100 %.3f, m=1000 %.3f, m=10 %.3f' % (1e-5 / (99 * 1e-8), 1e-5 / (999 * 1e-8), 1e-5 / (9 * 1e-8)))
