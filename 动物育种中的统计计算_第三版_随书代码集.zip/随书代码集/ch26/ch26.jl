# 本脚本由 tools/nb2jl.py 从同目录的 ch26.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 26

# %% [markdown]
# # 第二十六章　贝叶斯 GWAS、窗口方差与精细定位 —— 配套代码
#
# 本 Notebook 对应第二十六章。
#
# **内容**
#
# 1. BayesC 的 Gibbs 抽样（复用第二十二章框架），收集 $\boldsymbol\delta^{(t)}$ 与 $\boldsymbol\alpha^{(t)}$
# 2. PIP、**WPPA**（正文式 26.3）与贝叶斯因子（式 26.4）
# 3. **窗口遗传方差**（式 26.5–26.8），含协方差项的正确计算
# 4. 窗口大小的稳健性检查
# 5. **穷举式贝叶斯精细定位**：小区域上的精确 PIP（式 26.10–26.11）与可信集（式 26.12）
# 6. **SuSiE**：单效应回归（式 26.17–26.19）与 IBSS 算法（算法 26.1）
# 7. 式 (26.18) 的 ABF 与第二十二章式 (22.26) 的等价性验证
# 8. 基于汇总统计量的精细定位与 LD 面板不匹配的后果

# %%
using LinearAlgebra, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
rand_scaled_inv_chisq(rng, nu, S) = nu*S / rand(rng, Chisq(nu))
@inline logistic(x) = 1/(1 + exp(-x))
println("Julia ", VERSION)

# %%
"""按系谱做配子传递的简化模拟（与第二十一、二十三章相同），返回基因型、系谱与世代。"""
function sim_pedigree_genotypes(nbase::Int, ngen::Int, nper::Int, m::Int;
                                nchr::Int=10, r::Float64=0.02,
                                maf_min::Float64=0.05, rng=Random.default_rng())
    n = nbase + ngen*nper
    p0 = maf_min .+ (1 - 2maf_min) .* rand(rng, m)
    H = Array{Int8,3}(undef, n, m, 2)
    @inbounds for i in 1:nbase, j in 1:m, k in 1:2
        H[i,j,k] = Int8(rand(rng) < p0[j])
    end
    sire = zeros(Int, n); dam = zeros(Int, n); gen = zeros(Int, n)
    mper = m ÷ nchr
    @inbounds for g in 1:ngen
        lo = nbase + (g-1)*nper + 1; hi = nbase + g*nper; pool = lo - 1
        for i in lo:hi
            gen[i] = g
            s = rand(rng, 1:pool); d = rand(rng, 1:pool)
            while d == s; d = rand(rng, 1:pool); end
            sire[i] = s; dam[i] = d
            for (par, k) in ((s,1), (d,2))
                for c in 1:nchr
                    cur = rand(rng, 1:2)
                    for jj in 1:mper
                        j = (c-1)*mper + jj; j > m && break
                        if jj > 1 && rand(rng) < r; cur = 3 - cur; end
                        H[i,j,k] = H[par,j,cur]
                    end
                end
            end
        end
    end
    Mg = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        Mg[i,j] = Float64(H[i,j,1]) + Float64(H[i,j,2])
    end
    chrom = [min(nchr, (j-1) ÷ mper + 1) for j in 1:m]
    return Mg, sire, dam, gen, chrom
end

# %% [markdown]
# ## 1　BayesC 抽样并收集 $\delta$ 与 $\alpha$

# %%
"""BayesC 的 Gibbs 抽样，额外收集 δ 与 α 的全部样本（用于 PIP/WPPA/窗口方差）。"""
function bayesC_gwas(y::Vector{Float64}, X::Matrix{Float64}, Z::Matrix{Float64};
                     pi0::Float64=0.95, s2A::Float64=0.5, sum2pq::Float64=1.0,
                     nu::Float64=4.0, niter::Int=12_000, burnin::Int=3_000,
                     estimate_pi::Bool=true, rng=Random.default_rng())
    n, m = size(Z); p = size(X,2)
    zz = [dot(view(Z,:,j), view(Z,:,j)) for j in 1:m]
    xx = [dot(view(X,:,l), view(X,:,l)) for l in 1:p]
    S  = (nu-2)/nu * s2A/((1-pi0)*sum2pq)
    s2a = nu*S/(nu-2); s2e = var(y)/2
    beta = zeros(p); beta[1] = mean(y)
    alpha = zeros(m); delta = falses(m)
    e = y .- X*beta
    nsave = niter - burnin
    Dsum = zeros(m); Asum = zeros(m)
    Dchain = falses(m, nsave); Achain = zeros(m, nsave)
    pichain = Float64[]; ks = 0
    @inbounds for it in 1:niter
        for l in 1:p
            xl = view(X,:,l); old = beta[l]
            rhs = dot(xl, e) + xx[l]*old
            beta[l] = rhs/xx[l] + randn(rng)*sqrt(s2e/xx[l])
            @simd for i in 1:n; e[i] -= xl[i]*(beta[l]-old); end
        end
        for j in 1:m
            zj = view(Z,:,j); a0 = alpha[j]
            rhs = dot(zj, e) + zz[j]*a0
            Cj  = zz[j] + s2e/s2a
            lg  = log((1-pi0)/pi0) - 0.5*log(s2a*Cj/s2e) + rhs^2/(2*s2e*Cj)
            delta[j] = rand(rng) < logistic(lg)
            alpha[j] = delta[j] ? rhs/Cj + randn(rng)*sqrt(s2e/Cj) : 0.0
            d = alpha[j] - a0
            if d != 0.0
                @simd for i in 1:n; e[i] -= zj[i]*d; end
            end
        end
        m1 = count(delta)
        ssq = 0.0
        for j in 1:m; delta[j] && (ssq += alpha[j]^2); end
        s2a = rand_scaled_inv_chisq(rng, nu + m1, (ssq + nu*S)/(nu + m1))
        if estimate_pi
            pi0 = clamp(rand(rng, Beta(1 + m - m1, 1 + m1)), 1e-6, 1-1e-6)
            S   = (nu-2)/nu * s2A/((1-pi0)*sum2pq)
        end
        s2e = rand_scaled_inv_chisq(rng, 4.0 + n, (dot(e,e) + 4.0*var(y)/2)/(4.0 + n))
        if it % 200 == 0
            e .= y .- X*beta .- Z*alpha
        end
        if it > burnin
            ks += 1
            Dsum .+= delta; Asum .+= alpha
            Dchain[:, ks] .= delta; Achain[:, ks] .= alpha
            push!(pichain, pi0)
        end
    end
    return (pip = Dsum ./ ks, alpha = Asum ./ ks,
            dchain = view(Dchain, :, 1:ks), achain = view(Achain, :, 1:ks),
            pi_chain = pichain, nsave = ks)
end

# %%
# 模拟：一条染色体，少数 QTL，强 LD
Mg, sire, dam, gen, chrom = sim_pedigree_genotypes(120, 5, 140, 600;
                                                   nchr=3, r=0.01, rng=Xoshiro(2601))
n = size(Mg,1)
pf = vec(mean(Mg, dims=1)) ./ 2
keep = findall(j -> 0.03 < pf[j] < 0.97, eachindex(pf))
Mg = Mg[:, keep]; pf = pf[keep]; chrom = chrom[keep]; m = length(keep)
Z = Mg .- 2 .* pf'
sum2pq = 2*sum(pf .* (1 .- pf))

qtl = [60, 180, 340]
aq  = [1.0, -0.8, 0.6]
g   = Z[:, qtl]*aq
h2  = 0.5
g  .*= sqrt(h2)/std(g)
y   = 10.0 .+ g .+ randn(Xoshiro(2602), n).*sqrt(1-h2)
X   = ones(n, 1)
@printf("n = %d ， m = %d ， 真实 QTL 在 %s\n", n, m, string(qtl))

# 检查 QTL 附近的 LD
for j in qtl
    lo = max(1, j-10); hi = min(m, j+10)
    r2s = [cor(view(Z,:,j), view(Z,:,k))^2 for k in lo:hi if k != j]
    @printf("  QTL %3d 附近 ±10 标记的 r² 中位数 = %.3f ，最大 = %.3f\n",
            j, median(r2s), maximum(r2s))
end

res = bayesC_gwas(y, X, Z; pi0=0.98, s2A=h2, sum2pq=sum2pq,
                  niter=15_000, burnin=4_000, rng=Xoshiro(2603))
@printf("\nπ̂（零效应比例）后验均值 = %.4f ，95%% 区间 [%.4f, %.4f]\n",
        mean(res.pi_chain), quantile(res.pi_chain, 0.025), quantile(res.pi_chain, 0.975))
@printf("PIP 最大的 8 个标记：\n")
for j in sortperm(res.pip; rev=true)[1:8]
    @printf("  标记 %4d  PIP = %.3f  α̂ = %+.4f %s\n", j, res.pip[j], res.alpha[j],
            j in qtl ? "  ← 真实 QTL" : "")
end
@printf("\n真实 QTL 的 PIP：%s\n", string(round.(res.pip[qtl], digits=3)))
println("=> 强 LD 使单标记 PIP 被稀释（正文 §26.1.2）——下面用 WPPA 解决。")

# %% [markdown]
# ## 2　WPPA 与贝叶斯因子（正文式 26.3–26.4）

# %%
"""正文式 (26.3)：窗口后验包含概率。"""
function wppa(dchain::AbstractMatrix, windows::Vector{UnitRange{Int}})
    T = size(dchain, 2)
    out = zeros(length(windows))
    for (w, rg) in enumerate(windows)
        cnt = 0
        @inbounds for t in 1:T
            any(view(dchain, rg, t)) && (cnt += 1)
        end
        out[w] = cnt/T
    end
    return out
end

"""正文式 (26.4)：相对先验基线的贝叶斯因子。"""
function wppa_bf(w::Float64, pi0::Float64, nw::Int)
    prior = 1 - pi0^nw
    return (w/(1-w)) / (prior/(1-prior))
end

make_windows(m::Int, sz::Int) = [i:min(i+sz-1, m) for i in 1:sz:m]

wins = make_windows(m, 20)
W = wppa(res.dchain, wins)
pi_hat = mean(res.pi_chain)
@printf("窗口大小 20，共 %d 个窗口；先验 WPPA = %.4f\n\n", length(wins), 1 - pi_hat^20)
@printf("%-10s%-16s%-12s%-12s%-10s\n", "窗口", "标记范围", "WPPA", "BF", "含 QTL")
for w in sortperm(W; rev=true)[1:10]
    rg = wins[w]
    @printf("%-10d%-16s%-12.3f%-12.1f%-10s\n", w, "$(first(rg))–$(last(rg))",
            W[w], wppa_bf(W[w], pi_hat, length(rg)),
            any(q -> q in rg, qtl) ? "✔" : "")
end
@printf("\n三个真实 QTL 所在窗口的 WPPA： ")
for q in qtl
    w = findfirst(rg -> q in rg, wins)
    @printf("%.3f  ", W[w])
end
println("\n=> 与单标记 PIP 相比，WPPA 正确地把信号报告了出来。")

# %% [markdown]
# ## 3　窗口遗传方差（正文式 26.5–26.8）
#
# **必须用样本方差**，因为它自动包含窗口内标记间的协方差项（式 26.7）。

# %%
"""正文式 (26.5)–(26.6)：窗口解释的遗传方差比例的后验分布。"""
function window_var(Z::AbstractMatrix, achain::AbstractMatrix,
                    windows::Vector{UnitRange{Int}}; thin::Int=10)
    T = size(achain, 2); ts = 1:thin:T
    out = zeros(length(windows), length(ts))
    gt  = Vector{Float64}(undef, size(Z,1))
    for (k, t) in enumerate(ts)
        at = view(achain, :, t)
        mul!(gt, Z, at)
        vtot = var(gt)
        for (w, rg) in enumerate(windows)
            gw = view(Z, :, rg)*view(at, rg)
            out[w, k] = vtot > 0 ? var(gw)/vtot : 0.0
        end
    end
    return out
end

"""错误做法：忽略窗口内的协方差项（正文式 26.7 的反例）。"""
function window_var_naive(Z, achain, windows, p; thin=10)
    T = size(achain,2); ts = 1:thin:T
    twopq = 2 .* p .* (1 .- p)
    out = zeros(length(windows), length(ts))
    for (k,t) in enumerate(ts)
        at = view(achain,:,t)
        tot = sum(twopq .* at.^2)
        for (w, rg) in enumerate(windows)
            out[w,k] = tot > 0 ? sum(view(twopq,rg) .* view(at,rg).^2)/tot : 0.0
        end
    end
    return out
end

WV  = window_var(Z, res.achain, wins; thin=10)
WVn = window_var_naive(Z, res.achain, wins, pf; thin=10)

@printf("%-10s%-16s%-14s%-22s%-14s%-10s\n",
        "窗口", "标记范围", "ρ_w 均值", "95%% 区间", "P(ρ_w>1%)", "忽略协方差")
for w in sortperm(vec(mean(WV; dims=2)); rev=true)[1:8]
    rg = wins[w]; v = view(WV, w, :)
    @printf("%-10d%-16s%-14.4f[%.4f, %.4f]     %-14.3f%-10.4f\n", w,
            "$(first(rg))–$(last(rg))", mean(v),
            quantile(v, 0.025), quantile(v, 0.975),
            mean(>(0.01), v), mean(view(WVn, w, :)))
end
@printf("\n三个真实 QTL 窗口的 ρ_w 之和 = %.3f\n",
        sum(mean(view(WV, findfirst(rg -> q in rg, wins), :)) for q in qtl))
println("=> 最后一列（忽略协方差）系统性偏离——正文式 (26.7) 的警告。")

# %% [markdown]
# ### 3.1 窗口大小的稳健性

# %%
println("同一数据、不同窗口大小的结论比较\n")
@printf("%-12s%-14s%-40s\n", "窗口大小", "窗口数", "WPPA>0.5 的窗口所含的真实 QTL")
for sz in (10, 20, 40, 80)
    ws = make_windows(m, sz)
    Ww = wppa(res.dchain, ws)
    hot = findall(>(0.5), Ww)
    hitq = [q for q in qtl if any(w -> q in ws[w], hot)]
    @printf("%-12d%-14d%-40s\n", sz, length(ws),
            "$(length(hot)) 个热点窗口，命中 QTL $(hitq)")
end
println("\n=> 三个真实 QTL 在所有窗口大小下都被检出——结论稳健（正文 §26.1.4）。")

# %% [markdown]
# ## 4　穷举式贝叶斯精细定位（正文式 26.10–26.12）
#
# 在一个小区域（$m_w\le 20$）上枚举全部 $2^{m_w}$ 个模型，得到**精确**的 PIP。

# %%
"""单个模型的边际似然（对 β、α 用 g-先验的近似；这里用式 26.18 的 ABF 乘积）。

为保持可控，限制因果变异数 ≤ L。
"""
function exhaustive_pip(y::Vector{Float64}, Zw::Matrix{Float64};
                        sigma0::Float64=0.2, prior_p::Float64=0.01, L::Int=3)
    n, mw = size(Zw)
    yc = y .- mean(y)
    logml = Dict{Vector{Int},Float64}()
    # 枚举大小 ≤ L 的子集
    function logml_model(S::Vector{Int})
        isempty(S) && return -0.5*dot(yc,yc)          # 只到相差一个常数
        Zs = view(Zw, :, S)
        A  = Zs'Zs + (1/sigma0^2)*I
        Fc = cholesky(Symmetric(A))
        b  = Fc \ (Zs'yc)
        rss = dot(yc,yc) - dot(Zs'yc, b)
        return -0.5*rss - 0.5*logdet(Fc) - length(S)*log(sigma0)
    end
    models = Vector{Vector{Int}}()
    push!(models, Int[])
    for l in 1:L
        for S in combinations_idx(mw, l); push!(models, S); end
    end
    lp = Float64[]
    for S in models
        push!(lp, logml_model(S) + length(S)*log(prior_p) + (mw-length(S))*log(1-prior_p))
    end
    mx = maximum(lp); w = exp.(lp .- mx); w ./= sum(w)
    pip = zeros(mw)
    for (k, S) in enumerate(models), j in S
        pip[j] += w[k]
    end
    return pip, models, w
end

"""生成 1:m 中大小为 l 的全部组合（下标向量）。"""
function combinations_idx(m::Int, l::Int)
    out = Vector{Vector{Int}}()
    idx = collect(1:l)
    while true
        push!(out, copy(idx))
        i = l
        while i >= 1 && idx[i] == m - l + i; i -= 1; end
        i == 0 && break
        idx[i] += 1
        for k in i+1:l; idx[k] = idx[k-1] + 1; end
    end
    return out
end

"""正文式 (26.12)：ρ-可信集。"""
function credible_set(pip::Vector{Float64}; rho=0.95)
    o = sortperm(pip; rev=true); c = 0.0; out = Int[]
    for j in o
        push!(out, j); c += pip[j]
        c >= rho && break
    end
    return sort(out), c
end

# 取 QTL 60 附近的 16 个标记
reg = 53:68
Zw = Z[:, reg]
pip_ex, models, wm = exhaustive_pip(y, Zw; sigma0=0.3, prior_p=0.05, L=3)
cs, cov_ = credible_set(pip_ex; rho=0.95)
@printf("区域 %s 的穷举精细定位（枚举 %d 个模型）\n", string(reg), length(models))
@printf("真实 QTL 位于区域内下标 %d\n\n", 60 - first(reg) + 1)
for j in sortperm(pip_ex; rev=true)[1:6]
    @printf("  区域内下标 %2d （全局 %3d）  PIP = %.4f %s\n",
            j, first(reg)+j-1, pip_ex[j], first(reg)+j-1 == 60 ? " ← 真实 QTL" : "")
end
@printf("\n95%% 可信集大小 = %d ，累计 PIP = %.3f ，%s真实 QTL\n",
        length(cs), cov_, (60 - first(reg) + 1) in cs ? "包含" : "不包含")

# %% [markdown]
# ## 5　SuSiE：单效应回归与 IBSS（正文式 26.13–26.19、算法 26.1）

# %%
"""正文式 (26.17)–(26.19)：单效应回归（SER）。

返回 (α 向量, 后验均值 b̄, 后验二阶矩 b2)。
"""
function single_effect_regression(r::Vector{Float64}, Z::Matrix{Float64},
                                  sigma2::Float64, sigma0_2::Float64,
                                  prior::Vector{Float64})
    m = size(Z,2)
    zz = [dot(view(Z,:,j), view(Z,:,j)) for j in 1:m]
    bhat = [dot(view(Z,:,j), r)/zz[j] for j in 1:m]
    s2   = sigma2 ./ zz                                   # 式 (26.17)
    # 式 (26.18) 的对数 ABF
    lbf = @. 0.5*log(s2/(s2 + sigma0_2)) + 0.5*sigma0_2*bhat^2/(s2*(s2 + sigma0_2))
    lw  = log.(prior) .+ lbf
    mx  = maximum(lw); w = exp.(lw .- mx); w ./= sum(w)   # 式 (26.19) 的 α
    post_var  = @. 1/(1/s2 + 1/sigma0_2)
    post_mean = @. post_var/s2 * bhat
    return w, post_mean, post_var .+ post_mean.^2
end

"""算法 26.1：IBSS（Iterative Bayesian Stepwise Selection）。"""
function susie(y::Vector{Float64}, Z::Matrix{Float64}; L::Int=5,
               sigma2::Float64=NaN, sigma0_2::Float64=0.2,
               maxiter::Int=200, tol::Float64=1e-6)
    n, m = size(Z)
    yc = y .- mean(y)
    Zc = Z .- mean(Z; dims=1)
    isnan(sigma2) && (sigma2 = var(yc))
    prior = fill(1/m, m)
    A = zeros(L, m)          # α_{lj}
    B = zeros(L, m)          # b̄_{lj}
    post = zeros(L, m)       # α_{lj} b̄_{lj}
    fit = zeros(n)
    prev = -Inf
    for it in 1:maxiter
        for l in 1:L
            # 去掉第 l 个单效应的拟合
            fl = Zc*vec(view(post, l, :))
            r  = yc .- fit .+ fl
            w, bm, b2 = single_effect_regression(r, Zc, sigma2, sigma0_2, prior)
            A[l, :] .= w; B[l, :] .= bm
            post[l, :] .= w .* bm
            fit .= fit .- fl .+ Zc*vec(view(post, l, :))
        end
        rss = sum((yc .- fit).^2)
        sigma2 = rss/n
        if abs(rss - prev) < tol*max(1.0, abs(prev)); break; end
        prev = rss
    end
    pip = 1 .- vec(prod(1 .- A; dims=1))       # 式 (26.16)
    return (alpha=A, b=B, pip=pip, sigma2=sigma2, fit=fit)
end

"""SuSiE 的每个单效应的可信集（式 26.15）与"纯度"。"""
function susie_credible_sets(A::Matrix{Float64}, Z::Matrix{Float64};
                             rho=0.95, min_purity=0.5)
    L, m = size(A); out = NamedTuple[]
    for l in 1:L
        o = sortperm(view(A, l, :); rev=true); c = 0.0; S = Int[]
        for j in o
            push!(S, j); c += A[l, j]
            c >= rho && break
        end
        # 纯度：集合内最小绝对相关
        pur = length(S) == 1 ? 1.0 :
              minimum(abs(cor(view(Z,:,a), view(Z,:,b))) for a in S for b in S if a < b)
        pur >= min_purity && push!(out, (l=l, set=sort(S), coverage=c, purity=pur))
    end
    return out
end

sus = susie(y, Z; L=6, sigma0_2=0.05)
@printf("SuSiE（L = 6）\n")
@printf("  PIP 最大的 8 个标记：\n")
for j in sortperm(sus.pip; rev=true)[1:8]
    @printf("    标记 %4d  PIP = %.4f %s\n", j, sus.pip[j], j in qtl ? " ← 真实 QTL" : "")
end
@printf("\n  真实 QTL 的 PIP：%s\n", string(round.(sus.pip[qtl], digits=3)))

css = susie_credible_sets(sus.alpha, Z; rho=0.95, min_purity=0.3)
@printf("\n  通过纯度筛选的可信集 %d 个（L = 6）：\n", length(css))
for c in css
    hit = [q for q in qtl if q in c.set]
    @printf("    CS%-3d 大小 %-4d 覆盖 %.3f 纯度 %.3f  范围 %d–%d %s\n",
            c.l, length(c.set), c.coverage, c.purity,
            minimum(c.set), maximum(c.set),
            isempty(hit) ? "" : "  ← 含真实 QTL $(hit)")
end
println("\n=> 每个可信集对应一个独立信号——这正是 SuSiE 的关键优势（正文 §26.2.4）。")

# %% [markdown]
# ## 6　ABF 与第二十二章式 (22.26) 的等价性（正文思考题 5）

# %%
# 令 s² = σe²/(z'z)、σ₀² = σ²_{α_j}，验证两式给出相同的对数贝叶斯因子
let rng = Xoshiro(99)
    for _ in 1:4
        zz  = 50 + 500*rand(rng)
        s2e = 0.3 + rand(rng)
        s2a = 0.001 + 0.05*rand(rng)
        rhs = randn(rng)*10
        # 第二十二章式 (22.26)
        Cj  = zz + s2e/s2a
        lbf22 = -0.5*log(s2a*Cj/s2e) + rhs^2/(2*s2e*Cj)
        # 第二十六章式 (26.18)
        bhat = rhs/zz; s2 = s2e/zz
        lbf26 = 0.5*log(s2/(s2 + s2a)) + 0.5*s2a*bhat^2/(s2*(s2 + s2a))
        @printf("z'z=%7.1f σe²=%.3f σα²=%.4f :  式(22.26)=%.10f  式(26.18)=%.10f  差=%.2e\n",
                zz, s2e, s2a, lbf22, lbf26, abs(lbf22-lbf26))
    end
end
println("\n=> 两式完全等价（正文思考题 5）。")

# %% [markdown]
# ## 7　基于汇总统计量的精细定位与 LD 面板不匹配
#
# 正文式 (26.20)：$\mathbf Z'\mathbf y$ 与 $\mathbf Z'\mathbf Z/N$ 就是 $z$ 统计量与 LD 矩阵。

# %%
"""SuSiE-RSS：只用 (z 统计量, LD 矩阵, n) 的版本。

在标准化编码下，SER 只依赖 z'r 与 z'z，可以用 R 与 z 重建。
"""
function susie_rss(z::Vector{Float64}, R::Matrix{Float64}, n::Int;
                   L::Int=5, sigma0_2::Float64=0.2, maxiter::Int=200)
    m = length(z)
    prior = fill(1/m, m)
    A = zeros(L, m); B = zeros(L, m); post = zeros(L, m)
    Rb = zeros(m)                             # R * Σ_l post_l
    for it in 1:maxiter
        for l in 1:L
            Rl = R*vec(view(post, l, :))
            # 边际 z 的"残差"版本
            zr = z .- (Rb .- Rl)
            bhat = zr ./ sqrt(n)              # 标准化编码下 z'z = n
            s2   = fill(1/n, m)
            lbf  = @. 0.5*log(s2/(s2 + sigma0_2)) + 0.5*sigma0_2*bhat^2/(s2*(s2+sigma0_2))
            lw = log.(prior) .+ lbf
            mx = maximum(lw); w = exp.(lw .- mx); w ./= sum(w)
            pv = @. 1/(1/s2 + 1/sigma0_2)
            pm = @. pv/s2 * bhat
            A[l,:] .= w; B[l,:] .= pm
            newpost = w .* pm
            Rb .= Rb .- Rl .+ R*newpost
            post[l,:] .= newpost
        end
    end
    return (alpha=A, pip = 1 .- vec(prod(1 .- A; dims=1)))
end

# 用样本内 LD
Zs = (Z .- mean(Z; dims=1)) ./ std(Z; dims=1)
zstat = [begin
            zj = view(Zs,:,j); a = dot(zj, y .- mean(y))/dot(zj,zj)
            se = sqrt(var(y .- mean(y))/dot(zj,zj)); a/se
         end for j in 1:m]
R_in = cor(Zs); R_in[isnan.(R_in)] .= 0.0

rss_in = susie_rss(zstat, R_in, n; L=6, sigma0_2=0.05)
@printf("SuSiE-RSS（样本内 LD）：真实 QTL 的 PIP = %s\n",
        string(round.(rss_in.pip[qtl], digits=3)))
@printf("  与个体数据 SuSiE 的 PIP 相关 = %.4f\n", cor(rss_in.pip, sus.pip))

# 用"另一个群体"的 LD（不匹配）
Mg2, _, _, _, _ = sim_pedigree_genotypes(120, 5, 140, 600; nchr=3, r=0.01, rng=Xoshiro(7777))
Z2 = Mg2[:, keep]
Z2s = (Z2 .- mean(Z2; dims=1)) ./ max.(std(Z2; dims=1), 1e-8)
R_out = cor(Z2s); R_out[isnan.(R_out)] .= 0.0
rss_out = susie_rss(zstat, R_out, n; L=6, sigma0_2=0.05)
@printf("\nSuSiE-RSS（不匹配的 LD 面板）：真实 QTL 的 PIP = %s\n",
        string(round.(rss_out.pip[qtl], digits=3)))
@printf("  与个体数据 SuSiE 的 PIP 相关 = %.4f\n", cor(rss_out.pip, sus.pip))
@printf("  两个 LD 矩阵的元素相关 = %.4f\n", cor(vec(R_in), vec(R_out)))
println("\n=> LD 面板不匹配严重损害精细定位（正文 §26.2.5）。")
println("   家畜的品种间 LD 差异远大于人类大陆间差异——务必用样本内 LD。")

# %% [markdown]
# ## 8　自检汇总

# %%
ok = Bool[]
# ABF 等价性
let zz=200.0, s2e=0.5, s2a=0.01, rhs=8.0
    Cj = zz + s2e/s2a
    l22 = -0.5*log(s2a*Cj/s2e) + rhs^2/(2*s2e*Cj)
    bh = rhs/zz; s2 = s2e/zz
    l26 = 0.5*log(s2/(s2+s2a)) + 0.5*s2a*bh^2/(s2*(s2+s2a))
    push!(ok, check("式 (22.26) ≡ 式 (26.18)", l22, l26; tol=1e-12))
end
# PIP 的定义：α 行和为 1
push!(ok, check("SuSiE 每个 α_l 行和为 1", vec(sum(sus.alpha; dims=2)), ones(size(sus.alpha,1)); tol=1e-10))
# 穷举模型的后验和为 1
push!(ok, check("穷举模型后验和 = 1", sum(wm), 1.0; tol=1e-12))
# 可信集覆盖 ≥ ρ
push!(ok, cov_ >= 0.95)
@printf("穷举 95%% 可信集的覆盖 = %.4f （应 ≥ 0.95）\n", cov_)
# WPPA ≥ 单标记 PIP 的最大值
let w = findfirst(rg -> qtl[1] in rg, wins)
    @printf("窗口 WPPA = %.3f ≥ 窗口内最大 PIP = %.3f\n", W[w], maximum(res.pip[wins[w]]))
    push!(ok, W[w] >= maximum(res.pip[wins[w]]) - 1e-9)
end
# 窗口方差之和 ≈ 1
let s = sum(mean(view(window_var(Z, res.achain, make_windows(m, 20); thin=20), w, :))
            for w in 1:length(make_windows(m,20)))
    @printf("全部窗口 ρ_w 之和 = %.3f （因含协方差项，不必精确等于 1）\n", s)
    push!(ok, 0.5 < s < 2.0)
end
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
