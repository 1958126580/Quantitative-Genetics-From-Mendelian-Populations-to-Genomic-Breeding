# 第二章　Julia 语言基础 —— 配套代码

**所属**：第一篇　计算基础与 Julia 语言　　**对应正文**：第二章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch02.ipynb` | IJulia 笔记本：21 个代码单元，约 426 行 Julia 代码，穿插与正文对应的说明 |
| `ch02.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |

## 笔记本内容

- 1　类型系统：抽象字段的代价
- 2　类型稳定性：诊断与修复
- 3　多重派发：一份代码，多种结构
- 4　数组：列主序、视图、广播、就地操作
  - 4.1 列主序与遍历顺序
  - 4.2 视图 vs 拷贝：逐标记扫描的场景
  - 4.3 广播的融合
  - 4.4 就地操作与预分配：迭代求解器的场景
- 5　稀疏矩阵：正确的装配方式
- 6　第二版失效 API 逐条修复
- 7　数据读写
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 02
```

或在 Jupyter 中打开 `ch02/ch02.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 本章没有单独的 Python 复核脚本：正文中的解析数值已在写作时用 Python 逐一复算。
