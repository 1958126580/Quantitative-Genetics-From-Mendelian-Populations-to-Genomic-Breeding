# 本脚本由 tools/nb2jl.py 从同目录的 ch02.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 02

# %% [markdown]
# # 第二章　Julia 语言基础 —— 配套代码
#
# 《动物育种中的统计计算（第三版）》随书代码集
#
# ---
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | 类型系统：抽象字段的代价 | §2.2.2 |
# | 2 | 类型稳定性：诊断与修复 | §2.2.5 |
# | 3 | 多重派发：一份代码，多种结构 | §2.3 |
# | 4 | 数组：列主序、视图、广播、就地操作 | §2.4.1–2.4.4 |
# | 5 | 稀疏矩阵：正确的装配方式 | §2.4.5 |
# | 6 | **第二版失效 API 逐条修复**（表 2.7 的可运行版本） | §2.6.4 |
# | 7 | 数据读写 | §2.7 |
#
# 本笔记本的每一节都给出【原理实现】与【优化实现】的对照，并用【对照验证】证明两者数值一致。

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics
using BenchmarkTools, InteractiveUtils
BLAS.set_num_threads(1)     # 基准时固定单线程
rng = Xoshiro(20260918)
versioninfo()

# %% [markdown]
# ## 1　类型系统：抽象字段的代价
#
# 正文 §2.2.2 断言"以抽象类型为字段类型的结构体会很慢"。这里量化它。

# %%
# 【原理实现】字段类型抽象 —— 写法直观，但编译器无法确定内存布局
struct PedNodeBad
    id::Integer          # 抽象类型
    sire::Integer
    dam::Integer
    f::AbstractFloat     # 抽象类型
end

# 【优化实现 A】字段类型具体
struct PedNodeGood
    id::Int32
    sire::Int32
    dam::Int32
    f::Float64
end

# 【优化实现 B】参数化 —— 既泛型又具体
struct PedNode{I<:Integer, F<:AbstractFloat}
    id::I
    sire::I
    dam::I
    f::F
end

@printf("isbitstype(PedNodeBad)  = %s\n", isbitstype(PedNodeBad))
@printf("isbitstype(PedNodeGood) = %s\n", isbitstype(PedNodeGood))
@printf("isbitstype(PedNode{Int32,Float64}) = %s\n", isbitstype(PedNode{Int32,Float64}))
println()
@printf("sizeof(PedNodeGood) = %d 字节（4+4+4+8，紧凑内联）\n", sizeof(PedNodeGood))
println("PedNodeBad 的字段只能存指针，数组中每个元素还要额外的堆分配。")

# %%
# 对照验证：遍历 10⁶ 个节点求近交系数之和
function 累加近交(v)
    s = 0.0
    @inbounds for x in v
        s += x.f
    end
    return s
end

n  = 1_000_000
fs = rand(rng, n)                       # 两个版本使用同一组数据，便于对照
vb = [PedNodeBad(Int32(i),  Int32(0), Int32(0), fs[i]) for i in 1:n]
vg = [PedNodeGood(Int32(i), Int32(0), Int32(0), fs[i]) for i in 1:n]

@assert 累加近交(vb) ≈ 累加近交(vg)       # 【对照验证】结果一致，只有性能不同
tb = @belapsed 累加近交($vb)
tg = @belapsed 累加近交($vg)

@printf("抽象字段 : %8.2f ms   内存 %6.1f MiB\n", tb*1e3, Base.summarysize(vb)/2^20)
@printf("具体字段 : %8.2f ms   内存 %6.1f MiB\n", tg*1e3, Base.summarysize(vg)/2^20)
@printf("加速比   : %.1f×      内存节省 %.1f×\n", tb/tg, Base.summarysize(vb)/Base.summarysize(vg))

# %% [markdown]
# ## 2　类型稳定性：诊断与修复
#
# **Julia 性能优化的第一原则。** 下面复现正文 §2.2.5 的例子并给出诊断方法。

# %%
# 【不稳定】累加器初值类型写死为 Int
function 求和_不稳定(v)
    s = 0                     # ← Int，随后被 Float64 污染
    for x in v
        s += x
    end
    return s
end

# 【稳定】初值类型跟随数据
function 求和_稳定(v)
    s = zero(eltype(v))
    @inbounds @simd for x in v
        s += x
    end
    return s
end

x = randn(rng, 10^7)
@assert 求和_不稳定(x) ≈ 求和_稳定(x)

t1 = @belapsed 求和_不稳定($x)
t2 = @belapsed 求和_稳定($x)
@printf("不稳定 : %7.2f ms\n", t1*1e3)
@printf("稳定   : %7.2f ms\n", t2*1e3)
@printf("加速比 : %.1f×\n", t1/t2)

# %%
# 诊断工具：@code_warntype
# 观察 `s` 的推断类型 —— 不稳定版本中它是 Union{Float64, Int64}
println(">>> 不稳定版本："); @code_warntype 求和_不稳定(x)

# %%
println(">>> 稳定版本："); @code_warntype 求和_稳定(x)

# %%
# 类型不稳定的六个常见来源 —— 逐一演示与修复
println("【来源 3】全局变量（未声明 const）")

gvar = randn(rng, 10^6)                 # 全局变量，类型可随时改变

function 用全局()                       # 反例：直接引用全局变量
    s = 0.0
    for x in gvar; s += x; end
    return s
end
用参数(v) = (s = zero(eltype(v)); for x in v; s += x; end; s)   # 正例

@assert 用全局() ≈ 用参数(gvar)
tg1 = @belapsed 用全局()
tg2 = @belapsed 用参数($gvar)
@printf("  引用全局变量 : %7.2f ms\n", tg1*1e3)
@printf("  通过参数传入 : %7.2f ms   （加速 %.1f×）\n", tg2*1e3, tg1/tg2)
println()
println("→ 规则：性能敏感的代码必须写在函数里，数据通过参数传入。")

# %% [markdown]
# ## 3　多重派发：一份代码，多种结构
#
# 正文 §2.3.1 的例子：MME 左手项中 $\mathbf Z'\mathbf R^{-1}\mathbf Z$ 的计算，随 $\mathbf R^{-1}$ 的结构而不同。
# 用多重派发，调用方代码完全不变。

# %%
# 为三种 R⁻¹ 结构各写一个方法。注意：函数名相同，签名不同。
ZtRinvZ(Z::AbstractMatrix, Rinv::UniformScaling) = Rinv.λ * (Z' * Z)
ZtRinvZ(Z::AbstractMatrix, Rinv::Diagonal)       = Z' * (Rinv * Z)
ZtRinvZ(Z::AbstractMatrix, Rinv::AbstractMatrix) = Z' * Rinv * Z     # 通用回退

Z = randn(rng, 500, 60)
d = rand(rng, 500) .+ 0.5

R1 = 2.0 * I                    # 同质残差方差
R2 = Diagonal(d)                # 异质残差方差
R3 = Matrix(Diagonal(d))        # 同样的内容，但以稠密矩阵给出

# 【对照验证】三条路径在数学上等价
@assert ZtRinvZ(Z, R2) ≈ ZtRinvZ(Z, R3)
@assert ZtRinvZ(Z, R1) ≈ 2.0 * (Z' * Z)

println("派发结果：")
println("  UniformScaling → ", @which ZtRinvZ(Z, R1))
println("  Diagonal       → ", @which ZtRinvZ(Z, R2))
println("  Matrix         → ", @which ZtRinvZ(Z, R3))
println()
@printf("Diagonal 专用路径 : %7.3f ms\n", (@belapsed ZtRinvZ($Z, $R2))*1e3)
@printf("稠密通用路径      : %7.3f ms\n", (@belapsed ZtRinvZ($Z, $R3))*1e3)
println("→ 同一行调用代码，因类型不同而走了复杂度不同的路径。")

# %%
# 陷阱演示：关键字参数不参与派发
# 下面两个定义的【位置参数签名相同】，第二个会覆盖第一个。
f_demo(x; tol=1e-6)             = "第一个定义"
f_demo(x; tol=1e-6, output=10)  = "第二个定义"

println("f_demo(1) = ", f_demo(1))
println("方法数    = ", length(methods(f_demo)))
println()
println("→ 第二版第 4 章的两个 GaussSeidel(A,x,b;...) 正是这种情况：")
println("  第一个定义成为永远不会被调用的死代码。")

# %% [markdown]
# ## 4　数组：列主序、视图、广播、就地操作
#
# ### 4.1 列主序与遍历顺序

# %%
function 按列遍历(A)                 # 内层遍历行 —— 连续访问
    s = zero(eltype(A))
    @inbounds for j in axes(A, 2), i in axes(A, 1)
        s += A[i, j]
    end
    return s
end

function 按行遍历(A)                 # 内层遍历列 —— 跨步访问
    s = zero(eltype(A))
    @inbounds for i in axes(A, 1), j in axes(A, 2)
        s += A[i, j]
    end
    return s
end

A = randn(rng, 4000, 4000)
@assert 按列遍历(A) ≈ 按行遍历(A)
tc = @belapsed 按列遍历($A)
tr = @belapsed 按行遍历($A)
@printf("列主序（内层遍历行）: %7.2f ms\n", tc*1e3)
@printf("反向  （内层遍历列）: %7.2f ms   （慢 %.1f×）\n", tr*1e3, tr/tc)

# %% [markdown]
# ### 4.2 视图 vs 拷贝：逐标记扫描的场景

# %%
# 【原理实现】切片（每次分配）
function 列范数_拷贝(Z)
    m = size(Z, 2); out = zeros(m)
    for j in 1:m
        zⱼ = Z[:, j]                 # ← 分配一份拷贝
        out[j] = sum(abs2, zⱼ)
    end
    return out
end

# 【优化实现】视图（不分配）
function 列范数_视图(Z)
    m = size(Z, 2); out = zeros(m)
    @views @inbounds for j in 1:m
        out[j] = sum(abs2, Z[:, j])
    end
    return out
end

Z = randn(rng, 5000, 4000)
@assert 列范数_拷贝(Z) ≈ 列范数_视图(Z)      # 【对照验证】

t1 = @belapsed 列范数_拷贝($Z);  a1 = @allocated 列范数_拷贝(Z)
t2 = @belapsed 列范数_视图($Z);  a2 = @allocated 列范数_视图(Z)
@printf("切片拷贝 : %7.2f ms   分配 %8.1f MiB\n", t1*1e3, a1/2^20)
@printf("使用视图 : %7.2f ms   分配 %8.1f MiB\n", t2*1e3, a2/2^20)
@printf("加速 %.1f×，分配减少 %.0f×\n", t1/t2, a1/max(a2,1))

# %% [markdown]
# ### 4.3 广播的融合

# %%
a = 2.0
x = randn(rng, 10^7); b = randn(rng, 10^7)

g_naive(a, x, b)  = a * x + b          # 产生中间数组 a*x
g_fused(a, x, b)  = @. a * x + b       # 融合为一个循环，无中间数组

@assert g_naive(a,x,b) ≈ g_fused(a,x,b)
@printf("未融合 : %7.2f ms   分配 %6.1f MiB\n",
        (@belapsed g_naive($a,$x,$b))*1e3, (@allocated g_naive(a,x,b))/2^20)
@printf("融合   : %7.2f ms   分配 %6.1f MiB\n",
        (@belapsed g_fused($a,$x,$b))*1e3, (@allocated g_fused(a,x,b))/2^20)

# %% [markdown]
# ### 4.4 就地操作与预分配：迭代求解器的场景
#
# 这是第十一、十五章迭代求解器的核心写法。

# %%
# 【原理实现】每次迭代都分配
function jacobi_朴素(A, b, x0; niter=50, ω=1.0)
    x = copy(x0); D = diag(A)
    for _ in 1:niter
        r = b - A * x                 # ← 两次分配
        x = x + ω * (r ./ D)          # ← 两次分配
    end
    return x
end

# 【优化实现】预分配 + 就地
function jacobi_就地(A, b, x0; niter=50, ω=1.0)
    x  = copy(x0); D = diag(A)
    r  = similar(b); Ax = similar(b)
    for _ in 1:niter
        mul!(Ax, A, x)                # 无分配
        @. r = b - Ax                 # 无分配
        @. x = x + ω * r / D          # 无分配
    end
    return x
end

n = 2000
A = randn(rng, n, n); A = (A + A') / 2                  # 对称
A[diagind(A)] .= vec(sum(abs, A; dims=2)) .+ 1.0        # 严格对角占优 ⇒ Jacobi 必收敛
b = randn(rng, n); x0 = zeros(n)

x1 = jacobi_朴素(A, b, x0); x2 = jacobi_就地(A, b, x0)
@printf("【对照验证】两实现的相对差 = %.3e\n", norm(x1-x2)/norm(x2))
@printf("残差 ‖b-Ax‖/‖b‖            = %.3e   （严格对角占优，Jacobi 收敛）\n",
        norm(b - A*x2)/norm(b))

t1 = @belapsed jacobi_朴素($A, $b, $x0);  a1 = @allocated jacobi_朴素(A,b,x0)
t2 = @belapsed jacobi_就地($A, $b, $x0);  a2 = @allocated jacobi_就地(A,b,x0)
@printf("朴素 : %7.2f ms   分配 %7.2f MiB\n", t1*1e3, a1/2^20)
@printf("就地 : %7.2f ms   分配 %7.2f MiB\n", t2*1e3, a2/2^20)
@printf("加速 %.2f×，分配减少 %.0f×\n", t1/t2, a1/max(a2,1))
println()
println("注：本例中矩阵-向量乘占主导，故加速有限；在分配占比更高的场景")
println("（如逐标记扫描、MCMC 内层循环）中，加速可达 2–5 倍。")

# %% [markdown]
# ## 5　稀疏矩阵：正确的装配方式
#
# **本节是第二版代码最主要的性能缺陷所在，也是本书反复使用的核心模式。**

# %%
# 场景：装配单因子模型的 X'X。n 条记录，p 个水平。
n, p = 200_000, 2_000
lev  = rand(rng, 1:p, n)

# 【原理实现／第二版写法】向 spzeros 逐元素累加
function xtx_逐元素(lev, p)
    M = spzeros(p+1, p+1)
    @inbounds for i in eachindex(lev)
        a = 1; b = 1 + lev[i]
        M[a,a] += 1.0; M[a,b] += 1.0; M[b,a] += 1.0; M[b,b] += 1.0
    end
    return M
end

# 【优化实现】收集三元组，一次构造（sparse 对重复下标自动求和）
function xtx_三元组(lev, p)
    n = length(lev)
    I = Vector{Int}(undef, 4n); J = similar(I); V = Vector{Float64}(undef, 4n)
    @inbounds for i in 1:n
        a = 1; b = 1 + lev[i]; k = 4(i-1)
        I[k+1]=a; J[k+1]=a; V[k+1]=1.0
        I[k+2]=a; J[k+2]=b; V[k+2]=1.0
        I[k+3]=b; J[k+3]=a; V[k+3]=1.0
        I[k+4]=b; J[k+4]=b; V[k+4]=1.0
    end
    return sparse(I, J, V, p+1, p+1)
end

# 先用小规模验证两者结果一致
lev_s = rand(rng, 1:50, 2000)
@assert xtx_逐元素(lev_s, 50) ≈ xtx_三元组(lev_s, 50)   # 【对照验证】
println("✓ 小规模上两种实现结果完全一致")

# %%
# 规模对比：逐元素插入的代价随 nnz 增长
println(rpad("n", 10), rpad("逐元素 (ms)", 16), rpad("三元组 (ms)", 16), "加速比")
println("-"^56)
for nn in (2_000, 20_000, 200_000)
    L  = rand(rng, 1:p, nn)
    t1 = @belapsed xtx_逐元素($L, $p) samples=3 evals=1
    t2 = @belapsed xtx_三元组($L, $p) samples=3 evals=1
    @printf("%-10d%-16.2f%-16.2f%.1f×\n", nn, t1*1e3, t2*1e3, t1/t2)
end
println()
println("→ 逐元素插入的总代价约为 O(m·nnz)，三元组构造约为 O(m log m)。")
println("  规模越大，差距越悬殊 —— 这正是第二版代码在真实数据上不可用的原因。")

# %%
# CSC 内部结构：理解它才能写出正确的稀疏代码
S = sparse([1,3,2,3], [1,1,2,3], [10.0,20.0,30.0,40.0], 3, 3)
println("S =");  display(Matrix(S))
println()
println("nzval  (按列排列的非零值) = ", S.nzval)
println("rowval (每个非零值的行号) = ", S.rowval)
println("colptr (列 j 的范围)       = ", S.colptr)
println()
println("取第 2 列的非零元： ", [(S.rowval[k], S.nzval[k]) for k in S.colptr[2]:S.colptr[3]-1])
println("→ 按列访问是一次连续读取；按行访问需扫描所有列。")

# %% [markdown]
# ## 6　第二版失效 API 逐条修复
#
# 本节是正文**表 2.7** 的可运行版本。每一项给出第二版写法在 Julia 1.x 下的实际后果与修正写法。
#
# > 为避免笔记本中断，失效写法用 `try ... catch` 包裹，只打印错误类型。

# %%
function 演示(标题, 旧写法::Function, 新写法::Function)
    print(rpad(标题, 34))
    old = try
        旧写法(); "（竟然可运行 —— 请核对）"
    catch e
        "✗ " * string(nameof(typeof(e)))
    end
    new = try
        string(新写法())
    catch e
        "✗ 新写法也失败：" * string(e)
    end
    println(rpad(old, 24), "→  ", new)
end

println(rpad("项目", 34), rpad("第二版写法的后果", 24), "现代写法的结果")
println("="^90)

演示("Array(Float64, 3)",        () -> Base.Array(Float64, 3),      () -> Vector{Float64}(undef,3) |> typeof)
演示("full(A)",                  () -> Base.full(sparse([1],[1],[1.0])), () -> Matrix(sparse([1],[1],[1.0])))
演示("int([1.0,2.0])",           () -> Base.int([1.0,2.0]),         () -> Int.([1.0,2.0]))
演示("bool([1,0,1])",            () -> Base.bool([1,0,1]),          () -> Bool.([1,0,1]))
演示("sqrt([1.0,4.0])",          () -> sqrt([1.0,4.0]),             () -> sqrt.([1.0,4.0]))
演示("round([1.234,5.678], 2)",  () -> round([1.234,5.678], 2),     () -> round.([1.234,5.678]; digits=2))
演示("linspace(0,1,5)",          () -> Base.linspace(0,1,5),        () -> collect(range(0,1;length=5)))
演示("workspace()",              () -> Base.workspace(),            () -> "改用 Revise.jl 或重启进程")

# %%
# 几个"能运行但语义已改变"的项目 —— 比报错更危险
println("【1】`[1:5]` 的语义变化")
println("  Julia 0.4: [1:5] 得到 [1,2,3,4,5]")
println("  Julia 1.x: [1:5] 得到 ", [1:5], "  ← 含一个 UnitRange 的一元向量！")
println("  正确写法 : collect(1:5) = ", collect(1:5), " 或直接使用 1:5")
println()

println("【2】`diag(v)` —— 提取对角线，不是构造对角阵")
v = [1.0, 2.0, 3.0]
println("  Diagonal(v) 构造对角阵：");  display(Matrix(Diagonal(v)))
print("  diag(v) 的结果：")
try
    println(diag(v))
catch e
    println("✗ ", nameof(typeof(e)), " —— diag 需要矩阵参数")
end
println("  → 第二版 CORMAT 函数中的 `B = diag(1./D)` 属于此类错误。")
println()

println("【3】`!` 与 `=` 之间的空格")
println("  `x != 0` 是不等判断；`x! = 0` 会被解析为对名为 `x!` 的变量赋值。")
println("  → 第二版第 5 章 `if mme.ped! = 0` 属于此类笔误。")
println()

println("【4】`&` 与 `&&`")
a, b = true, false
println("  a & b  = ", a & b,  "  （按位与，两侧都求值）")
println("  a && b = ", a && b, "  （逻辑与，短路求值）")
println("  → 在 `while (cond1 & cond2)` 中用 `&` 虽可运行，但不短路，且对非 Bool 会出错。")

# %%
# 第二版 CORMAT 函数的完整修复
# 【第二版原文】
#   function CORMAT(Q::Array)
#       D = diag(Q); D = sqrt(D); B = diag(1./D); HC = B*Q*B; return HC
#   end
# 三处问题：(1) 1./D 解析错误  (2) sqrt(D) 需广播  (3) diag 不能构造对角阵

# 【修复版 · 原理实现】逐步对应公式 R = D^{-1/2} Q D^{-1/2}
function cormat_原理(Q::AbstractMatrix)
    d = diag(Q)                      # 提取对角线（方差）
    s = sqrt.(d)                     # 标准差（广播）
    B = Diagonal(1 ./ s)             # 构造对角阵（注意空格）
    return B * Q * B
end

# 【修复版 · 优化实现】避免两次矩阵乘法，直接逐元素计算
function cormat_优化(Q::AbstractMatrix)
    s = sqrt.(diag(Q))
    R = similar(Q, float(eltype(Q)))
    @inbounds for j in axes(Q, 2), i in axes(Q, 1)
        R[i, j] = Q[i, j] / (s[i] * s[j])
    end
    return R
end

# 【对照验证】
Σ = let X = randn(rng, 200, 6); X'X end       # 一个对称正定矩阵
R1, R2 = cormat_原理(Σ), cormat_优化(Σ)
@printf("两实现相对差            : %.3e\n", norm(R1-R2)/norm(R2))
@printf("与 Statistics.cov2cor 差 : %.3e\n", norm(R2 - Symmetric(Σ) ./ (sqrt.(diag(Σ)) * sqrt.(diag(Σ))')))
@printf("对角元是否全为 1         : %s\n", all(≈(1.0), diag(R2)) ? "✓" : "✗")
@printf("优化实现加速             : %.1f×\n",
        (@belapsed cormat_原理($Σ)) / (@belapsed cormat_优化($Σ)))

# %% [markdown]
# ## 7　数据读写
#
# 育种数据读取的三个要点：显式声明缺失值标记、显式声明个体号为字符串、大文件流式读取。

# %%
using CSV, DataFrames

# 构造一个演示用的表型文件（含前导零个体号与多种缺失标记）
demo = """
ID herd year weight backfat
0012345 A 2024 88.5 12.1
0012346 A 2024 NA 11.8
0012347 B 2024 91.2 NA
0012348 B 2025 85.0 13.4
"""
tmp = joinpath(tempdir(), "demo_phen.txt")
write(tmp, demo)

# 【错误示范】让 CSV 自动推断类型 —— 个体号丢失前导零
df_bad = CSV.read(tmp, DataFrame; delim=' ')
println("自动推断： ID 列类型 = ", eltype(df_bad.ID), "，首个 ID = ", df_bad.ID[1])

# 【正确写法】强制 ID 为字符串，显式声明缺失标记
df = CSV.read(tmp, DataFrame; delim=' ', missingstring=["NA", ".", "-999", ""],
              types=Dict(:ID => String))
println("强制字符串： ID 列类型 = ", eltype(df.ID), "，首个 ID = ", df.ID[1])
println()
display(df)

# %%
# 列访问语义（DataFrames 1.x）
println("df.A / df[!,:A] 不复制； df[:,:A] 复制")
w1 = df[!, :weight]; w2 = df[:, :weight]
println("  df[!,:weight] === df.weight ? ", df[!,:weight] === df.weight)
println("  df[:,:weight] === df.weight ? ", df[:,:weight] === df.weight)
println()
println("缺失值的传播性：")
println("  1 + missing        = ", 1 + missing)
println("  missing == missing = ", missing == missing, "   ← 不是 true！")
println("  ismissing(missing) = ", ismissing(missing))
println()
println("列均值（跳过缺失）： ", mean(skipmissing(df.weight)))
println("剔除缺失后的行数  ： ", nrow(dropmissing(df)))
println()

# 分类变量 → 连续整数编码 → 一次构造设计矩阵（第十一、十二章的标准模式）
levels = unique(df.herd)
lmap   = Dict(v => i for (i, v) in enumerate(levels))
col    = [lmap[v] for v in df.herd]
X      = sparse(1:nrow(df), col, 1.0, nrow(df), length(levels))
println("herd 的设计矩阵："); display(Matrix(X))
rm(tmp; force=true)

# %% [markdown]
# ## 本章代码小结
#
# 1. **抽象字段**使结构体无法内联存储，在百万级系谱上造成数量级的性能与内存差距。用具体类型或参数化类型。
# 2. **类型稳定性**是第一原则，`@code_warntype` 是第一诊断工具，**"性能敏感的代码必须写在函数里"** 是第一条实践规则。
# 3. **多重派发**让同一行调用代码依据类型走向复杂度不同的实现路径；注意**关键字参数不参与派发**。
# 4. 数组是**列主序**；`@views` 消除切片分配；`@.` 融合广播；`mul!` + 预分配消除迭代循环中的分配。**把热点循环的分配降到 0 是可检验的优化目标。**
# 5. **稀疏矩阵装配的正确模式是"收集三元组 → `sparse(I,J,V)`"**，`sparse` 对重复下标自动求和，恰好匹配 MME 装配的需求。逐元素向 `spzeros` 插入的代价是 $O(m\cdot \mathrm{nnz})$。
# 6. 第二版的失效 API 已逐条给出修复；其中 `diag(v)` 被误用于构造对角阵、`x! = y`、`[1:n]` 三项属于"能运行但语义错误"，最为危险。
# 7. 读育种数据时**必须**显式声明缺失标记与个体号类型。
#
# **下一步**：`ch03.ipynb` 进入数值线性代数 —— 矩阵分解、条件数、稀疏格式与矩阵微分。
