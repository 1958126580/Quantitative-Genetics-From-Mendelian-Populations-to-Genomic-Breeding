"""
    ASC3

《动物育种中的统计计算（第三版）》随书代码集公用模块。

提供全书各章笔记本共用的工具：数据路径解析、可复现随机数、计时与基准辅助、
数值一致性断言等。设计原则是**薄**——只做各章重复出现的样板工作，
所有与统计遗传学原理相关的算法都在各章笔记本中显式实现，以便读者阅读与修改。
"""
module ASC3

using Random, Printf, LinearAlgebra

export datapath, bookrng, @showtime, isclose, relerr

"全书实例数据目录。`datapath(\"ped1.txt\")` 返回该文件的绝对路径。"
datapath(parts...) = joinpath(dirname(@__DIR__), "data", parts...)

"""
    bookrng(seed=20260918)

返回全书统一使用的可复现随机数发生器。使用 `Xoshiro`（Julia ≥1.7 默认算法），
显式播种以保证任何机器、任何线程数下结果逐位一致。
"""
bookrng(seed::Integer=20260918) = Xoshiro(seed)

"相对误差 ‖a-b‖ / max(‖b‖, 1)。"
relerr(a, b) = norm(a .- b) / max(norm(b), one(eltype(float.(b))))

"数值一致性判定，用于【原理实现】与【优化实现】的对照验证。"
isclose(a, b; rtol=1e-8) = relerr(a, b) ≤ rtol

"打印表达式及其耗时，用于笔记本中的轻量计时。"
macro showtime(ex)
    quote
        local t0 = time_ns()
        local val = $(esc(ex))
        @printf("%-52s %8.3f ms\n", $(string(ex)), (time_ns() - t0) / 1e6)
        val
    end
end

end # module
