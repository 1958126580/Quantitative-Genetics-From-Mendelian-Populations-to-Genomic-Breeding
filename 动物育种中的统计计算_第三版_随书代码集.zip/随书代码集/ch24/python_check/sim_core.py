# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 24 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 sim_core.py    依赖：numpy
"""ch24 核心模拟：带 LD、家系结构、世代与两个分化品系的群体。
随机种子 20240624。"""
import numpy as np, os, sys

SEED = 20240624
OUT = os.path.dirname(os.path.abspath(__file__))

NCHR, LPC = 20, 125          # 20 条 1 Morgan 染色体，每条 125 个位点
L = NCHR * LPC               # 2500 个位点
NE = 200                     # burn-in 有效含量
BURN = 100                   # burn-in 世代数
DIVERGE = 25                 # 两品系独立漂变世代数
NGEN = 4                     # 育种世代数
NSIRE, NDAM, NPROG = 25, 100, 6
H2 = 0.30
NQTL = 250
NHERD = 20
SEX_EFF = 0.8
VAR_HERD = 1.0

# 重组率向量：染色体首位点 0.5（自由组合），其余相邻 1/(LPC-1) Morgan
rec = np.full(L, 1.0 / (LPC - 1))
rec[::LPC] = 0.5


def gametes(hap, par, rng):
    """hap:(n,2,L) int8, par:(m,) -> (m,L) int8"""
    m = len(par)
    sw = rng.random((m, L)) < rec
    which = np.cumsum(sw, axis=1) % 2
    h = hap[par]
    return np.where(which == 0, h[:, 0, :], h[:, 1, :]).astype(np.int8)


def mate(hap, sires, dams, rng):
    return np.stack([gametes(hap, sires, rng), gametes(hap, dams, rng)], axis=1)


def burnin(rng):
    p0 = rng.uniform(0.05, 0.95, L)
    hap = (rng.random((NE, 2, L)) < p0).astype(np.int8)
    for _ in range(BURN):
        s = rng.integers(0, NE // 2, NE)              # 前一半为雄
        d = rng.integers(NE // 2, NE, NE)
        hap = mate(hap, s, d, rng)
    return hap


def drift(hap, gens, rng):
    n = hap.shape[0]
    for _ in range(gens):
        s = rng.integers(0, n // 2, n)
        d = rng.integers(n // 2, n, n)
        hap = mate(hap, s, d, rng)
    return hap


def dosage(hap):
    return hap.sum(axis=1).astype(np.int8)


def breed(hap0, qtl, alpha, sigma_e, rng, ngen=NGEN, tag=''):
    """从 hap0（基础群）出发跑 ngen 个育种世代，返回各世代的基因型、TBV、表型、系谱。"""
    n0 = hap0.shape[0]
    # 基础群本身作为第 0 世代（有基因型无表型）
    haps = [hap0]
    gen_of = [np.zeros(n0, int)]
    sex = [np.r_[np.zeros(n0 // 2, int), np.ones(n0 // 2, int)]]   # 0=雄 1=雌
    sire_of = [np.full(n0, -1)]; dam_of = [np.full(n0, -1)]
    tbv = [dosage(hap0)[:, qtl] @ alpha]
    phen = [np.full(n0, np.nan)]
    offset = [0]
    cur = hap0; cur_tbv = tbv[0]; cur_sex = sex[0]; cur_off = 0
    sizes = [n0]
    for g in range(1, ngen + 1):
        males = np.where(cur_sex == 0)[0]
        females = np.where(cur_sex == 1)[0]
        # 用育种值+表型代理做截断选择（第 0 代用 TBV，之后用表型）
        crit = cur_tbv + rng.normal(0, np.sqrt(sigma_e), len(cur_tbv))
        sires = males[np.argsort(-crit[males])[:NSIRE]]
        dams = females[np.argsort(-crit[females])[:NDAM]]
        # 公畜使用强度不等（指数权重），造成规模差异很大的半同胞家系
        w = rng.exponential(1.0, NSIRE); w /= w.sum()
        assign = rng.choice(NSIRE, size=NDAM, p=w)
        s_idx = sires[assign]
        s_rep = np.repeat(s_idx, NPROG); d_rep = np.repeat(dams, NPROG)
        newhap = mate(cur, s_rep, d_rep, rng)
        n = newhap.shape[0]
        t = dosage(newhap)[:, qtl] @ alpha
        sx = rng.integers(0, 2, n)
        haps.append(newhap); gen_of.append(np.full(n, g))
        sex.append(sx)
        sire_of.append(s_rep + cur_off); dam_of.append(d_rep + cur_off)
        tbv.append(t)
        phen.append(np.zeros(n))          # 稍后统一加固定效应
        cur = newhap; cur_tbv = t; cur_sex = sx
        cur_off = sum(sizes)
        sizes.append(n)
    hap = np.concatenate(haps, axis=0)
    return dict(hap=hap, gen=np.concatenate(gen_of), sex=np.concatenate(sex),
                sire=np.concatenate(sire_of), dam=np.concatenate(dam_of),
                tbv=np.concatenate(tbv))


def main():
    rng = np.random.default_rng(SEED)
    hap = burnin(rng)
    print('burn-in done', hap.shape)
    # 分成两个品系
    idx = rng.permutation(NE)
    hA = hap[idx[:NE]]           # 同一批个体作为两系共同起点
    hB = hap[idx[:NE]].copy()
    hA = drift(hA, DIVERGE, rng)
    hB = drift(hB, DIVERGE, rng)
    print('divergence done')
    # QTL 与效应：按 A 系的位点定义
    dA = dosage(hA)
    pA = dA.mean(axis=0) / 2
    seg = np.where((pA > 0.02) & (pA < 0.98))[0]
    qtl = rng.choice(seg, NQTL, replace=False)
    alpha = rng.normal(0, 1, NQTL)
    # 标定：使 A 系基础群的加性方差为 1
    v = np.var(dA[:, qtl] @ alpha)
    alpha *= 1.0 / np.sqrt(v)
    sigma_e = (1 - H2) / H2
    A = breed(hA, qtl, alpha, sigma_e, rng, tag='A')
    B = breed(hB, qtl, alpha, sigma_e, rng, tag='B')
    # 固定效应 + 残差
    for D, nm in ((A, 'A'), (B, 'B')):
        n = len(D['tbv'])
        herd = rng.integers(0, NHERD, n)
        heff = rng.normal(0, np.sqrt(VAR_HERD), NHERD)
        e = rng.normal(0, np.sqrt(sigma_e), n)
        y = heff[herd] + SEX_EFF * (D['sex'] == 0) + D['tbv'] + e
        y[D['gen'] == 0] = np.nan
        D.update(herd=herd, heff=heff, e=e, y=y, line=nm)
    np.savez_compressed(os.path.join(OUT, 'sim.npz'),
        qtl=qtl, alpha=alpha, sigma_e=sigma_e,
        **{'A_' + k: v for k, v in A.items() if k != 'line'},
        **{'B_' + k: v for k, v in B.items() if k != 'line'})
    for nm, D in (('A', A), ('B', B)):
        m = D['gen'] > 0
        print(nm, 'n=', m.sum(), 'Var(tbv) by gen:',
              [round(float(np.var(D['tbv'][D['gen'] == g])), 3) for g in range(NGEN + 1)],
              'mean tbv:', [round(float(np.mean(D['tbv'][D['gen'] == g])), 3) for g in range(NGEN + 1)])
    # LD 诊断
    dA4 = dosage(A['hap'][A['gen'] == NGEN])
    p = dA4.mean(0) / 2
    keep = (p > 0.02) & (p < 0.98)
    Zs = (dA4[:, keep] - 2 * p[keep]) / np.sqrt(2 * p[keep] * (1 - p[keep]))
    for lag in (1, 2, 5, 10, 25):
        cols = np.where(keep)[0]
        ok = (cols[:-lag] // LPC) == (cols[lag:] // LPC)
        r = (Zs[:, :-lag] * Zs[:, lag:]).mean(0)
        print('lag', lag, 'mean r2 =', round(float((r[ok] ** 2).mean()), 4))
    print('segregating loci in A gen4:', keep.sum())


if __name__ == '__main__':
    main()
