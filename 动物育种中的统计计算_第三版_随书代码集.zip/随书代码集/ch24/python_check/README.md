# 第 24 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch24/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `common.py` | ch24 公共工具：数据载入、Z 矩阵、SNP-BLUP/GBLUP 拟合、REML。 | numpy, scipy | 0.4 | `outputs/common.out` |
| `sim_core.py` | ch24 核心模拟：带 LD、家系结构、世代与两个分化品系的群体。 | numpy | 8.0 | `outputs/sim_core.out` |
