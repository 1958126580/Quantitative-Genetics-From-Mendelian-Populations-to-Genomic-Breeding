# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 24 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 common.py    依赖：numpy, scipy
"""ch24 公共工具：数据载入、Z 矩阵、SNP-BLUP/GBLUP 拟合、REML。"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import numpy as np, os
from scipy.linalg import cho_factor, cho_solve, eigh

HERE = os.path.dirname(os.path.abspath(__file__))
NHERD = 20


def load():
    d = np.load(os.path.join(HERE, 'sim.npz'))
    A = {k[2:]: d[k] for k in d.files if k.startswith('A_')}
    B = {k[2:]: d[k] for k in d.files if k.startswith('B_')}
    qtl = d['qtl']; alpha = d['alpha']; sigma_e = float(d['sigma_e'])
    for D in (A, B):
        D['dos'] = D['hap'].sum(axis=1).astype(np.float64)
    return A, B, qtl, alpha, sigma_e


def marker_set(A, qtl):
    """标记 = 在 A 系 1–4 世代中分离、且不是 QTL 的位点。"""
    m = A['gen'] > 0
    p = A['dos'][m].mean(0) / 2
    keep = (p > 0.01) & (p < 0.99)
    keep[qtl] = False
    return np.where(keep)[0]


def make_Z(dos, cols, p_ref):
    """VanRaden 方法 1 的中心化（不逐位点标准化）。"""
    return dos[:, cols] - 2 * p_ref


def design(D, idx):
    """固定效应设计阵：场（20 水平，第 0 水平并入截距）+ 性别。"""
    n = len(idx)
    X = np.zeros((n, NHERD + 1))
    X[:, 0] = 1.0
    h = D['herd'][idx]
    for j in range(1, NHERD):
        X[:, j] = (h == j)
    X[:, NHERD] = (D['sex'][idx] == 0)
    return X[:, [0] + list(range(1, NHERD)) + [NHERD]]


def snpblup(X, Z, y, lam):
    """返回 (beta, alpha, Cinv)；Cinv 为整个系数阵之逆（用于 PEV）。"""
    W = np.hstack([X, Z])
    C = W.T @ W
    p = X.shape[1]
    C[p:, p:] += lam * np.eye(Z.shape[1])
    rhs = W.T @ y
    cf = cho_factor(C, lower=True)
    b = cho_solve(cf, rhs)
    return b[:p], b[p:], cf, p


def reml_lambda(G, X, y, lo=-3.0, hi=5.0, n=41):
    """在 log λ 网格上做剖面 REML（V = σ_e²(G/λ + I)），返回 (λ, σ_e², σ_g², logL)。"""
    nn, pp = X.shape
    best = None
    for t in np.linspace(lo, hi, n):
        lam = np.exp(t)
        H = G / lam + np.eye(nn)
        cf = cho_factor(H, lower=True)
        logdetH = 2 * np.sum(np.log(np.diag(cf[0])))
        HiX = cho_solve(cf, X); Hiy = cho_solve(cf, y)
        XtHiX = X.T @ HiX
        cf2 = cho_factor(XtHiX, lower=True)
        logdet2 = 2 * np.sum(np.log(np.diag(cf2[0])))
        bt = cho_solve(cf2, X.T @ Hiy)
        yPy = float(y @ Hiy - (X.T @ Hiy) @ bt)
        s2e = yPy / (nn - pp)
        ll = -0.5 * (logdetH + logdet2 + (nn - pp) * np.log(s2e))
        if best is None or ll > best[3]:
            best = (lam, s2e, s2e / lam, ll)
    return best


def acc_report(u_hat, target):
    r = float(np.corrcoef(u_hat, target)[0, 1])
    b = float(np.cov(target, u_hat, ddof=1)[0, 1] / np.var(u_hat, ddof=1))
    return r, b


class Fitter:
    """预先算好 W'W 与 W'y，用秩 -n_v 降级实现快速折叠拟合。"""

    def __init__(self, X, Z, y, lam):
        self.W = np.hstack([X, Z])
        self.p = X.shape[1]
        self.y = y
        self.lam = lam
        self.WtW = self.W.T @ self.W
        self.Wty = self.W.T @ y
        self.D = np.zeros(self.W.shape[1])
        self.D[self.p:] = lam

    def fit(self, train_mask):
        Wv = self.W[~train_mask]
        C = self.WtW - Wv.T @ Wv
        C[np.diag_indices_from(C)] += self.D
        rhs = self.Wty - Wv.T @ self.y[~train_mask]
        cf = cho_factor(C, lower=True)
        b = cho_solve(cf, rhs)
        return b[:self.p], b[self.p:], cf

    def gebv(self, alpha_hat, rows=None):
        Zp = self.W[:, self.p:] if rows is None else self.W[np.ix_(rows, np.arange(self.p, self.W.shape[1]))]
        return Zp @ alpha_hat
