# 本脚本由 tools/nb2jl.py 从同目录的 ch24.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 24

# %% [markdown]
# # 第二十四章　基因组预测的评估与诊断 —— 配套代码
#
# 本 Notebook 对应第二十四章。
#
# **内容**
#
# 1. 三个基本度量：$r$、$b_1$、MSE（正文式 24.1–24.5）
# 2. 验证标准的换算：除以 $h$ 还是除以 $r_{\mathrm{DRP}}$（正文式 24.7–24.9）
# 3. 四种交叉验证设计的对照（正文 §24.2）——**随机 $k$ 折的偏乐观有多大？**
# 4. 抽样误差与 Hotelling–Williams 配对检验（正文式 24.11–24.13）
# 5. **LR 方法**的完整实现（正文式 24.15–24.19）
# 6. 偏差诊断：分层 $b_1$、遗传趋势图
# 7. 自动生成验证报告

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %%
"""按系谱递推构造 A（第九章式 9.2–9.3）。"""
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

"""Henderson–Quaas 规则构造稀疏 A⁻¹（第九章 §9.3.2）。"""
function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        b = inv(delta)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

"""按系谱做配子传递的简化模拟（与第二十一章相同）。"""
function sim_pedigree_genotypes(nbase::Int, ngen::Int, nper::Int, m::Int;
                                nchr::Int=10, r::Float64=0.02,
                                maf_min::Float64=0.05, rng=Random.default_rng())
    n = nbase + ngen*nper
    p0 = maf_min .+ (1 - 2maf_min) .* rand(rng, m)
    H = Array{Int8,3}(undef, n, m, 2)
    @inbounds for i in 1:nbase, j in 1:m, k in 1:2
        H[i,j,k] = Int8(rand(rng) < p0[j])
    end
    sire = zeros(Int, n); dam = zeros(Int, n)
    mper = m ÷ nchr
    gen  = zeros(Int, n)
    @inbounds for g in 1:ngen
        lo = nbase + (g-1)*nper + 1; hi = nbase + g*nper
        pool_hi = lo - 1
        for i in lo:hi
            gen[i] = g
            s = rand(rng, 1:pool_hi); d = rand(rng, 1:pool_hi)
            while d == s; d = rand(rng, 1:pool_hi); end
            sire[i] = s; dam[i] = d
            for (par, k) in ((s,1), (d,2))
                for c in 1:nchr
                    cur = rand(rng, 1:2)
                    for jj in 1:mper
                        j = (c-1)*mper + jj
                        j > m && break
                        if jj > 1 && rand(rng) < r; cur = 3 - cur; end
                        H[i,j,k] = H[par,j,cur]
                    end
                end
            end
        end
    end
    Mg = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        Mg[i,j] = Float64(H[i,j,1]) + Float64(H[i,j,2])
    end
    return Mg, sire, dam, gen
end

# %% [markdown]
# ## 1　三个基本度量

# %%
"""正文式 (24.1)–(24.3)：预测评估的三个基本量。"""
function eval_prediction(ghat::Vector{Float64}, ycrit::Vector{Float64})
    r  = cor(ghat, ycrit)
    b1 = cov(ycrit, ghat)/var(ghat)
    mse = mean((ycrit .- ghat).^2)
    bias = mean(ghat) - mean(ycrit)
    return (r=r, b1=b1, mse=mse, bias=bias, n=length(ghat))
end

"""正文式 (24.5)：MSE 的 Theil 分解（偏移 / 尺度 / 随机）。"""
function theil_decomposition(ghat, ycrit)
    n = length(ghat)
    bias2  = (mean(ghat) - mean(ycrit))^2
    scale2 = (std(ghat; corrected=false) - std(ycrit; corrected=false))^2
    rand2  = 2*(1 - cor(ghat, ycrit))*std(ghat; corrected=false)*std(ycrit; corrected=false)
    tot    = mean((ycrit .- ghat).^2)
    return (bias=bias2, scale=scale2, random=rand2, total=tot,
            sum=bias2+scale2+rand2)
end

"""构造一个预测值，使其与 gtrue 的相关为 r、回归斜率为 b1、均值偏移为 off。

推导：设 sd(gtrue)=1。b1 = cov(gtrue,ĝ)/var(ĝ) = r·sd(ĝ)/sd(ĝ)² ⇒ sd(ĝ) = r/b1。
令 ĝ = a·g₀ + b·e（g₀、e 为独立标准化变量），则 a = r·sd(ĝ)、b = sd(ĝ)·√(1-r²)。
"""
function make_pred(gtrue, r, b1, off; rng=Random.default_rng())
    sd = r/b1; a = r*sd; b = sd*sqrt(1 - r^2)
    e  = randn(rng, length(gtrue)); e = (e .- mean(e))./std(e)
    g0 = (gtrue .- mean(gtrue))./std(gtrue)
    return a .* g0 .+ b .* e .+ mean(gtrue) .+ off
end

gtrue = randn(Xoshiro(2401), 20_000)
cases = ("(a) r=.7, b1=1.0, 无偏移" => (0.7, 1.0, 0.0),
         "(b) r=.7, b1=0.8, 无偏移" => (0.7, 0.8, 0.0),
         "(c) r=.7, b1=1.0, 偏移 0.3"  => (0.7, 1.0, 0.3))
@printf("%-26s%-10s%-10s%-12s%-12s%-12s\n",
        "情形", "实测 r", "实测 b1", "MSE", "偏移项", "尺度项")
for (nm, (rr, bb, off)) in cases
    gh = make_pred(gtrue, rr, bb, off; rng=Xoshiro(2402))
    ev = eval_prediction(gh, gtrue)
    d  = theil_decomposition(gh, gtrue)
    @printf("%-26s%-10.3f%-10.3f%-12.4f%-12.4f%-12.4f\n",
            nm, ev.r, ev.b1, d.total, d.bias, d.scale)
end
println("\n=> 情形 (c) 的偏移项直接进入 MSE，对“用 GEBV 定价”这类决策最有害；")
println("   情形 (b) 的膨胀在排序上无影响（r 相同），但顶端个体会系统性令人失望。")

# %% [markdown]
# ## 2　验证标准的换算（正文式 24.7–24.9）
#
# **最常见的错误**：直接把 $\mathrm{corr}(\hat g,y_c)$ 当作准确性。

# %%
"""模拟一个带世代与家系结构的群体，并做 GBLUP 预测。"""
function make_population(; nbase=150, ngen=6, nper=200, m=2000, h2=0.30, seed=24000)
    Mg, sire, dam, gen = sim_pedigree_genotypes(nbase, ngen, nper, m; rng=Xoshiro(seed))
    n = length(sire)
    p = vec(mean(Mg, dims=1)) ./ 2
    keep = findall(j -> 0.01 < p[j] < 0.99, eachindex(p))
    Z = Mg[:, keep] .- 2 .* p[keep]'
    s = 2*sum(p[keep] .* (1 .- p[keep]))
    G = (Z*Z') ./ s
    G .= 0.95 .* G .+ 0.05 .* Matrix(I, n, n)
    L = cholesky(Symmetric(G)).L
    g = L*randn(Xoshiro(seed+1), n)
    g .*= sqrt(h2)/std(g)
    y = 10.0 .+ g .+ randn(Xoshiro(seed+2), n).*sqrt(1-h2)
    return (y=y, g=g, G=G, Z=Z, gen=gen, sire=sire, dam=dam, h2=h2, n=n)
end

"""在给定训练集上做 GBLUP，返回全部个体的 ĝ。"""
function gblup_train(pop, train::Vector{Int}; h2=pop.h2)
    n = pop.n; lam = (1-h2)/h2
    Gi = inv(cholesky(Symmetric(pop.G)))
    W = zeros(length(train), n)
    for (k,i) in enumerate(train); W[k,i] = 1.0; end
    X = ones(length(train), 1)
    yt = pop.y[train]
    C = [X'X  X'W; W'X  W'W .+ lam .* Gi]
    sol = (C + 1e-10I) \ [X'yt; W'yt]
    return sol[2:end]
end

pop = make_population()
gen_last = maximum(pop.gen)
train = findall(g -> g < gen_last, pop.gen)
valid = findall(==(gen_last), pop.gen)
ghat  = gblup_train(pop, train)

yc = pop.y[valid] .- mean(pop.y[train])      # 校正表型
ev = eval_prediction(ghat[valid], yc)
h  = sqrt(pop.h2)
@printf("验证集 n_v = %d\n\n", length(valid))
@printf("corr(ĝ, y_c)            = %.4f   ← 常被错误地直接报告为“准确性”\n", ev.r)
@printf("corr(ĝ, y_c)/h          = %.4f   ← 正确的准确性估计（式 24.7）\n", ev.r/h)
@printf("corr(ĝ, g_true)         = %.4f   ← 真值（模拟中才知道）\n",
        cor(ghat[valid], pop.g[valid]))
@printf("\nb1 = Cov(y_c, ĝ)/Var(ĝ) = %.4f  （b1 不需要除以 h）\n", ev.b1)
@printf("均值差                   = %+.4f\n", ev.bias)
@printf("\n若把 %.4f 当作准确性，会低估 %.0f%%\n", ev.r, 100*(1 - ev.r/(ev.r/h)))

# %% [markdown]
# ## 3　四种交叉验证设计的对照（正文 §24.2）
#
# 回答正文思考题 6：**随机 $k$ 折的偏乐观有多大？**

# %%
"""四种划分方式。返回 (训练集, 验证集) 的向量。"""
function make_folds(pop; scheme::Symbol, k::Int=5, rng=Random.default_rng())
    n = pop.n
    if scheme === :random
        perm = randperm(rng, n)
        folds = [perm[i:k:end] for i in 1:k]
        return [(setdiff(1:n, f), f) for f in folds]
    elseif scheme === :generation
        gl = maximum(pop.gen)
        return [(findall(g -> g < gl, pop.gen), findall(==(gl), pop.gen))]
    elseif scheme === :family
        sires = unique(pop.sire[pop.sire .> 0])
        groups = [findall(==(s), pop.sire) for s in sires]
        shuffle!(rng, groups)
        chunks = [Int[] for _ in 1:k]
        for (i, g) in enumerate(groups); append!(chunks[mod1(i,k)], g); end
        return [(setdiff(1:n, c), c) for c in chunks if !isempty(c)]
    else
        error("未知划分方式：$scheme")
    end
end

"""在给定划分上评估，返回每折的 (r/h, b1)。"""
function cv_evaluate(pop, folds)
    rs = Float64[]; bs = Float64[]
    h = sqrt(pop.h2)
    for (tr, va) in folds
        (isempty(va) || length(tr) < 50) && continue
        gh = gblup_train(pop, tr)
        yc = pop.y[va] .- mean(pop.y[tr])
        e = eval_prediction(gh[va], yc)
        push!(rs, e.r/h); push!(bs, e.b1)
    end
    return rs, bs
end

@printf("%-16s%-10s%-16s%-16s%-14s\n", "划分方式", "折数", "准确性 均值", "准确性 标准差", "b1 均值")
for scheme in (:random, :family, :generation)
    folds = make_folds(pop; scheme=scheme, k=5, rng=Xoshiro(2410))
    rs, bs = cv_evaluate(pop, folds)
    @printf("%-16s%-10d%-16.4f%-16.4f%-14.3f\n",
            string(scheme), length(rs), mean(rs), std(rs; corrected=length(rs)>1), mean(bs))
end
println("\n=> 与正文 §24.2.2 的表一致：随机 k 折 > 按家系 > 按世代。")
println("   随机划分把同胞分到两边，验证个体的预测大量来自“兄弟姐妹的表型”。")

# 验证集与训练集的最大亲缘（正文 §24.2.1 的判据）
for scheme in (:random, :generation)
    folds = make_folds(pop; scheme=scheme, k=5, rng=Xoshiro(2411))
    tr, va = folds[1]
    mx = [maximum(view(pop.G, i, tr)) for i in va]
    @printf("\n%-12s 验证个体与训练集的最大 G_ik：中位数 %.3f ，  >0.4 的比例 %.1f%%\n",
            string(scheme), median(mx), 100*mean(mx .> 0.4))
end

# %% [markdown]
# ## 4　抽样误差与配对检验（正文式 24.11–24.13）

# %%
"""正文式 (24.11)：相关系数的近似标准误。"""
se_cor(r, n) = (1 - r^2)/sqrt(n - 1)

"""正文式 (24.12)：Fisher z 变换的置信区间。"""
function ci_cor(r, n; level=0.95)
    z = atanh(r); s = 1/sqrt(n - 3)
    q = quantile(Normal(), 1 - (1-level)/2)
    return tanh(z - q*s), tanh(z + q*s)
end

"""正文式 (24.13)：Hotelling–Williams 检验（比较两个共享一个变量的相关系数）。"""
function hotelling_williams(rA, rB, rAB, n)
    R = 1 - rA^2 - rB^2 - rAB^2 + 2*rA*rB*rAB
    rbar = (rA + rB)/2
    t = (rA - rB)*sqrt(((n-1)*(1 + rAB)) /
        (2*((n-1)/(n-3))*R + rbar^2*(1 - rAB)^3))
    p = 2*ccdf(TDist(n - 3), abs(t))
    return t, p
end

println("相关系数的抽样误差（r = 0.60）\n")
@printf("%-10s%-14s%-26s\n", "n_v", "SE(r)", "95% 置信区间")
for nv in (50, 100, 200, 500, 1000, 2000)
    lo, hi = ci_cor(0.60, nv)
    @printf("%-10d%-14.4f[%.3f, %.3f]\n", nv, se_cor(0.60, nv), lo, hi)
end

println("\n两个方法的比较（rA = 0.65, rB = 0.60）\n")
@printf("%-10s%-14s%-14s%-14s\n", "n_v", "r_AB", "t 统计量", "p 值")
for nv in (100, 200, 500), rab in (0.80, 0.95)
    t, p = hotelling_williams(0.65, 0.60, rab, nv)
    @printf("%-10d%-14.2f%-14.3f%-14.4f\n", nv, rab, t, p)
end
println("\n=> 两个方法的预测高度相关（r_AB = 0.95）时，配对检验的功效远高于独立比较；")
println("   这正是“所有方法必须用同一个划分”的统计理由（正文 §24.2.4 教训二）。")

# 蒙特卡洛验证 SE 公式
println("\n蒙特卡洛验证式 (24.11)：")
for nv in (50, 200, 1000)
    rs = Float64[]
    for rep in 1:4000
        rg = Xoshiro(5000 + rep)
        x = randn(rg, nv); y2 = 0.6 .* x .+ sqrt(1-0.36).*randn(rg, nv)
        push!(rs, cor(x, y2))
    end
    @printf("  n_v = %-6d  实测 SD(r) = %.4f ，  式 (24.11) = %.4f\n",
            nv, std(rs), se_cor(0.60, nv))
end

# %% [markdown]
# ## 5　LR 方法（正文式 24.15–24.19）

# %%
"""正文式 (24.15)–(24.19)：Legarra–Reverter 的 LR 方法。

`up` = 用"部分"数据得到的 EBV，`uw` = 用"全部"数据得到的 EBV，
两者都在同一批验证个体上取值。
"""
function lr_method(up::Vector{Float64}, uw::Vector{Float64};
                   s2u::Float64=1.0, Fbar::Float64=0.0, fbar::Float64=0.0)
    delta  = mean(up) - mean(uw)                       # 式 (24.15)
    b_wp   = cov(up, uw)/var(up)                       # 式 (24.16)
    rho_wp = cor(up, uw)                               # 式 (24.17)
    acc2   = cov(up, uw)/((1 + Fbar - 2*fbar)*s2u)     # 式 (24.19)
    return (delta=delta, b_wp=b_wp, rho_wp=rho_wp,
            acc_p=sqrt(max(acc2, 0.0)), n=length(up))
end

# partial = 截断到倒数第二代；whole = 全部数据
train_p = findall(g -> g < gen_last - 1, pop.gen)
train_w = findall(g -> g < gen_last,     pop.gen)
u_p = gblup_train(pop, train_p)
u_w = gblup_train(pop, train_w)

lr = lr_method(u_p[valid], u_w[valid]; s2u=pop.h2)
acc_p_true = cor(u_p[valid], pop.g[valid])
acc_w_true = cor(u_w[valid], pop.g[valid])

@printf("LR 方法（验证个体 n = %d）\n\n", lr.n)
@printf("  Δ_pw   = %+.4f          （期望 0）\n", lr.delta)
@printf("  b_wp   = %.4f           （期望 1，式 24.16）\n", lr.b_wp)
@printf("  ρ_wp   = %.4f           （≈ acc_p/acc_w，式 24.17）\n", lr.rho_wp)
@printf("  acc_p  = %.4f           （式 24.19）\n", lr.acc_p)
@printf("\n模拟中的真值：\n")
@printf("  acc_p(真) = %.4f ， acc_w(真) = %.4f ， 比值 = %.4f\n",
        acc_p_true, acc_w_true, acc_p_true/acc_w_true)
@printf("  LR 的 ρ_wp = %.4f  →  与真实比值相差 %.4f\n",
        lr.rho_wp, abs(lr.rho_wp - acc_p_true/acc_w_true))

# 人为制造偏差：方差组分错误 → b_wp 与 b1 同时偏离 1
println("\n人为高估遗传方差（用 h²=0.6 而真值 0.3）时：")
u_p_bad = gblup_train(pop, train_p; h2=0.6)
u_w_bad = gblup_train(pop, train_w; h2=0.6)
lr_bad  = lr_method(u_p_bad[valid], u_w_bad[valid]; s2u=pop.h2)
yc2 = pop.y[valid] .- mean(pop.y[train_w])
@printf("  LR   ： b_wp = %.3f  （正确模型 %.3f）\n", lr_bad.b_wp, lr.b_wp)
@printf("  传统 ： b1   = %.3f  （正确模型 %.3f）\n",
        eval_prediction(u_w_bad[valid], yc2).b1,
        eval_prediction(u_w[valid],     yc2).b1)
println("  => 两个指标同向变化，LR 不需要表型就能发出同样的警报（正文 §24.3.2）。")

# %% [markdown]
# ## 6　偏差诊断：分层 $b_1$ 与遗传趋势

# %%
"""按预测值分组做分层诊断（正文 §24.3.1）。"""
function stratified_b1(ghat, ycrit; ngroup=5)
    ord = sortperm(ghat)
    sz  = cld(length(ord), ngroup)
    rows = NamedTuple[]
    for k in 1:ngroup
        idx = ord[(k-1)*sz+1 : min(k*sz, length(ord))]
        isempty(idx) && continue
        push!(rows, (group=k, n=length(idx),
                     ghat=mean(ghat[idx]), yc=mean(ycrit[idx]),
                     b1=cov(ycrit[idx], ghat[idx])/var(ghat[idx])))
    end
    return rows
end

println("分层诊断（按 GEBV 五分位）\n")
@printf("%-8s%-8s%-14s%-14s%-10s\n", "分位", "n", "平均 ĝ", "平均 y_c", "组内 b1")
for r in stratified_b1(ghat[valid], yc; ngroup=5)
    @printf("%-8d%-8d%-14.4f%-14.4f%-10.3f\n", r.group, r.n, r.ghat, r.yc, r.b1)
end
println("\n理想情形：平均 ĝ 与平均 y_c 沿一条斜率 1 的直线；弯曲说明非线性偏差。")

"""遗传趋势：按世代的平均 EBV（正文 §24.3.3）。"""
function genetic_trend(u, gen)
    gs = sort(unique(gen))
    return [(gen=g, mean=mean(u[findall(==(g), gen)]),
             n=count(==(g), gen)) for g in gs]
end

println("\n遗传趋势\n")
@printf("%-8s%-8s%-14s%-14s\n", "世代", "n", "平均 ĝ", "平均 g_true")
for r in genetic_trend(u_w, pop.gen)
    idx = findall(==(r.gen), pop.gen)
    @printf("%-8d%-8d%-14.4f%-14.4f\n", r.gen, r.n, r.mean, mean(pop.g[idx]))
end
# 趋势斜率
gs = Float64.(pop.gen)
@printf("\n趋势斜率（回归 ĝ 于世代）      = %.5f\n", cov(gs, u_w)/var(gs))
@printf("趋势斜率（回归 g_true 于世代） = %.5f\n", cov(gs, pop.g)/var(gs))
println("=> 最后一代的 ĝ 被收缩（信息少），这是正常的“末端效应”而非偏差（正文 §24.3.3）。")

# %% [markdown]
# ## 7　自动生成验证报告（正文 §24.4.5）

# %%
"""生成一份符合正文 §24.4.5 规范的验证报告。"""
function validation_report(io::IO; trait, model, n_train, n_geno, n_valid,
                           ghat, ycrit, h2, r_crit=nothing,
                           up=nothing, uw=nothing, s2u=1.0,
                           ghat_ref=nothing, cutoff="")
    e = eval_prediction(ghat, ycrit)
    denom = r_crit === nothing ? sqrt(h2) : r_crit
    acc = e.r/denom
    lo, hi = ci_cor(e.r, e.n)
    println(io, "性状：", trait)
    println(io, "模型：", model)
    @printf(io, "训练数据：%s（n = %d 表型；n2 = %d 基因型）\n", cutoff, n_train, n_geno)
    @printf(io, "验证群体：n_v = %d ，验证标准的平均可靠性 = %.3f\n\n", n_valid, denom^2)
    println(io, "准确性")
    @printf(io, "  corr(GEBV, 标准)          = %.4f   SE = %.4f   95%%CI [%.3f, %.3f]\n",
            e.r, se_cor(e.r, e.n), lo, hi)
    @printf(io, "  acc = corr / %.3f         = %.4f\n", denom, acc)
    if ghat_ref !== nothing
        rB = cor(ghat_ref, ycrit); rAB = cor(ghat, ghat_ref)
        t, p = hotelling_williams(e.r, rB, rAB, e.n)
        @printf(io, "  与参照方程比较（配对）     = %+.4f   (Hotelling–Williams p = %.4f)\n",
                (e.r - rB)/denom, p)
    end
    println(io, "\n偏差")
    @printf(io, "  b1 = Cov(标准, GEBV)/Var(GEBV) = %.4f   %s\n", e.b1,
            0.9 <= e.b1 <= 1.1 ? "（可接受）" : "⚠ 超出 [0.9, 1.1]")
    @printf(io, "  均值差 mean(GEBV) − mean(标准) = %+.4f\n", e.bias)
    @printf(io, "  MSE                            = %.4f\n", e.mse)
    if up !== nothing && uw !== nothing
        lr = lr_method(up, uw; s2u=s2u)
        println(io, "\nLR 方法")
        @printf(io, "  Δ_pw = %+.4f ， b_wp = %.4f ， ρ_wp = %.4f ， acc_p = %.4f\n",
                lr.delta, lr.b_wp, lr.rho_wp, lr.acc_p)
    end
    println(io, "\n分层诊断（按 GEBV 五分位的 b1）")
    print(io, "  ")
    for r in stratified_b1(ghat, ycrit; ngroup=5); @printf(io, "%.2f  ", r.b1); end
    println(io)
    println(io, "\n结论：",
            (0.9 <= e.b1 <= 1.1 && e.n >= 200) ? "可上线。" : "需进一步排查（见上方标记项）。")
    return nothing
end

# 参照方程：只用一半训练数据
ghat_ref = gblup_train(pop, train[1:2:end])
println(repeat("=", 66))
validation_report(stdout; trait="模拟性状（h² = $(pop.h2)）",
    model="GBLUP（G_w，w = 0.05）",
    n_train=length(train), n_geno=pop.n, n_valid=length(valid),
    ghat=ghat[valid], ycrit=yc, h2=pop.h2,
    up=u_p[valid], uw=u_w[valid], s2u=pop.h2,
    ghat_ref=ghat_ref[valid], cutoff="截至第 $(gen_last-1) 世代")
println(repeat("=", 66))

# %% [markdown]
# ## 8　自检汇总

# %%
ok = Bool[]
# Fisher z 的往返
push!(ok, check("Fisher z 往返", tanh(atanh(0.6)), 0.6; tol=1e-14))
# SE 公式与蒙特卡洛
let nv = 500, rs = Float64[]
    for rep in 1:6000
        rg = Xoshiro(9000+rep)
        x = randn(rg, nv); y2 = 0.6 .* x .+ sqrt(1-0.36).*randn(rg, nv)
        push!(rs, cor(x, y2))
    end
    @printf("\n式 (24.11) 蒙特卡洛：实测 SD = %.4f ， 公式 = %.4f （相对差 %.1f%%）\n",
            std(rs), se_cor(0.6, nv), 100*abs(std(rs)/se_cor(0.6,nv) - 1))
    push!(ok, abs(std(rs)/se_cor(0.6,nv) - 1) < 0.08)
end
# Theil 分解求和
let d = theil_decomposition(ghat[valid], yc)
    @printf("Theil 分解：三项之和 = %.5f ，  MSE = %.5f\n", d.sum, d.total)
    push!(ok, check("Theil 分解三项之和 = MSE", d.sum, d.total; tol=1e-10))
end
# b1 在正确模型下接近 1
@printf("正确模型的 b1 = %.3f （应在 [0.9, 1.1]）\n", eval_prediction(ghat[valid], yc).b1)
push!(ok, 0.85 <= eval_prediction(ghat[valid], yc).b1 <= 1.15)
# LR 的 b_wp 在正确模型下接近 1
@printf("正确模型的 b_wp = %.3f\n", lr.b_wp)
push!(ok, 0.80 <= lr.b_wp <= 1.20)
# Hotelling–Williams：两个相关相同时 t = 0
let (t, p) = hotelling_williams(0.6, 0.6, 0.9, 500)
    push!(ok, check("rA = rB ⇒ t = 0", t, 0.0; tol=1e-12))
end
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
