# 本脚本由 tools/nb2jl.py 从同目录的 appA.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl appA

# %% [markdown]
# # 附录 A　矩阵代数与数学基础 —— 配套代码
#
# 本 Notebook 对应附录 A。附录 A 是全书推导的"工具箱"，这里对其中**每一个恒等式做数值验证**：随机生成满足条件的矩阵，分别按等式两边计算，比较相对误差。数值验证不能代替证明，但能在几秒内发现抄写错误、下标错误与条件遗漏——这正是第五章"验证优先"的做法。
#
# | 节 | 内容 | 对应附录 A |
# |:--|:--|:--|
# | 1 | 迹的循环性、行列式的对数计算与溢出 | 式 (A.1)–(A.2) |
# | 2 | 分块矩阵：Schur 补、分块行列式、分块求逆 | 式 (A.3)–(A.5) |
# | 3 | Woodbury 恒等式及其三个用途（含 REML 核心恒等式） | 式 (A.6)–(A.8a) |
# | 4 | Cholesky 与 $\mathbf{LDL}'$：$\mathbf L=\mathbf{TD}^{1/2}$（第二版勘误 1-1） | 式 (A.9)，第九章式 (9.8) |
# | 5 | 一次特征分解处理任意多个正则化参数 | 式 (A.10) |
# | 6 | 广义逆：Penrose 条件、通解、投影阵的不变性 | 式 (A.11)–(A.13) |
# | 7 | Kronecker 积与 vec 算子 | 式 (A.14)–(A.16) |
# | 8 | 矩阵微分与 REML 得分的有限差分核对 | 式 (A.17)–(A.20) |
# | 9 | 二次型的期望、方差与加权卡方分布 | 式 (A.21)–(A.23) |
# | 10 | 多元正态的条件分布 | 式 (A.24)–(A.25) |
# | 11 | 两个常用积分 | 式 (A.26)–(A.27) |
# | 12 | 数值计算的基本准则：不要显式求逆 | §A.13 |
# | 13 | 自检汇总 | — |

# %%
using LinearAlgebra, Random, Printf, Statistics, Distributions, SpecialFunctions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-10)
    e = relerr(a, b)
    @printf("%-50s 相对误差 = %.2e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
ok = Bool[]

"""随机对称正定矩阵，条件数约为 κ。"""
function randpd(rng, n; κ=10.0)
    Q = Matrix(qr(randn(rng, n, n)).Q)
    λ = exp.(range(0, log(κ), length=n))
    return Matrix(Symmetric(Q * Diagonal(λ) * Q'))
end
rng = Xoshiro(20260918)
println("Julia ", VERSION)

# %% [markdown]
# ## 1　迹与行列式（式 A.1–A.2）
#
# 迹的循环性 $\mathrm{tr}(\mathbf{ABC})=\mathrm{tr}(\mathbf{BCA})$ 是 REML 推导的主力工具。行列式**永远在对数尺度上计算**：由 Cholesky 因子 $\log|\mathbf A|=2\sum\log l_{ii}$；直接计算 $|\mathbf A|$ 在稍大的矩阵上就会溢出。

# %%
let A = randn(rng, 4, 6), B = randn(rng, 6, 5), C = randn(rng, 5, 4)
    push!(ok, check("式 (A.1) tr(ABC) = tr(BCA)", tr(A*B*C), tr(B*C*A)))
    push!(ok, check("式 (A.1) tr(ABC) = tr(CAB)", tr(A*B*C), tr(C*A*B)))
end
let S = randpd(rng, 50; κ=1e3)
    L = cholesky(Symmetric(S)).L
    push!(ok, check("式 (A.2) log|A| = 2Σ log l_ii", 2sum(log, diag(L)), logdet(S)))
end
let S = 10.0 * Matrix(I, 400, 400)
    @printf("\n400×400 的 10I：det = %s ，logdet = %.4f （= 400·log 10 = %.4f）\n",
            string(det(S)), logdet(S), 400log(10))
    push!(ok, isinf(det(S)) && isapprox(logdet(S), 400log(10); rtol=1e-12))
end

# %% [markdown]
# ## 2　分块矩阵（式 A.3–A.5）
#
# $\mathbf M=\begin{bmatrix}\mathbf A&\mathbf B\\\mathbf C&\mathbf D\end{bmatrix}$，Schur 补 $\mathbf S=\mathbf D-\mathbf{CA}^{-1}\mathbf B$。验证分块行列式与分块求逆，并确认"逆的右下块 = Schur 补的逆"——这就是 MME 中 $\mathbf C^{uu}$ 与吸收法的代数基础。

# %%
let n1 = 4, n2 = 3
    Mx = randpd(rng, n1 + n2; κ=50.0)
    A = Mx[1:n1, 1:n1];      B = Mx[1:n1, n1+1:end]
    Cb = Mx[n1+1:end, 1:n1]; D = Mx[n1+1:end, n1+1:end]
    S  = D - Cb * (A \ B)
    push!(ok, check("式 (A.4) |M| = |A|·|S|", logdet(Mx), logdet(A) + logdet(S)))
    Ai, Si = inv(A), inv(S)
    Minv = [Ai + Ai*B*Si*Cb*Ai   -Ai*B*Si;
            -Si*Cb*Ai             Si]
    push!(ok, check("式 (A.5) 分块求逆", Minv, inv(Mx)))
    push!(ok, check("逆的右下块 = Schur 补的逆", inv(Mx)[n1+1:end, n1+1:end], Si))
end

# %% [markdown]
# ## 3　Woodbury 恒等式及其三个用途（式 A.6–A.8a）
#
# 1. $\mathbf V^{-1}$ 的混合模型形式（式 A.8）：$N\times N$ 的求逆换成 $q\times q$；
# 2. SNP-BLUP 与 GBLUP 的等价（"推出恒等式"）：$\mathbf Z(\mathbf Z'\mathbf Z+\lambda\mathbf I_m)^{-1}\mathbf Z'=\mathbf{ZZ}'(\mathbf{ZZ}'+\lambda\mathbf I_n)^{-1}$；
# 3. 行列式引理与 REML 的核心恒等式（式 A.8a）：$\log|\mathbf V|+\log|\mathbf X'\mathbf V^{-1}\mathbf X|=\log|\mathbf R|+\log|\mathbf G|+\log|\mathbf C|$，$\mathbf y'\mathbf{Py}=\mathbf y'\mathbf R^{-1}\mathbf y-\hat{\mathbf s}'\mathbf r$。

# %%
# 一般形式 (A.6) 与秩一更新 (A.7)
let n = 8, k = 3
    A = randpd(rng, n); U = randn(rng, n, k); V = randn(rng, k, n); Cm = randpd(rng, k)
    lhs = inv(A + U*Cm*V)
    rhs = inv(A) - inv(A)*U*inv(inv(Cm) + V*inv(A)*U)*V*inv(A)
    push!(ok, check("式 (A.6) Woodbury", lhs, rhs; tol=1e-9))
    u = randn(rng, n); v = randn(rng, n)
    rhs1 = inv(A) - (inv(A)*u*v'*inv(A)) / (1 + v'*inv(A)*u)
    push!(ok, check("式 (A.7) Sherman–Morrison", inv(A + u*v'), rhs1; tol=1e-9))
    # 行列式引理
    push!(ok, check("行列式引理 |A+UCV| = |C⁻¹+VA⁻¹U||C||A|",
                    logabsdet(A + U*Cm*V)[1], logabsdet(inv(Cm) + V*inv(A)*U)[1] + logdet(Cm) + logdet(A)))
end
# 推出恒等式：SNP-BLUP 与 GBLUP 给出同一个预测
let n = 30, m = 200, λ = 2.5
    Z = randn(rng, n, m)
    lhs = Z * ((Z'Z + λ*I) \ Z')
    rhs = (Z*Z') * inv(Z*Z' + λ*I)
    push!(ok, check("推出恒等式（m=200 维 vs n=30 维）", lhs, rhs; tol=1e-9))
end

# %%
# 式 (A.8) 与 (A.8a)：在一个小型混合模型上核对
let N = 60, q = 40
    X  = hcat(ones(N), randn(rng, N))
    Z  = zeros(N, q); for i in 1:N; Z[i, rand(rng, 1:q)] = 1.0; end
    G  = 2.0 .* randpd(rng, q; κ=20.0)
    R  = Diagonal(fill(3.0, N))
    V  = Matrix(R) + Z*G*Z'
    y  = X*[1.0, 0.5] + Z*(cholesky(Symmetric(G)).L*randn(rng, q)) + sqrt(3.0)*randn(rng, N)
    Ri, Gi = inv(R), inv(G)
    Vi_w = Matrix(Ri) - Ri*Z*inv(Z'*Ri*Z + Gi)*Z'*Ri
    push!(ok, check("式 (A.8) V⁻¹ 的混合模型形式", Vi_w, inv(V); tol=1e-9))
    Cmme = [X'*Ri*X  X'*Ri*Z; Z'*Ri*X  Z'*Ri*Z + Gi]
    rmme = [X'*Ri*y; Z'*Ri*y]
    s  = Cmme \ rmme
    Vi = inv(V)
    P  = Vi - Vi*X*inv(X'*Vi*X)*X'*Vi
    push!(ok, check("式 (A.8a) log|V|+log|X'V⁻¹X| = log|R|+log|G|+log|C|",
                    logdet(V) + logdet(X'*Vi*X), logdet(R) + logdet(G) + logdet(Symmetric(Cmme)); tol=1e-9))
    push!(ok, check("式 (A.8a) y'Py = y'R⁻¹y − ŝ'r", y'*P*y, y'*Ri*y - s'*rmme; tol=1e-9))
    println("\n=> REML 似然的全部组成部分都能由 MME 的分解与解得到，无需形成 N×N 的 V。")
end

# %% [markdown]
# ## 4　Cholesky 与 $\mathbf{LDL}'$：$\mathbf L=\mathbf{TD}^{1/2}$（式 A.9；第二版勘误 1-1）
#
# 用第九章的 7 个体系谱构造 $\mathbf A$、$\mathbf T=(\mathbf I-\mathbf P)^{-1}$ 与孟德尔抽样方差 $\mathbf D$，验证：
#
# - $\mathbf A=\mathbf{TDT}'$（第九章式 9.8）；
# - Cholesky 因子 $\mathbf L=\mathbf{TD}^{1/2}$，即 $l_{ii}=\sqrt{d_i}$；
# - 第二版写的 $\mathbf L=\mathbf{TD}$ **不成立**。

# %%
sire = [0, 0, 1, 1, 3, 1, 5]; dam = [0, 0, 0, 2, 4, 4, 6]

"""表格法构造 A（第九章式 9.2–9.3）；个体须按"亲本在前"编号。"""
function build_A(sire, dam)
    n = length(sire); A = zeros(n, n)
    for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            a = 0.0
            s > 0 && (a += 0.5 * A[j, s])
            d > 0 && (a += 0.5 * A[j, d])
            A[i, j] = a; A[j, i] = a
        end
        A[i, i] = 1.0 + ((s > 0 && d > 0) ? 0.5 * A[s, d] : 0.0)
    end
    return A
end

"""T = (I − P)⁻¹ 与孟德尔抽样方差 D（第九章式 9.5–9.8）。小例子直接求逆；大规模时用递推。"""
function build_TD(sire, dam, A)
    n = length(sire); P = zeros(n, n); d = zeros(n)
    F = diag(A) .- 1.0
    for i in 1:n
        s, dd = sire[i], dam[i]
        s  > 0 && (P[i, s]  = 0.5)
        dd > 0 && (P[i, dd] = 0.5)
        d[i] = (s > 0 && dd > 0) ? 0.5 - 0.25 * (F[s] + F[dd]) :
               s > 0  ? 0.75 - 0.25 * F[s]  :
               dd > 0 ? 0.75 - 0.25 * F[dd] : 1.0
    end
    return inv(Matrix(1.0I, n, n) - P), Diagonal(d)
end

A7 = build_A(sire, dam)
T7, D7 = build_TD(sire, dam, A7)
@printf("近交系数 F = %s\n", string(round.(diag(A7) .- 1; digits=5)))
push!(ok, check("第九章手算：F₅, F₆, F₇ = 0.125, 0.25, 0.28125", diag(A7)[5:7] .- 1, [0.125, 0.25, 0.28125]; tol=1e-14))
push!(ok, check("A = T D T'", T7 * D7 * T7', A7; tol=1e-13))
L7 = cholesky(Symmetric(A7)).L
push!(ok, check("Cholesky 因子 L = T D^{1/2}", Matrix(L7), T7 * sqrt(D7); tol=1e-12))
push!(ok, check("l_ii² = d_i", diag(L7).^2, diag(D7); tol=1e-12))
@printf("第二版的 L = TD：‖(TD)(TD)' − A‖ = %.3f （不为零，故错误）\n", norm((T7*D7)*(T7*D7)' - A7))
push!(ok, norm((T7*D7)*(T7*D7)' - A7) > 0.1)

# %% [markdown]
# ## 5　一次特征分解，任意多个正则化参数（式 A.10）
#
# $(\mathbf G+\delta\mathbf I)^{-1}=\mathbf U(\boldsymbol\Lambda+\delta\mathbf I)^{-1}\mathbf U'$：对 $\mathbf G$ 做一次 $O(n^3)$ 的分解后，每个新的 $\delta$ 只需 $O(n^2)$。这是 GREML 中单个关系矩阵时特征分解加速的原理（第十八章 §18.5.4）。

# %%
let n = 60
    Zg = randn(rng, n, 400); G = Zg*Zg' / 400
    E = eigen(Symmetric(G)); U, Λ = E.vectors, E.values
    for δ in (0.01, 0.1, 1.0)
        push!(ok, check(@sprintf("式 (A.10) δ = %.2f", δ), U * Diagonal(1 ./ (Λ .+ δ)) * U', inv(G + δ*I); tol=1e-8))
    end
end

# %% [markdown]
# ## 6　广义逆（式 A.11–A.13）
#
# 一因子模型 $\mathbf X=[\mathbf 1\ \ \mathbf X_A]$ 列秩亏 1。取两种不同的广义逆：Moore–Penrose 逆与"置零"广义逆（去掉截距列对应的行列后求逆、其余置零）。二者给出**不同**的 $\hat{\boldsymbol\beta}$，但**相同**的投影阵、拟合值与可估函数的估计——这就是第十一章可估性理论的核心。

# %%
let n = 24, k = 4
    lev = repeat(1:k, inner=n÷k)
    XA  = zeros(n, k); for i in 1:n; XA[i, lev[i]] = 1.0; end
    X   = hcat(ones(n), XA)                      # 5 列，秩 4
    y   = X * [10.0, 1.0, -0.5, 2.0, 0.0] + randn(rng, n)
    XtX = X'X
    G1  = pinv(XtX)                              # Moore–Penrose 逆
    G2  = zeros(k+1, k+1); G2[2:end, 2:end] = inv(XtX[2:end, 2:end])   # 置零广义逆
    for (nm, Gm) in (("Moore–Penrose", G1), ("置零", G2))
        push!(ok, check("广义逆定义 (X'X)G(X'X) = X'X：" * nm, XtX*Gm*XtX, XtX; tol=1e-10))
    end
    Ap = pinv(X)
    push!(ok, check("式 (A.11) Penrose 条件 1", X*Ap*X, X; tol=1e-10))
    push!(ok, check("式 (A.11) Penrose 条件 2", Ap*X*Ap, Ap; tol=1e-10))
    push!(ok, check("式 (A.11) Penrose 条件 3", (X*Ap)', X*Ap; tol=1e-10))
    push!(ok, check("式 (A.11) Penrose 条件 4", (Ap*X)', Ap*X; tol=1e-10))
    b1, b2 = G1*X'y, G2*X'y
    @printf("两种广义逆的解：β̂₁[1] = %.4f，β̂₂[1] = %.4f （不同）\n", b1[1], b2[1])
    push!(ok, abs(b1[1] - b2[1]) > 1e-3)
    push!(ok, check("式 (A.13) 投影阵 X(X'X)⁻X' 不依赖广义逆", X*G1*X', X*G2*X'; tol=1e-10))
    kvec = [0.0, 1.0, -1.0, 0.0, 0.0]            # 水平 1 与水平 2 之差：可估
    push!(ok, check("可估函数 k'β̂ 不依赖广义逆", kvec'b1, kvec'b2; tol=1e-10))
    # 式 (A.12)：相容方程组的通解
    b = XtX * randn(rng, k+1)                    # 保证相容
    z = randn(rng, k+1)
    xgen = G2*b + (I - G2*XtX)*z
    push!(ok, check("式 (A.12) 通解满足方程", XtX*xgen, b; tol=1e-10))
end

# %% [markdown]
# ## 7　Kronecker 积与 vec 算子（式 A.14–A.16）
#
# 多性状模型 $\mathrm{Var}(\mathbf u)=\mathbf G_0\otimes\mathbf A$ 的逆只需 $(\mathbf G_0^{-1}\otimes\mathbf A^{-1})$（第十四章）。

# %%
let A = randpd(rng, 3), B = randpd(rng, 4), Cc = randn(rng, 3, 3), D = randn(rng, 4, 4)
    push!(ok, check("式 (A.14) 混合积", kron(A, B) * kron(Cc, D), kron(A*Cc, B*D)))
    push!(ok, check("式 (A.14) (A⊗B)⁻¹ = A⁻¹⊗B⁻¹", inv(kron(A, B)), kron(inv(A), inv(B)); tol=1e-9))
    push!(ok, check("式 (A.15) |A⊗B| = |A|^q |B|^p", logdet(kron(A, B)), 4logdet(A) + 3logdet(B)))
    push!(ok, check("式 (A.15) tr(A⊗B) = tr(A)tr(B)", tr(kron(A, B)), tr(A)*tr(B)))
end
let A = randn(rng, 3, 4), B = randn(rng, 4, 5), Cc = randn(rng, 5, 2)
    push!(ok, check("式 (A.16) vec(ABC) = (C'⊗A)vec(B)", vec(A*B*Cc), kron(Cc', A) * vec(B)))
end

# %% [markdown]
# ## 8　矩阵微分：有限差分核对（式 A.17–A.20）
#
# 对 $\mathbf V(\boldsymbol\theta)=\sigma_a^2\mathbf{ZAZ}'+\sigma_e^2\mathbf I$，用中心差分核对
#
# $$\frac{\partial\mathbf V^{-1}}{\partial\theta}=-\mathbf V^{-1}\mathbf V_\theta\mathbf V^{-1},\qquad
# \frac{\partial\log|\mathbf V|}{\partial\theta}=\mathrm{tr}(\mathbf V^{-1}\mathbf V_\theta),\qquad
# \frac{\partial\ell_R}{\partial\theta_i}=-\tfrac12\left[\mathrm{tr}(\mathbf{PV}_i)-\mathbf y'\mathbf{PV}_i\mathbf{Py}\right]$$
#
# **这是检查自己推导的得分向量的最廉价方法**：得分与有限差分不一致，推导或代码必有错。

# %%
let N = 50, q = 35
    Z  = zeros(N, q); for i in 1:N; Z[i, rand(rng, 1:q)] = 1.0; end
    Ar = randpd(rng, q; κ=5.0)
    Va, Ve = Z*Ar*Z', Matrix(1.0I, N, N)
    X  = hcat(ones(N), randn(rng, N))
    y  = X*[2.0, 1.0] + Z*(cholesky(Symmetric(Ar)).L*randn(rng, q))*sqrt(2.0) + randn(rng, N)
    Vf(θ) = θ[1]*Va + θ[2]*Ve
    function ellR(θ)
        V = Vf(θ); Vi = inv(V); XVX = X'*Vi*X
        P = Vi - Vi*X*inv(XVX)*X'*Vi
        return -0.5*(logdet(V) + logdet(XVX) + y'*P*y)
    end
    θ0 = [2.0, 1.0]; h = 1e-5
    # (A.18) 与 (A.19)
    dVi_fd = (inv(Vf(θ0 + [h, 0])) - inv(Vf(θ0 - [h, 0]))) / (2h)
    push!(ok, check("式 (A.18) ∂V⁻¹/∂θ", dVi_fd, -inv(Vf(θ0))*Va*inv(Vf(θ0)); tol=1e-6))
    dld_fd = (logdet(Vf(θ0 + [h, 0])) - logdet(Vf(θ0 - [h, 0]))) / (2h)
    push!(ok, check("式 (A.19) ∂log|V|/∂θ", dld_fd, tr(inv(Vf(θ0))*Va); tol=1e-7))
    # (A.20) REML 得分
    V = Vf(θ0); Vi = inv(V); P = Vi - Vi*X*inv(X'*Vi*X)*X'*Vi
    score = [-0.5*(tr(P*Vk) - y'*P*Vk*P*y) for Vk in (Va, Ve)]
    fd = [(ellR(θ0 + h*e) - ellR(θ0 - h*e)) / (2h) for e in ([1.0, 0.0], [0.0, 1.0])]
    push!(ok, check("式 (A.20) REML 得分 = 有限差分", score, fd; tol=1e-6))
    # (A.17) 二次型对向量的导数
    Aq = randn(rng, 5, 5); x0 = randn(rng, 5)
    gfd = [((x0 + h*e)'*Aq*(x0 + h*e) - (x0 - h*e)'*Aq*(x0 - h*e)) / (2h) for e in eachcol(Matrix(1.0I, 5, 5))]
    push!(ok, check("式 (A.17) ∂x'Ax/∂x = (A+A')x", gfd, (Aq + Aq')*x0; tol=1e-8))
end

# %% [markdown]
# ## 9　二次型的期望、方差与分布（式 A.21–A.23）
#
# $\mathbf y\sim N(\boldsymbol\mu,\mathbf V)$。期望公式 (A.21) 不需要正态性；方差公式 (A.22) 需要正态性；$\boldsymbol\mu=\mathbf 0$ 时 $\mathbf y'\mathbf{Ay}$ 与独立卡方的加权和同分布 (A.23)——SKAT 的零分布正是这样来的（第二十七章）。蒙特卡洛核对的容差按抽样误差设定。

# %%
let n = 5, nsim = 200_000
    V  = randpd(rng, n; κ=8.0); L = cholesky(Symmetric(V)).L
    Aq = Matrix(Symmetric(randn(rng, n, n)))
    μ  = randn(rng, n)
    Y  = μ .+ L * randn(rng, n, nsim)
    Q  = [dot(c, Aq, c) for c in eachcol(Y)]
    Eth = tr(Aq*V) + μ'*Aq*μ
    Vth = 2tr(Aq*V*Aq*V) + 4μ'*Aq*V*Aq*μ
    @printf("E(y'Ay)：模拟 %.4f，式 (A.21) %.4f\n", mean(Q), Eth)
    @printf("Var(y'Ay)：模拟 %.4f，式 (A.22) %.4f\n", var(Q), Vth)
    push!(ok, abs(mean(Q) - Eth) < 4sqrt(Vth/nsim))
    push!(ok, abs(var(Q)/Vth - 1) < 0.03)
    # (A.23)：μ = 0 时与 Σλχ² 同分布
    Q0  = [dot(c, Aq, c) for c in eachcol(L * randn(rng, n, nsim))]
    λ   = eigvals(Symmetric(L'*Aq*L))
    Qmx = vec(sum(λ .* randn(rng, n, nsim).^2; dims=1))
    qs  = (0.1, 0.5, 0.9, 0.99)
    for p in qs
        @printf("  %4.2f 分位数：y'Ay = %8.4f   Σλχ² = %8.4f\n", p, quantile(Q0, p), quantile(Qmx, p))
    end
    spread = quantile(Qmx, 0.99) - quantile(Qmx, 0.01)          # 容差按分布的尺度设定
    push!(ok, all(abs(quantile(Q0, p) - quantile(Qmx, p)) < 0.02*spread for p in qs))
end

# %% [markdown]
# ## 10　多元正态的条件分布（式 A.24–A.25）
#
# $\mathbf y_1\mid\mathbf y_2\sim N\big(\boldsymbol\mu_1+\boldsymbol\Sigma_{12}\boldsymbol\Sigma_{22}^{-1}(\mathbf y_2-\boldsymbol\mu_2),\ \boldsymbol\Sigma_{11}-\boldsymbol\Sigma_{12}\boldsymbol\Sigma_{22}^{-1}\boldsymbol\Sigma_{21}\big)$。两种核对：（1）条件协方差等于精度矩阵左上块的逆（分块求逆 A.5 的推论）；（2）模拟后把 $y_1$ 对 $\mathbf y_2$ 回归，回归系数与残差方差应与公式一致。BLUP（第十二章）与单步法中由有基因型个体推断无基因型个体（第二十三章）都是这个公式。

# %%
let Σ = randpd(rng, 3; κ=6.0), μ = [1.0, -1.0, 0.5], nsim = 400_000
    b_th = Σ[1:1, 2:3] / Σ[2:3, 2:3]
    v_th = Σ[1, 1] - (Σ[1:1, 2:3] / Σ[2:3, 2:3] * Σ[2:3, 1:1])[1]
    Qp   = inv(Σ)
    push!(ok, check("条件方差 = 1/(Σ⁻¹)₁₁", 1/Qp[1, 1], v_th; tol=1e-12))
    Y  = μ .+ cholesky(Symmetric(Σ)).L * randn(rng, 3, nsim)
    Xr = hcat(ones(nsim), Y[2, :], Y[3, :])
    β  = Xr \ Y[1, :]
    res = Y[1, :] - Xr*β
    @printf("回归系数：模拟 (%.4f, %.4f)，公式 (%.4f, %.4f)\n", β[2], β[3], b_th[1], b_th[2])
    @printf("残差方差：模拟 %.4f，公式 %.4f\n", var(res), v_th)
    push!(ok, maximum(abs.(β[2:3] .- vec(b_th))) < 0.01 && abs(var(res)/v_th - 1) < 0.01)
end

# %% [markdown]
# ## 11　两个常用积分（式 A.26–A.27）
#
# 式 (A.26) 是所有逆卡方完全条件分布的归一化常数来源；式 (A.27) 是把 $\boldsymbol\beta$ 积掉得到 REML 似然（第十七章式 17.16）的工具。这里用数值积分核对：前者作变量替换 $u=e^s$ 后在 $s$ 上用梯形法（被积函数光滑且两端超指数衰减，梯形法极其精确）；后者在二维网格上积分。

# %%
# (A.26)：∫₀^∞ u^{-a-1} e^{-b/u} du = Γ(a) b^{-a}；令 u = e^s，被积函数变为 exp(-a s - b e^{-s})
let a = 2.5, b = 1.7, hs = 1e-3
    s = -12.0:hs:60.0
    f = exp.(-a .* s .- b .* exp.(-s))
    num = hs * (sum(f) - 0.5*(f[1] + f[end]))
    push!(ok, check("式 (A.26) 数值积分 = Γ(a)b^{-a}", num, gamma(a) * b^(-a); tol=1e-9))
end
# (A.27)：∫ exp(-½x'Ax + b'x) dx = (2π)^{n/2}|A|^{-1/2} exp(½ b'A⁻¹b)，n = 2
let A = [2.0 0.5; 0.5 1.0], b = [0.3, -0.2], h = 0.02
    g = -12.0:h:12.0
    tot = 0.0
    for x1 in g, x2 in g
        x = [x1, x2]
        tot += exp(-0.5 * dot(x, A, x) + dot(b, x))
    end
    num = tot * h^2
    push!(ok, check("式 (A.27) 二维数值积分", num, 2π / sqrt(det(A)) * exp(0.5 * dot(b, A \ b)); tol=1e-8))
end

# %% [markdown]
# ## 12　数值计算的基本准则：解方程，不要显式求逆（§A.13）
#
# 对病态矩阵，`A \ b` 的残差比 `inv(A) * b` 小几个数量级；而且求逆的计算量是解一次方程的约三倍。第三章 §3.1.2 讨论了条件数对精度的放大作用。

# %%
let n = 12
    H = [1.0/(i + j - 1) for i in 1:n, j in 1:n]    # Hilbert 矩阵，条件数约 1e16
    xt = ones(n); b = H * xt
    x1 = H \ b; x2 = inv(H) * b
    @printf("cond(H) = %.2e\n", cond(H))
    @printf("A\\b      的残差 ‖Hx−b‖ = %.2e\n", norm(H*x1 - b))
    @printf("inv(A)*b 的残差 ‖Hx−b‖ = %.2e\n", norm(H*x2 - b))
    push!(ok, norm(H*x1 - b) <= norm(H*x2 - b))
    println("=> 病态问题的解（误差）本身可能很大，但反斜杠给出的解其残差总是更小——它是后向稳定的。")
end

# %% [markdown]
# ## 13　自检汇总

# %%
@printf("全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
all(ok) || println("失败的检查序号：", findall(!, ok))
