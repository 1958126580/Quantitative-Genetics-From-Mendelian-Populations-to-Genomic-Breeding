# 附录 A　矩阵代数与数学基础 —— 配套代码

**对应正文**：附录 A

## 文件

| 文件 | 说明 |
|:--|:--|
| `appA.ipynb` | IJulia 笔记本：15 个代码单元，约 265 行 Julia 代码，穿插与正文对应的说明 |
| `appA.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |

## 笔记本内容

- 1　迹与行列式（式 A.1–A.2）
- 2　分块矩阵（式 A.3–A.5）
- 3　Woodbury 恒等式及其三个用途（式 A.6–A.8a）
- 4　Cholesky 与 $\mathbf{LDL}'$：$\mathbf L=\mathbf{TD}^{1/2}$（式 A.9；第二版勘误 1-1）
- 5　一次特征分解，任意多个正则化参数（式 A.10）
- 6　广义逆（式 A.11–A.13）
- 7　Kronecker 积与 vec 算子（式 A.14–A.16）
- 8　矩阵微分：有限差分核对（式 A.17–A.20）
- 9　二次型的期望、方差与分布（式 A.21–A.23）
- 10　多元正态的条件分布（式 A.24–A.25）
- 11　两个常用积分（式 A.26–A.27）
- 12　数值计算的基本准则：解方程，不要显式求逆（§A.13）
- 13　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl appA
```

或在 Jupyter 中打开 `appA/appA.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 本章没有单独的 Python 复核脚本：正文中的解析数值已在写作时用 Python 逐一复算。
