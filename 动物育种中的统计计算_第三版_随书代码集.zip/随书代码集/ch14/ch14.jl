# 本脚本由 tools/nb2jl.py 从同目录的 ch14.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 14

# %% [markdown]
# # 第十四章　多性状模型 —— 配套代码
#
# 核心内容：多性状 MME、**按缺失模式缓存 $\mathbf R^{-1}$**、典型变换、弯曲，
# 以及 $\mathbf G_0\propto\mathbf R_0$（$r_A=r_E$ 且遗传力相同）时"多性状无收益"的退化验证。

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions, BenchmarkTools
rng = Xoshiro(20260918)

# ── 全书通用工具（第九章）────────────────────────────────────────────
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        b = inv(delta)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

function random_pedigree(n::Int; nbase::Int=max(10,n÷50), rng=Random.default_rng())
    sire=zeros(Int,n); dam=zeros(Int,n)
    for i in nbase+1:n; sire[i]=rand(rng,1:i-1); dam[i]=rand(rng,1:i-1); end
    return sire, dam
end

# %% [markdown]
# ## 1　多性状 MME 与准确性提升（正文 §14.2）

# %%
"""
    mt_mme(Y, Ainv, G0, R0)

多性状 MME（仅截距 + 动物效应，等模型、无缺失）。按**性状**堆叠，
故随机效应块为 Z'R^-1 Z + G0^-1 kron A^-1（式 14.4、14.5）。
"""
function mt_mme(Y::Matrix{Float64}, Ainv, G0::Matrix{Float64}, R0::Matrix{Float64})
    n, t = size(Y)
    Ri = inv(R0); Gi = inv(G0)
    XtRX = Ri .* n
    XtRZ = zeros(t, n*t)
    ZtRZ = zeros(n*t, n*t)
    for k in 1:t, l in 1:t, i in 1:n
        XtRZ[k, (l-1)*n + i] = Ri[k,l]
        ZtRZ[(k-1)*n+i, (l-1)*n+i] = Ri[k,l]
    end
    LHS = [XtRX XtRZ; XtRZ' (ZtRZ + kron(Gi, Matrix(Ainv)))]
    XtRy = zeros(t); ZtRy = zeros(n*t)
    for k in 1:t, l in 1:t
        XtRy[k] += Ri[k,l]*sum(Y[:,l])
        for i in 1:n; ZtRy[(k-1)*n+i] += Ri[k,l]*Y[i,l]; end
    end
    return LHS, vcat(XtRy, ZtRy)
end

G0 = [20.0 6.0; 6.0 8.0]
R0 = [40.0 11.0; 11.0 30.0]
t  = 2
h1 = G0[1,1]/(G0[1,1]+R0[1,1]); h2t = G0[2,2]/(G0[2,2]+R0[2,2])
rA = G0[1,2]/sqrt(G0[1,1]*G0[2,2]); rE = R0[1,2]/sqrt(R0[1,1]*R0[2,2])
@printf("h2_1=%.3f  h2_2=%.3f  r_A=%.3f  r_E=%.3f  |r_A-r_E|=%.3f\n\n", h1, h2t, rA, rE, abs(rA-rE))

nind = 400
sire, dam = random_pedigree(nind; rng=Xoshiro(31))
A = build_A(sire, dam); F = diag(A).-1; Ai = build_Ainv(sire, dam, F)
L = cholesky(Symmetric(A + 1e-10I)).L
uu = hcat([L*randn(Xoshiro(100+k), nind) for k in 1:t]...) * cholesky(G0).L'
ee = randn(Xoshiro(200), nind, t) * cholesky(R0).L'
Y  = 10.0 .+ uu .+ ee

LHSm, RHSm = mt_mme(Y, Ai, G0, R0)
u_mt = reshape((LHSm \ RHSm)[t+1:end], nind, t)

u_st = zeros(nind, t)
for kk in 1:t
    lam = R0[kk,kk]/G0[kk,kk]
    Cm = [Float64(nind) ones(nind)'; ones(nind) Matrix(1.0I,nind,nind)+lam*Matrix(Ai)]
    u_st[:,kk] = (Cm \ vcat(sum(Y[:,kk]), Y[:,kk]))[2:end]
end

println(rpad("性状", 8), rpad("单性状 cor", 16), rpad("多性状 cor", 16), "提升")
println("-"^52)
for kk in 1:t
    c1 = cor(u_st[:,kk], uu[:,kk]); c2 = cor(u_mt[:,kk], uu[:,kk])
    @printf("%-8d%-16.4f%-16.4f%+.1f%%\n", kk, c1, c2, 100*(c2-c1)/c1)
end

# %% [markdown]
# ## 2　退化验证：$\mathbf G_0\propto\mathbf R_0$ 时多性状无收益（第五章"免费测试用例"）
#
# 当 $r_A=r_E$ **且两性状遗传力相同**时 $\mathbf R_0=c\,\mathbf G_0$，多性状解与单性状解**逐位相同**（正文思考题 1）。下面前四行取两性状 $h^2=1/3$；最后一行保持 $r_A=r_E$ 但令性状 2 的遗传力降为约 0.21——此时多性状仍有（小的）收益，说明"$r_A=r_E$ 即无收益"的常见说法并不准确。

# %%
function mt_gain(rA_, rE_; r22=16.0, nind=400, seed=41)
    G = [20.0 rA_*sqrt(160); rA_*sqrt(160) 8.0]
    R = [40.0 rE_*sqrt(40*r22); rE_*sqrt(40*r22) r22]      # r22 = 16 时两性状 h² 均为 1/3
    (isposdef(G) && isposdef(R)) || return NaN
    s, d = random_pedigree(nind; rng=Xoshiro(seed))
    Av = build_A(s,d); Fv = diag(Av).-1; Aiv = build_Ainv(s,d,Fv)
    Lv = cholesky(Symmetric(Av + 1e-10I)).L
    u = hcat([Lv*randn(Xoshiro(seed+10k), nind) for k in 1:2]...)*cholesky(G).L'
    e = randn(Xoshiro(seed+99), nind, 2)*cholesky(R).L'
    Yv = 10.0 .+ u .+ e
    Lh, Rh = mt_mme(Yv, Aiv, G, R)
    um = reshape((Lh\Rh)[3:end], nind, 2)
    us = zeros(nind,2)
    for kk in 1:2
        lam = R[kk,kk]/G[kk,kk]
        Cm = [Float64(nind) ones(nind)'; ones(nind) Matrix(1.0I,nind,nind)+lam*Matrix(Aiv)]
        us[:,kk] = (Cm \ vcat(sum(Yv[:,kk]), Yv[:,kk]))[2:end]
    end
    return cor(um[:,2], u[:,2]) - cor(us[:,2], u[:,2])
end

println(rpad("r_A", 8), rpad("r_E", 8), rpad("h²₂", 8), rpad("|r_A - r_E|", 14), "性状2 准确性提升")
println("-"^58)
gains = Float64[]
for (ra, re, r22) in ((0.6,0.6,16.0), (0.6,0.3,16.0), (0.6,0.0,16.0), (0.6,-0.3,16.0), (0.6,0.6,30.0))
    g = mt_gain(ra, re; r22=r22)
    push!(gains, g)
    @printf("%-8.2f%-8.2f%-8.3f%-14.2f%+.6f\n", ra, re, 8/(8+r22), abs(ra-re), g)
end
degen_ok = abs(gains[1]) < 1e-8
println("\n=> G₀ ∝ R₀（第 1 行）时提升为 0（数值误差内）", degen_ok ? " ✔" : " ✘",
        "；|r_A - r_E| 越大收益越大；")
println("   第 5 行 r_A = r_E 但遗传力不同，仍有小的收益。")

# %% [markdown]
# ## 3　缺失数据：按缺失模式构造 $\mathbf R^{-1}$（正文 §14.3.2）
#
# **最常见的实现错误：先求逆再取子矩阵。**

# %%
"""
    build_Rinv_cache(R0, patterns)

按缺失模式缓存 R0 子矩阵的逆。**必须先取子矩阵再求逆。**
"""
function build_Rinv_cache(R0::Matrix, patterns::Vector{Vector{Int}})
    cache = Dict{Vector{Int}, Matrix{Float64}}()
    for S in patterns
        cache[S] = inv(R0[S, S])
    end
    return cache
end

R03 = [40.0 11.0 5.0; 11.0 30.0 8.0; 5.0 8.0 25.0]
S = [1, 3]
correct = inv(R03[S,S])
wrong   = inv(R03)[S,S]
println("R0 ="); display(R03)
println("\n观测性状集合 S = ", S)
println("\n【正确】inv(R0[S,S]) ="); display(round.(correct, digits=6))
println("\n【错误】inv(R0)[S,S] ="); display(round.(wrong, digits=6))
@printf("\n两者相对差 = %.4f  —— 完全不同！\n", norm(correct-wrong)/norm(correct))

pats = [[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]]
cache = build_Rinv_cache(R03, pats)
nrec = 1_000_000
@printf("\n3 性状共 %d 种非空缺失模式。\n", length(pats))
@printf("n = %d 条记录：逐记录求逆 %d 次  vs  缓存 %d 次  （减少 %.0f 倍）\n",
        nrec, nrec, length(pats), nrec/length(pats))
for Sp in pats
    @printf("  模式 %-12s -> %dx%d 矩阵, det = %.4f\n",
            string(Sp), length(Sp), length(Sp), det(cache[Sp]))
end

# %% [markdown]
# ## 4　典型变换（正文 §14.2.4）

# %%
"""
    canonical_transform(G0, R0) -> (Q, Lambda)

求 Q 使 Q'R0Q = I 且 Q'G0Q = Lambda（对角）。等价于广义特征值问题 G0 v = lambda R0 v。
"""
function canonical_transform(G0::Matrix, R0::Matrix)
    Lr = cholesky(Symmetric(R0)).L
    Mm = Lr \ (G0 / Lr')
    ev = eigen(Symmetric(Mm))
    Q  = Lr' \ ev.vectors
    return Q, Diagonal(ev.values)
end

Q, Lam = canonical_transform(G0, R0)
@printf("norm(Q'R0Q - I)      = %.3e   %s\n", norm(Q'*R0*Q - I), norm(Q'*R0*Q - I) < 1e-10 ? "OK" : "FAIL")
@printf("norm(Q'G0Q - Lambda) = %.3e   %s\n", norm(Q'*G0*Q - Lam), norm(Q'*G0*Q - Lam) < 1e-10 ? "OK" : "FAIL")
println("\n典型性状的「遗传力」lambda/(lambda+1) = ", round.(diag(Lam)./(diag(Lam).+1), digits=4))
println("Q ="); display(round.(Q, digits=5))
@printf("\n=> 等模型下运算量从 O(t^3 n^3) 降到 O(t n^3)，即 %d 倍加速（t=%d）\n", t^2, t)

# %% [markdown]
# ## 5　正定性与弯曲（正文 §14.4）

# %%
"""弯曲（Hayes & Hill 1981，式 14.12）：把特征值向均值收缩。"""
function bend(G::Matrix, gam::Float64)
    ev = eigen(Symmetric(G))
    lbar = mean(ev.values)
    lnew = (1-gam) .* ev.values .+ gam*lbar
    return ev.vectors * Diagonal(lnew) * ev.vectors'
end

"""求使矩阵正定的最小 gamma。"""
function min_gamma(G::Matrix; tol=1e-8)
    lo, hi = 0.0, 1.0
    for _ in 1:80
        mid = (lo+hi)/2
        isposdef(Symmetric(bend(G, mid))) ? (hi = mid) : (lo = mid)
    end
    return hi + tol
end

Gdiag = Diagonal([25.3, 8.1, 0.4, -1.2])
U = Matrix(qr(randn(Xoshiro(5), 4, 4)).Q)
Gbad = U*Gdiag*U'; Gbad = (Gbad + Gbad')/2
@printf("原特征值 = %s   正定？%s\n", string(round.(sort(eigvals(Symmetric(Gbad))), digits=4)),
        isposdef(Symmetric(Gbad)))
gam = min_gamma(Gbad)
Gb  = bend(Gbad, gam)
@printf("最小 gamma = %.6f\n", gam)
@printf("弯曲后特征值 = %s   正定？%s\n",
        string(round.(sort(eigvals(Symmetric(Gb))), digits=4)), isposdef(Symmetric(Gb)))
@printf("弯曲改变了矩阵 %.2f%%（Frobenius 相对差）\n", 100*norm(Gb-Gbad)/norm(Gbad))

# %% [markdown]
# ## 本章代码小结
#
# 1. **多性状的收益取决于 $|r_A-r_E|$ 与遗传力差异**；$\mathbf G_0\propto\mathbf R_0$ 时收益精确为 0，这是免费的测试用例；仅 $r_A=r_E$ 而遗传力不同时仍有收益。
# 2. **缺失数据必须用 $(\mathbf R_0[S,S])^{-1}$ 而非 $(\mathbf R_0^{-1})[S,S]$** —— 二者差异巨大。
# 3. **按缺失模式缓存**把 $n$ 次矩阵求逆降为 $\le 2^t-1$ 次。
# 4. **典型变换**同时对角化 $\mathbf G_0$ 与 $\mathbf R_0$，运算量降 $t^2$ 倍（要求等模型）。
# 5. **弯曲**使非正定的 $\hat{\mathbf G}_0$ 恢复正定，且改变量可量化。
