# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 14 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c14h.py    依赖：numpy, scipy
"""Reduced-rank / factor-analytic G0: parameter counts and eigenvalue spectra, t=10."""
import numpy as np
from scipy.linalg import eigh
np.set_printoptions(precision=4, suppress=True, linewidth=180)
t=10
print("unstructured G0: t(t+1)/2 =", t*(t+1)//2, "parameters")
print("\nr | rank-r  (tr - r(r-1)/2) | FA_r with diag Psi (+t) | saving vs 55")
for r in range(1,t+1):
    rr=t*r-r*(r-1)//2; fa=rr+t
    print("%2d | %20d | %22d | %.1f%% / %.1f%%" % (r, rr, fa, 100*(1-rr/55), 100*(1-fa/55)))

# a realistic 10-trait G0: AR(1) genetic correlation
rho=0.85
sA=np.array([5.0,4.8,4.6,4.4,4.2,4.0,3.8,3.6,3.4,3.2])
C=np.array([[rho**abs(i-j) for j in range(t)] for i in range(t)])
G0=np.outer(sA,sA)*C
w,V=eigh(G0); o=np.argsort(w)[::-1]; w=w[o]; V=V[:,o]
cum=np.cumsum(w)/w.sum()
print("\nAR(1) rho=0.85, sigma_A from 5.0 down to 3.2")
print("eigenvalues:", w)
print("cumulative proportion:", cum)
for p in [0.90,0.95,0.99]:
    r=int(np.searchsorted(cum,p)+1)
    print("  >=%.0f%% variance needs r = %d  (params %d, vs 55)"%(100*p,r,t*r-r*(r-1)//2))
print("\nLambda (t x 3) = U_3 * sqrt(Lambda_3):")
L3=V[:,:3]*np.sqrt(w[:3])
print(L3)
G3=L3@L3.T
print("max |G0 - Lambda Lambda'| = %.4f ; relative Frobenius = %.4f"
      % (np.max(np.abs(G0-G3)), np.linalg.norm(G0-G3)/np.linalg.norm(G0)))
Psi=np.diag(np.diag(G0-G3))
print("Psi diagonal:", np.diag(Psi))
G3p=G3+Psi
print("FA(3): max |G0 - (LL'+Psi)| = %.4f ; rel Frob = %.4f"
      % (np.max(np.abs(G0-G3p)), np.linalg.norm(G0-G3p)/np.linalg.norm(G0)))
print("eig(LL'+Psi) min = %.6f (PD? %s)" % (np.linalg.eigvalsh(G3p).min(), np.linalg.eigvalsh(G3p).min()>0))

# exact reduced rank case: covariance function of order 3 over 10 ages
print("\n--- exact rank-3 case (random regression, order 3 Legendre over 10 ages) ---")
ages=np.linspace(-1,1,10)
Phi=np.column_stack([np.ones(10)*np.sqrt(0.5),
                     ages*np.sqrt(1.5),
                     (1.5*ages**2-0.5)*np.sqrt(2.5)])
K=np.array([[12.,2.,-1.],[2.,3.,0.5],[-1.,0.5,1.5]])
Gk=Phi@K@Phi.T
wk=np.sort(np.linalg.eigvalsh(Gk))[::-1]
print("eigenvalues:", wk)
print("rank =", np.linalg.matrix_rank(Gk, tol=1e-8), "; params in K =", 6, "vs unstructured 55")
print("cumulative:", np.cumsum(wk)/wk.sum())

# counting: when does unstructured become infeasible
print("\nparameter counts, both G0 and R0 unstructured vs FA:")
print(" t | 2*t(t+1)/2 | FA(2)+FA(2) | FA(3)+unstr R0")
for tt in [3,5,10,15,20,30]:
    un=tt*(tt+1)
    fa2=2*(tt*2-1+tt)
    mix=(tt*3-3+tt)+tt*(tt+1)//2
    print("%2d | %10d | %11d | %13d"%(tt,un,fa2,mix))

print("\n=== spectra for several genetic correlation structures, t=10 ===")
def spec(Cmat, sA):
    G=np.outer(sA,sA)*Cmat
    w=np.sort(np.linalg.eigvalsh(G))[::-1]
    return w, np.cumsum(w)/w.sum()
sA=np.array([5.0,4.8,4.6,4.4,4.2,4.0,3.8,3.6,3.4,3.2])
cases={}
for rho in [0.70,0.85,0.95]:
    cases[f"AR(1) rho={rho}"]=np.array([[rho**abs(i-j) for j in range(t)] for i in range(t)])
for r in [0.5,0.8,0.9]:
    cases[f"等相关 r={r}"]=np.full((t,t),r)+np.eye(t)*(1-r)
print("结构                | r for 80% | 90% | 95% | 99% | params@95%")
for nm,Cm in cases.items():
    w,cum=spec(Cm,sA)
    rs=[int(np.searchsorted(cum,p)+1) for p in (0.80,0.90,0.95,0.99)]
    print("%-19s | %9d | %3d | %3d | %3d | %d"%(nm,rs[0],rs[1],rs[2],rs[3],t*rs[2]-rs[2]*(rs[2]-1)//2))
for nm in ["AR(1) rho=0.95","等相关 r=0.9"]:
    w,cum=spec(cases[nm],sA)
    print("\n%s eigenvalues:"%nm, np.array2string(w,precision=3))
    print("   cumulative:", np.array2string(cum,precision=4))
print("\nFA_r with diagonal Psi is cheaper than unstructured iff tr-r(r-1)/2+t < t(t+1)/2 :")
for tt in [5,10,20]:
    rmax=max(r for r in range(1,tt+1) if tt*r-r*(r-1)//2+tt < tt*(tt+1)//2)
    print("  t=%2d : r <= %d"%(tt,rmax))
