# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 14 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c14e.py    依赖：numpy, scipy
"""Bending a non-PD G0 (3x3), and its effect on EBV / reliability."""
import numpy as np
from scipy.linalg import eigh
np.set_printoptions(precision=6, suppress=True, linewidth=170)

sA = np.array([5.,4.,3.])          # genetic sd, sigma_A^2 = 25,16,9
Rg = np.array([[1.,0.90,0.80],[0.90,1.,0.30],[0.80,0.30,1.]])
G0 = np.outer(sA,sA)*Rg
print("estimated genetic correlation matrix:\n", Rg)
print("G0hat =\n", G0)
w,V = eigh(G0); idx=np.argsort(w)[::-1]; w=w[idx]; V=V[:,idx]
print("eigenvalues of G0hat:", w)
print("det =", np.linalg.det(G0), " trace =", np.trace(G0))
wc,_ = eigh(Rg); print("eigenvalues of correlation matrix:", np.sort(wc)[::-1])
print("is PD?", np.all(w>0))
print("implied r23 range given r12=0.90, r13=0.80:")
lo=0.90*0.80-np.sqrt((1-0.81)*(1-0.64)); hi=0.90*0.80+np.sqrt((1-0.81)*(1-0.64))
print("   [%.4f, %.4f]  -> 0.30 is OUTSIDE" % (lo,hi))

lbar = w.mean()
print("\nmean eigenvalue lbar = %.6f" % lbar)

# --- method 1: eigenvalue truncation ---
eps = 1e-6*lbar
w1 = np.maximum(w, eps)
G1 = V@np.diag(w1)@V.T
print("\n[1] truncation eps = %.4e" % eps)
print("eigenvalues:", w1)
print("G1 =\n", G1)
print("trace before %.6f after %.6f (diff %.6f)" % (np.trace(G0), np.trace(G1), np.trace(G1)-np.trace(G0)))
d1=np.sqrt(np.diag(G1)); print("implied h-scale sd:", d1)
print("implied rA:\n", G1/np.outer(d1,d1))
print("cond = %.4e" % (w1.max()/w1.min()))

# --- method 2: shrink to diagonal  G_rho = (1-rho)G0 + rho*lbar*I ---
def minrho():
    lmin=w.min()
    # eigenvalues become (1-rho)*w_i + rho*lbar  -> positive for all i
    # smallest: (1-rho)*lmin + rho*lbar > 0  -> rho > -lmin/(lbar-lmin)
    return -lmin/(lbar-lmin)
r0=minrho()
print("\n[2] shrink to diagonal: minimal rho = %.6f" % r0)
for rho in [r0, 0.05, 0.10, 0.20]:
    wr=(1-rho)*w+rho*lbar
    Gr=(1-rho)*G0+rho*lbar*np.eye(3)
    d=np.sqrt(np.diag(Gr))
    print(" rho=%.4f  eig=%s  min=%.6f  trace=%.4f  rA12=%.4f rA13=%.4f rA23=%.4f  h-sd=%s"
          % (rho, np.array2string(wr,precision=4), wr.min(), np.trace(Gr),
             Gr[0,1]/(d[0]*d[1]), Gr[0,2]/(d[0]*d[2]), Gr[1,2]/(d[1]*d[2]),
             np.array2string(d,precision=3)))
rho_use=0.10
G2=(1-rho_use)*G0+rho_use*lbar*np.eye(3)
print("\nG2 (rho=0.10) =\n", G2)
d2=np.sqrt(np.diag(G2)); print("implied rA:\n", G2/np.outer(d2,d2))

# --- method 3: Hayes-Hill classic bending toward the mean eigenvalue, same family ---
print("\n[3] Hayes-Hill (14.12) is exactly method 2 written on eigenvalues:")
wb=(1-rho_use)*w+rho_use*lbar
print("  (1-g)Lambda+g*lbar*I =", wb, " -> reconstruct equals G2? max diff = %.3e"
      % np.max(np.abs(V@np.diag(wb)@V.T-G2)))

# ---------- effect on EBV ----------
ped = {1:(0,0),2:(0,0),3:(0,0),4:(0,0),5:(1,3),6:(1,4),7:(2,3),8:(2,4),
       9:(5,8),10:(6,7),11:(5,7),12:(6,8)}
n=len(ped); t=3
def Ainv(ped):
    n=len(ped); Ai=np.zeros((n,n)); F=np.zeros(n+1); A=np.zeros((n,n))
    for i in range(1,n+1):
        s,d=ped[i]
        for j in range(1,i+1):
            if i==j: A[i-1,i-1]=1+(A[s-1,d-1] if s and d else 0.0)
            else:
                a=0.0
                if s: a+=0.5*A[j-1,s-1]
                if d: a+=0.5*A[j-1,d-1]
                A[i-1,j-1]=A[j-1,i-1]=a
    for i in range(1,n+1): F[i]=A[i-1,i-1]-1
    for i in range(1,n+1):
        s,d=ped[i]
        if s and d: dv=0.5-0.25*(F[s]+F[d])
        elif s or d: dv=0.75-0.25*(F[s] if s else F[d])
        else: dv=1.0
        a=1.0/dv
        ix=[i-1]+([s-1] if s else [])+([d-1] if d else [])
        cf=[1.0]+([-0.5] if s else [])+([-0.5] if d else [])
        for pp,ip in zip(cf,ix):
            for qq,iq in zip(cf,ix): Ai[ip,iq]+=pp*qq*a
    return Ai
Ai=Ainv(ped)
herd=np.array([1 if i%2==1 else 2 for i in range(1,n+1)])
X=np.zeros((n,2))
for i in range(n): X[i,herd[i]-1]=1.0
Z=np.eye(n)
Y=np.array([[102.,48.,31.],[ 96.,55.,27.],[110.,61.,35.],[ 91.,44.,25.],
            [105.,57.,33.],[ 99.,50.,29.],[113.,63.,36.],[ 94.,46.,26.],
            [108.,59.,34.],[101.,52.,30.],[ 97.,45.,28.],[106.,58.,32.]])
R0 = np.array([[75.,12.,5.],[12.,64.,18.],[5.,18.,36.]])
def solveMT(G0,R0,Y):
    R0i=np.linalg.inv(R0); G0i=np.linalg.inv(G0)
    p=2*t; N=p+t*n; C=np.zeros((N,N)); rhs=np.zeros(N)
    XtX=X.T@X; XtZ=X.T@Z; ZtZ=Z.T@Z
    for k in range(t):
        for l in range(t):
            C[k*2:(k+1)*2,l*2:(l+1)*2]+=R0i[k,l]*XtX
            C[k*2:(k+1)*2,p+l*n:p+(l+1)*n]+=R0i[k,l]*XtZ
            C[p+k*n:p+(k+1)*n,l*2:(l+1)*2]+=R0i[k,l]*XtZ.T
            C[p+k*n:p+(k+1)*n,p+l*n:p+(l+1)*n]+=R0i[k,l]*ZtZ+G0i[k,l]*Ai
            rhs[k*2:(k+1)*2]+=R0i[k,l]*(X.T@Y[:,l])
            rhs[p+k*n:p+(k+1)*n]+=R0i[k,l]*(Z.T@Y[:,l])
    s=np.linalg.solve(C,rhs)
    Cinv=np.linalg.inv(C)
    pev=np.array([np.diag(Cinv)[p+k*n:p+(k+1)*n] for k in range(t)])
    return s[p:].reshape(t,n), pev, C

print("\n" + "="*60)
print("effect on EBV / PEV")
u0,pev0,C0m = solveMT(G0,R0,Y)
ev=np.linalg.eigvalsh(C0m)
print("[hat G0, non-PD] eig(C) min = %.6f  -> C indefinite? %s" % (ev.min(), ev.min()<0))
print("  PEV trait1 min = %.4f  (sigma_A1^2=%.1f)" % (pev0[0].min(), G0[0,0]))
rel0=1-pev0/np.array([[G0[0,0]],[G0[1,1]],[G0[2,2]]])
print("  reliability trait1: min %.4f max %.4f" % (rel0[0].min(), rel0[0].max()))
print("  reliability trait2: min %.4f max %.4f" % (rel0[1].min(), rel0[1].max()))
print("  reliability trait3: min %.4f max %.4f" % (rel0[2].min(), rel0[2].max()))
print("  any reliability outside [0,1]? ", np.any(rel0<0) or np.any(rel0>1))
print("  #(PEV<0) =", int(np.sum(pev0<0)))

for nm,GG in [("truncation", G1), ("shrink rho=0.10", G2)]:
    u,pev,Cm = solveMT(GG,R0,Y)
    ev=np.linalg.eigvalsh(Cm)
    rel=1-pev/np.array([[GG[0,0]],[GG[1,1]],[GG[2,2]]])
    print("\n[%s] eig(C) min = %.6f" % (nm, ev.min()))
    print("  reliability range t1 [%.4f,%.4f] t2 [%.4f,%.4f] t3 [%.4f,%.4f]" %
          (rel[0].min(),rel[0].max(),rel[1].min(),rel[1].max(),rel[2].min(),rel[2].max()))
    for k in range(t):
        print("  trait%d: max|u-u_hatG0|=%.4f  sd(u)=%.4f  corr with hatG0 EBV=%.4f"
              % (k+1, np.max(np.abs(u[k]-u0[k])), np.std(u[k]), np.corrcoef(u[k],u0[k])[0,1]))
u1,_,_ = solveMT(G1,R0,Y); u2,_,_ = solveMT(G2,R0,Y)
print("\ntruncation vs shrink: per-trait max abs diff, corr")
for k in range(t):
    print("  trait%d: %.4f   corr=%.6f  rank corr=%.4f" %
          (k+1, np.max(np.abs(u1[k]-u2[k])), np.corrcoef(u1[k],u2[k])[0,1],
           np.corrcoef(np.argsort(np.argsort(u1[k])),np.argsort(np.argsort(u2[k])))[0,1]))
