# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 14 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c14j.py    依赖：numpy, scipy
"""Check the numbers embedded in the new exercises."""
import numpy as np
np.set_printoptions(precision=6, suppress=True, linewidth=160)
def acc(rg,re,h1s,h2s,src):
    sA1,sA2=np.sqrt(h1s),np.sqrt(h2s); sE1,sE2=np.sqrt(1-h1s),np.sqrt(1-h2s)
    sA12=rg*sA1*sA2; sE12=re*sE1*sE2; sP12=sA12+sE12
    P=np.array([[1.,sP12],[sP12,1.]]); g=np.array([sA12,h2s]); i=[k-1 for k in src]
    b=np.linalg.solve(P[np.ix_(i,i)],g[i]); return np.sqrt(b@P[np.ix_(i,i)]@b/h2s)
print("Ex9: h1=0.40 h2=0.05, re=-0.20")
for rg in [0.,0.3,0.6,0.9]:
    print("  rg=%.1f  ST=%.4f  MT=%.4f  gain=%+.2f%%  miss-only-T1=%.4f"%
          (rg,acc(rg,-0.2,0.4,0.05,[2]),acc(rg,-0.2,0.4,0.05,[1,2]),
           100*(acc(rg,-0.2,0.4,0.05,[1,2])/acc(rg,-0.2,0.4,0.05,[2])-1),acc(rg,-0.2,0.4,0.05,[1])))
print("  same with re=0:")
for rg in [0.,0.3,0.6,0.9]:
    print("  rg=%.1f  MT=%.4f gain=%+.2f%%"%(rg,acc(rg,0.,0.4,0.05,[1,2]),
        100*(acc(rg,0.,0.4,0.05,[1,2])/acc(rg,0.,0.4,0.05,[2])-1)))

print("\nEx10: R0 3x3 patterns {2,3} and {3}")
R0=np.array([[100.,30.,15.],[30.,64.,24.],[15.,24.,36.]]); R0i=np.linalg.inv(R0)
for S in [(1,2),(2,)]:
    sub=R0[np.ix_(S,S)]; inv=np.linalg.inv(sub); wrong=R0i[np.ix_(S,S)]
    print(" S=",[s+1 for s in S]); print("  correct*1000=\n",inv*1000); print("  wrong*1000=\n",wrong*1000)
    for j,s in enumerate(S):
        print("   trait %d: marginal var %.4f vs implied 1/wrong_jj %.4f -> understated %.2f%%"%
              (s+1,R0[s,s],1/wrong[j,j],100*(1-(1/wrong[j,j])/R0[s,s])))

print("\nEx11: G0 = c*R0 with c=0.3")
G0=0.3*R0
from scipy.linalg import cholesky,eigh
L=cholesky(R0,lower=True); Li=np.linalg.inv(L); M=Li@G0@Li.T
lam,U=eigh(M); print("  lambda =",np.sort(lam)[::-1]," canonical h2 =",np.sort(lam)[::-1]/(1+np.sort(lam)[::-1]))
print("  0.3/1.3 =",0.3/1.3)

print("\nEx12: eigenvalues (25.3, 8.1, 0.4, -1.2)")
w=np.array([25.3,8.1,0.4,-1.2]); lb=w.mean()
print("  lbar=%.4f  rho_min=%.6f"%(lb,-w.min()/(lb-w.min())))
for rho in [-w.min()/(lb-w.min()),0.15]:
    print("  rho=%.6f -> eig %s  (min %.6f)"%(rho,np.array2string((1-rho)*w+rho*lb,precision=4),((1-rho)*w+rho*lb).min()))

print("\nEx13: t=10, rA=0.6 all, equal sigma_A=4")
t=10; r=0.6; sA=np.full(t,4.0)
C=np.full((t,t),r)+np.eye(t)*(1-r); G=np.outer(sA,sA)*C
Lam=np.sqrt(r)*sA.reshape(-1,1); Psi=np.diag((1-r)*sA**2)
print("  Lambda_i = %.4f ; psi_i = %.4f ; max err %.2e"%(Lam[0,0],Psi[0,0],np.max(np.abs(G-(Lam@Lam.T+Psi)))))
w2,V=np.linalg.eigh(G); o=np.argsort(w2)[::-1]; w2=w2[o]; V=V[:,o]
print("  eigenvalues:",w2)
G1=np.outer(V[:,0],V[:,0])*w2[0]
print("  pure rank-1 rel Frobenius = %.4f ; cumulative prop of 1st = %.4f"%(np.linalg.norm(G-G1)/np.linalg.norm(G), w2[0]/w2.sum()))
print("  params: FA1+Psi=%d, pure rank1=%d, unstructured=%d"%(2*t,t,t*(t+1)//2))

print("\nEx14: n=2e6, p=5e4, nnz(Ainv)=7n, t=4, one record/animal")
n=2_000_000; p=50_000; nzA=7*n
for t in [1,4]:
    print("  t=%d: equations %,d"%(t,t*(n+p)) if False else
          "  t=%d: equations %d ; nnz %d ; %.2f GB"%(t,t*(n+p),t*t*(nzA+n+p),t*t*(nzA+n+p)*12/1e9))
rr=2
print("  reduced rank r=2: random-effect equations %d (vs %d); nnz(G^-1 part) %d (vs %d)"
      %(rr*n, 4*n, rr*nzA, 16*nzA))
print("  total nnz approx %d ; %.2f GB"%(rr*rr*(n)+rr*nzA+4*4*p, (rr*rr*n+rr*nzA+16*p)*12/1e9))
