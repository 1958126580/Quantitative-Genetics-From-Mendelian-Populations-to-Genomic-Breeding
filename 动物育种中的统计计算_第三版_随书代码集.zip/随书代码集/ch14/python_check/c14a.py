# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 14 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c14a.py    依赖：numpy
"""14.1.1 information borrowing: selection-index accuracies, trait 2 target."""
import numpy as np
np.set_printoptions(precision=6, suppress=True)

h1s, h2s = 0.25, 0.10            # heritabilities
sP1 = sP2 = 1.0                  # phenotypic sd = 1 for both traits
sA1, sA2 = np.sqrt(h1s), np.sqrt(h2s)
sE1, sE2 = np.sqrt(1-h1s), np.sqrt(1-h2s)

def acc(rg, re, sources):
    """sources: list of trait indices (1-based) observed on the individual.
       target: additive BV of trait 2. Returns accuracy."""
    sA12 = rg*sA1*sA2
    sE12 = re*sE1*sE2
    sP12 = sA12 + sE12
    P = np.array([[1.0, sP12],[sP12, 1.0]])
    g = np.array([sA12, h2s])           # cov(P_k, A_2)
    idx = [k-1 for k in sources]
    Ps = P[np.ix_(idx, idx)]; gs = g[idx]
    b = np.linalg.solve(Ps, gs)
    var_i = b @ Ps @ b                  # = b'g
    return np.sqrt(var_i / h2s)

print("=== r_e = 0 ===")
print("rg    ST(own T2)   MT(own T1+T2)   gain%   MT(only T1, T2 missing)")
rows=[]
for rg in [0.0,0.3,0.6,0.9]:
    st  = acc(rg, 0.0, [2])
    mt  = acc(rg, 0.0, [1,2])
    miss= acc(rg, 0.0, [1])
    rows.append((rg,st,mt,100*(mt/st-1),miss))
    print(f"{rg:.1f}  {st:.4f}      {mt:.4f}        {100*(mt/st-1):6.2f}   {miss:.4f}")

print()
print("=== r_e = 0.30 (contrast, |rA-rE|) ===")
for rg in [0.0,0.3,0.6,0.9]:
    st  = acc(rg, 0.30, [2]); mt = acc(rg, 0.30, [1,2]); miss = acc(rg, 0.30, [1])
    print(f"{rg:.1f}  {st:.4f}      {mt:.4f}        {100*(mt/st-1):6.2f}   {miss:.4f}")

print()
print("=== check: rg = re, equal h2 -> no gain ===")
h1s2=h2s2=0.25
def acc2(rg,re,h1s,h2s,sources):
    sA1=np.sqrt(h1s); sA2=np.sqrt(h2s); sE1=np.sqrt(1-h1s); sE2=np.sqrt(1-h2s)
    sA12=rg*sA1*sA2; sE12=re*sE1*sE2; sP12=sA12+sE12
    P=np.array([[1.0,sP12],[sP12,1.0]]); g=np.array([sA12,h2s])
    idx=[k-1 for k in sources]
    b=np.linalg.solve(P[np.ix_(idx,idx)],g[idx])
    return np.sqrt(b@P[np.ix_(idx,idx)]@b/h2s)
for rg in [0.3,0.6,0.9]:
    print(f"  h1=h2=0.25, rA=rE={rg}: ST={acc2(rg,rg,0.25,0.25,[2]):.6f}  MT={acc2(rg,rg,0.25,0.25,[1,2]):.6f}")
print("  h1=0.40,h2=0.10, rA=rE=0.5: ST=%.6f MT=%.6f" % (acc2(0.5,0.5,0.40,0.10,[2]), acc2(0.5,0.5,0.40,0.10,[1,2])))
print("  h1=0.40,h2=0.10, rA=0.6 rE=0.1: ST=%.6f MT=%.6f" % (acc2(0.6,0.1,0.40,0.10,[2]), acc2(0.6,0.1,0.40,0.10,[1,2])))

print()
print("=== index weights b for re=0 ===")
for rg in [0.0,0.3,0.6,0.9]:
    sA12=rg*sA1*sA2; sP12=sA12
    P=np.array([[1.0,sP12],[sP12,1.0]]); g=np.array([sA12,h2s])
    b=np.linalg.solve(P,g)
    print(f"  rg={rg:.1f}  b1={b[0]:.4f}  b2={b[1]:.4f}")
