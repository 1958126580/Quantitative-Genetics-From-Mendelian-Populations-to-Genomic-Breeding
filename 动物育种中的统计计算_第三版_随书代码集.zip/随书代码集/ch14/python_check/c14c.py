# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 14 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c14c.py    依赖：numpy
"""Kronecker block structure, nnz growth, R0 sub-block inverses under missing patterns."""
import numpy as np, itertools, math
np.set_printoptions(precision=6, suppress=True, linewidth=160)

# ---------- t=3 R0 and missing patterns ----------
R0 = np.array([[100.,30.,15.],[30.,64.,24.],[15.,24.,36.]])
sd = np.sqrt(np.diag(R0))
print("R0 =\n", R0)
print("residual sd:", sd)
print("residual corr: r12=%.4f r13=%.4f r23=%.4f" %
      (R0[0,1]/(sd[0]*sd[1]), R0[0,2]/(sd[0]*sd[2]), R0[1,2]/(sd[1]*sd[2])))
R0inv = np.linalg.inv(R0)
print("\nR0^{-1} =\n", R0inv)
print("R0^{-1} * 1000 =\n", R0inv*1000)

pats = [(0,1,2),(0,1),(0,)]
names = {(0,1,2):"{1,2,3} 全测", (0,1):"{1,2} 缺性状3", (0,):"{1} 只测性状1"}
for S in pats:
    sub = R0[np.ix_(S,S)]
    inv = np.linalg.inv(sub)
    wrong = R0inv[np.ix_(S,S)]
    print("\n--- pattern", names[S], "---")
    print("R0[S,S] =\n", sub)
    print("(R0[S,S])^{-1} *1000 =\n", inv*1000)
    print("(R0^{-1})[S,S] *1000 =\n", wrong*1000)
    if len(S)>0:
        print("max rel diff = %.4f" % np.max(np.abs(inv-wrong)/np.abs(inv)))
        print("ratio elementwise (correct/wrong):\n", inv/wrong)

# effective residual variance for pattern {1}
print("\nvar(e1 | e2,e3) = %.6f ; var(e1)=%.1f ; 1/R0inv[0,0] = %.6f" %
      (1/R0inv[0,0], R0[0,0], 1/R0inv[0,0]))
print("so using (R0^{-1})[1,1] pretends e2,e3 are KNOWN -> residual var %.4f instead of %.1f"
      % (1/R0inv[0,0], R0[0,0]))

# ---------- number of patterns and cache size ----------
print("\n" + "="*60)
print("t  | 2^t-1 patterns | cached doubles sum_k C(t,k)k^2 | bytes")
for t in [1,2,3,5,10,15]:
    tot = sum(math.comb(t,k)*k*k for k in range(1,t+1))
    assert tot == t*(t+1)*2**(t-2) if t>=2 else True
    print(f"{t:2d} | {2**t-1:14d} | {tot:28d} | {tot*8:10d}")

# ---------- nnz growth with t ----------
ped = {1:(0,0),2:(0,0),3:(0,0),4:(0,0),5:(1,3),6:(1,4),7:(2,3),8:(2,4),
       9:(5,8),10:(6,7),11:(5,7),12:(6,8)}
def nnz_Ainv(ped):
    n=len(ped); import collections
    S=set()
    for i in range(1,n+1):
        s,d=ped[i]
        idx=[i]+([s] if s else [])+([d] if d else [])
        for a in idx:
            for b in idx: S.add((a,b))
    return len(S)
print("\nsmall pedigree n=12: nnz(Ainv) =", nnz_Ainv(ped), " = %.2f n" % (nnz_Ainv(ped)/12))

rng=np.random.default_rng(20250923)
def sim_ped(n0, n):
    ped={}
    for i in range(1,n0+1): ped[i]=(0,0)
    for i in range(n0+1,n+1):
        s=int(rng.integers(1,i)); d=int(rng.integers(1,i))
        while d==s: d=int(rng.integers(1,i))
        ped[i]=(s,d)
    return ped
for n in [10000, 100000]:
    p=sim_ped(int(0.05*n), n); k=nnz_Ainv(p)
    print(f"simulated pedigree n={n}: nnz(Ainv)={k}  = {k/n:.3f} n")

print("\nMME size, n=1e6 animals + p=1e4 fixed levels, nnz(Ainv)=7n, nnz(Z'R^-1 Z)=n")
n=1_000_000; p=10_000; nzA=7*n
print("t | equations | blocks | nnz(coef, sym) | memory GB (val+idx, 12 B/elem)")
for t in [1,2,3,5,10]:
    eq=t*(n+p)
    blocks=nzA+n+2*p   # crude: Ainv blocks + data blocks
    nz=t*t*(nzA+n)+t*t*p
    print(f"{t:2d} | {eq:11,d} | {blocks:10,d} | {nz:15,d} | {nz*12/1e9:8.2f}")
