# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 14 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c14d.py    依赖：numpy, scipy
"""Canonical transformation, t=3: construction, canonical heritabilities, equivalence check."""
import numpy as np
from scipy.linalg import cholesky, eigh
np.set_printoptions(precision=6, suppress=True, linewidth=160)

G0 = np.array([[25., 9.5, 4.],[9.5,16.,6.],[4.,6.,9.]])
R0 = np.array([[75.,12.,5.],[12.,64.,18.],[5.,18.,36.]])
t=3
print("G0=\n",G0,"\nR0=\n",R0)
sg=np.sqrt(np.diag(G0)); sr=np.sqrt(np.diag(R0))
print("h^2 =", np.diag(G0)/(np.diag(G0)+np.diag(R0)))
print("rA: 12=%.4f 13=%.4f 23=%.4f"%(G0[0,1]/(sg[0]*sg[1]),G0[0,2]/(sg[0]*sg[2]),G0[1,2]/(sg[1]*sg[2])))
print("rE: 12=%.4f 13=%.4f 23=%.4f"%(R0[0,1]/(sr[0]*sr[1]),R0[0,2]/(sr[0]*sr[2]),R0[1,2]/(sr[1]*sr[2])))

L = cholesky(R0, lower=True)
print("\nL (R0=LL') =\n", L)
Li = np.linalg.inv(L)
M = Li @ G0 @ Li.T
print("M = L^{-1} G0 L^{-T} =\n", M)
lam, U = eigh(M)
order=np.argsort(lam)[::-1]; lam=lam[order]; U=U[:,order]
# sign convention: make largest-abs entry of each column positive
for k in range(t):
    if U[np.argmax(np.abs(U[:,k])),k] < 0: U[:,k]*=-1
print("eigenvalues lambda =", lam)
print("U =\n", U)
Q = Li.T @ U
print("Q = L^{-T} U =\n", Q)
print("\ncheck Q'R0Q =\n", Q.T@R0@Q)
print("check Q'G0Q =\n", Q.T@G0@Q)
print("canonical h^2 = lambda/(1+lambda) =", lam/(1+lam))
print("alpha_k = 1/lambda_k =", 1/lam)
Qinv=np.linalg.inv(Q)
print("Q^{-1} =\n", Qinv)
print("Q^{-T} =\n", Qinv.T)
print("cond(Q) = %.4f" % np.linalg.cond(Q))

# ---------- equivalence check on a real MME ----------
ped = {1:(0,0),2:(0,0),3:(0,0),4:(0,0),5:(1,3),6:(1,4),7:(2,3),8:(2,4),
       9:(5,8),10:(6,7),11:(5,7),12:(6,8)}
n=len(ped)
def Ainv(ped):
    n=len(ped); Ai=np.zeros((n,n)); F=np.zeros(n+1); A=np.zeros((n,n))
    for i in range(1,n+1):
        s,d=ped[i]
        for j in range(1,i+1):
            if i==j: A[i-1,i-1]=1+(A[s-1,d-1] if s and d else 0.0)
            else:
                a=0.0
                if s: a+=0.5*A[j-1,s-1]
                if d: a+=0.5*A[j-1,d-1]
                A[i-1,j-1]=A[j-1,i-1]=a
    for i in range(1,n+1): F[i]=A[i-1,i-1]-1
    for i in range(1,n+1):
        s,d=ped[i]
        if s and d: dv=0.5-0.25*(F[s]+F[d])
        elif s or d:
            f=F[s] if s else F[d]; dv=0.75-0.25*f
        else: dv=1.0
        a=1.0/dv
        idx=[i-1]+([s-1] if s else [])+([d-1] if d else [])
        cf=[1.0]+([-0.5] if s else [])+([-0.5] if d else [])
        for pp,ip in zip(cf,idx):
            for qq,iq in zip(cf,idx): Ai[ip,iq]+=pp*qq*a
    return Ai
Ai=Ainv(ped)
herd=np.array([1 if i%2==1 else 2 for i in range(1,n+1)])
X=np.zeros((n,2))
for i in range(n): X[i,herd[i]-1]=1.0
Z=np.eye(n)
Y=np.array([[102.,48.,31.],[ 96.,55.,27.],[110.,61.,35.],[ 91.,44.,25.],
            [105.,57.,33.],[ 99.,50.,29.],[113.,63.,36.],[ 94.,46.,26.],
            [108.,59.,34.],[101.,52.,30.],[ 97.,45.,28.],[106.,58.,32.]])
def solve_MT(G0,R0,Y):
    R0i=np.linalg.inv(R0); G0i=np.linalg.inv(G0)
    p=2*t; N=p+t*n
    C=np.zeros((N,N)); rhs=np.zeros(N)
    XtX=X.T@X; XtZ=X.T@Z; ZtZ=Z.T@Z
    for k in range(t):
        for l in range(t):
            C[k*2:(k+1)*2, l*2:(l+1)*2]+=R0i[k,l]*XtX
            C[k*2:(k+1)*2, p+l*n:p+(l+1)*n]+=R0i[k,l]*XtZ
            C[p+k*n:p+(k+1)*n, l*2:(l+1)*2]+=R0i[k,l]*XtZ.T
            C[p+k*n:p+(k+1)*n, p+l*n:p+(l+1)*n]+=R0i[k,l]*ZtZ+G0i[k,l]*Ai
        for l in range(t):
            rhs[k*2:(k+1)*2]+=R0i[k,l]*(X.T@Y[:,l])
            rhs[p+k*n:p+(k+1)*n]+=R0i[k,l]*(Z.T@Y[:,l])
    return np.linalg.solve(C,rhs), C
sol, C = solve_MT(G0,R0,Y)
u_mt = sol[6:].reshape(t,n)
b_mt = sol[:6].reshape(t,2)

# canonical route
Ys = Y @ Q             # y*_k = column k  (since y*=(Q' kron I) y  <=> Y* = Y Q)
u_can=np.zeros((t,n)); b_can=np.zeros((t,2))
for k in range(t):
    a=1.0/lam[k]
    N=2+n; Ck=np.zeros((N,N)); rk=np.zeros(N)
    Ck[:2,:2]=X.T@X; Ck[:2,2:]=X.T@Z; Ck[2:,:2]=Z.T@X; Ck[2:,2:]=Z.T@Z+Ai*a
    rk[:2]=X.T@Ys[:,k]; rk[2:]=Z.T@Ys[:,k]
    sk=np.linalg.solve(Ck,rk)
    b_can[k]=sk[:2]; u_can[k]=sk[2:]
Qit=np.linalg.inv(Q).T
u_back = Qit @ u_can      # u = (Q^{-T} kron I) u*
b_back = Qit @ b_can
print("\n=== equivalence check (complete data, equal design) ===")
print("max |u_MT - u_canonical| = %.3e" % np.max(np.abs(u_mt-u_back)))
print("max |b_MT - b_canonical| = %.3e" % np.max(np.abs(b_mt-b_back)))
print("EBV trait1 (MT):", u_mt[0])
print("EBV trait1 (can):", u_back[0])

# ---------- failure: missing data ----------
print("\n=== canonical transformation with missing data (animals 7-12 lack trait 3) ===")
obs=np.ones((n,t),dtype=bool); obs[6:,2]=False
def solve_MT_miss(G0,R0,Y,obs):
    G0i=np.linalg.inv(G0); p=2*t; N=p+t*n
    C=np.zeros((N,N)); rhs=np.zeros(N); cache={}
    for i in range(n):
        S=tuple(k for k in range(t) if obs[i,k])
        if S not in cache: cache[S]=np.linalg.inv(R0[np.ix_(S,S)])
        Ri=cache[S]
        cols=[(k*2+herd[i]-1, p+k*n+i) for k in S]; yv=[Y[i,k] for k in S]
        for a_,(bc,uc) in enumerate(cols):
            for b_,(bc2,uc2) in enumerate(cols):
                w=Ri[a_,b_]
                C[bc,bc2]+=w; C[bc,uc2]+=w; C[uc,bc2]+=w; C[uc,uc2]+=w
            rr=sum(Ri[a_,b_]*yv[b_] for b_ in range(len(cols)))
            rhs[bc]+=rr; rhs[uc]+=rr
    for k in range(t):
        for l in range(t):
            C[p+k*n:p+(k+1)*n, p+l*n:p+(l+1)*n]+=G0i[k,l]*Ai
    return np.linalg.solve(C,rhs)
solm=solve_MT_miss(G0,R0,Y,obs)
u_ref=solm[6:].reshape(t,n)
# naive canonical: transform with zeros filled in for missing
Yz=Y.copy(); Yz[6:,2]=0.0
Ysz=Yz@Q
u_c2=np.zeros((t,n))
for k in range(t):
    a=1.0/lam[k]; N=2+n; Ck=np.zeros((N,N)); rk=np.zeros(N)
    Ck[:2,:2]=X.T@X; Ck[:2,2:]=X.T@Z; Ck[2:,:2]=Z.T@X; Ck[2:,2:]=Z.T@Z+Ai*a
    rk[:2]=X.T@Ysz[:,k]; rk[2:]=Z.T@Ysz[:,k]
    u_c2[k]=np.linalg.solve(Ck,rk)[2:]
u_b2=Qit@u_c2
print("max |u_correct - u_naive_canonical| =", np.max(np.abs(u_ref-u_b2)))
for k in range(t):
    print("  trait %d: max abs diff %.4f, sd(correct)=%.4f, corr=%.4f" %
          (k+1, np.max(np.abs(u_ref[k]-u_b2[k])), np.std(u_ref[k]),
           np.corrcoef(u_ref[k],u_b2[k])[0,1]))

# fairer naive: fill missing with observed trait mean, and with herd-trait mean
for label, filler in [("trait mean", "t"), ("herd x trait mean", "h")]:
    Yf=Y.copy()
    if filler=="t":
        Yf[6:,2]=Y[:6,2].mean()
    else:
        for hh in [1,2]:
            m=[i for i in range(6) if herd[i]==hh]
            for i in range(6,n):
                if herd[i]==hh: Yf[i,2]=Y[m,2].mean()
    Ysf=Yf@Q; u_c3=np.zeros((t,n))
    for k in range(t):
        a=1.0/lam[k]; N=2+n; Ck=np.zeros((N,N)); rk=np.zeros(N)
        Ck[:2,:2]=X.T@X; Ck[:2,2:]=X.T@Z; Ck[2:,:2]=Z.T@X; Ck[2:,2:]=Z.T@Z+Ai*a
        rk[:2]=X.T@Ysf[:,k]; rk[2:]=Z.T@Ysf[:,k]
        u_c3[k]=np.linalg.solve(Ck,rk)[2:]
    u_b3=Qit@u_c3
    print(f"\nfill = {label}")
    for k in range(t):
        print("  trait %d: max abs diff %.4f, sd(correct)=%.4f, corr=%.4f" %
              (k+1, np.max(np.abs(u_ref[k]-u_b3[k])), np.std(u_ref[k]),
               np.corrcoef(u_ref[k],u_b3[k])[0,1]))
    # rank correlation of trait 3 among the 6 missing animals
    from scipy.stats import spearmanr
    print("  trait3 Spearman (all 12) = %.4f" % spearmanr(u_ref[2],u_b3[2]).statistic)
