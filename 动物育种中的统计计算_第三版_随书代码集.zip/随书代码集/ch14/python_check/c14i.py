# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 14 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c14i.py    依赖：numpy
"""FA(1)+Psi vs pure rank-1 on a compound-symmetry G0 (t=10)."""
import numpy as np
np.set_printoptions(precision=4, suppress=True, linewidth=180)
t=10; r=0.9
sA=np.array([5.0,4.8,4.6,4.4,4.2,4.0,3.8,3.6,3.4,3.2])
C=np.full((t,t),r)+np.eye(t)*(1-r)
G0=np.outer(sA,sA)*C
Lam=np.sqrt(r)*sA.reshape(-1,1)
Psi=np.diag((1-r)*sA**2)
print("Lambda' =", Lam.ravel())
print("diag(Psi) =", np.diag(Psi))
print("max |G0 - (Lam Lam' + Psi)| = %.3e" % np.max(np.abs(G0-(Lam@Lam.T+Psi))))
print("FA(1)+Psi parameters = t + t = %d ; unstructured = %d" % (2*t, t*(t+1)//2))
w=np.sort(np.linalg.eigvalsh(G0))[::-1]
print("eigenvalues of G0:", w)
print("pure rank-1 (PCA) relative Frobenius error = %.4f" %
      (np.linalg.norm(G0-np.linalg.eigh(G0)[1][:,-1:]*w[0]@np.linalg.eigh(G0)[1][:,-1:].T)/np.linalg.norm(G0)))
U=np.linalg.eigh(G0)[1][:,::-1]
G1=np.outer(U[:,0],U[:,0])*w[0]
print("pure rank-1: max abs err %.4f ; rel Frob %.4f ; params %d" %
      (np.max(np.abs(G0-G1)), np.linalg.norm(G0-G1)/np.linalg.norm(G0), t))
for rr in [2,3,5]:
    Gr=U[:,:rr]@np.diag(w[:rr])@U[:,:rr].T
    print("pure rank-%d: max abs err %.4f ; rel Frob %.4f ; params %d" %
          (rr, np.max(np.abs(G0-Gr)), np.linalg.norm(G0-Gr)/np.linalg.norm(G0), t*rr-rr*(rr-1)//2))
print("\n-> FA(1)+Psi is EXACT with 20 params; pure rank-5 PCA still has rel Frob %.4f with 40 params"
      % (np.linalg.norm(G0-U[:,:5]@np.diag(w[:5])@U[:,:5].T)/np.linalg.norm(G0)))
