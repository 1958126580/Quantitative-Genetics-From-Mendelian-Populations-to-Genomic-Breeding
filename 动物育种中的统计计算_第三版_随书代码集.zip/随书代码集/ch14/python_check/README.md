# 第 14 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch14/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `c14a.py` | 14.1.1 information borrowing: selection-index accuracies, trait 2 target. | numpy | 0.9 | `outputs/c14a.out` |
| `c14b.py` | Multi-trait MME: (a) G0 prop R0 -> no gain; (b) accuracy gain with/without missing. | numpy | 1.2 | `outputs/c14b.out` |
| `c14c.py` | Kronecker block structure, nnz growth, R0 sub-block inverses under missing patterns. | numpy | 8.8 | `outputs/c14c.out` |
| `c14d.py` | Canonical transformation, t=3: construction, canonical heritabilities, equivalence check. | numpy, scipy | 8.5 | `outputs/c14d.out` |
| `c14e.py` | Bending a non-PD G0 (3x3), and its effect on EBV / reliability. | numpy, scipy | 3.8 | `outputs/c14e.out` |
| `c14g.py` | Bending: trace behaviour, condition numbers, penalty <-> shrinkage mapping. | numpy, scipy | 3.2 | `outputs/c14g.out` |
| `c14h.py` | Reduced-rank / factor-analytic G0: parameter counts and eigenvalue spectra, t=10. | numpy, scipy | 3.1 | `outputs/c14h.out` |
| `c14i.py` | FA(1)+Psi vs pure rank-1 on a compound-symmetry G0 (t=10). | numpy | 1.2 | `outputs/c14i.out` |
| `c14j.py` | Check the numbers embedded in the new exercises. | numpy, scipy | 3.1 | `outputs/c14j.out` |
