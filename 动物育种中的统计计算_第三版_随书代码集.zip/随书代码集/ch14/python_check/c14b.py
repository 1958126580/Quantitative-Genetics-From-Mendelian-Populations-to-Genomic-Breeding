# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 14 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c14b.py    依赖：numpy
"""Multi-trait MME: (a) G0 prop R0 -> no gain; (b) accuracy gain with/without missing."""
import numpy as np
np.set_printoptions(precision=4, suppress=True, linewidth=150)

ped = {1:(0,0),2:(0,0),3:(0,0),4:(0,0),
       5:(1,3),6:(1,4),7:(2,3),8:(2,4),
       9:(5,8),10:(6,7),11:(5,7),12:(6,8)}
n = len(ped)

def Ainv(ped):
    n=len(ped); Ai=np.zeros((n,n)); F=np.zeros(n+1); A=np.zeros((n,n))
    for i in range(1,n+1):
        s,d=ped[i]
        for j in range(1,i+1):
            sj,dj=ped[j]
            if i==j:
                A[i-1,i-1]=1+(A[s-1,d-1] if s and d else 0.0)
            else:
                a=0.0
                if s: a+=0.5*A[j-1,s-1]
                if d: a+=0.5*A[j-1,d-1]
                A[i-1,j-1]=A[j-1,i-1]=a
    for i in range(1,n+1): F[i]=A[i-1,i-1]-1
    for i in range(1,n+1):
        s,d=ped[i]
        fs=F[s] if s else -1.0; fd=F[d] if d else -1.0
        b=0.5-0.25*(fs+fd)   # = 1/ (4/(2-Fs-Fd)) style; b_i = variance of mendelian sampling
        di=1.0/b if False else 0.0
        # standard: d_i = 0.5 - 0.25*(F_s+F_d) when both known; 0.75-0.25F_s one known; 1 none
        if s and d: dv=0.5-0.25*(F[s]+F[d])
        elif s:     dv=0.75-0.25*F[s]
        elif d:     dv=0.75-0.25*F[d]
        else:       dv=1.0
        a=1.0/dv
        idx=[i-1]+([s-1] if s else [])+([d-1] if d else [])
        cf=[1.0]+([-0.5] if s else [])+([-0.5] if d else [])
        for p,ip in zip(cf,idx):
            for q,iq in zip(cf,idx):
                Ai[ip,iq]+=p*q*a
    return Ai, A

Ai, A = Ainv(ped)
print("A diag:", np.diag(A))
print("Ainv[0:4,0:4]:\n", Ai[:4,:4])

herd = np.array([1 if i%2==1 else 2 for i in range(1,n+1)])
y1 = np.array([102.,  96., 110.,  91., 105.,  99., 113.,  94., 108., 101., 97., 106.])
y2 = np.array([ 48.,  55.,  61.,  44.,  57.,  50.,  63.,  46.,  59.,  52., 45., 58.])

def build_MT(G0, R0, obs):
    """obs: n x 2 boolean; stacked by trait. returns C, rhs, index maps"""
    t=2
    Xb=[];Zb=[]
    # per-trait design
    nb_beta=2
    # equation order: beta_1(2), beta_2(2), u_1(n), u_2(n)
    p=t*nb_beta; q=t*n; N=p+q
    C=np.zeros((N,N)); rhs=np.zeros(N)
    R0i_cache={}
    y=[y1,y2]
    for i in range(n):
        S=[k for k in range(t) if obs[i,k]]
        key=tuple(S)
        if key not in R0i_cache:
            R0i_cache[key]=np.linalg.inv(R0[np.ix_(S,S)])
        Ri=R0i_cache[key]
        # rows of W for this animal: for trait k in S, w has beta col (k*2 + herd-1) and u col (p + k*n + i)
        cols=[]; yv=[]
        for k in S:
            cols.append((k*nb_beta+herd[i]-1, p+k*n+i))
            yv.append(y[k][i])
        for a_,(bc,uc) in enumerate(cols):
            for b_,(bc2,uc2) in enumerate(cols):
                w=Ri[a_,b_]
                C[bc,bc2]+=w; C[bc,uc2]+=w; C[uc,bc2]+=w; C[uc,uc2]+=w
            rr=sum(Ri[a_,b_]*yv[b_] for b_ in range(len(cols)))
            rhs[bc]+=rr; rhs[uc]+=rr
    G0i=np.linalg.inv(G0)
    for k in range(t):
        for l in range(t):
            C[p+k*n:p+(k+1)*n, p+l*n:p+(l+1)*n]+=G0i[k,l]*Ai
    return C, rhs, p

def build_ST(sa2, se2, obs_k, yk):
    lam=se2/sa2
    p=2; N=p+n
    C=np.zeros((N,N)); rhs=np.zeros(N)
    for i in range(n):
        if not obs_k[i]: continue
        bc=herd[i]-1; uc=p+i
        C[bc,bc]+=1; C[bc,uc]+=1; C[uc,bc]+=1; C[uc,uc]+=1
        rhs[bc]+=yk[i]; rhs[uc]+=yk[i]
    C[p:,p:]+=Ai*lam
    return C, rhs, p

# ---------- (a) proportionality check ----------
print("\n" + "="*60)
print("(a) G0 = c*R0, complete data")
R0 = np.array([[40.,11.],[11.,30.]]); c=0.35; G0=c*R0
print("G0 =", G0.tolist(), " c =", c, " lambda = 1/c =", 1/c)
print("h1^2 = %.6f  h2^2 = %.6f  rA = %.6f  rE = %.6f" %
      (G0[0,0]/(G0[0,0]+R0[0,0]), G0[1,1]/(G0[1,1]+R0[1,1]),
       G0[0,1]/np.sqrt(G0[0,0]*G0[1,1]), R0[0,1]/np.sqrt(R0[0,0]*R0[1,1])))
obs_full=np.ones((n,2),dtype=bool)
C,rhs,p = build_MT(G0,R0,obs_full); sol=np.linalg.solve(C,rhs)
u1_mt=sol[p:p+n]; u2_mt=sol[p+n:p+2*n]; b_mt=sol[:p]
C1,r1,p1=build_ST(G0[0,0],R0[0,0],obs_full[:,0],y1); s1=np.linalg.solve(C1,r1)
C2,r2,p2=build_ST(G0[1,1],R0[1,1],obs_full[:,1],y2); s2=np.linalg.solve(C2,r2)
print("max |u1_MT - u1_ST| = %.3e" % np.max(np.abs(u1_mt-s1[p1:])))
print("max |u2_MT - u2_ST| = %.3e" % np.max(np.abs(u2_mt-s2[p2:])))
print("max |beta_MT - beta_ST| = %.3e" % max(np.max(np.abs(b_mt[:2]-s1[:2])), np.max(np.abs(b_mt[2:]-s2[:2]))))
allmax=max(np.max(np.abs(u1_mt-s1[p1:])), np.max(np.abs(u2_mt-s2[p2:])),
           np.max(np.abs(b_mt[:2]-s1[:2])), np.max(np.abs(b_mt[2:]-s2[:2])))
print("OVERALL max abs diff = %.3e" % allmax)
print("cond(C) = %.4g" % np.linalg.cond(C))

# ---------- (a2) non-proportional contrast ----------
print("\n(a2) non-proportional G0 (same R0), complete data")
G0b=np.array([[20.,6.],[6.,8.]])
print("G0 =", G0b.tolist())
print("h1^2=%.4f h2^2=%.4f rA=%.4f rE=%.4f" % (20/60, 8/38, 6/np.sqrt(160), 11/np.sqrt(1200)))
Cb,rb,pb=build_MT(G0b,R0,obs_full); solb=np.linalg.solve(Cb,rb)
C1b,r1b,_=build_ST(20.,40.,obs_full[:,0],y1); s1b=np.linalg.solve(C1b,r1b)
C2b,r2b,_=build_ST(8.,30.,obs_full[:,1],y2); s2b=np.linalg.solve(C2b,r2b)
d1=np.max(np.abs(solb[pb:pb+n]-s1b[2:])); d2=np.max(np.abs(solb[pb+n:pb+2*n]-s2b[2:]))
print("max |u1_MT-u1_ST| = %.4f   max |u2_MT-u2_ST| = %.4f" % (d1,d2))
print("sd(u2_ST) = %.4f ; ratio = %.3f" % (np.std(s2b[2:]), d2/np.std(s2b[2:])))

# ---------- (b) accuracy with rg, with/without missing ----------
print("\n" + "="*60)
print("(b) accuracy from MME inverse, sP^2=100 both traits, h1=0.25 h2=0.10, re=0")
sA1s, sA2s, sE1s, sE2s = 25., 10., 75., 90.
def run(rg, miss_ids):
    sA12=rg*np.sqrt(sA1s*sA2s)
    G0=np.array([[sA1s,sA12],[sA12,sA2s]]); R0=np.array([[sE1s,0.],[0.,sE2s]])
    obs=np.ones((n,2),dtype=bool)
    for i in miss_ids: obs[i-1,1]=False
    C,rhs,p=build_MT(G0,R0,obs)
    Cinv=np.linalg.inv(C)
    pev2=np.diag(Cinv)[p+n:p+2*n]
    r2=1-pev2/sA2s
    # single trait trait-2
    C2,r2v,p2=build_ST(sA2s,sE2s,obs[:,1],y2)
    C2inv=np.linalg.inv(C2)
    pev2s=np.diag(C2inv)[p2:]*sE2s          # lambda-scaled MME: PEV = C^{-1} * sigma_e^2
    r2s=1-pev2s/sA2s
    return np.sqrt(np.maximum(r2,0)), np.sqrt(np.maximum(r2s,0))

print("\n-- complete data (no missing) --")
print("rg     mean acc ST   mean acc MT   gain%")
for rg in [0.0,0.3,0.6,0.9]:
    a_mt,a_st=run(rg,[])
    print(f"{rg:.1f}    {a_st.mean():.4f}        {a_mt.mean():.4f}       {100*(a_mt.mean()/a_st.mean()-1):6.2f}")

miss=[7,8,9,10,11,12]
print("\n-- trait 2 missing on animals 7-12 --")
print("rg   ST(all12) MT(all12) gain%  | ST(miss6) MT(miss6) gain%")
for rg in [0.0,0.3,0.6,0.9]:
    a_mt,a_st=run(rg,miss)
    m=np.array([i-1 for i in miss])
    print(f"{rg:.1f}   {a_st.mean():.4f}   {a_mt.mean():.4f}  {100*(a_mt.mean()/a_st.mean()-1):6.2f} |"
          f"  {a_st[m].mean():.4f}   {a_mt[m].mean():.4f}  {100*(a_mt[m].mean()/a_st[m].mean()-1):6.2f}")
