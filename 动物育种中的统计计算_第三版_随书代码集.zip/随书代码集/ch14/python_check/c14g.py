# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 14 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c14g.py    依赖：numpy, scipy
"""Bending: trace behaviour, condition numbers, penalty <-> shrinkage mapping."""
import numpy as np
from scipy.linalg import eigh
np.set_printoptions(precision=6, suppress=True, linewidth=170)
sA=np.array([5.,4.,3.]); Rg=np.array([[1.,.9,.8],[.9,1.,.3],[.8,.3,1.]])
G0=np.outer(sA,sA)*Rg
w,V=eigh(G0); idx=np.argsort(w)[::-1]; w=w[idx]; V=V[:,idx]; lbar=w.mean()
print("eig:",w," lbar=%.6f  trace=%.4f  det=%.4f"%(lbar,np.trace(G0),np.linalg.det(G0)))
rho_min=-w.min()/(lbar-w.min()); print("rho_min = %.6f"%rho_min)
print("\nmethod          eigenvalues                         trace      det        cond")
for nm,eps_or_rho,kind in [("原始 hatG0",None,"raw"),
                           ("截断 eps=1e-6*lbar",1e-6*lbar,"trunc"),
                           ("截断 eps=0.01*lbar",0.01*lbar,"trunc"),
                           ("收缩 rho=rho_min",rho_min,"shr"),
                           ("收缩 rho=0.10",0.10,"shr"),
                           ("收缩 rho=0.20",0.20,"shr")]:
    if kind=="raw": ww=w.copy(); M=G0
    elif kind=="trunc": ww=np.maximum(w,eps_or_rho); M=V@np.diag(ww)@V.T
    else: ww=(1-eps_or_rho)*w+eps_or_rho*lbar; M=(1-eps_or_rho)*G0+eps_or_rho*lbar*np.eye(3)
    cd = ww.max()/ww.min() if ww.min()>0 else float('inf')
    print("%-20s %-34s %8.4f %10.4f %12.4g" %
          (nm, np.array2string(ww,precision=4), np.trace(M), np.linalg.det(M), cd))
    if kind!="raw":
        d=np.sqrt(np.diag(M))
        print("%22s rA12=%.4f rA13=%.4f rA23=%.4f   sigmaA=%s"%("",M[0,1]/(d[0]*d[1]),M[0,2]/(d[0]*d[2]),M[1,2]/(d[1]*d[2]),np.array2string(d,precision=4)))

print("\npenalty <-> shrinkage:  G_pen = (n*hatG0 + nu*S)/(n+nu), S = lbar*I  => rho = nu/(n+nu)")
for n_eff in [50,100,500]:
    nu_need = n_eff*rho_min/(1-rho_min)
    print("  n_eff=%4d : nu needed for PD = %.3f ; nu=10 gives rho=%.4f ; nu=20 gives rho=%.4f"
          % (n_eff, nu_need, 10/(n_eff+10), 20/(n_eff+20)))
# feasible r23 interval
lo=0.9*0.8-np.sqrt((1-0.81)*(1-0.64)); hi=0.9*0.8+np.sqrt((1-0.81)*(1-0.64))
print("\nfeasible r23 given r12=0.90,r13=0.80: [%.4f, %.4f]  width %.4f"%(lo,hi,hi-lo))
for r12,r13 in [(0.9,0.8),(0.8,0.7),(0.6,0.5),(0.3,0.2)]:
    l=r12*r13-np.sqrt((1-r12**2)*(1-r13**2)); h=r12*r13+np.sqrt((1-r12**2)*(1-r13**2))
    print("  r12=%.2f r13=%.2f -> r23 in [%.4f, %.4f], width %.4f (fraction of [-1,1]: %.3f)"%(r12,r13,l,h,h-l,(h-l)/2))
