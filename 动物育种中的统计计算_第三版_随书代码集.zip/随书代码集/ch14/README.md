# 第十四章　多性状模型 —— 配套代码

**所属**：第三篇　线性混合模型的理论与计算　　**对应正文**：第十四章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch14.ipynb` | IJulia 笔记本：6 个代码单元，约 209 行 Julia 代码，穿插与正文对应的说明 |
| `ch14.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 9 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　多性状 MME 与准确性提升（正文 §14.2）
- 2　退化验证：$\mathbf G_0\propto\mathbf R_0$ 时多性状无收益（第五章"免费测试用例"）
- 3　缺失数据：按缺失模式构造 $\mathbf R^{-1}$（正文 §14.3.2）
- 4　典型变换（正文 §14.2.4）
- 5　正定性与弯曲（正文 §14.4）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 14
```

或在 Jupyter 中打开 `ch14/ch14.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
