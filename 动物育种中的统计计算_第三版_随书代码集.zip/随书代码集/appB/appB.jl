# 本脚本由 tools/nb2jl.py 从同目录的 appB.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl appB

# %% [markdown]
# # 附录 B　概率分布手册 —— 配套代码
#
# 本 Notebook 对应附录 B。原则只有一条：**任何抽样函数在进入 MCMC 之前，都要先通过与模型无关的分布检验**（第五章"验证工具箱"）。
#
# | 节 | 内容 | 对应附录 B |
# |:--|:--|:--|
# | 1 | 检验工具：矩检验、Kolmogorov–Smirnov 统计量 | §B.9 |
# | 2 | `Distributions.jl` 的参数化陷阱；正态—逆卡方混合的 $t$ 边际 | §B.1–B.2，式 (B.1) |
# | 3 | **逆卡方的三种参数化与"先验抽样检验"**；共轭更新 | §B.3，式 (B.2)–(B.3) |
# | 4 | 多元分布：Cholesky 抽样、Bartlett 分解、逆 Wishart 均值、Dirichlet | §B.4 |
# | 5 | 离散分布：条件二项法抽多项分布、Walker 别名法 | §B.5、§B.8 |
# | 6 | 随机数发生器：可复现性、按逻辑单元播种、LCG 的低位周期 | §B.7 |
# | 7 | 抽样算法：逆变换、极端尾部的截断正态、Box–Muller、Marsaglia–Tsang | §B.8 |
# | 8 | 基于模拟的校准（SBC）：发现完全条件推导错误 | §B.9 |
# | 9 | 马尔可夫链：非周期性、细致平衡、MH 与 Gibbs 的平稳性 | §B.10，式 (B.5)–(B.6) |
# | 10 | 自检汇总 | — |

# %%
using LinearAlgebra, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-10)
    e = relerr(a, b)
    @printf("%-50s 相对误差 = %.2e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
ok = Bool[]
println("Julia ", VERSION)

# %% [markdown]
# ## 1　检验工具
#
# - **矩检验**：样本均值与理论均值之差除以蒙特卡洛标准误，$|z|<4$ 视为通过；
# - **KS 统计量** $D_n=\sup_x|F_n(x)-F(x)|$；显著性水平 $\alpha$ 的渐近临界值为 $\sqrt{-\tfrac12\ln(\alpha/2)}/\sqrt n$（$\alpha=0.001$ 时约 $1.95/\sqrt n$）。
#
# 所有检验都用固定种子，结果可复现；个别检验偶然失败（概率约为 $\alpha$）时，换一个种子重跑即可区分"偶然"与"错误"。

# %%
"""样本均值的 z 分数（理论均值 μ、理论方差 σ²）。"""
mom_z(x, μ, σ2) = (mean(x) - μ) / sqrt(σ2 / length(x))

"""单样本 KS 统计量；F 为理论分布函数。"""
function ks_stat(x::AbstractVector, F)
    xs = sort(x); n = length(xs); D = 0.0
    for (i, v) in enumerate(xs)
        Fv = F(v)
        D = max(D, i/n - Fv, Fv - (i-1)/n)
    end
    return D
end
ks_crit(n; α=0.001) = sqrt(-0.5 * log(α / 2) / n)
@printf("n = 10⁵ 时 α = 0.001 的 KS 临界值 = %.5f\n", ks_crit(100_000))

# %% [markdown]
# ## 2　参数化陷阱与 $t$ 边际（式 B.1）
#
# `Normal(μ, σ)` 的第二个参数是**标准差**；`Gamma(α, θ)` 的第二个参数是**尺度**（速率的倒数）。式 (B.1)：$X\mid\sigma^2\sim N(0,\sigma^2)$、$\sigma^2\sim\chi^{-2}(\nu,S)$，则 $X\sim\sqrt S\,t_\nu$——这就是 BayesA 标记效应边际先验为 $t$ 分布的原因（第二十二章式 22.11）。

# %%
let rng = Xoshiro(201), n = 200_000
    xg = rand(rng, Gamma(2.0, 3.0), n)                 # 形状 2，尺度 3
    @printf("Gamma(2, 3)：样本均值 %.3f（尺度参数化的理论值 6；若误当速率则应为 %.3f）\n", mean(xg), 2/3)
    push!(ok, abs(mom_z(xg, 6.0, 18.0)) < 4)
    xn = rand(rng, Normal(1.0, 2.0), n)
    @printf("Normal(1, 2)：样本方差 %.3f（第二参数是标准差，方差应为 4）\n", var(xn))
    push!(ok, abs(var(xn) / 4 - 1) < 0.02)
    # 式 (B.1)
    ν, S = 5.0, 2.0
    σ2 = ν * S ./ rand(rng, Chisq(ν), n)
    x  = sqrt.(σ2) .* randn(rng, n)
    D  = ks_stat(x, v -> cdf(TDist(ν), v / sqrt(S)))
    @printf("式 (B.1)：正态—逆卡方混合 vs √S·t_ν 的 KS 统计量 = %.5f（临界值 %.5f）\n", D, ks_crit(n))
    push!(ok, D < ks_crit(n))
end

# %% [markdown]
# ## 3　逆卡方的三种参数化与先验抽样检验（式 B.2–B.3）
#
# 约定 A（本书）：$\sigma^2=\nu S/\chi^2_\nu$；约定 C：`InverseGamma(ν/2, νS/2)`。二者应完全同分布。常见错误"$S/\chi^2_\nu$"（漏乘 $\nu$）使先验均值只剩正确值的 $1/\nu$。**在无数据的条件下从先验抽样、与理论分布比较**，是任何 MCMC 实现之前都应当做的纯分布检验。
#
# $\nu=4$ 时方差无穷，样本均值收敛很慢，因此判定用 KS 统计量与中位数，均值只作展示。

# %%
let rng = Xoshiro(301), n = 100_000, ν = 4.0, S = 2.0
    dA  = InverseGamma(ν/2, ν*S/2)                          # 约定 C 表示的约定 A 分布
    xA  = ν * S ./ rand(rng, Chisq(ν), n)                   # 约定 A 的抽样
    xC  = rand(rng, dA, n)                                  # InverseGamma
    xC2 = 1 ./ rand(rng, Gamma(ν/2, 2/(ν*S)), n)            # 1/Gamma(α, 尺度 1/β)
    xW  = S ./ rand(rng, Chisq(ν), n)                       # 错误：漏乘 ν
    med = ν * S / quantile(Chisq(ν), 0.5)
    @printf("%-26s%-12s%-12s%-12s\n", "抽样方式", "样本均值", "样本中位数", "KS 统计量")
    for (nm, x) in (("νS/χ²_ν（约定 A）", xA), ("InverseGamma(ν/2, νS/2)", xC),
                    ("1/Gamma(ν/2, 尺度 2/(νS))", xC2), ("S/χ²_ν（错误）", xW))
        @printf("%-26s%-12.3f%-12.3f%-12.5f\n", nm, mean(x), median(x), ks_stat(x, v -> cdf(dA, v)))
    end
    @printf("理论：均值 νS/(ν−2) = %.3f，中位数 %.3f，众数 νS/(ν+2) = %.3f；KS 临界值 %.5f\n",
            ν*S/(ν-2), med, ν*S/(ν+2), ks_crit(n))
    push!(ok, all(ks_stat(x, v -> cdf(dA, v)) < ks_crit(n) for x in (xA, xC, xC2)))
    push!(ok, ks_stat(xW, v -> cdf(dA, v)) > 10ks_crit(n))    # 错误的参数化必须被检出
    push!(ok, abs(median(xA) / med - 1) < 0.02)
end

# %%
# 式 (B.3)：共轭更新。把"先验 × 似然"在网格上数值归一化，与解析的后验密度逐点比较
let rng = Xoshiro(302), ν = 5.0, S = 1.5, nobs = 20
    x  = 2.0 .* randn(rng, nobs)                            # 真实 σ² = 4
    ss = sum(abs2, x)
    post = InverseGamma((ν + nobs)/2, (ν*S + ss)/2)         # 即 χ⁻²(ν+n, (νS+Σx²)/(ν+n))
    h  = 1e-4; g = h:h:40.0
    logk = [-(ν/2 + 1)*log(s) - ν*S/(2s) - (nobs/2)*log(s) - ss/(2s) for s in g]
    k  = exp.(logk .- maximum(logk))
    k ./= h * (sum(k) - 0.5*(k[1] + k[end]))                 # 梯形法归一化
    push!(ok, check("式 (B.3) 数值后验 = 解析后验（网格上）", k, pdf.(post, g); tol=1e-5))
    @printf("后验均值 %.4f（真值 4；先验均值 %.4f）\n", mean(post), ν*S/(ν-2))
end

# %% [markdown]
# ## 4　多元分布（§B.4）
#
# - 多元正态：$\mathbf x=\boldsymbol\mu+\mathbf{Lz}$，$\boldsymbol\Sigma=\mathbf{LL}'$；
# - Wishart 的 **Bartlett 分解**：$b_{ii}=\sqrt{\chi^2_{\nu-i+1}}$、$b_{ij}\sim N(0,1)$（$i>j$），$\mathbf{LBB}'\mathbf L'\sim\mathcal W_p(\nu,\mathbf S)$，$E=\nu\mathbf S$；
# - 逆 Wishart：$E(\boldsymbol\Sigma)=\boldsymbol\Psi/(\nu-p-1)$；
# - Dirichlet：独立 Gamma 归一化。

# %%
"""Bartlett 分解抽 Wishart(ν, S)。"""
function rand_wishart_bartlett(rng, ν, S)
    p = size(S, 1); L = cholesky(Symmetric(S)).L
    B = zeros(p, p)
    for i in 1:p
        B[i, i] = sqrt(rand(rng, Chisq(ν - i + 1)))
        for j in 1:i-1
            B[i, j] = randn(rng)
        end
    end
    LB = L * B
    return LB * LB'
end

let rng = Xoshiro(401), p = 3, nrep = 40_000
    S = [2.0 0.6 0.3; 0.6 1.0 0.2; 0.3 0.2 1.5]; ν = 7.0
    # 多元正态
    Lc = cholesky(Symmetric(S)).L
    Xm = Lc * randn(rng, p, 200_000)
    push!(ok, check("MvNormal：样本协方差 ≈ Σ", cov(Xm; dims=2), S; tol=0.02))
    # Wishart：Bartlett 与 Distributions 的均值
    Wb = sum(rand_wishart_bartlett(rng, ν, S) for _ in 1:nrep) / nrep
    Wd = sum(rand(rng, Wishart(ν, S)) for _ in 1:nrep) / nrep
    push!(ok, check("Bartlett 分解：E(W) ≈ νS", Wb, ν .* S; tol=0.02))
    push!(ok, check("Distributions.Wishart：E(W) ≈ νS", Wd, ν .* S; tol=0.02))
    # 逆 Wishart
    Ψ = S; νi = 9.0
    Iw = sum(rand(rng, InverseWishart(νi, Ψ)) for _ in 1:nrep) / nrep
    push!(ok, check("InverseWishart：E(Σ) ≈ Ψ/(ν−p−1)", Iw, Ψ ./ (νi - p - 1); tol=0.03))
    # Dirichlet
    α = [1.0, 2.0, 3.0, 4.0]
    Gs = rand(rng, Gamma(1.0, 1.0), 1)   # 预热
    πs = [(g = [rand(rng, Gamma(a, 1.0)) for a in α]; g ./ sum(g)) for _ in 1:nrep]
    push!(ok, check("Dirichlet（Gamma 归一化）：E(π) ≈ α/α₀", sum(πs) / nrep, α ./ sum(α); tol=0.01))
end

# %% [markdown]
# ## 5　离散分布：条件二项法与 Walker 别名法（§B.5、§B.8）

# %%
"""依次抽条件二项得到多项分布。"""
function rand_multinomial_seq(rng, n::Int, p::Vector{Float64})
    K = length(p); x = zeros(Int, K); rem_n = n; rem_p = 1.0
    for k in 1:K-1
        q = rem_p > 0 ? clamp(p[k] / rem_p, 0.0, 1.0) : 0.0
        x[k] = rand(rng, Binomial(rem_n, q))
        rem_n -= x[k]; rem_p -= p[k]
    end
    x[K] = rem_n
    return x
end

"""Walker 别名表（Vose 的构造）：预处理 O(K)，每次抽样 O(1)。"""
function alias_table(p::Vector{Float64})
    K = length(p); prob = zeros(K); alias = zeros(Int, K)
    scaled = p .* K
    small = Int[]; large = Int[]
    for (k, s) in enumerate(scaled)
        s < 1.0 ? push!(small, k) : push!(large, k)
    end
    while !isempty(small) && !isempty(large)
        s = pop!(small); l = pop!(large)
        prob[s] = scaled[s]; alias[s] = l
        scaled[l] = scaled[l] + scaled[s] - 1.0
        scaled[l] < 1.0 ? push!(small, l) : push!(large, l)
    end
    for l in large; prob[l] = 1.0; end
    for s in small; prob[s] = 1.0; end        # 数值舍入的残余
    return prob, alias
end
alias_draw(rng, prob, alias) = (k = rand(rng, 1:length(prob)); rand(rng) < prob[k] ? k : alias[k])

let rng = Xoshiro(501), p = [0.05, 0.15, 0.30, 0.50], n = 50, nrep = 50_000
    X = reduce(hcat, [rand_multinomial_seq(rng, n, p) for _ in 1:nrep])
    push!(ok, check("条件二项法：E(x) = np", vec(mean(X; dims=2)), n .* p; tol=0.01))
    Σth = n .* (Diagonal(p) - p*p')
    push!(ok, check("条件二项法：Cov(x) = n(diag(p) − pp')", cov(X; dims=2), Σth; tol=0.03))
    pw = [0.01, 0.04, 0.10, 0.20, 0.25, 0.40]
    prob, al = alias_table(pw)
    N = 400_000
    cnt = zeros(Int, length(pw))
    for _ in 1:N
        cnt[alias_draw(rng, prob, al)] += 1
    end
    χ2 = sum((cnt .- N .* pw).^2 ./ (N .* pw))
    @printf("别名法 %d 次抽样：χ² = %.2f（自由度 5，0.999 分位数 %.2f）\n", N, χ2, quantile(Chisq(5), 0.999))
    push!(ok, χ2 < quantile(Chisq(5), 0.999))
end

# %% [markdown]
# ## 6　随机数发生器（§B.7）
#
# 1. 同一种子、同一版本 → 逐位相同；
# 2. **按逻辑单元播种**（第 $r$ 个重复用 `Xoshiro(hash((seed, r)))`）使结果与线程数、调度顺序无关；
# 3. 线性同余法（LCG）的最低位以周期 2 交替——这就是它"不适合科学计算"的一个直观原因；
# 4. "均值接近 0.5"远不足以说明随机性：一个确定性的递增序列均值也是 0.5，但前后高度相关。

# %%
push!(ok, rand(Xoshiro(42), 5) == rand(Xoshiro(42), 5))
let seed = 20260918, R = 16
    one_rep(r) = sum(rand(Xoshiro(hash((seed, r))), 1000))
    serial = [one_rep(r) for r in 1:R]
    threaded = zeros(R)
    Threads.@threads for r in 1:R
        threaded[r] = one_rep(r)
    end
    @printf("线程数 %d：串行与多线程结果逐位相同？ %s\n", Threads.nthreads(), serial == threaded)
    push!(ok, serial == threaded)
end
let a = UInt32(1664525), c = UInt32(1013904223), x = UInt32(12345), bits = Int[]
    for _ in 1:12
        x = a * x + c                    # UInt32 运算自动模 2³²
        push!(bits, Int(x & 0x00000001))
    end
    println("LCG 最低位序列：", join(bits, " "))
    push!(ok, all(bits[i] != bits[i+1] for i in 1:length(bits)-1))
end
let n = 10_000
    u = collect(0:n-1) ./ n
    @printf("确定性序列 0, 1/n, 2/n, …：均值 = %.4f，但一阶自相关 = %.4f\n", mean(u), cor(u[1:end-1], u[2:end]))
    push!(ok, abs(mean(u) - 0.5) < 1e-3 && cor(u[1:end-1], u[2:end]) > 0.99)
end

# %% [markdown]
# ## 7　抽样算法（§B.8）
#
# - **逆变换**：指数分布 $X=-\theta\log U$；
# - **极端尾部的截断正态**：$a=8.5$ 时 $\Phi(a)$ 在双精度下已舍入为 1，朴素逆变换失效；改在互补分布函数的尺度上计算（`cquantile`），或用 Robert（1995）的指数提议拒绝抽样；
# - **Box–Muller**；
# - **Marsaglia–Tsang**（2000）的 Gamma 抽样，以及 $\alpha<1$ 时的 $YU^{1/\alpha}$ 提升。

# %%
"""Robert (1995)：N(0,1) 在 (a, ∞) 上截断，a > 0。"""
function rand_tnorm_tail(rng, a)
    αs = (a + sqrt(a^2 + 4)) / 2
    while true
        z = a - log(rand(rng)) / αs                  # a + Exp(速率 αs)
        rand(rng) <= exp(-(z - αs)^2 / 2) && return z
    end
end

"""Marsaglia–Tsang (2000)：Gamma(α, 1)。"""
function rand_gamma_mt(rng, α)
    if α < 1
        return rand_gamma_mt(rng, α + 1) * rand(rng)^(1 / α)
    end
    d = α - 1/3; c = 1 / sqrt(9d)
    while true
        z = randn(rng); v = (1 + c*z)^3
        v <= 0 && continue
        log(rand(rng)) < 0.5z^2 + d - d*v + d*log(v) && return d * v
    end
end

let rng = Xoshiro(701), n = 200_000
    # 逆变换：指数分布
    θ = 2.5
    xe = -θ .* log.(rand(rng, n))
    push!(ok, ks_stat(xe, v -> cdf(Exponential(θ), v)) < ks_crit(n))
    # 极端尾部的截断正态
    a = 8.5
    @printf("Φ(8.5) 在双精度下 = %.17f；1 − Φ(8.5) = %.3e（ccdf 直接计算）\n", cdf(Normal(), a), ccdf(Normal(), a))
    naive = quantile(Normal(), cdf(Normal(), a) + 0.5 * (1 - cdf(Normal(), a)))
    @printf("朴素逆变换的一个抽样 = %s（失效）\n", string(naive))
    push!(ok, !isfinite(naive) || naive == a || isnan(naive))
    Etail = pdf(Normal(), a) / ccdf(Normal(), a)             # E(Z | Z > a)
    zr = [rand_tnorm_tail(rng, a) for _ in 1:n]
    zc = [cquantile(Normal(), rand(rng) * ccdf(Normal(), a)) for _ in 1:n]
    @printf("E(Z|Z>8.5)：理论 %.5f，Robert %.5f，互补尺度逆变换 %.5f\n", Etail, mean(zr), mean(zc))
    push!(ok, all(zr .> a) && abs(mean(zr) - Etail) < 0.002)
    push!(ok, all(zc .> a) && abs(mean(zc) - Etail) < 0.002)
    # Box–Muller
    u1, u2 = rand(rng, n ÷ 2), rand(rng, n ÷ 2)
    r = sqrt.(-2 .* log.(u1))
    z1, z2 = r .* cos.(2π .* u2), r .* sin.(2π .* u2)
    push!(ok, ks_stat(vcat(z1, z2), v -> cdf(Normal(), v)) < ks_crit(n))
    push!(ok, abs(cor(z1, z2)) < 4 / sqrt(n ÷ 2))
    # Marsaglia–Tsang
    for α in (0.5, 2.5)
        xg = [rand_gamma_mt(rng, α) for _ in 1:n]
        D = ks_stat(xg, v -> cdf(Gamma(α, 1.0), v))
        @printf("Marsaglia–Tsang α = %.1f：KS = %.5f（临界值 %.5f）\n", α, D, ks_crit(n))
        push!(ok, D < ks_crit(n))
    end
end

# %% [markdown]
# ## 8　基于模拟的校准（SBC，§B.9）
#
# 模型：$\sigma^2\sim\chi^{-2}(\nu_0,S_0)$，$x_i\mid\sigma^2\sim N(0,\sigma^2)$。重复：从先验抽"真值"→ 模拟数据 → 用待检的后验抽样器抽 $L$ 个样本 → 记录真值在样本中的秩。**后验抽样器正确时，秩服从 $\{0,\dots,L\}$ 上的均匀分布。**对照一个"漏掉先验项"的错误抽样器（完全条件推导漏项的典型情形，第五章案例四），秩直方图明显偏离均匀。

# %%
function sbc_ranks(rng, sampler; R=2000, L=99, ν0=6.0, S0=1.0, nobs=10)
    ranks = zeros(Int, R)
    for r in 1:R
        σ2 = ν0 * S0 / rand(rng, Chisq(ν0))
        x  = sqrt(σ2) .* randn(rng, nobs)
        post = sampler(rng, x, ν0, S0, L)
        ranks[r] = count(<(σ2), post)
    end
    return ranks
end
# 正确的完全条件：χ⁻²(ν0 + n, (ν0 S0 + Σx²)/(ν0 + n))，式 (B.3)
good_sampler(rng, x, ν0, S0, L) = (ν0*S0 + sum(abs2, x)) ./ rand(rng, Chisq(ν0 + length(x)), L)
# 错误：漏掉先验项（只用数据）
bad_sampler(rng, x, ν0, S0, L)  = sum(abs2, x) ./ rand(rng, Chisq(length(x)), L)

function rank_chi2(ranks; L=99, nbins=10)
    cnt = zeros(Int, nbins)
    for r in ranks
        cnt[min(nbins, r * nbins ÷ (L + 1) + 1)] += 1
    end
    e = length(ranks) / nbins
    return sum((cnt .- e).^2 ./ e), cnt
end

let rng = Xoshiro(801)
    crit = quantile(Chisq(9), 0.999)
    for (nm, s) in (("正确的完全条件", good_sampler), ("漏掉先验项", bad_sampler))
        χ2, cnt = rank_chi2(sbc_ranks(rng, s))
        @printf("%-14s 秩直方图 %s  χ² = %7.2f（临界值 %.2f）\n", nm, string(cnt), χ2, crit)
        push!(ok, nm == "正确的完全条件" ? χ2 < crit : χ2 > crit)
    end
end

# %% [markdown]
# ## 9　马尔可夫链：非周期性与细致平衡（§B.10，式 B.5–B.6）
#
# 在有限状态空间上，平稳性、细致平衡、收敛都可以**精确地**用矩阵运算检验：
#
# 1. 周期链 $p_{12}=p_{21}=1$：$\boldsymbol\pi=(\tfrac12,\tfrac12)$ 平稳，但 $\mathbf P^t$ 不收敛；"懒惰化" $(\mathbf I+\mathbf P)/2$ 后收敛；
# 2. Metropolis–Hastings（对称提议）：$\mathrm{diag}(\boldsymbol\pi)\mathbf P$ 对称（细致平衡），$\boldsymbol\pi'\mathbf P=\boldsymbol\pi'$；
# 3. Gibbs：单分量更新核 $\mathbf K_1$、$\mathbf K_2$ 各自满足细致平衡；系统扫描 $\mathbf K_1\mathbf K_2$ 保持 $\boldsymbol\pi$ **但不可逆**；随机扫描 $(\mathbf K_1+\mathbf K_2)/2$ 可逆。

# %%
# 1. 周期链
let P = [0.0 1.0; 1.0 0.0], πv = [0.5, 0.5]
    push!(ok, check("周期链：π'P = π'", P' * πv, πv; tol=1e-14))
    @printf("P^100 第一行 = %s；P^101 第一行 = %s（振荡，不收敛）\n", string((P^100)[1, :]), string((P^101)[1, :]))
    push!(ok, (P^100)[1, 1] == 1.0 && (P^101)[1, 1] == 0.0)
    Pl = (I + P) / 2
    push!(ok, check("懒惰链：P^50 的每一行 → π", (Pl^50)[1, :], πv; tol=1e-12))
end
# 2. 离散目标上的 Metropolis–Hastings（均匀对称提议）
let πv = [0.05, 0.10, 0.15, 0.20, 0.25, 0.25], K = 6
    P = zeros(K, K)
    for i in 1:K, j in 1:K
        i == j && continue
        P[i, j] = (1 / (K - 1)) * min(1.0, πv[j] / πv[i])      # 式 (B.6)，q 对称
    end
    for i in 1:K
        P[i, i] = 1.0 - sum(P[i, :])
    end
    F = Diagonal(πv) * P
    push!(ok, check("MH：细致平衡 diag(π)P 对称（式 B.5）", F, F'; tol=1e-14))
    push!(ok, check("MH：π'P = π'", P' * πv, πv; tol=1e-14))
    push!(ok, check("MH：P^200 的行 → π", (P^200)[3, :], πv; tol=1e-10))
end

# %%
# 3. Gibbs：3×3 联合分布上的单分量更新核
let J = [0.10 0.05 0.05; 0.05 0.20 0.10; 0.05 0.10 0.30]     # π(i, j)，和为 1
    nI, nJ = size(J); S = nI * nJ
    idx(i, j) = (j - 1) * nI + i
    πv = vec(J)
    K1 = zeros(S, S); K2 = zeros(S, S)
    for i in 1:nI, j in 1:nJ
        for i2 in 1:nI                                   # 给定 j 更新 i
            K1[idx(i, j), idx(i2, j)] = J[i2, j] / sum(J[:, j])
        end
        for j2 in 1:nJ                                   # 给定 i 更新 j
            K2[idx(i, j), idx(i, j2)] = J[i, j2] / sum(J[i, :])
        end
    end
    for (nm, Kx) in (("K₁（更新 i）", K1), ("K₂（更新 j）", K2))
        Fx = Diagonal(πv) * Kx
        push!(ok, check("Gibbs " * nm * "：π'K = π'", Kx' * πv, πv; tol=1e-14))
        push!(ok, check("Gibbs " * nm * "：细致平衡", Fx, Fx'; tol=1e-14))
    end
    Ks = K1 * K2
    Fs = Diagonal(πv) * Ks
    push!(ok, check("系统扫描 K₁K₂：π'K = π'（平稳性保持）", Ks' * πv, πv; tol=1e-14))
    @printf("系统扫描：‖diag(π)K − (diag(π)K)'‖ = %.4f（不为零：不可逆）\n", norm(Fs - Fs'))
    push!(ok, norm(Fs - Fs') > 1e-3)
    Kr = (K1 + K2) / 2
    Fr = Diagonal(πv) * Kr
    push!(ok, check("随机扫描 (K₁+K₂)/2：细致平衡", Fr, Fr'; tol=1e-14))
    push!(ok, check("系统扫描：K^100 的行 → π", (Ks^100)[1, :], πv; tol=1e-10))
end

# %% [markdown]
# ## 10　自检汇总

# %%
@printf("全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
all(ok) || println("失败的检查序号：", findall(!, ok))
