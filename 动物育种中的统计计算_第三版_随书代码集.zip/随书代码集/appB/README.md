# 附录 B　概率分布手册 —— 配套代码

**对应正文**：附录 B

## 文件

| 文件 | 说明 |
|:--|:--|
| `appB.ipynb` | IJulia 笔记本：13 个代码单元，约 315 行 Julia 代码，穿插与正文对应的说明 |
| `appB.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |

## 笔记本内容

- 1　检验工具
- 2　参数化陷阱与 $t$ 边际（式 B.1）
- 3　逆卡方的三种参数化与先验抽样检验（式 B.2–B.3）
- 4　多元分布（§B.4）
- 5　离散分布：条件二项法与 Walker 别名法（§B.5、§B.8）
- 6　随机数发生器（§B.7）
- 7　抽样算法（§B.8）
- 8　基于模拟的校准（SBC，§B.9）
- 9　马尔可夫链：非周期性与细致平衡（§B.10，式 B.5–B.6）
- 10　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl appB
```

或在 Jupyter 中打开 `appB/appB.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 本章没有单独的 Python 复核脚本：正文中的解析数值已在写作时用 Python 逐一复算。
