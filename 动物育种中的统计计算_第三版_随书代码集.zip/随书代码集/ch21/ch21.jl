# 本脚本由 tools/nb2jl.py 从同目录的 ch21.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 21

# %% [markdown]
# # 第二十一章　GBLUP 与基因组关系矩阵 —— 配套代码
#
# 本 Notebook 对应第二十一章。
#
# **内容**
#
# 1. 基因型数据的读取（含 PLINK `.bed` 二进制格式）
# 2. 三种 $\mathbf G$ 矩阵：**原理实现**与**优化实现**（分块 + 多线程 + BLAS）
# 3. 质量控制的完整流程
# 4. $\mathbf G$ 与 $\mathbf A_{22}$ 的调平（三种方案）
# 5. GBLUP 的求解与 back-solving
# 6. APY 算法与核心群规模的选择
# 7. 加权 GBLUP 与显性关系矩阵
# 8. 基准测试
#
# > **代码分层约定**：函数名以 `_naive` 结尾的是**原理介绍代码**，逐步对应正文公式，便于阅读；
# > 不带后缀的是**优化实现**，使用分块、BLAS、多线程与就地运算，面向生产规模。
# > 两者在每一节末尾都做数值一致性检查。

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Base.Threads

const BOOKSEED = 20260918
bookrng() = Xoshiro(BOOKSEED)
relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-10)
    e = relerr(a, b); @printf("%-50s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end

@printf("Julia %s ， 线程数 = %d ， BLAS 线程数 = %d\n",
        VERSION, nthreads(), BLAS.get_num_threads())

# %% [markdown]
# ## 1　基因型数据
#
# ### 1.1 模拟数据
#
# 为了让 Notebook 自包含，先用一个带系谱的简化模拟生成基因型。真实工作中请用 XSim.jl
# （含重组与漂变）或直接读取 PLINK 文件。

# %%
"""按系谱做配子传递的简化模拟：base 群体按 HWE 抽样，其后代按孟德尔规则传递。

为演示 LD，把 m 个标记排成 nchr 条染色体，染色体内相邻标记间重组率为 r。
"""
function sim_pedigree_genotypes(nbase::Int, ngen::Int, nper::Int, m::Int;
                                nchr::Int=10, r::Float64=0.02,
                                maf_min::Float64=0.05, rng=Random.default_rng())
    n = nbase + ngen*nper
    p0 = maf_min .+ (1 - 2maf_min) .* rand(rng, m)
    # 单倍型：n × m × 2
    H = Array{Int8,3}(undef, n, m, 2)
    @inbounds for i in 1:nbase, j in 1:m, k in 1:2
        H[i,j,k] = Int8(rand(rng) < p0[j])
    end
    sire = zeros(Int, n); dam = zeros(Int, n)
    mper = m ÷ nchr
    @inbounds for g in 1:ngen
        lo = nbase + (g-1)*nper + 1; hi = nbase + g*nper
        pool_hi = lo - 1
        for i in lo:hi
            s = rand(rng, 1:pool_hi); d = rand(rng, 1:pool_hi)
            while d == s; d = rand(rng, 1:pool_hi); end
            sire[i] = s; dam[i] = d
            for (par, k) in ((s,1), (d,2))
                for c in 1:nchr
                    cur = rand(rng, 1:2)
                    for jj in 1:mper
                        j = (c-1)*mper + jj
                        j > m && break
                        if jj > 1 && rand(rng) < r; cur = 3 - cur; end
                        H[i,j,k] = H[par,j,cur]
                    end
                end
            end
        end
    end
    Mg = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        Mg[i,j] = Float64(H[i,j,1]) + Float64(H[i,j,2])
    end
    return Mg, sire, dam
end

n_base, n_gen, n_per, m_snp = 200, 6, 300, 3000
Mg, sire, dam = sim_pedigree_genotypes(n_base, n_gen, n_per, m_snp; rng=Xoshiro(101))
n = size(Mg, 1)
@printf("个体数 n = %d ， 标记数 m = %d\n", n, m_snp)
@printf("基因型矩阵大小 = %.1f MB (Float64)\n", sizeof(Mg)/2^20)

# %% [markdown]
# ### 1.2 PLINK `.bed` 二进制格式的读取
#
# PLINK 1 的 `.bed`（SNP-major 模式）以 3 字节文件头 `0x6c 0x1b 0x01` 开始，之后每个 SNP 占 $\lceil n/4\rceil$ 字节，每字节依次存 4 个个体、每个 2 bit（**低位在前**），不足一字节的末尾补零。编码相对于 `.bim` 第 5、6 列的等位基因 A1、A2：
#
# | 编码 | 含义 | 本书读取为 |
# |---|---|---|
# | `00` | A1/A1 纯合 | 0 |
# | `01` | 缺失 | `NaN` |
# | `10` | A1/A2 杂合 | 1 |
# | `11` | A2/A2 纯合 | 2 |
#
# 即本书读取的是 **A2 的拷贝数**。PLINK 1.9 默认把次等位基因记为 A1，所以这里得到的通常是**主等位基因**拷贝数；而 `plink --recode A` 输出的是 A1（通常为次等位基因）的拷贝数——两者互为 $2-x$。这对中心化后的 $\mathbf G$ 没有影响（$\mathbf Z$ 只变号），但会改变标记效应的符号以及"$p$ 指哪个等位基因"的含义，与其他软件交换结果时必须核对。
#
# 下面给出读写实现并做往返测试。

# %%
const PLINK_MAGIC = UInt8[0x6c, 0x1b, 0x01]

"""把 0/1/2/缺失(-1) 的基因型矩阵写成 PLINK .bed（SNP-major）。"""
function write_bed(path::AbstractString, Mg::AbstractMatrix)
    n, m = size(Mg)
    nbyte = cld(n, 4)
    open(path, "w") do io
        write(io, PLINK_MAGIC)
        buf = zeros(UInt8, nbyte)
        for j in 1:m
            fill!(buf, 0x00)
            for i in 1:n
                g = Mg[i,j]
                code = g < 0      ? 0b01 :
                       g == 0     ? 0b00 :
                       g == 1     ? 0b10 : 0b11
                b, sh = fldmod(i-1, 4)
                buf[b+1] |= UInt8(code) << (2*sh)
            end
            write(io, buf)
        end
    end
    return path
end

"""读取 PLINK .bed，返回 n×m 的 Float64 矩阵，缺失编码为 NaN。"""
function read_bed(path::AbstractString, n::Int, m::Int)
    nbyte = cld(n, 4)
    Mg = Matrix{Float64}(undef, n, m)
    open(path, "r") do io
        hdr = read(io, 3)
        hdr == PLINK_MAGIC || error("不是 SNP-major 的 PLINK .bed 文件")
        buf = Vector{UInt8}(undef, nbyte)
        for j in 1:m
            readbytes!(io, buf, nbyte)
            @inbounds for i in 1:n
                b, sh = fldmod(i-1, 4)
                code = (buf[b+1] >> (2*sh)) & 0x03
                Mg[i,j] = code == 0b00 ? 0.0 :
                          code == 0b01 ? NaN :
                          code == 0b10 ? 1.0 : 2.0
            end
        end
    end
    return Mg
end

tmp = joinpath(tempdir(), "asc3_demo.bed")
write_bed(tmp, Mg)
Mg_rt = read_bed(tmp, n, m_snp)
check("PLINK .bed 往返一致", Mg_rt, Mg; tol=0)
@printf("文件大小 = %.2f MB  （Float64 内存的 1/%.0f）\n",
        filesize(tmp)/2^20, sizeof(Mg)/filesize(tmp))
rm(tmp; force=true)

# %% [markdown]
# ## 2　三种 $\mathbf G$ 矩阵
#
# - **方法 1**（VanRaden）：$\mathbf G_1=\dfrac{\mathbf{ZZ}'}{2\sum p_jq_j}$，正文式 (21.2)
# - **方法 2**（VanRaden）：$\mathbf G_2=\dfrac{\mathbf{WW}'}{m}$，$W_{ij}=\dfrac{M_{ij}-2p_j}{\sqrt{2p_jq_j}}$，正文式 (21.8)
# - **Yang / GCTA**：非对角同方法 2，对角用式 (21.11) 的无偏修正
#
# ### 2.1 原理实现

# %%
"""方法 1 的原理实现：逐元素照抄正文式 (21.2) 与 (21.6)。"""
function G_vanraden1_naive(Mg::AbstractMatrix, p::AbstractVector)
    n, m = size(Mg)
    s = 2*sum(p .* (1 .- p))
    G = zeros(n, n)
    for i in 1:n, k in 1:n
        acc = 0.0
        for j in 1:m
            acc += (Mg[i,j] - 2p[j]) * (Mg[k,j] - 2p[j])
        end
        G[i,k] = acc / s
    end
    return G
end

"""方法 2 的原理实现：正文式 (21.9)。"""
function G_vanraden2_naive(Mg::AbstractMatrix, p::AbstractVector)
    n, m = size(Mg)
    G = zeros(n, n)
    for i in 1:n, k in 1:n
        acc = 0.0
        for j in 1:m
            d = 2*p[j]*(1 - p[j])
            acc += (Mg[i,j] - 2p[j]) * (Mg[k,j] - 2p[j]) / d
        end
        G[i,k] = acc / m
    end
    return G
end

"""Yang/GCTA 的原理实现：非对角同方法 2，对角用正文式 (21.11)。"""
function G_yang_naive(Mg::AbstractMatrix, p::AbstractVector)
    n, m = size(Mg)
    G = G_vanraden2_naive(Mg, p)
    for i in 1:n
        acc = 0.0
        for j in 1:m
            pj = p[j]; d = 2*pj*(1-pj); x = Mg[i,j]
            acc += (x^2 - (1 + 2pj)*x + 2pj^2) / d
        end
        G[i,i] = 1 + acc/m
    end
    return G
end

# %% [markdown]
# ### 2.2 优化实现
#
# 三项优化：
#
# 1. **一次构造中心化矩阵 $\mathbf Z$**（或标准化矩阵 $\mathbf W$），再用 BLAS 的 `syrk`（`BLAS.syrk!`）做 $\mathbf{ZZ}'$——这是 Level-3 BLAS，能用满缓存与向量化；
# 2. **分块**：当 $m$ 很大、内存放不下 $n\times m$ 的 Float64 时，按标记分块累加；
# 3. **多线程**：块之间并行，每个线程有自己的累加缓冲，最后归约。
#
# 另外提供 **`Float32` 版本**——$\mathbf G$ 的元素量级在 1 附近，单精度足够构造（但**求逆与 MME 必须用双精度**）。

# %%
"""中心化（就地写入预分配缓冲）：Z[:, j] = M[:, j] - 2p[j]。"""
function center!(Z::AbstractMatrix{T}, Mg::AbstractMatrix, p::AbstractVector,
                 jrange) where {T}
    @inbounds for (jj, j) in enumerate(jrange)
        c = T(2*p[j])
        @simd for i in axes(Mg, 1)
            Z[i, jj] = T(Mg[i, j]) - c
        end
    end
    return Z
end

"""标准化：W[:, j] = (M[:, j] - 2p[j]) / sqrt(2 p q)。"""
function standardize!(W::AbstractMatrix{T}, Mg::AbstractMatrix, p::AbstractVector,
                      jrange) where {T}
    @inbounds for (jj, j) in enumerate(jrange)
        pj = p[j]; c = T(2*pj); sd = T(sqrt(2*pj*(1-pj)))
        @simd for i in axes(Mg, 1)
            W[i, jj] = (T(Mg[i, j]) - c) / sd
        end
    end
    return W
end

"""优化实现：分块 + 多线程 + BLAS.syrk! 构造交叉乘积 ZZ'。

`kind` 取 `:vr1` / `:vr2` / `:yang`。`blocksize` 控制每块的标记数。
"""
function grm(Mg::AbstractMatrix, p::AbstractVector; kind::Symbol=:vr1,
             blocksize::Int=1024, T::Type=Float64)
    n, m = size(Mg)
    blocks = [j:min(j+blocksize-1, m) for j in 1:blocksize:m]
    nt = min(nthreads(), length(blocks))
    partial = [zeros(T, n, n) for _ in 1:nt]
    bufs    = [Matrix{T}(undef, n, blocksize) for _ in 1:nt]

    # 每个任务固定处理一组块（步长划分），不依赖 threadid()，
    # 因为 Julia 1.9+ 的任务可能在线程间迁移。
    @threads for t in 1:nt
        Pt = partial[t]; Bt = bufs[t]
        for b in t:nt:length(blocks)
            jr = blocks[b]; w = length(jr)
            B = view(Bt, :, 1:w)
            kind === :vr1 ? center!(B, Mg, p, jr) : standardize!(B, Mg, p, jr)
            # Pt += B*B'  （只更新下三角，最后对称化）
            BLAS.syrk!('L', 'N', one(T), B, one(T), Pt)
        end
    end

    G = partial[1]
    for t in 2:nt; G .+= partial[t]; end
    @inbounds for i in 1:n-1, k in i+1:n; G[i,k] = G[k,i]; end

    if kind === :vr1
        G ./= T(2*sum(p .* (1 .- p)))
    else
        G ./= T(m)
    end
    Gd = Matrix{Float64}(G)
    if kind === :yang
        @inbounds for i in 1:n
            acc = 0.0
            for j in 1:m
                pj = p[j]; d = 2*pj*(1-pj); x = Mg[i,j]
                acc += (x^2 - (1 + 2pj)*x + 2pj^2) / d
            end
            Gd[i,i] = 1 + acc/m
        end
    end
    return Gd
end

# %%
# 等位基因频率（观测频率）
pfreq = vec(mean(Mg, dims=1)) ./ 2
# 过滤单态位点
keep = findall(j -> 0.01 < pfreq[j] < 0.99, 1:m_snp)
Mg2 = Mg[:, keep]; p2 = pfreq[keep]
@printf("过滤后标记数 = %d （剔除 %d 个 MAF < 0.01 的位点）\n", length(keep), m_snp - length(keep))

# 小规模上对比原理实现与优化实现
idx = 1:200
G1n = G_vanraden1_naive(Mg2[idx,:], p2)
G1o = grm(Mg2[idx,:], p2; kind=:vr1)
check("方法 1：原理实现 vs 优化实现", G1o, G1n; tol=1e-10)

G2n = G_vanraden2_naive(Mg2[idx,:], p2)
G2o = grm(Mg2[idx,:], p2; kind=:vr2)
check("方法 2：原理实现 vs 优化实现", G2o, G2n; tol=1e-10)

GYn = G_yang_naive(Mg2[idx,:], p2)
GYo = grm(Mg2[idx,:], p2; kind=:yang)
check("Yang  ：原理实现 vs 优化实现", GYo, GYn; tol=1e-10)

# 全规模
G1 = grm(Mg2, p2; kind=:vr1)
G2 = grm(Mg2, p2; kind=:vr2)
GY = grm(Mg2, p2; kind=:yang)

@printf("\n%-12s%-14s%-14s%-14s\n", "矩阵", "对角均值", "非对角均值", "全元素和")
for (nm, GG) in (("VanRaden1", G1), ("VanRaden2", G2), ("Yang", GY))
    od = (sum(GG) - sum(diag(GG))) / (n*(n-1))
    @printf("%-12s%-14.4f%-14.4f%-14.3e\n", nm, mean(diag(GG)), od, sum(GG))
end
println("\n=> 用观测频率中心化时 Σ_ik G_ik ≈ 0（正文式 21.15–21.16），")
println("   故非对角均值必为负，约为 -mean(diag)/(n-1) = ",
        round(-mean(diag(G1))/(n-1), digits=5))

# %% [markdown]
# ### 2.3 性能基准

# %%
function bench_grm(Mg, p; reps=2)
    n, m = size(Mg)
    t_naive = NaN
    if n <= 400
        t_naive = minimum(@elapsed(G_vanraden1_naive(Mg, p)) for _ in 1:reps)
    end
    t_blas  = minimum(@elapsed(grm(Mg, p; kind=:vr1, T=Float64)) for _ in 1:reps)
    t_f32   = minimum(@elapsed(grm(Mg, p; kind=:vr1, T=Float32)) for _ in 1:reps)
    return t_naive, t_blas, t_f32
end

println("构造 G 的耗时（秒）\n")
@printf("%-16s%-14s%-14s%-14s%-10s\n", "规模 n×m", "原理实现", "优化(F64)", "优化(F32)", "加速比")
for nn in (200, 400, 800, n)
    sub = 1:min(nn, n)
    tn, tb, tf = bench_grm(Mg2[sub,:], p2)
    sp = isnan(tn) ? NaN : tn/tb
    @printf("%-16s%-14s%-14.4f%-14.4f%-10s\n",
            "$(length(sub))×$(size(Mg2,2))",
            isnan(tn) ? "—" : @sprintf("%.4f", tn), tb, tf,
            isnan(sp) ? "—" : @sprintf("%.1f×", sp))
end
println("\n注：优化实现的复杂度仍是 O(n²m)，但常数因子小 1–2 个数量级，")
println("    原因是 BLAS Level-3 的分块与向量化。F32 再快约 1.5–2×。")

# %% [markdown]
# ## 3　质量控制
#
# 按正文 §21.4.1 的顺序执行，并给出系谱—基因组一致性诊断（正文式 21.58）。

# %%
"""正文 §21.4.1 的质控流程。返回保留的 (个体索引, 标记索引) 与报告。"""
function qc_genotypes(Mg::AbstractMatrix;
                      snp_callrate=0.95, ind_callrate=0.90,
                      maf_min=0.01, hwe_p=1e-6)
    n, m = size(Mg)
    miss = isnan.(Mg)
    rep = String[]

    # 1. SNP 检出率
    cr_snp = 1 .- vec(sum(miss, dims=1)) ./ n
    keep_j = findall(>=(snp_callrate), cr_snp)
    push!(rep, @sprintf("SNP 检出率 < %.2f          剔除 %d", snp_callrate, m - length(keep_j)))

    # 2. 个体检出率
    cr_ind = 1 .- vec(sum(miss[:, keep_j], dims=2)) ./ length(keep_j)
    keep_i = findall(>=(ind_callrate), cr_ind)
    push!(rep, @sprintf("个体检出率 < %.2f          剔除 %d", ind_callrate, n - length(keep_i)))

    # 3. MAF
    sub = Mg[keep_i, keep_j]
    pj = [mean(skipnan(view(sub, :, j)))/2 for j in axes(sub,2)]
    ok_maf = findall(j -> maf_min < pj[j] < 1 - maf_min, eachindex(pj))
    push!(rep, @sprintf("MAF < %.3f                剔除 %d", maf_min, length(keep_j) - length(ok_maf)))
    keep_j = keep_j[ok_maf]; pj = pj[ok_maf]; sub = Mg[keep_i, keep_j]

    # 4. HWE 精确检验（第七章）
    pvals = [hwe_exact_p(count_geno(view(sub, :, j))...) for j in axes(sub,2)]
    ok_hwe = findall(>=(hwe_p), pvals)
    push!(rep, @sprintf("HWE p < %.0e             剔除 %d", hwe_p, length(keep_j) - length(ok_hwe)))
    keep_j = keep_j[ok_hwe]

    return keep_i, keep_j, rep
end

skipnan(v) = (x for x in v if !isnan(x))

"""统计一列基因型的 (n_AA, n_Aa, n_aa)。"""
function count_geno(v)
    a = b = c = 0
    for x in v
        isnan(x) && continue
        x == 2 ? (a += 1) : x == 1 ? (b += 1) : (c += 1)
    end
    return a, b, c
end

"""Hardy–Weinberg 精确检验（Wigginton 等 2005），返回双侧 p 值。第七章已详述。"""
function hwe_exact_p(nAA::Int, nAa::Int, naa::Int)
    n = nAA + nAa + naa
    n == 0 && return 1.0
    nA = 2nAA + nAa
    na = 2n - nA
    (nA == 0 || na == 0) && return 1.0
    # 以 log 概率枚举所有可能的杂合子数
    lognum(h) = begin
        hAA = (nA - h) ÷ 2; haa = (na - h) ÷ 2
        (hAA < 0 || haa < 0) && return -Inf
        # log P(N_Aa = h | n, nA) = log n! - log(hAA! h! haa!) + h log2 + log(nA! na!) - log(2n)!
        lfact(n) - lfact(hAA) - lfact(h) - lfact(haa) + h*log(2.0) +
        lfact(nA) + lfact(na) - lfact(2n)
    end
    hs = [h for h in (nA % 2):2:min(nA, na)]
    lp = [lognum(h) for h in hs]
    mx = maximum(lp)
    w  = exp.(lp .- mx); w ./= sum(w)
    pobs = w[findfirst(==(nAa), hs)]
    return min(1.0, sum(w[w .<= pobs * (1 + 1e-9)]))
end

"""对数阶乘 log(k!)，带记忆化累加表，避免重复 O(k) 求和。"""
const _LFACT = Ref(Float64[0.0])
function lfact(k::Int)
    k <= 1 && return 0.0
    tbl = _LFACT[]
    if length(tbl) < k + 1
        old = length(tbl)
        resize!(tbl, k + 1)
        @inbounds for i in old:k
            tbl[i+1] = tbl[i] + log(i)
        end
    end
    return @inbounds tbl[k+1]
end

# 人为注入一些缺失与坏位点做演示
Mq = copy(Mg)
rngq = Xoshiro(202)
for j in 1:30, i in 1:n                      # 30 个低检出率位点
    rand(rngq) < 0.3 && (Mq[i,j] = NaN)
end
for i in 1:5, j in 1:m_snp                   # 5 个低检出率个体
    rand(rngq) < 0.25 && (Mq[i,j] = NaN)
end

ki, kj, rep = qc_genotypes(Mq)
println("质控报告\n" * "-"^44)
for r in rep; println("  ", r); end
@printf("\n保留个体 %d / %d ， 保留标记 %d / %d\n", length(ki), n, length(kj), m_snp)

# %% [markdown]
# ### 3.2 系谱—基因组一致性诊断（正文式 21.58）

# %%
"""用系谱递推构造 A（第九章）。"""
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

"""正文式 (21.58)：标记 |G_ik - A_ik| > thr 且 A_ik ≥ amin 的可疑个体对。"""
function pedigree_genomic_check(G::AbstractMatrix, A::AbstractMatrix;
                                thr=0.25, amin=0.25)
    n = size(G,1); out = NTuple{4,Any}[]
    @inbounds for i in 1:n-1, k in i+1:n
        if A[i,k] >= amin && abs(G[i,k] - A[i,k]) > thr
            push!(out, (i, k, A[i,k], G[i,k]))
        end
    end
    return out
end

A = build_A(sire, dam)
susp = pedigree_genomic_check(G1, A)
@printf("可疑个体对数 = %d （占 A_ik ≥ 0.25 的对数的 %.2f%%）\n",
        length(susp), 100*length(susp)/max(1, count(x -> x >= 0.25, [A[i,k] for i in 1:n-1 for k in i+1:n])))

# 整体一致性：G 的非对角元对 A 的非对角元回归
offG = Float64[]; offA = Float64[]
for i in 1:n-1, k in i+1:n
    push!(offG, G1[i,k]); push!(offA, A[i,k])
end
bhat = cov(offA, offG) / var(offA)
ahat = mean(offG) - bhat*mean(offA)
@printf("\nG_ik = a + b·A_ik 回归：a = %.4f ， b = %.4f ， R² = %.3f\n",
        ahat, bhat, cor(offA, offG)^2)
println("（b 远离 1 提示系谱错误、群体分层或频率基准问题——见正文 §23.2.3 步骤 3）")

# 人为制造一个系谱错误看诊断是否灵敏
sire_bad = copy(sire); sire_bad[n] = 1
A_bad = build_A(sire_bad, dam)
@printf("\n人为把个体 %d 的父亲改错后：\n", n)
@printf("  真系谱 A[%d, %d] = %.3f ， G = %.3f\n", n, sire[n], A[n, sire[n]], G1[n, sire[n]])
@printf("  错系谱 A[%d, 1] = %.3f ， G = %.3f  → 差值 %.3f （应被式 21.58 捕获）\n",
        n, A_bad[n,1], G1[n,1], abs(G1[n,1] - A_bad[n,1]))

# %% [markdown]
# ## 4　$\mathbf G$ 与 $\mathbf A_{22}$ 的调平（正文 §21.1.5、§23.2.3）
#
# 三种方案：
#
# 1. **均值匹配**：$\mathbf G^*=\alpha\mathbf J+\beta\mathbf G$，式 (23.17)
# 2. **混合**：$\mathbf G_w=(1-w)\mathbf G^*+w\mathbf A_{22}$，式 (23.18)
# 3. **回归调平**：把 $\mathbf G$ 的元素对 $\mathbf A_{22}$ 回归后变换

# %%
"""正文式 (23.17)：均值匹配调平，返回 (G*, α, β)。"""
function tune_meanmatch(G::AbstractMatrix, A22::AbstractMatrix)
    gd = mean(diag(G));  ga = mean(G)
    ad = mean(diag(A22)); aa = mean(A22)
    beta  = (ad - aa) / (gd - ga)
    alpha = aa - beta*ga
    return alpha .+ beta .* G, alpha, beta
end

"""正文式 (23.18)：与 A22 混合。"""
blend(Gstar::AbstractMatrix, A22::AbstractMatrix, w::Float64) =
    (1-w) .* Gstar .+ w .* A22

"""回归调平：G_ik = a + b A_ik，取 G* = (G - a)/b。"""
function tune_regression(G::AbstractMatrix, A22::AbstractMatrix)
    n = size(G,1)
    x = Float64[]; y = Float64[]
    for i in 1:n, k in 1:n
        push!(x, A22[i,k]); push!(y, G[i,k])
    end
    b = cov(x,y)/var(x); a = mean(y) - b*mean(x)
    return (G .- a) ./ b, a, b
end

geno_idx = collect((n - 900):n)           # 假设最后 901 头有基因型
A22 = A[geno_idx, geno_idx]
Gsub = G1[geno_idx, geno_idx]

Gstar, al, be = tune_meanmatch(Gsub, A22)
Gw = blend(Gstar, A22, 0.05)
Greg, ar, br = tune_regression(Gsub, A22)

@printf("均值匹配：α = %+.4f ， β = %.4f\n", al, be)
@printf("回归调平：a = %+.4f ， b = %.4f\n", ar, br)

@printf("\n%-16s%-14s%-14s%-14s\n", "矩阵", "对角均值", "全元素均值", "非对角均值")
for (nm, MM) in (("A22", A22), ("G(原始)", Gsub), ("G*(均值匹配)", Gstar),
                 ("G_w(w=0.05)", Gw), ("G(回归调平)", Greg))
    nn = size(MM,1); od = (sum(MM) - sum(diag(MM)))/(nn*(nn-1))
    @printf("%-16s%-14.4f%-14.4f%-14.4f\n", nm, mean(diag(MM)), mean(MM), od)
end
println("\n=> 均值匹配后 G* 的两个矩与 A22 精确相符（这是构造条件）；")
println("   混合会把它们稍稍拉回 A22；回归调平匹配的是元素级回归而非均值。")

# 奇异性检查
ev = eigvals(Symmetric(Gsub))
@printf("\nG 的最小特征值 = %.3e ，  条件数 = %.3e （奇异！）\n",
        minimum(ev), maximum(ev)/max(minimum(ev), eps()))
evw = eigvals(Symmetric(Gw))
@printf("G_w 的最小特征值 = %.4f ，  条件数 = %.1f （已正定）\n",
        minimum(evw), maximum(evw)/minimum(evw))

# %% [markdown]
# ## 5　GBLUP 的求解与 back-solving

# %%
"""GBLUP：解 MME，返回 (β̂, ĝ, ê, C⁻¹ 的遗传块对角元)。"""
function gblup_solve(y, X, G, lam)
    n_ = length(y); p_ = size(X,2)
    Gi = inv(cholesky(Symmetric(G)))
    C  = [X'X   X';
          X     I + lam*Gi]
    Cinv = inv(C)
    sol  = Cinv * [X'y; y]
    b = sol[1:p_]; g = sol[p_+1:end]
    Cgg = diag(Cinv)[p_+1:end]
    return b, g, y - X*b - g, Cgg
end

"""正文式 (21.26)：可靠性（注意分母的 G_ii）。"""
reliability(Cgg::Vector, G::AbstractMatrix, lam::Float64) =
    1 .- (Cgg .* lam) ./ diag(G)

# 模拟表型
ng = length(geno_idx)
s2A_ = 1.0; h2_ = 0.35; s2e_ = s2A_*(1-h2_)/h2_
Lg = cholesky(Symmetric(Gw)).L
g_true = Lg * randn(Xoshiro(303), ng) .* sqrt(s2A_)
X_ = ones(ng, 1)
y_ = 100.0 .+ g_true .+ randn(Xoshiro(304), ng) .* sqrt(s2e_)
lam_ = s2e_ / s2A_

bh, gh, eh, Cgg = gblup_solve(y_, X_, Gw, lam_)
rel = reliability(Cgg, Gw, lam_)
rel_wrong = 1 .- Cgg .* lam_          # 第二版的错误写法（漏掉 G_ii）

@printf("β̂ = %.3f （真值 100）\n", bh[1])
@printf("cor(ĝ, g_true) = %.4f\n", cor(gh, g_true))
@printf("平均可靠性（正确，式 21.26）   = %.4f\n", mean(rel))
@printf("平均可靠性（第二版错误写法）   = %.4f\n", mean(rel_wrong))
hi = argmax(diag(Gw))
@printf("\n最近交个体 #%d： G_ii = %.3f\n", hi, Gw[hi,hi])
@printf("  正确可靠性 = %.4f ， 错误写法 = %.4f ， 低估 %.1f%%\n",
        rel[hi], rel_wrong[hi], 100*(1 - rel_wrong[hi]/rel[hi]))

# %%
# back-solving：正文式 (21.29) 与式 (21.31)
Zc = Mg2[geno_idx, :] .- 2 .* p2'
sv2 = 2*sum(p2 .* (1 .- p2))
alpha_a = (Zc' * (inv(cholesky(Symmetric(Gw))) * gh)) ./ sv2   # 式 (21.29)，需求逆
alpha_b = (Zc' * eh) ./ (lam_ * sv2)                           # 式 (21.31)，免求逆

check("back-solving 式 (21.29) vs 式 (21.31)", alpha_b, alpha_a; tol=1e-6)
check("Zα̂ 复原 ĝ",                              Zc*alpha_a, gh; tol=1e-6)

# 计时对比
t1 = @elapsed (Zc' * (inv(cholesky(Symmetric(Gw))) * gh)) ./ sv2
t2 = @elapsed (Zc' * eh) ./ (lam_ * sv2)
@printf("\n式 (21.29) 耗时 %.4f s ；式 (21.31) 耗时 %.4f s ； 加速 %.1f×\n", t1, t2, t1/t2)

# 位点解释方差与"曼哈顿"风格排序
varexp = (alpha_b .^ 2) .* (2 .* p2 .* (1 .- p2))
ord = sortperm(varexp; rev=true)
println("\n解释方差最大的 5 个标记：")
for j in ord[1:5]
    @printf("  标记 %5d ： α̂ = %+.5f ， 2pq α̂² = %.3e （占总数的 %.2f%%）\n",
            j, alpha_b[j], varexp[j], 100*varexp[j]/sum(varexp))
end

# %% [markdown]
# ## 6　APY 算法（正文式 21.32–21.38）

# %%
"""正文式 (21.35)：APY 的 G⁻¹。返回稠密矩阵（用于验证）。

`core` 是核心个体的索引；其余为非核心。
"""
function apy_inverse(G::AbstractMatrix, core::Vector{Int})
    n = size(G,1)
    noncore = setdiff(1:n, core)
    Gcc = G[core, core]; Gnc = G[noncore, core]
    Fcc = cholesky(Symmetric(Gcc))
    Gcci = inv(Fcc)
    P = Gnc * Gcci                                  # 式 (21.32)
    mii = [G[i,i] - dot(view(P, k, :), view(G, core, i)) for (k,i) in enumerate(noncore)]
    mii .= max.(mii, 1e-8)                          # 数值保护
    Mi = Diagonal(1 ./ mii)

    Gi = zeros(n, n)
    Gi[core, core]       .= Gcci .+ P' * Mi * P
    Gi[core, noncore]    .= .-(P' * Mi)
    Gi[noncore, core]    .= .-(Mi * P)
    Gi[noncore, noncore] .= Matrix(Mi)
    return Gi, mii
end

"""APY 的稀疏算子形式：返回一个计算 G⁻¹v 的闭包，成本 O(n·nc)。"""
function apy_operator(G::AbstractMatrix, core::Vector{Int})
    n = size(G,1); noncore = setdiff(1:n, core)
    Gcci = inv(cholesky(Symmetric(G[core, core])))
    P = G[noncore, core] * Gcci
    mii = [G[i,i] - dot(view(P, k, :), view(G, core, i)) for (k,i) in enumerate(noncore)]
    mii .= max.(mii, 1e-8)
    return function (v::AbstractVector)
        vc = view(v, core); vn = view(v, noncore)
        tn  = vn ./ mii                     # M⁻¹ v_n
        Pvc = P * vc
        out = similar(v)
        out[core]    .= Gcci*vc .+ P'*(Pvc ./ mii) .- P'*tn
        out[noncore] .= tn .- (Pvc ./ mii)
        return out
    end
end

# 特征值谱与"有效维数"
evG = sort(eigvals(Symmetric(Gw)); rev=true)
cum = cumsum(evG) ./ sum(evG)
k98 = findfirst(>=(0.98), cum); k99 = findfirst(>=(0.99), cum)
@printf("G 的特征值谱： n = %d\n", size(Gw,1))
@printf("  解释 98%% 方差需要 %d 个特征值\n", k98)
@printf("  解释 99%% 方差需要 %d 个特征值\n", k99)
@printf("  理论 Me（Ne 由模拟决定，此处取 Ne≈%d，L≈1 M）≈ %.0f\n",
        2*n_base, 2*2*n_base*1.0/log(4*2*n_base*1.0))

# %%
# APY 的精度随核心群规模的变化
println("核心群规模对 APY 精度的影响（核心个体随机选取）\n")
@printf("%-10s%-18s%-18s%-14s\n", "n_core", "cor(ĝ_APY, ĝ_full)", "max|Δĝ|/sd(ĝ)", "G⁻¹ 相对误差")
Gfull_inv = inv(cholesky(Symmetric(Gw)))
for nc in (50, 100, 200, 400, 600, size(Gw,1))
    core = sort(randperm(Xoshiro(500+nc), size(Gw,1))[1:nc])
    Gi_apy, _ = apy_inverse(Gw, core)
    # 用 APY 的 G⁻¹ 重解 GBLUP
    C = [X_'X_   X_';
         X_      I + lam_*Gi_apy]
    sol = C \ [X_'y_; y_]
    g_apy = sol[2:end]
    @printf("%-10d%-18.6f%-18.4f%-14.3e\n", nc,
            cor(g_apy, gh), maximum(abs.(g_apy .- gh))/std(gh),
            relerr(Gi_apy, Gfull_inv))
end
println("\n=> 核心群达到 98% 方差对应的维数（约 $(k98)）之后，")
println("   GEBV 与完整 GBLUP 的相关超过 0.999（正文式 21.38）。")

# %% [markdown]
# ## 7　加权 GBLUP 与显性关系矩阵

# %%
"""正文式 (21.39)：加权 G（迹标准化）。"""
function grm_weighted(Mg::AbstractMatrix, p::AbstractVector, w::AbstractVector)
    Z = Mg .- 2 .* p'
    ZD = Z .* sqrt.(w)'
    G = ZD*ZD'
    return G .* (size(G,1) / tr(G))
end

"""正文式 (21.40)：VanRaden 的非线性权重 nonlinearA。"""
function weights_nonlinearA(alpha::AbstractVector; base=1.125, floor_=0.1)
    s = std(alpha)
    return max.(base .^ (abs.(alpha) ./ s .- 2), floor_)
end

"""迭代加权 GBLUP：正文 §21.3.1。niter 建议 ≤ 3。"""
function wgblup(y, X, Mg, p, lam; niter=2, wfun=:square)
    n_ = size(Mg,1); m_ = size(Mg,2)
    w = ones(m_); s = 2*sum(p .* (1 .- p))
    local b, g, e, Gk
    for t in 0:niter
        Gk = t == 0 ? (let Z = Mg .- 2 .* p'; Z*Z' ./ s end) : grm_weighted(Mg, p, w)
        Gk = 0.95 .* Gk .+ 0.05 .* Matrix(I, n_, n_)
        b, g, e, _ = gblup_solve(y, X, Gk, lam)
        a = ((Mg .- 2 .* p')' * e) ./ (lam * s)
        w = wfun === :square ? (a.^2 .* (2 .* p .* (1 .- p))) : weights_nonlinearA(a)
        w .*= m_/sum(w)
    end
    return b, g, w
end

_, g_w2, wts = wgblup(y_, X_, Mg2[geno_idx,:], p2, lam_; niter=2, wfun=:square)
_, g_wn, wtn = wgblup(y_, X_, Mg2[geno_idx,:], p2, lam_; niter=2, wfun=:nonlinear)
@printf("GBLUP           ： cor(ĝ, g_true) = %.4f\n", cor(gh,   g_true))
@printf("WGBLUP(平方权重)： cor(ĝ, g_true) = %.4f   权重范围 [%.2e, %.2e]\n",
        cor(g_w2, g_true), minimum(wts), maximum(wts))
@printf("WGBLUP(nonlinA) ： cor(ĝ, g_true) = %.4f   权重范围 [%.2f, %.2f]\n",
        cor(g_wn, g_true), minimum(wtn), maximum(wtn))
println("\n=> 本例的遗传结构是纯多基因（所有标记效应同分布），")
println("   因此加权不带来增益——与正文 §21.3.1 的结论一致。")

# %%
"""正文式 (21.44)、(21.47)：显性编码与显性关系矩阵。"""
function dominance_matrix(Mg::AbstractMatrix, p::AbstractVector)
    n, m = size(Mg); q = 1 .- p
    Wd = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        g = Mg[i,j]
        Wd[i,j] = g == 2 ? -2*q[j]^2 : g == 1 ? 2*p[j]*q[j] : -2*p[j]^2
    end
    return (Wd*Wd') ./ sum((2 .* p .* q).^2), Wd
end

D, Wd = dominance_matrix(Mg2, p2)
Zc_all = Mg2 .- 2 .* p2'

# 验证正文式 (21.45)、(21.46) 与加性—显性正交性
j = 7
@printf("位点 %d （p = %.3f）：\n", j, p2[j])
@printf("  E(W^d)      = %+.3e  （理论 0，式 21.45）\n", mean(view(Wd,:,j)))
@printf("  Var(W^d)    = %.5f   （理论 (2pq)² = %.5f，式 21.46）\n",
        var(view(Wd,:,j); corrected=false), (2*p2[j]*(1-p2[j]))^2)
@printf("  Cov(Z, W^d) = %+.3e  （理论 0，加性—显性正交）\n",
        cov(view(Zc_all,:,j), view(Wd,:,j); corrected=false))
@printf("\nD 的对角均值 = %.4f ， 非对角均值 = %+.5f\n",
        mean(diag(D)), (sum(D) - sum(diag(D)))/(size(D,1)*(size(D,1)-1)))

# 上位关系矩阵（式 21.49）
GAA = (G1 .* G1); GAA .*= size(GAA,1)/tr(GAA)
GAD = (G1 .* D);  GAD .*= size(GAD,1)/tr(GAD)
@printf("G_AA 对角均值 = %.4f ，  G_AD 对角均值 = %.4f\n", mean(diag(GAA)), mean(diag(GAD)))

# %% [markdown]
# ## 8　自检汇总

# %%
ok = Bool[]
push!(ok, check("方法1 原理 vs 优化", grm(Mg2[1:150,:], p2; kind=:vr1),
                G_vanraden1_naive(Mg2[1:150,:], p2); tol=1e-10))
push!(ok, check("方法2 原理 vs 优化", grm(Mg2[1:150,:], p2; kind=:vr2),
                G_vanraden2_naive(Mg2[1:150,:], p2); tol=1e-10))
push!(ok, check("back-solving 两式一致", alpha_a, alpha_b; tol=1e-6))
push!(ok, check("Zα̂ = ĝ",              Zc*alpha_b, gh; tol=1e-6))
push!(ok, check("APY(全核心) = 完整 G⁻¹",
                apy_inverse(Gw, collect(1:size(Gw,1)))[1], inv(cholesky(Symmetric(Gw))); tol=1e-8))
gd_ = mean(diag(Gstar)); ad_ = mean(diag(A22))
push!(ok, check("均值匹配：对角均值相等", gd_, ad_; tol=1e-12))
push!(ok, check("均值匹配：全元素均值相等", mean(Gstar), mean(A22); tol=1e-12))
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
