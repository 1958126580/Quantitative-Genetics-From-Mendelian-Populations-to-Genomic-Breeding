# 第二十一章　GBLUP 与基因组关系矩阵 —— 配套代码

**所属**：第五篇　基因组选择与基因组预测　　**对应正文**：第二十一章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch21.ipynb` | IJulia 笔记本：17 个代码单元，约 693 行 Julia 代码，穿插与正文对应的说明 |
| `ch21.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |

## 笔记本内容

- 1　基因型数据
  - 1.1 模拟数据
  - 1.2 PLINK `.bed` 二进制格式的读取
- 2　三种 $\mathbf G$ 矩阵
  - 2.1 原理实现
  - 2.2 优化实现
  - 2.3 性能基准
- 3　质量控制
  - 3.2 系谱—基因组一致性诊断（正文式 21.58）
- 4　$\mathbf G$ 与 $\mathbf A_{22}$ 的调平（正文 §21.1.5、§23.2.3）
- 5　GBLUP 的求解与 back-solving
- 6　APY 算法（正文式 21.32–21.38）
- 7　加权 GBLUP 与显性关系矩阵
- 8　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 21
```

或在 Jupyter 中打开 `ch21/ch21.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 本章没有单独的 Python 复核脚本：正文中的解析数值已在写作时用 Python 逐一复算。
