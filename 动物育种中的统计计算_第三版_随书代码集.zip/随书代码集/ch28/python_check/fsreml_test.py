# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 28 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 fsreml_test.py    依赖：numpy
import numpy as np, time
from fsreml import FSREML
from reml import reml
rng=np.random.default_rng(11)
n,p,q=600,300,80
X=rng.binomial(2,rng.uniform(0.05,0.5,p),(n,p)).astype(float); X=(X-X.mean(0))/X.std(0)/np.sqrt(p)
T=rng.standard_normal((n,q))/np.sqrt(q)
y=2+X@rng.normal(0,np.sqrt(0.4),p)+T@rng.normal(0,np.sqrt(0.2),q)+rng.normal(0,np.sqrt(0.5),n)
t=time.time(); m=FSREML([X,T],y).fit(); print('FS-REML',m.s2,'%.2fs'%(time.time()-t))
Xc=X-X.mean(0); Tc=T-T.mean(0)
t=time.time(); r=reml(y,np.ones((n,1)),[X@X.T,T@T.T]); print('n-space AI-REML',r['theta'],'%.2fs'%(time.time()-t))
print('loglik diff check: FS ll=%.6f'%m.ll)
# BLUP agreement
th=r['theta']; V=th[0]*X@X.T+th[1]*T@T.T+th[2]*np.eye(n)
Py=r['Py']; g_dual=th[0]*X@(X.T@Py); 
Fs=[X,T]; g_primal=(X-m.mu_F[0])@m.u[:p]
print('max |BLUP diff| (G part):',np.max(np.abs((g_dual-g_dual.mean())-(g_primal-g_primal.mean()))))
