# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 28 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 mr.py    依赖：numpy, scipy
import numpy as np
from scipy import stats
def ivw(bx,by,sy):
    w=1/sy**2; b=np.sum(w*bx*by)/np.sum(w*bx*bx)
    se=np.sqrt(1/np.sum(w*bx*bx))
    Q=np.sum(w*(by-b*bx)**2); J=len(bx)
    se_re=se*max(1,np.sqrt(Q/(J-1)))
    return b,se_re,Q
def egger(bx,by,sy):
    s=np.sign(bx); bx=bx*s; by=by*s
    w=1/sy**2; X=np.column_stack([np.ones_like(bx),bx]); W=np.diag(w)
    XtWX=X.T@W@X; beta=np.linalg.solve(XtWX,X.T@W@by)
    res=by-X@beta; J=len(bx); sig2=max(1,np.sum(w*res**2)/(J-2))
    cov=np.linalg.inv(XtWX)*sig2
    return beta[1],np.sqrt(cov[1,1]),beta[0],np.sqrt(cov[0,0])
def wmedian(bx,by,sy):
    r=by/bx; w=(bx/sy)**2; o=np.argsort(r); r=r[o]; w=w[o]/w.sum()
    cum=np.cumsum(w)-0.5*w
    return np.interp(0.5,cum,r)
def sim(scen,beta,rng,J=30):
    gam=rng.uniform(0.03,0.10,J); sx=np.full(J,0.01); sy=np.full(J,0.01)
    alpha=np.zeros(J)
    if scen=='balanced': alpha=rng.normal(0,0.02,J)
    if scen=='directional': alpha=rng.uniform(0,0.03,J)            # InSIDE holds (independent of gamma)
    if scen=='40pct_invalid':
        k=int(0.4*J); inv=rng.choice(J,k,replace=False); alpha[inv]=rng.uniform(0.01,0.04,k)
    bx=gam+rng.normal(0,sx); by=beta*gam+alpha+rng.normal(0,sy)
    return bx,by,sy
rng=np.random.default_rng(28028)
R=2000
for beta in (0.3,0.0):
  print('==== true beta =',beta)
  for scen in ('valid','balanced','directional','40pct_invalid'):
    est={'IVW':[], 'Egger':[], 'WMed':[]}; cov={'IVW':0,'Egger':0}; rej={'IVW':0,'Egger':0,'EggerInt':0}
    for r in range(R):
        bx,by,sy=sim(scen,beta,rng)
        b,se,Q=ivw(bx,by,sy); est['IVW'].append(b)
        cov['IVW']+= abs(b-beta)<=1.96*se; rej['IVW']+= abs(b)>1.96*se
        be,see,ie,sie=egger(bx,by,sy); est['Egger'].append(be)
        cov['Egger']+= abs(be-beta)<=stats.t.ppf(0.975,28)*see; rej['Egger']+= abs(be)>stats.t.ppf(0.975,28)*see
        rej['EggerInt']+= abs(ie)>stats.t.ppf(0.975,28)*sie
        est['WMed'].append(wmedian(bx,by,sy))
    line=f'{scen:14s} '
    for k in ('IVW','Egger','WMed'):
        a=np.array(est[k]); line+=f'{k}: mean={a.mean():.4f} sd={a.std():.4f}  '
    line+=f"cov IVW={cov['IVW']/R:.3f} Egger={cov['Egger']/R:.3f}  rej0 IVW={rej['IVW']/R:.3f} Egger={rej['Egger']/R:.3f} EggerInt={rej['EggerInt']/R:.3f}"
    print(line)
