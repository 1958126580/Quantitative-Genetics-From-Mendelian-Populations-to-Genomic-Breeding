# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 28 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 reml_test.py    依赖：numpy, scipy
import numpy as np, time
from reml import reml
from scipy.optimize import minimize_scalar
rng=np.random.default_rng(7)
n,p=800,1500
Xg=rng.binomial(2,rng.uniform(0.05,0.5,p),(n,p)).astype(float); Xg=(Xg-Xg.mean(0))/Xg.std(0)
G=Xg@Xg.T/p
g=Xg@rng.normal(0,np.sqrt(0.4/p),p); y=1.0+g+rng.normal(0,np.sqrt(0.6),n)
X=np.ones((n,1))
t=time.time(); r=reml(y,X,[G]); print('AI-REML',r['theta'],r['iters'],'iters %.2fs'%(time.time()-t))
# independent check: eigen-based REML profile over h2 (single component)
w,U=np.linalg.eigh(G); yt=U.T@y; Xt=U.T@X
def negll(h):
    d=h*w+(1-h)
    Xd=Xt/d[:,None]; b=np.linalg.solve(Xt.T@Xd, Xd.T@yt); res=yt-Xt@b
    s2=np.sum(res**2/d)/(n-1)
    return 0.5*(np.sum(np.log(d*s2))+np.log(np.linalg.det(Xt.T@Xd/s2))+(n-1))
o=minimize_scalar(negll,bounds=(1e-4,1-1e-4),method='bounded',options={'xatol':1e-10})
h=o.x; d=h*w+(1-h); Xd=Xt/d[:,None]; b=np.linalg.solve(Xt.T@Xd,Xd.T@yt); s2=np.sum((yt-Xt@b)**2/d)/(n-1)
print('eigen REML: sg2=%.6f se2=%.6f'%(h*s2,(1-h)*s2))
# two-component check: pen effect
Z=np.kron(np.eye(40),np.ones((20,1))); C=Z@Z.T
y2=y+Z@rng.normal(0,np.sqrt(0.3),40)
r2=reml(y2,X,[G,C]); print('2-comp',r2['theta'],r2['iters'])
