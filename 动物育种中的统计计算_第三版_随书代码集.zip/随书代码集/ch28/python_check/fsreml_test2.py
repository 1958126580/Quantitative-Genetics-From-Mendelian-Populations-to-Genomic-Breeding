# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 28 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 fsreml_test2.py    依赖：numpy, scipy
import numpy as np, time
from fsreml import FSREML
from reml import reml
from scipy.optimize import check_grad
rng=np.random.default_rng(11)
n,p,q=600,300,80
X=rng.binomial(2,rng.uniform(0.05,0.5,p),(n,p)).astype(float); X=(X-X.mean(0))/X.std(0)/np.sqrt(p)
T=rng.standard_normal((n,q))/np.sqrt(q)
y=2+X@rng.normal(0,np.sqrt(0.4),p)+T@rng.normal(0,np.sqrt(0.2),q)+rng.normal(0,np.sqrt(0.5),n)
m=FSREML([X,T],y)
x=np.log([0.3,0.1,0.6])
print('grad check (should be ~0):', check_grad(lambda v: m.negll_grad(v)[0], lambda v: m.negll_grad(v)[1], x))
t=time.time(); m.fit(); print('FS-REML',m.s2,'%.2fs'%(time.time()-t))
r=reml(y,np.ones((n,1)),[X@X.T,T@T.T]); print('dual AI-REML',r['theta'], 'll dual %.6f FS %.6f'%(r['ll'],m.ll))
