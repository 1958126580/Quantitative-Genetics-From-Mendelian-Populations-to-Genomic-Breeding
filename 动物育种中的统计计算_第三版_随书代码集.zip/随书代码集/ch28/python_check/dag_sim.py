# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 28 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 dag_sim.py    依赖：numpy, scipy
"""Sec 28.6: DAG, back-door criterion, collider bias. Linear-Gaussian SEM, n=20000, 1000 replicates.
H (pen/herd environment, observed) -> X (feed intake), H -> Y (daily gain); Z (genetic score) -> X;
X -> Y (beta); X -> C <- Y (collider: selection index); S = 1{C in top 30%}.
X = 0.5 Z + 0.6 H + eX (var .39);  Y = beta X + 0.5 H + eY (var sY2);  C = 0.6 X + 0.6 Y + eC (var .5)
Seeds 28601 (beta=0.3) and 28602 (beta=0)."""
import numpy as np, json
from scipy.stats import norm, t as tdist

def sem_cov(beta, sY2):
    # variables: Z, H, X, Y, C  as linear functions of independent (Z, H, eX, eY, eC)
    B = np.zeros((5, 5))
    # rows: Z,H,X,Y,C ; cols: Z,H,eX,eY,eC
    B[0] = [1, 0, 0, 0, 0]; B[1] = [0, 1, 0, 0, 0]
    B[2] = [0.5, 0.6, 1, 0, 0]
    B[3] = beta * B[2] + np.array([0, 0.5, 0, 1, 0])
    B[4] = 0.6 * B[2] + 0.6 * B[3] + np.array([0, 0, 0, 0, 1])
    D = np.diag([1, 1, 0.39, sY2, 0.5])
    return B @ D @ B.T

def ols_coef(S, yi, xs):
    Sxx = S[np.ix_(xs, xs)]; Sxy = S[xs, yi]
    return np.linalg.solve(Sxx, Sxy)

def select_cov(S, ci, prop):
    x = norm.ppf(1 - prop); i = norm.pdf(x) / prop; k = i * (i - x)
    return S - k * np.outer(S[:, ci], S[:, ci]) / S[ci, ci], k, i, x

Zi, Hi, Xi, Yi, Ci = range(5)
res = {}
for beta, seed in ((0.3, 28601), (0.0, 28602)):
    sY2 = 1 - (beta ** 2 + 0.25 + 2 * beta * 0.5 * 0.6)    # keeps Var(Y)=1
    S = sem_cov(beta, sY2)
    Ss, k, i, x = select_cov(S, Ci, 0.30)
    ana = dict(
        naive=ols_coef(S, Yi, [Xi])[0],
        backdoor=ols_coef(S, Yi, [Xi, Hi])[0],
        collider=ols_coef(S, Yi, [Xi, Hi, Ci])[0],
        selected=ols_coef(Ss, Yi, [Xi, Hi])[0],
        mr_full=S[Zi, Yi] / S[Zi, Xi],
        mr_selected=Ss[Zi, Yi] / Ss[Zi, Xi],
        corrZH_selected=Ss[Zi, Hi] / np.sqrt(Ss[Zi, Zi] * Ss[Hi, Hi]))
    # closed-form collider bias within H-strata: beta - kk (a + b beta), kk = b sY2/(b^2 sY2 + sC2)
    kk = 0.6 * sY2 / (0.36 * sY2 + 0.5)
    ana['collider_formula'] = beta - kk * (0.6 + 0.6 * beta)
    rng = np.random.default_rng(seed)
    n, R = 20000, 1000
    est = {kk_: [] for kk_ in ('naive', 'backdoor', 'collider', 'selected', 'mr_full', 'mr_selected')}
    cover = {kk_: 0 for kk_ in ('naive', 'backdoor', 'collider', 'selected')}
    rej = {kk_: 0 for kk_ in ('naive', 'backdoor', 'collider', 'selected', 'mr_full', 'mr_selected')}
    zh = []
    for r in range(R):
        Z = rng.standard_normal(n); H = rng.standard_normal(n)
        X = 0.5 * Z + 0.6 * H + rng.normal(0, np.sqrt(0.39), n)
        Y = beta * X + 0.5 * H + rng.normal(0, np.sqrt(sY2), n)
        C = 0.6 * X + 0.6 * Y + rng.normal(0, np.sqrt(0.5), n)
        sel = C > np.quantile(C, 0.70)
        def fit(yv, cols):
            A = np.column_stack([np.ones(len(yv))] + cols)
            coef, *_ = np.linalg.lstsq(A, yv, rcond=None)
            res_ = yv - A @ coef; s2 = res_ @ res_ / (len(yv) - A.shape[1])
            se = np.sqrt(s2 * np.linalg.inv(A.T @ A)[1, 1])
            return coef[1], se, len(yv) - A.shape[1]
        out = {'naive': fit(Y, [X]), 'backdoor': fit(Y, [X, H]), 'collider': fit(Y, [X, H, C]),
               'selected': fit(Y[sel], [X[sel], H[sel]])}
        for key, (bh, se, df) in out.items():
            est[key].append(bh); q = tdist.ppf(0.975, df)
            cover[key] += abs(bh - beta) <= q * se; rej[key] += abs(bh) > q * se
        for key, mask in (('mr_full', np.ones(n, bool)), ('mr_selected', sel)):
            zz, xx, yy = Z[mask], X[mask], Y[mask]
            bzx = np.cov(zz, xx)[0, 1] / zz.var(ddof=1); bzy = np.cov(zz, yy)[0, 1] / zz.var(ddof=1)
            # Wald ratio SE by delta method (first-order term)
            m_ = mask.sum()
            ry = yy - yy.mean() - bzy * (zz - zz.mean()); sey = np.sqrt(ry.var(ddof=2) / (m_ * zz.var(ddof=1)))
            wr = bzy / bzx; se_wr = sey / abs(bzx)
            est[key].append(wr); rej[key] += abs(wr) > 1.959963984540054 * se_wr
        zh.append(np.corrcoef(Z[sel], H[sel])[0, 1])
    sim = {kk_: dict(mean=float(np.mean(v)), sd=float(np.std(v))) for kk_, v in est.items()}
    res[str(beta)] = dict(analytic={a: float(b_) for a, b_ in ana.items()}, sim=sim,
                          cover={a: b_ / R for a, b_ in cover.items()}, rej={a: b_ / R for a, b_ in rej.items()},
                          corrZH_selected_sim=float(np.mean(zh)), k=k, i=i, x=x, sY2=sY2, n_sel=int(0.3 * n))
    print(json.dumps(res[str(beta)], indent=1))
json.dump(res, open('dag_sim.json', 'w'), indent=1)
