# 第 28 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch28/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `dag_sim.py` | Sec 28.6: DAG, back-door criterion, collider bias. Linear-Gaussian SEM, n=20000, 1000 replicates. | numpy, scipy | 25.8 | `outputs/dag_sim.out` |
| `fsreml_test.py` | 数值复核 | numpy, scipy | 1.4 | `outputs/fsreml_test.out` |
| `fsreml_test2.py` | 数值复核 | numpy, scipy | 1.5 | `outputs/fsreml_test2.out` |
| `mr.py` | 数值复核 | numpy, scipy | 14.0 | `outputs/mr.out` |
| `reml_test.py` | independent check: eigen-based REML profile over h2 (single component) | numpy, scipy | 2.1 | `outputs/reml_test.out` |

公共函数模块（被上列脚本导入，不单独运行）：`fsreml.py`、`reml.py`。
