# -*- coding: utf-8 -*-
"""Exact REML for y = 1*mu + sum_k F_k u_k + e, u_k ~ N(0, s2_k I_{q_k}), e ~ N(0, s2_e I),
computed in feature space (Woodbury). Kernels K_k = F_k F_k'. Intercept handled exactly by centering
(likelihood of the n-1 contrasts). Cost O(r^3) per evaluation, r = sum q_k."""
import numpy as np
from scipy.optimize import minimize
from scipy.linalg import cho_factor, cho_solve

class FSREML:
    def __init__(self, Fs, y):
        self.q = [F.shape[1] for F in Fs]
        self.mu_F = [F.mean(0) for F in Fs]
        Fc = np.hstack([F - F.mean(0) for F in Fs])
        self.ybar = y.mean(); yc = y - self.ybar
        self.A = Fc.T @ Fc; self.b = Fc.T @ yc; self.s = yc @ yc
        self.n = len(y); self.r = Fc.shape[1]
        self.idx = np.repeat(np.arange(len(Fs)), self.q)

    def negll(self, lt):
        s2 = np.exp(lt); s2k, s2e = s2[:-1], s2[-1]
        dinv = 1.0 / s2k[self.idx]
        C = self.A + s2e * np.diag(dinv)
        try:
            cf = cho_factor(C, lower=True)
        except np.linalg.LinAlgError:
            return 1e300
        logdetC = 2 * np.sum(np.log(np.diag(cf[0])))
        Cb = cho_solve(cf, self.b)
        ll = -0.5 * ((self.n - 1 - self.r) * np.log(s2e) + np.sum(np.array(self.q) * np.log(s2k))
                     + logdetC + (self.s - self.b @ Cb) / s2e)
        return -ll

    def negll_grad(self, lt):
        s2 = np.exp(lt); s2k, s2e = s2[:-1], s2[-1]
        lam = 1.0 / s2k[self.idx]
        C = self.A + s2e * np.diag(lam)
        try:
            cf = cho_factor(C, lower=True)
        except np.linalg.LinAlgError:
            return 1e300, np.zeros_like(lt)
        logdetC = 2 * np.sum(np.log(np.diag(cf[0])))
        u = cho_solve(cf, self.b)
        Ci = cho_solve(cf, np.eye(self.r))
        dCi = np.diag(Ci)
        ll = -0.5 * ((self.n - 1 - self.r) * np.log(s2e) + np.sum(np.array(self.q) * np.log(s2k))
                     + logdetC + (self.s - self.b @ u) / s2e)
        g = np.empty_like(lt)
        for k, qk in enumerate(self.q):
            m = self.idx == k
            dk = -0.5 * (qk / s2k[k] - s2e * dCi[m].sum() / s2k[k]**2 - (u[m] @ u[m]) / s2k[k]**2)
            g[k] = dk * s2k[k]
        de = -0.5 * ((self.n - 1 - self.r) / s2e + np.sum(dCi * lam) - (self.s - self.b @ u) / s2e**2 + (u * lam) @ u / s2e)
        g[-1] = de * s2e
        return -ll, -g

    def fit(self, init=None):
        vy = self.s / (self.n - 1); L = len(self.q)
        x0 = np.log(np.full(L + 1, vy / (L + 1))) if init is None else np.log(init)
        lo = np.log(vy * 1e-8); hi = np.log(vy * 10)
        res = minimize(self.negll_grad, x0, jac=True, method='L-BFGS-B', bounds=[(lo, hi)] * (L + 1),
                       options=dict(maxiter=1000, ftol=1e-14, gtol=1e-9))
        self.s2 = np.exp(res.x); self.ll = -res.fun
        s2k, s2e = self.s2[:-1], self.s2[-1]
        C = self.A + s2e * np.diag(1.0 / s2k[self.idx])
        self.u = np.linalg.solve(C, self.b)          # BLUP of feature effects (MME solution)
        return self

    def predict(self, Fs_new, by_component=False):
        parts = []; start = 0
        for k, F in enumerate(Fs_new):
            q = self.q[k]
            parts.append((F - self.mu_F[k]) @ self.u[start:start + q]); start += q
        return parts if by_component else self.ybar + np.sum(parts, axis=0)
