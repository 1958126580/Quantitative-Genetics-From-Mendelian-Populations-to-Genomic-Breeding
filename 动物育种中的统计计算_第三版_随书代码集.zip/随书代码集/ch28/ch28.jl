# 本脚本由 tools/nb2jl.py 从同目录的 ch28.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 28

# %% [markdown]
# # 第二十八章　多组学整合与因果推断 —— 配套代码
#
# 本 Notebook 对应第二十八章。
#
# **内容**
#
# 1. 模拟一个"基因组 → 表达 → 性状"的三层数据
# 2. **TWAS**：两阶段实现与只用汇总统计量的版本（正文式 28.4）
# 3. TWAS 的陷阱：非因果基因也显著（正文 §28.1.3）
# 4. **coloc**：五个假设的后验概率（正文式 28.5–28.6）
# 5. **SMR** 与 **HEIDI**（正文式 28.7–28.12）
# 6. **孟德尔随机化**：IVW、MR-Egger、加权中位数、加权众数（正文式 28.14–28.19）
# 7. **完整的敏感性分析套件**（正文 §28.3.5）
# 8. 微生物组：CLR 变换与 holobiont 模型（正文式 28.22–28.24）

# %%
using LinearAlgebra, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %% [markdown]
# ## 1　模拟"基因组 → 表达 → 性状"三层数据
#
# 场景：一个区域内有两个基因。**基因 1 是真正的中介**（变异 → 表达 1 → 性状）；
# **基因 2 只是与基因 1 处于 LD**（表达 2 由一个与因果变异 LD 的变异决定，但对性状无作用）。

# %%
"""生成一个含 LD 的区域基因型（AR(1) 相关结构的连续潜变量阈值化）。"""
function sim_region(n::Int, m::Int; rho=0.9, maf=0.3, rng=Random.default_rng())
    H = zeros(n, m, 2)
    for k in 1:2
        x = randn(rng, n)
        for j in 1:m
            x = rho*x .+ sqrt(1-rho^2).*randn(rng, n)
            H[:, j, k] .= Float64.(x .< quantile(Normal(), maf))
        end
    end
    return H[:,:,1] .+ H[:,:,2]
end

Random.seed!(2801)
n_ref, n_gwas, mreg = 400, 3000, 40
causal = 15          # 因果变异（同时影响表达 1 与性状）
tag    = 20          # 与 causal 有 LD 的变异，只影响表达 2

# 参考样本（有表达数据）
Mref = sim_region(n_ref, mreg; rho=0.9, rng=Xoshiro(2802))
Zref = Mref .- mean(Mref; dims=1)
E1ref = 0.6 .* Zref[:, causal] .+ randn(Xoshiro(2803), n_ref).*0.8
E2ref = 0.6 .* Zref[:, tag]    .+ randn(Xoshiro(2804), n_ref).*0.8

# GWAS 样本
Mg = sim_region(n_gwas, mreg; rho=0.9, rng=Xoshiro(2805))
Zg = Mg .- mean(Mg; dims=1)
E1g = 0.6 .* Zg[:, causal] .+ randn(Xoshiro(2806), n_gwas).*0.8
y   = 0.35 .* E1g .+ randn(Xoshiro(2807), n_gwas)      # 只有基因 1 影响性状

@printf("参考样本 n = %d ， GWAS 样本 n = %d ， 区域变异数 = %d\n", n_ref, n_gwas, mreg)
@printf("因果变异 = %d ， 标签变异 = %d ， 二者 r² = %.3f\n",
        causal, tag, cor(Zg[:,causal], Zg[:,tag])^2)

# %% [markdown]
# ## 2　TWAS：两阶段与汇总统计量版本

# %%
"""第一阶段：用 cis 变异预测表达（这里用岭回归/BLUP）。"""
function fit_expression_model(E::Vector{Float64}, Z::Matrix{Float64}; lam=10.0)
    Zc = Z .- mean(Z; dims=1)
    Ec = E .- mean(E)
    w = (Zc'Zc + lam*I) \ (Zc'Ec)
    pred = Zc*w
    return w, cor(pred, Ec)^2          # 权重与样本内 R²（实际应用交叉验证）
end

"""交叉验证的 cis 预测 R²。"""
function cv_r2(E, Z; lam=10.0, k=5, rng=Random.default_rng())
    n = length(E); perm = randperm(rng, n)
    pred = zeros(n)
    for f in 1:k
        va = perm[f:k:end]; tr = setdiff(1:n, va)
        Zt = Z[tr,:] .- mean(Z[tr,:]; dims=1)
        w  = (Zt'Zt + lam*I) \ (Zt'(E[tr] .- mean(E[tr])))
        pred[va] .= (Z[va,:] .- mean(Z[tr,:]; dims=1))*w
    end
    return cor(pred, E)^2
end

w1, r2in1 = fit_expression_model(E1ref, Mref)
w2, r2in2 = fit_expression_model(E2ref, Mref)
cv1 = cv_r2(E1ref, Mref; rng=Xoshiro(2810))
cv2 = cv_r2(E2ref, Mref; rng=Xoshiro(2811))
@printf("表达预测模型： 基因 1 CV-R² = %.3f ， 基因 2 CV-R² = %.3f\n", cv1, cv2)

"""第二阶段（个体数据）：检验遗传预测的表达与性状的关联。"""
function twas_individual(y, Zg, w)
    Ehat = (Zg .- mean(Zg; dims=1))*w
    yc = y .- mean(y)
    zz = dot(Ehat, Ehat)
    a  = dot(Ehat, yc)/zz
    s2 = (dot(yc,yc) - a^2*zz)/(length(y) - 2)
    z  = a/sqrt(s2/zz)
    return z, 2*ccdf(Normal(), abs(z))
end

"""正文式 (28.4)：只用汇总统计量的 TWAS。"""
function twas_summary(zstat::Vector{Float64}, R::Matrix{Float64}, w::Vector{Float64})
    num = dot(w, zstat)
    den = sqrt(max(dot(w, R*w), 1e-300))
    z = num/den
    return z, 2*ccdf(Normal(), abs(z))
end

# 逐变异的 GWAS z 统计量与样本内 LD
zstat = Float64[]
yc = y .- mean(y)
for j in 1:mreg
    zj = Zg[:,j] .- mean(Zg[:,j])
    zz = dot(zj,zj); a = dot(zj,yc)/zz
    s2 = (dot(yc,yc) - a^2*zz)/(n_gwas-2)
    push!(zstat, a/sqrt(s2/zz))
end
Rld = cor(Zg)

z1i, p1i = twas_individual(y, Zg, w1)
z2i, p2i = twas_individual(y, Zg, w2)
z1s, p1s = twas_summary(zstat, Rld, w1)
z2s, p2s = twas_summary(zstat, Rld, w2)

@printf("\n%-14s%-16s%-16s%-16s%-16s\n", "基因", "个体数据 z", "个体数据 p", "汇总统计 z", "汇总统计 p")
@printf("%-14s%-16.3f%-16.2e%-16.3f%-16.2e\n", "基因1（因果）", z1i, p1i, z1s, p1s)
@printf("%-14s%-16.3f%-16.2e%-16.3f%-16.2e\n", "基因2（连锁）", z2i, p2i, z2s, p2s)
@printf("\ncor(个体数据 z, 汇总统计 z) 的一致性： %.3f vs %.3f ， %.3f vs %.3f\n",
        z1i, z1s, z2i, z2s)
println("\n=> **两个基因都显著**，但只有基因 1 是因果的（正文 §28.1.3 陷阱一、二）。")
println("   单靠 TWAS 无法区分——需要共定位与 HEIDI。")

# %% [markdown]
# ## 3　coloc：五个假设的后验概率（正文式 28.5–28.6）

# %%
"""Wakefield 的近似贝叶斯因子（正文式 28.5）的对数。"""
function log_abf(bhat::Float64, se::Float64; sigma0::Float64=0.15)
    s2 = se^2
    return 0.5*log(s2/(s2 + sigma0^2)) + 0.5*sigma0^2*bhat^2/(s2*(s2 + sigma0^2))
end

"""正文式 (28.6)：coloc 的五个后验概率。"""
function coloc(bhat1, se1, bhat2, se2; p1=1e-4, p2=1e-4, p12=1e-5, sigma0=0.15)
    m = length(bhat1)
    l1 = [log_abf(bhat1[j], se1[j]; sigma0=sigma0) for j in 1:m]
    l2 = [log_abf(bhat2[j], se2[j]; sigma0=sigma0) for j in 1:m]
    lse(v) = (mx = maximum(v); mx + log(sum(exp, v .- mx)))
    L0 = 0.0
    L1 = log(p1)  + lse(l1)
    L2 = log(p2)  + lse(l2)
    # H3：不同变异（排除 j = k）
    s1 = lse(l1); s2_ = lse(l2)
    both = lse(l1 .+ l2)
    # Σ_{j≠k} e^{l1j+l2k} = (Σ e^{l1j})(Σ e^{l2k}) - Σ e^{l1j+l2j}
    v3 = exp(s1 + s2_) - exp(both)
    L3 = log(p1) + log(p2) + log(max(v3, 1e-300))
    L4 = log(p12) + both
    ls = [L0, L1, L2, L3, L4]
    mx = maximum(ls); w = exp.(ls .- mx); w ./= sum(w)
    return (PP0=w[1], PP1=w[2], PP2=w[3], PP3=w[4], PP4=w[5])
end

"""逐变异的边际效应与标准误。"""
function marginal_stats(yv::Vector{Float64}, Z::Matrix{Float64})
    n, m = size(Z); yc = yv .- mean(yv)
    b = zeros(m); se = zeros(m)
    for j in 1:m
        zj = Z[:,j] .- mean(Z[:,j])
        zz = dot(zj,zj); zz < 1e-10 && continue
        a = dot(zj,yc)/zz
        s2 = (dot(yc,yc) - a^2*zz)/(n-2)
        b[j] = a; se[j] = sqrt(s2/zz)
    end
    return b, se
end

by, sey = marginal_stats(y, Zg)
b1, se1 = marginal_stats(E1ref, Mref)
b2, se2 = marginal_stats(E2ref, Mref)

c1 = coloc(by, sey, b1, se1)
c2 = coloc(by, sey, b2, se2)
@printf("%-16s%-10s%-10s%-10s%-10s%-10s\n", "对比", "PP0", "PP1", "PP2", "PP3", "PP4")
@printf("%-16s%-10.3f%-10.3f%-10.3f%-10.3f%-10.3f\n", "性状 vs 表达1",
        c1.PP0, c1.PP1, c1.PP2, c1.PP3, c1.PP4)
@printf("%-16s%-10.3f%-10.3f%-10.3f%-10.3f%-10.3f\n", "性状 vs 表达2",
        c2.PP0, c2.PP1, c2.PP2, c2.PP3, c2.PP4)
println("\n=> PP4（共定位）区分了因果基因与连锁基因（正文 §28.2.2）。")
println("   注意：本例的 LD 极强（r² ≈ 0.9），coloc 的区分能力有限——这正是真实的困难。")

# %% [markdown]
# ## 4　SMR 与 HEIDI（正文式 28.7–28.12）

# %%
"""正文式 (28.7)–(28.8)：SMR。"""
function smr(b_zy, se_zy, b_zx, se_zx)
    bxy = b_zy/b_zx
    zzy = b_zy/se_zy; zzx = b_zx/se_zx
    T = zzy^2*zzx^2/(zzy^2 + zzx^2)
    se_bxy = abs(bxy)*sqrt(1/zzy^2 + 1/zzx^2)
    return (b_xy=bxy, se=se_bxy, T=T, p=ccdf(Chisq(1), T))
end

"""正文式 (28.11)–(28.12)：HEIDI 的简化实现。

用 top eQTL 与其余 K 个 LD 伙伴的 b_xy 差异做异质性检验。
协方差用 delta 法 + LD 矩阵近似。
"""
function heidi(b_zy, se_zy, b_zx, se_zx, R::Matrix{Float64}, top::Int,
               idx::Vector{Int}; nlam=20)
    bxy(j) = b_zy[j]/b_zx[j]
    d = [bxy(j) - bxy(top) for j in idx]
    # 近似方差：Var(b_xy_j) 用 delta 法；协方差按 LD 折减
    v = [bxy(j)^2*(se_zy[j]^2/b_zy[j]^2 + se_zx[j]^2/b_zx[j]^2) for j in idx]
    vtop = bxy(top)^2*(se_zy[top]^2/b_zy[top]^2 + se_zx[top]^2/b_zx[top]^2)
    K = length(idx)
    S = zeros(K, K)
    for a in 1:K, b in 1:K
        cab = a == b ? v[a] : R[idx[a], idx[b]]*sqrt(v[a]*v[b])
        S[a,b] = cab + vtop - R[idx[a], top]*sqrt(v[a]*vtop) - R[idx[b], top]*sqrt(v[b]*vtop)
    end
    S .= 0.5 .* (S .+ S')
    ev = eigvals(Symmetric(S))
    keep = ev .> 1e-10*maximum(abs, ev)
    Si = pinv(Symmetric(S))
    Q = dot(d, Si*d)
    return Q, ccdf(Chisq(count(keep)), Q)
end

# SMR：用 top eQTL
top1 = argmax(abs.(b1 ./ se1))
top2 = argmax(abs.(b2 ./ se2))
s1r = smr(by[top1], sey[top1], b1[top1], se1[top1])
s2r = smr(by[top2], sey[top2], b2[top2], se2[top2])
@printf("%-16s%-10s%-14s%-14s%-14s%-12s\n", "基因", "top变异", "b_xy", "SE", "T_SMR", "p")
@printf("%-16s%-10d%-14.4f%-14.4f%-14.2f%-12.2e\n", "基因1（因果）", top1, s1r.b_xy, s1r.se, s1r.T, s1r.p)
@printf("%-16s%-10d%-14.4f%-14.4f%-14.2f%-12.2e\n", "基因2（连锁）", top2, s2r.b_xy, s2r.se, s2r.T, s2r.p)
@printf("\n验证 T_SMR ≤ min(z²_zy, z²_zx)： 基因1 %.2f ≤ %.2f ✔\n",
        s1r.T, min((by[top1]/sey[top1])^2, (b1[top1]/se1[top1])^2))

# HEIDI
idx1 = [j for j in max(1,top1-8):min(mreg,top1+8) if j != top1 && abs(b1[j]/se1[j]) > 2]
idx2 = [j for j in max(1,top2-8):min(mreg,top2+8) if j != top2 && abs(b2[j]/se2[j]) > 2]
if length(idx1) >= 3
    Q1, ph1 = heidi(by, sey, b1, se1, Rld, top1, idx1)
    @printf("\nHEIDI 基因1： Q = %.2f ， p = %.4f  （%s）\n", Q1, ph1,
            ph1 > 0.05 ? "不拒绝同一变异 → 支持中介" : "存在异质性 → 提示连锁")
end
if length(idx2) >= 3
    Q2, ph2 = heidi(by, sey, b2, se2, Rld, top2, idx2)
    @printf("HEIDI 基因2： Q = %.2f ， p = %.4f  （%s）\n", Q2, ph2,
            ph2 > 0.05 ? "不拒绝同一变异 → 支持中介" : "存在异质性 → 提示连锁")
end
println("\n注：HEIDI 是证伪工具，p > 0.05 不等于证明（正文 §28.2.3）。")

# %% [markdown]
# ## 5　孟德尔随机化：四种估计量（正文式 28.14–28.19）

# %%
"""模拟一组 MR 数据：K 个独立工具，其中 nplei 个有定向多效。"""
function sim_mr(; K=25, beta_true=0.3, nplei=0, plei=0.15, nx=20_000, ny=20_000,
                  rng=Random.default_rng())
    bzx = 0.05 .+ 0.15 .* rand(rng, K)                 # 工具对暴露的效应
    gam = zeros(K); gam[1:nplei] .= plei               # 定向多效
    sx = 1/sqrt(nx); sy = 1/sqrt(ny)
    bzx_hat = bzx .+ randn(rng, K).*sx
    bzy_hat = beta_true .* bzx .+ gam .+ randn(rng, K).*sy
    return bzx_hat, fill(sx, K), bzy_hat, fill(sy, K), beta_true
end

"""正文式 (28.15)–(28.16)：IVW。"""
function mr_ivw(bx, sx, by, sy)
    w = 1 ./ sy.^2
    b = sum(w .* bx .* by)/sum(w .* bx.^2)
    se = 1/sqrt(sum(w .* bx.^2))
    return b, se, 2*ccdf(Normal(), abs(b/se))
end

"""正文式 (28.18)：MR-Egger（加权回归，不过原点）。"""
function mr_egger(bx, sx, by, sy)
    w = 1 ./ sy.^2
    X = hcat(ones(length(bx)), bx)
    W = Diagonal(w)
    b = (X'W*X) \ (X'W*by)
    r = by .- X*b
    s2 = dot(r, w .* r)/(length(bx) - 2)
    V = inv(Symmetric(X'W*X)) .* s2
    return (intercept=b[1], se_int=sqrt(V[1,1]), p_int=2*ccdf(TDist(length(bx)-2), abs(b[1]/sqrt(V[1,1]))),
            slope=b[2], se_slope=sqrt(V[2,2]))
end

"""加权中位数估计。"""
function mr_weighted_median(bx, sx, by, sy)
    r = by ./ bx
    w = (bx.^2) ./ (sy.^2)              # 与 IVW 一致的权重
    o = sortperm(r); rs = r[o]; ws = w[o] ./ sum(w)
    cw = cumsum(ws) .- 0.5 .* ws
    k = findfirst(>=(0.5), cw)
    k === nothing && return rs[end]
    k == 1 && return rs[1]
    # 线性插值
    return rs[k-1] + (rs[k]-rs[k-1])*(0.5 - cw[k-1])/(cw[k]-cw[k-1])
end

"""加权众数估计（核密度的峰）。"""
function mr_weighted_mode(bx, sx, by, sy; phi=1.0)
    r = by ./ bx
    se = abs.(r) .* sqrt.(sy.^2 ./ by.^2 .+ sx.^2 ./ bx.^2)
    w = 1 ./ se.^2; w ./= sum(w)
    h = phi*0.9*std(r)*length(r)^(-0.2)
    grid = range(minimum(r)-3h, maximum(r)+3h; length=2000)
    dens = [sum(w .* pdf.(Normal(), (g .- r) ./ h))/h for g in grid]
    return grid[argmax(dens)]
end

"""正文式 (28.17)：Cochran's Q。"""
function cochran_q(bx, sx, by, sy, b)
    w = 1 ./ sy.^2
    Q = sum(w .* (by .- b .* bx).^2)
    return Q, ccdf(Chisq(length(bx)-1), Q)
end

println("四种 MR 估计量的比较（真值 β = 0.30）\n")
@printf("%-22s%-12s%-12s%-14s%-14s%-12s\n",
        "情形", "IVW", "Egger斜率", "加权中位数", "加权众数", "Egger截距p")
for (nm, npl) in ("无多效"=>0, "2/25 有多效"=>2, "8/25 有多效"=>8, "15/25 有多效"=>15)
    bx, sx, by2, sy, bt = sim_mr(; K=25, nplei=npl, rng=Xoshiro(2820))
    iv, _, _ = mr_ivw(bx, sx, by2, sy)
    eg = mr_egger(bx, sx, by2, sy)
    wm = mr_weighted_median(bx, sx, by2, sy)
    wo = mr_weighted_mode(bx, sx, by2, sy)
    @printf("%-22s%-12.4f%-12.4f%-14.4f%-14.4f%-12.3f\n", nm, iv, eg.slope, wm, wo, eg.p_int)
end
println("\n=> 与正文 §28.3.4 的表一致：多效比例上升时 IVW 偏倚增大，")
println("   中位数法在 <50% 时仍稳健，众数法在 >50% 时仍可能有效。")

# %% [markdown]
# ## 6　完整的敏感性分析套件（正文 §28.3.5）

# %%
"""正文 §28.3.5：一份完整的 MR 敏感性分析报告。"""
function mr_report(io::IO, bx, sx, by, sy; label="MR 分析")
    K = length(bx)
    Fs = (bx ./ sx).^2                                  # 式 (28.14)
    iv, se_iv, p_iv = mr_ivw(bx, sx, by, sy)
    eg = mr_egger(bx, sx, by, sy)
    wm = mr_weighted_median(bx, sx, by, sy)
    wo = mr_weighted_mode(bx, sx, by, sy)
    Q, pQ = cochran_q(bx, sx, by, sy, iv)
    I2 = max(0.0, (Q - (K-1))/Q)
    println(io, "=== ", label, " ===")
    @printf(io, "工具数 K = %d\n", K)
    @printf(io, "1. 工具强度   ： F 最小 = %.1f ， 中位 = %.1f ， %s\n",
            minimum(Fs), median(Fs), all(>(10), Fs) ? "全部 > 10 ✔" : "⚠ 存在弱工具")
    @printf(io, "2. IVW        ： β̂ = %+.4f (SE %.4f) ， p = %.3e\n", iv, se_iv, p_iv)
    @printf(io, "   MR-Egger   ： β̂ = %+.4f (SE %.4f)\n", eg.slope, eg.se_slope)
    @printf(io, "   加权中位数 ： β̂ = %+.4f\n", wm)
    @printf(io, "   加权众数   ： β̂ = %+.4f\n", wo)
    @printf(io, "   一致性     ： 四个估计的范围 = [%.4f, %.4f] ， %s\n",
            minimum((iv,eg.slope,wm,wo)), maximum((iv,eg.slope,wm,wo)),
            maximum((iv,eg.slope,wm,wo)) - minimum((iv,eg.slope,wm,wo)) < 2*se_iv ?
            "一致 ✔" : "⚠ 分歧明显")
    @printf(io, "3. Cochran Q  ： Q = %.2f (df %d) ， p = %.4f ， I² = %.3f %s\n",
            Q, K-1, pQ, I2, pQ < 0.05 ? "⚠ 存在异质性" : "✔")
    @printf(io, "4. Egger 截距 ： %+.4f (SE %.4f) ， p = %.4f %s\n",
            eg.intercept, eg.se_int, eg.p_int,
            eg.p_int < 0.05 ? "⚠ 提示定向多效" : "✔")
    # 5. 留一法
    loo = Float64[]
    for k in 1:K
        idx = setdiff(1:K, k)
        push!(loo, mr_ivw(bx[idx], sx[idx], by[idx], sy[idx])[1])
    end
    @printf(io, "5. 留一法     ： β̂ 范围 = [%.4f, %.4f] ， 最大偏离 = %.4f (剔除工具 %d)\n",
            minimum(loo), maximum(loo), maximum(abs.(loo .- iv)), argmax(abs.(loo .- iv)))
    # 6/7. 散点与漏斗图的数值摘要
    @printf(io, "6. 散点图     ： cor(b_zx, b_zy) = %.3f\n", cor(bx, by))
    @printf(io, "7. 漏斗图     ： cor(β̂_j, 1/SE_j) = %.3f %s\n",
            cor(by ./ bx, 1 ./ sy), abs(cor(by ./ bx, 1 ./ sy)) > 0.5 ? "⚠ 不对称" : "✔")
    # 8. Steiger 方向性
    r2x = mean(bx.^2 ./ (bx.^2 .+ sx.^2))
    r2y = mean(by.^2 ./ (by.^2 .+ sy.^2))
    @printf(io, "8. Steiger    ： 工具解释 X 的 R² = %.4f ， 解释 Y 的 R² = %.4f ， %s\n",
            r2x, r2y, r2x > r2y ? "方向 X→Y ✔" : "⚠ 方向可疑")
    return nothing
end

bx, sx, by2, sy, bt = sim_mr(; K=25, nplei=0, rng=Xoshiro(2830))
mr_report(stdout, bx, sx, by2, sy; label="情形 A：无多效（真值 0.30）")
println()
bx2, sx2, by3, sy2, _ = sim_mr(; K=25, nplei=8, plei=0.12, rng=Xoshiro(2831))
mr_report(stdout, bx2, sx2, by3, sy2; label="情形 B：8/25 工具有定向多效（真值 0.30）")

# %% [markdown]
# ## 7　微生物组：CLR 变换与 holobiont 模型（正文式 28.22–28.24）

# %%
"""正文式 (28.22)：中心对数比（CLR）变换。"""
function clr(B::Matrix{Float64}; pseudo=0.5)
    A = B .+ pseudo
    A = A ./ sum(A; dims=2)                    # 相对丰度
    L = log.(A)
    return L .- mean(L; dims=2)
end

"""正文式 (28.23)：微生物组关系矩阵。"""
function microbiome_matrix(Bclr::Matrix{Float64})
    Bc = Bclr .- mean(Bclr; dims=1)
    M = Bc*Bc'
    return M .* (size(M,1)/tr(M))
end

# 演示：组分性造成的虚假负相关
let rng = Xoshiro(2840), n = 500, K = 8
    counts = zeros(n, K)
    base = [100.0, 80, 60, 40, 30, 20, 10, 5]
    for i in 1:n
        depth = 5000 + 3000*rand(rng)
        lam = base .* exp.(0.5 .* randn(rng, K))
        lam ./= sum(lam)
        counts[i, :] .= depth .* lam
    end
    rel = counts ./ sum(counts; dims=2)
    Cclr = clr(counts)
    @printf("组分数据的虚假相关\n")
    @printf("  相对丰度矩阵的平均两两相关 = %+.4f （必然为负！）\n",
            mean([cor(rel[:,a], rel[:,b]) for a in 1:K for b in 1:K if a < b]))
    @printf("  CLR 变换后的平均两两相关   = %+.4f\n",
            mean([cor(Cclr[:,a], Cclr[:,b]) for a in 1:K for b in 1:K if a < b]))
    @printf("  CLR 后每个样本的取值之和   = %.3e （应为 0）\n",
            maximum(abs, sum(Cclr; dims=2)))
end

# holobiont 模型：微生物组能否提高预测？
let rng = Xoshiro(2850), n = 600, m = 500, K = 40
    p = 0.1 .+ 0.8 .* rand(rng, m)
    Mg = [Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j]) for i in 1:n, j in 1:m]
    Z  = Mg .- 2 .* p'
    G  = (Z*Z') ./ (2*sum(p .* (1 .- p)))
    G .= 0.98 .* G .+ 0.02 .* Matrix(I, n, n)
    counts = exp.(randn(rng, n, K) .* 0.8) .* 1000
    Bc = clr(counts)
    Mm = microbiome_matrix(Bc)
    Mm .= 0.98 .* Mm .+ 0.02 .* Matrix(I, n, n)

    h2g, h2m = 0.25, 0.20
    ug = cholesky(Symmetric(G)).L*randn(rng, n);  ug .*= sqrt(h2g)/std(ug)
    um = cholesky(Symmetric(Mm)).L*randn(rng, n); um .*= sqrt(h2m)/std(um)
    y  = 10.0 .+ ug .+ um .+ randn(rng, n).*sqrt(1 - h2g - h2m)

    tr_ = 1:450; va = 451:n
    function predict(Ks, s2s)
        n_ = length(tr_); V = (1-sum(s2s)) .* Matrix(I, n_, n_)
        for (K_, s) in zip(Ks, s2s); V .+= s .* K_[tr_,tr_]; end
        Vi = inv(cholesky(Symmetric(V)))
        Xt = ones(n_,1)
        b = (Xt'Vi*Xt) \ (Xt'Vi*y[tr_])
        r = Vi*(y[tr_] .- Xt*b)
        return sum(s .* (K_[va, tr_]*r) for (K_, s) in zip(Ks, s2s))
    end
    pg  = predict([G], [h2g + h2m])
    pgm = predict([G, Mm], [h2g, h2m])
    @printf("\nholobiont 模型（h²_g = %.2f, h²_m = %.2f）\n", h2g, h2m)
    @printf("  只用 G     ： cor(ŷ, 表型) = %.4f ， cor(ŷ, 育种值) = %.4f\n",
            cor(pg,  y[va]),  cor(pg,  ug[va]))
    @printf("  G + M      ： cor(ŷ, 表型) = %.4f ， cor(ŷ, 育种值) = %.4f\n",
            cor(pgm, y[va]), cor(pgm, ug[va]))
    println("  => 加入 M 提高了**表型**预测，对**育种值**预测无增益（正文 §28.4.2）。")
end

# %% [markdown]
# ## 8　自检汇总

# %%
ok = Bool[]
# SMR 的调和平均性质
let s = smr(0.10, 0.02, 0.30, 0.02)
    zzy = 0.10/0.02; zzx = 0.30/0.02
    push!(ok, check("T_SMR 公式", s.T, zzy^2*zzx^2/(zzy^2+zzx^2); tol=1e-12))
    push!(ok, s.T <= min(zzy^2, zzx^2) + 1e-10)
    @printf("T_SMR = %.3f ≤ min(z²) = %.3f ✔\n", s.T, min(zzy^2, zzx^2))
end
# coloc 的后验概率和为 1
let c = coloc(by, sey, b1, se1)
    push!(ok, check("coloc 五个后验和 = 1",
                    c.PP0+c.PP1+c.PP2+c.PP3+c.PP4, 1.0; tol=1e-10))
end
# IVW 等价于过原点的加权回归（正文思考题 6）
let bx=[0.1,0.2,0.15,0.3], sx=fill(0.01,4), byv=[0.03,0.06,0.045,0.09], syv=fill(0.01,4)
    b1_, _, _ = mr_ivw(bx, sx, byv, syv)
    w = 1 ./ syv.^2
    b2_ = sum(w .* bx .* byv)/sum(w .* bx.^2)
    push!(ok, check("IVW = 过原点加权回归", b1_, b2_; tol=1e-14))
    @printf("IVW β̂ = %.6f （真值 0.30）\n", b1_)
    push!(ok, abs(b1_ - 0.30) < 1e-10)
end
# Egger 截距在无多效时应接近 0
let (bx3, sx3, by4, sy3, _) = sim_mr(; K=40, nplei=0, rng=Xoshiro(999))
    eg = mr_egger(bx3, sx3, by4, sy3)
    @printf("无多效时 Egger 截距 = %+.5f ， p = %.3f （应不显著）\n", eg.intercept, eg.p_int)
    push!(ok, eg.p_int > 0.01)
end
# CLR 的性质
let B = rand(Xoshiro(3), 50, 6) .* 100 .+ 1
    Cc = clr(B)
    push!(ok, check("CLR 每行和为 0", vec(sum(Cc; dims=2)), zeros(50); tol=1e-10))
end
# TWAS 汇总统计量版本 ≈ 个体数据版本
@printf("TWAS 基因1： 个体数据 z = %.3f ， 汇总统计 z = %.3f ， 相对差 %.1f%%\n",
        z1i, z1s, 100*abs(z1s-z1i)/abs(z1i))
push!(ok, abs(z1s - z1i)/abs(z1i) < 0.2)
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
