# 第二十八章　多组学整合与因果推断 —— 配套代码

**所属**：第六篇　关联分析与统计基因组学　　**对应正文**：第二十八章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch28.ipynb` | IJulia 笔记本：9 个代码单元，约 463 行 Julia 代码，穿插与正文对应的说明 |
| `ch28.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 5 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　模拟"基因组 → 表达 → 性状"三层数据
- 2　TWAS：两阶段与汇总统计量版本
- 3　coloc：五个假设的后验概率（正文式 28.5–28.6）
- 4　SMR 与 HEIDI（正文式 28.7–28.12）
- 5　孟德尔随机化：四种估计量（正文式 28.14–28.19）
- 6　完整的敏感性分析套件（正文 §28.3.5）
- 7　微生物组：CLR 变换与 holobiont 模型（正文式 28.22–28.24）
- 8　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 28
```

或在 Jupyter 中打开 `ch28/ch28.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
