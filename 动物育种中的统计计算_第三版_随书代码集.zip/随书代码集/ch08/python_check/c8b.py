# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8b.py    依赖：numpy, sympy
import numpy as np, itertools, sympy as sp

# ---------- 两位点正交剖分 ----------
def decomp(Gmat,p1,p2,label):
    """Gmat[i,j]: i=#A1 at locus1 (2,1,0 order -> use idx 0,1,2 = A1A1,A1A2,A2A2)"""
    q1,q2=1-p1,1-p2
    f1=np.array([p1*p1,2*p1*q1,q1*q1]); f2=np.array([p2*p2,2*p2*q2,q2*q2])
    z1=np.array([2.,1.,0.]); z2=np.array([2.,1.,0.])
    rows=[];w=[];y=[]
    for i in range(3):
        for j in range(3):
            rows.append((i,j)); w.append(f1[i]*f2[j]); y.append(Gmat[i,j])
    w=np.array(w); y=np.array(y)
    # basis: additive contrast = z-2p ; dominance contrast = indicator of het minus its mean,
    # orthogonalised within locus by construction under HWE
    def basis(idx,p):
        q=1-p
        z=np.array([2.,1.,0.])[idx]
        A=z-2*p
        Dv=np.array([-2*q*q,2*p*q,-2*p*p])[idx]   # standard dominance deviation coding (d=1)
        return A,Dv
    X=[]
    for (i,j) in rows:
        A1,D1=basis(i,p1); A2,D2=basis(j,p2)
        X.append([1.,A1,A2,D1,D2,A1*A2,A1*D2,D1*A2,D1*D2])
    X=np.array(X)
    W=np.diag(w)
    beta=np.linalg.solve(X.T@W@X, X.T@W@y)
    comp=X*beta                      # column-wise contributions
    names=['mu','A1','A2','D1','D2','AA','AD','DA','DD']
    var={}
    for k,n in enumerate(names):
        if n=='mu': continue
        c=comp[:,k]; m=(w*c).sum(); var[n]=(w*(c-m)**2).sum()
    mu=(w*y).sum(); vG=(w*(y-mu)**2).sum()
    # check orthogonality: sum of variances
    s=sum(var.values())
    print("\n---",label,"  p1=%.2f p2=%.2f"%(p1,p2))
    print("   mean=%.6f  vG=%.6f"%(mu,vG))
    vA=var['A1']+var['A2']; vD=var['D1']+var['D2']
    print("   vA=%.6f vD=%.6f vAA=%.6f vAD=%.6f vDA=%.6f vDD=%.6f  sum=%.6f"%(
        vA,vD,var['AA'],var['AD'],var['DA'],var['DD'],s))
    print("   fractions: A=%.4f D=%.4f AA=%.4f AD+DA=%.4f DD=%.4f"%(
        vA/vG,vD/vG,var['AA']/vG,(var['AD']+var['DA'])/vG,var['DD']/vG))
    return vG,vA,vD,var

# 互补作用: G=1 iff at least one A1 and at least one B1
Gc=np.zeros((3,3))
for i in range(3):
    for j in range(3):
        Gc[i,j]=1.0 if (i<=1 and j<=1) else 0.0
for p in [0.5,0.3,0.7]:
    decomp(Gc,p,p,"互补作用 G=1 当 A_ 且 B_")

# 纯 A x A 上位: G = z1*z2 (centred)
Gaa=np.zeros((3,3))
z=np.array([2.,1.,0.])
for i in range(3):
    for j in range(3):
        Gaa[i,j]=(z[i]-1)*(z[j]-1)
decomp(Gaa,0.5,0.5,"纯加性x加性 G=(z1-1)(z2-1)")
decomp(Gaa,0.7,0.7,"纯加性x加性 G=(z1-1)(z2-1)")

# ---------- 近交下的方差 ----------
a,d,p,F=sp.symbols('a d p F',positive=True)
q=1-p
f11=p**2+F*p*q; f12=2*p*q*(1-F); f22=q**2+F*p*q
vals=[a,d,-a]; fr=[f11,f12,f22]
M=sp.expand(sum(f*v for f,v in zip(fr,vals)))
EG2=sp.expand(sum(f*v**2 for f,v in zip(fr,vals)))
VG=sp.simplify(sp.expand(EG2-M**2))
print("\n=== 近交群体 (系数 F) 单位点 ===")
print("M_F =",sp.simplify(M))
print("Var(G) =",sp.factor(sp.simplify(VG)))
alpha=a+d*(q-p)
vA0=2*p*q*alpha**2; vD0=(2*p*q*d)**2
print("Var(G)-[(1+F)vA+(1-F)vD] =",sp.factor(sp.simplify(sp.expand(VG-((1+F)*vA0+(1-F)*vD0)))))
print("d=0 case: Var(G) =",sp.factor(sp.simplify(VG.subs(d,0))))
