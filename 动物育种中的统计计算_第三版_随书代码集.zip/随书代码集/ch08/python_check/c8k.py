# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8k.py    依赖：numpy, scipy
import numpy as np
from scipy.stats import norm, multivariate_normal as mvn
def se_f(s,n,t): return (1-t)*(1+(n-1)*t)*np.sqrt(2.0/(n*(n-1)*(s-1)))
print("Ex11: h2=0.30 (t=0.075), n=30, SE(h2)<=0.04")
for s in range(3,10**7):
    if 4*se_f(s,30,0.075)<=0.04: break
print("   s =",s," 记录 =",s*30, " SE =",4*se_f(s,30,0.075))
print("   固定 s=%d: n=30 -> SE=%.5f ; n=60 -> SE=%.5f ; 改善 %.1f%%"%(s,4*se_f(s,30,0.075),4*se_f(s,60,0.075),100*(1-se_f(s,60,0.075)/se_f(s,30,0.075))))
print("   s 加倍 (n=30): SE=%.5f 改善 %.1f%%"%(4*se_f(2*s,30,0.075),100*(1-se_f(2*s,30,0.075)/se_f(s,30,0.075))))

print("\nEx12: pi=0.05, h2obs=0.04 -> h2lia ; 全同胞时的一阶偏差")
t=norm.ppf(0.95); z=norm.pdf(t); f=z*z/(0.05*0.95)
hl=0.04/f; print("   h2lia=%.4f"%hl)
rho=0.5*hl; print("   全同胞 rho=%.4f, 一阶修正因子 1+rho t^2/2 = %.4f (即高估约 %.1f%%)"%(rho,1+rho*t*t/2,100*(rho*t*t/2)))
# exact
def orth(tt,r): return mvn(mean=[0,0],cov=[[1,r],[r,1]]).cdf([-tt,-tt])
cov=orth(t,rho)-0.05**2; h2obs=cov/(0.05*0.95)/0.5; print("   精确: 若真 h2lia=%.4f 则 h2obs=%.5f -> 反算 %.5f (高估 %.1f%%)"%(hl,h2obs*1,h2obs/f,100*(h2obs/f/hl-1)))

print("\nEx15: lam=2.5, h2_l=0.40, sl2=0.25 -> sa2=0.10")
lam,sa2,sl2=2.5,0.10,0.25
vy=lam+lam**2*(np.exp(sl2)-1); vA=lam**2*(np.exp(sa2)-1)
print("   Poisson: Var(y)=%.4f  vA=%.4f  h2obs=%.4f ; 极限式 %.4f x h2_l = %.4f"%(vy,vA,vA/vy,lam*sl2/(1+lam*sl2),0.4*lam*sl2/(1+lam*sl2)))
k=4.0; vy2=lam+lam**2*(np.exp(sl2)/k+np.exp(sl2)-1)
print("   NB(k=4): Var(y)=%.4f  h2obs=%.4f"%(vy2,vA/vy2))

print("\nEx7: m=1000, 1+(m-1)r=0.8 -> r =",-0.2/999)

print("\nEx6: 重叠作用 G=1 若任一位点携带显性等位基因")
def decomp(Gmat,p1,p2):
    q1,q2=1-p1,1-p2
    f1=np.array([p1*p1,2*p1*q1,q1*q1]); f2=np.array([p2*p2,2*p2*q2,q2*q2])
    rows=[(i,j) for i in range(3) for j in range(3)]
    w=np.array([f1[i]*f2[j] for i,j in rows]); y=np.array([Gmat[i,j] for i,j in rows])
    def basis(idx,p):
        q=1-p; A=np.array([2.,1.,0.])[idx]-2*p
        D=np.array([-2*q*q,2*p*q,-2*p*p])[idx]; return A,D
    X=[]
    for (i,j) in rows:
        A1,D1=basis(i,p1); A2,D2=basis(j,p2)
        X.append([1.,A1,A2,D1,D2,A1*A2,A1*D2,D1*A2,D1*D2])
    X=np.array(X); W=np.diag(w)
    b=np.linalg.solve(X.T@W@X,X.T@W@y); comp=X*b
    names=['mu','A1','A2','D1','D2','AA','AD','DA','DD']; var={}
    for k2,n2 in enumerate(names):
        if n2=='mu': continue
        c=comp[:,k2]; m=(w*c).sum(); var[n2]=(w*(c-m)**2).sum()
    mu=(w*y).sum(); vG=(w*(y-mu)**2).sum()
    vA=var['A1']+var['A2']; vD=var['D1']+var['D2']
    return vG,vA/vG,vD/vG,var['AA']/vG,(var['AD']+var['DA'])/vG,var['DD']/vG
Gd=np.zeros((3,3))
for i in range(3):
    for j in range(3):
        Gd[i,j]=1.0 if (i<=1 or j<=1) else 0.0
for p in [0.2,0.5,0.8]:
    vG,a,d,aa,ad,dd=decomp(Gd,p,p)
    print("   重叠 p=%.1f: vG=%.5f A=%.2f%% D=%.2f%% AA=%.2f%% AD=%.2f%% DD=%.2f%% 上位合计=%.2f%%"%(p,vG,100*a,100*d,100*aa,100*ad,100*dd,100*(aa+ad+dd)))
Gc=np.zeros((3,3))
for i in range(3):
    for j in range(3):
        Gc[i,j]=1.0 if (i<=1 and j<=1) else 0.0
for p in [0.2,0.5,0.8]:
    vG,a,d,aa,ad,dd=decomp(Gc,p,p)
    print("   互补 p=%.1f: vG=%.5f A=%.2f%% D=%.2f%% AA=%.2f%% AD=%.2f%% DD=%.2f%% 上位合计=%.2f%%"%(p,vG,100*a,100*d,100*aa,100*ad,100*dd,100*(aa+ad+dd)))
