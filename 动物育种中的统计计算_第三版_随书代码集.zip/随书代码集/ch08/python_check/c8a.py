# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8a.py    依赖：numpy
import numpy as np
from math import lgamma, exp, sqrt

def locus(a,d,p):
    q=1-p
    M=a*(p-q)+2*p*q*d
    al=a+d*(q-p)
    A=np.array([2*q*al,(q-p)*al,-2*p*al])          # A1A1, A1A2, A2A2
    G=np.array([a,d,-a])
    D=(G-M)-A
    f=np.array([p*p,2*p*q,q*q])
    vA=2*p*q*al**2; vD=(2*p*q*d)**2
    vG=np.sum(f*(G-M)**2)
    cov=np.sum(f*A*D)
    # regression check
    z=np.array([2.,1.,0.]); Ez=np.sum(f*z); Vz=np.sum(f*(z-Ez)**2)
    beta=np.sum(f*(G-M)*(z-Ez))/Vz
    return dict(M=M,alpha=al,A=A,D=D,vA=vA,vD=vD,vG=vG,cov=cov,beta=beta,Vz=Vz,
                a1=q*al,a2=-p*al)

print("=== 例 a=10,d=4,p=0.6 ===")
r=locus(10,4,0.6)
for k,v in r.items(): print(" ",k,np.round(v,6))
print("  vA+vD =",r['vA']+r['vD'], " vG =",r['vG'])

print("\n=== 例 a=10,d=10,p=0.9 (思考题3) ===")
r2=locus(10,10,0.9)
for k,v in r2.items(): print(" ",k,np.round(v,6))
print("  vA/vD =",r2['vA']/r2['vD'], " 2q/p =",2*0.1/0.9)

print("\n=== 例 a=0,d=5,p=0.8 超显性但 a=0 ===")
r3=locus(0,5,0.8)
for k,v in r3.items(): print(" ",k,np.round(v,6))
print("  vA/(vA+vD)=",r3['vA']/(r3['vA']+r3['vD']))

print("\n=== sigma_D^2/sigma_A^2 table (a=1) ===")
ps=[0.05,0.1,0.25,0.5,0.75,0.9,0.95]
for d in [0.0,0.25,0.5,1.0,1.5]:
    row=[]
    for p in ps:
        r=locus(1.0,d,p)
        row.append(r['vD']/r['vA'] if r['vA']>0 else float('nan'))
    print(" d/a=%4.2f "%d, " ".join("%8.4f"%x for x in row))
print("  p =", ps)

print("\n=== 完全显性 vA/vD = 2q/p 验证 ===")
for p in [0.1,0.25,0.5,0.75,0.9,0.99]:
    r=locus(1.0,1.0,p)
    print("  p=%.2f  vA=%.6f vD=%.6f  vA/vD=%.4f  2q/p=%.4f  vA/(vA+vD)=%.4f"%(p,r['vA'],r['vD'],r['vA']/r['vD'],2*(1-p)/p,r['vA']/(r['vA']+r['vD'])))

print("\n=== Beta(0.2,0.2) 下完全显性位点 E[vA]/E[vD] ===")
def B(x,y): return exp(lgamma(x)+lgamma(y)-lgamma(x+y))
for s in [0.2,0.5,1.0,2.0]:
    ratio=2*B(1+s,3+s)/B(2+s,2+s)
    print("  Beta(%.1f,%.1f): E[vA]/E[vD] = %.4f"%(s,s,ratio))
# Monte Carlo check for 0.2
rng=np.random.default_rng(1); p=rng.beta(0.2,0.2,5_000_000); q=1-p
print("  MC check Beta(0.2,0.2):", (8*p*q**3).mean()/(4*p*p*q*q).mean())
