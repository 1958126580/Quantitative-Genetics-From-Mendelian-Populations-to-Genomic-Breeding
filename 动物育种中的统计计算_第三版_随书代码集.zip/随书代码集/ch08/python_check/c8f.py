# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8f.py    依赖：numpy, scipy
import numpy as np
from scipy.stats import norm, multivariate_normal as mvn
def zz(pi):
    t=norm.ppf(1-pi); return t, norm.pdf(t)
print("=== 发生率 -> 转换因子 ===")
print("  pi      t       z       z^2/[pi(1-pi)]   pi(1-pi)/z^2   h2obs(h2l=0.25)  h2obs 上限")
for pi in [0.50,0.40,0.30,0.20,0.10,0.05,0.02,0.01,0.005,0.001]:
    t,z=zz(pi); f=z*z/(pi*(1-pi))
    print("  %.3f  %6.3f  %6.4f   %8.4f       %8.3f      %8.4f       %.4f"%(pi,t,z,f,1/f,0.25*f,f))
print("\n=== h2_obs -> h2_lia (三个示例性状) ===")
for pi,ho in [(0.50,0.10),(0.20,0.06),(0.08,0.04),(0.05,0.03),(0.01,0.01)]:
    t,z=zz(pi); f=z*z/(pi*(1-pi))
    print("  pi=%.3f  h2_obs=%.3f -> h2_lia=%.4f"%(pi,ho,ho/f))
print("\n=== 极端对比 pi=0.5 vs pi=0.01, 同一 h2_lia=0.30 ===")
for pi in [0.5,0.01]:
    t,z=zz(pi); print("  pi=%.2f: z=%.5f, z^2=%.6f, pi(1-pi)=%.6f, 因子=%.5f, h2_obs=%.5f"%(pi,z,z*z,pi*(1-pi),z*z/(pi*(1-pi)),0.30*z*z/(pi*(1-pi))))
t5,z5=zz(0.5); t1,z1=zz(0.01)
print("  因子之比 =",(z5*z5/0.25)/(z1*z1/(0.01*0.99)))

print("\n=== Dempster-Lerner 近似的精确性（四分相关展开）===")
def orth(t,rho):
    return mvn(mean=[0,0],cov=[[1,rho],[rho,1]]).cdf([-t,-t])   # P(X>t,Y>t)
for pi in [0.5,0.2,0.05,0.01]:
    t,z=zz(pi)
    print("  pi=%.2f (t=%.3f):"%(pi,t))
    for h2l in [0.1,0.3,0.6]:
        for a_xy,nm in [(0.5,'全同胞/亲子'),(0.25,'半同胞')]:
            rho=a_xy*h2l
            P11=orth(t,rho); cov=P11-pi*pi
            tobs=cov/(pi*(1-pi))          # 观测尺度组内相关
            h2obs=tobs/a_xy
            f=z*z/(pi*(1-pi))
            h2rec=h2obs/f                  # 用 D-L 反算的潜在尺度 h2
            print("     h2_l=%.1f %s: rho=%.4f 观测协方差=%.6f h2_obs=%.5f  反算 h2_lia=%.5f (相对偏差 %+.1f%%)"%(
                h2l,nm,rho,cov,h2obs,h2rec,100*(h2rec/h2l-1)))
