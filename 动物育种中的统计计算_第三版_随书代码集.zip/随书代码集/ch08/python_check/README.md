# 第 8 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch08/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `c8a.py` | 数值复核 | numpy | 2.2 | `outputs/c8a.out` |
| `c8b.py` | ---------- 两位点正交剖分 ---------- | numpy, sympy | 5.2 | `outputs/c8b.out` |
| `c8c.py` | 数值复核 | numpy, sympy | 5.1 | `outputs/c8c.out` |
| `c8d.py` | gamete freqs with LD: p1,p2 allele freqs of A1,B1 ; D | numpy | 0.5 | `outputs/c8d.out` |
| `c8e.py` | 数值复核 | numpy | 0.4 | `outputs/c8e.out` |
| `c8f.py` | 数值复核 | numpy, scipy | 5.1 | `outputs/c8f.out` |
| `c8g.py` | Mehler expansion check | numpy, scipy | 5.2 | `outputs/c8g.out` |
| `c8h.py` | 数值复核 | numpy | 20.6 | `outputs/c8h.out` |
| `c8i.py` | 数值复核 | numpy | 3.4 | `outputs/c8i.out` |
| `c8j.py` | 数值复核 | numpy, scipy | 7.2 | `outputs/c8j.out` |
| `c8k.py` | 数值复核 | numpy, scipy | 6.4 | `outputs/c8k.out` |
