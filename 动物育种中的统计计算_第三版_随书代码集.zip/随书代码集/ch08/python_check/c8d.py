# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8d.py    依赖：numpy
import numpy as np, itertools
# gamete freqs with LD: p1,p2 allele freqs of A1,B1 ; D
def gametes(p1,p2,D):
    q1,q2=1-p1,1-p2
    return {'AB':p1*p2+D,'Ab':p1*q2-D,'aB':q1*p2-D,'ab':q1*q2+D}
def joint_cov(p1,p2,D):
    g=gametes(p1,p2,D)
    assert min(g.values())>=-1e-12, g
    # random union of two gametes
    z1=[];z2=[];w=[]
    ks=list(g)
    cnt={'AB':(1,1),'Ab':(1,0),'aB':(0,1),'ab':(0,0)}
    for k1 in ks:
        for k2 in ks:
            w.append(g[k1]*g[k2]); z1.append(cnt[k1][0]+cnt[k2][0]); z2.append(cnt[k1][1]+cnt[k2][1])
    w=np.array(w);z1=np.array(z1,float);z2=np.array(z2,float)
    m1=(w*z1).sum(); m2=(w*z2).sum()
    return (w*(z1-m1)*(z2-m2)).sum(), (w*(z1-m1)**2).sum(), (w*(z2-m2)**2).sum()
print("=== Cov(z1,z2)=2D 验证 ===")
for p1,p2,D in [(0.5,0.5,0.1),(0.5,0.5,-0.1),(0.3,0.6,0.05),(0.2,0.8,-0.03)]:
    c,v1,v2=joint_cov(p1,p2,D)
    print("  p1=%.2f p2=%.2f D=%+.3f -> Cov=%.6f  2D=%.6f  Var(z1)=%.4f (2pq=%.4f)  r=%.4f"%(
        p1,p2,D,c,2*D,v1,2*p1*(1-p1),D/np.sqrt(p1*(1-p1)*p2*(1-p2))))

print("\n=== 两位点加性方差与 D（a=1,d=0, p1=p2=0.5 -> alpha=1）===")
p1=p2=0.5
for D in [-0.25,-0.20,-0.10,-0.05,0.0,0.05,0.10,0.20,0.25]:
    c,v1,v2=joint_cov(p1,p2,D)
    vA=v1*1+v2*1+2*c*1*1
    r=D/np.sqrt(p1*(1-p1)*p2*(1-p2))
    print("  D=%+.2f  r=%+.2f  sigmaA2=%.4f  (无LD=%.4f)  变化 %+.1f%%"%(D,r,vA,v1+v2,100*(vA/(v1+v2)-1)))

print("\n=== 100 个等效位点、成对 r 相同的情形 ===")
m=100; twopq=0.5; al=1.0
for r in [-0.05,-0.02,0.0,0.02,0.05]:
    D=r*0.25
    vA=m*twopq*al**2 + 4*(m*(m-1)/2)*D*al**2
    print("  m=%d r=%+.2f: sigmaA2=%.3f  (LE 基准 %.3f)  比值 %.3f"%(m,r,vA,m*twopq,vA/(m*twopq)))
