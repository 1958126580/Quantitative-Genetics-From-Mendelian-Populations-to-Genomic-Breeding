# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8e.py    依赖：numpy
import numpy as np
print("=== 等相关 LD: sigmaA2 / LE 基准 = 1 + r(m-1) ===")
for m in [10,100,1000]:
    print("  m=%d  下界 r>=-1/(m-1)=%.5f"%(m,-1/(m-1)))
    for r in [-0.5/(m-1),-0.2/(m-1),0,0.2/(m-1),0.5/(m-1),1.0/(m-1)]:
        print("     r=%+.5f -> 比值 %.3f"%(r,1+r*(m-1)))
print("\n=== m=100, 具体 r ===")
for r in [-0.010,-0.005,-0.002,0.0,0.002,0.005,0.010]:
    print("  r=%+.3f -> sigmaA2/LE = %.3f"%(r,1+r*99))

print("\n=== h2_(n) ===")
def h2n(h2,r,n): return n*h2/(1+(n-1)*r)
for (h2,r) in [(0.25,0.5),(0.15,0.35),(0.10,0.20),(0.40,0.45)]:
    row=[h2n(h2,r,n) for n in [1,2,3,4,5,10,20,50]]
    print("  h2=%.2f r=%.2f: "%(h2,r)," ".join("%.4f"%x for x in row)," 上限=%.4f"%(h2/r))
# n needed for target
def nmin(h2,r,target):
    n=1
    while h2n(h2,r,n)<target and n<10**7: n+=1
    return n
print("  h2=0.15,r=0.35 达到 0.30 需 n =",nmin(0.15,0.35,0.30), " h2n=",h2n(0.15,0.35,nmin(0.15,0.35,0.30)))
print("  h2=0.15,r=0.35 达到 0.35 需 n =",nmin(0.15,0.35,0.35))
print("  h2=0.25,r=0.50 达到 0.45 需 n =",nmin(0.25,0.5,0.45))
print("  MPPA 权重 nr/(1+(n-1)r), r=0.5:", [round(n*0.5/(1+(n-1)*0.5),4) for n in [1,2,3,5,10]])

print("\n=== rP = h1h2 rA + e1e2 rE ===")
def rP(h12,h22,rA,rE):
    h1=np.sqrt(h12);h2=np.sqrt(h22);e1=np.sqrt(1-h12);e2=np.sqrt(1-h22)
    return h1*h2*rA+e1*e2*rE, h1*h2*rA, e1*e2*rE
for args in [(0.40,0.10,-0.5,0.3),(0.30,0.05,-0.6,0.2),(0.25,0.25,0.5,-0.5),(0.35,0.08,-0.45,0.25)]:
    tot,g,e=rP(*args)
    print("  h1^2=%.2f h2^2=%.2f rA=%+.2f rE=%+.2f -> 遗传贡献 %+.4f 环境贡献 %+.4f  rP=%+.4f"%(args+(g,e,tot)))
# 反解: rP=0 时的 rE
for h12,h22,rA in [(0.40,0.10,-0.5),(0.30,0.05,-0.6)]:
    h1,h2=np.sqrt(h12),np.sqrt(h22); e1,e2=np.sqrt(1-h12),np.sqrt(1-h22)
    print("  使 rP=0 所需 rE = %.4f  (h1h2=%.4f, e1e2=%.4f)"%(-h1*h2*rA/(e1*e2),h1*h2,e1*e2))
print("\n=== rP 的取值范围（给定 h, rA∈[-1,1], rE∈[-1,1]）===")
for h12,h22 in [(0.4,0.1),(0.1,0.1),(0.6,0.6)]:
    h1,h2=np.sqrt(h12),np.sqrt(h22); e1,e2=np.sqrt(1-h12),np.sqrt(1-h22)
    print("  h1^2=%.2f h2^2=%.2f: h1h2=%.4f e1e2=%.4f  rA 的最大可能权重占比 %.3f"%(h12,h22,h1*h2,e1*e2,h1*h2/(h1*h2+e1*e2)))
