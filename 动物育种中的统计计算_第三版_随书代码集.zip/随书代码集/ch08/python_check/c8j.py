# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8j.py    依赖：numpy, scipy
import numpy as np
def se_formula(s,n,t): return (1-t)*(1+(n-1)*t)*np.sqrt(2.0/(n*(n-1)*(s-1)))
print("=== h2=0.20, n=20, 不同 SE 目标所需公畜数 ===")
for tgt in [0.10,0.05,0.03,0.02]:
    for s in range(3,10**7):
        if 4*se_formula(s,20,0.05)<=tgt: break
    print("   SE(h2)<=%.2f -> s=%5d 头公畜, %7d 条记录"%(tgt,s,s*20))
print("\n=== Robertson (1959) 近似 SE(rA) ===")
def se_rA(rA,h1,h2,s1,s2): return (1-rA**2)/np.sqrt(2)*np.sqrt(s1*s2/(h1*h2))
for rA,h1,h2,s1,s2 in [(-0.5,0.40,0.10,0.05,0.04),(-0.5,0.40,0.10,0.03,0.02),
                       (0.3,0.30,0.30,0.05,0.05),(0.8,0.30,0.25,0.06,0.05)]:
    print("   rA=%+.2f h1^2=%.2f h2^2=%.2f SE(h1^2)=%.2f SE(h2^2)=%.2f -> SE(rA)=%.4f"%(rA,h1,h2,s1,s2,se_rA(rA,h1,h2,s1,s2)))
print("\n=== CV_A 与 h2 的对照（两个 h2 相同但均值/方差不同的性状）===")
for mu,sP,h2 in [(6000.0,900.0,0.25),(12.0,2.6,0.25),(1.05,0.30,0.25)]:
    sA=np.sqrt(h2)*sP
    print("   mu=%8.2f sigmaP=%6.2f h2=%.2f -> sigmaA=%.4f  CV_A=%.4f (%.2f%%)  CV_P=%.4f"%(mu,sP,h2,sA,sA/mu,100*sA/mu,sP/mu))
print("\n=== 遗传进展（i=1.0, 单世代）: R = i h sigmaA / ... 只比较 i*sigmaA ===")
for mu,sP,h2 in [(6000.0,900.0,0.25),(12.0,2.6,0.25)]:
    sA=np.sqrt(h2)*sP; R=1.0*np.sqrt(h2)*sA
    print("   mu=%8.2f R(i=1)=%.4f 绝对量, 相对 %.4f%%"%(mu,R,100*R/mu))
print("\n=== 思考题 6：pi=0.05, h2obs=0.04 -> h2lia; 再换到 pi=0.20 ===")
from scipy.stats import norm
def fac(pi):
    t=norm.ppf(1-pi); z=norm.pdf(t); return z*z/(pi*(1-pi)),t,z
f5,t5,z5=fac(0.05); f2,t2,z2=fac(0.20)
hl=0.04/f5
print("   pi=0.05: t=%.5f z=%.5f factor=%.5f -> h2_lia=%.5f"%(t5,z5,f5,hl))
print("   pi=0.20: factor=%.5f -> h2_obs=%.5f"%(f2,hl*f2))
print("\n=== 思考题：h2=0.25, r=0.5, MPPA 权重与准确性 ===")
for n in [1,2,3,5,10]:
    w=n*0.5/(1+(n-1)*0.5); acc=np.sqrt(n*0.25/(1+(n-1)*0.5))
    print("   n=%2d  MPPA 权重=%.4f  用均值预测育种值的准确性 r=%.4f"%(n,w,acc))
