# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8c.py    依赖：numpy, sympy
import sympy as sp, numpy as np
a,d,p,F=sp.symbols('a d p F',positive=True); q=1-p
fr=[p**2+F*p*q, 2*p*q*(1-F), q**2+F*p*q]; vals=[a,d,-a]; zs=[2,1,0]
M=sp.expand(sum(f*v for f,v in zip(fr,vals)))
Ez=sp.expand(sum(f*z for f,z in zip(fr,zs)))
Vz=sp.simplify(sp.expand(sum(f*z**2 for f,z in zip(fr,zs))-Ez**2))
Cgz=sp.simplify(sp.expand(sum(f*v*z for f,v,z in zip(fr,vals,zs))-M*Ez))
beta=sp.simplify(Cgz/Vz)
print("E(z)=",sp.simplify(Ez)," Var(z)=",sp.factor(Vz))
print("Cov(G,z)=",sp.factor(Cgz))
print("beta_F =",sp.simplify(sp.factor(beta)))
vAF=sp.simplify(sp.factor(beta**2*Vz))
print("sigma_A^2(F) = beta^2 Var(z) =",sp.factor(vAF))
alpha=a+d*(q-p)
print("check F=0:",sp.simplify(sp.factor(vAF.subs(F,0)-2*p*q*alpha**2)))
print("check d=0:",sp.factor(sp.simplify(vAF.subs(d,0))))
# alpha_F
alphaF=sp.simplify(sp.factor(beta))
print("alpha_F =", sp.collect(sp.expand(alphaF),d))
# numeric demo
f=sp.lambdify((a,d,p,F),[M,Vz,beta,vAF],'numpy')
for Fv in [0,0.1,0.25]:
    Mv,Vzv,bv,vAv=f(10,4,0.6,Fv)
    # total genotypic variance
    frn=[0.6**2+Fv*0.24, 2*0.24*(1-Fv), 0.4**2+Fv*0.24]
    vv=[10,4,-10]; mu=sum(x*y for x,y in zip(frn,vv))
    vG=sum(x*(y-mu)**2 for x,y in zip(frn,vv))
    print("F=%.2f: M=%.4f Var(z)=%.4f alpha_F=%.4f sigma_A2=%.4f vG=%.4f resid(D)=%.4f  [(1+F)vA0=%.4f]"
          %(Fv,mu,Vzv,bv,vAv,vG,vG-vAv,(1+Fv)*40.6272))
