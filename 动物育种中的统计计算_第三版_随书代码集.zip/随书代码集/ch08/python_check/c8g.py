# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8g.py    依赖：numpy, scipy
import numpy as np, math
from scipy.stats import norm, multivariate_normal as mvn
# Mehler expansion check
def orth(t,rho): return mvn(mean=[0,0],cov=[[1,rho],[rho,1]]).cdf([-t,-t])
def herm(k,t):
    # probabilists' Hermite He_k
    H=[1.0,t]
    for n in range(1,10): H.append(t*H[n]-n*H[n-1])
    return H[k]
print("=== Mehler 展开验证 Cov = sum rho^k/k! [z He_{k-1}(t)]^2 ===")
for pi in [0.5,0.2,0.05,0.01]:
    t=norm.ppf(1-pi); z=norm.pdf(t)
    for rho in [0.05,0.15,0.30]:
        exact=orth(t,rho)-pi*pi
        s=sum(rho**k/math.factorial(k)*(z*herm(k-1,t))**2 for k in range(1,9))
        t1=rho*z*z; t2=t1*(1+rho*t*t/2)
        print("  pi=%.2f rho=%.2f: 精确=%.8f 级数(8项)=%.8f 一阶=%.8f 二阶近似=%.8f"%(pi,rho,exact,s,t1,t2))

print("\n=== 对数尺度 vs 原尺度：h2 的变化 (y=exp(mu+a+e)) ===")
print("  sa2   sl2   h2(log)  h2(原尺度)  CV_P(原)   相对变化")
for sa2,sl2 in [(0.025,0.05),(0.05,0.10),(0.125,0.25),(0.25,0.50),(0.5,1.0),(0.75,1.5)]:
    h2log=sa2/sl2
    h2obs=(np.exp(sa2)-1)/(np.exp(sl2)-1)
    cv=np.sqrt(np.exp(sl2)-1)
    print("  %.3f %.3f  %.4f    %.4f     %.4f    %+.1f%%"%(sa2,sl2,h2log,h2obs,cv,100*(h2obs/h2log-1)))

print("\n=== 计数性状：Poisson / 负二项 对数正态混合 ===")
def counts(lam_bar,sa2,se2,k=None):
    sl2=sa2+se2
    varlam=lam_bar**2*(np.exp(sl2)-1)
    EL2=lam_bar**2*np.exp(sl2)
    if k is None: vy=lam_bar+varlam                 # Poisson
    else:        vy=lam_bar+EL2/k+varlam            # NB with Var(y|lam)=lam+lam^2/k
    vA=lam_bar**2*(np.exp(sa2)-1)                   # Var(E(y|a))
    return vy,vA,vA/vy,sa2/sl2
print("  分布      lam   sa2   se2    Var(y)    Var(E(y|a))  h2_obs   h2_latent")
for lam in [12.0,3.0,1.0]:
    for sa2,se2 in [(0.05,0.05),(0.10,0.20)]:
        vy,vA,h2o,h2l=counts(lam,sa2,se2)
        print("  Poisson  %5.1f %.2f  %.2f  %9.4f  %9.4f   %.4f   %.4f"%(lam,sa2,se2,vy,vA,h2o,h2l))
for lam in [12.0,3.0]:
    for kk in [5.0,10.0]:
        vy,vA,h2o,h2l=counts(lam,0.05,0.05,k=kk)
        print("  NB(k=%.0f) %5.1f %.2f  %.2f  %9.4f  %9.4f   %.4f   %.4f"%(kk,lam,0.05,0.05,vy,vA,h2o,h2l))
print("\n  Poisson 上限: 当 sa2->0, h2_obs ~ lam*sa2/(1+lam*sl2); 比值 h2_obs/h2_lat -> lam*sl2/(1+lam*sl2)")
for lam in [1,3,12,30]:
    for sl2 in [0.1,0.3]:
        print("     lam=%2d sl2=%.1f -> 比值上界 %.4f"%(lam,sl2,lam*sl2/(1+lam*sl2)))
