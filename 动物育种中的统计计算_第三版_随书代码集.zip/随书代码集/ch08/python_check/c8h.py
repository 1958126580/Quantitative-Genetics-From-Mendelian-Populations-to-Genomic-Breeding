# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8h.py    依赖：numpy
import numpy as np
rng=np.random.default_rng(7)
def sim(s,n,t,R=4000):
    est=[]
    for _ in range(R):
        a=rng.normal(0,np.sqrt(t),s)
        y=a[:,None]+rng.normal(0,np.sqrt(1-t),(s,n))
        gm=y.mean(); gmi=y.mean(1)
        MSB=n*((gmi-gm)**2).sum()/(s-1)
        MSW=((y-gmi[:,None])**2).sum()/(s*(n-1))
        est.append((MSB-MSW)/(MSB+(n-1)*MSW))
    est=np.array(est)
    return est.mean(),est.std(ddof=1)
def se_formula(s,n,t):
    return (1-t)*(1+(n-1)*t)*np.sqrt(2.0/(n*(n-1)*(s-1)))
print("=== 半同胞设计：组内相关 t 的抽样标准误（模拟 vs 公式）===")
print("  s(公畜) n(每头女儿)  t     均值(模拟)  SD(模拟)  公式SE    SE(h2=4t)")
for s,n,t in [(50,20,0.05),(100,20,0.05),(100,50,0.05),(200,50,0.05),(100,20,0.10),(500,100,0.05)]:
    m,sd=sim(s,n,t,R=3000)
    f=se_formula(s,n,t)
    print("  %5d %8d  %.3f   %.5f   %.5f   %.5f   模拟 %.4f / 公式 %.4f"%(s,n,t,m,sd,f,4*sd,4*f))
print("\n=== 要使 SE(h2)=0.05（h2=0.20,t=0.05），需要多少公畜 x 女儿 ===")
for n in [10,20,50,100]:
    # solve for s
    for s in range(5,100000):
        if 4*se_formula(s,n,0.05)<=0.05: break
    print("   每头公畜 %3d 头女儿 -> 需要 %5d 头公畜, 共 %7d 条记录"%(n,s,s*n))
