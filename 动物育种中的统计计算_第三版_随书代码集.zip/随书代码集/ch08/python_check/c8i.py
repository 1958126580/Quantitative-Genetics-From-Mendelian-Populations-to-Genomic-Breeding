# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 8 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c8i.py    依赖：numpy
import numpy as np
def se_formula(s,n,t): return (1-t)*(1+(n-1)*t)*np.sqrt(2.0/(n*(n-1)*(s-1)))
print("=== 达到 SE(h2)=0.05 所需记录总数随家系含量的变化 (h2=0.20, t=0.05) ===")
best=None
for n in [5,10,15,20,25,30,40,50,75,100,200]:
    for s in range(3,200000):
        if 4*se_formula(s,n,0.05)<=0.05: break
    tot=s*n
    print("   n=%4d  s=%6d  总记录 %7d"%(n,s,tot))
print("=== 不同 h2 下使总记录最少的 n（网格搜索）===")
for h2 in [0.05,0.10,0.20,0.40]:
    t=h2/4; bn,bt=None,10**18
    for n in range(2,4001):
        for s in range(3,10**7):
            if 4*se_formula(s,n,t)<=0.05: break
        if s*n<bt: bt,bn=s*n,n
    print("   h2=%.2f (t=%.4f): 最优 n=%d, 总记录=%d, 4/h2=%.0f, 1/t=%.0f"%(h2,t,bn,bt,4/h2,1/t))

print("\n=== 母体效应：sigma_P^2 = s2d + s2m + sdm + s2pe + s2e 模拟验证 ===")
rng=np.random.default_rng(3)
s2d,s2m,sdm,s2pe,s2e=1.0,0.6,-0.4,0.3,2.0
G0=np.array([[s2d,sdm],[sdm,s2m]])
N=400000
# unrelated sires and dams (base), offspring
L=np.linalg.cholesky(G0)
sire=(L@rng.normal(size=(2,N))).T
dam=(L@rng.normal(size=(2,N))).T
mend=(L@rng.normal(size=(2,N))).T*np.sqrt(0.5)
off=0.5*sire+0.5*dam+mend
pe=rng.normal(0,np.sqrt(s2pe),N); e=rng.normal(0,np.sqrt(s2e),N)
P=off[:,0]+dam[:,1]+pe+e
print("   模拟 Var(P)=%.4f   理论 s2d+s2m+sdm+s2pe+s2e=%.4f"%(P.var(),s2d+s2m+sdm+s2pe+s2e))
print("   直接遗传力 h2_d=%.4f  母体遗传力 h2_m=%.4f  总体遗传方差 sigma_T^2=%.4f (h2_T=%.4f)"%(
    s2d/P.var(),s2m/P.var(),s2d+sdm+0.25*s2m,(s2d+sdm+0.25*s2m)/P.var()))
print("   若忽略母体效应而把它并入残差：表观 h2 = %.4f"%(s2d/P.var()))

print("\n=== 显性关系系数 d_xy = 1/4 (a_ss a_dd + a_sd a_ds) ===")
rels={'亲子':(0.5,0.0,0.0,0.5),'全同胞':(1.0,1.0,0.0,0.0),'半同胞（同父）':(1.0,0.0,0.0,0.0),
      '全同胞的后代（叔侄）':(0.5,0.0,0.0,0.25),'一级堂表':(0.25,0.25,0.0,0.0)}
for k,(a1,a2,a3,a4) in rels.items():
    print("   %-22s d = %.4f"%(k,0.25*(a1*a2+a3*a4)))
