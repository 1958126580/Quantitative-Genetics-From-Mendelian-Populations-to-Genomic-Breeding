# 本脚本由 tools/nb2jl.py 从同目录的 ch08.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 08

# %% [markdown]
# # 第八章　数量性状的遗传模型 —— 配套代码
#
# 本笔记本的核心是**数值验证第八章的每一个方差剖分公式**，并用模拟展示它们的实际含义。

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions
rng = Xoshiro(20260918)

# %% [markdown]
# ## 1　单位点模型：基因型值、平均效应、育种值（正文 §8.1）

# %%
"""
    single_locus(a, d, p)

返回单位点模型的全部量：群体均值 M、替代效应 α、三种基因型的育种值 A 与显性偏差 D、
以及 σ²A、σ²D。基因型顺序为 (A₁A₁, A₁A₂, A₂A₂)。
"""
function single_locus(a::Float64, d::Float64, p::Float64)
    q = 1 - p
    freq = (p^2, 2p*q, q^2)
    G    = (a, d, -a)
    M    = a*(p - q) + 2p*q*d
    α    = a + d*(q - p)
    A    = (2q*α, (q - p)*α, -2p*α)
    Dv   = ntuple(k -> (G[k] - M) - A[k], 3)
    σ²A  = sum(freq[k]*A[k]^2  for k in 1:3)
    σ²D  = sum(freq[k]*Dv[k]^2 for k in 1:3)
    covAD = sum(freq[k]*A[k]*Dv[k] for k in 1:3)
    σ²G  = sum(freq[k]*(G[k]-M)^2 for k in 1:3)
    return (M=M, α=α, A=A, D=Dv, σ²A=σ²A, σ²D=σ²D, covAD=covAD, σ²G=σ²G)
end

r = single_locus(10.0, 10.0, 0.9)   # 完全显性，p = 0.9（思考题 3）
@printf("a=10, d=10, p=0.9\n")
@printf("  群体均值 M          = %.6f   （式 8.1 验证: %.6f）\n", r.M, 10*(0.9-0.1)+2*0.9*0.1*10)
@printf("  替代效应 α          = %.6f   （式 8.2 验证: %.6f）\n", r.α, 10 + 10*(0.1-0.9))
@printf("  育种值 (A₁A₁,A₁A₂,A₂A₂) = (%.4f, %.4f, %.4f)\n", r.A...)
@printf("  显性偏差            = (%.4f, %.4f, %.4f)\n", r.D...)
@printf("  σ²A = %.6f   （式 8.6: 2pqα² = %.6f）\n", r.σ²A, 2*0.9*0.1*r.α^2)
@printf("  σ²D = %.6f   （式 8.7: (2pqd)² = %.6f）\n", r.σ²D, (2*0.9*0.1*10)^2)
@printf("  Cov(A,D) = %.3e   ← 正交性（本章核心定理）\n", r.covAD)
@printf("  σ²G = σ²A + σ²D ?   %.6f = %.6f  %s\n", r.σ²G, r.σ²A + r.σ²D,
        isapprox(r.σ²G, r.σ²A + r.σ²D; rtol=1e-12) ? "✓" : "✗")

# %% [markdown]
# ### 1.1 "显性也贡献加性方差"（正文 §8.1.3 要点 3）

# %%
println("超显性但 a = 0 的位点：")
for p in (0.5, 0.7, 0.9, 0.99)
    rr = single_locus(0.0, 5.0, p)
    @printf("  p=%.2f  α = %+.4f   σ²A = %.4f   σ²D = %.4f   σ²A/σ²G = %.3f\n",
            p, rr.α, rr.σ²A, rr.σ²D, rr.σ²A/rr.σ²G)
end
println("→ a=0 时只要 p≠q 就有 α≠0：显性效应贡献加性方差。")
println()
println("完全显性位点（d=a）的 σ²A/σ²D 随 q 的变化（思考题 2）：")
for q in (0.5, 0.3, 0.1, 0.05, 0.01)
    rr = single_locus(1.0, 1.0, 1-q)
    @printf("  q=%.3f   σ²A/σ²D = %8.2f   σ²A 占 σ²G 的 %.1f%%\n",
            q, rr.σ²A/rr.σ²D, 100*rr.σ²A/rr.σ²G)
end
println("→ 低频隐性基因时加性方差绝对主导 —— 这就是“加性模型为什么有效”。")

# %% [markdown]
# ## 2　多位点：连锁平衡下的可加性与 LD 的影响（正文 §8.2）

# %%
"""模拟 m 个位点、n 个个体，验证 σ²A = Σ 2p q α²（连锁平衡）。"""
function multilocus_sim(m::Int, n::Int; d_frac=0.0, rng=Random.default_rng())
    p = 0.1 .+ 0.8 .* rand(rng, m)
    a = randn(rng, m)
    d = d_frac .* abs.(a) .* sign.(randn(rng, m))
    # 连锁平衡：各位点独立抽样
    Gt = [rand(rng) < p[j] ? 1 : 0 for i in 1:n, j in 1:m] .+
         [rand(rng) < p[j] ? 1 : 0 for i in 1:n, j in 1:m]   # 0/1/2
    # 基因型值
    gv(x, j) = x == 2 ? a[j] : (x == 1 ? d[j] : -a[j])
    G = [sum(gv(Gt[i,j], j) for j in 1:m) for i in 1:n]
    # 理论 σ²A、σ²D
    α = a .+ d .* (1 .- 2 .* p)
    σ²A_theo = sum(2 .* p .* (1 .- p) .* α.^2)
    σ²D_theo = sum((2 .* p .* (1 .- p) .* d).^2)
    return (G=G, σ²G_emp=var(G), σ²A=σ²A_theo, σ²D=σ²D_theo, p=p, α=α)
end

for (nm, df) in (("纯加性 (d=0)", 0.0), ("部分显性 (d=0.5|a|)", 0.5), ("完全显性 (d=|a|)", 1.0))
    s = multilocus_sim(300, 50_000; d_frac=df, rng=Xoshiro(3))
    @printf("%-22s 模拟 σ²G = %8.3f   理论 σ²A+σ²D = %8.3f   σ²A 占比 %.3f\n",
            nm, s.σ²G_emp, s.σ²A + s.σ²D, s.σ²A/(s.σ²A+s.σ²D))
end
println("\n→ 连锁平衡下方差可加（式 8.8）。即使完全显性，加性方差仍占主导。")

# %% [markdown]
# ## 3　遗传参数：重复力、$h^2_{(n)}$ 与表型相关（正文 §8.4）

# %%
h2n(h², r, n) = n*h²/(1 + (n-1)*r)

println("【n 次测量均值的遗传力】（式 8.20）h² = 0.25, r = 0.50")
println(rpad("n", 6), rpad("h²₍ₙ₎", 12), "距上限 h²/r 的差")
println("-"^40)
lim = 0.25/0.50
for n in (1,2,3,5,10,20,50,100)
    v = h2n(0.25, 0.50, n)
    @printf("%-6d%-12.4f%.4f\n", n, v, lim - v)
end
@printf("上限 h²/r = %.4f\n", lim)
@printf("→ 从 3 次到 10 次只提升 %.3f，通常不值得。\n", h2n(0.25,0.5,10) - h2n(0.25,0.5,3))

println("\n【r ≥ h² 是恒等关系】（第二版勘误 1-8）")
for (σ²a, σ²pe, σ²e) in ((1.0, 0.0, 3.0), (1.0, 0.5, 2.5), (1.0, 2.0, 1.0))
    σ²P = σ²a + σ²pe + σ²e
    @printf("  σ²a=%.1f σ²pe=%.1f σ²e=%.1f  →  h²=%.4f  r=%.4f  r−h²=%.4f\n",
            σ²a, σ²pe, σ²e, σ²a/σ²P, (σ²a+σ²pe)/σ²P, σ²pe/σ²P)
end
println("→ r − h² = σ²pe/σ²P ≥ 0 恒成立（正文定理）。")

println("\n【表型相关可能与遗传相关符号相反】（式 8.23，思考题 5）")
hX, hY, rA, rE = sqrt(0.4), sqrt(0.1), -0.5, 0.3
eX, eY = sqrt(1-0.4), sqrt(1-0.1)
rP = hX*hY*rA + eX*eY*rE
@printf("  h²X=0.4, h²Y=0.1, r_A=%+.1f, r_E=%+.1f  →  r_P = %+.4f\n", rA, rE, rP)
println("  → 遗传相关是负的，表型相关却是正的。用 r_P 做育种决策会完全错误。")

# %% [markdown]
# ## 4　阈性状的尺度转换（正文式 8.25）

# %%
"""观测尺度 ↔ 潜在尺度遗传力的转换（式 8.25）。"""
function liability_scale(h²_obs, π)
    z = pdf(Normal(), quantile(Normal(), 1 - π))
    return h²_obs * π*(1-π) / z^2, z
end
function observed_scale(h²_liab, π)
    z = pdf(Normal(), quantile(Normal(), 1 - π))
    return h²_liab * z^2 / (π*(1-π)), z
end

println("h²_潜在 = 0.25 时，观测尺度的遗传力随发生率变化：")
println(rpad("发生率 π", 12), rpad("z", 10), rpad("z²/[π(1−π)]", 16), "h²_观测")
println("-"^52)
for π in (0.5, 0.3, 0.2, 0.1, 0.05, 0.01)
    ho, z = observed_scale(0.25, π)
    @printf("%-12.2f%-10.4f%-16.4f%.4f\n", π, z, z^2/(π*(1-π)), ho)
end
println("\n【思考题 6】发生率 5%、观测遗传力 0.04：")
hl, _ = liability_scale(0.04, 0.05)
@printf("  潜在尺度遗传力 = %.4f\n", hl)
ho2, _ = observed_scale(hl, 0.20)
@printf("  同一潜在遗传力在发生率 20%% 的群体中，观测遗传力 = %.4f\n", ho2)
println("\n→ 报告阈性状遗传力必须注明尺度与发生率。")

# %% [markdown]
# ### 4.1 阈模型的模拟验证

# %%
"""模拟阈性状并用观测尺度估计遗传力，验证式 (8.25)。"""
function threshold_sim(n::Int, h²_liab::Float64, π::Float64; nfam=500, rng=Random.default_rng())
    # 半同胞设计：nfam 个公畜，每个 n/nfam 个后代
    k = n ÷ nfam
    σ²s = h²_liab/4                 # 公畜方差 = 1/4 加性方差（潜在尺度总方差 = 1）
    s = randn(rng, nfam) .* sqrt(σ²s)
    ℓ = repeat(s, inner=k) .+ randn(rng, nfam*k) .* sqrt(1 - σ²s)
    t = quantile(Normal(), 1 - π)
    y = Float64.(ℓ .> t)
    # 半同胞组内相关 → 观测尺度遗传力
    fam = repeat(1:nfam, inner=k)
    ȳ  = mean(y); ȳi = [mean(y[fam .== i]) for i in 1:nfam]
    MSA = k*sum((ȳi .- ȳ).^2)/(nfam-1)
    MSE = sum((y .- ȳi[fam]).^2)/(nfam*(k-1))
    σ²s_obs = (MSA - MSE)/k
    return 4*σ²s_obs/(σ²s_obs + MSE)
end

println(rpad("π", 10), rpad("h²_潜在", 12), rpad("h²_观测(模拟)", 16), "h²_观测(理论)")
println("-"^56)
for π in (0.5, 0.2, 0.05)
    hsim = threshold_sim(100_000, 0.25, π; rng=Xoshiro(11))
    hthe, _ = observed_scale(0.25, π)
    @printf("%-10.2f%-12.2f%-16.4f%.4f\n", π, 0.25, hsim, hthe)
end
println("\n→ 模拟结果与式 (8.25) 的理论预测一致。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **式 (8.1)、(8.2)、(8.6)、(8.7) 与 $\mathrm{Cov}(A,D)=0$ 全部数值验证通过。**
# 2. **$a=0$ 但 $p\ne q$ 时 $\alpha\ne0$**：显性效应贡献加性方差。
# 3. **低频隐性基因时 $\sigma_A^2/\sigma_D^2$ 极大**——这是加性模型有效的定量解释。
# 4. **$r-h^2=\sigma_{pe}^2/\sigma_P^2\ge0$ 是恒等关系**（第二版勘误 1‑8）。
# 5. **表型相关可能与遗传相关符号相反**——不能用 $r_P$ 代替 $r_A$ 做决策。
# 6. **阈性状的观测遗传力随发生率急剧下降**，模拟验证了式 (8.25)。
