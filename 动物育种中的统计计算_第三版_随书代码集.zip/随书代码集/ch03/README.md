# 第三章　数值线性代数与矩阵计算 —— 配套代码

**所属**：第一篇　计算基础与 Julia 语言　　**对应正文**：第三章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch03.ipynb` | IJulia 笔记本：14 个代码单元，约 348 行 Julia 代码，穿插与正文对应的说明 |
| `ch03.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 7 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　浮点误差
  - 1.1 灾难性抵消：方差的三种算法（正文 §3.1.3）
  - 1.2 条件数与误差放大（正文式 3.2）
  - 1.3 混合模型的条件数随遗传力如何变化（思考题 2）
  - 1.4 求和误差与补偿求和（正文 §3.1.4）
- 2　矩阵分解
  - 2.1 Cholesky：原理实现与 LAPACK 对照（正文 §3.2.2）
  - 2.2 LDLᵀ 与 Cholesky 的关系：验证式 (3.10)
  - 2.3 为什么最小二乘要用 QR：条件数的平方（正文式 3.11）
- 3　广义逆与可估函数（正文 §3.3）
- 4　稀疏矩阵：填入与重排序（正文 §3.4.4）
- 5　Kronecker 积与矩阵微分的数值验证（正文 §3.5）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 03
```

或在 Jupyter 中打开 `ch03/ch03.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
