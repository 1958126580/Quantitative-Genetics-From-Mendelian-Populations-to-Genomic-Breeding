# 本脚本由 tools/nb2jl.py 从同目录的 ch03.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 03

# %% [markdown]
# # 第三章　数值线性代数与矩阵计算 —— 配套代码
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | 浮点误差：条件数、灾难性抵消、求和 | §3.1 |
# | 2 | 矩阵分解：四种分解的原理实现与 LAPACK 对照 | §3.2 |
# | 3 | 广义逆与可估函数 | §3.3 |
# | 4 | 稀疏矩阵：格式、填入、重排序 | §3.4 |
# | 5 | Kronecker 积与矩阵微分的数值验证 | §3.5 |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics
using BenchmarkTools
BLAS.set_num_threads(1)
rng = Xoshiro(20260918)
@printf("机器精度 ε = %.6e\n", eps(Float64))
@printf("单位舍入 u = %.6e\n", eps(Float64)/2)

# %% [markdown]
# ## 1　浮点误差
#
# ### 1.1 灾难性抵消：方差的三种算法（正文 §3.1.3）

# %%
# 【原理实现 · 有缺陷】一遍公式 (3.5)
function var_naive(x)
    n = length(x); s1 = zero(eltype(x)); s2 = zero(eltype(x))
    for xi in x; s1 += xi; s2 += xi*xi; end
    return (s2 - s1^2/n) / (n - 1)
end

# 【两遍算法】公式 (3.6)
function var_twopass(x)
    n = length(x); m = sum(x)/n; s = zero(eltype(x))
    for xi in x; s += (xi - m)^2; end
    return s / (n - 1)
end

# 【Welford 递推】公式 (3.7) —— 一遍且稳定
function var_welford(x)
    n = 0; m = zero(eltype(x)); M2 = zero(eltype(x))
    for xi in x
        n += 1
        d  = xi - m
        m += d / n
        M2 += d * (xi - m)
    end
    return M2 / (n - 1)
end

# 病态数据：均值很大、变异很小（如体重 500 kg ± 5 kg 的极端版本）
for μ in (1e2, 1e6, 1e8, 1e9)
    x = μ .+ randn(rng, 100_000)          # 真方差 ≈ 1
    @printf("μ=%.0e  naive=%14.6f  twopass=%10.6f  welford=%10.6f\n",
            μ, var_naive(x), var_twopass(x), var_welford(x))
end
println()
println("→ 一遍公式 (3.5) 在 μ 很大时完全失效，甚至给出负方差。")
println("  Welford 递推兼顾一遍与稳定，是本书推荐的写法。")

# %% [markdown]
# ### 1.2 条件数与误差放大（正文式 3.2）

# %%
# 构造条件数可控的对称正定矩阵
function make_spd(n, κ; rng=Random.default_rng())
    Q, _ = qr(randn(rng, n, n)); Q = Matrix(Q)
    λ = exp.(range(0, log(κ); length=n))      # 特征值从 1 到 κ
    return Symmetric(Q * Diagonal(λ) * Q')
end

n = 200
println(rpad("κ(A)", 12), rpad("实际相对误差", 18), "式(3.2) 的上界")
println("-"^54)
for κ in (1e2, 1e6, 1e10, 1e14)
    A  = make_spd(n, κ; rng=rng)
    x  = randn(rng, n)
    b  = A * x
    δb = 1e-12 * norm(b) * normalize(randn(rng, n))     # 相对扰动 1e-12
    x̃  = A \ (b + δb)
    err = norm(x̃ - x) / norm(x)
    @printf("%-12.0e%-18.3e%.3e\n", κ, err, cond(Matrix(A)) * 1e-12)
end
println()
println("→ 实际误差被条件数放大，且不超过式 (3.2) 的上界。")

# %% [markdown]
# ### 1.3 混合模型的条件数随遗传力如何变化（思考题 2）

# %%
# 一个玩具动物模型：n 个体，每个体一条记录，仅截距
function toy_mme_cond(n::Int, h²::Float64, Ainv::AbstractMatrix)
    λ = (1 - h²) / h²
    X = ones(n, 1); Z = Matrix(1.0I, n, n)
    C = [X'X  X'Z; Z'X  Z'Z + λ*Ainv]
    return cond(C), λ
end

# 用一个简单的随机系谱构建 A⁻¹（复用第一章的函数思路）
function simple_Ainv(n::Int; rng=Random.default_rng())
    sire = zeros(Int, n); dam = zeros(Int, n)
    for i in 11:n; sire[i] = rand(rng, 1:i-1); dam[i] = rand(rng, 1:i-1); end
    I_, J_, V_ = Int[], Int[], Float64[]
    F = zeros(n)                      # 演示用，近似为 0
    for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;     q = (-0.5,-0.5,1.0); δ = 0.5
        elseif s>0;        q = (-0.5, 0.0,1.0); δ = 0.75
        elseif d>0;        q = ( 0.0,-0.5,1.0); δ = 0.75
        else;              q = ( 0.0, 0.0,1.0); δ = 1.0
        end
        b = 1/δ
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_, pos[a]); push!(J_, pos[c]); push!(V_, q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

Ai = Matrix(simple_Ainv(150; rng=rng))
println(rpad("h²", 8), rpad("λ", 10), "κ(C)")
println("-"^34)
for h² in (0.8, 0.5, 0.25, 0.10, 0.05, 0.02)
    κ, λ = toy_mme_cond(150, h², Ai)
    @printf("%-8.2f%-10.1f%.3e\n", h², λ, κ)
end
println()
println("→ 遗传力越低，λ 越大，系数矩阵越病态 —— 这是第十五章必须讲预处理的原因。")

# %% [markdown]
# ### 1.4 求和误差与补偿求和（正文 §3.1.4）

# %%
function sum_naive(x)
    s = zero(eltype(x)); for xi in x; s += xi; end; s
end

function sum_kahan(x)                      # Kahan 补偿求和
    s = zero(eltype(x)); c = zero(eltype(x))
    for xi in x
        y = xi - c
        t = s + y
        c = (t - s) - y
        s = t
    end
    return s
end

# 构造一个求和误差明显的例子：大数 + 大量小数
x = vcat(1e16, ones(10^7))                 # 精确和 = 1e16 + 1e7
exact = big(1e16) + big(10^7)
for (name, f) in (("朴素累加", sum_naive), ("成对求和(Base.sum)", sum), ("Kahan 补偿", sum_kahan))
    v = f(x)
    @printf("%-22s = %.6f   相对误差 %.3e\n", name, v, abs(big(v)-exact)/exact)
end
println()
println("→ 朴素累加把 1e7 个 1 全部丢失；成对与 Kahan 都能保住。")

# %% [markdown]
# ## 2　矩阵分解
#
# ### 2.1 Cholesky：原理实现与 LAPACK 对照（正文 §3.2.2）

# %%
# 【原理实现】按正文的分块递推，逐列计算
function chol_naive(A::AbstractMatrix{T}) where {T}
    n = size(A, 1)
    L = zeros(T, n, n)
    for j in 1:n
        s = A[j, j] - sum(L[j, k]^2 for k in 1:j-1; init=zero(T))
        s > 0 || error("矩阵非正定：第 $j 个主元为 $s")
        L[j, j] = sqrt(s)
        for i in j+1:n
            L[i, j] = (A[i, j] - sum(L[i, k]*L[j, k] for k in 1:j-1; init=zero(T))) / L[j, j]
        end
    end
    return LowerTriangular(L)
end

A = make_spd(300, 1e4; rng=rng)
L1 = chol_naive(Matrix(A))
L2 = cholesky(A).L                       # LAPACK

@printf("【对照验证】‖L_naive − L_LAPACK‖ / ‖L‖ = %.3e\n", norm(L1-L2)/norm(L2))
@printf("【对照验证】‖L L' − A‖ / ‖A‖          = %.3e\n", norm(L1*L1' - A)/norm(A))
@printf("原理实现 : %8.2f ms\n", (@belapsed chol_naive($(Matrix(A))))*1e3)
@printf("LAPACK   : %8.2f ms   （加速 %.0f×）\n",
        (@belapsed cholesky($A))*1e3,
        (@belapsed chol_naive($(Matrix(A)))) / (@belapsed cholesky($A)))

# %% [markdown]
# ### 2.2 LDLᵀ 与 Cholesky 的关系：验证式 (3.10)
#
# **这是第二版勘误 1‑1 的数值证明。**

# %%
# LDL' 分解（单位下三角 T，对角 D）
function ldl_naive(A::AbstractMatrix{T}) where {T}
    n = size(A,1); L = Matrix{T}(I, n, n); d = zeros(T, n)
    for j in 1:n
        d[j] = A[j,j] - sum(L[j,k]^2 * d[k] for k in 1:j-1; init=zero(T))
        for i in j+1:n
            L[i,j] = (A[i,j] - sum(L[i,k]*L[j,k]*d[k] for k in 1:j-1; init=zero(T))) / d[j]
        end
    end
    return UnitLowerTriangular(L), Diagonal(d)
end

A5 = make_spd(5, 100; rng=rng)
T5, D5 = ldl_naive(Matrix(A5))
Lc     = cholesky(A5).L

println("验证 A = T D T'          : ", isapprox(T5*D5*T5', A5; rtol=1e-10) ? "✓" : "✗")
println("验证 L_chol = T · D^{1/2}: ", isapprox(Matrix(T5)*sqrt.(D5), Matrix(Lc); rtol=1e-10) ? "✓" : "✗")
println()
println("D 的对角元      : ", round.(diag(D5), digits=6))
println("L_chol 对角元   : ", round.(diag(Lc), digits=6))
println("L_chol 对角元的平方: ", round.(diag(Lc).^2, digits=6))
println()
println("→ d_i = l_ii²，不是 d_i = l_ii。第二版第 2 章此处有误（勘误 1-1）。")

# %% [markdown]
# ### 2.3 为什么最小二乘要用 QR：条件数的平方（正文式 3.11）

# %%
# 构造一个条件数可控的设计矩阵
function make_X(n, p, κ; rng=Random.default_rng())
    U, _ = qr(randn(rng, n, p)); U = Matrix(U)[:, 1:p]
    V, _ = qr(randn(rng, p, p)); V = Matrix(V)
    σ = exp.(range(0, -log(κ); length=p))
    return U * Diagonal(σ) * V'
end

println(rpad("κ(X)", 10), rpad("κ(X'X)", 12), rpad("正规方程误差", 16), "QR 误差")
println("-"^56)
for κ in (1e2, 1e4, 1e6, 1e8)
    X = make_X(500, 20, κ; rng=rng)
    β = randn(rng, 20)
    y = X * β                                # 无噪声，真解已知
    β_ne = (X'X) \ (X'y)                     # 正规方程
    β_qr = qr(X, ColumnNorm()) \ y           # QR
    @printf("%-10.0e%-12.1e%-16.3e%.3e\n", κ, cond(X'X),
            norm(β_ne-β)/norm(β), norm(β_qr-β)/norm(β))
end
println()
println("→ 正规方程的误差按 κ² 增长，QR 按 κ 增长（式 3.11）。")
println("  但育种 MME 因 G⁻¹ 的正则化作用而可用正规方程，见正文 §3.2.4。")

# %% [markdown]
# ## 3　广义逆与可估函数（正文 §3.3）

# %%
# 一个典型的秩亏育种设计：截距 + 一个 3 水平因子
n = 12
herd = repeat(1:3, inner=4)
X = hcat(ones(n), Float64.(herd .== 1), Float64.(herd .== 2), Float64.(herd .== 3))
y = 10.0 .+ [2.0, -1.0, 0.5][herd] .+ 0.1 .* randn(rng, n)

@printf("X 的秩 = %d，列数 = %d  ⇒ 秩亏 %d\n", rank(X), size(X,2), size(X,2)-rank(X))

# 三种不同的广义逆给出三个不同的"解"
β_pinv = pinv(X'X) * (X'y)                       # Moore–Penrose
β_bsl  = let                                     # "把第 1 水平固定为 0"
    Xr = X[:, [1,3,4]];  b = (Xr'Xr) \ (Xr'y);  [b[1], 0.0, b[2], b[3]]
end
β_bsl3 = let                                     # "把第 3 水平固定为 0"
    Xr = X[:, [1,2,3]];  b = (Xr'Xr) \ (Xr'y);  [b[1], b[2], b[3], 0.0]
end

println("\n三个'解'（完全不同）:")
for (nm, b) in (("pinv", β_pinv), ("固定水平1=0", β_bsl), ("固定水平3=0", β_bsl3))
    @printf("  %-14s μ=%8.4f  h1=%8.4f  h2=%8.4f  h3=%8.4f\n", nm, b...)
end

println("\n但可估函数的值完全相同：")
K = [0.0 1.0 -1.0 0.0;      # h1 − h2（对比，可估）
     0.0 1.0  0.0 -1.0;     # h1 − h3
     1.0 1.0  0.0  0.0]     # μ + h1（最小二乘均值，可估）
for (i, nm) in enumerate(("h₁ − h₂", "h₁ − h₃", "μ + h₁"))
    @printf("  %-10s : %10.6f  %10.6f  %10.6f\n", nm,
            dot(K[i,:], β_pinv), dot(K[i,:], β_bsl), dot(K[i,:], β_bsl3))
end

println("\n不可估函数（如单独的 h₁）:")
k = [0.0, 1.0, 0.0, 0.0]
@printf("  h₁ 单独    : %10.6f  %10.6f  %10.6f   ← 三者不同！\n",
        dot(k,β_pinv), dot(k,β_bsl), dot(k,β_bsl3))

# 可估性判别：k ∈ C(X')  ⇔  k'H = k'，其中 H = (X'X)⁻(X'X)
H = pinv(X'X) * (X'X)
println("\n可估性判别（式 3.15）:")
for (nm, kk) in (("h₁ − h₂", K[1,:]), ("μ + h₁", K[3,:]), ("h₁ 单独", k))
    @printf("  %-10s : ‖k'H − k'‖ = %.3e  ⇒ %s\n",
            nm, norm(kk'H - kk'), norm(kk'H - kk') < 1e-10 ? "可估 ✓" : "不可估 ✗")
end

# %% [markdown]
# > **这是本书反复强调的结论**：育种数据分析中，固定效应的**绝对值不可报告**，**对比与最小二乘均值才可报告**。
#
# ## 4　稀疏矩阵：填入与重排序（正文 §3.4.4）

# %%
# 箭头矩阵：自然顺序 vs 逆序（思考题 5）
function arrow_matrix(n)
    I_ = vcat(1:n, fill(1, n-1), 2:n)
    J_ = vcat(1:n, 2:n, fill(1, n-1))
    V_ = vcat(fill(Float64(n), n), fill(1.0, n-1), fill(1.0, n-1))
    return sparse(I_, J_, V_, n, n)
end

n = 800
A_arrow = arrow_matrix(n)
perm_rev = collect(n:-1:1)                       # 把第 1 个变量排到最后
A_perm   = A_arrow[perm_rev, perm_rev]

F1 = cholesky(Symmetric(A_arrow); perm = collect(1:n))   # 强制自然顺序
F2 = cholesky(Symmetric(A_perm);  perm = collect(1:n))   # 逆序
F3 = cholesky(Symmetric(A_arrow))                        # 让 CHOLMOD 自动重排（AMD）

@printf("原矩阵下三角非零元         : %d\n", nnz(tril(A_arrow)))
@printf("自然顺序分解后 L 的非零元   : %d   （填入 %d）\n", nnz(sparse(F1.L)), nnz(sparse(F1.L))-nnz(tril(A_arrow)))
@printf("逆序分解后   L 的非零元     : %d   （填入 %d）\n", nnz(sparse(F2.L)), nnz(sparse(F2.L))-nnz(tril(A_perm)))
@printf("CHOLMOD 自动重排后 L 非零元 : %d\n", nnz(sparse(F3.L)))
println()
println("→ 同一个矩阵，排序不同，填入从 O(n²) 变成 O(n)。")
println("  这就是第十五章重排序算法的价值。")

# %%
# 三元组装配 vs 逐元素插入（正文 §3.4.3，再次强调）
function assemble_coo(I_, J_, V_, n)
    return sparse(I_, J_, V_, n, n)
end
function assemble_incr(I_, J_, V_, n)
    S = spzeros(n, n)
    @inbounds for k in eachindex(I_); S[I_[k], J_[k]] += V_[k]; end
    return S
end

n = 5000; m = 50_000
I_ = rand(rng, 1:n, m); J_ = rand(rng, 1:n, m); V_ = randn(rng, m)
@assert assemble_coo(I_,J_,V_,n) ≈ assemble_incr(I_,J_,V_,n)    # 【对照验证】
t1 = @belapsed assemble_coo($I_,$J_,$V_,$n)  samples=3 evals=1
t2 = @belapsed assemble_incr($I_,$J_,$V_,$n) samples=3 evals=1
@printf("三元组一次构造 : %8.2f ms\n", t1*1e3)
@printf("逐元素插入     : %8.2f ms   （慢 %.0f×）\n", t2*1e3, t2/t1)

# %% [markdown]
# ## 5　Kronecker 积与矩阵微分的数值验证（正文 §3.5）

# %%
# 验证 Kronecker 性质 (3.19)–(3.24)
A = randn(rng, 4, 4); B = randn(rng, 3, 3)
C_ = randn(rng, 4, 4); D_ = randn(rng, 3, 3)

println("式 (3.19) (A⊗B)(C⊗D) = (AC)⊗(BD) : ",
        isapprox(kron(A,B)*kron(C_,D_), kron(A*C_, B*D_); rtol=1e-10) ? "✓" : "✗")
println("式 (3.20) (A⊗B)⁻¹ = A⁻¹⊗B⁻¹      : ",
        isapprox(inv(kron(A,B)), kron(inv(A), inv(B)); rtol=1e-8) ? "✓" : "✗")
println("式 (3.22) tr(A⊗B) = tr(A)tr(B)   : ",
        isapprox(tr(kron(A,B)), tr(A)*tr(B); rtol=1e-10) ? "✓" : "✗")
println("式 (3.23) |A⊗B| = |A|³|B|⁴       : ",
        isapprox(det(kron(A,B)), det(A)^3 * det(B)^4; rtol=1e-8) ? "✓" : "✗")

# 式 (3.25) vec(ABC) = (C'⊗A) vec(B)
A2 = randn(rng,3,4); B2 = randn(rng,4,5); C2 = randn(rng,5,2)
println("式 (3.25) vec(ABC) = (C'⊗A)vec(B): ",
        isapprox(vec(A2*B2*C2), kron(C2', A2)*vec(B2); rtol=1e-10) ? "✓" : "✗")

# 多性状模型中的实际意义：(G₀⊗A)⁻¹ = G₀⁻¹⊗A⁻¹
G₀ = [5.0 1.0; 1.0 1.0]          # 2 性状遗传方差协方差
Asm = make_spd(50, 50; rng=rng)
@printf("\n式 (3.24) 多性状: ‖(G₀⊗A)⁻¹ − G₀⁻¹⊗A⁻¹‖ = %.3e\n",
        norm(inv(kron(G₀, Matrix(Asm))) - kron(inv(G₀), inv(Matrix(Asm)))))
@printf("   直接求逆 %d×%d 与 分别求逆 %d×%d + %d×%d 的运算量比 ≈ %.0f×\n",
        100,100,2,2,50,50, (100^3)/(2^3 + 50^3))

# %%
# 矩阵微分公式 (3.31)-(3.33) 的数值验证（中心差分）
σa², σe² = 2.0, 3.0
nn = 40
Z  = Matrix(1.0I, nn, nn)
Aa = Matrix(make_spd(nn, 20; rng=rng))
V(θa, θe) = θa * (Z*Aa*Z') + θe * Matrix(1.0I, nn, nn)

Vc = V(σa², σe²)
V1 = Z*Aa*Z'                       # ∂V/∂σa²
h  = 1e-6

# (3.31) ∂V⁻¹/∂θ = −V⁻¹ (∂V/∂θ) V⁻¹
num  = (inv(V(σa²+h, σe²)) - inv(V(σa²-h, σe²))) / (2h)
anal = -inv(Vc) * V1 * inv(Vc)
@printf("式 (3.31) ∂V⁻¹/∂σa²  : 相对误差 %.3e\n", norm(num-anal)/norm(anal))

# (3.32) ∂log|V|/∂θ = tr(V⁻¹ ∂V/∂θ)
num2  = (logdet(V(σa²+h, σe²)) - logdet(V(σa²-h, σe²))) / (2h)
anal2 = tr(inv(Vc) * V1)
@printf("式 (3.32) ∂log|V|/∂σa²: 数值 %.8f，解析 %.8f，相对误差 %.3e\n",
        num2, anal2, abs(num2-anal2)/abs(anal2))

# (3.33) ∂(y'V⁻¹y)/∂θ
yv = randn(rng, nn)
num3  = (yv'*inv(V(σa²+h,σe²))*yv - yv'*inv(V(σa²-h,σe²))*yv) / (2h)
anal3 = -yv' * inv(Vc) * V1 * inv(Vc) * yv
@printf("式 (3.33) ∂(y'V⁻¹y)/∂σa²: 相对误差 %.3e\n", abs(num3-anal3)/abs(anal3))
println()
println("→ 这三个公式就是第十七、十八章 REML 推导的全部微分工具。")

# %%
# Woodbury 恒等式 (3.35) 与 SNP-BLUP ⇔ GBLUP 的等价性 (3.36)
nI, p = 120, 900                        # n ≪ p，典型的基因组预测情形
Zg = randn(rng, nI, p); λ = 4.0
yv = randn(rng, nI)

lhs = (Zg'Zg + λ*I) \ (Zg' * yv)        # p×p 求逆
rhs = Zg' * ((Zg*Zg' + λ*I) \ yv)       # n×n 求逆
@printf("式 (3.36) 两端相对差 = %.3e\n", norm(lhs-rhs)/norm(rhs))
@printf("运算量之比 ≈ (p/n)³ = %.0f×\n", (p/nI)^3)
t1 = @belapsed ($Zg'$Zg + $λ*I) \ ($Zg' * $yv)
t2 = @belapsed $Zg' * (($Zg*$Zg' + $λ*I) \ $yv)
@printf("实测 : p×p 路径 %.2f ms，n×n 路径 %.2f ms （加速 %.1f×）\n", t1*1e3, t2*1e3, t1/t2)
println()
println("→ 这就是第二十一章 SNP-BLUP 与 GBLUP 等价的代数根源。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **方差的一遍公式 (3.5) 在均值大时完全失效**；用两遍算法或 Welford 递推。同理，$\mathbf G$ 矩阵必须先中心化再相乘。
# 2. **条件数放大误差**：实测误差与式 (3.2) 的上界一致；混合模型的 $\kappa$ 随遗传力降低而急剧上升。
# 3. **$d_i = l_{ii}^2$**（式 3.10）已用数值验证——这是第二版勘误 1‑1 的直接证明。
# 4. 正规方程的误差按 $\kappa^2$ 增长、QR 按 $\kappa$ 增长；但育种 MME 因 $\mathbf G^{-1}$ 的正则化而可用正规方程。
# 5. **秩亏模型中，固定效应的绝对值随广义逆而变，对比与最小二乘均值不变**。可估性可用 $\mathbf k'\mathbf H=\mathbf k'$ 判别。
# 6. 同一个箭头矩阵，排序不同，填入从 $O(n^2)$ 变成 $O(n)$。
# 7. Kronecker 性质与三个矩阵微分公式均已数值验证；Woodbury 恒等式给出 SNP‑BLUP $\Leftrightarrow$ GBLUP 的等价性与 $(p/n)^3$ 的加速。
#
# **下一步**：`ch04.ipynb` 把这些工具用于性能工程——一个 $\mathbf G$ 矩阵构建函数的五级优化。
