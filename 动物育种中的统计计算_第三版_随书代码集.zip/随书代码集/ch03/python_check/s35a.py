# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 3 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s35a.py    依赖：numpy, scipy
"""Section 3.5 (a): numerical verification of the matrix-differential formulas with central differences.
Model y = X b + a + e, a ~ N(0, A s2a), e ~ N(0, I s2e); V = s2a*A + s2e*I  (Z = I).
Pedigree sim_ped(400, G=10, seed=20240905); X = [1, x], x ~ N(0,1);  data seed 20240906; truth (s2a, s2e) = (1, 2).
Evaluate at theta = (0.8, 1.7).
"""
import json, math, time
from c3common import *
import numpy as np, scipy.linalg as sl
from fmt import *

n = 400
sire, dam, gen = sim_ped(n, G=10, seed=20240905)
A = dense_A(sire, dam); F = np.diag(A) - 1.0
rng = np.random.default_rng(20240906)
x = rng.standard_normal(n)
X = np.column_stack([np.ones(n), x])
a = sim_breeding_values(sire, dam, F, 1.0, rng)
e = rng.standard_normal(n) * np.sqrt(2.0)
y = X @ np.array([10.0, 0.5]) + a + e
I = np.eye(n)
V1, V2 = A, I   # dV/ds2a, dV/ds2e


def Vof(th):
    return th[0] * A + th[1] * I


def logdet(V):
    c = np.linalg.cholesky(V)
    return 2.0 * np.sum(np.log(np.diag(c)))


def reml_ll(th):
    V = Vof(th)
    L = sl.cho_factor(V)
    Vi_X = sl.cho_solve(L, X)
    Vi_y = sl.cho_solve(L, y)
    XtViX = X.T @ Vi_X
    b = np.linalg.solve(XtViX, X.T @ Vi_y)
    r = y - X @ b
    Vi_r = sl.cho_solve(L, r)
    return -0.5 * (logdet(V) + logdet(XtViX) + r @ Vi_r)


def P_of(th):
    V = Vof(th)
    L = sl.cho_factor(V)
    Vi = sl.cho_solve(L, I)
    ViX = Vi @ X
    P = Vi - ViX @ np.linalg.solve(X.T @ ViX, ViX.T)
    return P, Vi


th0 = np.array([0.8, 1.7])
P, Vi = P_of(th0)
Vmat = Vof(th0)
# analytic quantities
an_logdet = [np.trace(Vi @ V1), np.trace(Vi @ V2)]
an_dVi = [-Vi @ V1 @ Vi, -Vi @ V2 @ Vi]
an_score = [-0.5 * (np.trace(P @ V1) - y @ P @ V1 @ P @ y), -0.5 * (np.trace(P @ V2) - y @ P @ V2 @ P @ y)]
# third derivative of logdet wrt s2a : 2 tr((Vi V1)^3)
M1 = Vi @ V1
f3 = 2.0 * np.trace(M1 @ M1 @ M1)
print("analytic: dlogdet/ds2a =", an_logdet[0], " dlogdet/ds2e =", an_logdet[1], " score =", an_score, " logdet'''_a =", f3)
print("log|V| =", logdet(Vmat), " l_R =", reml_ll(th0))

hrels = [10.0 ** (-k) for k in range(1, 14)]
rows = []
for hr in hrels:
    row = dict(h=hr)
    for i, Vi_ in enumerate([V1, V2]):
        h = hr * th0[i]
        e_i = np.zeros(2); e_i[i] = h
        thp, thm = th0 + e_i, th0 - e_i
        fd_ld = (logdet(Vof(thp)) - logdet(Vof(thm))) / (2 * h)
        row[f'ld{i}'] = abs(fd_ld - an_logdet[i]) / abs(an_logdet[i])
        Vip = np.linalg.inv(Vof(thp)); Vim = np.linalg.inv(Vof(thm))
        fd_dVi = (Vip - Vim) / (2 * h)
        row[f'dVi{i}'] = np.max(np.abs(fd_dVi - an_dVi[i])) / np.max(np.abs(an_dVi[i]))
        fd_sc = (reml_ll(thp) - reml_ll(thm)) / (2 * h)
        row[f'sc{i}'] = abs(fd_sc - an_score[i]) / abs(an_score[i])
        # 4th-order stencil
        e2 = np.zeros(2); e2[i] = 2 * h
        fd4_ld = (-logdet(Vof(th0 + e2)) + 8 * logdet(Vof(thp)) - 8 * logdet(Vof(thm)) + logdet(Vof(th0 - e2))) / (12 * h)
        row[f'ld4_{i}'] = abs(fd4_ld - an_logdet[i]) / abs(an_logdet[i])
    rows.append(row)
for r in rows:
    print(f"h_rel={r['h']:.0e}  logdet_a={r['ld0']:.2e} logdet_e={r['ld1']:.2e} | dVinv_a={r['dVi0']:.2e} dVinv_e={r['dVi1']:.2e} | score_a={r['sc0']:.2e} score_e={r['sc1']:.2e} | 4th-order logdet_a={r['ld4_0']:.2e}")
# optimum
for key in ['ld0', 'ld1', 'dVi0', 'dVi1', 'sc0', 'sc1', 'ld4_0']:
    j = min(range(len(rows)), key=lambda t: rows[t][key])
    print(key, "min error", f"{rows[j][key]:.2e}", "at h_rel", f"{rows[j]['h']:.0e}")
eps = 2.0 ** -52
print("eps^(1/3) =", eps ** (1 / 3), " eps^(2/3) =", eps ** (2 / 3), " eps^(1/5)=", eps ** 0.2, " eps^(4/5)=", eps ** 0.8)
json.dump(dict(rows=rows, an_logdet=[float(v) for v in an_logdet], an_score=[float(v) for v in an_score], f3=float(f3),
               logdet=float(logdet(Vmat)), ll=float(reml_ll(th0))), open("s35a.json", "w"), indent=1)
