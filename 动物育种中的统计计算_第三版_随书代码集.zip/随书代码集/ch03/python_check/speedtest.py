# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 3 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 speedtest.py    依赖：numpy
import os
for k in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS"): os.environ[k]="1"
import numpy as np, time, math
rng = np.random.default_rng(1)
x = rng.random(2_000_000)*3
# python float64 Kahan
def kahan64(chunk):
    s=0.0; c=0.0
    for v in chunk:
        y=v-c; t=s+y; c=(t-s)-y; s=t
    return s
t=time.time(); xs=x.tolist(); r=kahan64(xs); print("py float64 Kahan 2e6:", time.time()-t, "s")
# numpy float32 scalar Kahan
x32 = x.astype(np.float32)
def kahan32(arr):
    s=np.float32(0); c=np.float32(0)
    for v in arr:
        y=v-c; t=s+y; c=(t-s)-y; s=t
    return s
t=time.time(); r32=kahan32(x32[:500_000]); print("np float32 Kahan 5e5:", time.time()-t, "s")
# float32 emulation with struct? try iterating via tolist and float32 rounding by np.float32()
f32 = np.float32
def kahan32b(lst):
    s=f32(0); c=f32(0)
    for v in lst:
        y=f32(v)-c; t=s+y; c=(t-s)-y; s=t
    return s
t=time.time(); r=kahan32b(x32[:500_000].tolist()); print("np float32 Kahan (tolist) 5e5:", time.time()-t,"s")
t=time.time(); print(math.fsum(xs)); print("fsum 2e6:", time.time()-t)
