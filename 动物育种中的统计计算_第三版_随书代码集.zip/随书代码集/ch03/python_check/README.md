# 第 3 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch03/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `determ.py` | 数值复核 | numpy, scipy | 1.5 | `outputs/determ.out` |
| `determ2.py` | 数值复核 | numpy, scipy | 1.0 | `outputs/determ2.out` |
| `s31a2.py` | float32 breakdown scan + verification of the first-order bound eps <= kappa*eta*(1+\|xhat\|/\|x\|) | numpy, scipy | 23.8 | `outputs/s31a2.out` |
| `s31a_extra.py` | 数值复核 | numpy, scipy | 5.4 | `outputs/s31a_extra.out` |
| `s33.py` | Section 3.3: non-uniqueness of g-inverses on a small unbalanced 2x2 additive design (n=7). | numpy, scipy | 1.1 | `outputs/s33.out` |
| `s35a.py` | Section 3.5 (a): numerical verification of the matrix-differential formulas with central differences. | numpy, scipy | 4.9 | `outputs/s35a.out` |
| `speedtest.py` | python float64 Kahan | numpy | 1.8 | `outputs/speedtest.out` |

公共函数模块（被上列脚本导入，不单独运行）：`c3common.py`、`fmt.py`、`s31a.py`。
