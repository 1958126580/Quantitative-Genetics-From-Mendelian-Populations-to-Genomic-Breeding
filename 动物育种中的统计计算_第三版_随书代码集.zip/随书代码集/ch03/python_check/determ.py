# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 3 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 determ.py    依赖：numpy, scipy
from c3common import *
from s31a import solve_ref, LD
import numpy as np, scipy.linalg as sl, sys
n=1000; lam=1e-3
sire, dam, gen = sim_ped(n, G=10, seed=20240901)
A = dense_A(sire, dam); F = np.diag(A) - 1.0
Ai = Ainv_henderson(sire, dam, F).toarray()
rng = np.random.default_rng(20240902 + n * 1000 + int(lam * 10))
a = sim_breeding_values(sire, dam, F, 1.0, rng)
e = rng.standard_normal(n) * np.sqrt(lam)
y = 10.0 + a + e
C = np.block([[np.array([[float(n)]]), np.ones((1, n))], [np.ones((n, 1)), np.eye(n) + lam * Ai]])
b = np.concatenate([[y.sum()], y])
xref, Cl = solve_ref(C, b); nx = np.sqrt(np.sum(xref ** 2))
import hashlib
print("C hash", hashlib.md5(C.tobytes()).hexdigest(), "b hash", hashlib.md5(b.tobytes()).hexdigest())
for rep in range(3):
    x32 = sl.cho_solve(sl.cho_factor(C.astype(np.float32)), b.astype(np.float32))
    print(rep, float(np.sqrt(np.sum((x32.astype(LD) - xref) ** 2)) / nx), hashlib.md5(x32.tobytes()).hexdigest())
