# -*- coding: utf-8 -*-
"""Shared helpers for chapter-3 numerical experiments (single-thread BLAS)."""
import os
for _k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_k] = "1"
import numpy as np
import scipy.sparse as sp


def sim_ped(n, G=10, seed=0, sire_frac=0.2, dam_frac=0.5):
    """Discrete-generation pedigree, G generations of n//G animals (last one takes the remainder).

    Generation 0 = base (parents unknown, code 0).  In generation g>=1 every animal
    draws its sire uniformly from a random subset (sire_frac) of the males of generation g-1 and
    its dam uniformly from a random subset (dam_frac) of the females of generation g-1.
    Animals are numbered by generation (older first).  Codes are 1-based, 0 = unknown.
    """
    rng = np.random.default_rng(seed)
    ng = n // G
    sizes = [ng] * G
    sizes[-1] += n - ng * G
    sire = np.zeros(n, dtype=np.int64)
    dam = np.zeros(n, dtype=np.int64)
    sex = np.zeros(n, dtype=np.int64)          # 0 male, 1 female
    gen = np.zeros(n, dtype=np.int64)
    start = 0
    prev = None
    for g in range(G):
        ids = np.arange(start, start + sizes[g])
        gen[ids] = g
        sex[ids] = (np.arange(len(ids)) % 2)    # alternate M, F, M, F ...
        if g > 0:
            males = prev[sex[prev] == 0]
            females = prev[sex[prev] == 1]
            nm = max(2, int(round(sire_frac * len(males))))
            nf = max(2, int(round(dam_frac * len(females))))
            sm = rng.choice(males, size=nm, replace=False)
            sf = rng.choice(females, size=nf, replace=False)
            sire[ids] = sm[rng.integers(0, nm, size=len(ids))] + 1
            dam[ids] = sf[rng.integers(0, nf, size=len(ids))] + 1
        prev = ids
        start += sizes[g]
    return sire, dam, gen


def dense_A(sire, dam):
    """Tabular method for the numerator relationship matrix (dense)."""
    n = len(sire)
    A = np.zeros((n, n))
    for i in range(n):
        s, d = sire[i] - 1, dam[i] - 1
        if s >= 0 and d >= 0:
            row = 0.5 * (A[s, :i] + A[d, :i])
            A[i, :i] = row
            A[:i, i] = row
            A[i, i] = 1.0 + 0.5 * A[s, d]
        elif s >= 0 or d >= 0:
            p = s if s >= 0 else d
            row = 0.5 * A[p, :i]
            A[i, :i] = row
            A[:i, i] = row
            A[i, i] = 1.0
        else:
            A[i, i] = 1.0
    return A


def Ainv_henderson(sire, dam, F):
    """Henderson's rules.  Returns (csc matrix, number of contributed positions)."""
    n = len(sire)
    rows, cols, vals = [], [], []
    for i in range(n):
        s, d = sire[i] - 1, dam[i] - 1
        if s >= 0 and d >= 0:
            dii = 0.5 - 0.25 * (F[s] + F[d])
            idx = [i, s, d]
            w = [1.0, -0.5, -0.5]
        elif s >= 0 or d >= 0:
            p = s if s >= 0 else d
            dii = 0.75 - 0.25 * F[p]
            idx = [i, p]
            w = [1.0, -0.5]
        else:
            dii = 1.0
            idx = [i]
            w = [1.0]
        delta = 1.0 / dii
        for a in range(len(idx)):
            for b in range(len(idx)):
                rows.append(idx[a])
                cols.append(idx[b])
                vals.append(delta * w[a] * w[b])
    M = sp.coo_matrix((vals, (rows, cols)), shape=(n, n)).tocsc()   # duplicates summed
    M.sum_duplicates()
    return M


def sim_breeding_values(sire, dam, F, sig2a, rng):
    """Draw a ~ N(0, A sig2a) along the pedigree (Mendelian sampling)."""
    n = len(sire)
    a = np.zeros(n)
    for i in range(n):
        s, d = sire[i] - 1, dam[i] - 1
        if s >= 0 and d >= 0:
            dii = 0.5 - 0.25 * (F[s] + F[d])
            a[i] = 0.5 * (a[s] + a[d]) + np.sqrt(dii * sig2a) * rng.standard_normal()
        elif s >= 0 or d >= 0:
            p = s if s >= 0 else d
            dii = 0.75 - 0.25 * F[p]
            a[i] = 0.5 * a[p] + np.sqrt(dii * sig2a) * rng.standard_normal()
        else:
            a[i] = np.sqrt(sig2a) * rng.standard_normal()
    return a
