# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 3 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s31a_extra.py    依赖：numpy
import json
from c3common import *
import numpy as np
d = json.load(open("s31a_final.json"))
g = d['grid']
print("kappa(2000,1)/kappa(200,1) =", g['2000_1']['kappa'] / g['200_1']['kappa'])
for n in [200, 500, 1000, 2000]:
    for lam in [1, 3, 10, 30]:
        r = g[f"{n}_{lam}"]
        print(n, lam, f"lam_max={r['lam_max']:.4f} lam_min={r['lam_min']:.6f} kappa={r['kappa']:.4e}")
for n in [200, 500, 1000, 2000]:
    sire, dam, gen = sim_ped(n, G=10, seed=20240901)
    A = dense_A(sire, dam); F = np.diag(A) - 1.0
    Ai = Ainv_henderson(sire, dam, F).toarray()
    w = np.linalg.eigvalsh(Ai)
    print(n, "kappa(Ainv)=", w[-1] / w[0], " lam_max(Ainv)=", w[-1], " lam_min(Ainv)=", w[0], " nF>0:", int((F > 1e-12).sum()), "F max", F.max())
# the product kappa(C)*lam at small lam (n=1000)
s = d['scan']
for k in ['0.1', '0.01', '0.001', '0.0001']:
    r = s[k]; print("lam", k, "kappa*lam =", r['kappa'] * float(k), " kappa=", r['kappa'])

# --- additional checks cited in the text
mx = 0.0
for n in [200, 500, 1000, 2000]:
    sire, dam, gen = sim_ped(n, G=10, seed=20240901)
    A = dense_A(sire, dam); F = np.diag(A) - 1.0
    Ai = Ainv_henderson(sire, dam, F).toarray()
    err = np.max(np.abs(Ai @ A - np.eye(n)))
    mx = max(mx, err)
    print(n, "max|Ainv A - I| =", err)
print("max over four sizes:", mx)
lmin = g['2000_1']['lam_min']
print("extrapolated kappa at n=1e6 (lam=1) = (1e6+1)/lam_min(n=2000) =", (1e6 + 1) / lmin, " using n=1000 lam_min:", (1e6 + 1) / g['1000_1']['lam_min'])
print("1/0.34318 =", 1/0.34317957, " 1/0.0025486 =", 1/0.0025486442571543994)
print("thread ratio 0.012783400192979369/0.0025946107106695902 =", 0.012783400192979369/0.0025946107106695902)
