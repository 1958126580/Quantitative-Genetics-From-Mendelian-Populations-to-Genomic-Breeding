# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 3 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s31a2.py    依赖：numpy, scipy
# float32 breakdown scan + verification of the first-order bound eps <= kappa*eta*(1+|xhat|/|x|)
import numpy as np, scipy.linalg as sl, json
from c3common import *
from s31a import *

def full(n, lam, seed_ped=20240901, seed_y=20240902):
    sire, dam, gen = sim_ped(n, G=10, seed=seed_ped)
    A = dense_A(sire, dam); F = np.diag(A) - 1.0
    Ai = Ainv_henderson(sire, dam, F).toarray()
    rng = np.random.default_rng(seed_y + n * 1000 + int(lam * 10))
    a = sim_breeding_values(sire, dam, F, 1.0, rng)
    e = rng.standard_normal(n) * np.sqrt(lam)
    y = 10.0 + a + e
    C = np.block([[np.array([[float(n)]]), np.ones((1, n))], [np.ones((n, 1)), np.eye(n) + lam * Ai]])
    b = np.concatenate([[y.sum()], y])
    return C, b

# (1) bound check for all 16 + 4 cases
rows = []
for (n, lam) in [(n, l) for n in [200, 500, 1000, 2000] for l in [1, 3, 10, 30]] + [(1000, l) for l in [0.01, 0.1, 100, 1000]]:
    C, b = full(n, lam)
    w = np.linalg.eigvalsh(C); kappa = w[-1] / w[0]; nC = w[-1]
    xref, Cl = solve_ref(C, b)
    nx = np.sqrt(np.sum(xref ** 2))
    for prec in (32, 64):
        if prec == 32:
            x = sl.cho_solve(sl.cho_factor(C.astype(np.float32)), b.astype(np.float32))
        else:
            x = sl.cho_solve(sl.cho_factor(C), b)
        xl = x.astype(LD)
        r = b.astype(LD) - Cl @ xl
        eta = float(np.sqrt(np.sum(r ** 2)) / (nC * np.sqrt(np.sum(xl ** 2)) + np.sqrt(np.sum(b.astype(LD) ** 2))))
        eps = float(np.sqrt(np.sum((xl - xref) ** 2)) / nx)
        ratio_x = float(np.sqrt(np.sum(xl ** 2)) / nx)
        bound = kappa * eta * (1 + ratio_x)
        rows.append(dict(n=n, lam=lam, prec=prec, kappa=float(kappa), eps=eps, eta=eta, bound=float(bound), eps_over_bound=eps / bound,
                         eps_over_ku=eps / (kappa * (U32 if prec == 32 else U64)), eta_over_u=eta / (U32 if prec == 32 else U64)))
for prec in (32, 64):
    sel = [r for r in rows if r['prec'] == prec and r['lam'] in (1, 3, 10, 30)]
    print(prec, "main grid 16 cases: eps/(k u) range", min(r['eps_over_ku'] for r in sel), max(r['eps_over_ku'] for r in sel),
          " eta/u range", min(r['eta_over_u'] for r in sel), max(r['eta_over_u'] for r in sel),
          " eps/bound range", min(r['eps_over_bound'] for r in sel), max(r['eps_over_bound'] for r in sel))
    sel = [r for r in rows if r['prec'] == prec]
    print(prec, "all 20 cases: eps/(k u) range", min(r['eps_over_ku'] for r in sel), max(r['eps_over_ku'] for r in sel),
          " eta/u range", min(r['eta_over_u'] for r in sel), max(r['eta_over_u'] for r in sel),
          " eps/bound range", min(r['eps_over_bound'] for r in sel), max(r['eps_over_bound'] for r in sel), " all bounds hold:", all(r['eps'] <= r['bound'] for r in sel))
json.dump(rows, open('s31a2_bound.json', 'w'), indent=1)

# (2) float32 breakdown scan
print("---- float32 breakdown scan, n=1000")
for lam in [1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8]:
    C, b = full(1000, lam)
    w = np.linalg.eigvalsh(C); kappa = w[-1] / w[0]
    xref, Cl = solve_ref(C, b); nx = np.sqrt(np.sum(xref ** 2))
    try:
        x32 = sl.cho_solve(sl.cho_factor(C.astype(np.float32)), b.astype(np.float32))
        e32 = float(np.sqrt(np.sum((x32.astype(LD) - xref) ** 2)) / nx); ok = 'ok'
    except Exception as ex:
        e32 = None; ok = 'FAIL: ' + type(ex).__name__
    try:
        x64 = sl.cho_solve(sl.cho_factor(C), b)
        e64 = float(np.sqrt(np.sum((x64.astype(LD) - xref) ** 2)) / nx)
    except Exception as ex:
        e64 = None
    print(f"lam={lam:g} kappa={kappa:.3e} k*u32={kappa*U32:.2e} f32:{ok} err32={e32} err64={e64}")
