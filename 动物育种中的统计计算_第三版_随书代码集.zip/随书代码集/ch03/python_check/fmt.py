# -*- coding: utf-8 -*-
import math

def sci(x, d=3, math_mode=True):
    """3 s.f. scientific notation as LaTeX inline: $1.23\\times10^{-4}$ ; x==0 -> 0"""
    if x == 0:
        return "$0$" if math_mode else "0"
    e = int(math.floor(math.log10(abs(x))))
    m = x / 10 ** e
    s = f"{m:.{d-1}f}"
    if s.startswith("10"):
        e += 1; m = x / 10 ** e; s = f"{m:.{d-1}f}"
    if e == 0:
        out = s
    else:
        out = f"{s}\\times10^{{{e}}}"
    return f"${out}$" if math_mode else out

def sci_plain(x, d=3):
    """e.g. 3.31e+04 style used in log files"""
    return f"{x:.{d-1}e}"

def fixed(x, d=3):
    return f"{x:.{d}f}"

def sig(x, d=2):
    """d significant digits, plain decimal"""
    if x == 0: return "0"
    e = int(math.floor(math.log10(abs(x))))
    dec = max(0, d - 1 - e)
    return f"{x:.{dec}f}"
