# -*- coding: utf-8 -*-
"""Section 3.1 (a): condition number of the animal-model MME and float32/float64 solve accuracy.
Model: y = 1*mu + a + e, every animal has one record (Z = I), one fixed effect (overall mean).
Pedigree: sim_ped(n, G=10, seed=20240901, sire_frac=0.2, dam_frac=0.5).
Data   : mu = 10, a ~ N(0, A) (sig2a = 1), e ~ N(0, lam) ; rng seed 20240902 (y drawn separately for each n, lam).
Reference solution: float64 Cholesky + 3 steps of iterative refinement with the residual in long double.
"""
import time, json
from c3common import *
import numpy as np, scipy.linalg as sl

U32 = 2.0 ** -24
U64 = 2.0 ** -53
LD = np.longdouble


def solve_ref(C, b):
    c, low = sl.cho_factor(C)
    x = sl.cho_solve((c, low), b).astype(LD)
    Cl = C.astype(LD); bl = b.astype(LD)
    for _ in range(3):
        r = bl - Cl @ x
        d = sl.cho_solve((c, low), r.astype(np.float64)).astype(LD)
        x = x + d
    return x, Cl


def run(n, lam, seed_ped=20240901, seed_y=20240902, verbose=True):
    sire, dam, gen = sim_ped(n, G=10, seed=seed_ped)
    A = dense_A(sire, dam); F = np.diag(A) - 1.0
    Ai = Ainv_henderson(sire, dam, F).toarray()
    rng = np.random.default_rng(seed_y + n * 1000 + int(lam * 10))
    a = sim_breeding_values(sire, dam, F, 1.0, rng)
    e = rng.standard_normal(n) * np.sqrt(lam)
    y = 10.0 + a + e
    X = np.ones((n, 1))
    C = np.block([[np.array([[float(n)]]), np.ones((1, n))], [np.ones((n, 1)), np.eye(n) + lam * Ai]])
    b = np.concatenate([[y.sum()], y])
    w = np.linalg.eigvalsh(C)
    kappa = w[-1] / w[0]
    d = np.sqrt(np.diag(C)); Ce = C / np.outer(d, d)
    we = np.linalg.eigvalsh(Ce); kappa_eq = we[-1] / we[0]
    xref, Cl = solve_ref(C, b)
    nx = np.sqrt(np.sum(xref ** 2))
    # float64
    c64 = sl.cho_factor(C); x64 = sl.cho_solve(c64, b)
    # float32 (data rounded to float32 first)
    C32 = C.astype(np.float32); b32 = b.astype(np.float32)
    c32 = sl.cho_factor(C32); x32 = sl.cho_solve(c32, b32)
    assert x32.dtype == np.float32 and c32[0].dtype == np.float32
    def relerr(x):
        return float(np.sqrt(np.sum((x.astype(LD) - xref) ** 2)) / nx)
    def beta(x):
        xl = x.astype(LD)
        r = b.astype(LD) - Cl @ xl
        return float(np.sqrt(np.sum(r ** 2)) / (w[-1] * np.sqrt(np.sum(xl ** 2)) + np.sqrt(np.sum(b.astype(LD) ** 2))))
    # error of the EBV part only (relative to its own norm)
    def relerr_u(x):
        return float(np.sqrt(np.sum((x[1:].astype(LD) - xref[1:]) ** 2)) / np.sqrt(np.sum(xref[1:] ** 2)))
    res = dict(n=n, lam=lam, kappa=float(kappa), kappa_eq=float(kappa_eq),
               e32=relerr(x32), e64=relerr(x64), eta32=beta(x32), eta64=beta(x64),
               eu32=relerr_u(x32), eu64=relerr_u(x64),
               lam_min=float(w[0]), lam_max=float(w[-1]), meanF=float(F.mean()))
    if verbose:
        print(f"n={n:5d} lam={lam:6g} kappa={kappa:.3e} (eq {kappa_eq:.3e}) | f32 err={res['e32']:.2e} "
              f"[{res['e32']/(kappa*U32):.3f} k*u32] eta={res['eta32']:.2e} [{res['eta32']/U32:.2f} u32] ebv-part {res['eu32']:.2e}"
              f" | f64 err={res['e64']:.2e} [{res['e64']/(kappa*U64):.3f} k*u64] eta={res['eta64']:.2e} [{res['eta64']/U64:.2f} u64] ebv-part {res['eu64']:.2e}", flush=True)
    return res

if __name__ == "__main__":
    out = []
    t0 = time.time()
    for n in [200, 500, 1000, 2000]:
        for lam in [1, 3, 10, 30]:
            out.append(run(n, lam))
    print("main grid time", time.time() - t0)
    print("---- lambda extremes at n=1000")
    ext = []
    for lam in [0.01, 0.1, 100, 1000]:
        ext.append(run(1000, lam))
    json.dump(dict(main=out, ext=ext), open("s31a.json", "w"), indent=1)
    print("total time", time.time() - t0)
