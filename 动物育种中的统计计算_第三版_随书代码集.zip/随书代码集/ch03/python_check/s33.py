# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 3 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s33.py    依赖：numpy
"""Section 3.3: non-uniqueness of g-inverses on a small unbalanced 2x2 additive design (n=7).
beta = (mu, a1, a2, b1, b2)'; cell counts n11=2, n12=1, n21=1, n22=3.
"""
import json
from c3common import *
import numpy as np
from fmt import *

# data (artificial): herd i, diet j, weaning weight (kg)
cells = {(1, 1): [52.0, 56.0], (1, 2): [61.0], (2, 1): [47.0], (2, 2): [58.0, 55.0, 63.0]}
rows = []
y = []
for (i, j), vals in cells.items():
    for v in vals:
        x = np.zeros(5); x[0] = 1; x[i] = 1; x[2 + j] = 1
        rows.append(x); y.append(v)
X = np.array(rows); y = np.array(y); n = len(y)
A = X.T @ X; b = X.T @ y
print("X'X =\n", A.astype(int)); print("X'y =", b)
print("y'y =", y @ y)
sv = np.linalg.svd(A, compute_uv=False)
print("singular values of X'X:", sv)
r = np.linalg.matrix_rank(X)
print("rank(X) =", r, " n-r =", n - r)

# G1: reflexive g-inverse by zeroing a2 and b2 (keep mu, a1, b1)
keep = [0, 1, 3]
G1 = np.zeros((5, 5)); G1[np.ix_(keep, keep)] = np.linalg.inv(A[np.ix_(keep, keep)])
# G2: Moore-Penrose
G2 = np.linalg.pinv(A, rcond=1e-12)
np.set_printoptions(precision=6, suppress=True, linewidth=150)
print("det of kept 3x3 block:", np.linalg.det(A[np.ix_(keep, keep)]))
print("G1 =\n", G1); print("G2 =\n", G2)

def pen(G):
    return dict(
        i=np.linalg.norm(A @ G @ A - A), ii=np.linalg.norm(G @ A @ G - G),
        iii=np.linalg.norm((A @ G).T - A @ G), iv=np.linalg.norm((G @ A).T - G @ A), rank=np.linalg.matrix_rank(G), sym=np.linalg.norm(G - G.T))
p1, p2 = pen(G1), pen(G2)
print("Penrose residuals G1:", p1); print("Penrose residuals G2:", p2)

b1 = G1 @ b; b2 = G2 @ b
print("b1 =", b1, " ||b1|| =", np.linalg.norm(b1)); print("b2 =", b2, " ||b2|| =", np.linalg.norm(b2))
for nm, bb in [("b1", b1), ("b2", b2)]:
    res = y - X @ bb
    print(nm, "residual SS =", res @ res, " normal eq residual:", np.linalg.norm(A @ bb - b))
yh1, yh2 = X @ b1, X @ b2
print("fitted values max diff:", np.max(np.abs(yh1 - yh2)))
print("X(b1-b2) norm:", np.linalg.norm(X @ (b1 - b2)))
# general solution formula (3.14): b2 = G1 X'y + (I - G1 A) z with z = b2
print("check b2 = G1 b + (I-G1 A) b2: ", np.linalg.norm(b2 - (G1 @ b + (np.eye(5) - G1 @ A) @ b2)))
H1, H2 = G1 @ A, G2 @ A
print("H1 = G1 A =\n", H1); print("H2 = G2 A =\n", H2)
print("||H1-H2||:", np.linalg.norm(H1 - H2), " H1 idempotent:", np.linalg.norm(H1 @ H1 - H1), " H1 sym:", np.linalg.norm(H1 - H1.T), " H2 sym:", np.linalg.norm(H2 - H2.T))
SSE = float((y - yh1) @ (y - yh1)); s2 = SSE / (n - r)
print("SSE =", SSE, " s2 =", s2, " s =", np.sqrt(s2))

fun = [
 ("alpha1 - alpha2", [0, 1, -1, 0, 0]),
 ("beta1 - beta2", [0, 0, 0, 1, -1]),
 ("mu + alpha1 + beta1", [1, 1, 0, 1, 0]),
 ("mu + alpha1 + (beta1+beta2)/2", [1, 1, 0, .5, .5]),
 ("mu + (alpha1+alpha2)/2 + beta1", [1, .5, .5, 1, 0]),
 ("mu", [1, 0, 0, 0, 0]),
 ("alpha1", [0, 1, 0, 0, 0]),
 ("mu + alpha1", [1, 1, 0, 0, 0]),
 ("alpha1 + alpha2", [0, 1, 1, 0, 0]),
 ("beta1", [0, 0, 0, 1, 0]),
]
out = []
print(f"{'function':36s} {'rank':>7s} {'|k(H1-I)|':>10s} {'|k(H2-I)|':>10s} {'k b1':>10s} {'k b2':>10s} {'k G1 k':>9s} {'k G2 k':>9s} {'SE1':>8s} {'SE2':>8s}")
for nm, k in fun:
    k = np.array(k, float)
    rk = np.linalg.matrix_rank(np.vstack([X, k]))
    d1 = np.max(np.abs(k @ H1 - k)); d2 = np.max(np.abs(k @ H2 - k))
    v1, v2 = k @ G1 @ k, k @ G2 @ k
    se1 = np.sqrt(s2 * v1) if v1 > 0 else float('nan'); se2 = np.sqrt(s2 * v2) if v2 > 0 else float('nan')
    out.append(dict(name=nm, k=list(k), rank=int(rk), d1=float(d1), d2=float(d2), kb1=float(k @ b1), kb2=float(k @ b2), v1=float(v1), v2=float(v2), se1=float(se1), se2=float(se2)))
    print(f"{nm:36s} {rk:>3d}/{r} {d1:10.2e} {d2:10.2e} {k@b1:10.5f} {k@b2:10.5f} {v1:9.5f} {v2:9.5f} {se1:8.4f} {se2:8.4f}")
# reparametrised full-rank check: drop a2, b2
Xr = X[:, [0, 1, 3]]
br = np.linalg.solve(Xr.T @ Xr, Xr.T @ y)
print("full-rank reparam (mu, a1, b1):", br, "  -> alpha1-alpha2 =", br[1], " beta1-beta2 =", br[2], " mu+a1+b1 =", br.sum())
Cr = np.linalg.inv(Xr.T @ Xr)
print("SE(alpha1-alpha2) via reparam:", np.sqrt(s2 * Cr[1, 1]), " SE(beta1-beta2):", np.sqrt(s2 * Cr[2, 2]), " SE(mu+a1+b1):", np.sqrt(s2 * np.ones(3) @ Cr @ np.ones(3)))
json.dump(dict(fun=out, b1=list(map(float, b1)), b2=list(map(float, b2)), G1=G1.tolist(), G2=G2.tolist(), p1={k: float(v) for k, v in p1.items()}, p2={k: float(v) for k, v in p2.items()}, SSE=SSE, s2=s2), open("s33.json", "w"), indent=1)

# ---------------- extra checks used in the text
print("\n--- extra")
M1 = G1 * 17; M2 = G2 * 544
print("17*G1 =\n", np.round(M1, 10)); print("max |17 G1 - round| =", np.max(np.abs(M1 - np.round(M1))))
print("544*G2 =\n", np.round(M2, 10)); print("max |544 G2 - round| =", np.max(np.abs(M2 - np.round(M2))))
Hh1 = X @ G1 @ X.T; Hh2 = X @ G2 @ X.T
print("hat matrix invariance ||X G1 X' - X G2 X'||_max =", np.max(np.abs(Hh1 - Hh2)), " trace =", np.trace(Hh1), np.trace(Hh2))
PN = np.eye(5) - H2
for nm, k in fun[5:]:
    k = np.array(k, float)
    print(f"{nm:20s} ||k'H2-k'||_2 = {np.linalg.norm(k @ H2 - k):.6f}   ||P_N k||_2 = {np.linalg.norm(PN @ k):.6f}")
print("diff of b: b1-b2 =", b1 - b2, " null space basis check: X(b1-b2) max:", np.max(np.abs(X @ (b1 - b2))))
# null space of X: two vectors
u, s, vt = np.linalg.svd(X)
print("singular values of X:", s)
N = vt[3:].T
print("null space basis (columns):\n", N)
print("tolerance for numerical rank of X'X: ", max(A.shape) * sv[0] * np.finfo(float).eps)
# R-style treatment contrasts (alpha1=0, beta1=0) for comparison
keepR = [0, 2, 4]
GR = np.zeros((5, 5)); GR[np.ix_(keepR, keepR)] = np.linalg.inv(A[np.ix_(keepR, keepR)])
bR = GR @ b
print("first-level-zero solution:", bR, " k=a1-a2:", bR[1] - bR[2], " b1-b2:", bR[3] - bR[4])
