# 本脚本由 tools/nb2jl.py 从同目录的 ch23.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 23

# %% [markdown]
# # 第二十三章　单步法与多信息源整合 —— 配套代码
#
# 本 Notebook 对应第二十三章。
#
# **内容**
#
# 1. 系谱工具与模拟数据
# 2. $\mathbf H$ 与 $\mathbf H^{-1}$ 的构建——正文式 (23.9)、(23.14)
# 3. **单元测试**：令 $\mathbf G:=\mathbf A_{22}$ 时 $\mathbf H=\mathbf A$（正文 §23.2.1 第 3 点）
# 4. 调平的三种方案与诊断（正文 §23.2.3）
# 5. $\mathbf A_{22}^{-1}$ 的三条计算路径（正文 §23.3.1），含 $\mathbf A_{22}^{-1}\ne(\mathbf A^{-1})_{22}$ 的演示
# 6. ssGBLUP 的直接解与 PCG 解
# 7. Metafounder 的 $\gamma$ 估计——正文式 (23.24)、(23.25)
# 8. **去回归的完整实现与自洽性检验**——正文式 (23.43)–(23.52)
# 9. ssBR（单步贝叶斯回归）与定理 23.1 的数值验证
# 10. **ssBR：自实现与 JWAS 的对照**（可选，需安装 JWAS）

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %%
"""按系谱递推构造 A（第九章式 9.2–9.3）。"""
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

"""Henderson–Quaas 规则构造稀疏 A⁻¹（第九章 §9.3.2）。"""
function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        b = inv(delta)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

"""按系谱做配子传递的简化模拟（与第二十一章相同）。"""
function sim_pedigree_genotypes(nbase::Int, ngen::Int, nper::Int, m::Int;
                                nchr::Int=10, r::Float64=0.02,
                                maf_min::Float64=0.05, rng=Random.default_rng())
    n = nbase + ngen*nper
    p0 = maf_min .+ (1 - 2maf_min) .* rand(rng, m)
    H = Array{Int8,3}(undef, n, m, 2)
    @inbounds for i in 1:nbase, j in 1:m, k in 1:2
        H[i,j,k] = Int8(rand(rng) < p0[j])
    end
    sire = zeros(Int, n); dam = zeros(Int, n)
    mper = m ÷ nchr
    gen  = zeros(Int, n)
    @inbounds for g in 1:ngen
        lo = nbase + (g-1)*nper + 1; hi = nbase + g*nper
        pool_hi = lo - 1
        for i in lo:hi
            gen[i] = g
            s = rand(rng, 1:pool_hi); d = rand(rng, 1:pool_hi)
            while d == s; d = rand(rng, 1:pool_hi); end
            sire[i] = s; dam[i] = d
            for (par, k) in ((s,1), (d,2))
                for c in 1:nchr
                    cur = rand(rng, 1:2)
                    for jj in 1:mper
                        j = (c-1)*mper + jj
                        j > m && break
                        if jj > 1 && rand(rng) < r; cur = 3 - cur; end
                        H[i,j,k] = H[par,j,cur]
                    end
                end
            end
        end
    end
    Mg = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        Mg[i,j] = Float64(H[i,j,1]) + Float64(H[i,j,2])
    end
    return Mg, sire, dam, gen
end

# %%
# 模拟一个"部分个体有基因型"的群体
n_base, n_gen, n_per, m_snp = 120, 5, 160, 1500
Mg, sire, dam, gen = sim_pedigree_genotypes(n_base, n_gen, n_per, m_snp; rng=Xoshiro(2301))
n = length(sire)

# 只有最近两个世代的个体被基因分型
geno = findall(g -> g >= n_gen - 1, gen)
nogeno = setdiff(1:n, geno)
n2 = length(geno); n1 = length(nogeno)
@printf("总个体 n = %d ，  有基因型 n2 = %d ，  无基因型 n1 = %d\n", n, n2, n1)

A = build_A(sire, dam)
F = diag(A) .- 1
Ainv = build_Ainv(sire, dam, F)
check("A⁻¹ 正确性（A·A⁻¹ = I）", Matrix(Ainv)*A, Matrix(I, n, n); tol=1e-8)
@printf("A⁻¹ 非零元 = %d  （≤ 9n = %d）\n", nnz(Ainv), 9n)

# %% [markdown]
# ## 2　$\mathbf H$ 与 $\mathbf H^{-1}$
#
# 正文式 (23.9)：
#
# $$\mathbf H=\begin{bmatrix}
# \mathbf A_{11}+\mathbf P(\mathbf G-\mathbf A_{22})\mathbf P' & \mathbf P\mathbf G\\
# \mathbf G\mathbf P' & \mathbf G\end{bmatrix},\qquad \mathbf P=\mathbf A_{12}\mathbf A_{22}^{-1}$$
#
# 正文式 (23.14)：
#
# $$\mathbf H^{-1}=\mathbf A^{-1}+\begin{bmatrix}\mathbf 0&\mathbf 0\\ \mathbf 0&\mathbf G^{-1}-\mathbf A_{22}^{-1}\end{bmatrix}$$

# %%
"""正文式 (23.9)：显式构造 H（仅用于小规模验证，生产中绝不构造）。"""
function build_H(A::AbstractMatrix, G::AbstractMatrix,
                 idx1::Vector{Int}, idx2::Vector{Int})
    A11 = A[idx1, idx1]; A12 = A[idx1, idx2]; A22 = A[idx2, idx2]
    P = A12 / A22                        # A12 A22⁻¹
    n = size(A,1); H = zeros(n, n)
    H[idx1, idx1] .= A11 .+ P*(G .- A22)*P'
    H[idx1, idx2] .= P*G
    H[idx2, idx1] .= G*P'
    H[idx2, idx2] .= G
    return H
end

"""正文式 (23.14)：H⁻¹ = A⁻¹ + [0 0; 0 G⁻¹ - A22⁻¹]（含 τ、ω，式 23.19）。"""
function build_Hinv(Ainv::AbstractMatrix, Ginv::AbstractMatrix, A22inv::AbstractMatrix,
                    idx2::Vector{Int}; tau::Float64=1.0, omega::Float64=1.0)
    Hi = Matrix(Ainv)
    Hi[idx2, idx2] .+= tau .* Ginv .- omega .* A22inv
    return Hi
end

# ---- 单元测试 1：G := A22 时 H = A ----
A22 = A[geno, geno]
Ht = build_H(A, A22, nogeno, geno)
check("正文 §23.2.1：G = A22 ⇒ H = A", Ht, A; tol=1e-8)

# ---- 构造真正的 G ----
pfreq = vec(mean(Mg[geno, :], dims=1)) ./ 2
keepj = findall(j -> 0.01 < pfreq[j] < 0.99, 1:m_snp)
Mg2 = Mg[:, keepj]; p2 = pfreq[keepj]
Z2 = Mg2[geno, :] .- 2 .* p2'
sum2pq = 2*sum(p2 .* (1 .- p2))
G_raw = (Z2*Z2') ./ sum2pq
@printf("\nG 的秩 = %d （n2 = %d，必然奇异，正文 §21.1.6）\n", rank(G_raw), n2)

# %% [markdown]
# ## 3　调平（正文 §23.2.3）

# %%
"""正文式 (23.17)：均值匹配调平。"""
function tune_meanmatch(G, A22)
    gd = mean(diag(G)); ga = mean(G)
    ad = mean(diag(A22)); aa = mean(A22)
    b = (ad - aa)/(gd - ga); a = aa - b*ga
    return a .+ b .* G, a, b
end

"""正文式 (23.18)：混合。"""
blend(Gs, A22, w) = (1-w) .* Gs .+ w .* A22

"""调平诊断报告（正文 §23.2.3 的五步流程）。"""
function tuning_report(G, A22)
    n = size(G,1)
    od(M) = (sum(M) - sum(diag(M)))/(n*(n-1))
    @printf("%-18s%-12s%-12s%-12s\n", "矩阵", "diag 均值", "全元素均值", "非对角均值")
    for (nm, MM) in ("A22"=>A22, "G(原始)"=>G)
        @printf("%-18s%-12.4f%-12.4f%-12.4f\n", nm, mean(diag(MM)), mean(MM), od(MM))
    end
    Gs, a, b = tune_meanmatch(G, A22)
    @printf("\n均值匹配： α = %+.4f ， β = %.4f", a, b)
    println(0.7 <= b <= 1.4 ? "   （β 在合理范围）" : "   ⚠ β 异常，应检查数据！")
    Gw = blend(Gs, A22, 0.05)
    for (nm, MM) in ("G*(调平)"=>Gs, "G_w(w=.05)"=>Gw)
        @printf("%-18s%-12.4f%-12.4f%-12.4f\n", nm, mean(diag(MM)), mean(MM), od(MM))
    end
    # 元素级一致性
    x = Float64[]; y = Float64[]
    for i in 1:n-1, k in i+1:n
        push!(x, A22[i,k]); push!(y, Gs[i,k])
    end
    @printf("\n非对角元回归 G* ~ A22： 斜率 = %.4f ， R² = %.3f\n",
            cov(x,y)/var(x), cor(x,y)^2)
    return Gs, Gw
end

Gstar, Gw = tuning_report(G_raw, A22)
check("调平后 diag 均值匹配", mean(diag(Gstar)), mean(diag(A22)); tol=1e-12)
check("调平后 全元素均值匹配", mean(Gstar), mean(A22); tol=1e-12)
@printf("\nG_w 最小特征值 = %.5f （正定 ✔）\n", minimum(eigvals(Symmetric(Gw))))

# %% [markdown]
# ## 4　$\mathbf A_{22}^{-1}$：三条路径与一个重要警告
#
# **警告**（正文式 23.26）：$\mathbf A_{22}^{-1}\ne\left(\mathbf A^{-1}\right)_{22}$。
#
# 正确关系是 $\mathbf A^{-1}$ 的 Schur 补（正文式 23.27）：
#
# $$\mathbf A_{22}^{-1}=\left(\mathbf A^{-1}\right)_{22}-\left(\mathbf A^{-1}\right)_{21}\left[\left(\mathbf A^{-1}\right)_{11}\right]^{-1}\left(\mathbf A^{-1}\right)_{12}$$

# %%
"""路径一：直接构造 A22 后求逆（小规模）。"""
A22inv_direct = inv(A22)

"""路径二（推荐）：正文式 (23.27) 的 Schur 补 + 稀疏 Cholesky。"""
function A22inv_schur(Ainv::SparseMatrixCSC, idx1::Vector{Int}, idx2::Vector{Int})
    A11i = Ainv[idx1, idx1]
    A12i = Ainv[idx1, idx2]
    A22i = Ainv[idx2, idx2]
    Fc = cholesky(Symmetric(A11i))        # 稀疏 Cholesky（含 AMD 排序）
    W  = Fc \ Matrix(A12i)                # n2 个稀疏三角求解
    return Matrix(A22i) .- Matrix(A12i)'*W
end

A22inv_s = A22inv_schur(Ainv, nogeno, geno)
check("式 (23.27)：Schur 补 = inv(A22)", A22inv_s, A22inv_direct; tol=1e-7)

# 演示常见错误
A22inv_wrong = Matrix(Ainv[geno, geno])
@printf("\n(A⁻¹)₂₂ 与 A₂₂⁻¹ 的相对差 = %.3f  （二者完全不同！）\n",
        relerr(A22inv_wrong, A22inv_direct))
@printf("  对角均值： A₂₂⁻¹ = %.3f ，  (A⁻¹)₂₂ = %.3f\n",
        mean(diag(A22inv_direct)), mean(diag(A22inv_wrong)))

# 路径三：无矩阵（只需 A22⁻¹v）—— 用 PCG 解 A22 x = v
"""Colleau (2002) 算法：O(n) 计算 A·v，不构造 A。"""
function colleau_Av(v::Vector{Float64}, sire::Vector{Int}, dam::Vector{Int},
                    dvec::Vector{Float64})
    n = length(v)
    # 第一步：求解 T' q = v （自后向前）
    q = copy(v)
    @inbounds for i in n:-1:1
        s, d = sire[i], dam[i]
        s > 0 && (q[s] += 0.5*q[i])
        d > 0 && (q[d] += 0.5*q[i])
    end
    # 第二步：b = D q
    b = q .* dvec
    # 第三步：求解 T a = b （自前向后）
    a = copy(b)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        s > 0 && (a[i] += 0.5*a[s])
        d > 0 && (a[i] += 0.5*a[d])
    end
    return a
end

dvec = [ (sire[i]>0 && dam[i]>0) ? 0.5 - 0.25*(F[sire[i]]+F[dam[i]]) :
         (sire[i]>0)             ? 0.75 - 0.25*F[sire[i]] :
         (dam[i]>0)              ? 0.75 - 0.25*F[dam[i]]  : 1.0  for i in 1:n ]
vt = randn(Xoshiro(77), n)
check("Colleau 算法 A·v", colleau_Av(vt, sire, dam, dvec), A*vt; tol=1e-9)

# %% [markdown]
# ## 5　ssGBLUP 的求解

# %%
# 模拟表型：只有较早世代的个体有记录（典型的"母畜有记录、候选无记录"场景）
s2u = 1.0; h2 = 0.35; s2e = s2u*(1-h2)/h2
Lh = cholesky(Symmetric(A .+ 1e-9I)).L
u_true = Lh * randn(Xoshiro(2310), n) .* sqrt(s2u)

has_rec = findall(g -> g <= n_gen - 1, gen)
nr = length(has_rec)
y = 50.0 .+ u_true[has_rec] .+ randn(Xoshiro(2311), nr).*sqrt(s2e)
X = ones(nr, 1)
W = zeros(nr, n); for (k,i) in enumerate(has_rec); W[k,i] = 1.0; end
@printf("有表型记录的个体 = %d ； 待预测（候选）= %d\n", nr, n - nr)

"""解 MME：给定 K⁻¹（A⁻¹ 或 H⁻¹）。"""
function solve_mme(y, X, W, Kinv, lam)
    p = size(X,2); n = size(Kinv,1)
    C = [X'X      X'W;
         W'X      W'W .+ lam .* Matrix(Kinv)]
    sol = (C + 1e-10I) \ [X'y; W'y]
    return sol[1:p], sol[p+1:end]
end

lam = s2e/s2u
Ginv_w = inv(cholesky(Symmetric(Gw)))
Hinv   = build_Hinv(Ainv, Ginv_w, A22inv_direct, geno)

b_ped, u_ped = solve_mme(y, X, W, Matrix(Ainv), lam)
b_ss,  u_ss  = solve_mme(y, X, W, Hinv,          lam)

cand = setdiff(1:n, has_rec)
@printf("\n%-24s%-16s%-16s\n", "方法", "全部个体 r", "候选个体 r")
@printf("%-24s%-16.4f%-16.4f\n", "系谱 BLUP",
        cor(u_ped, u_true), cor(u_ped[cand], u_true[cand]))
@printf("%-24s%-16.4f%-16.4f\n", "ssGBLUP",
        cor(u_ss, u_true),  cor(u_ss[cand],  u_true[cand]))

# 单元测试 2：H⁻¹ 用 A22 代替 G 时应精确退化为 A⁻¹
Hinv_deg = build_Hinv(Ainv, inv(A22), A22inv_direct, geno)
check("G = A22 ⇒ H⁻¹ = A⁻¹", Hinv_deg, Matrix(Ainv); tol=1e-8)
_, u_deg = solve_mme(y, X, W, Hinv_deg, lam)
check("G = A22 ⇒ ssGBLUP = 系谱 BLUP", u_deg, u_ped; tol=1e-7)

# %% [markdown]
# ### 5.1 未调平的后果（正文 §23.2.3 的症状清单）

# %%
Ginv_raw = inv(Symmetric(G_raw .+ 0.05 .* Matrix(I, n2, n2)))   # 只做对角加载，不调平
Hinv_bad = build_Hinv(Ainv, Ginv_raw, A22inv_direct, geno)
_, u_bad = solve_mme(y, X, W, Hinv_bad, lam)

"""按世代给出平均 EBV，并按是否有基因型分层（正文 §24.3.3 的遗传趋势诊断）。"""
function trend_by_gen(u, gen, geno; ngen=maximum(gen))
    isg = falses(length(u)); isg[geno] .= true
    rows = NamedTuple[]
    for g in 0:ngen
        idx = findall(==(g), gen)
        isempty(idx) && continue
        ig = intersect(idx, geno); ng = setdiff(idx, geno)
        push!(rows, (gen=g, all=mean(u[idx]),
                     with = isempty(ig) ? NaN : mean(u[ig]),
                     without = isempty(ng) ? NaN : mean(u[ng])))
    end
    return rows
end

for (nm, uu) in ("已调平 G_w"=>u_ss, "未调平 G"=>u_bad)
    println("\n遗传趋势（", nm, "）")
    @printf("%-8s%-14s%-14s%-14s\n", "世代", "全体均值", "有基因型", "无基因型")
    for r in trend_by_gen(uu, gen, geno)
        @printf("%-8d%-14.4f%-14s%-14s\n", r.gen, r.all,
                isnan(r.with) ? "—" : @sprintf("%.4f", r.with),
                isnan(r.without) ? "—" : @sprintf("%.4f", r.without))
    end
end
@printf("\n与真值的相关：已调平 %.4f ； 未调平 %.4f\n",
        cor(u_ss[cand], u_true[cand]), cor(u_bad[cand], u_true[cand]))
@printf("回归斜率 b1（真值 ~ 预测）：已调平 %.3f ； 未调平 %.3f\n",
        cov(u_true[cand], u_ss[cand])/var(u_ss[cand]),
        cov(u_true[cand], u_bad[cand])/var(u_bad[cand]))

# %% [markdown]
# ### 5.2 PCG 求解（正文 §23.3.3）

# %%
"""预条件共轭梯度法（Jacobi 预条件），返回 (x, 迭代数, 残差历史)。"""
function pcg(Aop, b::Vector{Float64}, diagA::Vector{Float64};
             tol=1e-10, maxit=5000)
    x = zeros(length(b)); r = b .- Aop(x)
    Minv = 1 ./ diagA
    z = Minv .* r; p = copy(z)
    rz = dot(r, z); nb = norm(b); hist = Float64[]
    for it in 1:maxit
        Ap = Aop(p); a = rz/dot(p, Ap)
        @. x += a*p
        @. r -= a*Ap
        push!(hist, norm(r)/nb)
        hist[end] < tol && return x, it, hist
        z .= Minv .* r
        rz_new = dot(r, z)
        @. p = z + (rz_new/rz)*p
        rz = rz_new
    end
    return x, maxit, hist
end

# 构造 MME 的算子形式（正文式 23.31–23.32）
p_fix = size(X,2)
function mme_op(v)
    vb = view(v, 1:p_fix); vu = view(v, p_fix+1:p_fix+n)
    Xb = X*vb; Wu = W*vu
    top = X'*(Xb .+ Wu)
    Hv  = Ainv*vu
    Hv[geno] .+= Ginv_w*view(vu, geno) .- A22inv_direct*view(vu, geno)
    bot = W'*(Xb .+ Wu) .+ lam .* Hv
    return vcat(top, bot)
end
Cd = vcat(diag(X'X), diag(W'W) .+ lam .* diag(Hinv))
rhs = vcat(X'y, W'y)
xpcg, nit, hist = pcg(mme_op, rhs, Cd; tol=1e-10)

@printf("PCG 迭代 %d 次收敛到相对残差 %.2e\n", nit, hist[end])
check("PCG 解 = 直接解", xpcg[p_fix+1:end], u_ss; tol=1e-6)

# 与纯系谱模型的条件数对比
function mme_op_ped(v)
    vb = view(v, 1:p_fix); vu = view(v, p_fix+1:p_fix+n)
    Xb = X*vb; Wu = W*vu
    vcat(X'*(Xb .+ Wu), W'*(Xb .+ Wu) .+ lam .* (Ainv*vu))
end
Cd_ped = vcat(diag(X'X), diag(W'W) .+ lam .* diag(Ainv))
_, nit_ped, _ = pcg(mme_op_ped, rhs, Cd_ped; tol=1e-10)
@printf("纯系谱模型 PCG 迭代 %d 次 ； 单步法 %d 次 （修正块恶化了条件数，正文 §23.3.3）\n",
        nit_ped, nit)

# %% [markdown]
# ## 6　Metafounder 的 $\gamma$ 估计（正文式 23.22–23.25）
#
# $$\mathbf G_{05}=\frac{(\mathbf M-\mathbf 1\mathbf 1')(\mathbf M-\mathbf 1\mathbf 1')'}{m/2},
# \qquad \gamma=8\,\mathrm{Var}_j(p_j)\ \ (\text{当 }E(p)=0.5)$$

# %%
"""正文式 (23.22)：以 p = 0.5 为基准构造的 G05。"""
function G05(Mg::AbstractMatrix)
    Z = Mg .- 1.0
    return (Z*Z') ./ (size(Mg,2)/2)
end

"""正文式 (23.25)：γ 的矩估计（全元素均值）。"""
gamma_mom(G05m) = mean(G05m)

# 用基础群体个体（无系谱祖先）估计
base_ind = findall(==(0), gen)
G05_base = G05(Mg2[base_ind, :])
gam_mom  = gamma_mom(G05_base)

# 与解析式 (23.24) 对照：γ = 8 Var(p) + 2(2E(p)-1)²
p_base = vec(mean(Mg2[base_ind, :], dims=1)) ./ 2
gam_analytic = 8*var(p_base; corrected=false) + 2*(2*mean(p_base) - 1)^2

@printf("基础群体： n = %d ， m = %d\n", length(base_ind), size(Mg2,2))
@printf("  E(p)    = %.4f      Var(p) = %.5f\n", mean(p_base), var(p_base; corrected=false))
@printf("  矩估计 γ̂ (式 23.25)          = %.4f\n", gam_mom)
@printf("  解析式 8Var(p)+2(2E(p)-1)²  = %.4f\n", gam_analytic)
@printf("  简化式 8Var(p)（E(p)=0.5 时）= %.4f\n", 8*var(p_base; corrected=false))
nb_ = length(base_ind)
gam_off = (sum(G05_base) - sum(diag(G05_base)))/(nb_*(nb_-1))   # 只用非对角元
@printf("  非对角元均值（无亲缘个体对）  = %.4f\n", gam_off)
check("式 (23.23)：非对角元均值 ≈ 8Var(p)+2(2E(p)-1)²", gam_off, gam_analytic; tol=0.20)

println("\n=> γ 度量基础群体等位基因频率偏离 0.5 的程度（正文 §23.2.6）。")
println("   本模拟的基础频率由 U(0.05,0.95) 抽取，E(p)≈0.5，故两式接近。")
@printf("   理论上 U(a,1-a) 的 Var(p) = (1-2a)²/12 = %.5f\n", (1-2*0.05)^2/12)

# %% [markdown]
# ## 7　去回归（正文式 23.43–23.52）
#
# 完整实现 + 两个自洽性检验：
#
# 1. 令 $r_i^2=r_{\mathrm{PA}}^2$ 时 $q_i=0$（正文思考题 8）
# 2. 由 $(q_{\mathrm{PA}},q_i)$ 反推的 $r_i^2$ 必须回到输入值

# %%
"""正文式 (23.46)–(23.47)：由可靠性反解有效记录数 (q_PA, q_i)。"""
function effective_records(h2::Float64, r2PA::Float64, r2i::Float64)
    lam = (1 - h2)/h2
    r2PA < 0.5 || error("r²_PA 必须 < 0.5（亲本均值的可靠性上限，正文式 23.46）")
    qPA = 4*lam*r2PA/(1 - 2*r2PA)
    qi  = lam*(1/(1 - r2i) + (1 - 2*r2PA)/(1 - r2PA) - 2)
    return lam, qPA, qi
end

"""正文式 (23.49)：去回归值 DRP。"""
function deregress(ebv::Float64, ebv_pa::Float64, h2::Float64,
                   r2PA::Float64, r2i::Float64)
    lam, qPA, qi = effective_records(h2, r2PA, r2i)
    qi <= 0 && return (drp=NaN, r2=NaN, q=qi, w=NaN)
    drp  = ((qi + 2lam)*ebv - 2lam*ebv_pa)/qi
    r2d  = qi/(qi + lam)                       # 式 (23.50)
    return (drp=drp, r2=r2d, q=qi, w=NaN)
end

"""正文式 (23.51)：Garrick 权重。"""
garrick_weight(h2::Float64, r2drp::Float64, c::Float64) =
    (1 - h2)/((c + (1 - r2drp)/r2drp)*h2)

# --- 自洽性检验 1：r²_i = r²_PA ⇒ q_i = 0 ---
println("自洽性检验 1：r²_i = r²_PA ⇒ q_i = 0")
for h2x in (0.15, 0.25, 0.40), r2p in (0.10, 0.25, 0.45)
    _, _, qi0 = effective_records(h2x, r2p, r2p)
    @printf("  h²=%.2f  r²_PA=%.2f  →  q_i = %.3e\n", h2x, r2p, qi0)
end

# --- 自洽性检验 2：由 q 反推可靠性 ---
println("\n自洽性检验 2：由 (q_PA, q_i) 反推 r²_i")
@printf("%-10s%-10s%-10s%-12s%-12s%-14s\n", "h²", "r²_PA", "r²_i", "q_PA", "q_i", "反推 r²_i")
for (h2x, r2p, r2ii) in ((0.25,0.30,0.85), (0.10,0.20,0.60), (0.40,0.45,0.95))
    lam, qPA, qi = effective_records(h2x, r2p, r2ii)
    det = (qPA + 4lam)*(qi + 2lam) - 4lam^2
    r2back = 1 - lam*(qPA + 4lam)/det          # 式 (23.45)
    @printf("%-10.2f%-10.2f%-10.2f%-12.4f%-12.4f%-14.6f\n",
            h2x, r2p, r2ii, qPA, qi, r2back)
end

# --- 正文思考题 9 的数值 ---
println("\n正文第二十三章思考题 9：")
h2x, r2p, r2ii, ui, upa, cc = 0.25, 0.30, 0.85, 120.0, 80.0, 0.2
lam, qPA, qi = effective_records(h2x, r2p, r2ii)
d = deregress(ui, upa, h2x, r2p, r2ii)
w = garrick_weight(h2x, d.r2, cc)
@printf("  λ = %.4f ， q_PA = %.4f ， q_i = %.4f\n", lam, qPA, qi)
@printf("  DRP = %.3f ， r²_DRP = %.4f ， w(c=0.2) = %.4f\n", d.drp, d.r2, w)
@printf("  错误做法 EBV/r² = %.3f  （相差 %.1f%%）\n", ui/r2ii, 100*(ui/r2ii/d.drp - 1))
check("式 (23.52)：c = 0 时 w = q_i", garrick_weight(h2x, d.r2, 0.0), qi; tol=1e-10)
@printf("\n权重上界（r²_DRP → 1）= (1-h²)/(c h²) = %.3f\n", (1-h2x)/(cc*h2x))

# %%
# 常见错误的量化对比（正文 §23.5.2 的错误清单）
println("三种“去回归”做法的比较（h² = 0.25, c = 0.2）\n")
@printf("%-10s%-10s%-12s%-12s%-12s%-10s\n",
        "r²_PA", "r²_i", "EBV", "DRP(正确)", "EBV/r²", "偏差%")
for (r2p, r2ii, ui, upa) in ((0.20,0.50,100.0,60.0), (0.30,0.85,120.0,80.0),
                             (0.45,0.95,150.0,140.0), (0.40,0.42,90.0,88.0))
    d = deregress(ui, upa, 0.25, r2p, r2ii)
    @printf("%-10.2f%-10.2f%-12.1f%-12.2f%-12.2f%-10.1f\n",
            r2p, r2ii, ui, d.drp, ui/r2ii, 100*(ui/r2ii/d.drp - 1))
end
println("\n=> r²_i 与 r²_PA 接近时（最后一行），个体几乎没有自身信息，")
println("   q_i 很小、DRP 的方差极大——这类个体应从基因组回归中剔除（正文错误清单）。")

# 权重随可靠性的变化
println("\n权重 w 随 r²_DRP 的变化（h²=0.25）：")
@printf("%-12s%-14s%-14s%-14s\n", "r²_DRP", "c=0", "c=0.1", "c=0.5")
for r2d in (0.2, 0.4, 0.6, 0.8, 0.9, 0.99)
    @printf("%-12.2f%-14.2f%-14.2f%-14.2f\n", r2d,
            garrick_weight(0.25, r2d, 0.0),
            garrick_weight(0.25, r2d, 0.1),
            garrick_weight(0.25, r2d, 0.5))
end
println("=> c > 0 给权重设了上界，防止极高可靠性个体主导分析（正文 §23.5.2）。")

# %% [markdown]
# ## 8　ssBR 与定理 23.1 的验证
#
# 定理 23.1：取 $\boldsymbol\alpha\sim N(\mathbf 0,\mathbf I\sigma_\alpha^2)$、$\sigma_\epsilon^2=\sigma_u^2$ 时，
# ssBR 与**未调平未混合**的 ssGBLUP 给出相同的 $\hat{\mathbf u}$。
#
# 这里用**等价的混合模型方程**直接验证（避免长链 MCMC）：ssBR 的模型（正文式 23.38）
# 在正态先验下等价于把 $\mathbf u$ 的方差取为 $\mathbf H$，所以只需验证
# $\mathrm{Var}(\mathbf u)$ 的构造一致。

# %%
# 由 ssBR 的结构（式 23.36–23.37）构造 Var(u)，应等于 H（式 23.9）
P  = A[nogeno, geno] / A22
A112 = A[nogeno,nogeno] .- A[nogeno,geno]*(A22\A[geno,nogeno])
G_ss = (Z2*Z2') ./ sum2pq                     # 未调平

H_ssbr = zeros(n, n)
H_ssbr[nogeno, nogeno] .= P*G_ss*P' .+ A112     # Var(u1) = P G P' + A11.2
H_ssbr[nogeno, geno]   .= P*G_ss
H_ssbr[geno,   nogeno] .= G_ss*P'
H_ssbr[geno,   geno]   .= G_ss

H_ssg = build_H(A, G_ss, nogeno, geno)
check("定理 23.1：ssBR 的 Var(u) = ssGBLUP 的 H", H_ssbr, H_ssg; tol=1e-8)

# A11.2⁻¹ = (A⁻¹)11 —— 这是 ssBR 可行的关键（正文式 23.13）
check("式 (23.13)：A11.2⁻¹ = (A⁻¹)₁₁", inv(A112), Matrix(Ainv[nogeno, nogeno]); tol=1e-7)
@printf("\n(A⁻¹)₁₁ 的稀疏度 = %.2f%% 非零  （稠密逆的 %.0f 倍稀疏）\n",
        100*nnz(Ainv[nogeno,nogeno])/n1^2, n1^2/nnz(Ainv[nogeno,nogeno]))

# %%
"""ssBR 的 Gibbs 抽样（正文式 23.38–23.42）。

把模型写成 y = 1μ + Z_eff α + W_ε ε + e，其中
  Z_eff 的行对有基因型个体取 Z₂，对无基因型个体取 P Z₂（式 23.35）；
  ε 只对无基因型个体存在，先验方差 A₁₁.₂ σ_ε²，
  而 A₁₁.₂⁻¹ = (A⁻¹)₁₁ 是稀疏的（式 23.13）——这正是 ssBR 可行的关键。
"""
function ssbr_gibbs(y::Vector{Float64}, Zeff::Matrix{Float64}, Weps::Matrix{Float64},
                    A11inv::SparseMatrixCSC;
                    s2a::Float64, s2eps::Float64, s2e::Float64,
                    niter::Int=4000, burnin::Int=1000, rng=Random.default_rng())
    nr, m = size(Zeff); n1 = size(Weps, 2)
    zz = [dot(view(Zeff,:,j), view(Zeff,:,j)) for j in 1:m]
    ww = [dot(view(Weps,:,i), view(Weps,:,i)) for i in 1:n1]
    alpha = zeros(m); eps = zeros(n1); mu = mean(y)
    e = y .- mu
    sum_a = zeros(m); sum_e = zeros(n1); ks = 0
    rows = rowvals(A11inv); vals = nonzeros(A11inv)
    @inbounds for it in 1:niter
        # 截距
        old = mu
        mu  = mu + mean(e) + randn(rng)*sqrt(s2e/nr)
        e .-= (mu - old)
        # 标记效应（式 22.7 + 增量残差更新 22.48–22.49）
        for j in 1:m
            zj = view(Zeff, :, j); a0 = alpha[j]
            rhs = dot(zj, e) + zz[j]*a0
            Cj  = zz[j] + s2e/s2a
            alpha[j] = rhs/Cj + randn(rng)*sqrt(s2e/Cj)
            d = alpha[j] - a0
            @simd for r in 1:nr; e[r] -= zj[r]*d; end
        end
        # 填充误差 ε：逐元素 Gibbs，用稀疏 (A⁻¹)₁₁（式 23.39）
        for i in 1:n1
            wi = view(Weps, :, i); e0 = eps[i]
            rhs_dat = dot(wi, e) + ww[i]*e0
            off = 0.0; aii = 0.0
            for k2 in nzrange(A11inv, i)
                r = rows[k2]
                r == i ? (aii = vals[k2]) : (off += vals[k2]*eps[r])
            end
            ci   = ww[i]/s2e + aii/s2eps
            mu_i = (rhs_dat/s2e - off/s2eps)/ci
            eps[i] = mu_i + randn(rng)/sqrt(ci)
            d = eps[i] - e0
            @simd for r in 1:nr; e[r] -= wi[r]*d; end
        end
        if it > burnin
            ks += 1; sum_a .+= alpha; sum_e .+= eps
        end
    end
    return sum_a ./ ks, sum_e ./ ks, mu
end

# ---- 在本章的模拟数据上运行，并与 ssGBLUP 对照（定理 23.1）----
Zfull = zeros(n, size(Z2,2))
Zfull[geno, :]   .= Z2
Zfull[nogeno, :] .= P*Z2
Zeff = W*Zfull
Weps = W[:, nogeno]
A11i = Ainv[nogeno, nogeno]

s2alpha_ss = s2u/sum2pq
a_ss, eps_ss, mu_ss = ssbr_gibbs(y, Zeff, Weps, A11i;
        s2a=s2alpha_ss, s2eps=s2u, s2e=s2e,
        niter=5000, burnin=1200, rng=Xoshiro(2320))

u_ssbr = Zfull*a_ss
u_ssbr[nogeno] .+= eps_ss

# 对照：未调平的 ssGBLUP（G 奇异，加极小对角载荷以便求逆）
Ginv_pure = inv(Symmetric(G_ss .+ 1e-6 .* Matrix(I, n2, n2)))
Hinv_pure = build_Hinv(Ainv, Ginv_pure, A22inv_direct, geno)
_, u_ssg  = solve_mme(y, X, W, Hinv_pure, lam)

@printf("定理 23.1 的数值验证（ssBR 取正态先验）\n")
@printf("  cor(û_ssBR, û_ssGBLUP)        = %.5f\n", cor(u_ssbr, u_ssg))
@printf("  回归斜率 û_ssGBLUP ~ û_ssBR   = %.4f\n", cov(u_ssbr, u_ssg)/var(u_ssbr))
@printf("  与真值的相关： ssBR %.4f ， ssGBLUP %.4f\n",
        cor(u_ssbr, u_true), cor(u_ssg, u_true))
println("\n=> ssBR 不需要 G⁻¹，对奇异的 G 天然稳健（正文 §23.4.3）；")
println("   在正态先验下两者的解一致（蒙特卡洛误差内）。")

# %% [markdown]
# ## 9　ssBR：自实现与 JWAS 的对照（可选，需安装 JWAS）
#
# JWAS 的 `single_step_analysis = true` 实现的正是正文 §23.4 的 ssBR。对照其源码（`single_step/SSBR.jl`）可以确认三点，它们决定了应该怎样设置对照实验：
#
# 1. **缺失基因型的填充**：JWAS 解 $(\mathbf A^{-1})_{11}\mathbf M_1=-(\mathbf A^{-1})_{12}\mathbf M_2$，即 $\mathbf M_1=\mathbf A_{12}\mathbf A_{22}^{-1}\mathbf M_2$（式 23.35），而且用的是**已中心化**的 $\mathbf M_2$——与本笔记本的 `Zfull[nogeno, :] = P*Z2` 完全相同；
# 2. **填充误差 $\boldsymbol\varepsilon$** 的逆协方差取 $(\mathbf A^{-1})_{11}$（式 23.13），先验均值取遗传方差；但 JWAS **单独抽样** $\sigma^2_\varepsilon$（`set_random` 的默认 `estimate_variance = true`），而自实现把它固定为 $\sigma_u^2$；
# 3. **$\mathbf J$ 协变量**（Fernando 等 2014 的"中心化参数"）默认拟合；为与定理 23.1 的纯形式对照，这里设 `fitting_J_vector = false`。
#
# 因此两者**不会逐位相等**（第 2 点），但 EBV 的相关应在 0.98 以上；若远低于此，先检查个体编号是否对齐。

# %%
RUN_JWAS = false            # 先实例化可选环境 envs/jwas（附录 E），再改为 true
if RUN_JWAS
    let env = joinpath(dirname(Base.active_project()), "envs", "jwas")
        isdir(env) || (env = normpath(joinpath(pwd(), "..", "envs", "jwas")))
        env in LOAD_PATH || push!(LOAD_PATH, env)   # 叠加可选环境（附录 E）
    end
    using JWAS, DataFrames
end

# %%
if RUN_JWAS
    ped_df = DataFrame(ID   = string.(1:n),
                       Sire = [s > 0 ? string(s) : missing for s in sire],   # 未知亲本用 missing
                       Dam  = [d > 0 ? string(d) : missing for d in dam])
    pedigree = get_pedigree(ped_df)

    gdf = DataFrame(Mg2[geno, :], ["m$j" for j in 1:size(Mg2, 2)])
    insertcols!(gdf, 1, :ID => string.(geno))
    phen = DataFrame(ID = string.(has_rec), y = y)

    # 与 ssbr_gibbs 相同：正态先验（RR-BLUP），标记方差与残差方差固定为真值，不拟合 J
    geno_ss = get_genotypes(gdf, s2u; method = "RR-BLUP", estimatePi = false,
                            estimate_variance = false, quality_control = false, center = true)
    model = build_model("y = intercept + geno_ss", s2e; estimate_variance = false)
    out = runMCMC(model, phen; single_step_analysis = true, pedigree = pedigree,
                  fitting_J_vector = false,
                  chain_length = 20_000, burnin = 4_000, output_samples_frequency = 10,
                  seed = 2330, printout_model_info = false, output_folder = "jwas_ch23")

    ebv = out["EBV_y"]
    dct = Dict(string(r.ID) => Float64(r.EBV) for r in eachrow(ebv))
    idx = [i for i in 1:n if haskey(dct, string(i))]
    u_jwas = [dct[string(i)] for i in idx]

    @printf("JWAS 输出了 %d / %d 个个体的 EBV\n", length(idx), n)
    @printf("cor(û_自实现 ssBR, û_JWAS ssBR) = %.4f\n", cor(u_ssbr[idx], u_jwas))
    @printf("cor(û_JWAS ssBR, û_ssGBLUP)     = %.4f\n", cor(u_jwas, u_ssg[idx]))
    @printf("与真值的相关：自实现 %.4f ， JWAS %.4f\n",
            cor(u_ssbr[idx], u_true[idx]), cor(u_jwas, u_true[idx]))
    rm("jwas_ch23"; recursive = true, force = true)
    rm("IDs_for_individuals_with_pedigree.txt"; force = true)
else
    println("RUN_JWAS = false：跳过 ssBR 的 JWAS 对照。")
end

# %% [markdown]
# ## 10　自检汇总

# %%
ok = Bool[]
push!(ok, check("A·A⁻¹ = I",                 Matrix(Ainv)*A, Matrix(I,n,n); tol=1e-8))
push!(ok, check("G = A22 ⇒ H = A",           build_H(A, A22, nogeno, geno), A; tol=1e-8))
push!(ok, check("G = A22 ⇒ H⁻¹ = A⁻¹",       build_Hinv(Ainv, inv(A22), A22inv_direct, geno), Matrix(Ainv); tol=1e-8))
push!(ok, check("式 (23.27) Schur 补",        A22inv_schur(Ainv, nogeno, geno), inv(A22); tol=1e-7))
push!(ok, check("式 (23.13) A11.2⁻¹=(A⁻¹)₁₁", inv(A112), Matrix(Ainv[nogeno,nogeno]); tol=1e-7))
push!(ok, check("Colleau A·v",                colleau_Av(vt, sire, dam, dvec), A*vt; tol=1e-9))
push!(ok, check("定理 23.1",                  H_ssbr, H_ssg; tol=1e-8))
push!(ok, check("调平：对角均值",              mean(diag(Gstar)), mean(diag(A22)); tol=1e-12))
push!(ok, check("去回归 c=0 ⇒ w=q_i",
                garrick_weight(0.25, deregress(120.0,80.0,0.25,0.30,0.85).r2, 0.0),
                effective_records(0.25,0.30,0.85)[3]; tol=1e-10))
push!(ok, check("PCG = 直接解",               xpcg[p_fix+1:end], u_ss; tol=1e-6))
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
