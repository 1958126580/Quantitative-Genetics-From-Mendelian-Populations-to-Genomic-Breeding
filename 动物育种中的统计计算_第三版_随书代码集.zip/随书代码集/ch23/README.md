# 第二十三章　单步法与多信息源整合 —— 配套代码

**所属**：第五篇　基因组选择与基因组预测　　**对应正文**：第二十三章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch23.ipynb` | IJulia 笔记本：17 个代码单元，约 606 行 Julia 代码，穿插与正文对应的说明 |
| `ch23.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |

## 笔记本内容

- 2　$\mathbf H$ 与 $\mathbf H^{-1}$
- 3　调平（正文 §23.2.3）
- 4　$\mathbf A_{22}^{-1}$：三条路径与一个重要警告
- 5　ssGBLUP 的求解
  - 5.1 未调平的后果（正文 §23.2.3 的症状清单）
  - 5.2 PCG 求解（正文 §23.3.3）
- 6　Metafounder 的 $\gamma$ 估计（正文式 23.22–23.25）
- 7　去回归（正文式 23.43–23.52）
- 8　ssBR 与定理 23.1 的验证
- 9　ssBR：自实现与 JWAS 的对照（可选，需安装 JWAS）
- 10　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 23
```

或在 Jupyter 中打开 `ch23/ch23.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 可选单元

- 开关 `RUN_JWAS`（默认 `false`）：JWAS 2.4（与 JWAS 的交叉验证单元）；需先实例化 `envs/jwas`：`julia --project=envs/jwas -e 'using Pkg; Pkg.instantiate()'`，再把笔记本中的开关改为 `true`。
- 开关关闭时只打印一行提示并跳过，不影响其余单元（见 `../README.md` 与正文附录 E）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 本章没有单独的 Python 复核脚本：正文中的解析数值已在写作时用 Python 逐一复算。
