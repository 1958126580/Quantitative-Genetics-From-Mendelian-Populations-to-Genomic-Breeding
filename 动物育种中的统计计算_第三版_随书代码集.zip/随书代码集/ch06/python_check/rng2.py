# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 rng2.py    依赖：numpy
import numpy as np
from numpy.random import SeedSequence, PCG64, Generator
def trunc(g, n, lo):
    out=[]; ndraw=0
    while len(out)<n:
        x=g.standard_normal(); ndraw+=1
        if x>lo: out.append(x)
    return np.array(out), ndraw
for lo in [1.0, 1.2, 1.5]:
    g=Generator(PCG64(99)); x,nd=trunc(g,20,lo)
    nxt=g.standard_normal(3)
    print(f'截断点 {lo}: 抽 20 个留种用了 {nd} 次抽样；之后紧接着的 3 个数 = {np.round(nxt,5)}')
print()
print('-> 同一条流、同一个种子，只改选择强度，"之后"的所有随机量全部错位。')
print('   把"选择"和"下一世代的孟德尔抽样"放在同一条流上，就会出现这种耦合。')
print()
# 正确做法：每个环节一条独立子流
ss = SeedSequence(99)
names = ['founder','meiosis','phenotype','selection']
kids = dict(zip(names, ss.spawn(len(names))))
def gen(name): return Generator(PCG64(kids[name]))
for lo in [1.0, 1.5]:
    gsel = gen('selection'); x,nd = trunc(gsel, 20, lo)
    gme  = gen('meiosis')
    print(f'截断点 {lo}: 选择用了 {nd} 次抽样；减数分裂流的前 3 个数 = {np.round(gme.standard_normal(3),5)}')
print('-> 按环节分流后，改选择强度不影响减数分裂流。')
