# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 breed.py    依赖：numpy
"""育种代码的可断言恒等式：逐条数值验证，报告实际残差量级。"""
import numpy as np
np.set_printoptions(precision=6, suppress=True)

def random_pedigree(n, nbase, rng):
    s = np.zeros(n, int); d = np.zeros(n, int)
    for i in range(nbase, n):
        s[i] = rng.integers(0, i) + 1
        d[i] = rng.integers(0, i) + 1
        while d[i] == s[i]:
            d[i] = rng.integers(0, i) + 1
    return s, d

def build_A(s, d):
    n = len(s); A = np.zeros((n, n))
    for i in range(n):
        si, di = s[i]-1, d[i]-1
        for j in range(i):
            a_sj = A[si, j] if si >= 0 else 0.0
            a_dj = A[di, j] if di >= 0 else 0.0
            A[i, j] = A[j, i] = 0.5*(a_sj + a_dj)
        A[i, i] = 1.0 + (0.5*A[si, di] if (si >= 0 and di >= 0) else 0.0)
    return A

def dvec(s, d, F):
    n = len(s); dd = np.empty(n)
    for i in range(n):
        si, di = s[i]-1, d[i]-1
        if si >= 0 and di >= 0: dd[i] = 0.5 - 0.25*(F[si]+F[di])
        elif si >= 0:           dd[i] = 0.75 - 0.25*F[si]
        elif di >= 0:           dd[i] = 0.75 - 0.25*F[di]
        else:                   dd[i] = 1.0
    return dd

def build_Ainv(s, d, F):
    n = len(s); dd = dvec(s, d, F); Ai = np.zeros((n, n))
    for i in range(n):
        si, di = s[i]-1, d[i]-1
        idx = [i] + ([si] if si >= 0 else []) + ([di] if di >= 0 else [])
        q   = [1.0] + ([-0.5] if si >= 0 else []) + ([-0.5] if di >= 0 else [])
        for a, qa in zip(idx, q):
            for b, qb in zip(idx, q):
                Ai[a, b] += qa*qb/dd[i]
    return Ai

def build_T(s, d):
    n = len(s); T = np.eye(n)
    for i in range(n):
        si, di = s[i]-1, d[i]-1
        if si >= 0: T[i] += 0.5*T[si]
        if di >= 0: T[i] += 0.5*T[di]
    return T

rng = np.random.default_rng(20260605)
n, nbase = 400, 40
s, d = random_pedigree(n, nbase, rng)
A = build_A(s, d); F = np.diag(A) - 1.0
Ai = build_Ainv(s, d, F)

print('='*72); print('第一组：关系矩阵'); print('='*72)
print('T1 对称性       max|Ai - Ai\'|            = %.3e' % np.abs(Ai - Ai.T).max())
print('T2 A·Ai = I     max|A Ai - I|            = %.3e' % np.abs(A @ Ai - np.eye(n)).max())
rs = Ai.sum(axis=1)
both = (s > 0) & (d > 0); base = (s == 0) & (d == 0)
print('T3 行和（双亲已知个体）max|rowsum|        = %.3e   （理论值 0）' % np.abs(rs[both]).max())
print('   行和（基础群个体） 取值集合           = %s   （理论值 1）' % np.unique(np.round(rs[base], 12)))
print('   1\'Ai·1 = %.12f，基础群个体数 = %d' % (np.ones(n) @ Ai @ np.ones(n), base.sum()))
nz = np.count_nonzero(np.abs(Ai) > 1e-14)
print('T4 稀疏性       nnz(Ai) = %d ≤ 9n = %d；n=%d 时密度 %.4f' % (nz, 9*n, n, nz/n**2))
Fchk = np.array([A[s[i]-1, d[i]-1]/2 if (s[i] > 0 and d[i] > 0) else 0.0 for i in range(n)])
print('T5 F_i = a_sd/2 max|F - a_sd/2|          = %.3e' % np.abs(F - Fchk).max())
print('T6 diag(A)=1+F  max|diag(A)-1-F|         = %.3e' % np.abs(np.diag(A) - 1 - F).max())
T = build_T(s, d); D = np.diag(dvec(s, d, F))
print('T7 A = TDT\'     max|A - TDT\'|            = %.3e' % np.abs(A - T @ D @ T.T).max())
print('   近交系数范围 [%.4f, %.4f]，平均 %.4f' % (F.min(), F.max(), F.mean()))

print()
print('='*72); print('第二组：混合模型方程组'); print('='*72)
h2 = 0.3; lam = (1-h2)/h2
nh = 8
herd = rng.integers(0, nh, n)
X = np.zeros((n, nh)); X[np.arange(n), herd] = 1.0
Z = np.eye(n)
a = np.linalg.cholesky(A + 1e-10*np.eye(n)) @ rng.standard_normal(n) * np.sqrt(h2)
y = X @ (rng.standard_normal(nh)*0.5) + a + rng.standard_normal(n)*np.sqrt(1-h2)
def solve_mme(X, Z, Ai, y, lam):
    p = X.shape[1]; q = Z.shape[1]
    C = np.block([[X.T@X, X.T@Z], [Z.T@X, Z.T@Z + lam*Ai]])
    r = np.concatenate([X.T@y, Z.T@y])
    sol = np.linalg.lstsq(C, r, rcond=None)[0]
    return sol[:p], sol[p:], C, r
b, u, C, r = solve_mme(X, Z, Ai, y, lam)
e = y - X@b - Z@u
print('T8  X\'ê = 0          max|X\'e|            = %.3e   (||y||=%.2f)' % (np.abs(X.T@e).max(), np.linalg.norm(y)))
print('T9  Z\'ê = λ Ai û     max|Z\'e - λAi u|    = %.3e' % np.abs(Z.T@e - lam*Ai@u).max())
print('T10 残差和（含同期组固定效应）sum(e) = %.3e' % e.sum())
# λ -> 0 与 λ -> ∞
b0, u0, *_ = solve_mme(X, Z, Ai, y, 1e-8)
yhat0 = X@b0 + Z@u0
print('T11 λ→0（1e-8）：max|ŷ - y| = %.3e   （饱和拟合）' % np.abs(yhat0 - y).max())
bI, uI, *_ = solve_mme(X, Z, Ai, y, 1e8)
bols = np.linalg.lstsq(X, y, rcond=None)[0]
print('    λ→∞（1e8）：max|û| = %.3e；max|b̂-OLS| = %.3e' %
      (np.abs(uI).max(), np.abs(bI - bols).max()))
# 平移与缩放
c = 137.0
b2, u2, *_ = solve_mme(X, Z, Ai, y + c, lam)
print('T12 平移 y+c：max|û2 - û| = %.3e；b̂ 的平移量 max|b̂2-b̂-c| = %.3e' %
      (np.abs(u2-u).max(), np.abs(b2-b-c).max()))
k = 2.5
b3, u3, *_ = solve_mme(X, Z, Ai, k*y, lam)
print('T13 缩放 k·y：max|û3 - k·û|/k = %.3e' % (np.abs(u3-k*u).max()/k))
# 置换不变性
perm = rng.permutation(n)
# 重新编号必须保持拓扑序：这里用"个体顺序不变、只换同期组编号"的置换做等价检验
hperm = rng.permutation(nh)
Xp = X[:, hperm]
bp, up, *_ = solve_mme(Xp, Z, Ai, y, lam)
print('T14 同期组重编号：max|ûp - û| = %.3e；max|b̂p - b̂[perm]| = %.3e' %
      (np.abs(up-u).max(), np.abs(bp - b[hperm]).max()))
# PEV 与可靠性
Cg = np.linalg.pinv(C)
PEV = np.diag(Cg)[nh:] * (1-h2)
rel = 1 - PEV/(h2*(1+F))
print('T15 可靠性范围 [%.4f, %.4f]（须落在 [0,1]）；PEV ≤ σ_a²(1+F) 违反次数 %d' %
      (rel.min(), rel.max(), np.sum(PEV > h2*(1+F) + 1e-12)))
print('T16 1\'Ai·û = %.3e（基础群育种值的加权和）' % (np.ones(n) @ Ai @ u))
