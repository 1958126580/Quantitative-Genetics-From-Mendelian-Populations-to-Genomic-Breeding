# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 fp3.py    依赖：numpy, scipy, threadpoolctl
import numpy as np, struct
from threadpoolctl import threadpool_limits
from scipy.linalg import blas

def ulps(a, b):
    ia = struct.unpack('<q', struct.pack('<d', a))[0]
    ib = struct.unpack('<q', struct.pack('<d', b))[0]
    if ia < 0: ia = -9223372036854775808 - ia
    if ib < 0: ib = -9223372036854775808 - ib
    return abs(ia - ib)

rng = np.random.default_rng(7)
print('=== ddot：长向量内积，1 vs 2 线程 ===')
for n in [10**6, 10**7, 5*10**7]:
    a = rng.standard_normal(n); b = rng.standard_normal(n)
    with threadpool_limits(limits=1, user_api='blas'): d1 = float(blas.ddot(a, b))
    with threadpool_limits(limits=2, user_api='blas'): d2 = float(blas.ddot(a, b))
    print(f'n={n:>10d}  1线程 {d1!r}   2线程 {d2!r}   ulp={ulps(d1,d2)}  rel={abs(d1-d2)/max(abs(d1),1e-300):.2e}')

print()
print('=== dgemv：X\'y，1 vs 2 线程 ===')
n, p = 2_000_000, 40
X = rng.standard_normal((n, p)); y = rng.standard_normal(n)
with threadpool_limits(limits=1, user_api='blas'): v1 = X.T @ y
with threadpool_limits(limits=2, user_api='blas'): v2 = X.T @ y
print('max ulp =', max(ulps(float(a), float(b)) for a, b in zip(v1, v2)),
      ' 完全相同:', np.array_equal(v1, v2))

print()
print('=== syrk vs gemm（同一个 G，同 1 线程）===')
n, m = 800, 4000
p = rng.uniform(0.05, 0.95, m)
M = (rng.random((n, m)) < p).astype(float) + (rng.random((n, m)) < p).astype(float)
Z = M - 2*p; den = 2*np.sum(p*(1-p))
with threadpool_limits(limits=1, user_api='blas'):
    Gs = blas.dsyrk(alpha=1.0/den, a=Z, lower=0)
    Gg = Z @ Z.T / den
iu = np.triu_indices(n)
a_, b_ = Gs[iu], Gg[iu]
big = np.abs(a_) > 0.05
print('上三角元素数 %d，其中 |g|>0.05 的 %d' % (len(a_), big.sum()))
print('逐位相同的比例（全部）= %.4f' % np.mean(a_ == b_))
print('|g|>0.05 上：max ulp = %d，max 相对差 = %.2e' %
      (max(ulps(float(x), float(y)) for x, y in zip(a_[big], b_[big])),
       (np.abs(a_[big]-b_[big])/np.abs(a_[big])).max()))
print('对角线：max ulp = %d' % max(ulps(float(Gs[i,i]), float(Gg[i,i])) for i in range(n)))
print('tr/n: syrk %.17g  gemm %.17g  ulp=%d' %
      (np.trace(Gs)/n, np.trace(Gg)/n, ulps(np.trace(Gs)/n, np.trace(Gg)/n)))
