# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 fp.py    依赖：numpy, threadpoolctl
"""浮点不可复现的四个来源：求和次序、BLAS 线程数、BLAS 实现/算法路径、fastmath 允许的变换。"""
import numpy as np, math, struct
from fractions import Fraction
from threadpoolctl import threadpool_limits

def ulps(a, b):
    """两个 float64 之间相差多少个 ulp（按位序距离）。"""
    ia = struct.unpack('<q', struct.pack('<d', a))[0]
    ib = struct.unpack('<q', struct.pack('<d', b))[0]
    if ia < 0: ia = -9223372036854775808 - ia
    if ib < 0: ib = -9223372036854775808 - ib
    return abs(ia - ib)

def exact_sum(x):
    return float(math.fsum(x.tolist()))

print('='*70)
print('实验 1：求和次序（分块数 = 线程数）对 X\'y 型累加的影响')
print('='*70)
rng = np.random.default_rng(20260601)
n = 5_000_000
# 模拟表型：大均值 + 小离差（产奶量 kg，均值 9000，sd 1500）
y = 9000.0 + 1500.0 * rng.standard_normal(n)
ref = exact_sum(y)
print(f'n = {n}, 精确和（fsum） = {ref!r}')
rows = []
for nb in [1, 2, 4, 8, 16, 32, 64, 128]:
    parts = np.array_split(y, nb)
    # 块内严格顺序累加（math.fsum 会补偿，所以手写循环）
    s = 0.0
    partials = []
    for p in parts:
        t = 0.0
        for v in p.tolist():
            t += v
        partials.append(t)
    tot = 0.0
    for t in partials:
        tot += t
    rows.append((nb, tot, ulps(tot, ref), abs(tot-ref)/abs(ref)))
    print(f'{nb:4d} 块  {tot!r}  ulp={ulps(tot,ref):8d}  rel={abs(tot-ref)/abs(ref):.3e}')
print()
print('numpy 的 pairwise sum:', repr(float(np.sum(y))), 'ulp=', ulps(float(np.sum(y)), ref))
