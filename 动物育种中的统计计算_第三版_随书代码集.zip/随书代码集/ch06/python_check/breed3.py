# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 breed3.py    依赖：numpy, scipy
import numpy as np
from scipy.optimize import minimize_scalar
rng = np.random.default_rng(20260606)
ns, k = 25, 10
alpha = rng.standard_normal(ns)*np.sqrt(0.35)
y = alpha[:,None] + rng.standard_normal((ns,k))*np.sqrt(0.65)
ybar_i=y.mean(1); ybar=y.mean()
MSB=k*np.sum((ybar_i-ybar)**2)/(ns-1); MSW=np.sum((y-ybar_i[:,None])**2)/(ns*(k-1))
a_sa2=(MSB-MSW)/k; a_se2=MSW
yv=y.ravel(); Z=np.kron(np.eye(ns),np.ones((k,1))); X=np.ones((ns*k,1))
def negREML(logr):
    r=np.exp(logr); V=Z@Z.T*r+np.eye(ns*k)
    L=np.linalg.cholesky(V); Vi=np.linalg.inv(V)
    XtViX=X.T@Vi@X
    P=Vi-Vi@X@np.linalg.solve(XtViX,X.T@Vi)
    yPy=float(yv@P@yv); nmp=ns*k-1
    return 0.5*(2*np.sum(np.log(np.diag(L)))+np.log(np.linalg.det(XtViX))+nmp*np.log(yPy/nmp))
print('REML=ANOVA 检验的残差随优化器容差变化（说明残差量的是收敛精度，不是公式对错）：')
for xt in [1e-4, 1e-6, 1e-8, 1e-10, 1e-12]:
    res=minimize_scalar(negREML,bracket=(-3,0),method='brent',options={'xtol':xt})
    r=np.exp(res.x); V=Z@Z.T*r+np.eye(ns*k); Vi=np.linalg.inv(V)
    P=Vi-Vi@X@np.linalg.solve(X.T@Vi@X,X.T@Vi)
    se2=float(yv@P@yv)/(ns*k-1); sa2=r*se2
    print('  xtol=%.0e -> σ_a² 相对差 %.2e，σ_e² 相对差 %.2e' %
          (xt, abs(sa2-a_sa2)/a_sa2, abs(se2-a_se2)/a_se2))
print('  ANOVA 参照：σ_a²=%.12f σ_e²=%.12f' % (a_sa2, a_se2))

print()
print('中心化基准对 1\'W 与 mean(G) 的影响：')
nn,m=800,3000
p=rng.uniform(0.05,0.95,m)
M=(rng.random((nn,m))<p).astype(float)+(rng.random((nn,m))<p).astype(float)
for name,pp in [('真（基础群）频率 p', p), ('样本频率 p̂', M.mean(0)/2)]:
    W=M-2*pp; den=2*np.sum(pp*(1-pp)); G=W@W.T/den
    print('  %s: max|1\'W| = %.3e, mean(G) = %.3e, tr(G)/n = %.6f' %
          (name, np.abs(W.sum(0)).max(), G.mean(), np.trace(G)/nn))
