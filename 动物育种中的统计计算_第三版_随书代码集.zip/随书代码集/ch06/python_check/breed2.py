# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 breed2.py    依赖：numpy, scipy
"""第二批断言：REML=ANOVA、多性状退化、G 矩阵、单步 H⁻¹、EM 单调、PCG。"""
import numpy as np
from scipy.optimize import minimize_scalar
rng = np.random.default_rng(20260606)

print('='*72); print('T17 平衡单因子随机模型：REML = ANOVA（精确相等）'); print('='*72)
ns, k = 25, 10
sa2, se2 = 0.35, 0.65
alpha = rng.standard_normal(ns)*np.sqrt(sa2)
y = (alpha[:, None] + rng.standard_normal((ns, k))*np.sqrt(se2))
ybar_i = y.mean(1); ybar = y.mean()
MSB = k*np.sum((ybar_i-ybar)**2)/(ns-1)
MSW = np.sum((y - ybar_i[:, None])**2)/(ns*(k-1))
anova_sa2 = (MSB-MSW)/k; anova_se2 = MSW
yv = y.ravel()
Z = np.kron(np.eye(ns), np.ones((k, 1)))
X = np.ones((ns*k, 1))
def negREML(logr):
    r = np.exp(logr)                     # r = sa2/se2
    V = Z@Z.T*r + np.eye(ns*k)           # V/se2
    L = np.linalg.cholesky(V)
    Vi = np.linalg.inv(V)
    XtViX = X.T@Vi@X
    P = Vi - Vi@X@np.linalg.solve(XtViX, X.T@Vi)
    yPy = float(yv@P@yv)
    ld = 2*np.sum(np.log(np.diag(L)))
    ldx = np.log(np.linalg.det(XtViX))
    nmp = ns*k - 1
    return 0.5*(ld + ldx + nmp*np.log(yPy/nmp))
res = minimize_scalar(negREML, bracket=(-3, 0), method='brent', options={'xtol': 1e-12})
r = np.exp(res.x)
V = Z@Z.T*r + np.eye(ns*k); Vi = np.linalg.inv(V)
P = Vi - Vi@X@np.linalg.solve(X.T@Vi@X, X.T@Vi)
se2_hat = float(yv@P@yv)/(ns*k-1); sa2_hat = r*se2_hat
print('ANOVA : σ_a² = %.12f  σ_e² = %.12f' % (anova_sa2, anova_se2))
print('REML  : σ_a² = %.12f  σ_e² = %.12f' % (sa2_hat, se2_hat))
print('相对差: σ_a² %.2e   σ_e² %.2e' % (abs(sa2_hat-anova_sa2)/anova_sa2, abs(se2_hat-anova_se2)/anova_se2))

print()
print('='*72); print('T18 多性状：G0 ∝ R0 且无缺失 -> 与逐性状单性状 BLUP 完全一致'); print('='*72)
n = 200
Ai = np.eye(n)*1.0   # 用独立个体简化；结论与 A 无关
c = 0.4
R0 = np.array([[1.0, 0.5], [0.5, 2.0]])
G0 = c*R0
y2 = rng.standard_normal((n, 2))
X1 = np.ones((n, 1))
def mt_blup(y2, G0, R0, Ai):
    n, t = y2.shape
    Ri = np.linalg.inv(R0); Gi = np.linalg.inv(G0)
    # 按性状分块排列：u = (u_1, u_2)
    ZtRZ = np.kron(Ri, np.eye(n))
    lhs = ZtRZ + np.kron(Gi, Ai)
    rhs = (np.kron(Ri, np.eye(n)) @ y2.T.ravel())
    return np.linalg.solve(lhs, rhs).reshape(t, n)
umt = mt_blup(y2, G0, R0, Ai)
ust = np.array([np.linalg.solve(np.eye(n)/R0[j, j] + Ai/G0[j, j], y2[:, j]/R0[j, j]) for j in range(2)])
print('max|u_多性状 - u_单性状| = %.3e   (||u||=%.3f)' % (np.abs(umt-ust).max(), np.linalg.norm(ust)))
# 反例：G0 与 R0 不成比例
G0b = np.array([[0.4, 0.05], [0.05, 0.8]])
umt2 = mt_blup(y2, G0b, R0, Ai)
ust2 = np.array([np.linalg.solve(np.eye(n)/R0[j, j] + Ai/G0b[j, j], y2[:, j]/R0[j, j]) for j in range(2)])
print('反例（G0 与 R0 不成比例）：max|Δ| = %.3e  -> 断言有鉴别力' % np.abs(umt2-ust2).max())

print()
print('='*72); print('T19 G 矩阵（VanRaden 方法 1，基础群频率）'); print('='*72)
nn, m = 1500, 5000
p = rng.uniform(0.05, 0.95, m)
M = (rng.random((nn, m)) < p).astype(float) + (rng.random((nn, m)) < p).astype(float)
W = M - 2*p
den = 2*np.sum(p*(1-p))
G = W@W.T/den
off = G[~np.eye(nn, dtype=bool)]
print('tr(G)/n = %.6f （HWE + 真频率下期望 1）' % (np.trace(G)/nn))
print('非对角均值 = %.3e （期望 0），标准差 = %.4f' % (off.mean(), off.std()))
print('全矩阵均值 = %.3e （期望 0，因 1\'W = 0）' % G.mean())
print('列和 max|1\'W| = %.3e （中心化的直接后果）' % np.abs(W.sum(0)).max())
ev = np.linalg.eigvalsh(G)
print('最小特征值 = %.3e （m>n 时应 >0；m<n 时必有 0）' % ev.min())
# m < n 的情形
G2 = (W[:, :800]@W[:, :800].T)/(2*np.sum(p[:800]*(1-p[:800])))
print('m=800 < n=1500 时最小特征值 = %.3e，秩 = %d （上界 min(n,m)=800）' %
      (np.linalg.eigvalsh(G2).min(), np.linalg.matrix_rank(G2, tol=1e-8)))

print()
print('='*72); print('T20 单步 H⁻¹ 的结构：只有基因型块被修改'); print('='*72)
def random_pedigree(n, nbase, rng):
    s = np.zeros(n, int); d = np.zeros(n, int)
    for i in range(nbase, n):
        s[i] = rng.integers(0, i)+1; d[i] = rng.integers(0, i)+1
        while d[i] == s[i]: d[i] = rng.integers(0, i)+1
    return s, d
def build_A(s, d):
    n = len(s); A = np.zeros((n, n))
    for i in range(n):
        si, di = s[i]-1, d[i]-1
        for j in range(i):
            A[i, j] = A[j, i] = 0.5*((A[si, j] if si >= 0 else 0)+(A[di, j] if di >= 0 else 0))
        A[i, i] = 1.0 + (0.5*A[si, di] if si >= 0 and di >= 0 else 0.0)
    return A
npd, nb = 300, 30
sp, dp = random_pedigree(npd, nb, rng)
Ap = build_A(sp, dp)
gen = np.sort(rng.choice(npd, 120, replace=False))     # 有基因型的个体
ngen = np.setdiff1d(np.arange(npd), gen)
Gsub = 0.95*(G[:120, :120]/1.0) + 0.05*Ap[np.ix_(gen, gen)]
A22 = Ap[np.ix_(gen, gen)]
Api = np.linalg.inv(Ap)
Hi = Api.copy()
Hi[np.ix_(gen, gen)] += np.linalg.inv(Gsub) - np.linalg.inv(A22)
D = Hi - Api
mask = np.zeros((npd, npd), bool); mask[np.ix_(gen, gen)] = True
print('H⁻¹ - A⁻¹ 在基因型块外的 max|Δ| = %.3e' % np.abs(D[~mask]).max())
print('在基因型块内的 max|Δ| = %.3f' % np.abs(D[mask]).max())
print('H⁻¹ 对称性 max|H⁻¹-H⁻¹\'| = %.3e' % np.abs(Hi-Hi.T).max())
