# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 breed5.py    依赖：numpy
"""病态测试数据的具体制造法：每一种病态各造成什么后果。"""
import numpy as np
rng=np.random.default_rng(20260609)
def rand_ped(n,nbase,rng):
    s=np.zeros(n,int); d=np.zeros(n,int)
    for i in range(nbase,n):
        s[i]=rng.integers(0,i)+1; d[i]=rng.integers(0,i)+1
        while d[i]==s[i]: d[i]=rng.integers(0,i)+1
    return s,d
def build_A(s,d):
    n=len(s); A=np.zeros((n,n))
    for i in range(n):
        si,di=s[i]-1,d[i]-1
        for j in range(i):
            A[i,j]=A[j,i]=0.5*((A[si,j] if si>=0 else 0)+(A[di,j] if di>=0 else 0))
        A[i,i]=1.0+(0.5*A[si,di] if si>=0 and di>=0 else 0.0)
    return A
def build_Ainv(s,d,F):
    n=len(s); dd=np.empty(n)
    for i in range(n):
        si,di=s[i]-1,d[i]-1
        if si>=0 and di>=0: dd[i]=0.5-0.25*(F[si]+F[di])
        elif si>=0: dd[i]=0.75-0.25*F[si]
        elif di>=0: dd[i]=0.75-0.25*F[di]
        else: dd[i]=1.0
    Ai=np.zeros((n,n))
    for i in range(n):
        si,di=s[i]-1,d[i]-1
        idx=[i]+([si] if si>=0 else [])+([di] if di>=0 else [])
        q=[1.0]+([-0.5] if si>=0 else [])+([-0.5] if di>=0 else [])
        for a,qa in zip(idx,q):
            for b,qb in zip(idx,q): Ai[a,b]+=qa*qb/dd[i]
    return Ai

n=500; s_,d_=rand_ped(n,50,rng); A_=build_A(s_,d_); F_=np.diag(A_)-1; Ai=build_Ainv(s_,d_,F_)
print('=== 病态 1：单记录同期组 ===')
for nh,label in [(10,'每组约 50 条'),(100,'每组约 5 条'),(250,'每组约 2 条')]:
    herd=rng.integers(0,nh,n); X=np.zeros((n,nh)); X[np.arange(n),herd]=1
    sizes=X.sum(0)
    for h2 in [0.5]:
        lam=(1-h2)/h2
        C=np.block([[X.T@X,X.T],[X,np.eye(n)+lam*Ai]])
        ev=np.abs(np.linalg.eigvalsh(C))
        print('  %-10s 组数=%3d，最小组容量=%d，空组=%d，cond(C)=%.3e'
              %(label,nh,int(sizes.min()),int((sizes==0).sum()),ev.max()/ev.min()))

print()
print('=== 病态 2：h² 极端值把 MME 推向两端 ===')
nh=20; herd=rng.integers(0,nh,n); X=np.zeros((n,nh)); X[np.arange(n),herd]=1
for h2 in [0.99,0.5,0.05,0.01,0.001]:
    lam=(1-h2)/h2
    C=np.block([[X.T@X,X.T],[X,np.eye(n)+lam*Ai]])
    ev=np.abs(np.linalg.eigvalsh(C))
    print('  h²=%-6.3g λ=%-9.3g cond(C)=%.3e'%(h2,lam,ev.max()/ev.min()))

print()
print('=== 病态 3：G 矩阵的奇异来源 ===')
nn,m=300,1200
p=rng.uniform(0.05,0.95,m)
M=(rng.random((nn,m))<p).astype(float)+(rng.random((nn,m))<p).astype(float)
def Gmat(M):
    ph=M.mean(0)/2; W=M-2*ph; return W@W.T/(2*np.sum(ph*(1-ph)))
G0=Gmat(M); e0=np.linalg.eigvalsh(G0)
M2=M.copy(); M2[1]=M2[0]                      # 一对重复基因型（同一头牛被录入两次）
G1=Gmat(M2); e1=np.linalg.eigvalsh(G1)
M3=M.copy(); M3[:,:50]=0.0                     # 50 个单态位点
G2=Gmat(M3); e2=np.linalg.eigvalsh(G2)
print('  正常：λ_min=%.3e  cond=%.3e'%(e0.min(),e0.max()/max(e0.min(),1e-300)))
print('  含 1 对重复基因型：λ_min=%.3e  cond=%.3e'%(e1.min(),e1.max()/max(abs(e1.min()),1e-300)))
print('  含 50 个单态位点：λ_min=%.3e（2Σp̂q̂ 的分母变了 %.4f 倍）'
      %(e2.min(), (2*np.sum((M3.mean(0)/2)*(1-M3.mean(0)/2)))/(2*np.sum((M.mean(0)/2)*(1-M.mean(0)/2)))))
ph=M3.mean(0)/2
print('  单态位点上 p̂(1-p̂)=0，中心化后整列为 0：贡献 %d 个零列' % int(np.sum(ph*(1-ph)==0)))

print()
print('=== 病态 4：无记录但有后代的个体（必须进 MME） ===')
has=np.ones(n,bool); has[rng.choice(np.arange(50),20,replace=False)]=False   # 20 头基础公畜无记录
nm=has.sum()
Zf=np.eye(n)[has]
herd2=herd[has]; Xf=np.zeros((nm,nh)); Xf[np.arange(nm),herd2]=1
lam=(1-0.3)/0.3
Cf=np.block([[Xf.T@Xf,Xf.T@Zf],[Zf.T@Xf,Zf.T@Zf+lam*Ai]])
ev=np.abs(np.linalg.eigvalsh(Cf))
print('  有记录个体 %d / %d；MME 维数 %d；cond=%.3e（无记录个体仍可得到 EBV）'
      %(nm,n,Cf.shape[0],ev.max()/ev.min()))
yf=rng.standard_normal(nm)
sol=np.linalg.lstsq(Cf,np.concatenate([Xf.T@yf,Zf.T@yf]),rcond=None)[0]
u=sol[nh:]
print('  无记录个体的 |û| 范围 [%.4f, %.4f]（若实现错误，这些值会恒为 0）'
      %(np.abs(u[~has]).min(),np.abs(u[~has]).max()))
