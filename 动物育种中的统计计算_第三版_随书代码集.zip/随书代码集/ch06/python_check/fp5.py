# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 fp5.py    依赖：numpy
import numpy as np, struct
from fractions import Fraction
def ulps(a,b):
    ia=struct.unpack('<q',struct.pack('<d',a))[0]; ib=struct.unpack('<q',struct.pack('<d',b))[0]
    if ia<0: ia=-9223372036854775808-ia
    if ib<0: ib=-9223372036854775808-ib
    return abs(ia-ib)
rng=np.random.default_rng(11)
A=rng.standard_normal(20000)*3; B=rng.standard_normal(20000)*3; C=rng.standard_normal(20000)*3
rels=[]; us=[]
for i in range(20000):
    a,b,c=float(A[i]),float(B[i]),float(C[i])
    f=float(Fraction(a)*Fraction(b)+Fraction(c)); g=a*b+c
    if f!=g:
        us.append(ulps(f,g)); rels.append(abs(f-g)/abs(f) if f!=0 else np.inf)
rels=np.array(rels); us=np.array(us)
print('不同的次数 %d / 20000 = %.1f%%' % (len(us), 100*len(us)/20000))
print('ulp 分布: 中位 %g, 90%% %g, 99%% %g, max %g' % (np.median(us), np.percentile(us,90), np.percentile(us,99), us.max()))
print('相对差分布: 中位 %.2e, 99%% %.2e, max %.2e' % (np.median(rels), np.percentile(rels,99), rels.max()))
# 抵消情形：a*b+c 接近 0
i=np.argmax(us); a,b,c=float(A[i]),float(B[i]),float(C[i])
print('最坏一例：a*b+c = %.3e（发生抵消），FMA=%r 非FMA=%r' % (a*b+c, float(Fraction(a)*Fraction(b)+Fraction(c)), a*b+c))
