# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 fp2.py    依赖：numpy, scipy, threadpoolctl
"""BLAS 线程数 / 算法路径对结果的影响。"""
import numpy as np, math, struct
from threadpoolctl import threadpool_limits, threadpool_info

def ulps(a, b):
    ia = struct.unpack('<q', struct.pack('<d', a))[0]
    ib = struct.unpack('<q', struct.pack('<d', b))[0]
    if ia < 0: ia = -9223372036854775808 - ia
    if ib < 0: ib = -9223372036854775808 - ib
    return abs(ia - ib)

def maxulp(A, B):
    A = np.asarray(A).ravel(); B = np.asarray(B).ravel()
    return max(ulps(float(a), float(b)) for a, b in zip(A, B))

print('BLAS:', [(d['internal_api'], d.get('num_threads'), d.get('version')) for d in threadpool_info()])

rng = np.random.default_rng(20260602)
n, m = 800, 4000
# 基因型矩阵（0/1/2），中心化
p = rng.uniform(0.05, 0.95, m)
M = (rng.random((n, m)) < p).astype(np.float64) + (rng.random((n, m)) < p).astype(np.float64)
Z = M - 2*p
den = 2*np.sum(p*(1-p))

res = {}
for nt in [1, 2]:
    with threadpool_limits(limits=nt, user_api='blas'):
        G = Z @ Z.T / den
        res[nt] = G.copy()
print('--- G = ZZ\'/2Σpq，n=%d, m=%d ---' % (n, m))
d = np.abs(res[1]-res[2])
print('1 线程 vs 2 线程：max|Δ| = %.3e, max rel = %.3e, max ulp = %d' %
      (d.max(), (d/np.abs(res[1])).max(), maxulp(res[1], res[2])))
print('G[0,0]: 1线程 %r  2线程 %r' % (res[1][0,0], res[2][0,0]))
print('tr(G)/n: 1线程 %.17g  2线程 %.17g  ulp=%d' %
      (np.trace(res[1])/n, np.trace(res[2])/n, ulps(np.trace(res[1])/n, np.trace(res[2])/n)))

# 算法路径：syrk vs gemm（数学上相同，BLAS 走不同内核）
from scipy.linalg import blas
with threadpool_limits(limits=1, user_api='blas'):
    Gs = blas.dsyrk(alpha=1.0/den, a=Z, lower=0)     # 只算上三角
    Gg = Z @ Z.T / den
iu = np.triu_indices(n)
dd = np.abs(Gs[iu] - Gg[iu])
print('--- 同一个 G：syrk 路径 vs gemm 路径（同为 1 线程）---')
print('max|Δ| = %.3e, max ulp = %d, 完全相等的元素比例 = %.4f' %
      (dd.max(), max(ulps(float(a), float(b)) for a, b in zip(Gs[iu], Gg[iu])),
       np.mean(dd == 0)))

# Cholesky 求解 vs 显式求逆（数学等价，数值路径不同）
A = res[1] + np.eye(n)*0.5
b = rng.standard_normal(n)
with threadpool_limits(limits=1, user_api='blas'):
    from scipy.linalg import cho_factor, cho_solve, solve, inv
    x1 = cho_solve(cho_factor(A), b)
    x2 = inv(A) @ b
    x3 = solve(A, b)
print('--- 解 Ax=b：Cholesky / 显式求逆 / LU ---')
print('cond(A) = %.3e' % np.linalg.cond(A))
print('||x_chol - x_inv||_inf / ||x||_inf = %.3e' % (np.abs(x1-x2).max()/np.abs(x1).max()))
print('||x_chol - x_lu||_inf  / ||x||_inf = %.3e' % (np.abs(x1-x3).max()/np.abs(x1).max()))
