# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 fp4.py    依赖：numpy
"""fastmath 允许的四类变换各自能造成多大差异（Float64）。"""
import numpy as np, math, struct
from fractions import Fraction

def ulps(a, b):
    ia = struct.unpack('<q', struct.pack('<d', a))[0]
    ib = struct.unpack('<q', struct.pack('<d', b))[0]
    if ia < 0: ia = -9223372036854775808 - ia
    if ib < 0: ib = -9223372036854775808 - ib
    return abs(ia - ib)

rng = np.random.default_rng(20260603)
n = 1_000_000
y = 9000.0 + 1500.0 * rng.standard_normal(n)     # 产奶量 kg

print('== 变换 1：重结合（reassociation）——把一条累加链拆成 8 条 ==')
s1 = 0.0
for v in y.tolist(): s1 += v
parts = np.array_split(y, 8); ps = []
for p in parts:
    t = 0.0
    for v in p.tolist(): t += v
    ps.append(t)
s8 = 0.0
for t in ps: s8 += t
ex = math.fsum(y.tolist())
print(f'  顺序链  {s1!r}  (距精确 {ulps(s1,ex)} ulp)')
print(f'  8 条链  {s8!r}  (距精确 {ulps(s8,ex)} ulp)')
print(f'  两者相差 {ulps(s1,s8)} ulp，相对差 {abs(s1-s8)/abs(ex):.3e}')

print()
print('== 变换 2：除法改乘倒数 a/b -> a*(1/b) ==')
lam = 2.3333333333333335       # (1-h2)/h2, h2=0.3
inv = 1.0/lam
a = y[:200000]
d1 = a/lam; d2 = a*inv
nd = np.sum(d1 != d2)
mu = max(ulps(float(x), float(z)) for x, z in zip(d1[:20000], d2[:20000]))
print(f'  20 万个除法中位模式不同的有 {nd} 个（{100*nd/len(a):.1f}%），最大 {mu} ulp')
print(f'  相对差上界 {np.max(np.abs(d1-d2)/np.abs(d1)):.3e}')

print()
print('== 变换 3：融合乘加 FMA，即 fl(a*b+c) vs fl(fl(a*b)+c) ==')
A = rng.standard_normal(200000)*3; B = rng.standard_normal(200000)*3; C = rng.standard_normal(200000)*3
def fma_exact(a, b, c):
    return float(Fraction(a)*Fraction(b) + Fraction(c))
diff = 0; mx = 0
for i in range(20000):
    f = fma_exact(float(A[i]), float(B[i]), float(C[i]))
    g = float(A[i])*float(B[i]) + float(C[i])
    if f != g:
        diff += 1; mx = max(mx, ulps(f, g))
print(f'  2 万次乘加中 FMA 与非 FMA 结果不同的有 {diff} 次（{100*diff/20000:.1f}%），最大 {mx} ulp')

print()
print('== 变换 4：补偿求和被优化掉（Kahan/Neumaier 的补偿项代数上为 0）==')
def kahan(x):
    s = 0.0; c = 0.0
    for v in x:
        yv = v - c; t = s + yv; c = (t - s) - yv; s = t
    return s
k = kahan(y.tolist())
print(f'  Kahan 求和 {k!r}  (距精确 {ulps(k,ex)} ulp)')
print(f'  朴素求和 {s1!r}  (距精确 {ulps(s1,ex)} ulp)')
print(f'  若 fastmath 把 c 优化成 0，Kahan 退化为朴素求和，精度损失 {ulps(s1,ex)-ulps(k,ex)} ulp')

print()
print('== 附：一遍法方差 vs 两遍法（这不是 fastmath，是算法选择）==')
s_ = 0.0; ss = 0.0
for v in y.tolist(): s_ += v; ss += v*v
var1 = (ss - s_*s_/n)/(n-1)
m_ = s_/n
var2 = math.fsum(((v-m_)**2 for v in y.tolist()))/(n-1)
print(f'  一遍法 {var1!r}')
print(f'  两遍法 {var2!r}')
print(f'  相对差 {abs(var1-var2)/var2:.3e}，即 {ulps(var1,var2)} ulp')
# 若均值更大（例如以克为单位）
y2 = y*1000.0
s_ = 0.0; ss = 0.0
for v in y2.tolist(): s_ += v; ss += v*v
v1 = (ss - s_*s_/n)/(n-1)
m2 = s_/n
v2 = math.fsum(((v-m2)**2 for v in y2.tolist()))/(n-1)
print(f'  单位换成克后：一遍法 {v1!r}，两遍法 {v2!r}，相对差 {abs(v1-v2)/v2:.3e}')
