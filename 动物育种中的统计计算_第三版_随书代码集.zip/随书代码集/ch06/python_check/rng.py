# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 rng.py    依赖：numpy
"""随机数可复现性：全局种子为什么不够，流分裂为什么够。"""
import numpy as np
from numpy.random import SeedSequence, PCG64, Generator

print('='*70); print('A. 共享一条流 + 并行消费：结果随"线程数"而变'); print('='*70)
def sim_shared(nrep, nblock):
    """模拟 nrep 次重复，每次抽一个孟德尔抽样项；一条流被 nblock 个'线程'按块消费。
       块的划分不同 -> 每个重复拿到的数不同。"""
    g = Generator(PCG64(20260604))
    out = np.empty(nrep)
    idx = np.array_split(np.arange(nrep), nblock)
    for blk in idx:                      # 模拟：线程按块从共享流取数
        out[blk] = g.standard_normal(len(blk))
    return out
base = sim_shared(1000, 1)
for nb in [2, 4, 8]:
    o = sim_shared(1000, nb)
    print(f'  {nb} 块 vs 1 块：逐个相同? {np.array_equal(base,o)}   均值 {o.mean():+.6f} (1块 {base.mean():+.6f})')
print('  注：本例块间不交错，所以数值恰好相同；一旦线程真的并发取数，顺序由调度决定。')

print()
print('B. 真并发下的消费顺序（用打乱的取数顺序模拟调度不确定性）')
def sim_race(nrep, order_seed):
    g = Generator(PCG64(20260604))
    out = np.empty(nrep)
    order = np.random.default_rng(order_seed).permutation(nrep)
    for i in order:                      # 谁先抢到锁谁先拿
        out[i] = g.standard_normal()
    return out
a = sim_race(1000, 1); b = sim_race(1000, 2)
print(f'  两次运行（调度不同）逐个相同? {np.array_equal(a,b)}')
print(f'  相关系数 {np.corrcoef(a,b)[0,1]:+.4f}；均值 {a.mean():+.6f} / {b.mean():+.6f}（统计性质一样，个体值全变）')

print()
print('='*70); print('C. 每个工作项一条子流（SeedSequence.spawn）：与并行方式无关'); print('='*70)
def sim_split(nrep, nblock):
    ss = SeedSequence(20260604)
    kids = ss.spawn(nrep)                # 每个重复一条独立子流
    out = np.empty(nrep)
    idx = np.array_split(np.arange(nrep), nblock)
    for blk in idx:
        for i in blk:
            out[i] = Generator(PCG64(kids[i])).standard_normal()
    return out
r1 = sim_split(1000, 1)
for nb in [2, 4, 8, 37]:
    print(f'  {nb} 块 vs 1 块：逐位相同? {np.array_equal(r1, sim_split(1000, nb))}')

print()
print('D. spawn 的子流只取决于"第几个"，不取决于"一共几个"')
k5  = SeedSequence(20260604).spawn(5)
k50 = SeedSequence(20260604).spawn(50)
print('  前 5 个子流的 entropy 状态相同?',
      all(np.array_equal(k5[i].generate_state(4), k50[i].generate_state(4)) for i in range(5)))
print('  -> 可以先只 spawn 5 个跑试点，再 spawn 50 个跑正式，前 5 个重复逐位可复现。')

print()
print('E. 每线程种子 = 全局种子 + 线程号：线程数一变，配对关系全变')
def sim_tidseed(nrep, nthread):
    out = np.empty(nrep)
    idx = np.array_split(np.arange(nrep), nthread)
    for t, blk in enumerate(idx):
        g = Generator(PCG64(20260604 + t))
        out[blk] = g.standard_normal(len(blk))
    return out
p2, p4 = sim_tidseed(1000, 2), sim_tidseed(1000, 4)
print(f'  2 线程 vs 4 线程逐位相同? {np.array_equal(p2, p4)}  相关 {np.corrcoef(p2,p4)[0,1]:+.4f}')

print()
print('='*70); print('F. 抽样次数依赖数据时的漂移（拒绝抽样 / 截断分布）'); print('='*70)
def trunc_normal_reject(g, n, lo):
    out = []
    while len(out) < n:
        x = g.standard_normal()
        if x > lo: out.append(x)
    return np.array(out)
g1 = Generator(PCG64(99)); g2 = Generator(PCG64(99))
x1 = trunc_normal_reject(g1, 5, lo=1.0)      # 选择留种：截断点 1.0
x2 = trunc_normal_reject(g2, 5, lo=1.2)      # 只把截断点动了 0.2
print('  截断点 1.0 抽 5 个：', np.round(x1, 4))
print('  截断点 1.2 抽 5 个：', np.round(x2, 4))
print('  后续再抽 3 个（同一条流）：', np.round(g1.standard_normal(3), 4), '|', np.round(g2.standard_normal(3), 4))
print('  -> 两条流已经错位；"改一个无关参数，其他结果全变"的根源。')

print()
print('G. Gibbs 链：同一条流的分裂 vs 共用')
def gibbs_sum(seed, nchain, niter, split):
    tot = []
    if split:
        kids = SeedSequence(seed).spawn(nchain)
        for c in range(nchain):
            g = Generator(PCG64(kids[c]))
            tot.append(g.standard_normal(niter).mean())
    else:
        g = Generator(PCG64(seed))
        for c in range(nchain):
            tot.append(g.standard_normal(niter).mean())
    return np.array(tot)
s1 = gibbs_sum(5, 4, 1000, True)
s2 = gibbs_sum(5, 4, 1000, True)
print('  分裂：两次运行相同?', np.array_equal(s1, s2))
print('  分裂后单独重跑第 3 条链：', end=' ')
k = SeedSequence(5).spawn(4)
print(np.isclose(Generator(PCG64(k[2])).standard_normal(1000).mean(), s1[2]))
print('  -> 分裂使"只重跑第 3 条链"成为可能；共用一条流则必须从头跑到第 3 条。')
