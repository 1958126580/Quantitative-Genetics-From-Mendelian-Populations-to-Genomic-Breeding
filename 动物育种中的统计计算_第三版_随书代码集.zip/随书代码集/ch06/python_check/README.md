# 第 6 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch06/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `breed.py` | 育种代码的可断言恒等式：逐条数值验证，报告实际残差量级。 | numpy | 1.3 | `outputs/breed.out` |
| `breed2.py` | 第二批断言：REML=ANOVA、多性状退化、G 矩阵、单步 H⁻¹、EM 单调、PCG。 | numpy, scipy | 9.0 | `outputs/breed2.out` |
| `breed3.py` | 数值复核 | numpy, scipy | 3.6 | `outputs/breed3.out` |
| `breed4.py` | 小而病态 vs 大而平凡；PCG 容差与断言；EM 单调；参数回收的功效。 | numpy | 39.0 | `outputs/breed4.out` |
| `breed5.py` | 病态测试数据的具体制造法：每一种病态各造成什么后果。 | numpy | 1.3 | `outputs/breed5.out` |
| `fp.py` | 浮点不可复现的四个来源：求和次序、BLAS 线程数、BLAS 实现/算法路径、fastmath 允许的变换。 | numpy, threadpoolctl | 20.3 | `outputs/fp.out` |
| `fp2.py` | BLAS 线程数 / 算法路径对结果的影响。 | numpy, scipy, threadpoolctl | 6.9 | `outputs/fp2.out` |
| `fp3.py` | 数值复核 | numpy, scipy, threadpoolctl | 14.8 | `outputs/fp3.out` |
| `fp4.py` | fastmath 允许的四类变换各自能造成多大差异（Float64）。 | numpy | 5.7 | `outputs/fp4.out` |
| `fp5.py` | 数值复核 | numpy | 1.4 | `outputs/fp5.out` |
| `rng.py` | 随机数可复现性：全局种子为什么不够，流分裂为什么够。 | numpy | 0.7 | `outputs/rng.out` |
| `rng2.py` | 数值复核 | numpy | 0.5 | `outputs/rng2.out` |
| `rowsum.py` | A⁻¹ 行和的一般公式（含单亲未知个体）。 | numpy | 0.6 | `outputs/rowsum.out` |
