# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 breed4.py    依赖：numpy
"""小而病态 vs 大而平凡；PCG 容差与断言；EM 单调；参数回收的功效。"""
import numpy as np
rng = np.random.default_rng(20260608)

def build_A(s, d):
    n=len(s); A=np.zeros((n,n))
    for i in range(n):
        si,di=s[i]-1,d[i]-1
        for j in range(i):
            A[i,j]=A[j,i]=0.5*((A[si,j] if si>=0 else 0)+(A[di,j] if di>=0 else 0))
        A[i,i]=1.0+(0.5*A[si,di] if si>=0 and di>=0 else 0.0)
    return A
def dvec(s,d,F,ignore_F=False):
    n=len(s); dd=np.empty(n)
    for i in range(n):
        si,di=s[i]-1,d[i]-1
        if si>=0 and di>=0: dd[i]=0.5 if ignore_F else 0.5-0.25*(F[si]+F[di])
        elif si>=0 or di>=0:
            p=si if si>=0 else di
            dd[i]=0.75 if ignore_F else 0.75-0.25*F[p]
        else: dd[i]=1.0
    return dd
def build_Ainv(s,d,F,ignore_F=False):
    n=len(s); dd=dvec(s,d,F,ignore_F); Ai=np.zeros((n,n))
    for i in range(n):
        si,di=s[i]-1,d[i]-1
        idx=[i]+([si] if si>=0 else [])+([di] if di>=0 else [])
        q=[1.0]+([-0.5] if si>=0 else [])+([-0.5] if di>=0 else [])
        for a,qa in zip(idx,q):
            for b,qb in zip(idx,q): Ai[a,b]+=qa*qb/dd[i]
    return Ai

print('='*72); print('E1  同一个 bug（漏近交修正）在两种测试数据上的可见度'); print('='*72)
# (a) 大而平凡：宽基础群、随机交配、近交极低
def rand_ped(n,nbase,rng):
    s=np.zeros(n,int); d=np.zeros(n,int)
    for i in range(nbase,n):
        s[i]=rng.integers(0,i)+1; d[i]=rng.integers(0,i)+1
        while d[i]==s[i]: d[i]=rng.integers(0,i)+1
    return s,d
sA,dA=rand_ped(3000,2000,rng); AA=build_A(sA,dA); FA=np.diag(AA)-1
# (b) 小而病态：4 个基础个体、5 代全同胞交配
def closed_ped():
    s=[0,0,0,0]; d=[0,0,0,0]
    # 每代由上一代的 2 个个体产生 2 个全同胞
    cur=[1,2,3,4]
    for g in range(6):
        nxt=[]
        for _ in range(2):
            s.append(cur[0]); d.append(cur[2 if len(cur)>2 else 1]); nxt.append(len(s))
        cur=nxt
    return np.array(s),np.array(d)
sB,dB=closed_ped(); AB=build_A(sB,dB); FB=np.diag(AB)-1
for name,(s_,d_,F_) in [('(a) 3000 头、随机交配', (sA,dA,FA)), ('(b) %d 头、连续全同胞交配'%len(sB), (sB,dB,FB))]:
    Ai =build_Ainv(s_,d_,F_,False)
    Aib=build_Ainv(s_,d_,F_,True)
    Atrue=build_A(s_,d_)
    r1=np.abs(Atrue@Ai-np.eye(len(s_))).max()
    r2=np.abs(Atrue@Aib-np.eye(len(s_))).max()
    print('%s：F̄=%.4f，F_max=%.4f' % (name,F_.mean(),F_.max()))
    print('    正确实现 max|A·A⁻¹-I| = %.3e ；漏修正版 = %.3e   （检出比 %.1e）'
          % (r1,r2,r2/max(r1,1e-300)))

print()
print('='*72); print('E2  条件数：测试数据应当"够病态"'); print('='*72)
h2=0.3; lam=(1-h2)/h2
for nh,nrec,label in [(3,600,'每个同期组 200 条记录（平衡、良态）'),
                      (60,600,'每个同期组 10 条记录'),
                      (150,600,'每个同期组 4 条记录（接近可估性边界）')]:
    n=nrec
    s_,d_=rand_ped(n,max(20,n//10),rng); A_=build_A(s_,d_); F_=np.diag(A_)-1
    Ai=build_Ainv(s_,d_,F_)
    herd=rng.integers(0,nh,n); X=np.zeros((n,nh)); X[np.arange(n),herd]=1
    C=np.block([[X.T@X, X.T],[X, np.eye(n)+lam*Ai]])
    ev=np.linalg.eigvalsh(C); ev=ev[np.abs(ev)>1e-10]
    print('%-32s cond(C) = %.3e' % (label, ev.max()/ev.min()))

print()
print('='*72); print('E3  PCG 的收敛容差 -> 断言容差怎么定'); print('='*72)
n=800
s_,d_=rand_ped(n,80,rng); A_=build_A(s_,d_); F_=np.diag(A_)-1; Ai=build_Ainv(s_,d_,F_)
nh=20; herd=rng.integers(0,nh,n); X=np.zeros((n,nh)); X[np.arange(n),herd]=1
y=rng.standard_normal(n)
C=np.block([[X.T@X, X.T],[X, np.eye(n)+lam*Ai]]); r=np.concatenate([X.T@y,y])
xdir=np.linalg.lstsq(C,r,rcond=None)[0]
Mi=1.0/np.diag(C)
def pcg(C,r,Mi,tol):
    x=np.zeros_like(r); res=r-C@x; z=Mi*res; p=z.copy(); rz=res@z; nb=np.linalg.norm(r); it=0
    while np.linalg.norm(res)/nb>tol and it<20000:
        Cp=C@p; a=rz/(p@Cp); x+=a*p; res-=a*Cp; z=Mi*res; rz2=res@z; p=z+(rz2/rz)*p; rz=rz2; it+=1
    return x,it
print('cond(C) = %.3e' % (lambda ev: ev.max()/ev.min())(np.abs(np.linalg.eigvalsh(C))))
for tol in [1e-4,1e-6,1e-8,1e-10,1e-12]:
    x,it=pcg(C,r,Mi,tol)
    print('  ‖r‖/‖b‖ < %.0e  迭代 %5d 次   max|x_PCG - x_直接| = %.3e' % (tol,it,np.abs(x-xdir).max()))

print()
print('='*72); print('E4  参数回收：需要多少次重复才能检出 5% 的偏倚'); print('='*72)
R=400; ns,k=40,8; sa2,se2=0.30,0.70
est=np.empty(R)
for rr in range(R):
    g=np.random.default_rng(np.random.SeedSequence(777).spawn(R)[rr])
    al=g.standard_normal(ns)*np.sqrt(sa2)
    yy=al[:,None]+g.standard_normal((ns,k))*np.sqrt(se2)
    ybi=yy.mean(1); yb=yy.mean()
    MSB=k*np.sum((ybi-yb)**2)/(ns-1); MSW=np.sum((yy-ybi[:,None])**2)/(ns*(k-1))
    est[rr]=(MSB-MSW)/k/((MSB-MSW)/k+MSW)     # h²（组内相关）
print('真值 h² = %.4f；%d 次重复的均值 = %.4f，重复间 sd = %.4f，均值的标准误 = %.4f'
      % (sa2/(sa2+se2), R, est.mean(), est.std(ddof=1), est.std(ddof=1)/np.sqrt(R)))
sd=est.std(ddof=1); bias=0.05*sa2/(sa2+se2)
Rneed=int(np.ceil((2.8*sd/bias)**2))
print('要以 80%% 功效、5%% 水平检出 %.4f（即真值的 5%%）的偏倚，需要 R ≈ %d 次重复' % (bias,Rneed))
for Rx in [20,50,100,400]:
    print('  R=%4d 时，均值的标准误 = %.4f，可检出的最小偏倚 ≈ %.4f（真值的 %.1f%%）'
          % (Rx, sd/np.sqrt(Rx), 2.8*sd/np.sqrt(Rx), 100*2.8*sd/np.sqrt(Rx)/(sa2/(sa2+se2))))
