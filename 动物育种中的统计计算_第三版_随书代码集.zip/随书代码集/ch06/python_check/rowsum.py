# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 6 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 rowsum.py    依赖：numpy
"""A⁻¹ 行和的一般公式（含单亲未知个体）。"""
import numpy as np
rng=np.random.default_rng(42)
n=200
s=np.zeros(n,int); d=np.zeros(n,int)
for i in range(20,n):
    r=rng.random()
    if r<0.6: s[i]=rng.integers(0,i)+1; d[i]=rng.integers(0,i)+1
    elif r<0.8: s[i]=rng.integers(0,i)+1           # 只知父
    elif r<0.9: d[i]=rng.integers(0,i)+1           # 只知母
    if s[i]==d[i]: d[i]=0
def build_A(s,d):
    n=len(s); A=np.zeros((n,n))
    for i in range(n):
        si,di=s[i]-1,d[i]-1
        for j in range(i):
            A[i,j]=A[j,i]=0.5*((A[si,j] if si>=0 else 0)+(A[di,j] if di>=0 else 0))
        A[i,i]=1.0+(0.5*A[si,di] if si>=0 and di>=0 else 0.0)
    return A
A=build_A(s,d); F=np.diag(A)-1
dd=np.empty(n); qs=np.empty(n)
for i in range(n):
    si,di=s[i]-1,d[i]-1
    if si>=0 and di>=0: dd[i]=0.5-0.25*(F[si]+F[di]); qs[i]=0.0
    elif si>=0: dd[i]=0.75-0.25*F[si]; qs[i]=0.5
    elif di>=0: dd[i]=0.75-0.25*F[di]; qs[i]=0.5
    else: dd[i]=1.0; qs[i]=1.0
Ai=np.zeros((n,n))
for i in range(n):
    si,di=s[i]-1,d[i]-1
    idx=[i]+([si] if si>=0 else [])+([di] if di>=0 else [])
    q=[1.0]+([-0.5] if si>=0 else [])+([-0.5] if di>=0 else [])
    for a,qa in zip(idx,q):
        for b,qb in zip(idx,q): Ai[a,b]+=qa*qb/dd[i]
pred=np.zeros(n)
for i in range(n):
    pred[i]+=qs[i]/dd[i]
for k in range(n):
    for par in [s[k]-1,d[k]-1]:
        if par>=0: pred[par]+=-0.5*qs[k]/dd[k]
rs=Ai.sum(1)
print('个体构成：双亲已知 %d，单亲已知 %d，双亲未知 %d'
      %(np.sum((s>0)&(d>0)),np.sum(((s>0)&(d==0))|((s==0)&(d>0))),np.sum((s==0)&(d==0))))
print('一般行和公式 max|rowsum - pred| = %.3e'%np.abs(rs-pred).max())
both=(s>0)&(d>0); nokid=np.ones(n,bool)
for k in range(n):
    for par in [s[k]-1,d[k]-1]:
        if par>=0: nokid[par]=False
print('双亲已知 且 无后代 的个体：max|rowsum| = %.3e（理论 0），共 %d 头'
      %(np.abs(rs[both&nokid]).max(),int((both&nokid).sum())))
print('1\'A⁻¹1 = %.10f；双亲未知个体数 = %d'%(np.ones(n)@Ai@np.ones(n),int(np.sum((s==0)&(d==0)))))
# 纯粹"双亲已知或双亲未知"的系谱
s2=s.copy(); d2=d.copy()
for i in range(n):
    if (s2[i]>0) != (d2[i]>0): s2[i]=0; d2[i]=0
A2=build_A(s2,d2); F2=np.diag(A2)-1
dd2=np.array([0.5-0.25*(F2[s2[i]-1]+F2[d2[i]-1]) if s2[i]>0 and d2[i]>0 else 1.0 for i in range(n)])
Ai2=np.zeros((n,n))
for i in range(n):
    si,di=s2[i]-1,d2[i]-1
    idx=[i]+([si] if si>=0 else [])+([di] if di>=0 else [])
    q=[1.0]+([-0.5] if si>=0 else [])+([-0.5] if di>=0 else [])
    for a,qa in zip(idx,q):
        for b,qb in zip(idx,q): Ai2[a,b]+=qa*qb/dd2[i]
print('全"双亲已知或全未知"系谱：1\'A⁻¹1 = %.10f，基础群 %d 头'
      %(np.ones(n)@Ai2@np.ones(n),int(np.sum((s2==0)&(d2==0)))))
print('                        行和 max|·|（非基础群）= %.3e'%np.abs(Ai2.sum(1)[(s2>0)]).max())
