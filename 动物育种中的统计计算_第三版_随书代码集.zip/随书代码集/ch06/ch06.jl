# 本脚本由 tools/nb2jl.py 从同目录的 ch06.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 06

# %% [markdown]
# # 第六章　可复现研究与科学软件工程 —— 配套代码
#
# 本笔记本导览随书代码集自身的工程实践，并运行全书自检。它既是第六章的配套，也是**读者可以直接借用的项目模板**。

# %%
using Pkg, Test, Random, LinearAlgebra, Printf, Dates, Statistics
println("=== 环境固化信息（应随论文一并归档）===")
println("Julia 版本    : ", VERSION)
println("BLAS 实现     : ", LinearAlgebra.BLAS.get_config())
println("BLAS 线程数   : ", LinearAlgebra.BLAS.get_num_threads())
println("Julia 线程数  : ", Threads.nthreads())
println("默认 RNG 类型 : ", typeof(Random.default_rng()))
println("时间戳        : ", now())
println()
println("→ 正文 §6.6.3：可复现性的三个断点是 BLAS 实现与线程数、")
println("  多线程归约顺序、RNG 版本。三者都必须显式记录或固定。")

# %% [markdown]
# ## 1　项目结构导览（正文 §6.3.1）

# %%
function tree(dir::AbstractString; prefix="", maxdepth=3, depth=1)
    depth > maxdepth && return
    entries = sort(readdir(dir))
    for (k, e) in enumerate(entries)
        startswith(e, ".") && continue
        p = joinpath(dir, e)
        last = k == length(entries)
        println(prefix, last ? "└── " : "├── ", e, isdir(p) ? "/" : "")
        isdir(p) && tree(p; prefix = prefix * (last ? "    " : "│   "),
                         maxdepth=maxdepth, depth=depth+1)
    end
end

root = dirname(@__DIR__)     # code/
println("随书代码集结构：")
println(basename(root), "/")
tree(root; maxdepth=2)

# %% [markdown]
# ## 2　依赖与环境（正文 §6.6）

# %%
Pkg.activate(root)
println("=== Project.toml 声明的直接依赖 ===")
Pkg.status()
println()
mf = joinpath(root, "Manifest.toml")
if isfile(mf)
    println("Manifest.toml 存在 ✓ —— 可用 Pkg.instantiate() 精确还原环境")
    @printf("  大小 %d 字节\n", filesize(mf))
else
    println("Manifest.toml 尚未生成。首次 Pkg.instantiate() 后会自动创建。")
    println("→ 分析型项目应当提交 Manifest.toml（正文 §6.6.1）。")
end

# %% [markdown]
# ## 3　可复现随机数（正文 §6.6.3 第 3 条）

# %%
# 反面做法：依赖默认 RNG（Julia 1.7 中默认发生器已从 MersenneTwister 改为 Xoshiro）
Random.seed!(42); a1 = rand(3)
Random.seed!(42); a2 = rand(3)
println("同一会话内可复现 : ", a1 == a2 ? "✓" : "✗")
println("  但跨 Julia 版本不保证 —— 默认发生器可能改变。")
println()

# 正确做法：显式指定发生器
b1 = rand(Xoshiro(42), 3)
b2 = rand(Xoshiro(42), 3)
println("显式 Xoshiro(42) : ", b1 == b2 ? "✓ 同一版本内逐位可复现" : "✗")
println("  注意：Julia 不保证不同版本之间随机数流不变；需要跨版本逐位一致时用 StableRNGs.jl。")
println()
println("本书的做法：ASC3.bookrng() 返回 Xoshiro，全书统一播种。")

# 按逻辑单元播种：结果与线程数无关（正文 §4.3.4）
function 并行模拟(nrep)
    out = zeros(nrep)
    Threads.@threads for r in 1:nrep
        rr = Xoshiro(hash((20260918, r)))      # 只依赖重复号
        out[r] = mean(randn(rr, 1000))
    end
    return out
end
s1 = 并行模拟(50); s2 = 并行模拟(50)
println("\n并行模拟两次运行逐位相同 : ", s1 == s2 ? "✓" : "✗")

# %% [markdown]
# ## 4　确定性归约（正文 §4.3.2、§6.6.3 第 2 条）

# %%
function 求和_不确定(x)                    # 依赖调度顺序
    s = Threads.Atomic{Float64}(0.0)
    Threads.@threads for i in eachindex(x)
        Threads.atomic_add!(s, x[i])
    end
    return s[]
end

function 求和_确定(x)                      # 固定分块 + 固定顺序合并
    nt = Threads.nthreads()
    chunks = collect(Iterators.partition(eachindex(x), cld(length(x), nt)))
    partial = zeros(eltype(x), length(chunks))
    Threads.@threads for t in 1:length(chunks)
        s = zero(eltype(x))
        @inbounds @simd for i in chunks[t]; s += x[i]; end
        partial[t] = s
    end
    return sum(partial)
end

x = randn(Xoshiro(1), 2_000_000)
if Threads.nthreads() > 1
    r1 = [求和_不确定(x) for _ in 1:5]
    r2 = [求和_确定(x)   for _ in 1:5]
    println("原子归约 5 次结果全相同 : ", all(==(r1[1]), r1) ? "✓（本次碰巧）" : "✗ 不可复现")
    println("确定性归约 5 次全相同   : ", all(==(r2[1]), r2) ? "✓" : "✗")
else
    println("单线程环境，无法演示差异。用 julia --threads=auto 重跑。")
end
println("\n→ 需要逐位复现时，必须用确定性归约模式。")

# %% [markdown]
# ## 5　断言与不变量（正文 §6.4.2）

# %%
# 便宜的断言放在函数入口/出口，始终开启
"""检查系谱的三个必要条件，作为所有系谱算法的入口断言。"""
function validate_pedigree(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire)
    length(dam) == n || throw(ArgumentError("sire 与 dam 长度不一致"))
    for i in 1:n
        0 <= sire[i] <= n || throw(ArgumentError("个体 $i 的父号越界: $(sire[i])"))
        0 <= dam[i]  <= n || throw(ArgumentError("个体 $i 的母号越界: $(dam[i])"))
        sire[i] < i || throw(ArgumentError("系谱未拓扑排序：个体 $i 的父号 $(sire[i]) ≥ $i"))
        dam[i]  < i || throw(ArgumentError("系谱未拓扑排序：个体 $i 的母号 $(dam[i]) ≥ $i"))
        sire[i] != dam[i] || sire[i] == 0 || throw(ArgumentError("个体 $i 的父母相同"))
    end
    return true
end

println("合法系谱  : ", validate_pedigree([0,0,1,1], [0,0,0,2]))
print("未排序系谱: ")
try
    validate_pedigree([0,0,4,1], [0,0,0,2])
catch e
    println("✗ 被捕获 → ", e.msg)
end
println()
println("→ 把前置条件写成可执行的检查，是 docstring 中“要求”一节的兑现。")

# %% [markdown]
# ## 6　测试组织（正文 §6.4）

# %%
# 本书随书代码集的测试按五类组织。这里演示每一类的写法。
@testset "随书代码集测试示例" begin

    @testset "1 解析解测试" begin
        # λ → ∞ 时 BLUP 的随机效应解趋于 0
        n = 5; X = ones(n,1); Z = Matrix(1.0I,n,n); Ainv = Matrix(1.0I,n,n)
        y = randn(Xoshiro(1), n)
        for λ in (1e0, 1e3, 1e6)
            C = [X'X X'Z; Z'X Z'Z + λ*Ainv]; r = [X'y; Z'y]
            u = (C \ r)[2:end]
            λ == 1e6 && @test maximum(abs, u) < 1e-4
        end
    end

    @testset "2 手算对照" begin
        # 7 个体系谱的近交系数（正文第九章）
        sire = [0,0,1,1,3,1,5]; dam = [0,0,0,2,4,4,6]
        n = 7; A = zeros(n,n)
        for i in 1:n
            s,d = sire[i], dam[i]
            for j in 1:i-1
                A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
            end
            A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
        end
        @test diag(A) .- 1 ≈ [0,0,0,0,0.125,0.25,0.28125] atol=1e-12
    end

    @testset "3 不变量/性质测试" begin
        for trial in 1:20
            rr = Xoshiro(trial); n = 30
            sire = zeros(Int,n); dam = zeros(Int,n)
            for i in 6:n; sire[i] = rand(rr,1:i-1); dam[i] = rand(rr,1:i-1); end
            A = let AA = zeros(n,n)
                for i in 1:n
                    s,d = sire[i],dam[i]
                    for j in 1:i-1
                        AA[i,j]=AA[j,i]=0.5*((s>0 ? AA[j,s] : 0.0)+(d>0 ? AA[j,d] : 0.0))
                    end
                    AA[i,i]=1.0+(s>0 && d>0 ? 0.5*AA[s,d] : 0.0)
                end; AA
            end
            @test issymmetric(A)
            @test all(diag(A) .>= 1 - 1e-12)
            @test isposdef(A + 1e-10I)
        end
    end

    @testset "4 回归测试（固定种子）" begin
        v = rand(Xoshiro(20260918), 3)
        @test v ≈ rand(Xoshiro(20260918), 3)          # 存档值应与此一致
    end

    @testset "5 参数回收（统计性质，放宽阈值）" begin
        z = Float64[]
        for r in 1:500
            d = 5.0 .+ randn(Xoshiro(r), 40).*2.0
            push!(z, (mean(d) - 5.0)/(std(d)/sqrt(40)))
        end
        @test abs(mean(z)) < 0.20        # 4σ 阈值，避免随机失败
        @test abs(std(z) - 1) < 0.15
    end
end

# %% [markdown]
# ## 7　来源追溯文件（正文 §6.7.2）

# %%
using SHA
"""
    write_provenance(outfile, script, inputs; extra...)

为一个衍生数据产物写来源追溯文件，记录生成脚本、输入及其校验和、环境信息。
"""
function write_provenance(outfile::AbstractString, script::AbstractString,
                          inputs::Vector{<:AbstractString}; extra...)
    open(outfile * ".provenance.toml", "w") do io
        println(io, "generated_by   = ", repr(script))
        println(io, "generated_at   = ", repr(string(now())))
        println(io, "julia_version  = ", repr(string(VERSION)))
        println(io, "blas_threads   = ", LinearAlgebra.BLAS.get_num_threads())
        println(io, "inputs         = ", repr(inputs))
        shas = [isfile(f) ? bytes2hex(sha256(read(f))) : "MISSING" for f in inputs]
        println(io, "input_sha256   = ", repr(shas))
        for (k, v) in extra
            println(io, rpad(string(k), 14), " = ", repr(v))
        end
    end
    return outfile * ".provenance.toml"
end

# 演示
tmpin  = joinpath(tempdir(), "demo_input.txt");  write(tmpin, "id sire dam\n1 0 0\n2 0 0\n3 1 2\n")
tmpout = joinpath(tempdir(), "demo_output.csv"); write(tmpout, "id,f\n1,0.0\n2,0.0\n3,0.0\n")
pf = write_provenance(tmpout, "scripts/01_clean_pedigree.jl", [tmpin];
                      n_records_in=3, n_records_out=3)
println(read(pf, String))
rm.([tmpin, tmpout, pf]; force=true)

# %% [markdown]
# ## 本章代码小结
#
# 1. **环境固化信息**（Julia 版本、BLAS 实现与线程数、RNG 类型）应当随每个结果一并记录。
# 2. **显式指定 RNG**（`Xoshiro(seed)`），不要依赖 `Random.seed!` 的默认发生器——它在 Julia 1.7 中已经改变过一次；需要跨 Julia 版本逐位一致时改用 `StableRNGs.jl`。
# 3. **按逻辑单元播种**使并行模拟的结果与线程数无关；**确定性归约**使并行求和逐位可复现。
# 4. **前置条件写成可执行的检查**（`validate_pedigree`），是 docstring 中"要求"一节的兑现。
# 5. **测试分五类**：解析解、手算对照、不变量、回归、参数回收。统计性质测试要放宽阈值（4σ）以避免随机失败。
# 6. **来源追溯文件**在两年后回答"这个结果是怎么来的"时价值极高，而写它的成本只有十几行代码。
#
# ---
#
# **第一篇到此结束。** 你现在拥有了全书所需的计算基础：Julia 语言、数值线性代数、性能工程、AI 辅助的工作方法、以及可复现的工程实践。
#
# **下一步**：第二篇（第 7–10 章）转入数量遗传学原理，为第三篇的混合模型建立遗传学地基。
