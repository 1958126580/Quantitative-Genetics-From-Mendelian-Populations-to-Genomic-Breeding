# 第六章　可复现研究与科学软件工程 —— 配套代码

**所属**：第一篇　计算基础与 Julia 语言　　**对应正文**：第六章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch06.ipynb` | IJulia 笔记本：8 个代码单元，约 213 行 Julia 代码，穿插与正文对应的说明 |
| `ch06.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 13 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　项目结构导览（正文 §6.3.1）
- 2　依赖与环境（正文 §6.6）
- 3　可复现随机数（正文 §6.6.3 第 3 条）
- 4　确定性归约（正文 §4.3.2、§6.6.3 第 2 条）
- 5　断言与不变量（正文 §6.4.2）
- 6　测试组织（正文 §6.4）
- 7　来源追溯文件（正文 §6.7.2）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 06
```

或在 Jupyter 中打开 `ch06/ch06.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
