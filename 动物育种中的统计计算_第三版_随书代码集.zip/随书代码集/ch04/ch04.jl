# 本脚本由 tools/nb2jl.py 从同目录的 ch04.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 04

# %% [markdown]
# # 第四章　高性能计算：性能工程、并行与 GPU —— 配套代码
#
# **本笔记本的主线**：把基因组关系矩阵 $\mathbf G=\mathbf{ZZ}'/(2\sum p_jq_j)$ 的构建从朴素实现逐级优化到 GPU，每一级给出加速比与原因分析。
#
# | 级别 | 手段 | 对应正文 |
# |:--|:--|:--|
# | L0 | 朴素三重循环（类型不稳定） | §4.2.1 |
# | L1 | 类型稳定 + 正确的遍历顺序 | §4.2.1–4.2.2 |
# | L2 | `@inbounds` + `@simd` + 利用对称性 | §4.2.3 |
# | L3 | BLAS Level‑3（`syrk`） | §4.2.5 |
# | L4 | 多线程分块 | §4.3 |
# | L5 | GPU | §4.5 |

# %%
using LinearAlgebra, Random, Printf, Statistics, BenchmarkTools
BLAS.set_num_threads(1)          # 先固定单线程，公平比较
rng = Xoshiro(20260918)
println("Julia 线程数 = ", Threads.nthreads())
println("BLAS 线程数  = ", BLAS.get_num_threads())
println("\n提示：多线程部分需以 julia --threads=auto 启动。")

# %% [markdown]
# ## 0　准备：模拟基因型数据

# %%
"""
    sim_genotypes(n, m; rng)

模拟 `n` 个体 × `m` 标记的基因型（0/1/2），等位基因频率从 U(0.05, 0.5) 抽取。
返回 (M, p)：基因型矩阵与等位基因频率。
"""
function sim_genotypes(n::Int, m::Int; rng=Random.default_rng())
    p = 0.05 .+ 0.45 .* rand(rng, m)
    M = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        M[i, j] = Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j])
    end
    return M, p
end

n, m = 1500, 3000
Mg, pf = sim_genotypes(n, m; rng=rng)
Zc = Mg .- 2 .* pf'                      # 中心化（先中心化再相乘，避免灾难性抵消）
denom = 2 * sum(pf .* (1 .- pf))
@printf("基因型矩阵 %d × %d，2Σp(1−p) = %.4f\n", n, m, denom)
@printf("内存占用 %.1f MiB\n", sizeof(Mg)/2^20)

# %% [markdown]
# ## L0　朴素实现（类型不稳定 + 错误的遍历顺序）

# %%
# 故意写成不稳定：累加器初值为 Int，且内层遍历行（跨列访问）
function G_L0(Z, denom)
    n = size(Z, 1)
    G = zeros(n, n)
    for i in 1:n, j in 1:n
        s = 0                              # ← Int，类型不稳定
        for k in 1:size(Z, 2)
            s += Z[i, k] * Z[j, k]         # ← Z[i,k] 跨列访问
        end
        G[i, j] = s / denom
    end
    return G
end

# 先在小规模上验证正确性
Zs, ps = let (Msm, psm) = sim_genotypes(80, 200; rng=Xoshiro(1)); (Msm .- 2 .* psm', psm) end
ds = 2*sum(ps .* (1 .- ps))
G_ref = (Zs * Zs') ./ ds
@printf("【对照验证】L0 与参考实现相对差 = %.3e\n", norm(G_L0(Zs, ds) - G_ref)/norm(G_ref))

t0 = @belapsed G_L0($Zs, $ds) samples=3 evals=1
@printf("L0 (80×200)  : %8.2f ms\n", t0*1e3)
println("（L0 太慢，只在小规模上测。）")

# %% [markdown]
# ## L1　类型稳定 + 正确的遍历顺序

# %%
function G_L1(Z::Matrix{T}, denom::T) where {T<:AbstractFloat}
    n, mm = size(Z)
    G = zeros(T, n, n)
    for j in 1:n, i in 1:n                 # 外层列、内层行（列主序）
        s = zero(T)                        # ← 类型跟随数据
        for k in 1:mm
            s += Z[i, k] * Z[j, k]
        end
        G[i, j] = s / denom
    end
    return G
end
@assert isapprox(G_L1(Zs, ds), G_ref; rtol=1e-10)
t1 = @belapsed G_L1($Zs, $ds) samples=3 evals=1
@printf("L1 (80×200)  : %8.2f ms   （相对 L0 加速 %.1f×）\n", t1*1e3, t0/t1)

# %% [markdown]
# ## L2　`@inbounds` + `@simd` + 利用对称性
#
# $\mathbf G$ 是对称的，只需算上三角。同时把内层循环改为对 $\mathbf Z$ 的**行**做点积——为此先转置存储。

# %%
function G_L2(Z::Matrix{T}, denom::T) where {T<:AbstractFloat}
    n, mm = size(Z)
    Zt = permutedims(Z)                    # mm × n，使同一个体的标记连续存放
    G  = zeros(T, n, n)
    inv_d = inv(denom)
    @inbounds for j in 1:n
        for i in 1:j                       # 只算上三角
            s = zero(T)
            @simd for k in 1:mm
                s = muladd(Zt[k, i], Zt[k, j], s)
            end
            v = s * inv_d
            G[i, j] = v; G[j, i] = v
        end
    end
    return G
end
@assert isapprox(G_L2(Zs, ds), G_ref; rtol=1e-10)
t2 = @belapsed G_L2($Zs, $ds) samples=3 evals=1
@printf("L2 (80×200)  : %8.2f ms   （相对 L0 加速 %.1f×）\n", t2*1e3, t0/t2)

# %% [markdown]
# ## L3　BLAS Level‑3
#
# `syrk`（symmetric rank‑k update）专门计算 $\mathbf{ZZ}'$，只做一半运算且分块以最大化算术强度。

# %%
function G_L3(Z::Matrix{T}, denom::T) where {T<:AbstractFloat}
    G = BLAS.syrk('U', 'N', inv(denom), Z)   # 上三角存 Z*Z'/denom
    return Symmetric(G, :U)
end
@assert isapprox(Matrix(G_L3(Zs, ds)), G_ref; rtol=1e-10)
t3 = @belapsed G_L3($Zs, $ds) samples=3 evals=1
@printf("L3 (80×200)  : %8.2f ms   （相对 L0 加速 %.1f×）\n", t3*1e3, t0/t3)

println("\n=== 在真实规模 $(n)×$(m) 上比较 L2 与 L3 ===")
tb2 = @belapsed G_L2($Zc, $denom) samples=2 evals=1
tb3 = @belapsed G_L3($Zc, $denom) samples=3 evals=1
@printf("L2 : %8.2f ms\n", tb2*1e3)
@printf("L3 : %8.2f ms   （加速 %.1f×）\n", tb3*1e3, tb2/tb3)
gflops = n^2 * m / tb3 / 1e9               # syrk 约 n²m 次 FLOP（利用对称性）
@printf("L3 实测性能 ≈ %.1f GFLOPS\n", gflops)

# %% [markdown]
# ## L4　多线程
#
# `syrk` 本身可由多线程 BLAS 加速。这里演示两条路径：（a）打开 BLAS 多线程；（b）自己按标记分块并用**确定性归约**（正文 §4.3.2）。

# %%
# (a) 让 BLAS 用多线程
nt = Sys.CPU_THREADS
BLAS.set_num_threads(nt)
t4a = @belapsed G_L3($Zc, $denom) samples=3 evals=1
BLAS.set_num_threads(1)
@printf("L4a BLAS %d 线程 : %8.2f ms   （相对单线程 %.1f×）\n", nt, t4a*1e3, tb3/t4a)

# (b) 自己按标记块分解 ZZ' = Σ_b Z_b Z_b'，确定性归约
function G_L4(Z::Matrix{T}, denom::T; nblocks::Int = Threads.nthreads()) where {T}
    n, mm = size(Z)
    blocks = collect(Iterators.partition(1:mm, cld(mm, nblocks)))
    partial = [zeros(T, n, n) for _ in 1:length(blocks)]
    Threads.@threads for b in 1:length(blocks)
        Zb = @view Z[:, blocks[b]]
        BLAS.syrk!('U', 'N', one(T), Zb, zero(T), partial[b])
    end
    G = zeros(T, n, n)
    for b in 1:length(blocks)              # 固定顺序合并 ⇒ 逐位可复现
        G .+= partial[b]
    end
    G .*= inv(denom)
    return Symmetric(G, :U)
end

G4 = Matrix(G_L4(Zc, denom))
G3 = Matrix(G_L3(Zc, denom))
@printf("【对照验证】L4 与 L3 相对差 = %.3e\n", norm(G4-G3)/norm(G3))
# 可复现性：同一输入两次运行结果必须逐位相同
@printf("【可复现性】两次运行逐位相同 : %s\n",
        Matrix(G_L4(Zc, denom)) == G4 ? "✓" : "✗")
if Threads.nthreads() > 1
    t4b = @belapsed G_L4($Zc, $denom) samples=3 evals=1
    @printf("L4b 手工分块 %d 线程 : %8.2f ms   （相对单线程 %.1f×）\n",
            Threads.nthreads(), t4b*1e3, tb3/t4b)
else
    println("（当前只有 1 个 Julia 线程；用 julia --threads=auto 重跑可见加速。）")
end

# %% [markdown]
# ## L5　GPU
#
# > 需要 NVIDIA GPU 与 `CUDA.jl`。若不可用，本单元会自动跳过。

# %%
gpu_ok = false
try
    @eval using CUDA
    global gpu_ok = CUDA.functional()
catch
    global gpu_ok = false
end

if gpu_ok
    println("GPU: ", CUDA.name(CUDA.device()))
    Zd = CuArray(Zc)
    G_gpu() = Array(Zd * Zd') ./ denom
    Gg = G_gpu()
    @printf("【对照验证】GPU 与 CPU 相对差 = %.3e\n", norm(Gg - G3)/norm(G3))
    t5 = @belapsed (CUDA.@sync $Zd * $Zd') samples=3 evals=1
    @printf("L5 GPU（不含传输）: %8.2f ms   （相对 L3 单线程 %.1f×）\n", t5*1e3, tb3/t5)
    # 传输开销
    ttr = @belapsed CuArray($Zc)
    @printf("主机→设备传输      : %8.2f ms   （占 GPU 计算的 %.1f 倍）\n", ttr*1e3, ttr/t5)
    println("→ 正文 §4.5.2 的第 3 条规则：计算量必须足以摊销传输开销。")
else
    println("未检测到可用的 CUDA 设备，跳过 GPU 级别。")
    println("正文 §4.5.3 给出了哪些育种计算适合 GPU 的判据。")
end

# %% [markdown]
# ## 屋顶线分析（正文 §4.1.4）

# %%
"""
    roofline(I, Pmax, B)

给定算术强度 `I`（FLOP/B）、峰值算力 `Pmax`（FLOP/s）与内存带宽 `B`（B/s），
返回可达性能上界与该操作的类型判定。
"""
function roofline(I_, Pmax, B)
    P  = min(Pmax, I_ * B)
    I★ = Pmax / B
    return P, I★, (I_ < I★ ? "访存受限" : "计算受限")
end

Pmax, B = 2e12, 200e9          # 2 TFLOPS, 200 GB/s
_, I★, _ = roofline(1.0, Pmax, B)
@printf("机器平衡点 I* = %.1f FLOP/B\n\n", I★)

println(rpad("操作", 26), rpad("I (FLOP/B)", 13), rpad("上界 (GFLOPS)", 16), "类型")
println("-"^70)
for (nm, I_) in (("向量加 z=x+y", 1/24),
                 ("SpMV (Int32 索引)", 2/12),
                 ("稠密矩阵-向量乘", 0.25),
                 ("G = ZZ' (n=1500)", 1500/4),   # I ∝ n
                 )
    P, _, cls = roofline(I_, Pmax, B)
    @printf("%-26s%-13.3f%-16.1f%s\n", nm, I_, P/1e9, cls)
end
println()
println("→ 迭代求解器的内核 SpMV 只能达到峰值的 ~1.7%；")
println("  而 G 矩阵构建是计算受限的，值得用 BLAS-3、多线程与 GPU。")

# %% [markdown]
# ## 加速比汇总

# %%
println("在 $(n)×$(m) 规模上（单线程基准 = L2）：")
println(rpad("级别", 34), rpad("耗时 (ms)", 14), "相对 L2")
println("-"^62)
@printf("%-34s%-14.2f%.1f×\n", "L2 手写 + @inbounds/@simd", tb2*1e3, 1.0)
@printf("%-34s%-14.2f%.1f×\n", "L3 BLAS syrk（单线程）", tb3*1e3, tb2/tb3)
@printf("%-34s%-14.2f%.1f×\n", "L4a BLAS 多线程", t4a*1e3, tb2/t4a)
println()
println("结论：")
println("  · 从 L0 到 L1（修类型稳定 + 遍历顺序）是最廉价的收益；")
println("  · 从 L2 到 L3（改用 BLAS Level-3）是最大的单步收益；")
println("  · 再往上的多线程与 GPU 收益取决于问题规模是否足够大。")
println("  · 每一级都用【对照验证】确认了数值结果不变。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **优化的顺序就是本笔记本的顺序**：类型稳定 → 内存布局 → `@inbounds`/`@simd` → BLAS Level‑3 → 多线程 → GPU。跳过前面直接做后面，收益会被前面的问题吃掉。
# 2. **最大的单步收益来自"重构为 Level‑3"**——这是算法层面的改变，不是微观调优。
# 3. **确定性归约**（固定分块 + 固定顺序合并）同时解决竞争、假共享与可复现性，本笔记本的 `G_L4` 给出了标准写法。
# 4. **屋顶线模型在动手之前就能告诉你值不值得优化**：SpMV 不值得堆核，$\mathbf{ZZ}'$ 值得上 GPU。
# 5. 每一级都有【对照验证】。**没有对照验证的优化不是优化，是赌博。**
