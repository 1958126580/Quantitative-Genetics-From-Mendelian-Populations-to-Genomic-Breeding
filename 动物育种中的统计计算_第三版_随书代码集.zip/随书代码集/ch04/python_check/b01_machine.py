# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b01_machine.py    依赖：numpy
"""本机峰值算力与内存带宽实测（供屋顶线模型使用）。"""
import numpy as np, time, os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')

def best(f, reps=7):
    ts=[]
    f(); f()                      # 预热
    for _ in range(reps):
        t0=time.perf_counter(); f(); ts.append(time.perf_counter()-t0)
    return min(ts), float(np.median(ts))

print('== 峰值算力：大规模 DGEMM（计算受限）==')
for n in (1000, 1500, 2000):
    A=np.random.rand(n,n); B=np.random.rand(n,n)
    tmin,tmed=best(lambda: A@B, 5)
    fl=2*n**3
    print(f'n={n:5d}  min={tmin*1e3:8.2f} ms  GFLOPS(min)={fl/tmin/1e9:7.2f}  GFLOPS(med)={fl/tmed/1e9:7.2f}')

print()
print('== 单精度 SGEMM ==')
for n in (1500, 2000):
    A=np.random.rand(n,n).astype(np.float32); B=np.random.rand(n,n).astype(np.float32)
    tmin,tmed=best(lambda: A@B, 5)
    fl=2*n**3
    print(f'n={n:5d}  min={tmin*1e3:8.2f} ms  GFLOPS(min)={fl/tmin/1e9:7.2f}')

print()
print('== 内存带宽：STREAM triad  a = b + s*c（访存受限）==')
for MB in (64, 256, 512):
    n = MB*1024*1024//8
    b=np.random.rand(n); c=np.random.rand(n); a=np.empty(n); s=3.0
    def f():
        np.multiply(c, s, out=a); np.add(a, b, out=a)
    tmin,tmed=best(f, 5)
    byt = 4*n*8        # 读 b、读 c、读 a(写分配)、写 a  -> 保守取 4 次流量；另报 3 次
    print(f'工作集={MB:4d} MB  min={tmin*1e3:8.2f} ms  BW(4流)={byt/tmin/1e9:6.2f} GB/s  BW(3流)={3*n*8/tmin/1e9:6.2f} GB/s')

print()
print('== 纯拷贝带宽 ==')
n = 256*1024*1024//8
x=np.random.rand(n); y=np.empty(n)
tmin,_=best(lambda: np.copyto(y,x), 5)
print(f'copy 256MB: min={tmin*1e3:.2f} ms  BW(2流)={2*n*8/tmin/1e9:.2f} GB/s')
