# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b09_models.py    依赖：仅标准库
"""纯模型计算：Amdahl/Gustafson、分块尺寸、显存容量、通信代价。"""
import math
print('=== 表：Amdahl 加速比 S(p)=1/(f_s+(1-f_s)/p) ===')
ps=[1,2,4,8,16,32,64,128,256]
print('并行比例 |' + ''.join(f'{p:>8d}' for p in ps) + '   上限')
for par in (0.90,0.95,0.99,0.999):
    s=1-par
    print(f'  {par:.3f}  |' + ''.join(f'{1/(s+par/p):8.2f}' for p in ps) + f'{1/s:8.1f}')
print()
print('=== 表：Gustafson 加速比 S(p)=f_s+(1-f_s)p（弱扩展）===')
print('并行比例 |' + ''.join(f'{p:>8d}' for p in ps))
for par in (0.90,0.95,0.99,0.999):
    s=1-par
    print(f'  {par:.3f}  |' + ''.join(f'{s+par*p:8.1f}' for p in ps))
print()
print('=== 达到目标加速比所需的最小并行比例 ===')
for p,S in ((16,8),(32,16),(64,32),(256,100)):
    # S = 1/(s+(1-s)/p) -> s = (1/S - 1/p)/(1-1/p)
    s=(1/S-1/p)/(1-1/p)
    print(f'  p={p:4d} 要达到 S={S:4d} 需串行比例 ≤ {s*100:.3f}%（并行比例 ≥ {100*(1-s):.3f}%）')
print()
print('=== 分块（tiling）尺寸：三块 b×b Float64 常驻缓存，3b^2*8 ≤ C ===')
for name,C in (('L1d 32 KiB',32*1024),('L2 1 MiB',1024*1024),('L3 33 MiB',33*1024*1024)):
    b=int(math.sqrt(C/(3*8)))
    print(f'  {name:14s} b ≤ sqrt(C/24) = {b:5d}；单块 {b*b*8/1024:8.1f} KiB；'
          f'块内算术强度 I = b/3 * ... -> 2b^3/(3b^2*8)= b/12 = {b/12:.1f} FLOP/B')
print()
print('=== 分块矩阵乘的访存量：n=8192 ===')
n=8192
print(f'  不分块（每次重读 B）：约 {2*n**3*8/1e9:8.1f} GB')
for name,C in (('L1 32K',32*1024),('L2 1M',1024*1024),('L3 33M',33*1024*1024)):
    b=int(math.sqrt(C/(3*8)))
    traf=2*n**3*8/b           # 经典结果：流量 ~ 2n^3/b 个元素
    print(f'  分块 b={b:5d}（{name:7s}）：{traf/1e9:8.3f} GB，降为 1/{b}')
print()
print('=== 表：G 矩阵（Float64 稠密）的内存/显存需求 ===')
print(f'{"n_g":>10}{"G(FP64)GB":>12}{"G(FP32)GB":>12}{"上三角FP64":>12}{"Z(m=5e4,FP64)GB":>18}{"Z 2bit GB":>11}')
for ng in (1000,5000,10000,50000,100000,200000,500000):
    m=50000
    print(f'{ng:>10d}{ng*ng*8/2**30:12.3f}{ng*ng*4/2**30:12.3f}{ng*(ng+1)/2*8/2**30:12.3f}'
          f'{ng*m*8/2**30:18.2f}{ng*m*0.25/2**30:11.3f}')
print()
print('=== PCG 每步的通信代价模型（p 个进程，N 阶方程）===')
print('每步 2 次全局归约（dot(p,Ap) 与 dot(r,z)），每次 allreduce 延迟 ~ 2*alpha*log2(p)')
alpha=2e-6   # 典型 MPI 延迟 2 us（作为模型参数，非实测）
for p in (2,8,32,128,512):
    tcomm=2*2*alpha*math.log2(p)
    print(f'  p={p:4d}: 每步归约延迟 ≈ {tcomm*1e6:7.2f} us')
print('  与之对比：N 阶 SpMV（nnz=7N）在 B=28.7GB/s、完美并行下的单步计算时间')
for N in (1e5,1e6,1e7,1e8):
    t=12*7*N/ (28.7e9)
    print(f'    N={N:9.0e}: 单进程 SpMV ≈ {t*1e6:9.1f} us；p=128 时每进程 ≈ {t/128*1e6:8.2f} us')
