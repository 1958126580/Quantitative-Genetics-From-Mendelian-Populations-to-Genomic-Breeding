# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b12_bench.py    依赖：numpy, scipy
"""基准方法学：时间分布的形状；临时数组的代价。"""
import numpy as np, time
rng=np.random.default_rng(1)
print('=== (1) 同一内核重复 200 次的时间分布（n=2000 DGEMM）===')
n=2000; A=rng.random((n,n)); B=rng.random((n,n))
A@B; A@B
ts=[]
for _ in range(60):
    t0=time.perf_counter(); A@B; ts.append(time.perf_counter()-t0)
ts=np.array(ts)*1e3
q=np.percentile(ts,[0,25,50,75,90,99,100])
print(f'  min={q[0]:.1f}  p25={q[1]:.1f}  中位={q[2]:.1f}  p75={q[3]:.1f}  p90={q[4]:.1f}  p99={q[5]:.1f}  max={q[6]:.1f} ms')
print(f'  均值={ts.mean():.1f} ms，标准差={ts.std():.1f} ms；max/min = {q[6]/q[0]:.2f}；中位/min = {q[2]/q[0]:.3f}')
print(f'  右偏度（均值-中位）/中位 = {(ts.mean()-q[2])/q[2]*100:.1f}%')

print()
print('=== (2) 第一次调用 vs 后续调用（numpy 的首次开销；Julia 的 JIT 效应更大）===')
m=3000; C=rng.random((m,m)); D=rng.random((m,m))
t0=time.perf_counter(); C@D; t1=time.perf_counter()
t2=time.perf_counter(); C@D; t3=time.perf_counter()
print(f'  首次 {(t1-t0)*1e3:.1f} ms，第二次 {(t3-t2)*1e3:.1f} ms，比 {(t1-t0)/(t3-t2):.2f}×')

print()
print('=== (3) 临时数组 vs 就地：PCG 内层循环的四个向量更新 ===')
N=4_000_000
x=rng.random(N); p=rng.random(N); r=rng.random(N); Ap=rng.random(N); al=0.37
def naive():
    global x,r
    x = x + al*p
    r = r - al*Ap
def inplace():
    x.__iadd__(al*p) if False else None
def inplace2():
    np.multiply(p, al, out=tmp); np.add(x, tmp, out=x)
    np.multiply(Ap, al, out=tmp); np.subtract(r, tmp, out=r)
tmp=np.empty(N)
def best(f,reps=9):
    f();f()
    ts=[]
    for _ in range(reps):
        t0=time.perf_counter(); f(); ts.append(time.perf_counter()-t0)
    return min(ts)
tn=best(naive); ti=best(inplace2)
print(f'  分配临时数组 {tn*1e3:7.2f} ms/步；预分配就地 {ti*1e3:7.2f} ms/步；比 {tn/ti:.2f}×')
print(f'  每步临时分配量 = 4×{N}×8 B = {4*N*8/2**20:.0f} MiB；1000 步累计 {4*N*8*1000/2**30:.0f} GiB')

print()
print('=== (4) FP32 syrk 的精度随 m 增长 ===')
from scipy.linalg.blas import dsyrk, ssyrk
nn=800
for mm in (1000,5000,20000,50000):
    p_=rng.uniform(.05,.95,mm)
    M=(rng.random((nn,mm))<p_).astype(np.float64)+(rng.random((nn,mm))<p_)
    Z=np.ascontiguousarray(M-2*p_); den=2*float(np.sum(p_*(1-p_)))
    G64=dsyrk(1.0/den,Z,lower=0); G32=ssyrk(np.float32(1.0/den),Z.astype(np.float32),lower=0)
    iu=np.triu_indices(nn); ref=G64[iu]
    rel=np.max(np.abs(ref-G32[iu]))/np.max(np.abs(ref))
    eps=float(np.finfo(np.float32).eps)
    print(f'  m={mm:6d}: 实测相对最大误差 {rel:.2e}；sqrt(m)*eps = {np.sqrt(mm)*eps:.2e}；m*eps = {mm*eps:.2e}')
