# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b11_gpu.py    依赖：numpy
"""GPU 判据的模型计算（无 GPU 可用，全部为公式代入）。"""
import math
print('=== PCIe 理论带宽（按规范算，非记忆）===')
for gen,gt in (('3.0',8),('4.0',16),('5.0',32)):
    enc = 128/130 if gt>=8 else 8/10
    bw = gt*1e9*16*enc/8/1e9
    print(f'  PCIe {gen} x16: {gt} GT/s × 16 lane × 128/130 ÷ 8 = {bw:5.1f} GB/s；按 80% 可达 {0.8*bw:5.1f} GB/s')
print()
PCPU=139.3e9          # 本机实测 DGEMM 峰值
print('=== 判据：W FLOP、D 字节往返，GPU 值得用当且仅当 W/D > P_cpu/B_pcie ===')
for name,bp in (('PCIe 3.0 x16 (80%)',0.8*8*16*128/130/8*1e9),
                ('PCIe 4.0 x16 (80%)',0.8*16*16*128/130/8*1e9),
                ('PCIe 5.0 x16 (80%)',0.8*32*16*128/130/8*1e9)):
    print(f'  {name}: 阈值 I_pcie = {PCPU/bp:7.2f} FLOP/B')
bp=0.8*16*16*128/130/8*1e9
thr=PCPU/bp
print()
print(f'=== 三类育种任务的 I_pcie（阈值 {thr:.1f} FLOP/B，PCIe 4.0）===')
# 1) G = ZZ'
for n,m,s in ((10000,50000,4),(100000,50000,4),(100000,50000,8)):
    W=n*n*m; D=s*(n*m)+s*n*n
    print(f'  G 构建 n={n:6d} m={m} {"FP32" if s==4 else "FP64"}: '
          f'W={W:.2e} FLOP, D={D/2**30:7.2f} GiB, I_pcie={W/D:9.1f} -> '
          + ('值得' if W/D>thr else '不值得'))
# 2) 稠密 gemv，矩阵驻留、重复 k 次
n=50000
print(f'  稠密 gemv n={n}（FP64，矩阵传一次、做 k 次）：I_pcie = 2k n^2/(8n^2)=k/4')
print(f'    -> k > 4*{thr:.1f} = {4*thr:.0f} 次才值得；单次 gemv 的 I_pcie=0.25，永远不值得')
# 3) Gibbs：每轮 m 个位点、每位点 O(n) 运算，链内串行
n,m,it=50000,50000,10000
W=2*n*m*it*2    # 每轮每位点 2 次长度 n 的内积级运算
D=4*n*m
print(f'  Gibbs（n={n} m={m}，{it} 轮，Z 传一次）：W={W:.2e}, D={D/2**30:.1f} GiB, '
      f'I_pcie={W/D:.3e} -> 传输不是瓶颈；瓶颈是链内串行与位点间依赖')
print()
print('=== 分支发散：一个 warp（32 线程）走 k 条不同路径 -> 至多 k 倍串行化 ===')
print('  A^{-1} 遍历的四种父本状态（双亲已知/仅父/仅母/双亲未知）：')
for frac in ((0.7,0.1,0.1,0.1),(0.97,0.01,0.01,0.01)):
    k_exp = sum(1-(1-f)**32 for f in frac)      # 每条路径至少被一个线程走到的期望条数
    print(f'    比例 {frac} -> 一个 warp 期望激活 {k_exp:.2f} 条路径 -> 期望串行化 ≈ {k_exp:.2f}×')
print()
print('=== 显存容量：稠密 G 能放下的最大 n_g ===')
print(f'{"显存GiB":>9}{"FP64 n_g":>12}{"FP32 n_g":>12}{"FP64 上三角":>14}')
for V in (16,24,40,80,141,192):
    b=V*2**30
    print(f'{V:9d}{int(math.sqrt(b/8)):12d}{int(math.sqrt(b/4)):12d}{int(math.sqrt(2*b/8)):14d}')
print()
print('=== 混合精度：FP32 能表示的 G 元素精度 ===')
import numpy as np
print(f'  FP32 eps = {np.finfo(np.float32).eps:.3e}，G 元素量级 ~1 -> 绝对误差 ~1e-7')
print(f'  FP64 eps = {np.finfo(np.float64).eps:.3e}')
print('  syrk 的误差界（Golub & Van Loan 定理）：|fl(ZZ\')-ZZ\'| ≤ m*eps*|Z||Z\'| + O(eps^2)')
for m_ in (5e4,5e5):
    for eps,nm in ((np.finfo(np.float32).eps,'FP32'),(np.finfo(np.float64).eps,'FP64')):
        print(f'    m={m_:.0e} {nm}: m*eps = {m_*eps:.2e}')
print()
print('=== 求解精度与条件数：FP32 解的相对误差 ~ kappa*eps ===')
for kap in (1e2,1e4,1e6,1e8):
    print(f'  kappa={kap:.0e}: FP32 相对误差 ~ {kap*np.finfo(np.float32).eps:.1e}（有效位 '
          f'{max(0,-math.log10(kap*float(np.finfo(np.float32).eps))):.1f}）; '
          f'FP64 ~ {kap*np.finfo(np.float64).eps:.1e}')
