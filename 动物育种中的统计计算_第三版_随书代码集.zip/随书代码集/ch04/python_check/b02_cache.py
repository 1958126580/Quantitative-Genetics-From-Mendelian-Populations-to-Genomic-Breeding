# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b02_cache.py    依赖：numpy
"""缓存层级的阶梯：有效带宽随工作集大小的变化（已扣除 numpy 每次调用的固定开销）。"""
import numpy as np, time
C = 1.0000000001
def best(f, reps=7):
    f(); f()
    ts=[]
    for _ in range(reps):
        t0=time.perf_counter(); f(); ts.append(time.perf_counter()-t0)
    return min(ts)

# 标定每次 np.multiply 调用的固定开销
tiny = np.random.rand(8)
R0 = 200000
def f0():
    for _ in range(R0): np.multiply(tiny, C, out=tiny)
ovh = best(f0, 5)/R0
print(f'# 每次 numpy 调用的固定开销 ≈ {ovh*1e9:.0f} ns（已从下表扣除）')
print(f'{"工作集":>10} {"每元素ns":>10} {"有效带宽GB/s":>14}   预期层级')
for KB in (16, 24, 32, 48, 64, 128, 256, 512, 768, 1024, 2048, 8192, 16384, 32768, 131072, 524288):
    n = KB*1024//8
    x = np.random.rand(n)
    rep = max(3, int(4e8//n))
    def f(x=x, rep=rep):
        for _ in range(rep): np.multiply(x, C, out=x)
    t = best(f, 5) - ovh*rep
    per = t/(rep*n); bw = 2*8*rep*n/t/1e9
    lvl = 'L1d 32K' if KB<=32 else ('L2 1M' if KB<=1024 else ('L3 33M' if KB<=33792 else 'DRAM'))
    print(f'{KB:8d}KB {per*1e9:10.3f} {bw:14.2f}   {lvl}')
