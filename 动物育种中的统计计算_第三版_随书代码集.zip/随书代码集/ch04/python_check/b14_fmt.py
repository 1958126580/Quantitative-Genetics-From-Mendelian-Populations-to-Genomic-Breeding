# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b14_fmt.py    依赖：仅标准库
"""浮点格式参数：全部由“符号/阶码/尾数位宽”的定义算出。"""
fmts = [('FP64 (binary64)',1,11,52),('FP32 (binary32)',1,8,23),('TF32 (NVIDIA)',1,8,10),
        ('FP16 (binary16)',1,5,10),('BF16 (bfloat16)',1,8,7)]
print(f'{"格式":<18}{"位宽":>5}{"阶码":>5}{"尾数":>5}{"有效位":>7}{"eps=2^-p":>12}{"十进制位":>9}{"最大值":>12}')
for name,s,e,m in fmts:
    p = m+1                      # 含隐含位
    eps = 2.0**-p
    emax = 2**(e-1)-1
    mx = (2-2.0**-m)*2.0**emax
    print(f'{name:<18}{s+e+m:>5}{e:>5}{m:>5}{p:>7}{eps:>12.3e}{-__import__("math").log10(eps):>9.1f}{mx:>12.3e}')
print()
print('=== 条件数 kappa 与可用格式：要求 kappa*eps < 1e-3（解有 3 位有效数字）===')
import math
for name,s,e,m in fmts:
    eps=2.0**-(m+1)
    print(f'  {name:<18} 可接受的最大 kappa = {1e-3/eps:.2e}')
print()
print('=== 迭代精化：每轮把误差缩小 ~kappa*eps 倍，需要的轮数 ===')
for kap in (1e3,1e5,1e7):
    e32=2.0**-24; e64=2.0**-53
    rho=kap*e32
    if rho<1:
        k=math.ceil(math.log(kap*e64/ (kap*e32))/math.log(rho))
        print(f'  kappa={kap:.0e}: 每轮收缩因子 {rho:.2e}，需 {max(1,k)} 轮达到 FP64 水平')
    else:
        print(f'  kappa={kap:.0e}: 收缩因子 {rho:.2e} ≥ 1，迭代精化不收敛')
