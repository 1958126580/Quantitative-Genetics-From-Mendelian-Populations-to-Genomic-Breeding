# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b08_reduce.py    依赖：numpy
"""归约顺序与可复现性：浮点加法不满足结合律（块内严格顺序累加）。"""
import numpy as np, struct
rng = np.random.default_rng(7)
n = 2_000_000
x = rng.standard_normal(n)*np.exp(rng.standard_normal(n)*3.0)
xl = x.tolist()
def bits(v): return struct.pack('>d', v).hex()
def seqsum(lst):
    s = 0.0
    for v in lst: s += v
    return s
def chunked(nt):
    b = -(-n//nt)
    part = [seqsum(xl[i*b:(i+1)*b]) for i in range(nt)]
    return seqsum(part)
ref = float(x.astype(np.longdouble).sum())
print(f'n = {n}；元素绝对值跨 {np.min(np.abs(x)):.1e} ~ {np.max(np.abs(x)):.1e}')
print(f'扩展精度参考值 = {ref:.17e}')
print()
print(f'{"线程数":>7} {"结果":>25} {"IEEE754 位模式":>18} {"相对误差":>12} {"与1线程差(ulp)":>15}')
base=None
for nt in (1,2,3,4,6,8,12,16,32,64):
    s = chunked(nt)
    if base is None: base = s
    ulp = abs(struct.unpack('>q', struct.pack('>d', s))[0] - struct.unpack('>q', struct.pack('>d', base))[0])
    print(f'{nt:7d} {s:25.17e} {bits(s):>18} {abs(s-ref)/abs(ref):12.3e} {ulp:15d}')
print()
print('numpy pairwise  x.sum() =', f'{float(x.sum()):.17e}', bits(float(x.sum())),
      f' 相对误差 {abs(float(x.sum())-ref)/abs(ref):.3e}')
import math
print('math.fsum (精确)        =', f'{math.fsum(xl):.17e}', bits(math.fsum(xl)))
print()
vals = {bits(chunked(4)) for _ in range(5)}
print(f'固定 4 分块重复 5 次 -> {len(vals)} 个位模式（' + ('逐位一致' if len(vals)==1 else '不一致') + '）')
print()
def neumaier(lst):
    s=0.0; c=0.0
    for v in lst:
        t=s+v
        c += (s-t+v) if abs(s)>=abs(v) else (v-t+s)
        s=t
    return s+c
print(f'补偿求和 Neumaier 相对误差 = {abs(neumaier(xl)-ref)/abs(ref):.3e}（朴素顺序 {abs(base-ref)/abs(ref):.3e}）')
