# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b04_blas.py    依赖：numpy
"""BLAS 三级的实测性能，与屋顶线模型的预测对照。"""
import numpy as np, time
def best(f, reps=7):
    f(); f()
    ts=[]
    for _ in range(reps):
        t0=time.perf_counter(); f(); ts.append(time.perf_counter()-t0)
    return min(ts)

PMAX = 139.3e9     # 本机实测 DGEMM 峰值 (FLOP/s)
BW   = 13.2e9      # 本机实测 triad 带宽 (B/s)
print(f'# 机器平衡点 I* = Pmax/B = {PMAX/BW:.1f} FLOP/B')
print()
print(f'{"内核":<26}{"规模":>12}{"FLOP":>12}{"最少访存B":>12}{"I":>8}{"实测GF":>9}{"屋顶GF":>9}{"达成率":>8}')

def row(name, size, fl, byt, t):
    I = fl/byt; g = fl/t/1e9; roof = min(PMAX, I*BW)/1e9
    print(f'{name:<26}{size:>12}{fl:12.3e}{byt:12.3e}{I:8.3f}{g:9.2f}{roof:9.2f}{100*g/roof:7.1f}%')

# Level-1: dot
n = 20_000_000
x = np.random.rand(n); y = np.random.rand(n)
t = best(lambda: float(x@y), 5); row('L1 dot (x·y)', f'n={n}', 2*n, 16*n, t)
# Level-1: axpy
a = np.random.rand(n); b = np.random.rand(n)
t = best(lambda: np.add(a, b, out=a), 5); row('L1 axpy (y+=a*x)', f'n={n}', n, 24*n, t)
# Level-2: gemv
m = 8000
A = np.asfortranarray(np.random.rand(m, m)); v = np.random.rand(m); o = np.empty(m)
t = best(lambda: np.dot(A, v, out=o), 5); row('L2 gemv (A*x)', f'n={m}', 2*m*m, 8*m*m, t)
# Level-3: gemm
for k in (500, 1000, 2000):
    A = np.random.rand(k, k); B = np.random.rand(k, k)
    t = best(lambda A=A,B=B: A@B, 5); row(f'L3 gemm (A*B)', f'n={k}', 2*k**3, 8*3*k*k, t)
# Level-3: syrk (Z Z')
nn, mm = 3000, 4000
Z = np.random.rand(nn, mm)
t = best(lambda: Z@Z.T, 3); row('L3 syrk (Z Z\')', f'{nn}x{mm}', nn*nn*mm, 8*(nn*mm+nn*nn), t)
