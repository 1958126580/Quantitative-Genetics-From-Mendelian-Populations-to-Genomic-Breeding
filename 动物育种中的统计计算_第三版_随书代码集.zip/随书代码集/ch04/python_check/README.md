# 第 4 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch04/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `b01_machine.py` | 本机峰值算力与内存带宽实测（供屋顶线模型使用）。 | numpy | 22.6 | `outputs/b01_machine.out` |
| `b02_cache.py` | 缓存层级的阶梯：有效带宽随工作集大小的变化（已扣除 numpy 每次调用的固定开销）。 | numpy | 47.9 | `outputs/b02_cache.out` |
| `b03_layout.py` | 内存布局实测：(1) 列主序 vs 行主序遍历；(2) AoS vs SoA。 | numpy | 5.6 | `outputs/b03_layout.out` |
| `b04_blas.py` | BLAS 三级的实测性能，与屋顶线模型的预测对照。 | numpy | 19.2 | `outputs/b04_blas.out` |
| `b05_bw.py` | 五种流式内核的实测带宽，用于确定屋顶线的带宽上界 B。工作集 512 MB >> L3(33 MB)。 | numpy | 12.7 | `outputs/b05_bw.out` |
| `b06_spmv.py` | SpMV 的实测性能：以系谱构造的 A^{-1} 为例，与屋顶线预测对照。 | numpy, scipy | 32.8 | `outputs/b06_spmv.out` |
| `b08_reduce.py` | 归约顺序与可复现性：浮点加法不满足结合律（块内严格顺序累加）。 | numpy | 3.9 | `outputs/b08_reduce.out` |
| `b09_models.py` | 纯模型计算：Amdahl/Gustafson、分块尺寸、显存容量、通信代价。 | 标准库 | 0.1 | `outputs/b09_models.out` |
| `b10_dist.py` | 分布式的判据：PCG 通信/计算交叉点；pmap 任务粒度下界。 | 标准库 | 0.0 | `outputs/b10_dist.out` |
| `b11_gpu.py` | GPU 判据的模型计算（无 GPU 可用，全部为公式代入）。 | numpy | 0.3 | `outputs/b11_gpu.out` |
| `b12_bench.py` | 基准方法学：时间分布的形状；临时数组的代价。 | numpy, scipy | 52.3 | `outputs/b12_bench.out` |
| `b14_fmt.py` | 浮点格式参数：全部由“符号/阶码/尾数位宽”的定义算出。 | 标准库 | 0.0 | `outputs/b14_fmt.out` |
