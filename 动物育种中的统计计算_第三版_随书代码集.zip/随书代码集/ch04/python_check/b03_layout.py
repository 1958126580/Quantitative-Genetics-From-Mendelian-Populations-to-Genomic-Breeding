# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b03_layout.py    依赖：numpy
"""内存布局实测：(1) 列主序 vs 行主序遍历；(2) AoS vs SoA。"""
import numpy as np, time
def best(f, reps=7):
    f(); f()
    ts=[]
    for _ in range(reps):
        t0=time.perf_counter(); f(); ts.append(time.perf_counter()-t0)
    return min(ts), float(np.median(ts))

print('== (1) 同一矩阵、同一运算，只改存储顺序 ==')
n = 4000                      # 4000^2 * 8 B = 128 MB，远超 L3
AF = np.asfortranarray(np.random.rand(n, n))   # 列主序（Julia 的默认）
AC = np.ascontiguousarray(AF)                  # 行主序（C 的默认）
assert np.allclose(AF, AC)
for name, A in (('列主序 F', AF), ('行主序 C', AC)):
    t1,_ = best(lambda A=A: A.sum(axis=0), 5)   # 沿列求和：顺着列主序走
    t2,_ = best(lambda A=A: A.sum(axis=1), 5)   # 沿行求和：顺着行主序走
    byt = n*n*8
    print(f'{name}: 按列归约 {t1*1e3:7.1f} ms ({byt/t1/1e9:5.2f} GB/s) | '
          f'按行归约 {t2*1e3:7.1f} ms ({byt/t2/1e9:5.2f} GB/s) | 比 {max(t1,t2)/min(t1,t2):.2f}×')

print()
print('== (2) 系谱存储：AoS vs SoA，只遍历 sire 列 ==')
N = 10_000_000
dt = np.dtype([('sire','<i4'),('dam','<i4'),('f','<f8')])   # 16 B/个体
aos = np.zeros(N, dtype=dt)
aos['sire'] = np.random.randint(0, N, N, dtype=np.int32)
aos['dam']  = np.random.randint(0, N, N, dtype=np.int32)
aos['f']    = np.random.rand(N)
sire = np.ascontiguousarray(aos['sire'])                    # SoA 的一列，4 B/个体
t_aos,_ = best(lambda: int(aos['sire'].sum(dtype=np.int64)), 5)
t_soa,_ = best(lambda: int(sire.sum(dtype=np.int64)), 5)
print(f'AoS(步长16B) {t_aos*1e3:7.1f} ms   SoA(连续4B) {t_soa*1e3:7.1f} ms   比 {t_aos/t_soa:.2f}×')
print(f'  理论内存流量比 = 16/4 = 4.00×（AoS 每条缓存行只用 4/16）')
print(f'  AoS 实际拉入字节 {N*16/1e6:.0f} MB -> 有效带宽 {N*16/t_aos/1e9:.2f} GB/s')
print(f'  SoA 实际拉入字节 {N*4/1e6:.0f} MB -> 有效带宽 {N*4/t_soa/1e9:.2f} GB/s')

print()
print('== (3) 视图 vs 拷贝（切片的分配代价）==')
m = 20000; M = np.asfortranarray(np.random.rand(m, 500))
t_copy,_ = best(lambda: sum(M[:, j].copy().sum() for j in range(0,500,10)), 5)
t_view,_ = best(lambda: sum(M[:, j].sum() for j in range(0,500,10)), 5)
print(f'先拷贝再求和 {t_copy*1e3:7.2f} ms   直接对视图求和 {t_view*1e3:7.2f} ms   比 {t_copy/t_view:.2f}×')
