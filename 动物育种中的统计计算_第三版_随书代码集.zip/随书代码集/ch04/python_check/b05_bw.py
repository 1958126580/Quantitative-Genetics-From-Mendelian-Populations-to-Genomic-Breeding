# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b05_bw.py    依赖：numpy
"""五种流式内核的实测带宽，用于确定屋顶线的带宽上界 B。工作集 512 MB >> L3(33 MB)。"""
import numpy as np, time
def best(f, reps=7):
    f(); f()
    ts=[]
    for _ in range(reps):
        t0=time.perf_counter(); f(); ts.append(time.perf_counter()-t0)
    return min(ts)
n = 64_000_000                       # 每个数组 512 MB
a = np.random.rand(n); b = np.random.rand(n); c = np.random.rand(n)
tests = [
    ('read   sum(a)',            lambda: float(a.sum()),                 1),
    ('read2  dot(a,b)',          lambda: float(a@b),                     2),
    ('scale  a *= s (原地)',      lambda: np.multiply(a, 1.0000001, out=a), 2),
    ('copy   c = a',             lambda: np.copyto(c, a),                2),
    ('triad  c = a + s*b',       lambda: np.add(a, b, out=c),            3),
]
print(f'{"内核":<22}{"流数":>5}{"时间ms":>10}{"带宽GB/s":>11}')
bws=[]
for name, f, streams in tests:
    t = best(f, 5); bw = streams*n*8/t/1e9; bws.append(bw)
    print(f'{name:<22}{streams:>5}{t*1e3:10.1f}{bw:11.2f}')
print(f'\n可持续带宽上界 B = {max(bws):.1f} GB/s（取五者最大）')
