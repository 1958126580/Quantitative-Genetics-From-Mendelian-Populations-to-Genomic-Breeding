# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b06_spmv.py    依赖：numpy, scipy
"""SpMV 的实测性能：以系谱构造的 A^{-1} 为例，与屋顶线预测对照。"""
import numpy as np, scipy.sparse as sp, time
rng = np.random.default_rng(20260923)
def best(f, reps=7):
    f(); f()
    ts=[]
    for _ in range(reps):
        t0=time.perf_counter(); f(); ts.append(time.perf_counter()-t0)
    return min(ts)

PMAX = 139.3e9; B = 28.7e9
def build_Ainv(n, nbase):
    """Henderson 规则（忽略近交）：双亲已知个体 b=2，贡献 9 个位置。"""
    idx = np.arange(nbase, n)
    sire = rng.integers(0, idx[:, None]*0 + 1, size=0) if False else None
    sire = (rng.random(n-nbase)*(idx-1)).astype(np.int64)     # 父序号 < 自身
    dam  = (rng.random(n-nbase)*(idx-1)).astype(np.int64)
    b = 2.0
    I = np.concatenate([idx, idx, idx, sire, dam, sire, dam, sire, dam, np.arange(nbase)])
    J = np.concatenate([idx, sire, dam, idx, idx, sire, dam, dam, sire, np.arange(nbase)])
    V = np.concatenate([np.full(n-nbase, b), np.full(n-nbase,-b/2), np.full(n-nbase,-b/2),
                        np.full(n-nbase,-b/2), np.full(n-nbase,-b/2), np.full(n-nbase, b/4),
                        np.full(n-nbase, b/4), np.full(n-nbase, b/4), np.full(n-nbase, b/4),
                        np.ones(nbase)])
    A = sp.coo_matrix((V, (I, J)), shape=(n, n)).tocsr()
    A.sum_duplicates()
    return A

for n in (200_000, 2_000_000):
    A = build_Ainv(n, n//20)
    A.indices = A.indices.astype(np.int32); A.indptr = A.indptr.astype(np.int32)
    nnz = A.nnz
    x = rng.random(n); y = np.empty(n)
    t = best(lambda: A.dot(x), 5)
    fl = 2*nnz
    byt_min = 12*nnz + 16*n        # 值8B+Int32索引4B/非零元；x、y 各读写一次（乐观）
    I_ = fl/byt_min
    gf = fl/t/1e9
    print(f'n={n:>9d}  nnz={nnz:>10d}  nnz/行={nnz/n:5.2f}  矩阵={(12*nnz+4*n)/1e6:8.1f} MB')
    print(f'    时间={t*1e3:8.2f} ms  实测={gf:6.3f} GFLOPS  I={I_:.3f} FLOP/B'
          f'  屋顶={min(PMAX, I_*B)/1e9:6.3f} GFLOPS  达成率={100*gf/(min(PMAX,I_*B)/1e9):5.1f}%'
          f'  占 Pmax 的 {100*gf*1e9/PMAX:.2f}%')
    print(f'    实际访存带宽 = {byt_min/t/1e9:5.2f} GB/s（占 B 的 {100*byt_min/t/B:.0f}%）')

print()
print('== 对照：同样非零元数的稠密 gemv 与 gemm ==')
m = 4000
Ad = np.asfortranarray(rng.random((m, m))); v = rng.random(m)
t = best(lambda: Ad@v, 5)
print(f'  稠密 gemv n={m}: {2*m*m/t/1e9:6.2f} GFLOPS (I=0.25)')
t = best(lambda: Ad@Ad, 3)
print(f'  稠密 gemm n={m}: {2*m**3/t/1e9:6.2f} GFLOPS (I=O(n))')
