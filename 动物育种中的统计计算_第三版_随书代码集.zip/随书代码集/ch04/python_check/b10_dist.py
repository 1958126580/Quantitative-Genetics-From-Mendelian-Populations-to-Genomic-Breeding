# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 4 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 b10_dist.py    依赖：仅标准库
"""分布式的判据：PCG 通信/计算交叉点；pmap 任务粒度下界。"""
import math
B=28.7e9; alpha=2e-6; beta=1/(5e9)   # 带宽 5 GB/s 的链路，模型参数
print('=== PCG：每步通信延迟 = 2 次 allreduce ≈ 4*alpha*log2(p) ===')
print(f'{"p":>5}{"通信us":>10}{"计算=通信的N*":>16}{"N*的每进程行数":>16}')
for p in (2,4,8,16,32,64,128,256,512):
    tc=4*alpha*math.log2(p)
    # 每进程 SpMV 时间 = 12*nnzpr*N/(p*B)；令其 = tc
    nnzpr=7
    N=tc*p*B/(12*nnzpr)
    print(f'{p:5d}{tc*1e6:10.2f}{N:16.3e}{N/p:16.3e}')
print()
print('=== 判据：通信占比 < 10% 要求每进程至少 r 行 ===')
for p in (8,32,128,512):
    tc=4*alpha*math.log2(p); nnzpr=7
    N=10*tc*p*B/(12*nnzpr)
    print(f'  p={p:4d}: N ≥ {N:.2e}，即每进程 ≥ {N/p:.2e} 行')
print()
print('=== pmap 任务粒度：单次任务耗时 T，结果 S 字节，进程数 p ===')
print('开销 ≈ 调度往返 + 序列化。取往返 c0=200 us，序列化速率 1 GB/s（模型参数）')
c0=200e-6; ser=1/1e9
for S,T in ((1e3,1e-3),(1e3,1e-1),(1e6,1e-1),(1e6,1.0),(1e8,10.0)):
    ov=c0+S*ser
    print(f'  结果 {S:8.0e} B, 任务 {T:6.3f} s -> 开销/计算 = {ov/T*100:8.2f}%  '
          + ('可并行' if ov/T<0.05 else '粒度太细，应合并'))
print()
print('=== 数据分发：把 D 字节广播到 p 个进程的时间（树形广播 ~ log2(p)*D/链路带宽）===')
for D in (1e9, 2e10, 1e11):
    for p in (8,64):
        t=math.log2(p)*D/5e9
        print(f'  D={D:8.0e} B, p={p:3d}: 广播 ≈ {t:8.1f} s；若每进程额外占内存 {D/2**30:.1f} GiB')
