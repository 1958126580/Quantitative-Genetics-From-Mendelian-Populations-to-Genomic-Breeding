# 第四章　高性能计算：性能工程、并行与 GPU —— 配套代码

**所属**：第一篇　计算基础与 Julia 语言　　**对应正文**：第四章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch04.ipynb` | IJulia 笔记本：10 个代码单元，约 202 行 Julia 代码，穿插与正文对应的说明 |
| `ch04.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 12 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 0　准备：模拟基因型数据
- L0　朴素实现（类型不稳定 + 错误的遍历顺序）
- L1　类型稳定 + 正确的遍历顺序
- L2　`@inbounds` + `@simd` + 利用对称性
- L3　BLAS Level‑3
- L4　多线程
- L5　GPU
- 屋顶线分析（正文 §4.1.4）
- 加速比汇总
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 04
```

或在 Jupyter 中打开 `ch04/ch04.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
