# 本脚本由 tools/nb2jl.py 从同目录的 ch11.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 11

# %% [markdown]
# # 第十一章　线性模型：估计、检验与可估性 —— 配套代码
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | 正规方程的三种装配方式 | §11.2.1 |
# | 2 | 可估函数与广义逆的不唯一性 | §11.3 |
# | 3 | ML 的向下偏性 | §11.5.2 |
# | 4 | 迭代法：Jacobi、GS、SOR（含第二版缺陷的复现与修正） | §11.6 |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions, BenchmarkTools
rng = Xoshiro(20260918)

# 全书通用：由系谱构建 A 与 A⁻¹（第九章）
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); δ=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); δ=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); δ=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); δ=1.0
        end
        b = inv(δ)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

# %% [markdown]
# ## 1　正规方程的三种装配（正文 §11.2.1）

# %%
# 模拟一个单因子育种数据
n, p = 20_000, 500
lev  = rand(rng, 1:p, n)
μ, α = 10.0, randn(rng, p) .* 2
y    = μ .+ α[lev] .+ randn(rng, n) .* 3

# 【方式一 · 原理实现】先建 X 再算 X'X（可读但浪费）
function normal_eq_dense(lev, p, y)
    n = length(lev)
    X = zeros(n, p+1); X[:,1] .= 1.0
    for i in 1:n; X[i, 1+lev[i]] = 1.0; end
    return X'X, X'y
end

# 【方式二 · 间接累加】不建 X，逐记录累加（第二版第 4 章的思路）
function normal_eq_indirect(lev, p, y)
    XtX = zeros(p+1, p+1); Xty = zeros(p+1)
    @inbounds for i in eachindex(lev)
        a = 1; b = 1 + lev[i]
        XtX[a,a] += 1.0; XtX[a,b] += 1.0; XtX[b,a] += 1.0; XtX[b,b] += 1.0
        Xty[a] += y[i];  Xty[b] += y[i]
    end
    return XtX, Xty
end

# 【方式三 · 优化实现】稀疏三元组一次构造
function normal_eq_sparse(lev, p, y)
    n = length(lev)
    X = sparse(vcat(1:n, 1:n), vcat(fill(1, n), 1 .+ lev), ones(2n), n, p+1)
    return Matrix(X'X), Vector(X'y)
end

A1, b1 = normal_eq_dense(lev, p, y)
A2, b2 = normal_eq_indirect(lev, p, y)
A3, b3 = normal_eq_sparse(lev, p, y)
@printf("【对照验证】方式一 vs 二 : %.3e ； 一 vs 三 : %.3e\n",
        norm(A1-A2)/norm(A1), norm(A1-A3)/norm(A1))
@printf("稠密建 X  : %8.2f ms   分配 %7.1f MiB\n",
        (@belapsed normal_eq_dense($lev,$p,$y))*1e3, (@allocated normal_eq_dense(lev,p,y))/2^20)
@printf("间接累加  : %8.2f ms   分配 %7.1f MiB\n",
        (@belapsed normal_eq_indirect($lev,$p,$y))*1e3, (@allocated normal_eq_indirect(lev,p,y))/2^20)
@printf("稀疏构造  : %8.2f ms   分配 %7.1f MiB\n",
        (@belapsed normal_eq_sparse($lev,$p,$y))*1e3, (@allocated normal_eq_sparse(lev,p,y))/2^20)

# %% [markdown]
# ## 2　可估函数（正文 §11.3）
#
# **核心结论：固定效应的绝对值随广义逆而变，对比与最小二乘均值不变。**

# %%
# 小例子：截距 + 3 水平场效应
ns = [5, 7, 4]
herd = vcat(fill(1,ns[1]), fill(2,ns[2]), fill(3,ns[3]))
n = length(herd)
X = hcat(ones(n), [Float64(herd[i]==k) for i in 1:n, k in 1:3])
ytrue = 10.0 .+ [2.0, -1.0, 0.5][herd]
y = ytrue .+ 0.3 .* randn(Xoshiro(1), n)

@printf("rank(X) = %d, 列数 = %d ⇒ 秩亏 %d\n\n", rank(X), size(X,2), size(X,2)-rank(X))

sols = Dict(
  "pinv (Moore–Penrose)" => pinv(X'X)*(X'y),
  "水平1 = 0"            => (b = (X[:,[1,3,4]]'X[:,[1,3,4]]) \ (X[:,[1,3,4]]'y); [b[1],0.0,b[2],b[3]]),
  "水平3 = 0"            => (b = (X[:,[1,2,3]]'X[:,[1,2,3]]) \ (X[:,[1,2,3]]'y); [b[1],b[2],b[3],0.0]),
  "Julia \\ (最小范数)"  => Vector((X'X) \ (X'y)),
)
println(rpad("广义逆选择", 24), rpad("μ", 10), rpad("h₁", 10), rpad("h₂", 10), "h₃")
println("-"^64)
for (k, v) in sort(collect(sols), by=first)
    @printf("%-24s%-10.4f%-10.4f%-10.4f%.4f\n", k, v...)
end

println("\n可估函数的值（与广义逆无关）：")
Ks = Dict("h₁ − h₂" => [0.,1.,-1.,0.], "h₁ − h₃" => [0.,1.,0.,-1.],
          "μ + h₁ (LSM₁)" => [1.,1.,0.,0.], "h₁ 单独 (不可估)" => [0.,1.,0.,0.])
Hb = pinv(X'X)*(X'X)
for (nm, k) in sort(collect(Ks), by=first)
    vals = [dot(k, v) for (_, v) in sort(collect(sols), by=first)]
    est  = norm(k'Hb - k') < 1e-10
    @printf("  %-18s %s   值 = %s\n", nm, est ? "可估 ✓" : "不可估 ✗",
            join([@sprintf("%8.4f", x) for x in vals], " "))
end

# %% [markdown]
# ## 3　ML 对方差的向下偏性（正文式 11.17）

# %%
"""模拟检验 σ̂²_ML 的偏性：E(σ̂²_ML) = (n−r)/n · σ²."""
function ml_bias_sim(n::Int, r::Int, σ²::Float64; R::Int=4000)
    ml = Float64[]; unb = Float64[]
    for rep in 1:R
        rr = Xoshiro(hash((77, rep)))
        X = randn(rr, n, r)
        β = randn(rr, r)
        y = X*β .+ randn(rr, n).*sqrt(σ²)
        H = X*((X'X)\X')
        sse = y'*(I - H)*y
        push!(ml, sse/n); push!(unb, sse/(n-r))
    end
    return mean(ml), mean(unb)
end

println(rpad("n", 8), rpad("r", 8), rpad("r/n", 10), rpad("E(σ̂²_ML)", 14), rpad("理论", 12), "E(σ̂²_无偏)")
println("-"^66)
for (n, r) in ((100,5), (100,30), (50,25), (200,100))
    m, u = ml_bias_sim(n, r, 4.0)
    @printf("%-8d%-8d%-10.3f%-14.4f%-12.4f%.4f\n", n, r, r/n, m, 4.0*(n-r)/n, u)
end
println()
println("→ 固定效应越多（r/n 越大），ML 的向下偏性越严重。")
println("  育种模型中 r 可达数千 —— 这就是 REML 存在的理由（第十七章）。")

# %% [markdown]
# ## 4　迭代法（正文 §11.6）
#
# ### 4.1 第二版 `Jacobi` 函数的缺陷复现与修正（勘误 1‑4）

# %%
# 【第二版写法】循环外初始化缺少 "+ x"
function jacobi_v2(A, x0, b, ω; tol=1e-10, maxiter=2000)
    x = copy(x0); D = diag(A)
    res = A*x; resid = b - res
    tempSol = resid ./ D                       # ← 缺少 + x
    for k in 1:maxiter
        x = ω .* tempSol .+ (1-ω) .* x
        resid = b - A*x
        tempSol = resid ./ D .+ x              # ← 循环内有 + x，与上面不一致
        norm(resid)/norm(b) < tol && break
    end
    return x
end

# 【修正版】统一为 x ← x + ω D⁻¹ r
function jacobi_fixed(A, x0, b, ω; tol=1e-10, maxiter=2000)
    x = copy(x0); D = diag(A)
    for k in 1:maxiter
        r = b - A*x
        norm(r)/norm(b) < tol && break
        x = x .+ ω .* (r ./ D)
    end
    return x
end

# 构造严格对角占优的测试矩阵
m = 400
A = randn(Xoshiro(2), m, m); A = (A + A')/2
A[diagind(A)] .= vec(sum(abs, A; dims=2)) .+ 1.0
xs = randn(Xoshiro(3), m); b = A*xs

println("【零初值】两版本应当一致：")
for (nm, f) in (("第二版", jacobi_v2), ("修正版", jacobi_fixed))
    x = f(A, zeros(m), b, 1.0)
    @printf("  %-8s 相对误差 = %.3e\n", nm, norm(x - xs)/norm(xs))
end

println("\n【非零初值（热启动）】缺陷暴露：")
x0 = xs .+ 0.1 .* randn(Xoshiro(4), m)
for (nm, f) in (("第二版", jacobi_v2), ("修正版", jacobi_fixed))
    x = f(A, x0, b, 1.0)
    @printf("  %-8s 相对误差 = %.3e\n", nm, norm(x - xs)/norm(xs))
end
println("\n→ 第二版的例子全部使用零初值，掩盖了这个缺陷（勘误 1-4）。")
println("  热启动在 REML 迭代、多性状逐轮求解中很常见。")

# %% [markdown]
# ### 4.2 Jacobi / Gauss–Seidel / SOR 的收敛速度对照

# %%
function gauss_seidel(A, x0, b; tol=1e-10, maxiter=5000)
    x = copy(x0); n = length(b); nb = norm(b); iters = 0
    for k in 1:maxiter
        @inbounds for i in 1:n
            s = b[i]
            for j in 1:n
                j == i && continue
                s -= A[i,j]*x[j]
            end
            x[i] = s / A[i,i]
        end
        iters = k
        norm(b - A*x)/nb < tol && break
    end
    return x, iters
end

function sor(A, x0, b, ω; tol=1e-10, maxiter=5000)
    x = copy(x0); n = length(b); nb = norm(b); iters = 0
    for k in 1:maxiter
        @inbounds for i in 1:n
            s = b[i]
            for j in 1:n
                j == i && continue
                s -= A[i,j]*x[j]
            end
            x[i] = (1-ω)*x[i] + ω*s/A[i,i]
        end
        iters = k
        norm(b - A*x)/nb < tol && break
    end
    return x, iters
end

# 迭代矩阵的谱半径（正文定理）
D = Diagonal(diag(A)); L = tril(A, -1); U = triu(A, 1)
ρ_J  = maximum(abs, eigvals(Matrix(-inv(D)*(L+U))))
ρ_GS = maximum(abs, eigvals(Matrix(-inv(D+L)*U)))
@printf("ρ(B_Jacobi)       = %.6f\n", ρ_J)
@printf("ρ(B_GaussSeidel)  = %.6f   （≈ ρ_J² = %.6f）\n", ρ_GS, ρ_J^2)
@printf("最优 ω (式 11.30) = %.4f\n\n", 2/(1+sqrt(1-ρ_J^2)))

x_j = jacobi_fixed(A, zeros(m), b, 1.0)
xg, ig = gauss_seidel(A, zeros(m), b)
ω_opt = 2/(1+sqrt(1-ρ_J^2))
xs_, is_ = sor(A, zeros(m), b, ω_opt)
println(rpad("方法", 20), rpad("迭代次数", 12), "相对误差")
println("-"^46)
@printf("%-20s%-12s%.3e\n", "Gauss–Seidel", string(ig), norm(xg-xs)/norm(xs))
@printf("%-20s%-12s%.3e\n", @sprintf("SOR (ω=%.3f)", ω_opt), string(is_), norm(xs_-xs)/norm(xs))
println("\n→ ρ(B_GS) ≈ ρ(B_J)²：Gauss–Seidel 的一次迭代约抵 Jacobi 的两次。")

# %% [markdown]
# ### 4.3 停机准则：为什么两个条件都要（正文式 11.31）

# %%
# 构造一个病态系统，演示"残差小但解不准"
function make_ill(m, κ; rng=Random.default_rng())
    Q, _ = qr(randn(rng, m, m)); Q = Matrix(Q)
    λ = exp.(range(0, log(κ); length=m))
    return Symmetric(Q*Diagonal(λ)*Q')
end
Aill = make_ill(200, 1e8; rng=Xoshiro(6))
xtrue = randn(Xoshiro(7), 200); bill = Aill*xtrue

# 人为构造一个残差很小但解不准的向量
δ = eigvecs(Matrix(Aill))[:, 1]      # 最小特征值方向
xbad = xtrue .+ 50 .* δ
@printf("相对残差 ‖b−Ax‖/‖b‖ = %.3e   ← 看起来已经收敛\n", norm(bill - Aill*xbad)/norm(bill))
@printf("相对误差 ‖x−x*‖/‖x*‖ = %.3e   ← 实际上完全不准\n", norm(xbad - xtrue)/norm(xtrue))
@printf("κ(A) = %.2e\n", cond(Matrix(Aill)))
println("\n→ 病态问题上残差小不意味着解准确（第三章式 3.2）。")
println("  必须同时检查解的相对变化，且对育种问题用式 (15.7) 的准则。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **正规方程的三种装配方式结果一致**，但稀疏三元组构造在内存与速度上最优。
# 2. **秩亏模型中固定效应的"解"随广义逆而变**，而对比与最小二乘均值不变——可估性可用 $\mathbf k'\mathbf H=\mathbf k'$ 判别。
# 3. **ML 对方差的向下偏性为 $r/n$**，模拟与理论完全吻合；育种模型中 $r$ 很大，这是 REML 的理由。
# 4. **第二版 `Jacobi` 的初始化缺陷只在非零初值时暴露**——本笔记本复现并修正。
# 5. $\rho(\mathbf B_{GS})\approx\rho(\mathbf B_J)^2$：GS 一次迭代约抵 Jacobi 两次。
# 6. **病态问题上"残差小"不等于"解准"**——停机准则必须同时看解的变化。
