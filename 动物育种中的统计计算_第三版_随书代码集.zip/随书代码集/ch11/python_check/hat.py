# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 hat.py    依赖：numpy
"""Hat matrix, leverages, estimability criteria, LSMeans."""
import numpy as np
from data import X, y, A, b, COLS, n, p, r, herd, treat
np.set_printoptions(precision=6, suppress=True, linewidth=220)
Gmp = np.linalg.pinv(A)
H   = X@Gmp@X.T
Hb  = Gmp@A                       # k' Hb = k'  <=> estimable
h   = np.diag(H)
bhat= Gmp@b
yhat= X@bhat; e = y-yhat
SSE = e@e; sig2 = SSE/(n-r)

print('== 帽子矩阵性质 ==')
print('||H^2-H||_max = %.2e' % np.abs(H@H-H).max())
print('||H-H\'||_max  = %.2e' % np.abs(H-H.T).max())
print('tr(H) = %.10f   rank(H) = %d   r = %d' % (np.trace(H), np.linalg.matrix_rank(H), r))
print('||HX-X||_max = %.2e' % np.abs(H@X-X).max())
# H invariant to choice of g-inverse
def sub_ginv(I,J):
    G=np.zeros((p,p)); G[np.ix_(J,I)]=np.linalg.inv(A[np.ix_(I,J)]); return G
for I,J,nm in [([0,1,3,4],[0,1,3,4],'置零A'),([0,2,4,5],[0,2,4,5],'置零B'),([0,1,3,4],[0,1,4,5],'反射')]:
    G=sub_ginv(I,J); print('  ||X G X\' - H||_max (%s) = %.2e' % (nm, np.abs(X@G@X.T-H).max()))

print('\n== 逐记录杠杆值 ==')
print('%3s %4s %5s %8s %9s %9s %9s %9s' % ('i','herd','trt','y','yhat','e','h_ii','stud.res'))
sres=[]
for i in range(n):
    sr = e[i]/np.sqrt(sig2*(1-h[i])) if 1-h[i]>1e-12 else np.nan
    sres.append(sr)
    print('%3d %4d %5d %8.1f %9.4f %9.4f %9.6f %9.4f' % (i+1,herd[i],treat[i],y[i],yhat[i],e[i],h[i],sr))
print('sum h_ii = %.10f ; mean = %.6f = r/n = %.6f' % (h.sum(), h.mean(), r/n))
print('max h_ii = %.6f at record %d (herd %d, treat %d)' % (h.max(), h.argmax()+1, herd[h.argmax()], treat[h.argmax()]))
print('min h_ii = %.6f at record %d' % (h.min(), h.argmin()+1))
print('2r/n = %.6f ; 记录 h_ii > 2r/n 的有:' % (2*r/n), [i+1 for i in range(n) if h[i]>2*r/n])
print('SSE=%.6f  df=%d  sigma2hat=%.6f  sigma=%.6f'%(SSE,n-r,sig2,np.sqrt(sig2)))

# leave-one-out: delete record 6 (the singleton cell 1,3)
print('\n== 删除第 6 条记录（单元 (1,3) 唯一记录）后 ==')
m=np.ones(n,bool); m[5]=False
X2=X[m]; y2=y[m]
print('rank(X) 由 %d 变为 %d' % (r, np.linalg.matrix_rank(X2)))
A2=X2.T@X2; G2=np.linalg.pinv(A2); b2=G2@(X2.T@y2)
k=np.array([0,0,0,1.,0,-1.])
print('t1-t3 在删除前 = %.6f' % (k@bhat))
print('k\'Hb - k\'  (删除后) = %.6e  -> 可估？ %s' % (np.abs(k@(G2@A2)-k).max(), np.abs(k@(G2@A2)-k).max()<1e-8))

# ---- 交互模型下的杠杆值 ----
print('\n== 含交互的饱和模型 ==')
cells=[(hh,tt) for hh in [1,2] for tt in [1,2,3]]
Xi=np.hstack([X]+[np.array([[1.0 if (herd[i],treat[i])==c else 0.0] for i in range(n)]) for c in cells])
ri=np.linalg.matrix_rank(Xi)
Hi=Xi@np.linalg.pinv(Xi.T@Xi)@Xi.T; hi=np.diag(Hi); ei=y-Hi@y
print('p=%d rank=%d  tr(H)=%.8f  SSE=%.6f  df=%d'%(Xi.shape[1],ri,np.trace(Hi),ei@ei,n-ri))
for i in range(n):
    print('  %2d (%d,%d) h_ii=%.6f  e=%+.6f'%(i+1,herd[i],treat[i],hi[i],ei[i]))
