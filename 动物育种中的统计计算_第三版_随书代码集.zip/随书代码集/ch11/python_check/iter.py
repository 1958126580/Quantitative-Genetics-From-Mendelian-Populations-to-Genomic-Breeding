# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 iter.py    依赖：numpy
"""Jacobi / Gauss-Seidel / SOR on the reduced normal equations of the running example."""
import numpy as np
from data import X, y, A, b, n, p, r
np.set_printoptions(precision=6, suppress=True, linewidth=220)

keep=[0,1,3,4]                      # mu, h1, t1, t2  (h2=0, t3=0)
Ar=A[np.ix_(keep,keep)]; br=b[keep]
xstar=np.linalg.solve(Ar,br)
print('A_r =\n',Ar.astype(int)); print('b_r =',br); print('x* =',np.round(xstar,8))
w,_=np.linalg.eigh(Ar)
print('特征值 =',np.round(w,6),' kappa=%.6f'%(w.max()/w.min()))
print('严格对角占优？', all(Ar[i,i]>sum(abs(Ar[i,j]) for j in range(4) if j!=i) for i in range(4)))
for i in range(4):
    print('  行%d: a_ii=%.1f, 非对角绝对值和=%.1f'%(i+1,Ar[i,i],sum(abs(Ar[i,j]) for j in range(4) if j!=i)))
print('对称正定？', np.all(w>0))

D=np.diag(np.diag(Ar)); L=np.tril(Ar,-1); U=np.triu(Ar,1)
BJ=-np.linalg.solve(D,L+U)
BG=-np.linalg.solve(D+L,U)
rJ=max(abs(np.linalg.eigvals(BJ))); rG=max(abs(np.linalg.eigvals(BG)))
print('\nrho(B_Jacobi)=%.6f  rho(B_GS)=%.6f  rho_GS/rho_J^2=%.6f'%(rJ,rG,rG/rJ**2))
wopt=2/(1+np.sqrt(1-rJ**2))
print('理论最优松弛因子 omega_opt = 2/(1+sqrt(1-rho_J^2)) = %.6f'%wopt)
print('对应的 rho(B_SOR) 理论值 = omega_opt-1 = %.6f'%(wopt-1))

def sor(omega,tol=1e-10,maxit=100000,x0=None):
    x=np.zeros(4) if x0 is None else x0.copy()
    nb=np.linalg.norm(br)
    for k in range(1,maxit+1):
        for i in range(4):
            s=Ar[i,:]@x-Ar[i,i]*x[i]
            x[i]=(1-omega)*x[i]+omega*(br[i]-s)/Ar[i,i]
        if np.linalg.norm(br-Ar@x)/nb<tol: return k,x
    return maxit,x
def jacobi(omega=1.0,tol=1e-10,maxit=100000):
    x=np.zeros(4); nb=np.linalg.norm(br)
    for k in range(1,maxit+1):
        x=x+omega*(br-Ar@x)/np.diag(Ar)
        if np.linalg.norm(br-Ar@x)/nb<tol: return k,x
    return maxit,x

kJ,xJ=jacobi(); kG,xG=sor(1.0)
print('\n== 迭代次数（相对残差 < 1e-10，零初值）==')
print('Jacobi        %4d 次  ||x-x*||=%.2e'%(kJ,np.linalg.norm(xJ-xstar)))
print('Gauss–Seidel  %4d 次  ||x-x*||=%.2e'%(kG,np.linalg.norm(xG-xstar)))
print('\n== SOR：迭代次数随 omega ==')
best=(10**9,None)
for om in [round(0.5+0.1*i,2) for i in range(15)]:
    k,x=sor(om)
    B=np.linalg.solve(D+om*L,(1-om)*D-om*U); rho=max(abs(np.linalg.eigvals(B)))
    if k<best[0]: best=(k,om)
    print('  omega=%.2f  迭代 %4d  rho(B_SOR)=%.6f'%(om,k,rho))
for om in [round(1.00+0.01*i,3) for i in range(0,31)]:
    pass
print('实测最优 omega = %.2f（%d 次）'%(best[1],best[0]))
# fine grid
best2=(10**9,None)
for om in np.arange(0.80,1.60,0.01):
    k,_=sor(round(om,2))
    if k<best2[0]: best2=(k,round(om,2))
print('细网格（步长 0.01）实测最优 omega = %.2f（%d 次）'%(best2[1],best2[0]))
# theoretical rho minimiser
rhos=[]
for om in np.arange(0.50,2.00,0.001):
    B=np.linalg.solve(D+om*L,(1-om)*D-om*U); rhos.append((max(abs(np.linalg.eigvals(B))),om))
rmin=min(rhos)
print('使 rho(B_SOR) 最小的 omega = %.3f，rho=%.6f'%(rmin[1],rmin[0]))
print('（与 Young 公式 %.6f 相比，差 %.3f —— A_r 不是相容次序矩阵）'%(wopt,rmin[1]-wopt))

# ---- 相容次序（三对角）例子：Young 公式精确 ----
print('\n== 三对角例子（一维 Laplace，m=20）：Young 公式精确成立 ==')
m=20
T=np.diag(2*np.ones(m))+np.diag(-np.ones(m-1),1)+np.diag(-np.ones(m-1),-1)
bT=np.ones(m)
DT=np.diag(np.diag(T)); LT=np.tril(T,-1); UT=np.triu(T,1)
rJT=max(abs(np.linalg.eigvals(-np.linalg.solve(DT,LT+UT))))
woptT=2/(1+np.sqrt(1-rJT**2))
print('rho_J=%.6f  理论 omega_opt=%.6f  理论 rho_SOR=%.6f'%(rJT,woptT,woptT-1))
rhoT=[]
for om in np.arange(1.0,1.999,0.001):
    B=np.linalg.solve(DT+om*LT,(1-om)*DT-om*UT); rhoT.append((max(abs(np.linalg.eigvals(B))),om))
mm=min(rhoT); print('数值最小 rho 处 omega=%.3f rho=%.6f  → 与理论差 %.4f'%(mm[1],mm[0],mm[1]-woptT))
def sorT(omega,tol=1e-10,maxit=200000):
    x=np.zeros(m); nb=np.linalg.norm(bT)
    for k in range(1,maxit+1):
        for i in range(m):
            s=T[i,:]@x-T[i,i]*x[i]
            x[i]=(1-omega)*x[i]+omega*(bT[i]-s)/T[i,i]
        if np.linalg.norm(bT-T@x)/nb<tol: return k
    return maxit
print('迭代次数：Jacobi=%d  GS=%d  SOR(omega_opt=%.3f)=%d'%(
    (lambda: (lambda c: c)( __import__('itertools') and 0))() or 0,0,woptT,0) if False else '')
def jacT(tol=1e-10,maxit=200000):
    x=np.zeros(m); nb=np.linalg.norm(bT)
    for k in range(1,maxit+1):
        x=x+(bT-T@x)/np.diag(T)
        if np.linalg.norm(bT-T@x)/nb<tol: return k
    return maxit
print('迭代次数  Jacobi=%d  Gauss–Seidel=%d  SOR(%.3f)=%d'%(jacT(),sorT(1.0),woptT,sorT(round(woptT,3))))
