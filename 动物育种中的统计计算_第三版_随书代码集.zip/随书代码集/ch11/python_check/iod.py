# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 iod.py    依赖：numpy
"""Iteration on data vs Gauss-Seidel / Jacobi; tridiagonal Young check."""
import numpy as np, warnings
warnings.filterwarnings('ignore')
from data import X, y, n, herd, treat
np.set_printoptions(precision=6, suppress=True, linewidth=220)

# --- 用效应编码的满秩模型做"逐数据迭代" ---
one=np.ones((n,1))
He=np.array([[1.0] if herd[i]==1 else [-1.0] for i in range(n)])
Te=np.array([[1.,0.] if treat[i]==1 else ([0.,1.] if treat[i]==2 else [-1.,-1.]) for i in range(n)])
Xe=np.hstack([one,He,Te]); A=Xe.T@Xe; b=Xe.T@y; N=4
xstar=np.linalg.solve(A,b)

def gs_matrix(K):                       # 常规 Gauss-Seidel（需要显式 A）
    x=np.zeros(N); out=[]
    for _ in range(K):
        for i in range(N):
            s=A[i,:]@x-A[i,i]*x[i]
            x[i]=(b[i]-s)/A[i,i]
        out.append(x.copy())
    return np.array(out)

def iod_effectwise(K):                  # 逐效应的逐数据迭代：只扫数据，不建 A
    x=np.zeros(N); out=[]
    for _ in range(K):
        for i in range(N):
            num=0.0; den=0.0
            for rec in range(n):        # 扫一遍数据文件
                xi=Xe[rec,i]
                if xi==0.0: continue
                adj=y[rec]-(Xe[rec,:]@x-xi*x[i])
                num+=xi*adj; den+=xi*xi
            x[i]=num/den
        out.append(x.copy())
    return np.array(out)

def iod_recordwise(K):                  # 逐记录累加 A x，扫完再整体更新
    x=np.zeros(N); out=[]
    dgn=np.array([ (Xe[:,i]**2).sum() for i in range(N)])
    for _ in range(K):
        Ax=np.zeros(N); rhs=np.zeros(N)
        for rec in range(n):
            Ax+=Xe[rec,:]*(Xe[rec,:]@x); rhs+=Xe[rec,:]*y[rec]
        x=x+(rhs-Ax)/dgn
        out.append(x.copy())
    return np.array(out)

def jacobi_matrix(K):
    x=np.zeros(N); out=[]
    for _ in range(K):
        x=x+(b-A@x)/np.diag(A); out.append(x.copy())
    return np.array(out)

K=25
g=gs_matrix(K); e1=iod_effectwise(K); j=jacobi_matrix(K); e2=iod_recordwise(K)
print('逐效应逐数据迭代 vs Gauss–Seidel：逐次迭代最大差 = %.3e'%np.abs(g-e1).max())
print('逐记录逐数据迭代 vs Jacobi      ：逐次迭代最大差 = %.3e'%np.abs(j-e2).max())
print('x* =',np.round(xstar,6))
print('\n前 6 次迭代（逐效应=GS）:')
for k in range(6):
    print('  k=%d  %s  ||x-x*||=%.3e'%(k+1,np.round(e1[k],6),np.linalg.norm(e1[k]-xstar)))
print('\n前 6 次迭代（逐记录=Jacobi）:')
for k in range(6):
    print('  k=%d  %s  ||x-x*||=%.3e'%(k+1,np.round(e2[k],6),np.linalg.norm(e2[k]-xstar)))

# 存储对照
nnz=int((A!=0).sum())
print('\n存储：显式 A 需 %d 个非零元；逐数据迭代只需解向量 %d 个 + 数据本身'%(nnz,N))

# --- 三对角 Young 校验 ---
print('\n== 三对角 m=20 ==')
m=20
T=np.diag(2*np.ones(m))+np.diag(-np.ones(m-1),1)+np.diag(-np.ones(m-1),-1)
D=np.diag(np.diag(T)); L=np.tril(T,-1); U=np.triu(T,1)
def rho(M): return max(abs(np.linalg.eigvals(M)))
rJ=rho(-np.linalg.solve(D,L+U)); rG=rho(-np.linalg.solve(D+L,U))
print('rho_J=%.6f  rho_J^2=%.6f  rho_GS=%.6f  (相等? %s)'%(rJ,rJ**2,rG,abs(rJ**2-rG)<1e-9))
wo=2/(1+np.sqrt(1-rJ**2))
print('Young omega_opt=%.6f  预测 rho_SOR=omega-1=%.6f'%(wo,wo-1))
rr=[(rho(np.linalg.solve(D+om*L,(1-om)*D-om*U)),om) for om in np.arange(1.0,1.999,0.0005)]
mn=min(rr); print('数值最优 omega=%.4f rho=%.6f'%(mn[1],mn[0]))
print('理论 cos(pi/(m+1)) = %.6f'%np.cos(np.pi/(m+1)))
