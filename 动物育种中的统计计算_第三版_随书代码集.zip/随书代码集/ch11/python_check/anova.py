# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 anova.py    依赖：numpy, scipy
import numpy as np
from scipy import stats
from data import X, y, n, herd, treat
one=np.ones((n,1))
Hd=np.array([[1.0 if herd[i]==l else 0. for l in [1,2]] for i in range(n)])
Td=np.array([[1.0 if treat[i]==l else 0. for l in [1,2,3]] for i in range(n)])
def R(*bl):
    M=np.hstack(bl); P=M@np.linalg.pinv(M.T@M)@M.T; return y@P@y, np.linalg.matrix_rank(M)
Rm,dm=R(one); Rmh,dmh=R(one,Hd); Rmt,dmt=R(one,Td); Rf,df=R(one,Hd,Td)
SSE=y@y-Rf; dfe=n-df; MSE=SSE/dfe
print('== 可加模型方差分析表（n=%d, rank=%d）=='%(n,df))
print('总（未校正） y\'y            = %.6f  df=%d'%(y@y,n))
print('R(mu)                      = %.6f  df=%d'%(Rm,dm))
print('校正总平方和 SST           = %.6f  df=%d'%(y@y-Rm,n-1))
print('R(h|mu)   = %.6f df=%d  F=%.4f p=%.6f'%(Rmh-Rm,dmh-dm,(Rmh-Rm)/(dmh-dm)/MSE,stats.f.sf((Rmh-Rm)/(dmh-dm)/MSE,dmh-dm,dfe)))
print('R(t|mu,h) = %.6f df=%d  F=%.4f p=%.6f'%(Rf-Rmh,df-dmh,(Rf-Rmh)/(df-dmh)/MSE,stats.f.sf((Rf-Rmh)/(df-dmh)/MSE,df-dmh,dfe)))
print('R(t|mu)   = %.6f df=%d'%(Rmt-Rm,dmt-dm))
print('R(h|mu,t) = %.6f df=%d  F=%.4f p=%.6f'%(Rf-Rmt,df-dmt,(Rf-Rmt)/(df-dmt)/MSE,stats.f.sf((Rf-Rmt)/(df-dmt)/MSE,df-dmt,dfe)))
print('SSE       = %.6f df=%d  MSE=%.6f'%(SSE,dfe,MSE))
print('模型（校正后）= %.6f df=%d'%(Rf-Rm,df-dm))
print('校验：%.6f + %.6f = %.6f'%(Rf-Rm,SSE,y@y-Rm))
print('R2 = %.6f'%((Rf-Rm)/(y@y-Rm)))
print('\n顺序和不唯一：R(h|mu)+R(t|mu,h) = %.6f ; R(t|mu)+R(h|mu,t) = %.6f （相等，均为模型SS）'%(Rmh-Rm+Rf-Rmh,Rmt-Rm+Rf-Rmt))
print('但单项不同：R(h|mu)=%.6f vs R(h|mu,t)=%.6f  差 %.6f'%(Rmh-Rm,Rf-Rmt,(Rf-Rmt)-(Rmh-Rm)))
print('           R(t|mu)=%.6f vs R(t|mu,h)=%.6f  差 %.6f'%(Rmt-Rm,Rf-Rmh,(Rf-Rmh)-(Rmt-Rm)))
