# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 mltest.py    依赖：numpy, scipy
"""ML bias, F vs LRT equivalence, on the running example."""
import numpy as np
from scipy import stats
from data import X, y, A, b, n, p, r, herd, treat
Gmp=np.linalg.pinv(A); bhat=Gmp@b
H=X@Gmp@X.T; e=y-H@y; SSE=e@e
s2ml=SSE/n; s2u=SSE/(n-r)
print('n=%d r=%d SSE=%.6f'%(n,r,SSE))
print('sigma2_ML   = SSE/n     = %.6f'%s2ml)
print('sigma2_无偏 = SSE/(n-r) = %.6f'%s2u)
print('相对偏性 = -r/n = %.6f  (%.2f%%)'%(-r/n,-100*r/n))
print('ML 比无偏小 %.4f%%'%(100*(1-s2ml/s2u)))
# MSE 比较 (E[(s2-sigma2)^2] for divisor c: SSE~sigma2*chi2_{n-r})
nu=n-r
def mse(c): return (2*nu/c**2 + (nu/c-1)**2)   # in units of sigma^4
print('\n== 除数 c 的 MSE（以 sigma^4 为单位），nu=%d =='%nu)
for c,nm in [(n,'n (ML)'),(nu,'n-r (无偏)'),(nu+2,'n-r+2 (最小 MSE)')]:
    print('  c=%-4d %-16s MSE=%.6f  偏性=%+.6f'%(c,nm,mse(c),nu/c-1))
print('  理论最小 MSE 的除数 = nu+2 = %d'%(nu+2))
# 大规模育种情形
print('\n== 育种规模下的偏性 ==')
for N,rr in [(50000,3000),(1000000,20000),(200,60),(14,4)]:
    print('  n=%-8d r=%-6d 偏性 = -r/n = %+.4f%%  sigma_ML/sigma = %.6f'%(N,rr,-100*rr/N,np.sqrt(1-rr/N)))

# ---- F 检验 vs LRT: H0: t1=t2=t3 ----
print('\n== H0: t1=t2=t3 ==')
K=np.zeros((2,p)); K[0,3]=1; K[0,4]=-1; K[1,4]=1; K[1,5]=-1
q=np.linalg.matrix_rank(K); Kb=K@bhat
M=K@Gmp@K.T
W=Kb@np.linalg.solve(M,Kb)        # numerator SS
F=(W/q)/ (SSE/(n-r))
pF=stats.f.sf(F,q,n-r)
print('K\'betahat =',np.round(Kb,6),' q=',q)
print('SS_H = %.6f'%W)
# reduced model
Xr=np.hstack([np.ones((n,1)),X[:,1:3]])
Hr=Xr@np.linalg.pinv(Xr.T@Xr)@Xr.T; er=y-Hr@y; SSE0=er@er
print('SSE(full)=%.6f  SSE(reduced)=%.6f  差=%.6f'%(SSE,SSE0,SSE0-SSE))
print('F=%.6f  df=(%d,%d)  p=%.8f'%(F,q,n-r,pF))
# LRT
l1=-n/2*np.log(2*np.pi)-n/2*np.log(SSE/n)-n/2
l0=-n/2*np.log(2*np.pi)-n/2*np.log(SSE0/n)-n/2
Lam=-2*(l0-l1)
print('logL(full)=%.6f  logL(H0)=%.6f  Lambda=%.6f'%(l1,l0,Lam))
print('Lambda = n*log(SSE0/SSE) = %.6f'%(n*np.log(SSE0/SSE)))
print('Lambda = n*log(1+qF/(n-r)) = %.6f'%(n*np.log(1+q*F/(n-r))))
print('chi2_%d p = %.8f  （与 F 检验 p=%.8f 相比）'%(q,stats.chi2.sf(Lam,q),pF))
print('Lambda 与 F 是严格单调变换：两者给出同一拒绝域')
# H0: h1=h2
print('\n== H0: h1=h2 ==')
K2=np.zeros((1,p)); K2[0,1]=1; K2[0,2]=-1
Kb2=K2@bhat; W2=Kb2@np.linalg.solve(K2@Gmp@K2.T,Kb2); F2=W2/(SSE/(n-r))
Xr2=np.hstack([np.ones((n,1)),X[:,3:6]]); Hr2=Xr2@np.linalg.pinv(Xr2.T@Xr2)@Xr2.T
SSE02=(y-Hr2@y)@(y-Hr2@y)
print('SS_H=%.6f  SSE0-SSE=%.6f  F=%.6f p=%.8f  Lambda=%.6f p=%.8f'%(
    W2,SSE02-SSE,F2,stats.f.sf(F2,1,n-r),n*np.log(SSE02/SSE),stats.chi2.sf(n*np.log(SSE02/SSE),1)))
