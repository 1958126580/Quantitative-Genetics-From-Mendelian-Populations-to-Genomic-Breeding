# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ss.py    依赖：numpy, scipy
"""Type I / II / III sums of squares on the unbalanced 2x3 example."""
import numpy as np
from scipy import stats
from data import X, y, n, herd, treat
np.set_printoptions(precision=6, suppress=True, linewidth=220)

def R(cols):
    """model SS (corrected later) for design matrix built from column blocks"""
    M=np.hstack(cols) if len(cols)>1 else cols[0]
    P=M@np.linalg.pinv(M.T@M)@M.T
    return y@P@y, np.linalg.matrix_rank(M)

one=np.ones((n,1))
Hd =np.array([[1.0 if herd[i]==l else 0.0 for l in [1,2]] for i in range(n)])
Td =np.array([[1.0 if treat[i]==l else 0.0 for l in [1,2,3]] for i in range(n)])
cells=[(a,bq) for a in [1,2] for bq in [1,2,3]]
HT =np.array([[1.0 if (herd[i],treat[i])==c else 0.0 for c in cells] for i in range(n)])

def ss(name,*blocks): 
    v,rk=R(list(blocks)); return v,rk
R_m ,r_m  = R([one])
R_mh,r_mh = R([one,Hd])
R_mt,r_mt = R([one,Td])
R_mht,r_mht=R([one,Hd,Td])
R_full,r_full=R([one,Hd,Td,HT])
SSE=y@y-R_full; dfe=n-r_full
print('R(mu)=%.6f df=%d'%(R_m,r_m))
print('R(mu,h)=%.6f df=%d'%(R_mh,r_mh))
print('R(mu,t)=%.6f df=%d'%(R_mt,r_mt))
print('R(mu,h,t)=%.6f df=%d'%(R_mht,r_mht))
print('R(mu,h,t,ht)=%.6f df=%d'%(R_full,r_full))
print('SSE=%.6f  df=%d  MSE=%.6f'%(SSE,dfe,SSE/dfe))
print('SST(corrected)=%.6f'%(y@y-R_m))

print('\n== Type I (顺序 mu, h, t, h*t) ==')
I_h=R_mh-R_m; I_t=R_mht-R_mh; I_ht=R_full-R_mht
print(' h    : R(h|mu)        = %.6f  df=%d'%(I_h,r_mh-r_m))
print(' t    : R(t|mu,h)      = %.6f  df=%d'%(I_t,r_mht-r_mh))
print(' h*t  : R(ht|mu,h,t)   = %.6f  df=%d'%(I_ht,r_full-r_mht))
print(' 合计 = %.6f = SST = %.6f'%(I_h+I_t+I_ht, y@y-R_m))
print('\n== Type I (顺序 mu, t, h, h*t) ==')
print(' t    : R(t|mu)        = %.6f  df=%d'%(R_mt-R_m,r_mt-r_m))
print(' h    : R(h|mu,t)      = %.6f  df=%d'%(R_mht-R_mt,r_mht-r_mt))
print(' h*t  : R(ht|mu,h,t)   = %.6f  df=%d'%(I_ht,r_full-r_mht))

print('\n== Type II ==')
II_h=R_mht-R_mt; II_t=R_mht-R_mh; II_ht=I_ht
print(' h    : R(h|mu,t)      = %.6f'%II_h)
print(' t    : R(t|mu,h)      = %.6f'%II_t)
print(' h*t  : R(ht|mu,h,t)   = %.6f'%II_ht)

print('\n== Type III (效应编码下的偏平方和) ==')
# sum-to-zero (effect) coding
He=np.array([[1.0] if herd[i]==1 else [-1.0] for i in range(n)])
Te=np.zeros((n,2))
for i in range(n):
    if treat[i]==1: Te[i]=[1,0]
    elif treat[i]==2: Te[i]=[0,1]
    else: Te[i]=[-1,-1]
HTe=np.hstack([He*Te[:,[0]],He*Te[:,[1]]])
full=np.hstack([one,He,Te,HTe])
def sse(M):
    P=M@np.linalg.pinv(M.T@M)@M.T; return y@y-y@P@y
S_full=sse(full)
III_h =sse(np.hstack([one,Te,HTe]))-S_full
III_t =sse(np.hstack([one,He,HTe]))-S_full
III_ht=sse(np.hstack([one,He,Te]))-S_full
print(' h    = %.6f  df=1'%III_h)
print(' t    = %.6f  df=2'%III_t)
print(' h*t  = %.6f  df=2'%III_ht)

print('\n== Type III 的假设检验路线（等权单元均值）==')
# cell means model
Cm=HT
Gm=np.linalg.pinv(Cm.T@Cm); mu_hat=Gm@(Cm.T@y)
print('单元均值 muhat =',np.round(mu_hat,6))
# herd: (1/3)sum_j mu_1j - (1/3)sum_j mu_2j = 0
L=np.zeros((1,6)); L[0,0:3]=1/3; L[0,3:6]=-1/3
Lb=L@mu_hat; W=Lb@np.linalg.solve(L@Gm@L.T,Lb)
print('Type III  h  (等权对比) SS = %.6f'%W)
L2=np.zeros((2,6))
L2[0,0]=.5; L2[0,3]=.5; L2[0,1]=-.5; L2[0,4]=-.5
L2[1,1]=.5; L2[1,4]=.5; L2[1,2]=-.5; L2[1,5]=-.5
Lb2=L2@mu_hat; W2=Lb2@np.linalg.solve(L2@Gm@L2.T,Lb2)
print('Type III  t  (等权对比) SS = %.6f'%W2)
L3=np.zeros((2,6))
L3[0,[0,1,3,4]]=[1,-1,-1,1]
L3[1,[1,2,4,5]]=[1,-1,-1,1]
Lb3=L3@mu_hat; W3=Lb3@np.linalg.solve(L3@Gm@L3.T,Lb3)
print('Type III h*t (等权对比) SS = %.6f'%W3)

print('\n== F 检验（分母 MSE=%.6f, df=%d）=='%(SSE/dfe,dfe))
tab=[('h',1,I_h,II_h,III_h),('t',2,I_t,II_t,III_t),('h*t',2,I_ht,II_ht,III_ht)]
print('%-5s %3s %12s %12s %12s | %8s %8s %8s'%('效应','df','Type I','Type II','Type III','F(I)','F(II)','F(III)'))
for nm,df,a,bb,c in tab:
    Fs=[x/df/(SSE/dfe) for x in (a,bb,c)]
    print('%-5s %3d %12.6f %12.6f %12.6f | %8.4f %8.4f %8.4f'%(nm,df,a,bb,c,*Fs))
print('\np 值：')
for nm,df,a,bb,c in tab:
    print('  %-5s I:%.6f  II:%.6f  III:%.6f'%(nm,*[stats.f.sf(x/df/(SSE/dfe),df,dfe) for x in (a,bb,c)]))

print('\n== 平衡数据对照 ==')
# balanced: 2 records per cell, take first 2 of each cell (pad cell (1,3))
yb=np.array([214.,229.,236.,244.,251.,247.,198.,207.,219.,226.,233.,241.])
hb=np.array([1,1,1,1,1,1,2,2,2,2,2,2]); tb=np.array([1,1,2,2,3,3,1,1,2,2,3,3])
nb=12
ob=np.ones((nb,1))
Hb=np.array([[1.0 if hb[i]==l else 0. for l in [1,2]] for i in range(nb)])
Tb=np.array([[1.0 if tb[i]==l else 0. for l in [1,2,3]] for i in range(nb)])
cb=[(a,q) for a in [1,2] for q in [1,2,3]]
HTb=np.array([[1.0 if (hb[i],tb[i])==c else 0. for c in cb] for i in range(nb)])
def Rb(cols):
    M=np.hstack(cols); P=M@np.linalg.pinv(M.T@M)@M.T; return yb@P@yb
Rm=Rb([ob]); Rmh=Rb([ob,Hb]); Rmt=Rb([ob,Tb]); Rmht=Rb([ob,Hb,Tb]); Rf=Rb([ob,Hb,Tb,HTb])
print('平衡：R(h|mu)=%.6f  R(h|mu,t)=%.6f  (相等? %s)'%(Rmh-Rm,Rmht-Rmt,abs((Rmh-Rm)-(Rmht-Rmt))<1e-9))
print('平衡：R(t|mu)=%.6f  R(t|mu,h)=%.6f  (相等? %s)'%(Rmt-Rm,Rmht-Rmh,abs((Rmt-Rm)-(Rmht-Rmh))<1e-9))
