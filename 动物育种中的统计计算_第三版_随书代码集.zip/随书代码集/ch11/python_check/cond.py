# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 cond.py    依赖：mpmath, numpy
"""Numerical stability: normal equations vs QR vs SVD; centering/scaling."""
import numpy as np, mpmath as mp
warnings=None
np.set_printoptions(precision=6, suppress=True, linewidth=220)
mp.mp.dps=60

# ---- 1. kappa(X'X)=kappa(X)^2 在算例上 ----
from data import X as X0, y as y0, n as n0, herd, treat
one=np.ones((n0,1))
He=np.array([[1.0] if herd[i]==1 else [-1.0] for i in range(n0)])
Te=np.array([[1.,0.] if treat[i]==1 else ([0.,1.] if treat[i]==2 else [-1.,-1.]) for i in range(n0)])
Xe=np.hstack([one,He,Te])
sv=np.linalg.svd(Xe,compute_uv=False)
kX=sv.max()/sv.min(); kA=np.linalg.cond(Xe.T@Xe)
print('== 算例（效应编码，满秩）==')
print('奇异值 =',np.round(sv,6))
print('kappa(X)=%.6f  kappa(X)^2=%.6f  kappa(X\'X)=%.6f  比值=%.10f'%(kX,kX**2,kA,kA/kX**2))

# ---- 2. 病态算例：日龄的多项式回归 ----
rng=np.random.default_rng(11)
m=40
age=np.linspace(200.,400.,m)                 # 日龄
beta_true={}
def build(deg, mode='raw'):
    if mode=='raw':
        return np.vander(age, deg+1, increasing=True)
    if mode=='center':
        a=age-age.mean(); return np.vander(a, deg+1, increasing=True)
    if mode=='std':
        a=(age-age.mean())/age.std(ddof=0); return np.vander(a, deg+1, increasing=True)
    if mode=='legendre':
        t=2*(age-age.min())/(age.max()-age.min())-1
        return np.polynomial.legendre.legvander(t,deg)
print('\n== 条件数：日龄多项式设计矩阵（n=%d，日龄 %.0f–%.0f）=='%(m,age.min(),age.max()))
print('%4s %14s %14s %14s %14s'%('阶数','原始 age','中心化','标准化','Legendre'))
for deg in [1,2,3,4,5,6]:
    ks=[np.linalg.cond(build(deg,mo)) for mo in ['raw','center','std','legendre']]
    print('%4d %14.4e %14.4e %14.4e %14.4e'%(deg,*ks))

# ---- 3. 三种解法的误差 ----
def refsol(Xm,ym):
    Xs=mp.matrix([[mp.mpf(float(v)) for v in row] for row in Xm])
    ys=mp.matrix([mp.mpf(float(v)) for v in ym])
    A=Xs.T*Xs; bb=Xs.T*ys
    return np.array([float(v) for v in mp.lu_solve(A,bb)])
def solve_ne_chol(Xm,ym):
    A=Xm.T@Xm; bb=Xm.T@ym
    try:
        Lc=np.linalg.cholesky(A)
        z=np.linalg.solve(Lc,bb); return np.linalg.solve(Lc.T,z), 'ok'
    except np.linalg.LinAlgError:
        return None,'Cholesky 失败'
def solve_ne_lu(Xm,ym):
    A=Xm.T@Xm; bb=Xm.T@ym
    try: return np.linalg.solve(A,bb),'ok'
    except np.linalg.LinAlgError: return None,'LU 失败'
def solve_qr(Xm,ym):
    Q,Rm=np.linalg.qr(Xm); return np.linalg.solve(Rm,Q.T@ym),'ok'
def solve_svd(Xm,ym):
    return np.linalg.lstsq(Xm,ym,rcond=None)[0],'ok'

print('\n== 同一问题的四种解法（y=X beta_true，beta_true 全 1，无噪声）==')
print('%4s %12s %12s %14s %14s %14s %14s'%('阶数','kappa(X)','kappa(X\'X)','正规+Chol','正规+LU','QR','SVD'))
for deg in [2,3,4,5,6]:
    Xm=build(deg,'raw'); bt=np.ones(deg+1); ym=Xm@bt
    ref=refsol(Xm,ym)
    kx=np.linalg.cond(Xm); ka=np.linalg.cond(Xm.T@Xm)
    out=[]
    for f in [solve_ne_chol,solve_ne_lu,solve_qr,solve_svd]:
        s,st=f(Xm,ym)
        out.append('%.3e'%(np.linalg.norm(s-ref)/np.linalg.norm(ref)) if s is not None else st)
    print('%4d %12.3e %12.3e %14s %14s %14s %14s'%(deg,kx,ka,*out))

print('\n== 同一问题、Legendre 基（数学上等价的模型）==')
print('%4s %12s %12s %14s %14s %14s %14s'%('阶数','kappa(X)','kappa(X\'X)','正规+Chol','正规+LU','QR','SVD'))
for deg in [2,3,4,5,6]:
    Xm=build(deg,'legendre'); bt=np.ones(deg+1); ym=Xm@bt
    ref=refsol(Xm,ym)
    kx=np.linalg.cond(Xm); ka=np.linalg.cond(Xm.T@Xm)
    out=[]
    for f in [solve_ne_chol,solve_ne_lu,solve_qr,solve_svd]:
        s,st=f(Xm,ym)
        out.append('%.3e'%(np.linalg.norm(s-ref)/np.linalg.norm(ref)) if s is not None else st)
    print('%4d %12.3e %12.3e %14s %14s %14s %14s'%(deg,kx,ka,*out))
