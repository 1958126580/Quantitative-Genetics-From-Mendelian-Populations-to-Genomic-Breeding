# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 collin.py    依赖：numpy
"""Age vs birth-date collinearity; digits-lost table."""
import numpy as np
np.set_printoptions(precision=6, suppress=True, linewidth=220)
rng=np.random.default_rng(2024)
# 单一测定日：age = measure - birth, 精确共线
birth=np.arange(1,41,dtype=float)*3.0      # 出生日（日序）
meas=np.full(40,400.0)                     # 同一测定日
age=meas-birth
X1=np.column_stack([np.ones(40),age,birth])
print('单一测定日：rank([1,age,birth]) = %d （列数 3）'%np.linalg.matrix_rank(X1))
sv=np.linalg.svd(X1,compute_uv=False); print('  奇异值 =',np.round(sv,6))
# 两个测定日
meas2=np.where(np.arange(40)<20,400.0,430.0)
age2=meas2-birth
X2=np.column_stack([np.ones(40),age2,birth])
print('两个测定日（相差 30 天）：rank = %d  kappa = %.4e'%(np.linalg.matrix_rank(X2),np.linalg.cond(X2)))
print('  corr(age,birth) = %.8f'%np.corrcoef(age2,birth)[0,1])
Xc=np.column_stack([np.ones(40),age2-age2.mean(),birth-birth.mean()])
print('  中心化后 kappa = %.4e'%np.linalg.cond(Xc))
Xs=np.column_stack([np.ones(40),(age2-age2.mean())/age2.std(),(birth-birth.mean())/birth.std()])
print('  标准化后 kappa = %.4e'%np.linalg.cond(Xs))
print('  kappa(X\'X) 原始 = %.4e，标准化 = %.4e'%(np.linalg.cond(X2.T@X2),np.linalg.cond(Xs.T@Xs)))
# 五个测定日
meas5=np.tile([400.,430.,460.,490.,520.],8)
age5=meas5-birth
X5=np.column_stack([np.ones(40),age5,birth])
print('五个测定日：kappa = %.4e  corr = %.6f'%(np.linalg.cond(X5),np.corrcoef(age5,birth)[0,1]))

print('\n== 有效数字损失 ==')
eps=np.finfo(float).eps
print('机器 eps = %.6e，double 约 %.2f 位十进制有效数字'%(eps,-np.log10(eps)))
dat=[(2,2.812e6,7.909e12,2.105e-08,1.849e-11),
     (3,5.409e9,2.926e19,2.571e-04,8.203e-08),
     (4,1.088e13,1.535e24,2.302e-01,8.102e-05),
     (5,2.255e16,1.207e28,1.299e+05,2.123e-01)]
print('%4s %11s %11s %9s %9s %12s %12s'%('阶数','log10 k(X)','log10 k(A)','正规误差','QR误差','正规保留位','QR保留位'))
for d,kx,ka,en,eq in dat:
    print('%4d %11.2f %11.2f %9.2e %9.2e %12.2f %12.2f'%(d,np.log10(kx),np.log10(ka),en,eq,-np.log10(en),-np.log10(eq)))
