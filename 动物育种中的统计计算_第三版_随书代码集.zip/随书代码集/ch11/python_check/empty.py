# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 empty.py    依赖：numpy
"""Empty cell -> non-estimable interaction contrasts."""
import numpy as np
from data import X, y, n, herd, treat
np.set_printoptions(precision=6, suppress=True, linewidth=220)
m=np.ones(n,bool); m[5]=False          # 删除单元 (1,3) 的唯一记录
h2=herd[m]; t2=treat[m]; y2=y[m]; n2=m.sum()
cells=[(a,q) for a in [1,2] for q in [1,2,3]]
Z=np.array([[1.0 if (h2[i],t2[i])==c else 0.0 for c in cells] for i in range(n2)])
print('n=%d 非空单元数=%d rank(Z)=%d'%(n2,sum(Z.sum(0)>0),np.linalg.matrix_rank(Z)))
print('单元记录数 =',Z.sum(0).astype(int))
G=np.linalg.pinv(Z.T@Z); Hb=G@(Z.T@Z); bh=G@(Z.T@y2)
def chk(k,nm):
    k=np.array(k,float); res=np.abs(k@Hb-k).max()
    print('%-42s ||k\'H-k\'||=%.3e  可估=%-5s  取值=%s'%(nm,res,res<1e-8, '%.6f'%(k@bh) if res<1e-8 else '—'))
chk([1,0,0,0,0,0],'$\\mu_{11}$（单元 (1,1) 均值）')
chk([0,0,1,0,0,0],'$\\mu_{13}$（单元 (1,3) 均值，空单元）')
chk([0,0,0,0,0,1],'$\\mu_{23}$')
chk([1,-1,0,0,0,0],'$\\mu_{11}-\\mu_{12}$（场 1 内的处理对比）')
chk([1,0,-1,0,0,0],'$\\mu_{11}-\\mu_{13}$（涉及空单元）')
chk([0,0,0,1,0,-1],'$\\mu_{21}-\\mu_{23}$（场 2 内，可估）')
chk([.5,0,0,.5,0,0],'等权处理 1 边际')
chk([0,0,.5,0,0,.5],'等权处理 3 边际（涉及空单元）')
chk([.5,0,0,.5,0,0],'—')
chk([.5,-.5,0,.5,-.5,0],'等权 $t_1-t_2$（Type III 对比）')
chk([.5,0,-.5,.5,0,-.5],'等权 $t_1-t_3$（Type III 对比，涉及空单元）')
chk([0,0,0,.5,-.5,0],'仅用场 2 的 $t_1-t_3$? ')
chk([1,-1,0,-1,1,0],'交互对比 $\\mu_{11}-\\mu_{12}-\\mu_{21}+\\mu_{22}$')
chk([0,1,-1,0,-1,1],'交互对比 $\\mu_{12}-\\mu_{13}-\\mu_{22}+\\mu_{23}$（涉及空单元）')
print('\n可估函数空间维数 =',np.linalg.matrix_rank(Z.T),' = 非空单元数')
# 主效应模型仍连通
Xa=np.hstack([np.ones((n2,1)),
              np.array([[1.0 if h2[i]==l else 0. for l in [1,2]] for i in range(n2)]),
              np.array([[1.0 if t2[i]==l else 0. for l in [1,2,3]] for i in range(n2)])])
print('可加模型（无交互）下 rank(X)=%d，t1-t3 仍可估：'%np.linalg.matrix_rank(Xa))
Ga=np.linalg.pinv(Xa.T@Xa); k=np.array([0,0,0,1.,0,-1.])
print('  ||k\'H-k\'|| = %.3e  取值 = %.6f'%(np.abs(k@(Ga@(Xa.T@Xa))-k).max(), k@(Ga@(Xa.T@y2))))
