# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 estim.py    依赖：numpy
"""Estimability: three equivalent criteria, checked numerically on the running example."""
import numpy as np
from data import X, y, A, b, COLS, n, p, r, herd, treat
np.set_printoptions(precision=6, suppress=True, linewidth=220)
Gmp=np.linalg.pinv(A); Hb=Gmp@A
def sub_ginv(I,J):
    G=np.zeros((p,p)); G[np.ix_(J,I)]=np.linalg.inv(A[np.ix_(I,J)]); return G
G2=sub_ginv([0,1,3,4],[0,1,3,4]); G3=sub_ginv([0,1,3,4],[0,1,4,5])
rX=np.linalg.matrix_rank(X)
bhat=Gmp@b; SSE=y@y-bhat@b; sig2=SSE/(n-r)

FUN=[("$\\mu$",              [1,0,0,0,0,0]),
     ("$h_1$",               [0,1,0,0,0,0]),
     ("$t_2$",               [0,0,0,0,1,0]),
     ("$\\mu+h_1$",          [1,1,0,0,0,0]),
     ("$\\mu+h_1+t_1$",      [1,1,0,1,0,0]),
     ("$h_1-h_2$",           [0,1,-1,0,0,0]),
     ("$t_1-t_3$",           [0,0,0,1,0,-1]),
     ("$t_1-2t_2+t_3$",      [0,0,0,1,-2,1]),
     ("$h_1+h_2$",           [0,1,1,0,0,0]),
     ("$\\mu+h_1+\\bar t$",  [1,1,0,1/3,1/3,1/3]),
     ("$\\mu+\\bar h+t_1$",  [1,.5,.5,1,0,0]),
     ("$h_1-t_1$",           [0,1,0,-1,0,0]),
     ("$2\\mu+h_1+h_2$",     [2,1,1,0,0,0]),
     ]
print('%-24s %11s %11s %11s %6s %11s %11s' % ('k\'β','判据A残差','判据B(MP)','判据B(置零)','秩判据','k\'β̂','s.e.'))
for nm,kk in FUN:
    k=np.array(kk,float)
    # A: k in C(X') ->  ||k - X' (X')^+ k||   via projection onto row space
    P=np.linalg.pinv(X)@X  # projector onto C(X')
    resA=np.abs(P@k-k).max()
    resB=np.abs(k@Hb-k).max()
    resC=np.abs(k@(G2@A)-k).max()
    rk=np.linalg.matrix_rank(np.vstack([X.T.T, k.reshape(1,-1)])) if False else np.linalg.matrix_rank(np.vstack([X, k.reshape(1,-1)]))
    est=resB<1e-8
    v=k@bhat
    se=np.sqrt(k@Gmp@k*sig2) if est else np.nan
    print('%-24s %11.2e %11.2e %11.2e %3d/%d %11.5f %11.5f' % (nm,resA,resB,resC,rk,rX,v,se))
print('\nrank(X)=%d  n=%d  sigma2hat=%.6f'%(rX,n,sig2))
# variance invariance
print('\n== k\'G k 对广义逆的不变性（可估函数）==')
for nm,kk in FUN:
    k=np.array(kk,float)
    if np.abs(k@Hb-k).max()>1e-8: continue
    v=[k@G@k for G in [Gmp,G2,G3]]
    print('%-24s %12.8f %12.8f %12.8f  极差 %.2e'%(nm,v[0],v[1],v[2],max(v)-min(v)))
print('\n== 不可估函数的 k\'Gk（无意义，随广义逆变化）==')
for nm,kk in FUN:
    k=np.array(kk,float)
    if np.abs(k@Hb-k).max()<=1e-8: continue
    v=[k@G@k for G in [Gmp,G2,G3]]
    print('%-24s %12.8f %12.8f %12.8f  极差 %.4f'%(nm,v[0],v[1],v[2],max(v)-min(v)))

# 可估函数空间与可估对比空间的维数
print('\n== 空间维数 ==')
print('可估函数空间 R(X\') 的维数 =', np.linalg.matrix_rank(X.T))
# contrasts: k_mu=0, sum over herd part =0, sum over treat part =0
B=[]
for v in np.eye(p):
    pass
M=[]
M.append([1,0,0,0,0,0]); M.append([0,1,1,0,0,0]); M.append([0,0,0,1,1,1])
M=np.array(M,float)
Nc=np.linalg.svd(M)[2][3:].T    # null space of M -> contrasts
print('对比空间维数 =', Nc.shape[1])
# estimable contrasts: intersect null(M) with R(X')
Pr=np.linalg.pinv(X)@X
Z=Pr@Nc
print('可估对比空间维数 =', np.linalg.matrix_rank(Z), ' (=(2-1)+(3-1)=3)')
print('全部对比是否都可估？', np.abs(Pr@Nc-Nc).max()<1e-10)
