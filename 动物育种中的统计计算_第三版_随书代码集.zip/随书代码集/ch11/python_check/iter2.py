# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 iter2.py    依赖：numpy
import numpy as np, warnings
warnings.filterwarnings('ignore')
from data import X, y, A, b, n, p, r, herd, treat
np.set_printoptions(precision=6, suppress=True, linewidth=220)

def rho(M): return max(abs(np.linalg.eigvals(M)))
def diag_dom(M):
    return all(M[i,i] > sum(abs(M[i,j]) for j in range(M.shape[0]) if j!=i) for i in range(M.shape[0]))
def spd(M): return np.allclose(M,M.T) and np.all(np.linalg.eigvalsh(M)>0)
def mats(M):
    D=np.diag(np.diag(M)); L=np.tril(M,-1); U=np.triu(M,1); return D,L,U
def run(M,v,omega,tol=1e-10,maxit=20000,method='sor'):
    N=M.shape[0]; x=np.zeros(N); nb=np.linalg.norm(v)
    for k in range(1,maxit+1):
        if method=='jacobi':
            x=x+omega*(v-M@x)/np.diag(M)
        else:
            for i in range(N):
                s=M[i,:]@x-M[i,i]*x[i]
                x[i]=(1-omega)*x[i]+omega*(v[i]-s)/M[i,i]
        rr=np.linalg.norm(v-M@x)/nb
        if not np.isfinite(rr) or rr>1e12: return None,x
        if rr<tol: return k,x
    return None,x

# 系统 1: 置零法约化正规方程
keep=[0,1,3,4]; A1=A[np.ix_(keep,keep)]; b1=b[keep]
# 系统 2: 效应编码 (和为零)
one=np.ones((n,1))
He=np.array([[1.0] if herd[i]==1 else [-1.0] for i in range(n)])
Te=np.array([[1.,0.] if treat[i]==1 else ([0.,1.] if treat[i]==2 else [-1.,-1.]) for i in range(n)])
Xe=np.hstack([one,He,Te]); A2=Xe.T@Xe; b2=Xe.T@y
# 系统 3,4: A1 + lambda I  (MME 风格)
SYS=[('置零法约化正规方程 $\\mathbf A_r$',A1,b1),
     ('效应编码（和为零）$\\mathbf X_e\'\\mathbf X_e$',A2,b2),
     ('$\\mathbf A_r+5\\mathbf I$',A1+5*np.eye(4),b1),
     ('$\\mathbf A_r+20\\mathbf I$',A1+20*np.eye(4),b1)]
print('%-40s %6s %6s %9s %9s %9s'%('系统','对角占优','SPD','kappa','rho_J','rho_GS'))
for nm,M,v in SYS:
    D,L,U=mats(M)
    rJ=rho(-np.linalg.solve(D,L+U)); rG=rho(-np.linalg.solve(D+L,U))
    ev=np.linalg.eigvalsh(M)
    print('%-40s %6s %6s %9.4f %9.6f %9.6f'%(nm,diag_dom(M),spd(M),ev.max()/ev.min(),rJ,rG))
print()
print('%-40s %8s %8s %8s %8s %8s'%('系统','Jacobi','GS','SOR最优ω','SOR次数','理论ω'))
ROWS=[]
for nm,M,v in SYS:
    D,L,U=mats(M)
    rJ=rho(-np.linalg.solve(D,L+U))
    kJ,_=run(M,v,1.0,method='jacobi'); kG,_=run(M,v,1.0)
    best=(10**9,None)
    for om in np.arange(0.50,1.99,0.01):
        k,_=run(M,v,round(om,2))
        if k is not None and k<best[0]: best=(k,round(om,2))
    wth=2/(1+np.sqrt(1-rJ**2)) if rJ<1 else float('nan')
    print('%-40s %8s %8s %8.2f %8d %8.4f'%(nm,kJ if kJ else '发散',kG,best[1],best[0],wth))
    ROWS.append((nm,kJ,kG,best[1],best[0],wth,rJ))
print()
print('A2 =\n',A2.astype(int)); print('b2 =',b2)
print('A2 解 =',np.round(np.linalg.solve(A2,b2),6))
print('A1 解 =',np.round(np.linalg.solve(A1,b1),6))
print('A_r+5I 解 =',np.round(np.linalg.solve(A1+5*np.eye(4),b1),6))
print('A_r+20I 解 =',np.round(np.linalg.solve(A1+20*np.eye(4),b1),6))
# SOR omega 扫描表 (效应编码系统 — Jacobi 收敛)
print('\n== 效应编码系统上的 omega 扫描 ==')
M,v=A2,b2; D,L,U=mats(M)
for om in [0.6,0.8,1.0,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9]:
    k,_=run(M,v,om)
    B=np.linalg.solve(D+om*L,(1-om)*D-om*U)
    print('  omega=%.2f 迭代 %4s rho=%.6f'%(om,k if k else '—',rho(B)))
best=(10**9,None); 
for om in np.arange(0.5,1.99,0.01):
    k,_=run(M,v,round(om,2))
    if k and k<best[0]: best=(k,round(om,2))
print('实测最优 omega=%.2f (%d 次)'%(best[1],best[0]))
rr=[(rho(np.linalg.solve(D+om*L,(1-om)*D-om*U)),om) for om in np.arange(0.5,1.999,0.001)]
print('谱半径最小处 omega=%.3f rho=%.6f'%(min(rr)[1],min(rr)[0]))
rJ=rho(-np.linalg.solve(D,L+U)); print('rho_J=%.6f  Young 公式 omega=%.6f  预测 rho=%.6f'%(rJ,2/(1+np.sqrt(1-rJ**2)),2/(1+np.sqrt(1-rJ**2))-1))
