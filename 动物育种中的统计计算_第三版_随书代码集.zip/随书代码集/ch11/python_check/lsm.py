# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 lsm.py    依赖：numpy, scipy
"""LSMeans vs arithmetic means on the running example."""
import numpy as np
from data import X, y, A, b, n, p, r, herd, treat
Gmp=np.linalg.pinv(A); bhat=Gmp@b
SSE=y@y-bhat@b; sig2=SSE/(n-r)
print('SSE=%.6f sigma2=%.6f'%(SSE,sig2))
print('\n== 处理的算术均值 vs 最小二乘均值 ==')
print('%-6s %4s %12s %12s %9s %9s'%('处理','n','算术均值','LSM','s.e.(LSM)','差'))
lsm={}
for t in [1,2,3]:
    k=np.zeros(p); k[0]=1; k[1]=k[2]=0.5; k[2+t]=1
    v=k@bhat; se=np.sqrt(k@Gmp@k*sig2); am=y[treat==t].mean(); lsm[t]=v
    print('%-6d %4d %12.6f %12.6f %9.4f %9.4f'%(t,(treat==t).sum(),am,v,se,am-v))
print('\n== 场的算术均值 vs 最小二乘均值 ==')
for hh in [1,2]:
    k=np.zeros(p); k[0]=1; k[hh]=1; k[3:]=1/3
    v=k@bhat; se=np.sqrt(k@Gmp@k*sig2); am=y[herd==hh].mean()
    print('场%d n=%d 算术=%.6f LSM=%.6f s.e.=%.4f 差=%.4f'%(hh,(herd==hh).sum(),am,v,se,am-v))
print('\n== 处理对比 ==')
for a,bq in [(1,2),(1,3),(2,3)]:
    k=np.zeros(p); k[2+a]=1; k[2+bq]=-1
    v=k@bhat; se=np.sqrt(k@Gmp@k*sig2); tt=v/se
    am=y[treat==a].mean()-y[treat==bq].mean()
    from scipy import stats
    pv=2*stats.t.sf(abs(tt), n-r)
    print('t%d-t%d: LSM差=%.6f s.e.=%.4f t=%.4f p=%.5f | 算术均值差=%.6f'%(a,bq,v,se,tt,pv,am))
print('\n== 为什么不同：各处理的场分布 ==')
for t in [1,2,3]:
    w=[( (treat==t)&(herd==hh) ).sum() for hh in [1,2]]
    print('处理%d: 场1 %d 条, 场2 %d 条, 场1占比 %.4f'%(t,w[0],w[1],w[0]/sum(w)))
print('场效应差 h1-h2 = %.6f'%(np.array([0,1,-1,0,0,0.])@bhat))
# 手算验证: 算术均值 = LSM + (场1占比-0.5)*(h1-h2)
d=np.array([0,1,-1,0,0,0.])@bhat
for t in [1,2,3]:
    w1=((treat==t)&(herd==1)).sum(); nt=(treat==t).sum()
    pred=lsm[t]+(w1/nt-0.5)*d
    print('处理%d: LSM+(p1-0.5)(h1-h2)=%.6f  算术均值=%.6f  差=%.2e'%(t,pred,y[treat==t].mean(),pred-y[treat==t].mean()))
