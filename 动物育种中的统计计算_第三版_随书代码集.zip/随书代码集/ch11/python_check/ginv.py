# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 11 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ginv.py    依赖：numpy
"""Generalized-inverse constructions and the solutions they give (final)."""
import numpy as np
from data import X, y, A, b, COLS, n, p, r
np.set_printoptions(precision=6, suppress=True, linewidth=220)

def pen(G, A, tol=1e-7):
    return ''.join(d for d,ok in zip('1234',[np.abs(A@G@A-A).max()<tol, np.abs(G@A@G-G).max()<tol,
        np.abs((A@G).T-A@G).max()<tol, np.abs((G@A).T-G@A).max()<tol]) if ok)

def sub_ginv(I, J):
    G = np.zeros((p,p)); G[np.ix_(J,I)] = np.linalg.inv(A[np.ix_(I,J)]); return G

Gmp  = np.linalg.pinv(A)                       # (1) Moore-Penrose
Grf  = sub_ginv([0,1,3,4],[0,1,4,5])           # (2) reflexive, non-symmetric
Gz1  = sub_ginv([0,1,3,4],[0,1,3,4])           # (3) zeroing h2=0,t3=0
Gz2  = sub_ginv([0,2,4,5],[0,2,4,5])           # (4) zeroing h1=0,t1=0
Gnr  = Gz1 + (np.eye(p) - Gz1@A)               # (5) non-reflexive
C = np.zeros((2,p)); C[0,[1,2]]=1.; C[1,[3,4,5]]=1.
bzc = np.linalg.solve(np.block([[A,C.T],[C,np.zeros((2,2))]]), np.concatenate([b,np.zeros(2)]))[:p]

NAMES = ['Moore–Penrose 逆 $\\mathbf A^+$','反射广义逆（非对称）','置零法：$h_2=0,\\,t_3=0$',
         '置零法：$h_1=0,\\,t_1=0$','非反射广义逆','和为零约束解']
GS    = [Gmp,Grf,Gz1,Gz2,Gnr]
BET   = [G@b for G in GS] + [bzc]

KS = [("$\\mu+h_1+t_1$", [1,1,0,1,0,0]),
      ("$h_1-h_2$",      [0,1,-1,0,0,0]),
      ("$t_1-t_2$",      [0,0,0,1,-1,0]),
      ("$t_1-t_3$",      [0,0,0,1,0,-1]),
      ("$t_1-2t_2+t_3$", [0,0,0,1,-2,1]),
      ("LSM$_{h_1}$",    [1,1,0,1/3,1/3,1/3]),
      ("LSM$_{t_1}$",    [1,.5,.5,1,0,0]),
      ("总均值 $\\mu+\\bar h+\\bar t$",[1,.5,.5,1/3,1/3,1/3])]
NE = [("$\\mu$",[1,0,0,0,0,0]),("$h_1$",[0,1,0,0,0,0]),("$t_1$",[0,0,0,1,0,0]),
      ("$\\mu+h_1$",[1,1,0,0,0,0]),("$h_1+h_2$",[0,1,1,0,0,0])]

if __name__ == '__main__':
    print('== 表：六组解 ==')
    for nm,G in zip(NAMES,GS):
        print('%-30s Penrose %-5s rank(G)=%d  对称=%s' % (nm,pen(G,A),np.linalg.matrix_rank(G),np.abs(G-G.T).max()<1e-9))
    print()
    print('%-30s %s |%10s' % ('解','  '.join('%11s'%c for c in COLS),'||b||'))
    for nm,bb in zip(NAMES,BET):
        print('%-30s %s |%10.4f' % (nm,'  '.join('%11.4f'%v for v in bb),np.linalg.norm(bb)))
    print()
    for nm,bb in zip(NAMES,BET):
        e = y-X@bb; print('%-30s SSE=%.9f' % (nm,e@e))
    print('\n== 可估函数 ==')
    mx=0
    print('%-24s %s | 极差' % ('k\'beta','  '.join('%12s'%s[:12] for s in ['MP','反射','置零A','置零B','非反射','和为零'])))
    for nm,k in KS:
        v=[np.array(k,float)@bb for bb in BET]; d=max(v)-min(v); mx=max(mx,d)
        print('%-24s %s | %.2e' % (nm,'  '.join('%12.6f'%x for x in v),d))
    print('>>> 可估函数取值的最大差 = %.2e' % mx)
    print('\n== 不可估函数 ==')
    for nm,k in NE:
        v=[np.array(k,float)@bb for bb in BET]
        print('%-24s %s | 极差 %.4f' % (nm,'  '.join('%12.4f'%x for x in v),max(v)-min(v)))
