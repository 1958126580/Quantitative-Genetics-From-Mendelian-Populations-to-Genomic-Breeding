# 第 11 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch11/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `anova.py` | 数值复核 | numpy, scipy | 11.7 | `outputs/anova.out` |
| `collin.py` | Age vs birth-date collinearity; digits-lost table. | numpy | 1.8 | `outputs/collin.out` |
| `cond.py` | Numerical stability: normal equations vs QR vs SVD; centering/scaling. | mpmath, numpy | 2.6 | `outputs/cond.out` |
| `empty.py` | Empty cell -> non-estimable interaction contrasts. | numpy | 1.0 | `outputs/empty.out` |
| `estim.py` | Estimability: three equivalent criteria, checked numerically on the running example. | numpy | 1.2 | `outputs/estim.out` |
| `ginv.py` | Generalized-inverse constructions and the solutions they give (final). | numpy | 1.4 | `outputs/ginv.out` |
| `hat.py` | Hat matrix, leverages, estimability criteria, LSMeans. | numpy | 1.5 | `outputs/hat.out` |
| `iod.py` | Iteration on data vs Gauss-Seidel / Jacobi; tridiagonal Young check. | numpy | 5.0 | `outputs/iod.out` |
| `iter.py` | Jacobi / Gauss-Seidel / SOR on the reduced normal equations of the running example. | numpy | 12.9 | `outputs/iter.out` |
| `iter2.py` | 数值复核 | numpy | 10.1 | `outputs/iter2.out` |
| `lsm.py` | LSMeans vs arithmetic means on the running example. | numpy, scipy | 10.2 | `outputs/lsm.out` |
| `mltest.py` | ML bias, F vs LRT equivalence, on the running example. | numpy, scipy | 10.4 | `outputs/mltest.out` |
| `ss.py` | Type I / II / III sums of squares on the unbalanced 2x3 example. | numpy, scipy | 10.6 | `outputs/ss.out` |

公共函数模块（被上列脚本导入，不单独运行）：`data.py`。
