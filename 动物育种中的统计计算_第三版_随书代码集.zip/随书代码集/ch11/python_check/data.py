# -*- coding: utf-8 -*-
"""Chapter 11 running example: 2 herds x 3 treatments, unbalanced, n=14."""
import numpy as np
np.set_printoptions(precision=6, suppress=True, linewidth=200)

# herd (1,2), treat (1,2,3), y = 断奶重 kg
REC = [
    (1,1,214.0),(1,1,229.0),(1,1,221.0),
    (1,2,236.0),(1,2,244.0),
    (1,3,251.0),
    (2,1,198.0),(2,1,207.0),
    (2,2,219.0),(2,2,226.0),(2,2,212.0),
    (2,3,233.0),(2,3,241.0),(2,3,228.0),
]
herd = np.array([r[0] for r in REC]); treat = np.array([r[1] for r in REC])
y = np.array([r[2] for r in REC], float)
n = len(y)

def dummy(v, levels):
    return np.array([[1.0 if vi==l else 0.0 for l in levels] for vi in v])

X = np.hstack([np.ones((n,1)), dummy(herd,[1,2]), dummy(treat,[1,2,3])])   # p=6
COLS = ['mu','h1','h2','t1','t2','t3']
p = X.shape[1]
r = np.linalg.matrix_rank(X)
A = X.T@X ; b = X.T@y

# cell counts
import collections
cnt = collections.Counter(zip(herd,treat))

if __name__ == '__main__':
    print('n =',n,' p =',p,' rank(X) =',r, ' 秩亏 =',p-r)
    print('cells:', {k:cnt[k] for k in sorted(cnt)})
    print('X=\n',X.astype(int))
    print("X'X=\n",A.astype(int))
    print("X'y=",b)
    print("y'y =", y@y, " sum y =", y.sum(), ' mean y=', y.mean())
    for h in [1,2]:
        print('herd',h,'n=',(herd==h).sum(),'mean=',round(y[herd==h].mean(),6))
    for t in [1,2,3]:
        print('treat',t,'n=',(treat==t).sum(),'mean=',round(y[treat==t].mean(),6))
    for h in [1,2]:
        for t in [1,2,3]:
            m = (herd==h)&(treat==t)
            print('cell',h,t,'n=',m.sum(),'mean=',round(y[m].mean(),6),'y=',y[m])
