# 第十一章　线性模型：估计、检验与可估性 —— 配套代码

**所属**：第三篇　线性混合模型的理论与计算　　**对应正文**：第十一章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch11.ipynb` | IJulia 笔记本：7 个代码单元，约 245 行 Julia 代码，穿插与正文对应的说明 |
| `ch11.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 13 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　正规方程的三种装配（正文 §11.2.1）
- 2　可估函数（正文 §11.3）
- 3　ML 对方差的向下偏性（正文式 11.17）
- 4　迭代法（正文 §11.6）
  - 4.1 第二版 `Jacobi` 函数的缺陷复现与修正（勘误 1‑4）
  - 4.2 Jacobi / Gauss–Seidel / SOR 的收敛速度对照
  - 4.3 停机准则：为什么两个条件都要（正文式 11.31）
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 11
```

或在 Jupyter 中打开 `ch11/ch11.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
