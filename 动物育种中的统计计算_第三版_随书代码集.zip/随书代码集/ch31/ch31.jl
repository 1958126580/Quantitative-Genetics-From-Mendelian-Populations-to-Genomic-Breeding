# 本脚本由 tools/nb2jl.py 从同目录的 ch31.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 31

# %% [markdown]
# # 第三十一章　深度学习在动物遗传育种中的应用 —— 配套代码
#
# 本 Notebook 对应第三十一章。
#
# **内容**
#
# 1. **式 (31.3) 的模拟验证**：$n^*=d_{\text{nl}}(1-h^2)/\varepsilon^2$——非线性建模何时划算
# 2. 纯加性结构下"深度学习不可能优于 GBLUP"的数值确认（§31.1.2 限制一）
# 3. **公平比较的完整实现**（§31.1.4 的六条要求）：同一划分、多次重复、$r$ 与 $b_1$、配对检验、计算成本
# 4. 混合策略：线性主干 + 非线性残差（式 31.6）、多核 GBLUP + 深度特征核
# 5. 图像表型的简化案例：重复力、虚假遗传力的陷阱与检验（式 31.7）
# 6. **深度集成的不确定性量化**（式 31.12–31.13）与 BLUP 的 PEV 对照
# 7. 跨群体泛化：深度模型的下降幅度

# %%
using LinearAlgebra, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %%
# 复用第三十章的 MLP 实现（此处重复给出，使本 Notebook 自包含）
# ============ 原理实现：从零的 MLP（正文式 30.10–30.16）============

"""一个全连接层：W (h_out × h_in)、b (h_out)。"""
mutable struct DenseLayer
    W::Matrix{Float64}
    b::Vector{Float64}
    act::Symbol            # :relu / :tanh / :identity
end

"""正文式 (30.35)：He 初始化（ReLU）/ 式 (30.34)：Xavier（tanh）。"""
function DenseLayer(nin::Int, nout::Int, act::Symbol; rng=Random.default_rng())
    s = act === :relu ? sqrt(2/nin) : sqrt(2/(nin + nout))
    DenseLayer(randn(rng, nout, nin) .* s, zeros(nout), act)
end

@inline actfun(z, s::Symbol) = s === :relu ? max(z, 0.0) :
                               s === :tanh ? tanh(z) : z
@inline actgrad(z, a, s::Symbol) = s === :relu ? (z > 0 ? 1.0 : 0.0) :
                                   s === :tanh ? 1 - a^2 : 1.0

"""前向传播，返回 (输出, 每层的 Z 与 A 用于反传)。正文式 (30.14)。"""
function forward(layers::Vector{DenseLayer}, X::Matrix{Float64})
    A = X                              # h_in × B
    Zs = Matrix{Float64}[]; As = Matrix{Float64}[X]
    for L in layers
        Z = L.W*A .+ L.b
        A = actfun.(Z, L.act)
        push!(Zs, Z); push!(As, A)
    end
    return A, Zs, As
end

"""反向传播（平方损失），返回梯度。正文式 (30.10)、(30.15)、(30.16)。"""
function backward(layers::Vector{DenseLayer}, Zs, As, Y::Matrix{Float64})
    Lnum = length(layers); B = size(Y, 2)
    gW = [zeros(size(L.W)) for L in layers]
    gb = [zeros(size(L.b)) for L in layers]
    # 输出层：dL/dA = 2(A - Y)/B，再逐元素乘 σ'（式 30.10）
    dA = 2 .* (As[end] .- Y) ./ B
    D  = dA .* actgrad.(Zs[end], As[end], layers[end].act)
    for l in Lnum:-1:1
        gW[l] .= D * As[l]'                       # 式 (30.16)
        gb[l] .= vec(sum(D; dims=2))
        if l > 1                                   # 式 (30.15)
            D = (layers[l].W' * D) .* actgrad.(Zs[l-1], As[l], layers[l-1].act)
        end
    end
    return gW, gb
end

mse_loss(P, Y) = sum(abs2, P .- Y)/size(Y, 2)

"""把全部参数展平成一个向量（用于数值梯度校验）。"""
function flatten_params(layers)
    v = Float64[]
    for L in layers; append!(v, vec(L.W)); append!(v, L.b); end
    return v
end
function set_params!(layers, v)
    k = 1
    for L in layers
        nW = length(L.W); L.W .= reshape(view(v, k:k+nW-1), size(L.W)); k += nW
        nb = length(L.b); L.b .= view(v, k:k+nb-1); k += nb
    end
    return layers
end
function flatten_grads(gW, gb)
    v = Float64[]
    for (a, b) in zip(gW, gb); append!(v, vec(a)); append!(v, b); end
    return v
end

# %%
# ============ 优化器（正文式 30.19–30.29）============

abstract type Optimizer end

mutable struct SGD <: Optimizer; eta::Float64; end
init_state(::SGD, v) = nothing
step!(o::SGD, theta, g, st) = (theta .-= o.eta .* g; st)

mutable struct Momentum <: Optimizer; eta::Float64; mu::Float64; end
init_state(::Momentum, v) = zeros(length(v))
function step!(o::Momentum, theta, g, st)
    @. st = o.mu*st + g                       # 式 (30.20)
    @. theta -= o.eta*st
    return st
end

mutable struct Adam <: Optimizer
    eta::Float64; b1::Float64; b2::Float64; eps::Float64; t::Int
end
Adam(eta=1e-3; b1=0.9, b2=0.999, eps=1e-8) = Adam(eta, b1, b2, eps, 0)
init_state(::Adam, v) = (zeros(length(v)), zeros(length(v)))
function step!(o::Adam, theta, g, st)
    m, v = st; o.t += 1
    @. m = o.b1*m + (1-o.b1)*g                # 式 (30.23)
    @. v = o.b2*v + (1-o.b2)*g^2              # 式 (30.24)
    mh = m ./ (1 - o.b1^o.t)                  # 式 (30.27)
    vh = v ./ (1 - o.b2^o.t)
    @. theta -= o.eta*mh/(sqrt(vh) + o.eps)   # 式 (30.28)
    return (m, v)
end

mutable struct AdamW <: Optimizer
    eta::Float64; b1::Float64; b2::Float64; eps::Float64; wd::Float64; t::Int
end
AdamW(eta=1e-3; b1=0.9, b2=0.999, eps=1e-8, wd=1e-2) = AdamW(eta, b1, b2, eps, wd, 0)
init_state(::AdamW, v) = (zeros(length(v)), zeros(length(v)))
function step!(o::AdamW, theta, g, st)
    m, v = st; o.t += 1
    @. m = o.b1*m + (1-o.b1)*g
    @. v = o.b2*v + (1-o.b2)*g^2
    mh = m ./ (1 - o.b1^o.t); vh = v ./ (1 - o.b2^o.t)
    @. theta -= o.eta*(mh/(sqrt(vh) + o.eps) + o.wd*theta)   # 式 (30.29)
    return (m, v)
end

# %%
"""小批量训练循环（含早停与 Dropout）。"""
function train_mlp!(layers, Xtr, Ytr, Xva, Yva; opt=AdamW(1e-3),
                    epochs=300, batch=64, dropout=0.0, patience=30,
                    rng=Random.default_rng(), verbose=false)
    theta = flatten_params(layers)
    st = init_state(opt, theta)
    n = size(Xtr, 2)
    best = (Inf, copy(theta), 0)
    hist = NamedTuple[]
    for ep in 1:epochs
        perm = randperm(rng, n)
        for s in 1:batch:n
            idx = perm[s:min(s+batch-1, n)]
            Xb = Xtr[:, idx]; Yb = Ytr[:, idx]
            if dropout > 0                       # 式 (30.39)：inverted dropout
                keep = 1 - dropout
                Xb = Xb .* (rand(rng, size(Xb)...) .< keep) ./ keep
            end
            set_params!(layers, theta)
            P, Zs, As = forward(layers, Xb)
            gW, gb = backward(layers, Zs, As, Yb)
            st = step!(opt, theta, flatten_grads(gW, gb), st)
        end
        set_params!(layers, theta)
        lva = mse_loss(forward(layers, Xva)[1], Yva)
        ltr = mse_loss(forward(layers, Xtr)[1], Ytr)
        push!(hist, (epoch=ep, train=ltr, valid=lva))
        if lva < best[1]
            best = (lva, copy(theta), ep)
        elseif ep - best[3] >= patience
            verbose && @printf("  早停于第 %d 轮（最优第 %d 轮）\n", ep, best[3])
            break
        end
    end
    set_params!(layers, best[2])                 # 恢复最优检查点
    return layers, best, hist
end

# %%
"""模拟基因组数据：线性部分解释 h²-ε²，非线性部分解释 ε²。"""
function sim_geno(n::Int, m::Int, h2::Float64; eps2=0.0, npair=50,
                  rng=Random.default_rng())
    p = 0.05 .+ 0.45 .* rand(rng, m)
    Mg = [Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j]) for i in 1:n, j in 1:m]
    Z = Mg .- 2 .* p'
    alpha = randn(rng, m)
    glin = Z*alpha; glin ./= std(glin)
    gnl = zeros(n)
    if eps2 > 0
        j1 = rand(rng, 1:m, npair); j2 = rand(rng, 1:m, npair); w = randn(rng, npair)
        for k in 1:npair; gnl .+= w[k].*(view(Z,:,j1[k]).*view(Z,:,j2[k])); end
        gnl ./= std(gnl)
    end
    g = sqrt(max(h2-eps2, 0.0)).*glin .+ sqrt(eps2).*gnl
    y = 10.0 .+ g .+ randn(rng, n).*sqrt(1-h2)
    return (y=y, Z=Z, g=g, glin=sqrt(max(h2-eps2,0.0)).*glin,
            gnl=sqrt(eps2).*gnl, p=p, sum2pq=2*sum(p.*(1 .- p)), h2=h2, eps2=eps2)
end

"""GBLUP：返回对测试集的预测。"""
function gblup(D, tr, te; h2=D.h2)
    Ztr = D.Z[tr,:]; G = (Ztr*Ztr')./D.sum2pq
    a = (G + (1-h2)/h2*I) \ (D.y[tr] .- mean(D.y[tr]))
    return (D.Z[te,:]*Ztr')./D.sum2pq*a .+ mean(D.y[tr])
end

"""把基因型标准化成"特征 × 样本"布局（MLP 需要）。"""
function to_features(D, tr)
    mu = vec(mean(D.Z[tr,:]; dims=1)); sd = vec(std(D.Z[tr,:]; dims=1))
    sd[sd .< 1e-12] .= 1.0
    return ((D.Z .- mu') ./ sd')'
end

# %% [markdown]
# ## 1　式 (31.3) 的模拟验证
#
# $$n^*=\frac{d_{\text{nl}}\left(1-h^2\right)}{\varepsilon^2}$$
#
# **实验设计**：固定 $h^2$ 与 $\varepsilon^2$，改变训练样本量 $n$，找出"非线性模型开始优于 GBLUP"的交叉点，与公式预测比较。
#
# 这里用**核岭回归（高斯核）**作为非线性模型——它的有效自由度可以通过带宽控制，且不受优化困难的干扰。

# %%
"""高斯核。"""
function gkernel(A, B, h)
    m = size(A,2)
    sa = vec(sum(abs2, A; dims=2)); sb = vec(sum(abs2, B; dims=2))
    return exp.(-h .* max.((sa .+ sb' .- 2 .*(A*B')) ./ m, 0.0))
end

"""核岭回归的有效自由度 tr(K(K+λI)⁻¹)（正文式 29.8）。"""
df_krr(K, lam) = tr(K*inv(K + lam*I))

"""在给定 (n, ε²) 下比较 GBLUP 与核岭回归。返回 (r_gblup, r_krr, df_nl)。"""
function crossover_experiment(n_tr, eps2; m=300, h2=0.35, n_te=600, hker=0.5, seed=3100)
    D = sim_geno(n_tr + n_te, m, h2; eps2=eps2, rng=Xoshiro(seed))
    tr = 1:n_tr; te = n_tr+1:n_tr+n_te
    pg = gblup(D, tr, te)
    Xf = to_features(D, tr)
    Ktr = gkernel(Xf[:,tr]', Xf[:,tr]', hker)
    Kte = gkernel(Xf[:,te]', Xf[:,tr]', hker)
    lam = (1-h2)/h2*mean(diag(Ktr))
    c = (Ktr + lam*I) \ (D.y[tr] .- mean(D.y[tr]))
    pk = Kte*c .+ mean(D.y[tr])
    # 非线性部分的"有效自由度"：核岭的 df 减去线性部分（用 GBLUP 的 df 近似）
    G = (D.Z[tr,:]*D.Z[tr,:]')./D.sum2pq
    df_lin = tr(G*inv(G + (1-h2)/h2*I))
    return cor(pg, D.g[te]), cor(pk, D.g[te]), max(df_krr(Ktr, lam) - df_lin, 1.0)
end

println("非线性建模的交叉点（h² = 0.35）\n")
for eps2 in (0.02, 0.06, 0.12)
    @printf("ε² = %.2f\n", eps2)
    @printf("  %-10s%-16s%-16s%-14s%-14s\n", "n_tr", "GBLUP r", "核岭 r", "差值", "d_nl")
    dnl_ref = 0.0
    for n_tr in (150, 300, 600, 1200)
        rg, rk, dnl = crossover_experiment(n_tr, eps2)
        dnl_ref = dnl
        @printf("  %-10d%-16.4f%-16.4f%+-14.4f%-14.0f\n", n_tr, rg, rk, rk-rg, dnl)
    end
    @printf("  式 (31.3) 预测的 n* = d_nl(1-h²)/ε² = %.0f\n\n",
            dnl_ref*(1-0.35)/eps2)
end
println("=> ε² 越大、n 越大，非线性模型越可能胜出；与式 (31.3) 的方向一致。")

# %% [markdown]
# ## 2　纯加性结构下的数值确认（§31.1.2 限制一）

# %%
println("纯加性结构（ε² = 0）下，非线性模型不可能优于 GBLUP\n")
@printf("%-10s%-16s%-16s%-16s\n", "n_tr", "GBLUP r", "核岭(h=0.5) r", "MLP r")
for n_tr in (300, 600, 1200)
    D = sim_geno(n_tr + 500, 300, 0.4; eps2=0.0, rng=Xoshiro(3110))
    tr = 1:n_tr; te = n_tr+1:n_tr+500
    pg = gblup(D, tr, te)
    Xf = to_features(D, tr)
    Ktr = gkernel(Xf[:,tr]', Xf[:,tr]', 0.5); Kte = gkernel(Xf[:,te]', Xf[:,tr]', 0.5)
    lam = (1-0.4)/0.4*mean(diag(Ktr))
    c = (Ktr + lam*I) \ (D.y[tr] .- mean(D.y[tr]))
    pk = Kte*c .+ mean(D.y[tr])
    # MLP
    rg_ = Xoshiro(3111)
    ntr2 = round(Int, 0.8*n_tr); trn = tr[1:ntr2]; van = tr[ntr2+1:end]
    Y = reshape(D.y .- mean(D.y[trn]), 1, :)
    layers = [DenseLayer(size(Xf,1), 16, :relu; rng=rg_),
              DenseLayer(16, 1, :identity; rng=rg_)]
    layers, _, _ = train_mlp!(layers, Xf[:,trn], Y[:,trn], Xf[:,van], Y[:,van];
                              opt=AdamW(1e-3; wd=1e-2), epochs=250, batch=64,
                              dropout=0.2, patience=30, rng=rg_)
    pm = vec(forward(layers, Xf[:,te])[1])
    @printf("%-10d%-16.4f%-16.4f%-16.4f\n", n_tr, cor(pg, D.g[te]),
            cor(pk, D.g[te]), cor(pm, D.g[te]))
end
println("\n=> 与正文 §31.1.2 限制一一致：加性结构下 GBLUP 是上界。")

# %% [markdown]
# ## 3　公平比较的完整实现（§31.1.4 的六条要求）

# %%
"""正文第二十四章式 (24.13)：Hotelling–Williams 配对检验。"""
function hotelling_williams(rA, rB, rAB, n)
    R = 1 - rA^2 - rB^2 - rAB^2 + 2*rA*rB*rAB
    rbar = (rA + rB)/2
    t = (rA - rB)*sqrt(((n-1)*(1 + rAB))/(2*((n-1)/(n-3))*R + rbar^2*(1 - rAB)^3))
    return t, 2*ccdf(TDist(n-3), abs(t))
end

"""在一次划分上跑全部方法，返回 (名称 => (预测, 秒))。"""
function run_all(D, tr, te; rng=Random.default_rng())
    out = Pair{String,Tuple{Vector{Float64},Float64}}[]
    tt(f) = (t0 = time_ns(); v = f(); (v, (time_ns()-t0)/1e9))

    v, t = tt(() -> gblup(D, tr, te))
    push!(out, "GBLUP" => (v, t))

    v, t = tt() do                       # 规则 2：GBLUP 也做同等预算的调参
        h2s = range(0.05, 0.9; length=20)
        ntr = length(tr); perm = randperm(rng, ntr)
        folds = [tr[perm[i:5:end]] for i in 1:5]
        best = (Inf, 0.4)
        for h2 in h2s
            e = Float64[]
            for f in folds
                t2 = setdiff(collect(tr), f)
                push!(e, mean((D.y[f] .- gblup(D, t2, f; h2=h2)).^2))
            end
            m = mean(e); m < best[1] && (best = (m, h2))
        end
        gblup(D, tr, te; h2=best[2])
    end
    push!(out, "GBLUP(调参)" => (v, t))

    Xf = to_features(D, tr)
    v, t = tt() do
        Ktr = gkernel(Xf[:,tr]', Xf[:,tr]', 0.5); Kte = gkernel(Xf[:,te]', Xf[:,tr]', 0.5)
        lam = (1-D.h2)/D.h2*mean(diag(Ktr))
        c = (Ktr + lam*I) \ (D.y[tr] .- mean(D.y[tr]))
        Kte*c .+ mean(D.y[tr])
    end
    push!(out, "核岭(RKHS)" => (v, t))

    v, t = tt() do
        ntr2 = round(Int, 0.8*length(tr)); trn = tr[1:ntr2]; van = tr[ntr2+1:end]
        Y = reshape(D.y .- mean(D.y[trn]), 1, :)
        best = (Inf, nothing)
        for (h1, dp) in ((16, 0.2), (32, 0.3), (64, 0.3))     # 规则 2：同等调参预算
            rg = Xoshiro(hash((h1, dp)) % UInt32)
            L = [DenseLayer(size(Xf,1), h1, :relu; rng=rg),
                 DenseLayer(h1, 1, :identity; rng=rg)]
            L, bst, _ = train_mlp!(L, Xf[:,trn], Y[:,trn], Xf[:,van], Y[:,van];
                                   opt=AdamW(1e-3; wd=1e-2), epochs=200, batch=64,
                                   dropout=dp, patience=25, rng=rg)
            bst[1] < best[1] && (best = (bst[1], L))
        end
        vec(forward(best[2], Xf[:,te])[1])
    end
    push!(out, "MLP" => (v, t))

    v, t = tt() do                        # 式 (31.6)：线性主干 + 非线性残差
        pg_tr = gblup(D, tr, tr)          # 注：生产中应使用交叉验证残差
        res = D.y[tr] .- pg_tr
        ntr2 = round(Int, 0.8*length(tr)); trn = 1:ntr2; van = ntr2+1:length(tr)
        Yr = reshape(res, 1, :)
        rg = Xoshiro(555)
        L = [DenseLayer(size(Xf,1), 16, :relu; rng=rg),
             DenseLayer(16, 1, :identity; rng=rg)]
        L, _, _ = train_mlp!(L, Xf[:,tr[trn]], Yr[:,trn], Xf[:,tr[van]], Yr[:,van];
                             opt=AdamW(1e-3; wd=5e-2), epochs=150, batch=64,
                             dropout=0.3, patience=20, rng=rg)
        gblup(D, tr, te) .+ vec(forward(L, Xf[:,te])[1])
    end
    push!(out, "GBLUP+残差网络" => (v, t))
    return out
end

"""规则 4：多次重复；规则 5：报告 r 与 b1 并做配对检验。"""
function fair_comparison(; nrep=6, n=1000, m=300, h2=0.4, eps2=0.10, ntr=700)
    acc = Dict{String,Vector{Float64}}(); b1s = Dict{String,Vector{Float64}}()
    secs = Dict{String,Vector{Float64}}(); preds_last = nothing; gte_last = nothing
    for r in 1:nrep
        D = sim_geno(n, m, h2; eps2=eps2, rng=Xoshiro(3200 + r))
        tr = 1:ntr; te = ntr+1:n                 # 规则 1：所有方法用同一划分
        res = run_all(D, tr, te; rng=Xoshiro(70 + r))
        for (nm, (p, t)) in res
            push!(get!(acc, nm, Float64[]), cor(p, D.g[te]))
            push!(get!(b1s, nm, Float64[]), cov(D.g[te], p)/var(p))
            push!(get!(secs, nm, Float64[]), t)
        end
        preds_last = Dict(nm => p for (nm, (p, _)) in res)
        gte_last = D.g[te]
    end
    return acc, b1s, secs, preds_last, gte_last
end

acc, b1s, secs, plast, glast = fair_comparison(; nrep=5)
println("公平比较（ε² = 0.10，n_tr = 700，5 次重复）\n")
@printf("%-20s%-20s%-18s%-14s\n", "方法", "r（均值±标准差）", "b1（均值）", "秒/次")
for nm in ("GBLUP", "GBLUP(调参)", "核岭(RKHS)", "MLP", "GBLUP+残差网络")
    @printf("%-20s%-20s%-18.3f%-14.2f\n", nm,
            @sprintf("%.4f ± %.4f", mean(acc[nm]), std(acc[nm])),
            mean(b1s[nm]), mean(secs[nm]))
end

println("\n配对检验（对照 GBLUP(调参)，用最后一次重复）：")
base = "GBLUP(调参)"
nv = length(glast)
rB = cor(plast[base], glast)
for nm in ("核岭(RKHS)", "MLP", "GBLUP+残差网络")
    rA = cor(plast[nm], glast); rAB = cor(plast[nm], plast[base])
    t, p = hotelling_williams(rA, rB, rAB, nv)
    @printf("  %-18s Δr = %+.4f ， r_AB = %.3f ， t = %+.2f ， p = %.4f %s\n",
            nm, rA - rB, rAB, t, p, p < 0.05 ? "*" : "")
end
println("\n=> 规则 6：计算成本已在上表给出。若 100 倍计算只换来 0.01 的 r，生产上通常不划算。")

# %% [markdown]
# ## 4　多核 GBLUP：无下行风险的整合（§31.1.5 (c)）
#
# 把"深度特征核"作为**额外的随机效应**，让 REML 决定权重。若特征无用，$\hat\sigma_h^2\to0$，自动退化为标准 GBLUP。

# %%
"""两核模型的 REML（网格搜索，演示用）。"""
function two_kernel_reml(y, K1, K2; grid=range(0.0, 0.9; length=19))
    n = length(y); yc = y .- mean(y)
    best = (-Inf, 0.0, 0.0)
    for w2 in grid, h2t in range(0.1, 0.8; length=15)
        s2g = h2t; s2e = 1 - h2t
        V = s2g*((1-w2).*K1 .+ w2.*K2) + s2e*I
        F = cholesky(Symmetric(V + 1e-8I))
        ll = -0.5*(logdet(F) + dot(yc, F \ yc))
        ll > best[1] && (best = (ll, w2, h2t))
    end
    return best
end

let rng = Xoshiro(3300)
    D = sim_geno(700, 300, 0.4; eps2=0.10, rng=rng)
    tr = 1:500; te = 501:700
    Xf = to_features(D, tr)
    G  = (D.Z*D.Z')./D.sum2pq
    Kg = gkernel(Xf', Xf', 0.5)                 # "非线性特征核"
    G  ./= mean(diag(G)); Kg ./= mean(diag(Kg))
    ll, w2, h2t = two_kernel_reml(D.y[tr], G[tr,tr], Kg[tr,tr])
    @printf("REML 选中的非线性核权重 w₂ = %.2f ， 总遗传力 = %.2f\n", w2, h2t)
    Vt = h2t*((1-w2).*G[tr,tr] .+ w2.*Kg[tr,tr]) + (1-h2t)*I
    a  = Symmetric(Vt) \ (D.y[tr] .- mean(D.y[tr]))
    pmk = h2t*((1-w2).*G[te,tr] .+ w2.*Kg[te,tr])*a .+ mean(D.y[tr])
    pg  = gblup(D, tr, te)
    @printf("GBLUP        ： r = %.4f\n", cor(pg,  D.g[te]))
    @printf("多核 GBLUP   ： r = %.4f\n", cor(pmk, D.g[te]))

    # 无非线性时（ε²=0）：REML 应给非线性核接近 0 的权重
    D0 = sim_geno(700, 300, 0.4; eps2=0.0, rng=Xoshiro(3301))
    Xf0 = to_features(D0, tr)
    G0 = (D0.Z*D0.Z')./D0.sum2pq; Kg0 = gkernel(Xf0', Xf0', 0.5)
    G0 ./= mean(diag(G0)); Kg0 ./= mean(diag(Kg0))
    _, w2b, _ = two_kernel_reml(D0.y[tr], G0[tr,tr], Kg0[tr,tr])
    @printf("\nε² = 0 时 REML 选中的非线性核权重 = %.2f （应接近 0，正文 §31.1.5(c)）\n", w2b)
end

# %% [markdown]
# ## 5　图像表型：重复力与"虚假遗传力"的陷阱（§31.2.2）

# %%
"""正文式 (31.7)：重复力。"""
repeatability(between_var, within_var) = between_var/(between_var + within_var)

"""模拟：AI 提取的表型 = 真表型 + 提取误差。

`family_bias`>0 时提取误差与家系相关（正文 §31.2.2 的陷阱）。
"""
function sim_ai_phenotype(; nfam=60, nper=6, h2=0.35, sigma_extract=0.5,
                            family_bias=0.0, rng=Random.default_rng())
    n = nfam*nper
    fam = repeat(1:nfam, inner=nper)
    a_fam = randn(rng, nfam).*sqrt(h2/2)         # 半同胞家系的家系效应
    u = a_fam[fam] .+ randn(rng, n).*sqrt(h2/2)
    ytrue = u .+ randn(rng, n).*sqrt(1-h2)
    fam_err = randn(rng, nfam).*family_bias
    yai = ytrue .+ fam_err[fam] .+ randn(rng, n).*sigma_extract
    yai2 = ytrue .+ fam_err[fam] .+ randn(rng, n).*sigma_extract   # 第二次"测定"
    return (fam=fam, u=u, ytrue=ytrue, yai=yai, yai2=yai2, nfam=nfam, nper=nper, h2=h2)
end

"""半同胞设计的遗传力估计：h² = 4 × 家系内相关。"""
function h2_halfsib(y, fam, nfam, nper)
    gm = mean(y)
    msb = nper*sum((mean(y[fam .== f]) - gm)^2 for f in 1:nfam)/(nfam-1)
    msw = sum(sum((y[fam .== f] .- mean(y[fam .== f])).^2) for f in 1:nfam)/(nfam*(nper-1))
    s2b = max((msb - msw)/nper, 0.0)
    t = s2b/(s2b + msw)
    return 4t, t
end

println("AI 表型的重复力与遗传力（真 h² = 0.35）\n")
@printf("%-22s%-16s%-18s%-18s\n", "情形", "重复力", "ĥ²(AI 表型)", "ĥ²(真表型)")
for (nm, fb) in ("无家系相关误差"=>0.0, "家系相关误差 0.3"=>0.3, "家系相关误差 0.6"=>0.6)
    D = sim_ai_phenotype(; family_bias=fb, rng=Xoshiro(3400))
    between = var([mean([D.yai[i], D.yai2[i]]) for i in eachindex(D.yai)])
    within  = mean((D.yai .- D.yai2).^2)/2
    rep = repeatability(max(between - within/2, 0.0), within)
    h2a, _ = h2_halfsib(D.yai, D.fam, D.nfam, D.nper)
    h2t, _ = h2_halfsib(D.ytrue, D.fam, D.nfam, D.nper)
    @printf("%-22s%-16.3f%-18.3f%-18.3f\n", nm, rep, h2a, h2t)
end
println("\n=> 家系相关的提取误差**抬高**了 AI 表型的遗传力估计——这就是“虚假遗传力”。")
println("   检验方法：把提取误差（AI 表型 − 人工测量）对家系做方差分析，")
println("   若家系效应显著，说明提取模型的训练集与评估群体存在重叠或结构混淆。")

# %%
# 虚假遗传力的检验：提取误差的家系方差分析
let
    for fb in (0.0, 0.3, 0.6)
        D = sim_ai_phenotype(; family_bias=fb, rng=Xoshiro(3400))
        err = D.yai .- D.ytrue                  # 实践中用 AI 表型 − 人工测量
        _, t = h2_halfsib(err, D.fam, D.nfam, D.nper)
        # 家系效应的 F 检验
        gm = mean(err); nfam = D.nfam; nper = D.nper
        msb = nper*sum((mean(err[D.fam .== f]) - gm)^2 for f in 1:nfam)/(nfam-1)
        msw = sum(sum((err[D.fam .== f] .- mean(err[D.fam .== f])).^2) for f in 1:nfam)/(nfam*(nper-1))
        F = msb/msw; pv = ccdf(FDist(nfam-1, nfam*(nper-1)), F)
        @printf("family_bias = %.1f ： 提取误差的家系内相关 = %.3f ， F = %.2f ， p = %.2e %s\n",
                fb, t, F, pv, pv < 0.05 ? "⚠ 检出" : "✔")
    end
    println("\n=> 这个检验能有效发现虚假遗传力（正文 §31.2.2）。")
end

# %% [markdown]
# ## 6　深度集成的不确定性量化（式 31.12–31.13）与 BLUP 的 PEV 对照

# %%
"""正文式 (31.13)：深度集成的认知不确定性。"""
function deep_ensemble(D, tr, te; M=8, rng=Random.default_rng())
    Xf = to_features(D, tr)
    ntr2 = round(Int, 0.8*length(tr)); trn = tr[1:ntr2]; van = tr[ntr2+1:end]
    Y = reshape(D.y .- mean(D.y[trn]), 1, :)
    P = zeros(M, length(te))
    for k in 1:M
        rg = Xoshiro(4000 + k)
        L = [DenseLayer(size(Xf,1), 16, :relu; rng=rg),
             DenseLayer(16, 1, :identity; rng=rg)]
        L, _, _ = train_mlp!(L, Xf[:,trn], Y[:,trn], Xf[:,van], Y[:,van];
                             opt=AdamW(1e-3; wd=1e-2), epochs=150, batch=64,
                             dropout=0.2, patience=20, rng=rg)
        P[k, :] .= vec(forward(L, Xf[:,te])[1]) .+ mean(D.y[trn])
    end
    return vec(mean(P; dims=1)), vec(var(P; dims=1)), P
end

"""GBLUP 的 PEV 与可靠性（第十二章式 12.14、第二十一章式 21.26）。"""
function gblup_pev(D, tr, te; h2=D.h2)
    Ztr = D.Z[tr,:]; s = D.sum2pq
    Gtt = (Ztr*Ztr')./s; lam = (1-h2)/h2
    Vi = inv(Symmetric(Gtt + lam*I))
    Gte_tr = (D.Z[te,:]*Ztr')./s
    gtt = vec(sum(abs2, D.Z[te,:]; dims=2))./s
    pev = [gtt[i] - dot(view(Gte_tr,i,:), Vi*view(Gte_tr,i,:)) for i in eachindex(te)]
    return max.(pev, 0.0)
end

let rng = Xoshiro(3500)
    D = sim_geno(900, 300, 0.4; eps2=0.08, rng=rng)
    tr = 1:650; te = 651:900
    pm, ve, P = deep_ensemble(D, tr, te; M=8, rng=rng)
    pg = gblup(D, tr, te)
    pev = gblup_pev(D, tr, te)
    errg = (D.g[te] .- pg).^2
    errm = (D.g[te] .- pm).^2
    @printf("深度集成（M = 8）  ： r = %.4f\n", cor(pm, D.g[te]))
    @printf("GBLUP              ： r = %.4f\n", cor(pg, D.g[te]))
    @printf("\n不确定性度量与实际误差的相关（越高越好）：\n")
    @printf("  深度集成方差 vs 实际平方误差 ： %+.4f\n", cor(ve, errm))
    @printf("  GBLUP PEV   vs 实际平方误差 ： %+.4f\n", cor(pev, errg))
    @printf("\n校准检查（把预测按不确定性五等分，看实际误差是否递增）：\n")
    for (nm, unc, err) in (("深度集成", ve, errm), ("GBLUP PEV", pev, errg))
        o = sortperm(unc); k = length(o) ÷ 5
        ms = [mean(err[o[(i-1)*k+1 : min(i*k, end)]]) for i in 1:5]
        @printf("  %-12s 各五分位的平均平方误差： %s %s\n", nm,
                string(round.(ms, digits=4)), issorted(ms) ? "（单调 ✔）" : "（非单调 ⚠）")
    end
    println("\n=> BLUP 的 PEV 有理论保证；深度集成的方差是启发式的，且倾向低估（正文 §31.5.2）。")
end

# %% [markdown]
# ## 7　跨群体泛化（§31.5.3）

# %%
"""构造两个"品种"：共享因果变异但 LD 相位不同。"""
function sim_two_breeds(; n=600, m=300, h2=0.4, rng=Random.default_rng())
    pA = 0.05 .+ 0.45 .* rand(rng, m)
    pB = clamp.(pA .+ 0.25 .* randn(rng, m), 0.02, 0.98)     # 频率漂移
    alpha = randn(rng, m)
    mk(p) = begin
        Mg = [Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j]) for i in 1:n, j in 1:m]
        Z = Mg .- 2 .* p'
        g = Z*alpha; g ./= std(g); g .*= sqrt(h2)
        (Z=Z, g=g, y=10.0 .+ g .+ randn(rng, n).*sqrt(1-h2),
         p=p, sum2pq=2*sum(p.*(1 .- p)), h2=h2)
    end
    return mk(pA), mk(pB)
end

let rng = Xoshiro(3600)
    A, B = sim_two_breeds(; rng=rng)
    trA = 1:450; teA = 451:600
    # 品种内
    pg_in = gblup(A, trA, teA)
    XfA = to_features(A, trA)
    Ktr = gkernel(XfA[:,trA]', XfA[:,trA]', 0.5); Kte = gkernel(XfA[:,teA]', XfA[:,trA]', 0.5)
    lam = (1-A.h2)/A.h2*mean(diag(Ktr))
    c = (Ktr + lam*I) \ (A.y[trA] .- mean(A.y[trA]))
    pk_in = Kte*c .+ mean(A.y[trA])
    # 跨品种：用 A 的训练集预测 B
    ZtrA = A.Z[trA,:]
    a = ((ZtrA*ZtrA')./A.sum2pq + (1-A.h2)/A.h2*I) \ (A.y[trA] .- mean(A.y[trA]))
    pg_x = (B.Z*ZtrA')./A.sum2pq*a
    muA = vec(mean(ZtrA; dims=1)); sdA = vec(std(ZtrA; dims=1)); sdA[sdA .< 1e-12] .= 1
    XB = ((B.Z .- muA') ./ sdA')'
    KteB = gkernel(XB', XfA[:,trA]', 0.5)
    pk_x = KteB*c .+ mean(A.y[trA])
    @printf("%-16s%-18s%-18s%-14s\n", "方法", "品种内 r", "跨品种 r", "下降")
    @printf("%-16s%-18.4f%-18.4f%-14.1f%%\n", "GBLUP", cor(pg_in, A.g[teA]),
            cor(pg_x, B.g), 100*(1 - cor(pg_x, B.g)/cor(pg_in, A.g[teA])))
    @printf("%-16s%-18.4f%-18.4f%-14.1f%%\n", "核岭(RKHS)", cor(pk_in, A.g[teA]),
            cor(pk_x, B.g), 100*(1 - cor(pk_x, B.g)/cor(pk_in, A.g[teA])))
    println("\n=> 非线性模型在分布外的下降幅度通常更大（正文 §31.5.3）——")
    println("   跨群体/跨世代验证是深度模型的**必检项**。")
end

# %% [markdown]
# ## 8　自检汇总

# %%
ok = Bool[]
# Hotelling–Williams：rA = rB 时 t = 0
let (t, p) = hotelling_williams(0.6, 0.6, 0.9, 300)
    push!(ok, check("rA = rB ⇒ t = 0", t, 0.0; tol=1e-12))
end
# 纯加性下 GBLUP 不劣于非线性（多次重复的平均）
let wins = 0, nrep = 4
    for r in 1:nrep
        D = sim_geno(800, 250, 0.4; eps2=0.0, rng=Xoshiro(3700 + r))
        tr = 1:600; te = 601:800
        pg = gblup(D, tr, te)
        Xf = to_features(D, tr)
        Ktr = gkernel(Xf[:,tr]', Xf[:,tr]', 0.5); Kte = gkernel(Xf[:,te]', Xf[:,tr]', 0.5)
        lam = (1-0.4)/0.4*mean(diag(Ktr))
        c = (Ktr + lam*I) \ (D.y[tr] .- mean(D.y[tr]))
        pk = Kte*c .+ mean(D.y[tr])
        wins += cor(pg, D.g[te]) >= cor(pk, D.g[te])
    end
    @printf("纯加性结构下 GBLUP 胜出 %d / %d 次\n", wins, nrep)
    push!(ok, wins >= nrep - 1)
end
# 式 (31.3) 的单调性：ε² 增大时 n* 减小
let dnl = 200.0, h2 = 0.35
    ns = [dnl*(1-h2)/e for e in (0.005, 0.01, 0.02, 0.05)]
    @printf("式 (31.3) 的 n*（ε² = 0.005/0.01/0.02/0.05）： %s\n",
            string(round.(Int, ns)))
    push!(ok, issorted(ns; rev=true))
end
# 重复力的定义
push!(ok, check("重复力定义", repeatability(0.6, 0.4), 0.6; tol=1e-14))
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
