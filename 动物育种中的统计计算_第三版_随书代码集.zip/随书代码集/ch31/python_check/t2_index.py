# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 t2_index.py    依赖：numpy, scipy
"""31.2.6-31.2.7 closed-form tables: repeatability vs heritability ceiling; relative efficiency of
indirect selection (eq. 31.8); selection-index gain from an image trait used as an auxiliary trait."""
import numpy as np, math
from scipy import stats
print('=== Part 1: repeatability r, heritability of mean of k records (eq 8.20)')
print('s = sigma_A^2/(sigma_A^2+sigma_PE^2) = 0.5 ; h2 = s*r')
def h2k(h2, r, k): return k * h2 / (1 + (k - 1) * r)
for r in (0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9):
    h2 = 0.5 * r
    k90 = math.ceil(9 * (1 - r) / r - 1e-12)
    # verify k90 numerically
    kk = 1
    while h2k(h2, r, kk) < 0.9 * 0.5 - 1e-12: kk += 1
    print('r=%.1f  h2max(s=1)=%.2f  h2(1)=%.3f  h2(3)=%.3f  h2(10)=%.3f  ceiling=%.3f  k90=%d (num %d)  accgain 1->3 = %.3f  1->10 = %.3f' % (
        r, r, h2, h2k(h2, r, 3), h2k(h2, r, 10), 0.5, k90, kk, math.sqrt(h2k(h2, r, 3) / h2), math.sqrt(h2k(h2, r, 10) / h2)))
print()
print('same, s=1 (no permanent env): h2=r; h2(k) -> 1')
for r in (0.3, 0.5, 0.7, 0.9):
    print('r=%.1f h2(1)=%.3f h2(3)=%.3f h2(10)=%.3f' % (r, r, h2k(r, r, 3), h2k(r, r, 10)))
print()
print('=== Part 2: RE = r_g h_Y i_Y / (h_X i_X), Y image trait, X target, equal intensity')
combos = [(0.1, 0.2), (0.1, 0.4), (0.1, 0.6), (0.3, 0.2), (0.3, 0.4), (0.3, 0.6)]
for rg in (0.3, 0.5, 0.7, 0.9):
    print('rg=%.1f ' % rg + '  '.join('%.3f' % (rg * math.sqrt(hy) / math.sqrt(hx)) for hx, hy in combos))
print('break-even rg: ' + '  '.join('%.3f' % (math.sqrt(hx / hy)) for hx, hy in combos))
# intensities
for pp in (0.05, 0.1, 0.2, 0.5):
    z = stats.norm.ppf(1 - pp); i = stats.norm.pdf(z) / pp
    print('p=%.2f i=%.3f' % (pp, i))
print()
print('=== Part 3: selection index for A_X')
def idx_acc(Pm, gv, varA):
    b = np.linalg.solve(Pm, gv); return math.sqrt(b @ gv / varA)
hX2, hY2 = 0.30, 0.40
hX, hY = math.sqrt(hX2), math.sqrt(hY2); eX, eY = math.sqrt(1 - hX2), math.sqrt(1 - hY2)
nhs = 20
def scen(rg, re):
    rP = rg * hX * hY + re * eX * eY
    covA = rg * hX * hY  # Cov(A_X, A_Y) with sigma_P = 1
    # scenario 1: own X, own Y
    P1 = np.array([[1, rP], [rP, 1]]); g1 = np.array([hX2, covA])
    r1 = idx_acc(P1, g1, hX2)
    closed = math.sqrt((hX2 + rg**2 * hY2 - 2 * rP * rg * hX * hY) / (1 - rP**2))
    # scenario 2: X not on candidate. sources: half-sib mean X (n), own Y, half-sib mean Y (n)
    t = 0.25
    vXbar = (1 + (nhs - 1) * t * hX2) / nhs
    vYbar = (1 + (nhs - 1) * t * hY2) / nhs
    cXYbar = (rP + (nhs - 1) * t * covA) / nhs
    cYown_Xbar = t * covA
    cYown_Ybar = t * hY2
    P2 = np.array([[vXbar, cYown_Xbar, cXYbar], [cYown_Xbar, 1, cYown_Ybar], [cXYbar, cYown_Ybar, vYbar]])
    g2 = np.array([t * hX2 * 1.0, covA, t * covA])  # Cov(Xbar_hs, A_X)=0.25 sigma_AX^2 ; Cov(Y_own, A_X)=covA ; Cov(Ybar_hs, A_X)=0.25 covA
    r2_sib = idx_acc(P2[:1, :1], g2[:1], hX2)
    r2_ownY = idx_acc(P2[1:2, 1:2], g2[1:2], hX2)
    r2_sib_ownY = idx_acc(P2[:2, :2], g2[:2], hX2)
    r2_all = idx_acc(P2, g2, hX2)
    return rP, r1, closed, r2_sib, r2_ownY, r2_sib_ownY, r2_all
print('h2X=%.2f h2Y=%.2f n_hs=%d ; baseline own X acc = %.4f' % (hX2, hY2, nhs, hX))
for rg in (0.3, 0.5, 0.7, 0.9):
    for re in (0.0, 0.3, 0.6):
        rP, r1, cl, rs, roy, rsoy, rall = scen(rg, re)
        print('rg=%.1f re=%.1f rP=%.3f | S1 ownX+ownY %.4f (closed %.4f) gain %+.4f | S2 sibX %.4f ownY %.4f sibX+ownY %.4f all %.4f gain %+.4f' % (
            rg, re, rP, r1, cl, r1 - hX, rs, roy, rsoy, rall, rall - rs))
# when is gain zero in S1: rg*hY = rP*hX
print()
print('check zero-gain condition: h equal, re=rg')
for rho in (0.5, 0.8):
    h2 = 0.3; h = math.sqrt(h2); e = math.sqrt(1 - h2); rP = rho * h * h + rho * e * e
    P1 = np.array([[1, rP], [rP, 1]]); g1 = np.array([h2, rho * h2])
    print(rho, idx_acc(P1, g1, h2), h)
