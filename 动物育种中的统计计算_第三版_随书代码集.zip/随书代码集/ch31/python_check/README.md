# 第 31 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch31/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `anaA.py` | 数值复核 | numpy, scipy | 1.5 | `outputs/anaA.out` |
| `anaA2.py` | bug rv / rt with SD | numpy | 0.2 | `outputs/anaA2.out` |
| `anaA3.py` | 数值复核 | numpy | 0.2 | `outputs/anaA3.out` |
| `anaA4.py` | average pairwise correlation (across reps) of config rv deviations | numpy, scipy | 1.8 | `outputs/anaA4.out` |
| `anaB.py` | 数值复核 | numpy | 0.1 | `outputs/anaB.out` |
| `anaE.py` | 数值复核 | numpy | 0.2 | `outputs/anaE.out` |
| `bayesr.py` | BayesR / BayesRC Gibbs sampler (ch22 eqs 22.41-22.47). Genotypes standardised (unit variance per SNP). | numpy | 0.1 | `outputs/bayesr.out` |
| `calib.py` | GBLUP with G = ZZ'/sum(2pq) scaled so that var(g) = h2 * mean diag | numpy, sklearn | 10.9 | `outputs/calib.out` |
| `dfA.py` | effective degrees of freedom tr(S) = sum d/(d+lam) for GBLUP (REML lambda) vs the scale-error lambda, same data as simA | numpy, scipy | 8.8 | `outputs/dfA.out` |
| `image_h2.py` | half-sib design: s sires x n progeny; image-derived trait with extraction error | numpy | 0.5 | `outputs/image_h2.out` |
| `numsA.py` | 数值复核 | numpy, scipy | 1.8 | `outputs/numsA.out` |
| `reml_multi.py` | Multi-component AI-REML: V = sum_k theta_k K_k + theta_e I. Fixed effects X (n x p). | numpy, scipy | 0.6 | `outputs/reml_multi.out` |
| `t2_extra.py` | break-even rg with intensity ratio | scipy | 1.2 | `outputs/t2_extra.out` |
| `t2_index.py` | 31.2.6-31.2.7 closed-form tables: repeatability vs heritability ceiling; relative efficiency of | numpy, scipy | 1.5 | `outputs/t2_index.out` |

公共函数模块（被上列脚本导入，不单独运行）：`common.py`。
