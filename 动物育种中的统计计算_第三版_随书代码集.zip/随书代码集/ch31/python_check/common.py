# -*- coding: utf-8 -*-
"""Shared helpers for ch31 expansion simulations."""
import numpy as np
from scipy.optimize import minimize_scalar

def sim_geno(n, m, rng, p=None):
    if p is None:
        p = rng.uniform(0.05, 0.5, m)
    X = rng.binomial(2, p, size=(n, m)).astype(float)
    return X, p

def center(Xtr, Xother_list):
    pf = Xtr.mean(0) / 2
    k = (2 * pf * (1 - pf)).sum()
    return Xtr - 2 * pf, [Xo - 2 * pf for Xo in Xother_list], k

def reml_h2_eig(y, d, U):
    """Single-kernel REML with V = s2 (h2*K + (1-h2) I), K = U diag(d) U'. Intercept only.
    Returns h2 (on the kernel scale: sg2/(sg2+se2)), and s2."""
    n = len(y)
    ys = U.T @ y; xs = U.T @ np.ones(n)
    def negll(h2):
        w = h2 * d + (1 - h2)
        xwx = np.sum(xs * xs / w); xwy = np.sum(xs * ys / w)
        b = xwy / xwx
        r = ys - xs * b
        rwr = np.sum(r * r / w)
        s2 = rwr / (n - 1)
        ll = -0.5 * ((n - 1) * np.log(s2) + np.sum(np.log(w)) + np.log(xwx))
        return -ll
    res = minimize_scalar(negll, bounds=(1e-4, 1 - 1e-4), method='bounded', options={'xatol': 1e-7})
    h2 = res.x
    w = h2 * d + (1 - h2)
    xwx = np.sum(xs * xs / w); b = np.sum(xs * ys / w) / xwx
    s2 = np.sum((ys - xs * b) ** 2 / w) / (n - 1)
    return h2, s2, b

def gblup_fit_eig(y, d, U, lam):
    """GBLUP with kernel K = U diag(d) U' and lambda = se2/sg2; GLS intercept.
    Returns alpha such that g_new = K_new,train @ alpha, and mu."""
    n = len(y)
    ys = U.T @ y; xs = U.T @ np.ones(n)
    w = d + lam
    mu = np.sum(xs * ys / w) / np.sum(xs * xs / w)
    alpha = U @ ((ys - xs * mu) / w)
    return alpha, mu

def williams_t(rA, rB, rAB, n):
    """Hotelling-Williams t for two dependent correlations sharing one variable (eq. 24.13), df = n-3."""
    R = 1 - rA**2 - rB**2 - rAB**2 + 2 * rA * rB * rAB
    rbar = (rA + rB) / 2
    return (rA - rB) * np.sqrt((n - 1) * (1 + rAB) / (2 * (n - 1) / (n - 3) * R + rbar**2 * (1 - rAB)**3))

def cor(a, b):
    return float(np.corrcoef(a, b)[0, 1])

def slope(g, ghat):
    """regression coefficient of g on ghat"""
    c = np.cov(g, ghat)
    return float(c[0, 1] / c[1, 1])
