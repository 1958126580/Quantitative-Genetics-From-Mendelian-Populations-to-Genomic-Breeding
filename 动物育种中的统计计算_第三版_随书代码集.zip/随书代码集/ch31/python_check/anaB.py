# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 anaB.py    依赖：numpy
import json, numpy as np
d = json.load(open('simB_res.json'))
print(len(d))
keys = ['gblup', 'all_cv_w', 'all_cv_w1', 'all_insample_w1', 'cand_cv_w', 'cand_cv_w1', 'cand_insample_w1']
for e2 in (0.0, 0.05, 0.10, 0.20):
    for ntr in (1000, 3000):
        rr = [r for r in d if abs(r['e2'] - e2) < 1e-9 and r['ntr'] == ntr]
        G = np.array([r['gblup']['acc'] for r in rr])
        line = 'e2=%.2f n=%d R=%d GBLUP %.3f' % (e2, ntr, len(rr), G.mean())
        for k in keys[1:]:
            A = np.array([r[k]['acc'] for r in rr]); dd = A - G
            line += ' | %s %.3f (%+.3f se %.3f, >0 %d)' % (k, A.mean(), dd.mean(), dd.std(ddof=1) / np.sqrt(len(dd)), (dd > 0).sum())
        print(line)
        wa = [r['all_cfg']['w'] for r in rr]; wc = [r['cand_cfg']['w'] for r in rr]
        ca = [r['all_cfg']['cor_f_epi'] for r in rr]; cc = [r['cand_cfg']['cor_f_epi'] for r in rr]; ci = [r['cand_cfg']['cor_fin_epi'] for r in rr]
        print('   w all', wa, ' w cand', wc)
        if e2 > 0:
            print('   cor(f, g_epi): all %.3f cand %.3f cand-insample %.3f' % (np.mean(ca), np.mean(cc), np.mean(ci)))
        Ga = np.array([r['gblup']['acc_add'] for r in rr]); Ca = np.array([r['cand_cv_w']['acc_add'] for r in rr])
        print('   acc vs additive part: GBLUP %.3f  cand_cv_w %.3f (diff %+.3f)' % (Ga.mean(), Ca.mean(), (Ca - Ga).mean()))
        sd_in = np.mean([r['cand_cfg']['sd_fin'] for r in rr]); sd_oof = np.mean([r['cand_cfg']['sd_f'] for r in rr])
        print('   sd f: oof %.3f insample %.3f ; h2hat %.3f' % (sd_oof, sd_in, np.mean([r['h2hat'] for r in rr])))
