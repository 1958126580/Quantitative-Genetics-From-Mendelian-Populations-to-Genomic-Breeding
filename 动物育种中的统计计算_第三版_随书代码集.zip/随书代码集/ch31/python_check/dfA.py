# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 dfA.py    依赖：numpy
# effective degrees of freedom tr(S) = sum d/(d+lam) for GBLUP (REML lambda) vs the scale-error lambda, same data as simA
import numpy as np, json
from common import *
d = {r['rep']: r for r in json.load(open('simA_res_r0_1.json')) + json.load(open('simA_res_r2_10.json')) + json.load(open('simA_res_r11_19.json'))}
m, nq, h2, ntr, nv, nte = 1000, 200, 0.40, 1000, 200, 2000
out = []
for rep in range(20):
    rng = np.random.default_rng(31106 + rep)
    X, p = sim_geno(ntr + nv + nte, m, rng)
    Ztr, _, k = center(X[:ntr], [])
    ev = np.maximum(np.linalg.eigvalsh(Ztr @ Ztr.T / k), 0)
    h2h = d[rep]['h2hat']; lam = (1 - h2h) / h2h; lamb = lam / k
    assert abs(k - d[rep]['k2pq']) < 1e-6
    out.append((np.sum(ev / (ev + lam)), np.sum(ev / (ev + lamb)), np.sum(ev > 1e-8)))
o = np.array(out); print('df REML mean %.1f  df bug mean %.1f  rank mean %.1f' % tuple(o.mean(0)))
