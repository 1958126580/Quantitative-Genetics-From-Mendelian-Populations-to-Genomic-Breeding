# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 anaA4.py    依赖：numpy, scipy
import json, numpy as np
from scipy import integrate, stats
d = json.load(open('simA_res_r0_1.json')) + json.load(open('simA_res_r2_10.json')) + json.load(open('simA_res_r11_19.json'))
allrv = np.array([r['mlp_all_rv'] for r in d])
print('max over configs of mean rv: %.4f ; mean of per-rep max rv: %.4f ; optimism vs best config %.4f' % (allrv.mean(0).max(), allrv.max(1).mean(), allrv.max(1).mean() - allrv.mean(0).max()))
# average pairwise correlation (across reps) of config rv deviations
dev = allrv - allrv.mean(0)
C = np.corrcoef(dev.T); iu = np.triu_indices(24, 1); print('mean corr between configs (across reps) %.3f' % C[iu].mean())
print('SD of rv across reps per config (mean) %.4f' % allrv.std(0, ddof=1).mean())
def emax(K):
    f = lambda x: x * K * stats.norm.pdf(x) * stats.norm.cdf(x) ** (K - 1)
    return integrate.quad(f, -12, 12, limit=200)[0]
for K in (1, 2, 5, 10, 24, 50, 100, 200):
    print('K=%d e_K=%.3f' % (K, emax(K)))
r = 0.30; nv = 200
print('SE(r) at r=0.30 n=200: %.4f' % ((1 - r**2) / np.sqrt(nv - 1)))
for r in (0.30, 0.375):
    print('r=%.3f SE %.4f bound K=24 %.4f' % (r, (1 - r**2) / np.sqrt(nv - 1), (1 - r**2) / np.sqrt(nv - 1) * emax(24)))
