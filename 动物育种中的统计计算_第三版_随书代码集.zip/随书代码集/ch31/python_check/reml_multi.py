# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 reml_multi.py    依赖：numpy, scipy
"""Multi-component AI-REML: V = sum_k theta_k K_k + theta_e I. Fixed effects X (n x p).
Active set for components at the lower bound; backtracking line search on the REML log-likelihood."""
import numpy as np
from scipy.linalg import lapack

def _inv_logdet(V):
    c, info = lapack.dpotrf(V, lower=1)
    if info != 0: raise np.linalg.LinAlgError('not PD')
    logdet = 2 * np.sum(np.log(np.diag(c)))
    Vi, info = lapack.dpotri(c, lower=1)
    Vi = np.tril(Vi) + np.tril(Vi, -1).T
    return Vi, logdet

def _state(th, y, X, Ks):
    V = sum(t * K for t, K in zip(th, Ks))
    Vi, logdetV = _inv_logdet(V)
    ViX = Vi @ X; XtViX = X.T @ ViX
    sign, logdetX = np.linalg.slogdet(XtViX)
    P = Vi - ViX @ np.linalg.solve(XtViX, ViX.T)
    Py = P @ y
    ll = -0.5 * (logdetV + logdetX + y @ Py)
    return ll, P, Py, ViX, XtViX

def reml(y, X, Ks, init=None, maxit=200, tol=1e-9, verbose=False):
    n = len(y); Ks = list(Ks) + [np.eye(n)]
    q = len(Ks); vy = np.var(y); lb = 1e-8 * vy
    th = np.full(q, vy / q) if init is None else np.maximum(np.array(init, float), lb)
    ll, P, Py, ViX, XtViX = _state(th, y, X, Ks)
    for it in range(maxit):
        KPy = [K @ Py for K in Ks]
        sc = np.array([-0.5 * (np.sum(P * K) - Py @ kp) for K, kp in zip(Ks, KPy)])
        PKPy = [P @ kp for kp in KPy]
        AI = np.array([[0.5 * KPy[i] @ PKPy[j] for j in range(q)] for i in range(q)])
        free = ~((th <= lb * 1.0001) & (sc < 0))
        step = np.zeros(q)
        step[free] = np.linalg.solve(AI[np.ix_(free, free)], sc[free])
        accepted = False
        for k in range(20):
            new = np.maximum(th + step, lb)
            try:
                st = _state(new, y, X, Ks)
            except np.linalg.LinAlgError:
                step *= 0.5; continue
            if st[0] >= ll - 1e-12:
                accepted = True; break
            step *= 0.5
        if not accepted:
            break
        dll = st[0] - ll; dth = np.max(np.abs(new - th))
        th = new; ll, P, Py, ViX, XtViX = st
        if verbose: print(it, ll, th)
        if dll < tol and dth < 1e-7 * vy:
            break
    beta = np.linalg.solve(XtViX, ViX.T @ y)
    KPy = [K @ Py for K in Ks]; PKPy = [P @ kp for kp in KPy]
    AI = np.array([[0.5 * KPy[i] @ PKPy[j] for j in range(q)] for i in range(q)])
    cov = np.full((q, q), np.nan)
    fr = th > lb * 1.0001
    cov[np.ix_(fr, fr)] = np.linalg.inv(AI[np.ix_(fr, fr)])
    return dict(theta=th, cov=cov, beta=beta, Py=Py, iters=it + 1, ll=ll,
                beta_cov=np.linalg.inv(XtViX))

def h2_se(th, cov, idx):
    """ratio theta[idx]/sum(theta) and its delta-method SE (components at the bound treated as fixed)."""
    s = th.sum(); r = th[idx] / s
    g = -np.full(len(th), th[idx] / s**2); g[idx] += 1 / s
    ok = ~np.isnan(np.diag(cov))
    return r, float(np.sqrt(g[ok] @ cov[np.ix_(ok, ok)] @ g[ok]))
