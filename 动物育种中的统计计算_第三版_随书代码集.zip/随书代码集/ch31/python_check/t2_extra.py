# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 t2_extra.py    依赖：scipy
import math
from scipy import stats
def inten(p):
    z = stats.norm.ppf(1 - p); return stats.norm.pdf(z) / p
i5, i20 = inten(0.05), inten(0.20)
print('i(0.05)=%.3f i(0.20)=%.3f ratio=%.4f' % (i5, i20, i5 / i20))
for hx2, hy2, rg in ((0.3, 0.4, 0.7), (0.3, 0.4, 0.5), (0.1, 0.4, 0.3), (0.3, 0.6, 0.5)):
    re = rg * math.sqrt(hy2 / hx2)
    print('hX2=%.1f hY2=%.1f rg=%.1f RE(equal i)=%.3f RE(i ratio)=%.3f' % (hx2, hy2, rg, re, re * i5 / i20))
# break-even rg with intensity ratio
for hx2, hy2 in ((0.3, 0.4), (0.3, 0.2), (0.1, 0.2)):
    print('break-even rg with i ratio: hX2=%.1f hY2=%.1f -> %.3f' % (hx2, hy2, math.sqrt(hx2 / hy2) * i20 / i5))
