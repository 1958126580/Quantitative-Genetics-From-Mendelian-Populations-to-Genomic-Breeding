# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 calib.py    依赖：numpy, sklearn
import numpy as np, warnings
from sklearn.neural_network import MLPRegressor
from sklearn.exceptions import ConvergenceWarning
warnings.filterwarnings('ignore', category=ConvergenceWarning)
rng=np.random.default_rng(31031)
n_tr,n_te,m=1500,500,800; h2=0.40
p=rng.uniform(0.05,0.5,m); X=rng.binomial(2,p,size=(n_tr+n_te,m)).astype(float); Z=X-2*p
q=rng.choice(m,200,replace=False); a=np.zeros(m); a[q]=rng.normal(0,1,200)
g=Z@a; g=(g-g.mean())/g.std()*np.sqrt(h2); y=g+rng.normal(0,np.sqrt(1-h2),n_tr+n_te)
tr=np.arange(n_tr); te=np.arange(n_tr,n_tr+n_te)
# GBLUP with G = ZZ'/sum(2pq) scaled so that var(g) = h2 * mean diag
k=(2*p*(1-p)).sum(); G=Z@Z.T/k
sg2=h2/np.mean(np.diag(G)); se2=1-h2
V=G[np.ix_(tr,tr)]*sg2+np.eye(n_tr)*se2
Vi=np.linalg.inv(V)
mu=y[tr].mean()
Gt=G[np.ix_(te,tr)]*sg2
ghat=Gt@Vi@(y[tr]-mu)
pev=np.diag(G[np.ix_(te,te)])*sg2-np.einsum('ij,jk,ik->i',Gt,Vi,Gt)
cov_gblup=np.mean(np.abs(g[te]-ghat)<=1.96*np.sqrt(pev))
print('GBLUP: cor=%.4f  mean PEV=%.4f  mean sq err=%.4f  coverage95=%.3f'%(np.corrcoef(ghat,g[te])[0,1],pev.mean(),np.mean((g[te]-ghat)**2),cov_gblup))
# deep ensemble (5 MLPs, different seeds)
preds=[]
for sd in range(5):
    mdl=MLPRegressor(hidden_layer_sizes=(64,32),alpha=10.0,max_iter=300,early_stopping=True,random_state=100+sd)
    mdl.fit(Z[tr],y[tr]); preds.append(mdl.predict(Z[te]))
P=np.array(preds); mean=P.mean(0); sdv=P.std(0,ddof=1)
# calibrate mean to scale of g (regress g on mean? no - use raw)
cov_ens=np.mean(np.abs(g[te]-mean)<=1.96*sdv)
print('Ensemble: cor=%.4f  mean ens var=%.4f  mean sq err=%.4f  coverage95=%.3f'%(np.corrcoef(mean,g[te])[0,1],np.mean(sdv**2),np.mean((g[te]-mean)**2),cov_ens))
print('ratio actual MSE / ensemble var = %.2f'%(np.mean((g[te]-mean)**2)/np.mean(sdv**2)))
print('ratio actual MSE / PEV = %.2f'%(np.mean((g[te]-ghat)**2)/pev.mean()))
