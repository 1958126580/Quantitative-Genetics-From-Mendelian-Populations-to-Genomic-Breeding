# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 image_h2.py    依赖：numpy
import numpy as np
# half-sib design: s sires x n progeny; image-derived trait with extraction error
rng=np.random.default_rng(20260924)
s,n=100,20; R=400
h2=0.30; sP2=1.0
def anova_h2(y):
    ybar=y.mean(1); gm=y.mean()
    MSB=n*((ybar-gm)**2).sum()/(s-1); MSW=((y-ybar[:,None])**2).sum()/(s*(n-1))
    ss=(MSB-MSW)/n; return 4*ss/(ss+MSW)
out={k:[] for k in ('true','indep','family','random_session','rg_true_image')}
for r in range(R):
    sire=rng.normal(0,np.sqrt(h2/4),s)            # sire effect var = h2/4
    a=sire[:,None]+rng.normal(0,np.sqrt(3*h2/4),(s,n))  # breeding values (sire + MS)
    t=a+rng.normal(0,np.sqrt(1-h2),(s,n))          # true phenotype
    # image extraction error: total error variance 0.30 (relative to sP2=1)
    ve=0.30
    e_ind=rng.normal(0,np.sqrt(ve),(s,n))
    # family-correlated: each family photographed in its own session, session effect var 0.05, rest indep
    vb=0.05
    e_fam=rng.normal(0,np.sqrt(vb),(s,1))+rng.normal(0,np.sqrt(ve-vb),(s,n))
    # randomized sessions: 100 sessions, animals assigned at random (session effect not tied to family)
    sess=rng.integers(0,s,(s,n)); beff=rng.normal(0,np.sqrt(vb),s)
    e_rand=beff[sess]+rng.normal(0,np.sqrt(ve-vb),(s,n))
    out['true'].append(anova_h2(t))
    out['indep'].append(anova_h2(t+e_ind))
    out['family'].append(anova_h2(t+e_fam))
    out['random_session'].append(anova_h2(t+e_rand))
for k in ('true','indep','family','random_session'):
    v=np.array(out[k]); print(f'{k:16s} mean h2={v.mean():.4f} sd={v.std(ddof=1):.4f}')
# theory
print('theory indep: h2*1/(1+ve)=',h2/(1+0.30))
print('theory family: (4*(h2/4+vb))/(1+ve)=',4*(h2/4+0.05)/(1+0.30))
# genetic correlation between image trait and target is 1 here (same genetics), but observed-scale
# repeatability of extraction: cor between two independent extractions of same animal
print('extraction repeatability (1 - ve/(1+ve)) =', 1/(1+0.30))
