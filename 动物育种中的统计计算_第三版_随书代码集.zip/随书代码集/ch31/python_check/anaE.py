# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 anaE.py    依赖：numpy
import json, numpy as np
d = json.load(open('simE_res_r0_9.json')); print('reps', len(d))
T = ['A_val', 'B_3', 'B_10', 'B_30', 'B_100']
print('markers mean %.0f  h2hat %.3f  mlp alpha' % (np.mean([r['n_markers'] for r in d]), np.mean([r['h2hat'] for r in d])), [r['mlp_alpha'] for r in d])
def A(nm, m, f='acc'): return np.array([r[nm][m][f] for r in d])
print('| 目标群体 | F_ST | r_AB | GBLUP | MLP | QTL-on-chip | GBLUP 保留 | MLP 保留 | QTL 保留 | b1 GBLUP | b1 MLP |')
for nm in T:
    fst = np.mean([r[nm]['fst'] for r in d]); rab = np.mean([r[nm]['r_AB'] for r in d])
    g, m, q = A(nm, 'gblup'), A(nm, 'mlp'), A(nm, 'gblup_qtl')
    g0, m0, q0 = A('A_val', 'gblup'), A('A_val', 'mlp'), A('A_val', 'gblup_qtl')
    rg, rm, rq = g / g0, m / m0, q / q0
    dd = rm - rg
    print('%-6s Fst %.3f rAB %.3f | G %.3f M %.3f Q %.3f | ret G %.3f M %.3f Q %.3f | retM-retG %+.3f se %.3f (M<G in %d/10) | M-G %+.3f se %.3f | b1 G %.3f M %.3f Q %.3f | varg %.3f meang %+.3f' % (
        nm, fst, rab, g.mean(), m.mean(), q.mean(), rg.mean(), rm.mean(), rq.mean(), dd.mean(), dd.std(ddof=1) / np.sqrt(10), (dd < 0).sum(),
        (m - g).mean(), (m - g).std(ddof=1) / np.sqrt(10), A(nm, 'gblup', 'b1').mean(), A(nm, 'mlp', 'b1').mean(), A(nm, 'gblup_qtl', 'b1').mean(),
        np.mean([r[nm]['varg'] for r in d]), np.mean([r[nm]['mean_g'] for r in d])))
# ratio of means as alternative
for nm in T:
    print(nm, 'ratio of means G %.3f M %.3f Q %.3f' % (A(nm, 'gblup').mean() / A('A_val', 'gblup').mean(), A(nm, 'mlp').mean() / A('A_val', 'mlp').mean(), A(nm, 'gblup_qtl').mean() / A('A_val', 'gblup_qtl').mean()))
# medians of b1
for nm in T:
    print(nm, 'b1 median G %.3f M %.3f' % (np.median(A(nm, 'gblup', 'b1')), np.median(A(nm, 'mlp', 'b1'))), 'b1 sd G %.3f M %.3f' % (A(nm, 'gblup', 'b1').std(ddof=1), A(nm, 'mlp', 'b1').std(ddof=1)))
