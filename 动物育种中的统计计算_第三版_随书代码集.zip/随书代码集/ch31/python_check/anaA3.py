# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 anaA3.py    依赖：numpy
import json, numpy as np
d = json.load(open('simA_res_r0_1.json')) + json.load(open('simA_res_r2_10.json')) + json.load(open('simA_res_r11_19.json'))
rows = ['gblup_reml'] + ['gblup_h2_%.2f' % h for h in [0.01, 0.05, 0.10, 0.20, 0.40, 0.60, 0.80, 0.95, 0.99]] + ['gblup_bug', 'mlp_honest', 'mlp_leaky']
for k in rows:
    rv = np.array([r[k]['rv'] for r in d]); rt = np.array([r[k]['rt'] for r in d]); b = np.array([r[k]['b1'] for r in d])
    print('%-16s rv %.3f  rt %.3f  b1 median %.3f  mean %.3f' % (k, rv.mean(), rt.mean(), np.median(b), b.mean()))
