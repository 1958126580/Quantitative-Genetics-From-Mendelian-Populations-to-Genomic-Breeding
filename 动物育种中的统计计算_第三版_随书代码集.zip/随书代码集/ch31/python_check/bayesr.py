# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 bayesr.py    依赖：numpy
"""BayesR / BayesRC Gibbs sampler (ch22 eqs 22.41-22.47). Genotypes standardised (unit variance per SNP).
gamma = (0, 1e-4, 1e-3, 1e-2) x sigma_A^2 ; pi^(c) ~ Dirichlet(1) per annotation class c."""
import numpy as np, math

GAM = np.array([0.0, 1e-4, 1e-3, 1e-2])

def bayesrc(y, Z, cls, niter=3000, burn=1000, seed=0, nu=4.0):
    rng = np.random.default_rng(seed)
    n, m = Z.shape
    Zt = np.ascontiguousarray(Z.T)
    zz = np.einsum('ij,ij->i', Zt, Zt)
    C = int(cls.max()) + 1
    vy = float(np.var(y))
    mu = float(np.mean(y)); ycorr = y - mu
    alpha = np.zeros(m); k = np.zeros(m, dtype=int)
    pi = np.tile(np.array([0.5, 0.25, 0.15, 0.10]), (C, 1))
    sA2 = 0.5 * vy; se2 = 0.5 * vy
    SA = 0.5 * vy; Se = 0.5 * vy
    amean = np.zeros(m); nsave = 0
    pis = np.zeros((C, 4)); sA2s = 0.0
    lg = np.log(GAM[1:])
    for it in range(niter):
        # intercept
        ycorr += mu
        mu = rng.normal(ycorr.mean(), math.sqrt(se2 / n))
        ycorr -= mu
        U = rng.random(m); N = rng.standard_normal(m)
        logpi = np.log(pi)
        ratio = se2 / (GAM[1:] * sA2)       # sigma_e^2/(gamma_k sigma_A^2), k=2..4
        for j in range(m):
            zj = Zt[j]
            aj = alpha[j]
            rhs = zj @ ycorr + zz[j] * aj
            c = cls[j]; lp = logpi[c]
            zzj = zz[j]
            # component 1 (zero): log weight = log pi_1
            l0 = lp[0]
            C1 = zzj + ratio[0]; C2 = zzj + ratio[1]; C3 = zzj + ratio[2]
            r2 = rhs * rhs / (2 * se2)
            l1 = lp[1] - 0.5 * math.log(C1 / ratio[0]) + r2 / C1
            l2 = lp[2] - 0.5 * math.log(C2 / ratio[1]) + r2 / C2
            l3 = lp[3] - 0.5 * math.log(C3 / ratio[2]) + r2 / C3
            mx = max(l0, l1, l2, l3)
            w0 = math.exp(l0 - mx); w1 = math.exp(l1 - mx); w2 = math.exp(l2 - mx); w3 = math.exp(l3 - mx)
            s = w0 + w1 + w2 + w3; u = U[j] * s
            if u < w0:
                kj = 0; new = 0.0
            elif u < w0 + w1:
                kj = 1; new = rhs / C1 + N[j] * math.sqrt(se2 / C1)
            elif u < w0 + w1 + w2:
                kj = 2; new = rhs / C2 + N[j] * math.sqrt(se2 / C2)
            else:
                kj = 3; new = rhs / C3 + N[j] * math.sqrt(se2 / C3)
            k[j] = kj
            if new != aj:
                ycorr += zj * (aj - new)
                alpha[j] = new
        # pi per class
        for c in range(C):
            cnt = np.bincount(k[cls == c], minlength=4)
            pi[c] = rng.dirichlet(1 + cnt)
        # sigma_A^2  (22.45)
        nz = k > 0
        ss = float(np.sum(alpha[nz] ** 2 / GAM[k[nz]]))
        sA2 = (ss + nu * SA) / rng.chisquare(nu + nz.sum())
        # sigma_e^2
        se2 = (float(ycorr @ ycorr) + nu * Se) / rng.chisquare(n + nu)
        if it >= burn:
            amean += alpha; nsave += 1; pis += pi; sA2s += sA2
    return dict(alpha=amean / nsave, mu=mu, pi=pis / nsave, sA2=sA2s / nsave)
