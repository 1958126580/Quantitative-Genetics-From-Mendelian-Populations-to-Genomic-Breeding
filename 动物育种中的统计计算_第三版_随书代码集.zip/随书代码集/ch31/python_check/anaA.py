# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 anaA.py    依赖：numpy, scipy
import json, numpy as np
from scipy import stats
d = json.load(open('simA_res_r0_1.json')) + json.load(open('simA_res_r2_10.json')) + json.load(open('simA_res_r11_19.json'))
d = sorted(d, key=lambda r: r['rep']); print('n reps', len(d), [r['rep'] for r in d])
def arr(key, f): return np.array([r[key][f] for r in d])
print('h2hat mean %.4f sd %.4f' % (np.mean([r['h2hat'] for r in d]), np.std([r['h2hat'] for r in d], ddof=1)))
print('k2pq mean %.2f' % np.mean([r['k2pq'] for r in d]), 'lam_eff bug mean %.5f' % np.mean(arr('gblup_bug', 'lam_eff')))
print('equiv h2 of bug: mean %.5f' % np.mean(1 / (1 + arr('gblup_bug', 'lam_eff'))))
rows = ['gblup_reml'] + ['gblup_h2_%.2f' % h for h in [0.01, 0.05, 0.10, 0.20, 0.40, 0.60, 0.80, 0.95, 0.99]] + ['gblup_bug', 'mlp_honest', 'mlp_leaky']
for k in rows:
    rv, rt, b1 = arr(k, 'rv'), arr(k, 'rt'), arr(k, 'b1')
    print('%-16s rv %.4f (sd %.4f)  rt %.4f (sd %.4f)  b1 %.4f (sd %.4f)' % (k, rv.mean(), rv.std(ddof=1), rt.mean(), rt.std(ddof=1), b1.mean(), b1.std(ddof=1)))
# median too
for k in ('mlp_honest', 'mlp_leaky', 'gblup_reml', 'gblup_bug'):
    print(k, 'median rt %.4f' % np.median(arr(k, 'rt')), 'min rt %.4f' % arr(k, 'rt').min())
# decomposition of reported gain on validation
L = arr('mlp_leaky', 'rv'); H = arr('mlp_honest', 'rv'); G = arr('gblup_reml', 'rv'); B = arr('gblup_bug', 'rv')
rep_gain = L - B
print('reported gain (leaky - bug) mean %.4f sd %.4f ; >0 in %d/20' % (rep_gain.mean(), rep_gain.std(ddof=1), (rep_gain > 0).sum()))
print('  selection optimism (leaky - honest) %.4f' % (L - H).mean())
print('  fair diff on val (honest - reml)   %.4f' % (H - G).mean())
print('  GBLUP misspec cost (reml - bug)   %.4f' % (G - B).mean())
print('  check sum %.4f' % ((L - H) + (H - G) + (G - B)).mean())
# truth
Lt = arr('mlp_leaky', 'rt'); Ht = arr('mlp_honest', 'rt'); Gt = arr('gblup_reml', 'rt'); Bt = arr('gblup_bug', 'rt')
print('truth: leaky-reml %.4f  honest-reml %.4f  leaky - bug %.4f' % ((Lt - Gt).mean(), (Ht - Gt).mean(), (Lt - Bt).mean()))
print('truth: honest > reml in %d/20 ; leaky > reml in %d/20' % ((Ht > Gt).sum(), (Lt > Gt).sum()))
print('val: honest > reml in %d/20 ; leaky > reml in %d/20' % ((H > G).sum(), (L > G).sum()))
for lab in ('unfair', 'fair', 'leaky_vs_reml', 'honest_vs_bug'):
    p = np.array([r['test_' + lab]['p'] for r in d]); dd = np.array([r['test_' + lab]['diff'] for r in d]); t = np.array([r['test_' + lab]['t'] for r in d])
    print('%-14s mean diff %.4f  signif(p<0.05, diff>0) %d/20   signif diff<0 %d/20  mean rAB %.3f' % (lab, dd.mean(), ((p < 0.05) & (dd > 0)).sum(), ((p < 0.05) & (dd < 0)).sum(), np.mean([r['test_' + lab]['rAB'] for r in d])))
# all MLP configs
allrt = np.array([r['mlp_all_rt'] for r in d]); allrv = np.array([r['mlp_all_rv'] for r in d])
print('MLP 24 configs: mean over configs&reps rt %.4f ; best config per rep (by rt) mean %.4f ; worst mean %.4f' % (allrt.mean(), allrt.max(1).mean(), allrt.min(1).mean()))
print('per-config mean rt:', np.round(allrt.mean(0), 3).tolist())
print('number of configs with mean rt > gblup_reml mean rt:', (allrt.mean(0) > Gt.mean()).sum())
print('reps where any config rt > reml rt: %d' % (allrt.max(1) > Gt).sum())
# the rep with collapse
for r in d:
    if r['mlp_honest']['rt'] < 0.4: print('collapse rep', r['rep'], r['mlp_honest'])
# excluding collapse
mask = Ht > 0.4
print('honest excluding collapse: rt mean %.4f, rv mean %.4f (n=%d)' % (Ht[mask].mean(), H[mask].mean(), mask.sum()))
print('config choice leaky:', [r['mlp_leaky']['cfg'] for r in d])
print('config choice honest:', [r['mlp_honest']['cfg'] for r in d])
