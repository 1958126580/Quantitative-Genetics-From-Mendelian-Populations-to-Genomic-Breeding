# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 anaA2.py    依赖：numpy
import json, numpy as np
d = json.load(open('simA_res_r0_1.json')) + json.load(open('simA_res_r2_10.json')) + json.load(open('simA_res_r11_19.json'))
d = sorted(d, key=lambda r: r['rep'])
for k in ('gblup_reml', 'gblup_bug', 'mlp_honest', 'mlp_leaky'):
    b = np.array([r[k]['b1'] for r in d]); print(k, 'b1 median %.3f  IQR %.3f-%.3f  min %.3f max %.3f' % (np.median(b), *np.percentile(b, [25, 75]), b.min(), b.max()))
L = np.array([r['mlp_leaky']['rv'] for r in d]); G = np.array([r['gblup_reml']['rv'] for r in d])
H = np.array([r['mlp_honest']['rv'] for r in d]); B = np.array([r['gblup_bug']['rv'] for r in d])
for nm, x in (('opt', L - H), ('fair', H - G), ('mis', G - B), ('rep', L - B)):
    print(nm, 'mean %.4f se %.4f' % (x.mean(), x.std(ddof=1) / np.sqrt(len(x))))
Ht = np.array([r['mlp_honest']['rt'] for r in d]); Gt = np.array([r['gblup_reml']['rt'] for r in d]); Lt = np.array([r['mlp_leaky']['rt'] for r in d])
print('truth honest-reml mean %.4f se %.4f ; leaky-reml %.4f se %.4f' % ((Ht - Gt).mean(), (Ht - Gt).std(ddof=1) / np.sqrt(20), (Lt - Gt).mean(), (Lt - Gt).std(ddof=1) / np.sqrt(20)))
# bug rv / rt with SD
print('max leaky-bug diff %.4f min %.4f' % ((L - B).max(), (L - B).min()))
