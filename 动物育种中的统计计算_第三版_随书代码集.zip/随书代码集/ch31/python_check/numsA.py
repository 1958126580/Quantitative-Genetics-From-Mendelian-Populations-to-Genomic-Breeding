# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 31 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 numsA.py    依赖：numpy, scipy
import numpy as np, json
from scipy import integrate, stats
def emax(K):
    return integrate.quad(lambda x: x * K * stats.norm.pdf(x) * stats.norm.cdf(x) ** (K - 1), -12, 12, limit=200)[0]
se = (1 - 0.30**2) / np.sqrt(200 - 1)
print('SE(r) r=0.30 nv=200: %.4f' % se)
for K in (10, 24, 100, 200):
    print('K=%d e_K=%.3f bound=%.3f' % (K, emax(K), se * emax(K)))
d = json.load(open('simA_res_r0_1.json')) + json.load(open('simA_res_r2_10.json')) + json.load(open('simA_res_r11_19.json'))
for r in d:
    if r['mlp_honest']['rt'] < 0.4: print('rep', r['rep'], 'rt %.3f b1 %.2f' % (r['mlp_honest']['rt'], r['mlp_honest']['b1']))
