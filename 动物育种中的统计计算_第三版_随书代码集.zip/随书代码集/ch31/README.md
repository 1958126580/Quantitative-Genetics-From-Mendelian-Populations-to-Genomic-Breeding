# 第三十一章　深度学习在动物遗传育种中的应用 —— 配套代码

**所属**：第七篇　机器学习与深度学习在动物遗传育种中的应用　　**对应正文**：第三十一章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch31.ipynb` | IJulia 笔记本：14 个代码单元，约 596 行 Julia 代码，穿插与正文对应的说明 |
| `ch31.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 14 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　式 (31.3) 的模拟验证
- 2　纯加性结构下的数值确认（§31.1.2 限制一）
- 3　公平比较的完整实现（§31.1.4 的六条要求）
- 4　多核 GBLUP：无下行风险的整合（§31.1.5 (c)）
- 5　图像表型：重复力与"虚假遗传力"的陷阱（§31.2.2）
- 6　深度集成的不确定性量化（式 31.12–31.13）与 BLUP 的 PEV 对照
- 7　跨群体泛化（§31.5.3）
- 8　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 31
```

或在 Jupyter 中打开 `ch31/ch31.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
