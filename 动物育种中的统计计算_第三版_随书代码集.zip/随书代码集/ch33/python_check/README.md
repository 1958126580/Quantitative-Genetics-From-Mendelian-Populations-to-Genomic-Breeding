# 第 33 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch33/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `geneflow3.py` | per-age selection differentials; pitfall: headcount-weighted generation interval | numpy | 0.2 | `outputs/geneflow3.out` |
| `ld_analyze.py` | 数值复核 | numpy | 0.2 | `outputs/ld_analyze.out` |
| `ld_numbers.py` | 数值复核 | numpy | 0.2 | `outputs/ld_numbers.out` |
| `meiosis.py` | §33.3.6: validating Algorithm 33.1 (Haldane) + counting-model interference + start-haplotype bug. | numpy, scipy | 13.4 | `outputs/meiosis.out` |
| `s1_analyze.py` | 数值复核 | numpy, scipy | 2.3 | `outputs/s1_analyze.out` |
| `sim_loci.py` | Loci-based forward simulator (unlinked biallelic QTL) for ch33 §33.2 / §33.3. | numpy, scipy | 1.0 | `outputs/sim_loci.out` |

公共函数模块（被上列脚本导入，不单独运行）：`common.py`、`det.py`、`geneflow.py`、`ld_sim.py`。
