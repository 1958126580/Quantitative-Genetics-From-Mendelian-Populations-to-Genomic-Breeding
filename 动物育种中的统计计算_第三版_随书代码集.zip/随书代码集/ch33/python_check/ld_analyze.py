# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 33 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ld_analyze.py    依赖：numpy
import json, numpy as np
from ld_sim import BINS, CHK, N
R = {}
for f in ('ld_0_4_mu1.25.json', 'ld_4_12_mu1.25.json'):
    R.update(json.load(open(f)))
reps = sorted(R, key=int); print('reps', len(reps))
nb = len(BINS) - 1
def arr(key, sub='full', what='r2'):
    return np.array([[R[r][str(t)][sub][what] for t in CHK] for r in reps])   # reps x T x bins
r2 = arr('r2'); sved = arr('r2', what='sved'); trans = arr('r2', what='trans'); dmean = arr('r2', what='d'); cnt = arr('r2', what='cnt')
r2s = arr('r2', sub='sub')
m = r2.mean(0); se = r2.std(0, ddof=1) / np.sqrt(len(reps)); sv = sved.mean(0); tr = trans.mean(0); dm = dmean.mean(0)
lab = [f'{BINS[k]*100:g}-{BINS[k+1]*100:g}cM' for k in range(nb)]
print('bin mean d (cM) at final:', np.round(dm[-1] * 100, 3))
for i, t in enumerate(CHK):
    print(f't={t:5d} r2   ', np.round(m[i], 4))
print('se final', np.round(se[-1], 4))
print('Sved eq (pairs avg)', np.round(sv[-1], 4)); print('Sved+1/200', np.round(sv[-1] + 1 / 200, 4))
for i, t in enumerate(CHK): print(f't={t:5d} trans+1/200', np.round(tr[i] + 1 / 200, 4))
print('sub n=50 final', np.round(r2s.mean(0)[-1], 4), ' Sved+1/50', np.round(sv[-1] + 1 / 50, 4))
eq = 0.5 * (m[-1] + m[-2])
print('equilibrium (avg t=1600,2400)', np.round(eq, 4))
for i, t in enumerate(CHK): print(f't={t:5d} frac of eq', np.round(m[i] / eq, 3))
print('ncommon', np.mean([R[r][str(CHK[-1])]['ncommon'] for r in reps]), 'nloci', np.mean([R[r][str(CHK[-1])]['nloci'] for r in reps]))
print('n_orig at t', [np.mean([R[r][str(t)]['n_orig'] for r in reps]) for t in CHK])
print('het', [round(np.mean([R[r][str(t)]['het'] for r in reps]), 4) for t in CHK])
