# -*- coding: utf-8 -*-
"""§33.2.6 gene flow with yearly age classes; four paths; PT (Table 10.4) -> GS (Table 10.5) switch."""
import numpy as np
A = 8   # oldest parental age tracked
PT = dict(S={'SS': 1.9235, 'SD': 1.3053, 'DS': 1.9772, 'DD': 0.1814},
          age={'SS': {6: .5, 7: .5}, 'SD': {5: .2, 6: .6, 7: .2}, 'DS': {4: 1/3, 5: 1/3, 6: 1/3}, 'DD': {3: .25, 4: .25, 5: .25, 6: .25}})
GS = dict(S={'SS': 1.6946, 'SD': 1.2285, 'DS': 1.6524, 'DD': 0.1701},
          age={'SS': {2: 1.0}, 'SD': {2: 1.0}, 'DS': {2: .5, 3: .5}, 'DD': {2: .2, 3: .2, 4: .2, 5: .2, 6: .2}})

def build(sch):
    """state x_t = [mM(t), mM(t-1), ..., mM(t-A+1), mF(t), ..., mF(t-A+1)];  x_{t+1} = P x_t + s"""
    q = 2 * A; P = np.zeros((q, q)); s = np.zeros(q)
    iM, iF = 0, A
    for a in range(1, A):             # ageing rows
        P[iM + a, iM + a - 1] = 1; P[iF + a, iF + a - 1] = 1
    for (row, sp, dp) in ((iM, 'SS', 'DS'), (iF, 'SD', 'DD')):
        for a, f in sch['age'][sp].items():  # sire of age a at t+1 born at t+1-a -> state index a-1
            P[row, iM + a - 1] += 0.5 * f
        for a, f in sch['age'][dp].items():
            P[row, iF + a - 1] += 0.5 * f
        s[row] = 0.5 * sch['S'][sp] + 0.5 * sch['S'][dp]
    return P, s

def L(sch):
    return {k: sum(a * f for a, f in v.items()) for k, v in sch['age'].items()}

def rr(sch):
    Lk = L(sch); return sum(sch['S'].values()) / sum(Lk.values()), Lk

if __name__ == '__main__':
    for nm, sch in (('PT', PT), ('GS', GS)):
        g, Lk = rr(sch); print(nm, 'L', Lk, 'sumL', sum(Lk.values()), 'sumS', round(sum(sch['S'].values()), 4), 'RR dG', round(g, 6))
        P, s = build(sch); x = np.zeros(2 * A); prev = 0
        for t in range(400):
            x = P @ x + s
        xm = 0.5 * (x[0] + x[A]); x2 = P @ x + s; print('   gene-flow asymptotic slope', 0.5 * (x2[0] + x2[A]) - xm, 'male-female offset', x[0] - x[A])
    # --- transient after switch
    P1, s1 = build(PT); P2, s2 = build(GS)
    x = np.zeros(2 * A)
    for t in range(400): x = P1 @ x + s1
    base = 0.5 * (x[0] + x[A]); dPT = rr(PT)[0]; dGS = rr(GS)[0]
    traj = []; xm = x.copy(); rows = []
    for t in range(1, 61):
        xn = P2 @ x + s2
        gm = xn[0] - x[0]; gf = xn[A] - x[A]; gbar = 0.5 * (gm + gf)
        lvl = 0.5 * (xn[0] + xn[A]) - base
        rows.append((t, gm, gf, gbar, lvl, dPT * t, dGS * t)); x = xn
    for r in rows[:20] + rows[24:25] + rows[29:30] + rows[39:40] + rows[59:60]:
        print('yr %2d  male %.4f  female %.4f  mean %.4f  cum %.4f  PTcont %.4f  naiveGS %.4f' % r)
    # convergence: first year after which |gbar - dGS|/dGS < 5% and 1% for all later years
    g = np.array([r[3] for r in rows])
    for tol in (0.05, 0.01):
        bad = np.where(np.abs(g - dGS) / dGS >= tol)[0]
        print('tol', tol, 'within from year', (bad[-1] + 2) if len(bad) else 1)
    lv = np.array([r[4] for r in rows])
    print('asymptotic intercept (level - dGS*t) at t=60:', lv[-1] - dGS * 60, ' in years of GS gain:', (lv[-1] - dGS * 60) / dGS)
    print('extra vs PT continued at 5,10,20 yrs:', [round(lv[k - 1] - dPT * k, 4) for k in (5, 10, 20)])
    print('ratio realised cum / (dGS*t) at 5,10,20:', [round(lv[k - 1] / (dGS * k), 4) for k in (5, 10, 20)])
    print('mean annual gain yrs1-5, 6-10:', g[:5].mean(), g[5:10].mean())
