# -*- coding: utf-8 -*-
"""Shared helpers for ch33 expansion: selection intensities (infinite & finite), Bulmer k."""
import numpy as np
from scipy import stats, integrate

def trunc(p):
    """infinite-population truncation point x, intensity i, variance reduction k"""
    x = stats.norm.isf(p); i = stats.norm.pdf(x) / p; k = i * (i - x)
    return x, i, k

def _pbin(z, n, m):
    # P{Bin(n, 1-Phi(z)) <= m}
    return stats.binom.cdf(m, n, stats.norm.sf(z))

def i_fin(N, M):
    """Expected mean of top-M of N iid N(0,1)  (eq. 10.6a)"""
    f = lambda z: z * stats.norm.pdf(z) * _pbin(z, N - 1, M - 1)
    v, _ = integrate.quad(f, -12, 12, limit=400, epsabs=1e-12, epsrel=1e-12)
    return N / M * v

def k_fin(N, M):
    """1 - E[within-group variance (divisor M)] of the top-M of N iid N(0,1).
    Includes the 1/M sampling loss; exact via single integrals."""
    s1 = integrate.quad(lambda z: z * stats.norm.pdf(z) * _pbin(z, N - 1, M - 1), -12, 12, limit=400, epsabs=1e-13)[0] * N
    s2 = integrate.quad(lambda z: z * z * stats.norm.pdf(z) * _pbin(z, N - 1, M - 1), -12, 12, limit=400, epsabs=1e-13)[0] * N
    if M >= 2:
        cr = integrate.quad(lambda z: z * stats.norm.pdf(z) ** 2 * _pbin(z, N - 2, M - 2), -12, 12, limit=400, epsabs=1e-13)[0] * 2 * N * (N - 1)
    else:
        cr = 0.0
    ez2bar = (s2 + cr) / M ** 2
    within = s2 / M - ez2bar
    return 1 - within

if __name__ == '__main__':
    for p in (0.1, 0.5):
        print('inf', p, trunc(p))
    print('i_fin(200,20)', i_fin(200, 20), 'i_fin(200,100)', i_fin(200, 100), 'i_fin(200,10)', i_fin(200, 10))
    print('k_fin(200,20)', k_fin(200, 20), 'k_fin(200,100)', k_fin(200, 100))
    # MC check
    rng = np.random.default_rng(1)
    for (N, M) in [(200, 20), (200, 100)]:
        Z = rng.standard_normal((200000, N))
        top = -np.sort(-Z, axis=1)[:, :M]
        print('MC', N, M, top.mean(), 1 - top.var(axis=1).mean())
