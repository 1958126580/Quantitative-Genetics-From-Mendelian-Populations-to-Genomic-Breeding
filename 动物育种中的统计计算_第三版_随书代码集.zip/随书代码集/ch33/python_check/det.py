# -*- coding: utf-8 -*-
"""Deterministic predictions for §33.2.5 (mass selection) and §33.2.7 (pseudo-BLUP)."""
import numpy as np
from common import trunc, i_fin, k_fin
VA0, VE = 0.25, 0.75
NCm = NCf = 200; NM, NF = 20, 100
DF = 1 / (8 * NM) + 1 / (8 * NF)
_, im_inf, km_inf = trunc(NM / NCm); _, if_inf, kf_inf = trunc(NF / NCf)
im_fin, km_fin = i_fin(NCm, NM), k_fin(NCm, NM)
if_fin, kf_fin = i_fin(NCf, NF), k_fin(NCf, NF)

def Fpred(t, dF=DF):
    """inbreeding of generation-t candidates (founders t=0 and their offspring t=1 are non-inbred)"""
    return 0.0 if t <= 1 else 1 - (1 - dF) ** (t - 1)

def mass(level, T=10, dF=DF):
    """level: 'A' naive; 'B' +Bulmer; 'C' +finite pop (i,k and 1/M sampling); 'D' +inbreeding"""
    V = VA0; G = 0.0; out = {'G': [0.0], 'V': [V], 'F': [0.0], 'h2': [V / (V + VE)]}
    fin = level in ('C', 'D')
    im, km, i_f, kf = (im_fin, km_fin, if_fin, kf_fin) if fin else (im_inf, km_inf, if_inf, kf_inf)
    for t in range(T):
        h2 = V / (V + VE)
        if level == 'A':
            G += 0.5 * (im + i_f) * np.sqrt(VA0 / (VA0 + VE)) * np.sqrt(VA0)
            out['G'].append(G); out['V'].append(VA0); out['F'].append(Fpred(t + 1, dF)); out['h2'].append(0.25); continue
        G += 0.5 * (im + i_f) * np.sqrt(h2) * np.sqrt(V)
        if fin:
            Vm = h2 * V * (1 - km) + (1 - h2) * V * (1 - 1 / NM)
            Vf = h2 * V * (1 - kf) + (1 - h2) * V * (1 - 1 / NF)
        else:
            Vm = V * (1 - km * h2); Vf = V * (1 - kf * h2)
        Ft = Fpred(t, dF) if level == 'D' else 0.0
        V = 0.25 * Vm + 0.25 * Vf + 0.5 * (1 - Ft) * VA0
        out['G'].append(G); out['V'].append(V); out['F'].append(Fpred(t + 1, dF)); out['h2'].append(V / (V + VE))
    return {k: np.array(v) for k, v in out.items()}

def pblup(T=10, dF=DF, nfs=3, nhs=16, ndo=4, fin=True, Fseq=None, sources=(1, 1, 1, 1, 1, 1)):
    """pseudo-BLUP recursion. sources flags: sireEBV, damEBV, own, FSmean, HSmean, mates' EBV mean"""
    im, km, i_f, kf = (im_fin, km_fin, if_fin, kf_fin) if fin else (im_inf, km_inf, if_inf, kf_inf)
    V = VA0; rho = V / (V + VE); G = 0.0
    out = {'G': [0.0], 'V': [V], 'rho': [rho], 'F': [0.0], 'b': [None]}
    for t in range(T):
        G += 0.5 * (im + i_f) * np.sqrt(rho * V)
        cs = rho * V * (1 - km); cd = rho * V * (1 - kf)
        if fin:
            Vs = cs + (1 - rho) * V * (1 - 1 / NM); Vd = cd + (1 - rho) * V * (1 - 1 / NF)
        else:
            Vs = V * (1 - km * rho); Vd = V * (1 - kf * rho)
        Ft = (Fseq[t] if Fseq is not None else Fpred(t, dF))
        M = 0.5 * (1 - Ft) * VA0
        Vn = 0.25 * Vs + 0.25 * Vd + M
        fs = 0.25 * Vs + 0.25 * Vd
        g = np.array([0.5 * cs, 0.5 * cd, Vn, fs, 0.25 * Vs, 0.0])
        P = np.array([
            [cs, 0, 0.5 * cs, 0.5 * cs, 0.5 * cs, 0],
            [0, cd, 0.5 * cd, 0.5 * cd, 0, 0],
            [0.5 * cs, 0.5 * cd, Vn + VE, fs, 0.25 * Vs, 0],
            [0.5 * cs, 0.5 * cd, fs, fs + (M + VE) / nfs, 0.25 * Vs, 0],
            [0.5 * cs, 0, 0.25 * Vs, 0.25 * Vs, 0.25 * Vs + Vd / (4 * ndo) + (M + VE) / nhs, cd / (2 * ndo)],
            [0, 0, 0, 0, cd / (2 * ndo), cd / ndo]])
        sel = np.array(sources, bool)
        Ps = P[np.ix_(sel, sel)]; gs = g[sel]
        b = np.linalg.solve(Ps, gs)
        rho = float(b @ gs / Vn); V = Vn
        out['G'].append(G); out['V'].append(V); out['rho'].append(rho); out['F'].append(Fpred(t + 1, dF) if Fseq is None else Fseq[t + 1]); out['b'].append(b)
    return out

if __name__ == '__main__':
    print('constants: inf i_m %.4f k_m %.4f i_f %.4f k_f %.4f' % (im_inf, km_inf, if_inf, kf_inf))
    print('           fin i_m %.4f k_m %.4f i_f %.4f k_f %.4f' % (im_fin, km_fin, if_fin, kf_fin))
    print('dF', DF)
    for L in 'ABCD':
        o = mass(L)
        print(L, 'G/sA0', np.round(o['G'] / 0.5, 4))
        print('   V/VA0', np.round(o['V'] / VA0, 4))
    o = pblup()
    print('PB G', np.round(np.array(o['G']) / 0.5, 4)); print('PB r', np.round(np.sqrt(o['rho']), 4)); print('PB V', np.round(np.array(o['V']) / VA0, 4))
    for t in (1, 2, 10): print('b', t, np.round(o['b'][t], 4))
