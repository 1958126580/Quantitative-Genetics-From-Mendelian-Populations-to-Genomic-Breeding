# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 33 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 meiosis.py    依赖：numpy, scipy
"""§33.3.6: validating Algorithm 33.1 (Haldane) + counting-model interference + start-haplotype bug.
Seeds: default_rng([20260930, 336, k])."""
import numpy as np, json
from scipy import stats
from math import factorial
n = 1_000_000; L = 1.0
D = [0.01, 0.05, 0.10, 0.20, 0.30, 0.50, 1.00]
hald = lambda d: 0.5 * (1 - np.exp(-2 * d)); kos = lambda d: 0.5 * np.tanh(2 * d)
def cm_formula(d, m):
    lam = 2 * (m + 1) * d
    return 0.5 * (1 - sum((1 - k / (m + 1)) * np.exp(-lam) * lam ** k / factorial(k) for k in range(m + 1)))
out = {}
# ---------- (1) Algorithm 33.1: gamete-level Poisson(L) crossovers
rng = np.random.default_rng([20260930, 336, 1])
K = rng.poisson(L, n); X = rng.random(K.sum()) * L; gid = np.repeat(np.arange(n), K)
start = rng.integers(0, 2, n)
cnt = np.bincount(np.minimum(K, 6), minlength=7) / n
pois = np.array([stats.poisson.pmf(k, L) for k in range(6)] + [stats.poisson.sf(5, L)])
obs = np.bincount(np.minimum(K, 6), minlength=7); chi2 = float(((obs - n * pois) ** 2 / (n * pois)).sum()); pchi = float(stats.chi2.sf(chi2, 6))
out['count'] = dict(freq=cnt.tolist(), pois=pois.tolist(), mean=float(K.mean()), var=float(K.var()), chi2=chi2, p=pchi)
# recombination fraction for intervals [a, a+d] with a = (L-d)/2 (centred)
def recfrac(gid, X, n, d, L=1.0):
    a = (L - d) / 2; m = (X > a) & (X < a + d)
    c = np.bincount(gid[m], minlength=n)
    return float(np.mean(c % 2))
out['rec'] = [dict(d=d, sim=recfrac(gid, X, n, d), se=float(np.sqrt(hald(d) * (1 - hald(d)) / n)), hald=float(hald(d)), kos=float(kos(d))) for d in D]
# ---------- (2) start-haplotype bug: always start from haplotype 1 -> P(transmit h1 allele at x)
xs = [0.0, 0.1, 0.25, 0.5, 0.75, 1.0]
bug = []
for x in xs:
    c = np.bincount(gid[X < x], minlength=n)
    p_bug = float(np.mean(c % 2 == 0))                       # start = h1, even # crossovers before x -> h1
    p_ok = float(np.mean(((c % 2) ^ start) == 0))            # random start
    bug.append(dict(x=x, bug=p_bug, ok=p_ok, theory=0.5 * (1 + np.exp(-2 * x))))
out['bug'] = bug
# ---------- (3) counting (chi-square) model with m = 0, 1, 4
def counting(m, seed):
    rng = np.random.default_rng([20260930, 336, seed])
    npt = rng.poisson(2 * (m + 1) * L, n)
    pos = rng.random(npt.sum()) * L; mid = np.repeat(np.arange(n), npt)
    o = np.lexsort((pos, mid)); pos = pos[o]; mid = mid[o]
    first = np.concatenate([[0], np.cumsum(npt)[:-1]])
    rank = np.arange(len(pos)) - np.repeat(first, npt)
    s = rng.integers(0, m + 1, n)
    chi = ((rank - s[mid]) % (m + 1) == 0) & (rank >= s[mid])
    keep = chi & (rng.random(len(pos)) < 0.5)
    return mid[keep], pos[keep], np.bincount(mid[chi], minlength=n)
cmres = {}
for m, seed in ((0, 2), (1, 3), (4, 4)):
    g2, x2, nchi = counting(m, seed)
    Kc = np.bincount(g2, minlength=n)
    cmres[m] = dict(mean=float(Kc.mean()), var=float(Kc.var()), p0=float(np.mean(Kc == 0)), p0_chiasma=float(np.mean(nchi == 0)),
                    rec=[dict(d=d, sim=recfrac(g2, x2, n, d), formula=float(cm_formula(d, m)), kos=float(kos(d)), hald=float(hald(d))) for d in D])
out['counting'] = cmres
json.dump(out, open('meiosis.json', 'w'), indent=1)
print('count freq', np.round(cnt, 5)); print('poisson   ', np.round(pois, 5)); print('mean var chi2 p', out['count']['mean'], out['count']['var'], chi2, pchi)
for r in out['rec']: print('d %.2f sim %.4f se %.4f hald %.4f kos %.4f' % (r['d'], r['sim'], r['se'], r['hald'], r['kos']))
for b in bug: print('x %.2f bug %.4f theory %.4f ok %.4f' % (b['x'], b['bug'], b['theory'], b['ok']))
for m, r in cmres.items():
    print('m', m, 'mean %.4f var %.4f P0 %.4f P0chiasma %.4f' % (r['mean'], r['var'], r['p0'], r['p0_chiasma']))
    for q in r['rec']: print('   d %.2f sim %.4f formula %.4f kos %.4f hald %.4f' % (q['d'], q['sim'], q['formula'], q['kos'], q['hald']))
