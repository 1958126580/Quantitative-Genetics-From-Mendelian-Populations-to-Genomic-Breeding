# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 33 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_analyze.py    依赖：numpy
import numpy as np, sys
import det
sA0 = 0.5
def load(s):
    d = np.load(f's1_{s}.npz'); return {k: d[k] for k in d.files}
def summ(s):
    d = load(s); R = d['mean'].shape[0]
    G = (d['mean'] - d['mean'][:, :1]) / sA0
    V = d['var'] / 0.25
    return R, G, V, d
if __name__ == '__main__':
  for s in sys.argv[1:]:
      R, G, V, d = summ(s)
      print(f'=== {s}  R={R}')
      print(' G mean', np.round(G.mean(0), 4)); print(' G se  ', np.round(G.std(0, ddof=1) / np.sqrt(R), 4)); print(' G sd  ', np.round(G.std(0, ddof=1), 4))
      print(' V/VA0 ', np.round(V.mean(0), 4), ' se', np.round(V.std(0, ddof=1)[[1, 5, 10]] / np.sqrt(R), 4))
      print(' genic ', np.round(d['genic'].mean(0) / 0.25, 4))
      print(' F     ', np.round(d['F'].mean(0), 5), ' se', np.round(d['F'].std(0, ddof=1)[[2, 5, 10]] / np.sqrt(R), 5))
      # per-generation dF from F_t: 1-(1-F10)^(1/9)
      F = d['F'].mean(0); print(' dF from F10 over 9 gens', 1 - (1 - F[10]) ** (1 / 9), ' mean increments', np.round(np.diff(F)[1:], 5))
      print(' acc   ', np.round(np.nanmean(d['acc'], 0), 4))
      print(' isel m', np.round(np.nanmean(d['isel_m'], 0), 4), ' overall', np.nanmean(d['isel_m'][:, :10]))
      print(' isel f', np.round(np.nanmean(d['isel_f'], 0), 4), ' overall', np.nanmean(d['isel_f'][:, :10]))
      print(' fixed ', np.round(d['fixed'].mean(0), 2))
