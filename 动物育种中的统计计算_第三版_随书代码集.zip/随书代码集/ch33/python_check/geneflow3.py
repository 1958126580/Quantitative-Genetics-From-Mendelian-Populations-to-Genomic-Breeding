# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 33 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 geneflow3.py    依赖：numpy
"""per-age selection differentials; pitfall: headcount-weighted generation interval"""
import numpy as np
from geneflow import A, PT
def build2(age_S):
    """age_S[path] = {age: (fraction, S)}"""
    q = 2 * A; P = np.zeros((q, q)); s = np.zeros(q); iM, iF = 0, A
    for a in range(1, A):
        P[iM + a, iM + a - 1] = 1; P[iF + a, iF + a - 1] = 1
    for (row, sp, dp) in ((iM, 'SS', 'DS'), (iF, 'SD', 'DD')):
        for a, (f, S) in age_S[sp].items(): P[row, iM + a - 1] += 0.5 * f; s[row] += 0.5 * f * S
        for a, (f, S) in age_S[dp].items(): P[row, iF + a - 1] += 0.5 * f; s[row] += 0.5 * f * S
    return P, s
def slope(P, s):
    x = np.zeros(2 * A)
    for t in range(600): x = P @ x + s
    x2 = P @ x + s; return 0.5 * (x2[0] + x2[A]) - 0.5 * (x[0] + x[A])
ages = {k: {a: (f, PT['S'][k]) for a, f in v.items()} for k, v in PT['age'].items()}
# SD path: 20% of inseminations by 2-yr-old test bulls (S=0), 80% by proven bulls (ages 5/6/7 as before)
ages['SD'] = {2: (0.2, 0.0), 5: (0.8 * 0.2, 1.3053), 6: (0.8 * 0.6, 1.3053), 7: (0.8 * 0.2, 1.3053)}
P, s = build2(ages)
g = slope(P, s)
LSD = sum(a * f for a, (f, S) in ages['SD'].items()); SSD = sum(f * S for a, (f, S) in ages['SD'].items())
Lsum = 6.5 + LSD + 5.0 + 4.5; Ssum = 1.9235 + SSD + 1.9772 + 0.1814
print('gene-flow slope %.6f ; RR with offspring-weighted L: L_SD %.3f S_SD %.5f -> %.6f' % (g, LSD, SSD, Ssum / Lsum))
# headcount weighting: 100 test bulls vs 25 proven bulls in service -> 80% young by headcount
LSD_h = 0.8 * 2 + 0.2 * 6.0
print('headcount L_SD %.2f -> dG %.6f (%+.1f%%)' % (LSD_h, Ssum / (6.5 + LSD_h + 5.0 + 4.5), 100 * (Ssum / (6.5 + LSD_h + 9.5) / g - 1)))
