# -*- coding: utf-8 -*-
"""§33.3.6: LD from drift-recombination(-mutation) balance.
Wright-Fisher, N diploids (2N haplotypes), one chromosome of length Lm Morgan, Haldane crossovers,
infinite-sites mutation (mu per haplotype per generation). Start: M0 loci in linkage equilibrium.
Seeds: default_rng([20260930, 33, rep])."""
import numpy as np, sys, json, time
N = 100; Lm = 1.0; MU = float(sys.argv[3]) if len(sys.argv) > 3 else 1.25; M0 = 3000
CHK = [0, 10, 25, 50, 100, 200, 400, 800, 1600, 2400]
BINS = np.array([0, 0.001, 0.0025, 0.005, 0.01, 0.02, 0.05, 0.10, 0.20, 0.50])   # Morgan
def hald(d): return 0.5 * (1 - np.exp(-2 * d))
def r2_by_bin(H, pos, t, maf=0.05, nsub=None, rng=None):
    X = H.astype(np.float64)
    if nsub is not None:
        X = X[rng.choice(X.shape[0], nsub, replace=False)]
    f = X.mean(0); keep = (f >= maf) & (f <= 1 - maf)
    X = X[:, keep]; ps = pos[keep]
    Z = (X - X.mean(0)) / X.std(0)
    R = (Z.T @ Z) / X.shape[0]
    iu = np.triu_indices(len(ps), 1)
    r2 = (R * R)[iu]; d = (ps[None, :] - ps[:, None])[iu]
    c = hald(d)
    lam = (1 - c) ** 2 * (1 - 1 / (2 * N)); Linf = (1 - c) ** 2 / (2 * N) / (1 - lam)
    sved = 1 / (1 + 4 * N * c); trans = Linf * (1 - lam ** t)
    b = np.clip(np.digitize(d, BINS) - 1, 0, len(BINS) - 2)
    nb = len(BINS) - 1
    cnt = np.bincount(b, minlength=nb).astype(float)
    S = lambda w: (np.bincount(b, weights=w, minlength=nb) / np.maximum(cnt, 1)).tolist()
    return dict(cnt=cnt.tolist(), r2=S(r2), d=S(d), sved=S(sved), trans=S(trans), Linf=S(Linf)), int(keep.sum())
def run(rep):
    rng = np.random.default_rng([20260930, 33, rep])
    pos = np.sort(rng.random(M0) * Lm)
    p = rng.uniform(0.05, 0.95, M0)
    H = (rng.random((2 * N, M0)) < p).astype(np.int8)
    orig = np.ones(M0, bool)
    res = {}
    for t in range(CHK[-1] + 1):
        if t in CHK:
            full, nk = r2_by_bin(H, pos, t)
            sub, nks = r2_by_bin(H, pos, t, nsub=50, rng=np.random.default_rng([20260930, 34, rep, t]))
            f = H.mean(0); het = float(np.mean(2 * f * (1 - f)))
            res[t] = dict(full=full, sub=sub, nloci=int(H.shape[1]), ncommon=nk, ncommon_sub=nks, het=het,
                          n_orig=int(np.sum(orig[keep_o])) if False else int(orig.sum()))
        # --- next generation: 2N gametes, each from a random parent (selfing allowed)
        par = rng.integers(0, N, 2 * N)
        start = rng.integers(0, 2, 2 * N)
        K = rng.poisson(Lm, 2 * N)
        X = rng.random(K.sum()) * Lm
        gid = np.repeat(np.arange(2 * N), K)
        S = H.shape[1]
        flat = np.bincount(gid * (S + 1) + np.searchsorted(pos, X), minlength=2 * N * (S + 1)).reshape(2 * N, S + 1)
        par_flip = np.logical_xor.accumulate((flat[:, :S] & 1).astype(bool), axis=1)
        which = par_flip ^ start[:, None].astype(bool)            # False -> first haplotype of parent
        Hn = np.where(which, H[2 * par + 1], H[2 * par])
        # --- mutation (infinite sites)
        nm = rng.poisson(MU * 2 * N)
        if nm:
            npos = rng.random(nm) * Lm
            carrier = rng.integers(0, 2 * N, nm)
            new = np.zeros((2 * N, nm), np.int8); new[carrier, np.arange(nm)] = 1
            Hn = np.concatenate([Hn, new], axis=1); pos2 = np.concatenate([pos, npos]); orig2 = np.concatenate([orig, np.zeros(nm, bool)])
            o = np.argsort(pos2, kind='stable'); Hn = Hn[:, o]; pos2 = pos2[o]; orig2 = orig2[o]
        else:
            pos2 = pos; orig2 = orig
        c = Hn.sum(0); keep = (c > 0) & (c < 2 * N)
        H = Hn[:, keep]; pos = pos2[keep]; orig = orig2[keep]
    return res
def pos_orig_mask(*a): return []
if __name__ == '__main__':
    r0, r1 = int(sys.argv[1]), int(sys.argv[2])
    allres = {}
    t0 = time.time()
    for rep in range(r0, r1):
        allres[rep] = run(rep)
        print('rep', rep, f'{time.time()-t0:.0f}s', 'nloci', allres[rep][CHK[-1]]['nloci'], 'common', allres[rep][CHK[-1]]['ncommon'], flush=True)
        json.dump(allres, open(f'ld_{r0}_{r1}_mu{MU}.json', 'w'))
    print('DONE')
