# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 33 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 sim_loci.py    依赖：numpy, scipy
"""Loci-based forward simulator (unlinked biallelic QTL) for ch33 §33.2 / §33.3.
Structure: each generation 400 candidates (200 M, 200 F); NM sires x (NF/NM) dams each;
4 offspring per mating (2M+2F). Phenotype y = TBV + e, sigma2_A0 = 0.25 (expected genic), sigma2_E = 0.75.
Pedigree coancestry tracked generation-wise; BLUP = animal model with A^-1 (Quaas/Henderson incl. F)."""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl

SEED = 20260930
VA0, VE = 0.25, 0.75

def founders(rep, nloci, n=400, pdist='unif'):
    rng = np.random.default_rng([SEED, rep, 0])
    if pdist == 'unif':
        p = rng.uniform(0.1, 0.9, nloci)
    elif pdist == 'ushape':      # neutral-like spectrum f(p) ~ 1/(p(1-p)) on [0.01,0.99]
        u = rng.random(nloci)
        lo, hi = 0.01, 0.99
        L0, L1 = np.log(lo / (1 - lo)), np.log(hi / (1 - hi))
        t = L0 + u * (L1 - L0); p = 1 / (1 + np.exp(-t))
    else:
        raise ValueError
    a = rng.normal(0, 1, nloci)
    a *= np.sqrt(VA0 / np.sum(2 * p * (1 - p) * a * a))
    H1 = (rng.random((n, nloci)) < p).astype(np.uint8)
    H2 = (rng.random((n, nloci)) < p).astype(np.uint8)
    return p, a, np.packbits(H1, axis=1), np.packbits(H2, axis=1)

_BITS = np.unpackbits(np.arange(256, dtype=np.uint8)[:, None], axis=1).astype(np.float64)   # 256 x 8, MSB first
def bv_table(a):
    nb = (len(a) + 7) // 8
    ap = np.zeros(nb * 8); ap[:len(a)] = a
    return (_BITS @ ap.reshape(nb, 8).T).T          # nb x 256

def tbv(T, H1, H2):
    cols = np.arange(T.shape[0])
    return T[cols, H1].sum(1) + T[cols, H2].sum(1)

def allele_freq(H1, H2, nloci):
    c = np.unpackbits(H1, axis=1)[:, :nloci].sum(0, dtype=np.int64) + np.unpackbits(H2, axis=1)[:, :nloci].sum(0, dtype=np.int64)
    return c / (2.0 * H1.shape[0])

def gametes(rng, H1, H2, par):
    n, nb = len(par), H1.shape[1]
    mask = np.frombuffer(rng.bytes(n * nb), dtype=np.uint8).reshape(n, nb)
    return (H1[par] & mask) | (H2[par] & ~mask)

def ainv(sire, dam, F):
    """sire/dam: -1 unknown; F: inbreeding of each animal. Returns sparse A^-1."""
    n = len(sire); idx = np.arange(n)
    s, d = sire, dam
    both = (s >= 0) & (d >= 0); onlys = (s >= 0) & (d < 0); onlyd = (s < 0) & (d >= 0)
    dii = np.ones(n)
    Fs = np.where(s >= 0, F[np.maximum(s, 0)], 0.0); Fd = np.where(d >= 0, F[np.maximum(d, 0)], 0.0)
    dii[both] = 0.5 - 0.25 * (Fs[both] + Fd[both])
    dii[onlys] = 0.75 - 0.25 * Fs[onlys]
    dii[onlyd] = 0.75 - 0.25 * Fd[onlyd]
    b = 1 / dii
    R = [idx]; C = [idx]; V = [b]
    for par, has in ((s, s >= 0), (d, d >= 0)):
        i = idx[has]; pp = par[has]; bb = b[has]
        R += [i, pp]; C += [pp, i]; V += [-bb / 2, -bb / 2]
    for p1, h1 in ((s, s >= 0), (d, d >= 0)):
        for p2, h2 in ((s, s >= 0), (d, d >= 0)):
            h = h1 & h2
            R.append(p1[h]); C.append(p2[h]); V.append(b[h] / 4)
    return sp.csr_matrix((np.concatenate(V), (np.concatenate(R), np.concatenate(C))), shape=(n, n))

def blup(y, sire, dam, F, lam):
    n = len(y)
    Ai = ainv(sire, dam, F)
    one = np.ones((n, 1))
    Cm = sp.bmat([[sp.csr_matrix([[float(n)]]), sp.csr_matrix(one.T)],
                  [sp.csr_matrix(one), sp.identity(n, format='csr') + lam * Ai]]).tocsc()
    rhs = np.concatenate([[y.sum()], y])
    sol = spl.spsolve(Cm, rhs)
    return sol[1:]

def run(rep, scheme='mass', nloci=2000, T=10, NM=20, NF=100, pdist='unif', keep_freq=False):
    """scheme in {'mass','random','blup'}; returns per-generation statistics t=0..T"""
    p0, a, H1, H2 = founders(rep, nloci, pdist=pdist)
    T_bv = bv_table(a)
    n = H1.shape[0]; half = n // 2
    male = np.zeros(n, bool); male[:half] = True
    C = 0.5 * np.eye(n)              # coancestry among current candidates
    Fcur = np.zeros(n)
    # pedigree over all generations (for BLUP)
    allS = [np.full(n, -1)]; allD = [np.full(n, -1)]; allF = [Fcur.copy()]; allY = []
    off0 = 0
    out = {k: [] for k in ('mean', 'var', 'F', 'genic', 'fixed', 'acc', 'isel_m', 'isel_f', 'acc_m', 'acc_f', 'lostfav', 'limit')}
    ngen_dams_per_sire = NF // NM
    for t in range(T + 1):
        rngE = np.random.default_rng([SEED, rep, t, 3])
        g = tbv(T_bv, H1, H2)
        y = g + rngE.normal(0, np.sqrt(VE), n)
        allY.append(y)
        freq = allele_freq(H1, H2, nloci)
        out['mean'].append(g.mean()); out['var'].append(g.var(ddof=1)); out['F'].append(Fcur.mean())
        out['genic'].append(np.sum(2 * freq * (1 - freq) * a * a))
        out['fixed'].append(int(np.sum((freq == 0) | (freq == 1))))
        fav = np.where(a > 0, freq, 1 - freq)          # frequency of favourable allele
        out['lostfav'].append(int(np.sum(fav == 0)))
        out['limit'].append(float(np.sum(2 * np.abs(a) * (1 - fav))))   # remaining possible gain (all favourable fixed)
        if t == T:
            out['acc'].append(np.nan); out['acc_m'].append(np.nan); out['acc_f'].append(np.nan)
            out['isel_m'].append(np.nan); out['isel_f'].append(np.nan)
            break
        # --- selection criterion
        if scheme == 'mass':
            crit = y
        elif scheme == 'random':
            crit = np.random.default_rng([SEED, rep, t, 4]).random(n)
        elif scheme == 'blup':
            S = np.concatenate(allS); D = np.concatenate(allD); Fa = np.concatenate(allF); Y = np.concatenate(allY)
            ebv = blup(Y, S, D, Fa, VE / VA0)
            crit = ebv[off0:off0 + n]
        out['acc'].append(np.corrcoef(crit, g)[0, 1])
        out['acc_m'].append(np.corrcoef(crit[male], g[male])[0, 1]); out['acc_f'].append(np.corrcoef(crit[~male], g[~male])[0, 1])
        mi = np.where(male)[0]; fi = np.where(~male)[0]
        selm = mi[np.argsort(-crit[mi], kind='stable')[:NM]]
        self_ = fi[np.argsort(-crit[fi], kind='stable')[:NF]]
        # realised standardised selection differential on the criterion
        out['isel_m'].append((crit[selm].mean() - crit[mi].mean()) / crit[mi].std())
        out['isel_f'].append((crit[self_].mean() - crit[fi].mean()) / crit[fi].std())
        # --- mating
        rngM = np.random.default_rng([SEED, rep, t, 1])
        dperm = rngM.permutation(self_)
        s_of = np.repeat(selm, ngen_dams_per_sire)
        d_of = dperm[:len(s_of)]
        noff_per = n // len(s_of)            # 4
        S = np.repeat(s_of, noff_per); D = np.repeat(d_of, noff_per)
        sexpat = np.array([True] * (noff_per // 2) + [False] * (noff_per // 2))
        msex = np.tile(sexpat, len(s_of))
        # reorder so males first
        order = np.concatenate([np.where(msex)[0], np.where(~msex)[0]])
        S = S[order]; D = D[order]
        # --- meiosis
        rngS = np.random.default_rng([SEED, rep, t, 2])
        G1 = gametes(rngS, H1, H2, S); G2 = gametes(rngS, H1, H2, D)
        # --- coancestry
        CS = C[S]; CD = C[D]
        Cn = 0.25 * (CS[:, S] + CS[:, D] + CD[:, S] + CD[:, D])
        Fnew = C[S, D]
        np.fill_diagonal(Cn, 0.5 * (1 + Fnew))
        # pedigree bookkeeping (global ids)
        allS.append(off0 + S); allD.append(off0 + D); allF.append(Fnew.copy())
        off0 += n
        H1, H2, C, Fcur = G1, G2, Cn, Fnew
    return {k: np.array(v, dtype=float) for k, v in out.items()}

if __name__ == '__main__':
    import time
    for sc in ('mass', 'random', 'blup'):
        t0 = time.time(); r = run(0, sc); print(sc, f'{time.time()-t0:.2f}s')
        print(' G(sigmaA0):', np.round((r['mean'] - r['mean'][0]) / 0.5, 3))
        print(' V/VA0:', np.round(r['var'] / 0.25, 3)); print(' F:', np.round(r['F'], 4)); print(' acc:', np.round(r['acc'], 3))
