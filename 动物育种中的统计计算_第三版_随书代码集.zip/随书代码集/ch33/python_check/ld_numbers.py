# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 33 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 ld_numbers.py    依赖：numpy
import json, numpy as np
from ld_sim import BINS, CHK, N
R = {}
for f in ('ld_0_4_mu1.25.json', 'ld_4_12_mu1.25.json'): R.update(json.load(open(f)))
reps = sorted(R, key=int); nrep = len(reps); nb = len(BINS) - 1
A = lambda sub, what: np.array([[R[r][str(t)][sub][what] for t in CHK] for r in reps])
r2 = A('full', 'r2'); sv = A('full', 'sved').mean(0); tr = A('full', 'trans').mean(0); dm = A('full', 'd').mean(0); r2s = A('sub', 'r2')
eqr = 0.5 * (r2[:, -1] + r2[:, -2]); eq = eqr.mean(0); eqse = eqr.std(0, ddof=1) / np.sqrt(nrep)
eqs = (0.5 * (r2s[:, -1] + r2s[:, -2])).mean(0)
m = r2.mean(0)
it = {t: CHK.index(t) for t in CHK}
# settling: first checkpoint after which all later checkpoints within +-5% of eq
settle = []
for k in range(nb):
    fr = m[:, k] / eq[k]; ok = np.abs(fr - 1) < 0.05
    idx = next(i for i in range(len(CHK)) if ok[i:].all()); settle.append(CHK[idx])
peak = [(CHK[int(np.argmax(m[:, k]))], float(m[:, k].max() / eq[k])) for k in range(nb)]
dfin = 0.5 * (dm[-1] + dm[-2])
c = 0.5 * (1 - np.exp(-2 * dfin))
Ne_hat = (1 / (eq - 1 / (2 * N)) - 1) / (4 * c)
out = dict(nrep=nrep, eq=eq.tolist(), eqse=eqse.tolist(), sved_n=(sv[-1] + 1 / (2 * N)).tolist(), ratio=((sv[-1] + 1 / (2 * N)) / eq).tolist(), dmean_cM=(dfin * 100).tolist(),
           t10=m[it[10]].tolist(), t50=m[it[50]].tolist(), t100=m[it[100]].tolist(), t400=m[it[400]].tolist(), tr10=(tr[it[10]] + 1 / (2 * N)).tolist(), tr50=(tr[it[50]] + 1 / (2 * N)).tolist(),
           settle=settle, peak=peak, Ne_hat=Ne_hat.tolist(), eq_sub50=eqs.tolist(), sved_50=(sv[-1] + 1 / 50).tolist(),
           ncommon=float(np.mean([R[r][str(CHK[-1])]['ncommon'] for r in reps])), nloci=float(np.mean([R[r][str(CHK[-1])]['nloci'] for r in reps])),
           n_orig=[float(np.mean([R[r][str(t)]['n_orig'] for r in reps])) for t in CHK])
json.dump(out, open('ld_numbers.json', 'w'), indent=1)
for k in ('eq', 'eqse', 'sved_n', 'ratio', 'dmean_cM', 't10', 'tr10', 't50', 'tr50', 't400', 'Ne_hat', 'eq_sub50', 'sved_50'):
    print(k, np.round(out[k], 4))
print('settle', settle); print('peak', peak); print('ncommon', out['ncommon'], 'nloci', out['nloci']); print('n_orig', np.round(out['n_orig'], 1))
