# 第三十三章　育种方案的模拟与评估 —— 配套代码

**所属**：第八篇　育种规划与遗传改良优化　　**对应正文**：第三十三章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch33.ipynb` | IJulia 笔记本：11 个代码单元，约 326 行 Julia 代码，穿插与正文对应的说明 |
| `ch33.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 6 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　Bulmer 效应（正文式 33.2–33.3）
- 2　基因流法：多年进展与瞬态（正文式 33.4–33.7）
- 3　减数分裂的模拟（算法 33.1）与 Haldane 验证
- 4　从零的前向模拟器（原理实现）
- 5　常规选择 vs 基因组选择的多世代对照
- 6　共同随机数的方差缩减（正文式 33.17–33.18）
- 7　重复数与功效（正文式 33.15）
- 8　XSim.jl 的完整方案（优化实现）
- 9　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 33
```

或在 Jupyter 中打开 `ch33/ch33.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 可选单元

- 开关 `RUN_XSIM`（默认 `false`）：XSim 2.1 + JWAS 1.x（育种方案模拟）；需先实例化 `envs/xsim`：`julia --project=envs/xsim -e 'using Pkg; Pkg.instantiate()'`，再把笔记本中的开关改为 `true`。
- 开关关闭时只打印一行提示并跳过，不影响其余单元（见 `../README.md` 与正文附录 E）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
