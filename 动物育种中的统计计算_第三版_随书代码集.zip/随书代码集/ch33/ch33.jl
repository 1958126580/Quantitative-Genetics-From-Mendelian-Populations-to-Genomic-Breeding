# 本脚本由 tools/nb2jl.py 从同目录的 ch33.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 33

# %% [markdown]
# # 第三十三章　育种方案的模拟与评估 —— 配套代码
#
# **内容**
#
# 1. Bulmer 效应的递推（正文式 33.2–33.3）
# 2. **基因流法**预测多年遗传进展与瞬态过程（正文式 33.4–33.7）
# 3. **减数分裂的模拟**（算法 33.1）与 Haldane 图谱函数的验证（式 33.12–33.13）
# 4. **从零的前向模拟器**：基础群体 → LD 形成 → 多世代选择（原理实现）
# 5. LD 衰减的验收（正文式 33.11）
# 6. 常规选择 vs 基因组选择的多世代对照
# 7. **共同随机数**的方差缩减验证（正文式 33.17–33.18）
# 8. 重复数与功效（正文式 33.15）
# 9. XSim.jl 的完整方案（优化实现，需安装 XSim 与 JWAS）

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %% [markdown]
# ## 1　Bulmer 效应（正文式 33.2–33.3）

# %%
"""截断选择的选择强度与方差缩减因子 k = i(i - x)。"""
function trunc_ik(p)
    x = quantile(Normal(), 1 - p)
    i = pdf(Normal(), x)/p
    return i, i*(i - x)
end

"""Bulmer 递推：返回各代的 σ_A² 与 ΔG。"""
function bulmer(h2, p_sel; ngen=10, r_acc=nothing)
    i, k = trunc_ik(p_sel)
    s2A0 = h2; s2E = 1 - h2
    s2A = s2A0; out = NamedTuple[]
    for t in 1:ngen
        s2P = s2A + s2E
        r2 = r_acc === nothing ? s2A/s2P : r_acc^2      # 表型选择时 r² = h²
        dG = i*sqrt(r2)*sqrt(s2A)
        s2A_star = s2A*(1 - r2*k)                         # 式 (33.2)
        s2A_next = 0.5*s2A_star + 0.5*s2A0               # 式 (33.3)，双亲同样选择
        push!(out, (gen=t, s2A=s2A, dG=dG))
        s2A = s2A_next
    end
    return out
end

res = bulmer(0.3, 0.1; ngen=10)
@printf("%-8s%-14s%-14s%-16s\n", "世代", "σ_A²", "ΔG", "相对第 1 代")
for r in res
    @printf("%-8d%-14.5f%-14.5f%-16.3f\n", r.gen, r.s2A, r.dG, r.dG/res[1].dG)
end
@printf("\n平衡时 σ_A² 为初始值的 %.1f%%，ΔG 下降 %.1f%%\n",
        100*res[end].s2A/0.3, 100*(1 - res[end].dG/res[1].dG))
println("=> 忽略 Bulmer 效应会高估长期进展（正文 §33.2.1）。")

# %% [markdown]
# ## 2　基因流法：多年进展与瞬态（正文式 33.4–33.7）

# %%
"""四路径、世代重叠的基因流模拟。L 为各路径的平均世代间隔（年）。"""
function gene_flow_projection(; years=30, ages_m=8, ages_f=8,
                                sire_age=[0,1,1,1,1,1,0,0]./5, dam_age=[0,0,1,1,1,1,1,0]./5,
                                sel_diff_m=1.2, sel_diff_f=0.4)
    q = ages_m + ages_f
    P = zeros(q, q)
    for r in (1, ages_f+1)
        for a in 1:ages_m; P[r, ages_f+a] += 0.5*sire_age[a]; end
        for a in 1:ages_f; P[r, a]        += 0.5*dam_age[a];  end
    end
    for a in 2:ages_f; P[a, a-1] = 1.0; end
    for a in 2:ages_m; P[ages_f+a, ages_f+a-1] = 1.0; end
    # 选择差：施加在"被用作亲本"的年龄组上——等价地加在新生组的来源上
    s = zeros(q)
    s[1] = s[ages_f+1] = 0.5*sel_diff_m + 0.5*sel_diff_f
    m = zeros(q); traj = Vector{Float64}[]
    for t in 1:years
        m = P*m .+ s
        push!(traj, copy(m))
    end
    Lm = sum((1:ages_m) .* sire_age)          # 父本的平均世代间隔（年）
    Lf = sum((1:ages_f) .* dam_age)
    return P, s, traj, Lm, Lf
end

P, s, traj, Lm, Lf = gene_flow_projection()
dG_theory = (1.2 + 0.4)/(Lm + Lf)        # 式 (33.7) 的两路径版本（单位：σ_A/年，此处以选择差计）
yr = [traj[t][1] - (t > 1 ? traj[t-1][1] : 0.0) for t in 1:length(traj)]
@printf("%-8s%-18s\n", "年", "雌性新生组的年增量")
for t in (1, 2, 3, 5, 8, 12, 20, 30)
    @printf("%-8d%-18.5f\n", t, yr[t])
end
@printf("\n渐近年进展（模拟）= %.5f ； 式 (33.7) = (Σ选择差)/(Σ世代间隔) = %.5f\n",
        yr[end], dG_theory)
@printf("公畜平均世代间隔 = %.2f 年，母畜 = %.2f 年\n", Lm, Lf)
println("=> 前若干年是瞬态，之后收敛到四路径公式——基因流法给出了两者（正文 §33.2.2）。")

# %% [markdown]
# ## 3　减数分裂的模拟（算法 33.1）与 Haldane 验证

# %%
"""算法 33.1：一次减数分裂（Haldane 模型）。pos 为遗传图位置（摩尔根）。"""
function meiosis(h1::AbstractVector, h2::AbstractVector, pos::AbstractVector{Float64},
                 L::Float64, rng)
    k = rand(rng, Poisson(L))                           # 式 (33.12)
    xs = sort(rand(rng, k) .* L)
    cur = rand(rng, 1:2); gam = similar(h1)
    ix = 1
    @inbounds for j in eachindex(pos)
        while ix <= k && xs[ix] < pos[j]
            cur = 3 - cur; ix += 1
        end
        gam[j] = cur == 1 ? h1[j] : h2[j]
    end
    return gam
end

haldane(d) = 0.5*(1 - exp(-2d))                          # 式 (33.13)
kosambi(d) = 0.5*tanh(2d)

let rng = Xoshiro(3301), L = 1.0
    pos = [0.0, 0.05, 0.10, 0.20, 0.40, 0.80]
    h1 = zeros(Int, 6); h2 = ones(Int, 6)
    nrep = 200_000
    rec = zeros(length(pos)-1)
    for _ in 1:nrep
        g = meiosis(h1, h2, pos, L, rng)
        for j in 2:length(pos); rec[j-1] += g[1] != g[j]; end
    end
    rec ./= nrep
    @printf("%-14s%-16s%-16s%-16s\n", "距离 d (M)", "模拟重组率", "Haldane", "Kosambi")
    for j in 2:length(pos)
        d = pos[j] - pos[1]
        @printf("%-14.2f%-16.4f%-16.4f%-16.4f\n", d, rec[j-1], haldane(d), kosambi(d))
    end
    global meiosis_ok = maximum(abs.(rec .- haldane.(pos[2:end] .- pos[1]))) < 0.005
    println(meiosis_ok ? "\n✔ 模拟与 Haldane 公式吻合" : "\n✘ 不吻合")
end

# %% [markdown]
# ## 4　从零的前向模拟器（原理实现）

# %%
"""一个极简的前向模拟器：单倍型存储、减数分裂、QTL、表型、选择。"""
mutable struct Pop
    H1::Matrix{Int8}          # n × m
    H2::Matrix{Int8}
    sire::Vector{Int}
    dam::Vector{Int}
    gen::Vector{Int}
    tbv::Vector{Float64}
    y::Vector{Float64}
end

"""基础群体：从 HWE 抽样后随机交配 nburn 代以形成 LD。"""
function founder_pop(n::Int, m::Int, L::Float64; nburn=50, rng=Random.default_rng())
    pos = sort(rand(rng, m) .* L)
    p0 = 0.05 .+ 0.9 .* rand(rng, m)
    H1 = Int8.(rand(rng, n, m) .< p0'); H2 = Int8.(rand(rng, n, m) .< p0')
    for _ in 1:nburn
        N1 = similar(H1); N2 = similar(H2)
        for i in 1:n
            s = rand(rng, 1:n); d = rand(rng, 1:n)
            N1[i,:] .= meiosis(view(H1,s,:), view(H2,s,:), pos, L, rng)
            N2[i,:] .= meiosis(view(H1,d,:), view(H2,d,:), pos, L, rng)
        end
        H1, H2 = N1, N2
    end
    return H1, H2, pos
end

geno(H1, H2) = Float64.(H1) .+ Float64.(H2)

"""正文式 (33.11)：r² 随距离的衰减。"""
function ld_decay(Mg::Matrix{Float64}, pos::Vector{Float64}; bins=[0.0,0.01,0.02,0.05,0.1,0.2,0.5])
    m = size(Mg, 2); out = Float64[]
    for b in 1:length(bins)-1
        r2 = Float64[]
        for j in 1:m-1, k in j+1:min(m, j+40)
            d = pos[k] - pos[j]
            (bins[b] <= d < bins[b+1]) || continue
            sj = std(view(Mg,:,j)); sk = std(view(Mg,:,k))
            (sj < 1e-8 || sk < 1e-8) && continue
            push!(r2, cor(view(Mg,:,j), view(Mg,:,k))^2)
        end
        push!(out, isempty(r2) ? NaN : mean(r2))
    end
    return out
end

Ne_sim, m_sim, L_sim = 100, 400, 1.0
H1, H2, pos = founder_pop(Ne_sim, m_sim, L_sim; nburn=60, rng=Xoshiro(3302))
Mg0 = geno(H1, H2)
bins = [0.0,0.01,0.02,0.05,0.1,0.2,0.5]
dec = ld_decay(Mg0, pos; bins=bins)
println("LD 衰减的验收（正文式 33.11，N_e ≈ $(Ne_sim)）\n")
@printf("%-18s%-16s%-18s\n", "距离区间 (M)", "模拟 r²", "Sved: 1/(1+4Nc)")
for b in 1:length(bins)-1
    c = haldane(0.5*(bins[b] + bins[b+1]))
    @printf("[%.2f, %.2f)%-6s%-16.4f%-18.4f\n", bins[b], bins[b+1], "", dec[b], 1/(1 + 4*Ne_sim*c))
end
println("\n注：有限代数的前向模拟尚未达到完全平衡，且样本 r² 含 ~1/n 的偏差；")
println("   趋势一致即可。真实项目应用合并模拟（msprime/MaCS）建立基础群体。")

# %% [markdown]
# ## 5　常规选择 vs 基因组选择的多世代对照

# %%
"""一代育种（算法 33.2）。method ∈ (:pheno, :gblup)。"""
function breed_one!(H1, H2, pos, L, qtl, aq, h2, nsel_m, nsel_f, noff, method, rng;
                    s2e=nothing, ref=nothing)
    n = size(H1, 1)
    Mg = geno(H1, H2)
    tbv = Mg[:, qtl]*aq
    s2e === nothing && (s2e = var(tbv)*(1-h2)/h2)
    y = tbv .+ randn(rng, n).*sqrt(s2e)
    if method === :pheno
        ebv = y
    else
        p = vec(mean(Mg; dims=1))./2
        Z = Mg .- 2 .* p'; s = 2*sum(p .* (1 .- p))
        G = (Z*Z')./s + 1e-3I
        ebv = G*((G + (1-h2)/h2*I) \ (y .- mean(y)))
    end
    males = 1:2:n; females = 2:2:n
    sm = males[sortperm(ebv[males]; rev=true)[1:nsel_m]]
    sf = females[sortperm(ebv[females]; rev=true)[1:nsel_f]]
    nnew = nsel_f*noff
    N1 = Matrix{Int8}(undef, nnew, size(H1,2)); N2 = similar(N1)
    k = 0
    for d in sf, _ in 1:noff
        k += 1; sire_ = rand(rng, sm)
        N1[k,:] .= meiosis(view(H1,sire_,:), view(H2,sire_,:), pos, L, rng)
        N2[k,:] .= meiosis(view(H1,d,:), view(H2,d,:), pos, L, rng)
    end
    return N1, N2, mean(tbv), var(tbv), s2e
end

"""运行一个方案 ngen 代。"""
function run_scheme(H1, H2, pos, L, qtl, aq, h2, method; ngen=6, seed=1)
    rng = Xoshiro(seed)
    A1, A2 = copy(H1), copy(H2)
    traj = Float64[]; vars = Float64[]; s2e = nothing
    for g in 1:ngen
        A1, A2, mtbv, vtbv, s2e = breed_one!(A1, A2, pos, L, qtl, aq, h2, 10, 50, 4,
                                             method, rng; s2e=s2e)
        push!(traj, mtbv); push!(vars, vtbv)
    end
    return traj, vars
end

rngq = Xoshiro(3310)
qtl = sort(randperm(rngq, m_sim)[1:40]); aq = randn(rngq, 40)
println("每代真实育种值均值（h² = 0.2，10 公 × 50 母，每母 4 后代）\n")
tp, vp = run_scheme(H1, H2, pos, L_sim, qtl, aq, 0.2, :pheno; seed=11)
tg, vg = run_scheme(H1, H2, pos, L_sim, qtl, aq, 0.2, :gblup; seed=11)
@printf("%-8s%-16s%-16s%-16s%-16s\n", "世代", "表型选择 ū", "GBLUP ū", "表型 σ²_A", "GBLUP σ²_A")
for g in 1:length(tp)
    @printf("%-8d%-16.3f%-16.3f%-16.3f%-16.3f\n", g, tp[g], tg[g], vp[g], vg[g])
end
@printf("\n累计进展（第 %d 代 − 第 1 代）：表型 %.3f ，GBLUP %.3f\n",
        length(tp), tp[end]-tp[1], tg[end]-tg[1])

# %% [markdown]
# ## 6　共同随机数的方差缩减（正文式 33.17–33.18）

# %%
"""一个带"随机数流对齐"的简化方案比较：每个个体的孟德尔抽样、环境效应用
(世代, 个体下标) 派生的独立种子生成，使两个方案面对同样的随机性。"""
function toy_scheme(p_sel::Float64, crn_seed::Int; ngen=8, n=400, h2=0.3)
    s2A = h2; s2E = 1 - h2; u = zeros(n); traj = 0.0
    for g in 1:ngen
        # 每个个体的随机数由 (crn_seed, g, i) 派生 —— 两个方案共享
        e  = [randn(Xoshiro(hash((crn_seed, g, i, :e)))) for i in 1:n] .* sqrt(s2E)
        y  = u .+ e
        k  = round(Int, p_sel*n)
        sel = sortperm(y; rev=true)[1:k]
        ms = [randn(Xoshiro(hash((crn_seed, g, i, :m)))) for i in 1:n] .* sqrt(s2A/2)
        par = [sel[mod1(i, k)] for i in 1:n]
        par2 = [sel[mod1(i*7 + 3, k)] for i in 1:n]
        u = 0.5 .* (u[par] .+ u[par2]) .+ ms
        traj = mean(u)
    end
    return traj
end

nrep = 60
A_crn = [toy_scheme(0.10, r) for r in 1:nrep]
B_crn = [toy_scheme(0.20, r) for r in 1:nrep]
A_ind = A_crn
B_ind = [toy_scheme(0.20, 10_000 + r) for r in 1:nrep]
rho = cor(A_crn, B_crn)
@printf("方案 A（留种 10%%） vs 方案 B（留种 20%%），%d 次重复\n\n", nrep)
@printf("共同随机数：ρ = %.3f ， Var(D) = %.5f\n", rho, var(A_crn .- B_crn))
@printf("独立随机数：ρ = %.3f ， Var(D) = %.5f\n", cor(A_ind, B_ind), var(A_ind .- B_ind))
@printf("实测方差比 = %.3f ； 式 (33.18) 预测 1 - ρ = %.3f\n",
        var(A_crn .- B_crn)/var(A_ind .- B_ind), 1 - rho)
tD = mean(A_crn .- B_crn)/(std(A_crn .- B_crn)/sqrt(nrep))
@printf("\n配对 t 检验（式 33.19）：均值差 = %.4f ， t = %.2f ， p = %.2e\n",
        mean(A_crn .- B_crn), tD, 2*ccdf(TDist(nrep-1), abs(tD)))

# %% [markdown]
# ## 7　重复数与功效（正文式 33.15）

# %%
n_rep(sigma_s, delta; alpha=0.05, power=0.8) =
    2*(quantile(Normal(), 1-alpha/2) + quantile(Normal(), power))^2*sigma_s^2/delta^2

@printf("%-12s%-12s%-18s%-24s\n", "σ_s", "δ", "独立重复数", "CRN(ρ=0.9) 重复数")
for (ss, dd) in ((0.05, 0.02), (0.05, 0.01), (0.10, 0.02), (0.02, 0.01))
    ni = n_rep(ss, dd)
    @printf("%-12.2f%-12.2f%-18.0f%-24.0f\n", ss, dd, ni, ni*(1 - 0.9))
end
check("式 (33.16) 的数值例子 ≈ 98", n_rep(0.05, 0.02), 98.0; tol=0.01)

# %% [markdown]
# ## 8　XSim.jl 的完整方案（优化实现）
#
# 以下两个单元需要可选环境 `envs/xsim`（XSim 2.1.1；**XSim 的依赖声明只允许 JWAS ≤ 1.x，因此该环境中的 JWAS 为 1.2.x**，与第十八、二十二、二十三章所用的 JWAS 2.4 分属两个环境，见附录 E）。接口以 XSim 2.x / JWAS 2.4 的**源代码**为准（正文 §33.4）：
#
# * `build_genome(n_chr, n_loci)` → `build_phenome(n_qtl; n_traits, vg, h2)` 设置全局参数；
# * `Founders(n)` 建立基础群体（`Cohort`）；`mate(...; nA, nB_per_A, n_per_mate, ratio_malefemale = 1.0)` 返回 `(公, 母)`；
# * `genetic_evaluation(pool; methods = "GBLUP", idx_missing_p = 候选下标)` 返回 `pool.n × t` 的 EBV 矩阵；
# * `select(cohort, n; criteria = EBV矩阵, weights = w)`——**`criteria` 必须是 n×t 矩阵**，`weights` 长度必须等于 t，否则被静默改为全 1。
#
# 默认 `RUN_XSIM = false`（完整闭环 10 代、每代一次 JWAS-GBLUP，普通笔记本约需数分钟）。

# %%
RUN_XSIM = false            # 先实例化可选环境 envs/xsim（附录 E），再改为 true
if RUN_XSIM
    let env = joinpath(dirname(Base.active_project()), "envs", "xsim")
        isdir(env) || (env = normpath(joinpath(pwd(), "..", "envs", "xsim")))
        env in LOAD_PATH || push!(LOAD_PATH, env)   # 叠加可选环境（附录 E）
    end
    using XSim, JWAS, DataFrames
end

# %%
if RUN_XSIM
    Random.seed!(20260918)
    build_genome(n_chr = 3, n_loci = 2000)
    build_phenome(100; n_traits = 2,
                  vg = [1.0 0.5
                        0.5 1.0],
                  h2 = [0.30, 0.25])

    sires = Founders(50)
    dams  = Founders(450)
    ref   = sires + dams              # 上一代：有表型的参考群体
    w     = [0.6, 0.4]                # 经济权重（第三十二章）
    trace = DataFrame(gen = Int[], mean_H = Float64[], var_H = Float64[],
                      mean_bv1 = Float64[], mean_bv2 = Float64[])

    for g in 1:10
        males, females = mate(sires, dams; nA = 50, nB_per_A = 9,
                              n_per_mate = 2, ratio_malefemale = 1.0)
        cand  = males + females
        pool  = ref + cand
        idx_c = collect((ref.n + 1):pool.n)                    # 候选个体（公犊在前）
        ebv   = genetic_evaluation(pool; methods = "GBLUP",
                                   idx_missing_p = idx_c)      # pool.n × 2
        sires = select(males,   50;  criteria = ebv[idx_c[1:males.n], :],     weights = w)
        dams  = select(females, 450; criteria = ebv[idx_c[males.n+1:end], :], weights = w)
        ref   = cand                                           # 滚动更新参考群体
        bv    = get_BVs(cand)                                  # 真实育种值 n × 2
        H     = bv * w
        push!(trace, (g, mean(H), var(H), mean(bv[:, 1]), mean(bv[:, 2])))
    end
    show(trace; allrows = true)
    println()
    @printf("10 代综合育种值的累计进展 = %.3f（单位：综合值的遗传标准差约 %.3f）\n",
            trace.mean_H[end] - trace.mean_H[1], sqrt(w' * [1.0 0.5; 0.5 1.0] * w))
else
    println("RUN_XSIM = false：跳过 XSim + JWAS 闭环（正文 §33.4.4）。")
end

# %% [markdown]
# ## 9　自检汇总

# %%
ok = Bool[]
push!(ok, meiosis_ok)
let (i, k) = trunc_ik(0.1)
    push!(ok, check("选择强度 i(0.1) = 1.755", i, 1.7550; tol=1e-3))
    @printf("k(0.1) = %.4f （0 < k < 1）\n", k); push!(ok, 0 < k < 1)
end
push!(ok, res[end].s2A < res[1].s2A)
@printf("Bulmer：平衡方差 < 初始方差 ✔\n")
push!(ok, rho > 0.5)
@printf("CRN 使两方案相关 ρ = %.3f > 0.5 ✔\n", rho)
push!(ok, check("Haldane 小距离 ≈ d", haldane(0.001), 0.001; tol=1e-2))
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
