# 本脚本由 tools/nb2jl.py 从同目录的 ch10.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 10

# %% [markdown]
# # 第十章　选择原理与遗传进展 —— 配套代码
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | 选择强度与有限群体修正 | §10.1.3 |
# | 2 | 四途径年进展：传统 vs 基因组选择 | §10.1.4 |
# | 3 | 选择指数权重与准确性 | §10.2 |
# | 4 | 各信息源的准确性 | §10.2.4 |
# | 5 | 相关反应与间接选择 | §10.3 |
# | 6 | Bulmer 效应的模拟 | §10.4.1 |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions, BenchmarkTools
rng = Xoshiro(20260918)

# %% [markdown]
# ## 1　选择强度（正文式 10.6、10.7）

# %%
"""截断选择的选择强度 i = φ(x_ρ)/ρ（式 10.6）。"""
sel_intensity(ρ::Float64) = pdf(Normal(), quantile(Normal(), 1 - ρ)) / ρ

"""有限群体修正（Burrows 1972，式 10.7）：从 N 个候选中选 M 个。"""
function sel_intensity_finite(N::Int, M::Int)
    ρ = M/N; i = sel_intensity(ρ)
    return i - (N - M)/(2M*(N + 1)*i)
end

println(rpad("留种率 ρ", 12), rpad("i (无限)", 12), "边际收益 Δi/Δ(1/ρ)")
println("-"^48)
prev_i, prev_r = 0.0, 0.0
for ρ in (0.5, 0.2, 0.1, 0.05, 0.02, 0.01, 0.001)
    i = sel_intensity(ρ)
    @printf("%-12.3f%-12.4f%s\n", ρ, i, prev_i == 0 ? "—" : @sprintf("%.4f", (i-prev_i)/(1/ρ-1/prev_r)))
    prev_i, prev_r = i, ρ
end
println("\n→ 留种率从 10% 降到 1%（十倍），i 只从 1.755 增到 2.665（1.52 倍）。")
println("  **选择强度的边际收益递减，而近交代价超线性上升。**")

println("\n【有限群体修正】（思考题 2）")
println(rpad("N", 8), rpad("M", 8), rpad("ρ", 8), rpad("i (无限)", 12), rpad("i (有限)", 12), "相对偏差")
println("-"^62)
for (N, M) in ((1000,50), (200,10), (50,5), (20,2))
    i∞ = sel_intensity(M/N); iN = sel_intensity_finite(N, M)
    @printf("%-8d%-8d%-8.3f%-12.4f%-12.4f%.1f%%\n", N, M, M/N, i∞, iN, 100*(i∞-iN)/i∞)
end
println("→ 候选数少时修正不可忽略。")

# %% [markdown]
# ## 2　四途径年进展：传统育种 vs 基因组选择（正文式 10.9）

# %%
"""
    annual_gain(paths; σA=1.0)

四途径年遗传进展（式 10.9）。`paths` 为 (i, r, L) 的具名元组向量。
"""
function annual_gain(paths; σA::Float64 = 1.0)
    num = sum(p.i * p.r for p in paths) * σA
    den = sum(p.L for p in paths)
    return num/den, num, den
end

trad = [(i=2.5, r=0.95, L=6.5),   # SS
        (i=2.0, r=0.95, L=4.5),   # SD
        (i=1.5, r=0.50, L=4.0),   # DS
        (i=0.7, r=0.40, L=5.0)]   # DD
gs   = [(i=2.5, r=0.70, L=2.0),
        (i=2.0, r=0.70, L=2.0),
        (i=1.5, r=0.60, L=3.0),
        (i=0.7, r=0.55, L=5.0)]

gt, nt, dt = annual_gain(trad)
gg, ng, dg = annual_gain(gs)
@printf("传统育种  : ΔGy = %.4f σA   （分子 %.2f / 分母 %.1f 年）\n", gt, nt, dt)
@printf("基因组选择: ΔGy = %.4f σA   （分子 %.2f / 分母 %.1f 年）\n", gg, ng, dg)
@printf("提升 %.1f%%\n\n", 100*(gg-gt)/gt)

println("【敏感性分析】基因组预测准确性的临界值（思考题 4）")
println(rpad("GS 准确性 r_SS/SD", 20), rpad("ΔGy", 12), "相对传统")
println("-"^46)
for rgs in (0.80, 0.70, 0.60, 0.55, 0.50, 0.45, 0.40)
    g = [(i=2.5, r=rgs, L=2.0), (i=2.0, r=rgs, L=2.0),
         (i=1.5, r=0.60, L=3.0), (i=0.7, r=0.55, L=5.0)]
    v, _, _ = annual_gain(g)
    @printf("%-20.2f%-12.4f%+.1f%%\n", rgs, v, 100*(v-gt)/gt)
end
# 求临界准确性
rc = let lo=0.1, hi=0.9
    for _ in 1:60
        mid = (lo+hi)/2
        g = [(i=2.5,r=mid,L=2.0),(i=2.0,r=mid,L=2.0),(i=1.5,r=0.60,L=3.0),(i=0.7,r=0.55,L=5.0)]
        (annual_gain(g)[1] < gt) ? (lo = mid) : (hi = mid)
    end
    (lo+hi)/2
end
@printf("\n临界准确性 ≈ %.3f  ← 低于此值基因组选择不再占优\n", rc)
println("→ 基因组选择的主要收益来自缩短世代间隔 L，而非提高准确性 r。")

# %% [markdown]
# ## 3　选择指数（正文式 10.10、10.11）

# %%
"""
    selection_index(P, G, v) -> (b, r_IH)

计算选择指数权重 b = P⁻¹Gv（式 10.10）与准确性 r_IH（式 10.11）。
- `P`：信息源的表型方差协方差矩阵
- `G`：信息源与目标性状育种值的协方差矩阵
- `v`：目标性状的经济加权向量
"""
function selection_index(P::Matrix, G::Matrix, v::Vector, C::Matrix)
    b = P \ (G*v)
    σ²I = b' * P * b
    σ²H = v' * C * v
    return b, sqrt(σ²I/σ²H)
end

# 示例：两个信息源（个体自身表型、父亲 EBV）预测单一目标性状
h² = 0.25; σ²P = 100.0; σ²A = h²*σ²P
# 信息源 1：个体表型；信息源 2：父亲的表型
P = [σ²P          0.5*σ²A;
     0.5*σ²A      σ²P]
G = reshape([σ²A, 0.5*σ²A], 2, 1)
Cmat = reshape([σ²A], 1, 1)
b, r = selection_index(P, G, [1.0], Cmat)
@printf("信息源：个体表型 + 父亲表型\n")
@printf("  权重 b = (%.4f, %.4f)\n", b...)
@printf("  准确性 r_IH = %.4f\n", r)
@printf("  仅用个体表型时 r = h = %.4f  ⇒ 父亲信息使准确性提高 %.1f%%\n",
        sqrt(h²), 100*(r - sqrt(h²))/sqrt(h²))

# 验证 b'Pb = b'Gv（思考题 5）
@printf("\n【思考题 5 验证】b'Pb = %.6f ， b'Gv = %.6f  %s\n",
        (b'*P*b)[1], (b'*G*[1.0])[1], isapprox((b'*P*b)[1], (b'*G*[1.0])[1]) ? "✓" : "✗")

# %% [markdown]
# ## 4　各信息源的准确性（正文式 10.12–10.14）

# %%
acc_own(h², r, n)   = sqrt(n*h²/(1 + (n-1)*r))                    # 式 10.12
acc_hs(h², n)       = sqrt(n*0.25h²/(1 + (n-1)*0.25h²))            # 式 10.13
acc_prog(h², n)     = sqrt(n/(n + (4 - h²)/h²))                     # 式 10.14
acc_pa(rs, rd)      = 0.5*sqrt(rs^2 + rd^2)                         # 双亲平均

println("【后裔测定的准确性】（式 10.14，思考题 3）")
println(rpad("后裔数 n", 12), rpad("h²=0.20", 12), rpad("h²=0.30", 12), "h²=0.40")
println("-"^50)
for n in (10, 25, 50, 100, 200, 500)
    @printf("%-12d%-12.4f%-12.4f%.4f\n", n, acc_prog(0.20,n), acc_prog(0.30,n), acc_prog(0.40,n))
end
# 达到 0.90 所需后裔数
for h² in (0.20, 0.40)
    n = findfirst(n -> acc_prog(h², n) ≥ 0.90, 1:5000)
    @printf("\n  h² = %.2f 时，准确性达 0.90 需要 %d 个后裔\n", h², n)
end

println("\n【双亲平均的准确性上限】（正文 §10.2.4 第 4 点）")
for (rs, rd) in ((0.99,0.99), (0.95,0.70), (0.90,0.50), (0.70,0.40))
    @printf("  父 r=%.2f, 母 r=%.2f  →  r_PA = %.4f\n", rs, rd, acc_pa(rs,rd))
end
@printf("  理论上限 = 1/√2 = %.4f  ← 仅凭系谱，候选个体 EBV 的准确性上限\n", 1/sqrt(2))
println("  → 这正是基因组选择的增益空间所在。")

println("\n【同胞信息的准确性趋近 1 但很慢】（式 10.13）")
for n in (10, 20, 50, 100, 500, 1000)
    @printf("  h²=0.25，%4d 个半同胞  →  r = %.4f\n", n, acc_hs(0.25, n))
end

# %% [markdown]
# ## 5　相关反应与间接选择（正文式 10.15、10.16）

# %%
CR_over_R(rA, hX, hY) = rA*hX/hY              # 式 10.16

println("【间接选择优于直接选择的条件：r_A·h_X > h_Y】")
println(rpad("h²_X", 10), rpad("h²_Y", 10), rpad("r_A", 10), rpad("CR/R", 12), "结论")
println("-"^56)
for (h2x, h2y, rA) in ((0.45,0.10,0.55), (0.45,0.10,0.80), (0.30,0.30,0.60), (0.60,0.05,0.40))
    v = CR_over_R(rA, sqrt(h2x), sqrt(h2y))
    @printf("%-10.2f%-10.2f%-10.2f%-12.4f%s\n", h2x, h2y, rA, v,
            v > 1 ? "间接选择更优" : "直接选择更优")
end

println("\n【思考题 6】Y 只能 4 岁测量，X 在 1 岁可测：从年进展比较")
h2x, h2y, rA = 0.45, 0.10, 0.55
LY, LX = 4.0 + 1.0, 1.0 + 1.0        # 世代间隔（测量年龄 + 1）
RY_per_year = sqrt(h2y)*sqrt(h2y) / LY          # ∝ i·h_Y·σA/L，省略公共因子
CR_per_year = rA*sqrt(h2x)*sqrt(h2y) / LX
@printf("  直接选择 ΔGy ∝ %.4f （L = %.1f 年）\n", RY_per_year, LY)
@printf("  间接选择 ΔGy ∝ %.4f （L = %.1f 年）\n", CR_per_year, LX)
@printf("  → 考虑世代间隔后，间接选择优 %.1f 倍\n", CR_per_year/RY_per_year)

# %% [markdown]
# ## 6　Bulmer 效应（正文式 10.18、10.19）

# %%
"""截断选择的方差缩减因子 k = i(i − x_ρ)（式 10.18）。"""
function bulmer_k(ρ::Float64)
    x = quantile(Normal(), 1 - ρ)
    i = pdf(Normal(), x)/ρ
    return i*(i - x)
end

println("【方差缩减因子 k】")
for ρ in (0.5, 0.2, 0.1, 0.05, 0.01)
    @printf("  ρ = %.2f  →  i = %.4f ， k = %.4f\n", ρ, sel_intensity(ρ), bulmer_k(ρ))
end

"""
    bulmer_equilibrium(h²₀, ρ, r_acc; T=30)

逐代迭代 Bulmer 效应，返回每代的加性方差（以初始 σ²A = 1 为单位）。
σ²ₐ,ₜ₊₁ = ½σ²ₐ,₀ + ½σ²ₐ,ₜ(1 − k·r²ₜ)，其中 r²ₜ 是选择准确性的平方。
"""
function bulmer_trajectory(h²₀::Float64, ρ::Float64; accuracy=nothing, T::Int=30, σ²E=nothing)
    k = bulmer_k(ρ)
    σ²A0 = h²₀; σ²E = σ²E === nothing ? 1 - h²₀ : σ²E
    σ²A = σ²A0
    traj = Float64[σ²A]
    for t in 1:T
        r² = accuracy === nothing ? σ²A/(σ²A + σ²E) : accuracy^2   # 表型选择时 r² = h²ₜ
        σ²A = 0.5*σ²A0 + 0.5*σ²A*(1 - k*r²)
        push!(traj, σ²A)
    end
    return traj ./ σ²A0
end

println("\n【Bulmer 效应的多代轨迹】（相对初始 σ²A）")
println(rpad("代", 6), rpad("h²=0.4, ρ=0.1", 18), rpad("h²=0.4, GS r=0.75", 20), "h²=0.1, ρ=0.1")
println("-"^62)
t1 = bulmer_trajectory(0.4, 0.1)
t2 = bulmer_trajectory(0.4, 0.1; accuracy=0.75)
t3 = bulmer_trajectory(0.1, 0.1)
for t in (0,1,2,3,5,10,20)
    @printf("%-6d%-18.4f%-20.4f%.4f\n", t, t1[t+1], t2[t+1], t3[t+1])
end
@printf("\n平衡时方差下降：表型选择 %.1f%% ； 基因组选择 %.1f%%\n",
        100*(1-t1[end]), 100*(1-t2[end]))
println("→ 基因组选择的准确性更高，Bulmer 效应更强 —— 这是实际长期进展")
println("  低于初期预期的原因之一（正文 §10.4.1）。")

# %% [markdown]
# ### 6.1 Bulmer 效应的可逆性（思考题 8）

# %%
"""选择 T₁ 代后停止，观察 σ²A 的恢复。"""
function bulmer_recovery(h²₀, ρ, T1, T2)
    k = bulmer_k(ρ); σ²A0 = h²₀; σ²E = 1 - h²₀
    σ²A = σ²A0; traj = Float64[σ²A]
    for t in 1:T1                      # 选择期
        r² = σ²A/(σ²A + σ²E)
        σ²A = 0.5*σ²A0 + 0.5*σ²A*(1 - k*r²)
        push!(traj, σ²A)
    end
    for t in 1:T2                      # 停止选择：重组恢复配子平衡
        σ²A = 0.5*σ²A0 + 0.5*σ²A
        push!(traj, σ²A)
    end
    return traj ./ σ²A0, T1
end

traj, T1 = bulmer_recovery(0.4, 0.1, 10, 15)
println("选择 10 代后停止：")
println(rpad("代", 6), rpad("σ²A / σ²A₀", 14), "阶段")
println("-"^36)
for t in (0,1,3,5,10,11,12,13,15,20,25)
    t < length(traj) || continue
    @printf("%-6d%-14.4f%s\n", t, traj[t+1], t <= T1 ? "选择中" : "已停止选择")
end
rec = findfirst(t -> traj[t] > 0.95, T1+1:length(traj))
@printf("\n恢复到 95%% 需要 %d 代  ← Bulmer 效应是可逆的（不消耗遗传变异本金）\n",
        rec === nothing ? -1 : rec)

# %% [markdown]
# ## 本章代码小结
#
# 1. **选择强度的边际收益递减**：留种率降十倍，$i$ 只增 1.5 倍；候选数少时必须做有限群体修正。
# 2. **四途径年进展**：本例中基因组选择使 $\Delta G_y$ 提高 40%，**临界准确性约 0.44**——收益主要来自缩短 $L$。
# 3. **选择指数权重 $\mathbf b=\mathbf P^{-1}\mathbf{Gv}$** 与 $\mathbf b'\mathbf{Pb}=\mathbf b'\mathbf{Gv}$ 已验证。
# 4. **双亲平均的准确性上限是 $1/\sqrt2\approx0.707$**——基因组选择的增益空间。后裔测定可达 0.95+，代价是世代间隔。
# 5. **间接选择优于直接选择当且仅当 $r_Ah_X>h_Y$**；考虑世代间隔后结论可能反转。
# 6. **Bulmer 效应**使方差在数代内下降 10%–30%，**基因组选择下更强**；停止选择后可逆。
