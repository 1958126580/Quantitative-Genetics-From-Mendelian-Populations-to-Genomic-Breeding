# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s8_restricted.py    依赖：numpy
"""§10.3 限制性选择指数 (Kempthorne & Nordskog 1959) 的数值例：蛋鸡蛋数 / 蛋重。"""
import numpy as np
np.set_printoptions(precision=6,suppress=True)
# 性状 1 = 产蛋数 EN，性状 2 = 蛋重 EW
sP=np.array([20.0,4.5]); h2=np.array([0.20,0.50])
rg=-0.30; rp=-0.20
sA=sP*np.sqrt(h2)
G=np.array([[sA[0]**2, rg*sA[0]*sA[1]],[rg*sA[0]*sA[1], sA[1]**2]])
P=np.array([[sP[0]**2, rp*sP[0]*sP[1]],[rp*sP[0]*sP[1], sP[1]**2]])
print("sigma_A =",np.round(sA,4)); print("G =\n",np.round(G,4)); print("P =\n",np.round(P,4))
i=1.7550
v=np.array([1.0,0.0])          # 目标 H = A_EN

def report(name,b):
    sI=np.sqrt(b@P@b)
    R=i*(G@b)/sI               # 各性状的反应
    RH=i*(b@G@v)/sI            # 综合目标的反应
    rIH=(b@G@v)/np.sqrt((b@P@b)*(v@G@v))
    print(f"{name}: b = {np.round(b,6)}  sigma_I = {sI:.4f}")
    print(f"   反应：EN {R[0]:+.4f} 枚/代，EW {R[1]:+.4f} g/代； r_IH = {rIH:.4f}, ΔH = {RH:.4f}")
    return R,RH

b_un=np.linalg.solve(P,G@v)
Run,RHun=report("无限制指数",b_un)
# 限制 EW 的反应为 0：约束 c'b = 0，c = G 的第 2 列
C=G[:,[1]]
Pi=np.linalg.inv(P)
M=np.eye(2)-Pi@C@np.linalg.inv(C.T@Pi@C)@C.T
b_r=M@Pi@(G@v)
Rr,RHr=report("限制性指数",b_r)
print(f"\n限制的代价：EN 的反应由 {Run[0]:.4f} 降到 {Rr[0]:.4f}，相对效率 = {Rr[0]/Run[0]:.4f}（损失 {100*(1-Rr[0]/Run[0]):.2f}%）")
print(f"限制性指数权重之比 b2/b1 = {b_r[1]/b_r[0]:.4f}；与 b2/b1 = -g12/g22 = {-G[0,1]/G[1,1]:.4f} 比较")

# 验证：限制性指数等价于"只对 A_EN 中与 A_EW 正交的部分选择"
a_perp = np.array([1.0, -G[0,1]/G[1,1]])   # A_EN - beta*A_EW
b_perp=np.linalg.solve(P,G@a_perp)
print("\n正交化目标 H' = A_EN - (g12/g22) A_EW 的无限制指数 b =",np.round(b_perp,6))
print("与限制性指数成比例？ 比值 =",np.round(b_perp/b_r,6))

# 期望反应指数（desired gains）：要求 EN:EW 的反应比例为 (1, 0.25) 枚:g
print("\n=== 期望反应指数：指定 EN 与 EW 的反应比例 ===")
for dg in [np.array([1.0,0.0]),np.array([1.0,0.25]),np.array([1.0,0.5]),np.array([1.0,-0.25])]:
    b_d=np.linalg.solve(G,dg)          # G b ∝ 期望反应向量 -> b = G^{-1} d
    sI=np.sqrt(b_d@P@b_d); R=i*(G@b_d)/sI
    print(f"期望比例 {dg}: b={np.round(b_d,6)}  实际反应 EN {R[0]:+.4f} 枚, EW {R[1]:+.4f} g, 比例 {R[1]/R[0]:+.4f}")

# 多代的"限制漂移"：若参数估计有误，限制不再精确
print("\n=== 参数误设时限制的失效（真 r_g = -0.30，指数按误设的 r_g 构造）===")
for rg_a in [-0.50,-0.40,-0.30,-0.20,-0.10,0.0]:
    Ga=np.array([[sA[0]**2, rg_a*sA[0]*sA[1]],[rg_a*sA[0]*sA[1], sA[1]**2]])
    Ca=Ga[:,[1]]
    Ma=np.eye(2)-Pi@Ca@np.linalg.inv(Ca.T@Pi@Ca)@Ca.T
    ba=Ma@Pi@(Ga@v)
    sI=np.sqrt(ba@P@ba); R=i*(G@ba)/sI
    print(f"假定 r_g={rg_a:+.2f}: EN {R[0]:+.4f} 枚/代, EW {R[1]:+.4f} g/代（应为 0）")
