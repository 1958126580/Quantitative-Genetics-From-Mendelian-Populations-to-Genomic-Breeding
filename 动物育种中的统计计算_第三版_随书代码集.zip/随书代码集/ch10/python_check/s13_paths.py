# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s13_paths.py    依赖：numpy, scipy
"""§10.1 四路径年遗传进展的数值例（奶牛 + 猪），准确性全部由指数公式算出。"""
import numpy as np
from scipy.stats import norm
np.set_printoptions(precision=6,suppress=True)
def ii(p): 
    x=norm.isf(p); return norm.pdf(x)/p
def r_prog(n,h2): return np.sqrt(n/(n+(4-h2)/h2))
def r_own(n,h2,t): return np.sqrt(n*h2/(1+(n-1)*t))
def r_own_sire(n,h2,t,rs):
    """自身 n 次记录均值 + 父亲 EBV（准确性 rs）"""
    P=np.array([[(1+(n-1)*t)/n, 0.5*rs*rs*h2],[0.5*rs*rs*h2, rs*rs*h2]])
    g=np.array([h2,0.5*rs*rs*h2])
    b=np.linalg.solve(P,g); return np.sqrt(b@g/h2)
def r_idx3(h2,nfs,nhs,c2):
    tf=0.5*h2+c2; th=0.25*h2
    P=np.array([[1.0,tf,th],[tf,(1+(nfs-1)*tf)/nfs,th],[th,th,(1+(nhs-1)*th)/nhs]])
    g=np.array([h2,0.5*h2,0.25*h2]); b=np.linalg.solve(P,g)
    return np.sqrt(b@g/h2)

def fourpath(rows,label):
    tot_num=sum(r['i']*r['r'] for r in rows); tot_L=sum(r['L'] for r in rows)
    print(f"\n--- {label} ---")
    print(f"{'途径':<6}{'留种率 p':>9}{'i':>8}{'r':>8}{'L(年)':>8}{'i·r':>9}{'贡献占比':>9}")
    for r in rows:
        print(f"{r['n']:<6}{r['p']:>9.3f}{r['i']:>8.4f}{r['r']:>8.4f}{r['L']:>8.2f}{r['i']*r['r']:>9.4f}{r['i']*r['r']/tot_num:>9.3f}")
    print(f"{'合计':<6}{'':>9}{'':>8}{'':>8}{tot_L:>8.2f}{tot_num:>9.4f}")
    print(f"ΔG_y = {tot_num:.4f} / {tot_L:.2f} = {tot_num/tot_L:.4f} σ_A/年；ΔG_代 = {tot_num/4:.4f} σ_A/代（代间隔均值 {tot_L/4:.2f} 年）")
    return tot_num/tot_L, tot_num, tot_L

# ===== 奶牛：产奶量 h2=0.25，重复力 t=0.50 =====
h2=0.25; t=0.50
r_bull=r_prog(100,h2)
print(f"奶牛：100 个女儿的后裔测定准确性 r = {r_bull:.4f}（n=100, h²={h2}, k={(4-h2)/h2:.1f}）")
r_cow3=r_own_sire(3,h2,t,r_bull); r_cow2=r_own_sire(2,h2,t,r_bull)
print(f"母牛 3 胎 + 父亲 EBV：r = {r_cow3:.4f}；2 胎 + 父亲 EBV：r = {r_cow2:.4f}")
print(f"（仅 3 胎自身记录 r = {r_own(3,h2,t):.4f}；仅父亲 EBV r = {0.5*r_bull:.4f}）")
trad=[dict(n='SS',p=0.05,i=ii(0.05),r=r_bull,L=6.5),
      dict(n='SD',p=0.20,i=ii(0.20),r=r_bull,L=6.0),
      dict(n='DS',p=0.005,i=ii(0.005),r=r_cow3,L=5.0),
      dict(n='DD',p=0.85,i=ii(0.85),r=r_cow2,L=4.5)]
gy_t,num_t,L_t=fourpath(trad,"传统奶牛（后裔测定）")
rg_b, rg_h = 0.70, 0.62
gs=[dict(n='SS',p=0.02,i=ii(0.02),r=rg_b,L=2.0),
    dict(n='SD',p=0.10,i=ii(0.10),r=rg_b,L=2.0),
    dict(n='DS',p=0.01,i=ii(0.01),r=rg_h,L=2.5),
    dict(n='DD',p=0.85,i=ii(0.85),r=rg_h,L=4.0)]
gy_g,num_g,L_g=fourpath(gs,f"基因组选择（青年公牛 r={rg_b}，青年母牛 r={rg_h}）")
print(f"\n基因组 / 传统 = {gy_g/gy_t:.4f}（提高 {100*(gy_g/gy_t-1):.1f}%）")
print(f"分解：分子（选择差合计）{num_g/num_t:.4f} 倍，分母（世代间隔合计）{L_g/L_t:.4f} 倍")
# 临界准确性
from scipy.optimize import brentq
f=lambda rr: (ii(0.02)*rr+ii(0.10)*rr+ii(0.01)*rr*rg_h/rg_b+ii(0.85)*rr*rg_h/rg_b)/L_g - gy_t
rcrit=brentq(f,0.01,0.99)
print(f"若公牛基因组准确性降到 {rcrit:.4f}（母牛按同比例降到 {rcrit*rg_h/rg_b:.4f}），两方案年进展相等")

# ===== 猪：生长速度 h2=0.30，同窝效应 c2=0.08 =====
print("\n"+"="*70)
h2p=0.30; c2=0.08
r_pig=r_idx3(h2p,10,40,c2)
print(f"猪：自身 + 10 全同胞 + 40 半同胞的指数准确性 r = {r_pig:.4f}（h²={h2p}, c²={c2}）")
r_sow=r_idx3(h2p,10,40,c2)   # 同一指数
pig=[dict(n='SS',p=0.02,i=ii(0.02),r=r_pig,L=1.4),
     dict(n='SD',p=0.08,i=ii(0.08),r=r_pig,L=1.4),
     dict(n='DS',p=0.15,i=ii(0.15),r=r_sow,L=1.8),
     dict(n='DD',p=0.50,i=ii(0.50),r=r_sow,L=2.0)]
gy_p,_,_=fourpath(pig,"猪核心群（同胞测定 + 自身性能）")
r_pg=0.62
pigg=[dict(n='SS',p=0.02,i=ii(0.02),r=r_pg,L=1.0),
      dict(n='SD',p=0.08,i=ii(0.08),r=r_pg,L=1.0),
      dict(n='DS',p=0.15,i=ii(0.15),r=r_pg,L=1.5),
      dict(n='DD',p=0.50,i=ii(0.50),r=r_pg,L=1.8)]
gy_pg,_,_=fourpath(pigg,f"猪 + 基因组选择（r={r_pg}）")
print(f"\n猪：基因组 / 传统 = {gy_pg/gy_p:.4f}（提高 {100*(gy_pg/gy_p-1):.1f}%）")
print("\n对照：奶牛的世代间隔缩短幅度大得多，这是两个物种收益差异的根源。")
