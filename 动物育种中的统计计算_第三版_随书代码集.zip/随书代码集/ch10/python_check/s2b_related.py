# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2b_related.py    依赖：numpy, scipy
"""全同胞家系 + 共同环境 c^2 时，按表型选择的实际遗传反应。"""
import numpy as np
from scipy.stats import norm
rng = np.random.default_rng(7)
NREP=20000
def run(nfam,nper,p,h2,c2):
    sA=np.sqrt(h2); sC=np.sqrt(c2); sE=np.sqrt(1-h2-c2)
    N=nfam*nper; M=int(round(p*N))
    dS=[];dA=[]
    for _ in range(NREP):
        pm = rng.standard_normal(nfam)*sA/np.sqrt(2)     # 双亲均值育种值
        A  = pm[:,None] + sA/np.sqrt(2)*rng.standard_normal((nfam,nper))
        C  = sC*rng.standard_normal(nfam)[:,None]
        P  = A + C + sE*rng.standard_normal((nfam,nper))
        A=A.ravel();P=P.ravel()
        idx=np.argsort(P)[::-1][:M]
        dS.append(P[idx].mean()-P.mean()); dA.append(A[idx].mean())
    ip=norm.pdf(norm.isf(M/N))/(M/N)
    return N,M,ip,np.mean(dS),ip*h2,np.mean(dA)
print(f"{'设计':>22} {'h2':>5} {'c2':>5} {'i_pred':>7} {'i_实现':>7} {'ΔA_pred':>8} {'ΔA_实现':>8} {'损失%':>7}")
for nfam,nper,h2,c2 in [(20,10,0.30,0.00),(20,10,0.30,0.10),(20,10,0.30,0.20),
                        (10,20,0.30,0.20),(20,10,0.15,0.20)]:
    N,M,ip,s,Ap,a = run(nfam,nper,0.10,h2,c2)
    print(f"{str(nfam)+'家系×'+str(nper):>22} {h2:>5.2f} {c2:>5.2f} {ip:>7.4f} {s:>7.4f} {Ap:>8.4f} {a:>8.4f} {100*(Ap-a)/Ap:>7.2f}")
