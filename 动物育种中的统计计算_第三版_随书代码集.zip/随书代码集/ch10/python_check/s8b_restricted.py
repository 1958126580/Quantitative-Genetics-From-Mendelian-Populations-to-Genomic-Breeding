# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s8b_restricted.py    依赖：numpy
"""限制性指数：影子价格解释、与期望反应指数的关系、三性状情形。"""
import numpy as np
np.set_printoptions(precision=6,suppress=True)
i=1.7550
def resp(b,P,G): 
    sI=np.sqrt(b@P@b); return i*(G@b)/sI, sI

# ---------- 两性状 ----------
sP=np.array([20.0,4.5]); h2=np.array([0.20,0.50]); rg=-0.30; rp=-0.20
sA=sP*np.sqrt(h2)
G=np.array([[sA[0]**2,rg*sA[0]*sA[1]],[rg*sA[0]*sA[1],sA[1]**2]])
P=np.array([[sP[0]**2,rp*sP[0]*sP[1]],[rp*sP[0]*sP[1],sP[1]**2]])
v=np.array([1.0,0.0]); Pi=np.linalg.inv(P)
C=G[:,[1]]
lam=float((np.linalg.inv(C.T@Pi@C)@(C.T@Pi@(G@v))).ravel()[0])
b_r=Pi@(G@v-C*lam)
b_alt=Pi@(G@(v-lam*np.array([0.0,1.0])))
b_kn=(np.eye(2)-Pi@C@np.linalg.inv(C.T@Pi@C)@C.T)@Pi@(G@v)
b_dg=np.linalg.solve(G,np.array([1.0,0.0]))
print("影子价格 lambda =",round(lam,6))
print("b (式10.17)        =",np.round(b_kn,6))
print("b = P^-1(Gv - Cλ)  =",np.round(b_r,6))
print("b = P^-1 G(v-λe2)  =",np.round(b_alt,6))
print("期望反应指数 G^-1 d  =",np.round(b_dg,6),"  与 b_kn 的比值 =",np.round(b_kn/b_dg,6))
R,_=resp(b_kn,P,G); print("限制性指数反应：",np.round(R,6))

# ---------- 三性状：目标 = 2 个性状的加权，限制 1 个性状 ----------
print("\n=== 三性状：目标 H = v1 A1 + v2 A2，限制 A3 的反应为 0 ===")
sP3=np.array([20.0,4.5,3.0]); h23=np.array([0.20,0.50,0.35])
rg3=np.array([[1.0,-0.30,0.25],[-0.30,1.0,0.40],[0.25,0.40,1.0]])
rp3=np.array([[1.0,-0.20,0.15],[-0.20,1.0,0.25],[0.15,0.25,1.0]])
sA3=sP3*np.sqrt(h23)
G3=np.outer(sA3,sA3)*rg3; P3=np.outer(sP3,sP3)*rp3
v3=np.array([1.0,2.0,0.0]); Pi3=np.linalg.inv(P3)
C3=G3[:,[2]]
b_un3=Pi3@(G3@v3); R3u,sI=resp(b_un3,P3,G3)
b_kn3=(np.eye(3)-Pi3@C3@np.linalg.inv(C3.T@Pi3@C3)@C3.T)@Pi3@(G3@v3)
R3r,_=resp(b_kn3,P3,G3)
lam3=float((np.linalg.inv(C3.T@Pi3@C3)@(C3.T@Pi3@(G3@v3))).ravel()[0])
b_dg3=np.linalg.solve(G3,np.array([R3r[0],R3r[1],0.0]))
print("无限制 b =",np.round(b_un3,6)," 反应 =",np.round(R3u,6)," ΔH =",round(float(i*(b_un3@G3@v3)/np.sqrt(b_un3@P3@b_un3)),6))
print("限制性 b =",np.round(b_kn3,6)," 反应 =",np.round(R3r,6)," ΔH =",round(float(i*(b_kn3@G3@v3)/np.sqrt(b_kn3@P3@b_kn3)),6))
print("影子价格 λ =",round(lam3,6),"；等价的惩罚目标 H' = A1 + 2A2 - %.6f A3"%lam3)
print("检验 P^-1 G (v - λ e3) =",np.round(Pi3@(G3@(v3-lam3*np.array([0,0,1.0]))),6))
print("与限制性 b 的比值 =",np.round(Pi3@(G3@(v3-lam3*np.array([0,0,1.0])))/b_kn3,6))
dH=float(i*(b_un3@G3@v3)/np.sqrt(b_un3@P3@b_un3)); dHr=float(i*(b_kn3@G3@v3)/np.sqrt(b_kn3@P3@b_kn3))
print("限制的代价：ΔH 由 %.6f 降到 %.6f，相对效率 %.6f（损失 %.3f%%）"%(dH,dHr,dHr/dH,100*(1-dHr/dH)))
# 期望反应指数（与限制性指数不同）
print("按期望反应 d=(1,1,0) 的指数 b =",np.round(np.linalg.solve(G3,np.array([1.0,1.0,0.0])),6))
Rd,_=resp(np.linalg.solve(G3,np.array([1.0,1.0,0.0])),P3,G3)
print("   反应 =",np.round(Rd,6)," ΔH =",round(float(i*(np.linalg.solve(G3,np.array([1.0,1.0,0.0]))@G3@v3)/np.sqrt(np.linalg.solve(G3,np.array([1.0,1.0,0.0]))@P3@np.linalg.solve(G3,np.array([1.0,1.0,0.0])))),6))
