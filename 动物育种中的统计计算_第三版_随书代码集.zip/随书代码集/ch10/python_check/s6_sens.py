# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s6_sens.py    依赖：numpy
"""§10.2.x 指数权重对参数误设的敏感性。相对效率 RE = b'g / sqrt(b'Pb * g'P^{-1}g)."""
import numpy as np
np.set_printoptions(precision=4, suppress=True)

def RE(b,P,g):
    return (b@g)/np.sqrt((b@P@b)*(g@np.linalg.solve(P,g)))

# ================= 情形 1：单性状、三信息源（自身 / 10 全同胞均值 / 40 半同胞均值） =================
def PG(h2,c2,nfs=10,nhs=40):
    tf=0.5*h2+c2; th=0.25*h2
    P=np.array([[1.0, tf, th],
                [tf,(1+(nfs-1)*tf)/nfs, th],
                [th, th,(1+(nhs-1)*th)/nhs]])
    g=np.array([h2,0.5*h2,0.25*h2])
    return P,g
h2T,c2T=0.25,0.10
PT,gT=PG(h2T,c2T); bT=np.linalg.solve(PT,gT)
print("真参数 h2=0.25, c2=0.10:  b =",np.round(bT,4),"  r_IA =",round(np.sqrt(bT@gT/h2T),4))
print("\n=== 情形 1：单性状指数，参数误设的相对效率 ===")
print(f"{'误设':<26}{'假定 h2':>9}{'假定 c2':>9}{'b1':>8}{'b2':>8}{'b3':>8}{'RE':>9}{'损失%':>8}")
cases=[("无误设",1.0,1.0),("h2 +20%",1.2,1.0),("h2 -20%",0.8,1.0),("h2 +50%",1.5,1.0),("h2 -50%",0.5,1.0),
       ("c2 +50%",1.0,1.5),("c2 -50%",1.0,0.5),("c2 误设为 0",1.0,0.0),
       ("h2+50% 且 c2-50%",1.5,0.5),("h2-50% 且 c2+50%",0.5,1.5),
       ("h2 +100%",2.0,1.0),("h2 -75%",0.25,1.0)]
for nm,fh,fc in cases:
    ha,ca=h2T*fh,c2T*fc
    Pa,ga=PG(ha,ca); ba=np.linalg.solve(Pa,ga)
    re=RE(ba,PT,gT)
    print(f"{nm:<26}{ha:>9.4f}{ca:>9.4f}{ba[0]:>8.4f}{ba[1]:>8.4f}{ba[2]:>8.4f}{re:>9.5f}{100*(1-re):>8.3f}")

# ================= 情形 2：三性状综合育种值指数（自身表型） =================
sP=np.array([50.0,0.18,2.2])              # ADG(g/d), FCR, 背膘(mm)
h2=np.array([0.30,0.25,0.45])
rg=np.array([[1.0,-0.55,0.15],[-0.55,1.0,0.30],[0.15,0.30,1.0]])
rp=np.array([[1.0,-0.35,0.10],[-0.35,1.0,0.20],[0.10,0.20,1.0]])
v =np.array([0.30,-180.0,-9.0])           # 元/单位
sA=sP*np.sqrt(h2)
G=np.outer(sA,sA)*rg
P=np.outer(sP,sP)*rp
print("\n=== 情形 2：三性状指数（真参数） ===")
print("G 的特征值",np.round(np.linalg.eigvalsh(G),4)," P 的特征值",np.round(np.linalg.eigvalsh(P),4))
b=np.linalg.solve(P,G@v)
sH=np.sqrt(v@G@v); sI=np.sqrt(b@P@b)
print("b =",np.round(b,4))
print(f"sigma_H = {sH:.4f} 元,  sigma_I = {sI:.4f} 元,  r_IH = {sI/sH:.4f}")
i=1.7550
Rj=i*(G@b)/sI
print(f"留种率 10% 时各性状的反应：ADG {Rj[0]:.4f} g/d, FCR {Rj[1]:.5f}, 背膘 {Rj[2]:.4f} mm；ΔH = {i*sI:.4f} 元")

def make(h2a,rga,rpa,sPa):
    sAa=sPa*np.sqrt(h2a)
    return np.outer(sPa,sPa)*rpa, np.outer(sAa,sAa)*rga
gT2=G@v
print("\n=== 情形 2：参数/经济权重误设的相对效率 ===")
print(f"{'误设':<30}{'RE':>9}{'损失%':>9}")
def rep(nm,Pa,Ga,va):
    ba=np.linalg.solve(Pa,Ga@va)
    re=RE(ba,P,gT2)
    print(f"{nm:<30}{re:>9.5f}{100*(1-re):>9.3f}")
    return re
rep("无误设",P,G,v)
for f,lab in [(1.2,"+20%"),(0.8,"-20%"),(1.5,"+50%"),(0.5,"-50%")]:
    Pa,Ga=make(np.clip(h2*f,0.01,0.99),rg,rp,sP); rep(f"全部 h2 {lab}",Pa,Ga,v)
for f,lab in [(1.2,"+20%"),(0.8,"-20%"),(1.5,"+50%"),(0.5,"-50%")]:
    rga=rg.copy()
    for a in range(3):
        for bq in range(3):
            if a!=bq: rga[a,bq]=np.clip(rg[a,bq]*f,-0.99,0.99)
    ev=np.linalg.eigvalsh(rga)
    Pa,Ga=make(h2,rga,rp,sP); rep(f"全部 r_g {lab} (minEig {ev.min():.3f})",Pa,Ga,v)
rga=rg.copy(); rga[0,1]=rga[1,0]=0.0
Pa,Ga=make(h2,rga,rp,sP); rep("r_g(ADG,FCR) 误设为 0",Pa,Ga,v)
rga=rg.copy(); rga[0,1]=rga[1,0]=+0.55
Pa,Ga=make(h2,rga,rp,sP); rep("r_g(ADG,FCR) 符号弄反",Pa,Ga,v)
for f,lab in [(1.5,"+50%"),(0.5,"-50%"),(2.0,"+100%")]:
    va=v.copy(); va[1]=v[1]*f; rep(f"FCR 经济权重 {lab}",P,G,va)
va=v.copy(); va[2]=0.0; rep("忽略背膘的经济权重",P,G,va)
va=np.array([0.30,0.0,0.0]); rep("只按 ADG 选择（单性状）",P,G,va)

print("\n=== 情形 2 续：单个性状的 h2 误设（非等比例）===")
print(f"{'误设':<30}{'RE':>9}{'损失%':>9}")
for k,tn in enumerate(['ADG','FCR','背膘']):
    for f,lab in [(1.2,'+20%'),(0.8,'-20%'),(1.5,'+50%'),(0.5,'-50%')]:
        h2a=h2.copy(); h2a[k]=np.clip(h2[k]*f,0.01,0.99)
        Pa,Ga=make(h2a,rg,rp,sP)
        ba=np.linalg.solve(Pa,Ga@v); re=RE(ba,P,gT2)
        print(f"{'只有 '+tn+' 的 h2 '+lab:<30}{re:>9.5f}{100*(1-re):>9.3f}")

print("\n=== 情形 2 续：全部参数随机扰动（模拟估计误差）===")
rng=np.random.default_rng(2024)
for cv in [0.10,0.20,0.50]:
    res=[]
    for _ in range(20000):
        h2a=np.clip(h2*(1+cv*rng.standard_normal(3)),0.02,0.95)
        rga=rg.copy()
        for a in range(3):
            for bq in range(a+1,3):
                val=np.clip(rg[a,bq]+cv*rng.standard_normal()*0.5,-0.95,0.95)
                rga[a,bq]=rga[bq,a]=val
        rpa=rp.copy()
        for a in range(3):
            for bq in range(a+1,3):
                val=np.clip(rp[a,bq]+cv*rng.standard_normal()*0.3,-0.95,0.95)
                rpa[a,bq]=rpa[bq,a]=val
        if np.linalg.eigvalsh(rga).min()<=0 or np.linalg.eigvalsh(rpa).min()<=0: continue
        Pa,Ga=make(h2a,rga,rpa,sP)
        ba=np.linalg.solve(Pa,Ga@v)
        res.append(RE(ba,P,gT2))
    res=np.array(res)
    print(f"扰动 CV={cv:.2f}  n={len(res)}  RE 均值 {res.mean():.5f}  5% 分位 {np.percentile(res,5):.5f}  最小 {res.min():.5f}")
