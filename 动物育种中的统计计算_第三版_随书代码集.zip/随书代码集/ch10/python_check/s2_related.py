# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_related.py    依赖：numpy, scipy
"""候选个体间有亲缘时，实现的选择差与遗传反应低于独立候选的预测。"""
import numpy as np
from scipy.stats import norm

rng = np.random.default_rng(101)
h2 = 0.30; sA = np.sqrt(h2); sE = np.sqrt(1-h2)   # sigma_P = 1
NREP = 20000

def run(nfam, nper, p, kind='HS'):
    """kind='HS': 半同胞家系（共享父本育种值的 1/2）；'FS': 全同胞家系"""
    N = nfam*nper; M = int(round(p*N))
    dS = []; dA = []
    for _ in range(NREP):
        if kind=='HS':
            As = rng.standard_normal(nfam)*sA                      # 父本育种值
            A  = 0.5*As[:,None] + np.sqrt(1-0.25)*sA*rng.standard_normal((nfam,nper))
        else:
            Asd = rng.standard_normal(nfam)*sA*np.sqrt(0.5)*np.sqrt(2)  # 双亲均值，方差 sA^2/2
            Asd = rng.standard_normal(nfam)*sA/np.sqrt(2)
            A  = Asd[:,None] + sA/np.sqrt(2)*rng.standard_normal((nfam,nper))
        P = A + sE*rng.standard_normal((nfam,nper))
        A=A.ravel(); P=P.ravel()
        idx = np.argsort(P)[::-1][:M]
        dS.append(P[idx].mean()-P.mean()); dA.append(A[idx].mean())
    return np.mean(dS), np.mean(dA), N, M

print(f"{'设计':>26} {'N':>5} {'M':>4} {'i_pred':>7} {'i_实现':>7} {'ΔA_pred':>8} {'ΔA_实现':>8} {'反应损失%':>9}")
out=[]
for kind,nfam,nper,p in [('HS',200,1,0.10),('HS',20,10,0.10),('HS',10,20,0.10),('HS',5,40,0.10),
                         ('FS',20,10,0.10),('FS',10,20,0.10)]:
    s,a,N,M = run(nfam,nper,p,kind)
    ip = norm.pdf(norm.isf(M/N))/(M/N)
    Ap = ip*h2   # 独立候选、表型选择：ΔA = i h^2 σ_P
    out.append((kind,nfam,nper,N,M,ip,s,Ap,a,100*(Ap-a)/Ap))
    print(f"{kind+' '+str(nfam)+'家系×'+str(nper):>26} {N:>5} {M:>4} {ip:>7.4f} {s:>7.4f} {Ap:>8.4f} {a:>8.4f} {100*(Ap-a)/Ap:>9.2f}")
