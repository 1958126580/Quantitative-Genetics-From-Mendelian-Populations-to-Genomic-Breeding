# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5_blup_eq.py    依赖：numpy
"""§10.2.x 选择指数与 BLUP 的数值等价（固定效应已知）。"""
import numpy as np
np.set_printoptions(precision=8, suppress=True)
h2=0.25; lam=(1-h2)/h2

def Ainv_simple(n):
    """个体 1 + n 个后裔（母本未知且互不相关）的 A^{-1}（Henderson 规则）"""
    m=n+1
    Ai=np.zeros((m,m))
    Ai[0,0]+=1.0                     # 个体 1 双亲未知：贡献 1
    for j in range(1,m):             # 后裔 j：父=1，母未知 -> b = 1 - 1/4 = 3/4, d = 1/b = 4/3
        d=4.0/3.0
        Ai[j,j]+=d
        Ai[j,0]+=-0.5*d; Ai[0,j]+=-0.5*d
        Ai[0,0]+=0.25*d
    return Ai

def blup(n, y_prog, y_own=None):
    m=n+1
    Z=np.zeros((0,m))
    yy=[]
    rows=[]
    if y_own is not None:
        r=np.zeros(m); r[0]=1; rows.append(r); yy.append(y_own)
    for j in range(1,m):
        r=np.zeros(m); r[j]=1; rows.append(r); yy.append(y_prog[j-1])
    Z=np.array(rows); yy=np.array(yy)
    C=Z.T@Z+Ainv_simple(n)*lam
    return np.linalg.solve(C, Z.T@yy)

rng=np.random.default_rng(3)
for n in [10,50,100]:
    y=rng.standard_normal(n)*1.0
    # --- 仅后裔信息 ---
    u=blup(n,y)
    t=0.25*h2
    b=0.5*h2/((1+(n-1)*t)/n)
    idx=b*y.mean()
    print(f"n={n:>4} 仅后裔: BLUP û1={u[0]:.8f}  指数={idx:.8f}  差={u[0]-idx:.2e}")
    # --- 自身 + 后裔 ---
    y0=rng.standard_normal()
    u2=blup(n,y,y0)
    P=np.array([[1.0,0.5*h2],[0.5*h2,(1+(n-1)*t)/n]]); g=np.array([h2,0.5*h2])
    bb=np.linalg.solve(P,g); idx2=bb@np.array([y0,y.mean()])
    print(f"        自身+后裔: BLUP û1={u2[0]:.8f}  指数={idx2:.8f}  差={u2[0]-idx2:.2e}")
