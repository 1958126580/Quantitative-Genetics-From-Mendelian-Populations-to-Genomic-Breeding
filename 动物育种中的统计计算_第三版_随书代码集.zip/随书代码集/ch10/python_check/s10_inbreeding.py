# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s10_inbreeding.py    依赖：numpy
"""§10.4 近交累积：ΔF=1/(8Nm)+1/(8Nf) 在随机 / 表型 / BLUP 选择下的实际表现。"""
import numpy as np, time
np.set_printoptions(precision=5,suppress=True)

NM,NF=10,50; NOFF=200; NGEN=10; H2=0.25; LAM=(1-H2)/H2
REPS=8

def run(method, seed):
    rng=np.random.default_rng(seed)
    n0=NM+NF
    sire=np.full(n0,-1,dtype=np.int64); dam=np.full(n0,-1,dtype=np.int64)
    sex=np.array([0]*NM+[1]*NF)                     # 0=公 1=母
    A_=rng.standard_normal(n0)                      # 育种值（σ_A=1）
    y=np.full(n0,np.nan)
    # A 矩阵（增量构建）
    NMAX=n0+NGEN*NOFF
    Amat=np.zeros((NMAX,NMAX)); Amat[:n0,:n0]=np.eye(n0)
    F=np.zeros(NMAX)
    cur_s=np.arange(NM); cur_d=np.arange(NM,n0)
    n=n0
    Fbar=[0.0]; Gbar=[A_.mean()]
    for g in range(NGEN):
        ss=rng.choice(cur_s,NOFF); dd=rng.choice(cur_d,NOFF)
        idx=np.arange(n,n+NOFF)
        # 增量更新 A
        for t,(i,s,d) in enumerate(zip(idx,ss,dd)):
            row=0.5*(Amat[s,:i]+Amat[d,:i])
            Amat[i,:i]=row; Amat[:i,i]=row
            Amat[i,i]=1.0+0.5*Amat[s,d]
            F[i]=Amat[i,i]-1.0
        ms=np.sqrt(0.5*(1-0.5*(F[ss]+F[dd])))       # 孟德尔抽样标准差
        Anew=0.5*(A_[ss]+A_[dd])+rng.standard_normal(NOFF)*ms
        ynew=Anew+rng.standard_normal(NOFF)*np.sqrt((1-H2)/H2)   # σ_A=1 -> σ_e²=(1-h²)/h²
        sire=np.concatenate([sire,ss]); dam=np.concatenate([dam,dd])
        sexnew=np.array([0]*(NOFF//2)+[1]*(NOFF//2)); rng.shuffle(sexnew)
        sex=np.concatenate([sex,sexnew]); A_=np.concatenate([A_,Anew]); y=np.concatenate([y,ynew])
        n+=NOFF
        Fbar.append(F[idx].mean()); Gbar.append(Anew.mean())
        # --- 选择依据 ---
        if method=='random':
            crit=rng.standard_normal(n)
        elif method=='pheno':
            crit=np.where(np.isnan(y),-1e9,np.nan_to_num(y))
        else:  # BLUP
            Ai=np.zeros((n,n))
            for i in range(n):
                s,d=sire[i],dam[i]
                if s>=0 and d>=0:
                    di=0.5-0.25*(F[s]+F[d]); w=1.0/di
                    Ai[i,i]+=w
                    Ai[i,s]-=0.5*w; Ai[s,i]-=0.5*w; Ai[i,d]-=0.5*w; Ai[d,i]-=0.5*w
                    Ai[s,s]+=0.25*w; Ai[d,d]+=0.25*w; Ai[s,d]+=0.25*w; Ai[d,s]+=0.25*w
                else:
                    Ai[i,i]+=1.0
            has=~np.isnan(y)
            C=Ai*LAM; C[np.arange(n)[has],np.arange(n)[has]]+=1.0
            rhs=np.where(has,np.nan_to_num(y),0.0)
            crit=np.linalg.solve(C,rhs)
        cand=idx
        males=cand[sex[cand]==0]; females=cand[sex[cand]==1]
        cur_s=males[np.argsort(crit[males])[::-1][:NM]]
        cur_d=females[np.argsort(crit[females])[::-1][:NF]]
    return np.array(Fbar), np.array(Gbar)

pred=1/(8*NM)+1/(8*NF)
print(f"NM={NM}, NF={NF}, 每代 {NOFF} 后代，选 {NM} 公 {NF} 母，h2={H2}，{NGEN} 代，{REPS} 次重复")
print(f"公式预测 ΔF = 1/(8×{NM}) + 1/(8×{NF}) = {pred:.5f} /代；Ne = {1/(2*pred):.2f}")
print(f"\n{'方法':<10}{'F_10':>9}{'ΔF(实现)':>10}{'Ne(实现)':>10}{'ΔF/预测':>9}{'10 代遗传进展(σ_A)':>18}")
res={}
for m in ['random','pheno','blup']:
    t0=time.time()
    FB=[];GB=[]
    for r in range(REPS):
        f,gg=run(m,1000+r); FB.append(f); GB.append(gg)
    FB=np.array(FB); GB=np.array(GB)
    fbar=FB.mean(axis=0); gbar=GB.mean(axis=0)
    dF=1-(1-fbar[NGEN])**(1.0/NGEN)
    res[m]=(fbar,gbar,dF)
    name={'random':'随机','pheno':'表型选择','blup':'BLUP'}[m]
    print(f"{name:<10}{fbar[NGEN]:>9.4f}{dF:>10.5f}{1/(2*dF):>10.2f}{dF/pred:>9.3f}{gbar[NGEN]-gbar[0]:>18.4f}   ({time.time()-t0:.0f}s)")
print("\n逐代平均近交系数：")
print(f"{'代':>4}"+"".join(f"{n:>11}" for n in ['随机','表型选择','BLUP']))
for t in range(NGEN+1):
    print(f"{t:>4}"+"".join(f"{res[m][0][t]:>11.4f}" for m in ['random','pheno','blup']))
print("\n逐代平均育种值：")
print(f"{'代':>4}"+"".join(f"{n:>11}" for n in ['随机','表型选择','BLUP']))
for t in range(NGEN+1):
    print(f"{t:>4}"+"".join(f"{res[m][1][t]-res[m][1][0]:>11.4f}" for m in ['random','pheno','blup']))
print("\n每单位近交换得的进展（10 代进展 / F_10）：")
for m,n in [('random','随机'),('pheno','表型选择'),('blup','BLUP')]:
    fbar,gbar,_=res[m]
    print(f"  {n:<8} {(gbar[NGEN]-gbar[0])/fbar[NGEN]:.3f} σ_A / 单位 F")
