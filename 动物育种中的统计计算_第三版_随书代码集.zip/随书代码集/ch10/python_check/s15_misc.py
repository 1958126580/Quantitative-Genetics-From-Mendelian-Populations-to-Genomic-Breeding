# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s15_misc.py    依赖：numpy, scipy
"""Bulmer 可逆性；间接选择判据的数值表。"""
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq
def ii(p):
    x=norm.isf(p); return norm.pdf(x)/p, x

print("=== Bulmer 效应的可逆性（h2_0=0.40, p=0.10 下选择到平衡后停止选择）===")
i,x=ii(0.10); k=i*(i-x); G=0.40; VE=0.60
a=1+k; b=VE-G; c=-G*VE
vstar=(-b+np.sqrt(b*b-4*a*c))/(2*a)
print(f"平衡值 σ*² = {vstar:.6f} = {vstar/G:.6f} σ_a²")
v=vstar
print(f"{'停选后代数':>10}{'σ_A²':>10}{'/σ_a²':>10}")
print(f"{0:>10}{v:>10.6f}{v/G:>10.6f}")
for t in range(1,7):
    v=0.5*G+0.5*v
    print(f"{t:>10}{v:>10.6f}{v/G:>10.6f}")

print("\n=== 间接选择：临界遗传相关 r_A* = h_Y/h_X ===")
print("{:>12}".format("h2Y \\ h2X")+"".join(f"{h:>9.2f}" for h in [0.10,0.20,0.30,0.45,0.60,1.00]))
for hy in [0.05,0.10,0.20,0.30,0.40]:
    row=[]
    for hx in [0.10,0.20,0.30,0.45,0.60,1.00]:
        row.append(np.sqrt(hy)/np.sqrt(hx))
    print(f"{hy:>12.2f}"+"".join((f"{v:>9.3f}" if v<=1 else f"{'>1':>9}") for v in row))
print("（表中值 >1 表示无论 r_A 多高，间接选择都不可能优于直接选择）")

print("\n=== 数值例：Y 为目标（h²=0.10），X 为辅助 ===")
hy2=0.10
for hx2,rA in [(0.45,0.55),(0.45,0.30),(0.20,0.55),(0.60,0.45),(1.00,0.50)]:
    ratio=rA*np.sqrt(hx2)/np.sqrt(hy2)
    print(f"h²_X={hx2:.2f}, r_A={rA:.2f}: CR_Y/R_Y = {ratio:.4f} -> {'间接更优' if ratio>1 else '直接更优'}")
print("\n加入世代间隔：Y 在 4 岁可测（L_Y=4.5 年），X 在 1 岁可测（L_X=1.5 年）")
for hx2,rA in [(0.45,0.55),(0.45,0.30),(0.20,0.55),(0.20,0.25)]:
    ratio=(rA*np.sqrt(hx2)/1.5)/(np.sqrt(hy2)/4.5)
    print(f"h²_X={hx2:.2f}, r_A={rA:.2f}: (CR_Y/L_X)/(R_Y/L_Y) = {ratio:.4f}")
print("\n基因组选择视作'极端间接选择'（h²_X = 1，r_A = 预测准确性 r_g）：")
for hy2 in [0.05,0.10,0.25,0.40]:
    for rg in [0.35,0.50,0.65]:
        print(f"  h²_Y={hy2:.2f}, r_g={rg:.2f}: CR/R = {rg/np.sqrt(hy2):.3f}", end="")
    print()

print("\n=== 相关反应的数值例：对 X 选择时 Y 的变化 ===")
sPY=1.0; hy=np.sqrt(0.10); i=1.7550
for rA in [-0.5,-0.2,0.0,0.3,0.6]:
    for hx2 in [0.45]:
        CR=i*rA*np.sqrt(hx2)*hy*sPY
        print(f"  r_A={rA:+.1f}: CR_Y = {CR:+.4f} σ_P,Y /代（直接选择 R_Y = {i*hy*hy*sPY:+.4f}）")
