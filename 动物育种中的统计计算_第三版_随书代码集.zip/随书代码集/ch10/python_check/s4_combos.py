# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4_combos.py    依赖：numpy
"""§10.2 组合信息源的指数权重与准确性（sigma_P^2 = 1）。"""
import numpy as np
np.set_printoptions(precision=6, suppress=True)

def solve(P,g,h2):
    b=np.linalg.solve(P,g)
    return b, np.sqrt(b@g/h2)

def own_plus_fs(h2,n,c2=0.0):
    tf=0.5*h2+c2
    P=np.array([[1.0, tf],[tf,(1+(n-1)*tf)/n]])
    g=np.array([h2,0.5*h2])
    return solve(P,g,h2)
def own_plus_prog(h2,n):
    th=0.25*h2
    P=np.array([[1.0,0.5*h2],[0.5*h2,(1+(n-1)*th)/n]])
    g=np.array([h2,0.5*h2])
    return solve(P,g,h2)
def own_plus_pa(h2):
    P=np.array([[1.0,0.5*h2],[0.5*h2,0.5]])
    g=np.array([h2,0.5*h2])
    return solve(P,g,h2)
def own_fs_hs(h2,nfs,nhs,c2=0.0):
    tf=0.5*h2+c2; th=0.25*h2
    P=np.array([[1.0,   tf,           th],
                [tf,   (1+(nfs-1)*tf)/nfs, th],
                [th,    th,          (1+(nhs-1)*th)/nhs]])
    g=np.array([h2,0.5*h2,0.25*h2])
    return solve(P,g,h2)
def rel_mean(h2,n,a,t):
    return a*np.sqrt(h2)*np.sqrt(n/(1+(n-1)*t))

H2=[0.05,0.10,0.20,0.25,0.30,0.40,0.50]
def line(name,f,fmt="{:>9.4f}"):
    print(f"{name:<34}"+"".join(fmt.format(f(h)) for h in H2))

print("== 表 10-x  常见信息源组合的选择准确性 r_IA（sigma_P=1, c^2=0）==")
print(f"{'信息源':<34}"+"".join(f"{h:>9.2f}" for h in H2))
line("自身 1 次记录",                lambda h: np.sqrt(h))
line("自身 3 次记录（rep 0.5）",      lambda h: np.sqrt(3*h/(1+2*0.5)))
line("双亲表型均值",                  lambda h: rel_mean(h,2,0.5,0.0))
line("20 个半同胞均值",               lambda h: rel_mean(h,20,0.25,0.25*h))
line("100 个半同胞均值",              lambda h: rel_mean(h,100,0.25,0.25*h))
line("10 个全同胞均值",               lambda h: rel_mean(h,10,0.5,0.5*h))
line("50 个后裔均值",                 lambda h: rel_mean(h,50,0.5,0.25*h))
line("100 个后裔均值",                lambda h: rel_mean(h,100,0.5,0.25*h))
line("自身 + 双亲均值",               lambda h: own_plus_pa(h)[1])
line("自身 + 10 全同胞",              lambda h: own_plus_fs(h,10)[1])
line("自身 + 10 全同胞 + 40 半同胞",   lambda h: own_fs_hs(h,10,40)[1])
line("自身 + 50 后裔",                lambda h: own_plus_prog(h,50)[1])

print("\n== 权重示例（h2 = 0.25）==")
for nm,f in [("自身+双亲均值",lambda:own_plus_pa(0.25)),
             ("自身+10全同胞",lambda:own_plus_fs(0.25,10)),
             ("自身+10全同胞(c2=0.10)",lambda:own_plus_fs(0.25,10,0.10)),
             ("自身+10全同胞+40半同胞",lambda:own_fs_hs(0.25,10,40)),
             ("自身+50后裔",lambda:own_plus_prog(0.25,50))]:
    b,r=f(); print(f"{nm:<26} b = {np.round(b,4)}   r_IA = {r:.4f}")

print("\n== 共同环境 c^2 对全同胞信息的毒性（h2=0.25, 自身+10 全同胞）==")
for c2 in [0.0,0.05,0.10,0.15,0.20]:
    b,r=own_plus_fs(0.25,10,c2)
    print(f"c2={c2:.2f}  b=({b[0]:.4f},{b[1]:.4f})  r_IA={r:.4f}")
print("\n== 若误设 c^2=0 而真值为 0.15（h2=0.25, 自身+10 全同胞）==")
b_w,_=own_plus_fs(0.25,10,0.0)
h2=0.25;n=10;c2=0.15;tf=0.5*h2+c2
Ptrue=np.array([[1.0,tf],[tf,(1+(n-1)*tf)/n]]); g=np.array([h2,0.5*h2])
r_wrong=(b_w@g)/np.sqrt((b_w@Ptrue@b_w)*(g@np.linalg.solve(Ptrue,g)))
b_t,r_t=own_plus_fs(0.25,10,0.15)
print(f"正确权重 b={np.round(b_t,4)}  r={r_t:.4f};  误用 c2=0 的权重 b={np.round(b_w,4)}  相对效率 ={r_wrong:.4f}")
