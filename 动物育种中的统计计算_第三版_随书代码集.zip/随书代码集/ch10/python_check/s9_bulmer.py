# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s9_bulmer.py    依赖：numpy, scipy
"""§10.4 Bulmer 效应：逐代递推、平衡点闭式解、与模拟验证。"""
import numpy as np
from scipy.stats import norm
np.set_printoptions(precision=6,suppress=True)
def ix(p):
    x=norm.isf(p); return norm.pdf(x)/p, x
def k_of(p):
    i,x=ix(p); return i*(i-x), i, x

# ---- 表型选择：平衡点闭式解 ----
def eq_pheno(G,VE,k):
    """(1+k) v^2 + (VE - G) v - G*VE = 0 的正根"""
    a=1+k; b=VE-G; c=-G*VE
    return (-b+np.sqrt(b*b-4*a*c))/(2*a)
def recur_pheno(G,VE,k,T=40):
    v=G; tr=[v]
    for _ in range(T):
        h2=v/(v+VE)
        v=0.5*G+0.5*v*(1-k*h2)
        tr.append(v)
    return np.array(tr)

print("=== 表 1：Bulmer 平衡（表型选择，sigma_P^2 初始 = 1）===")
print(f"{'h2_0':>6}{'p':>7}{'k':>8}{'σ*²/σ_a²':>10}{'h²*':>8}{'下降%':>8}{'递推验证':>10}{'到平衡代数':>10}")
rows=[]
for h20 in [0.10,0.25,0.40,0.60]:
    for p in [0.50,0.20,0.10,0.05,0.02]:
        k,i,x=k_of(p)
        G=h20; VE=1-h20
        vstar=eq_pheno(G,VE,k)
        tr=recur_pheno(G,VE,k,60)
        ngen=int(np.argmax(np.abs(tr-vstar)/vstar<0.01))
        rows.append((h20,p,k,vstar/G,vstar/(vstar+VE),100*(1-vstar/G),tr[-1],ngen))
        print(f"{h20:>6.2f}{p:>7.2f}{k:>8.4f}{vstar/G:>10.4f}{vstar/(vstar+VE):>8.4f}{100*(1-vstar/G):>8.2f}{tr[-1]/G:>10.4f}{ngen:>10d}")

print("\n=== 表 2：逐代轨迹（h2_0=0.40, p=0.10, k=%.4f）==="%k_of(0.10)[0])
k,_,_=k_of(0.10); G=0.40; VE=0.60
tr=recur_pheno(G,VE,k,10); vs=eq_pheno(G,VE,k)
print(f"{'代 t':>5}{'σ_A,t²':>10}{'σ_A,t²/σ_a²':>13}{'h_t²':>9}{'ΔG_t=i h_t σ_A,t':>18}{'累计反应':>10}")
cum=0; i=ix(0.10)[0]
for t,v in enumerate(tr):
    h2t=v/(v+VE); dg=i*np.sqrt(h2t)*np.sqrt(v)
    print(f"{t:>5}{v:>10.6f}{v/G:>13.6f}{h2t:>9.6f}{dg:>18.6f}{cum:>10.4f}")
    cum+=dg
print(f"平衡值 σ*² = {vs:.6f}（= {vs/G:.6f} σ_a²），h²* = {vs/(vs+VE):.6f}")
print(f"第 1 代反应 {i*np.sqrt(G/(G+VE))*np.sqrt(G):.6f}，平衡期每代反应 {i*np.sqrt(vs/(vs+VE))*np.sqrt(vs):.6f}，比值 {i*np.sqrt(vs/(vs+VE))*np.sqrt(vs)/(i*np.sqrt(G/(G+VE))*np.sqrt(G)):.6f}")

# ---- 固定准确性（BLUP/基因组选择）情形：闭式 σ*² = σ_a²/(1+k r²) ----
print("\n=== 表 3：固定准确性 r 的情形（如基因组选择），σ*²/σ_a² = 1/(1+k r²）===")
print(f"{'p':>6}{'k':>8}"+"".join(f"{'r='+str(r):>10}" for r in [0.3,0.5,0.7,0.9,0.99]))
for p in [0.50,0.20,0.10,0.05,0.02,0.01]:
    k,_,_=k_of(p)
    print(f"{p:>6.2f}{k:>8.4f}"+"".join(f"{1/(1+k*r*r):>10.4f}" for r in [0.3,0.5,0.7,0.9,0.99]))

# ---- 随机模拟验证（无穷小模型，无限群体 -> 大样本）----
print("\n=== 表 4：个体水平模拟验证（N=200000/代，p=0.10，h2_0=0.40）===")
rng=np.random.default_rng(555)
N=200000; G0=0.40; VE=0.60; p=0.10; M=int(N*p)
# 亲本 "育种值"：无穷小模型下孟德尔抽样方差恒为 G0/2
A=rng.standard_normal(N)*np.sqrt(G0)
print(f"{'代':>4}{'模拟 σ_A²':>12}{'递推 σ_A²':>12}{'相对误差%':>10}")
tr=recur_pheno(G0,VE,k_of(p)[0],12)
for t in range(11):
    va=A.var()
    print(f"{t:>4}{va:>12.6f}{tr[t]:>12.6f}{100*(va-tr[t])/tr[t]:>10.3f}")
    P_=A+rng.standard_normal(N)*np.sqrt(VE)
    sel=np.argpartition(P_,-M)[-M:]
    As=A[sel]
    s=rng.integers(0,M,N); d=rng.integers(0,M,N)
    A=0.5*(As[s]+As[d])+rng.standard_normal(N)*np.sqrt(G0/2)
