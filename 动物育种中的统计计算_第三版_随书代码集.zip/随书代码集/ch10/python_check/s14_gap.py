# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s14_gap.py    依赖：numpy, scipy
"""§10.5 预测反应与实测反应的差距预算；对照群设计的精度。"""
import numpy as np
from scipy.stats import norm
def ii(p):
    x=norm.isf(p); return norm.pdf(x)/p, x

# ---- 猪核心群：每代反应的"折减预算" ----
h2=0.30; sP=1.0; sA=np.sqrt(h2); r=0.6595
p_eff=0.10                                    # 两性平均的有效留种率
i,x=ii(p_eff); k=i*(i-x)
R1=i*r*sA
print(f"基准：i={i:.4f}（p={p_eff}）, r={r:.4f}, σ_A={sA:.4f}  ->  第一代预测反应 R1 = {R1:.4f} σ_P")
print(f"k = i(i-x) = {k:.4f}")
fac=[]
f1=np.sqrt(1/(1+k*r*r));            fac.append(("Bulmer 效应（平衡期 σ_A*/σ_a）",f1))
f2=1-0.040;                          fac.append(("候选群体有限 + 候选间有亲缘",f2))
dF=0.020; bF=0.15                    # 每代 ΔF=0.02；近交衰退 0.15 σ_P / 单位 F
f3=1-bF*dF/R1;                       fac.append(("近交衰退（%.2f σ_P/单位F × ΔF=%.3f）"%(bF,dF),f3))
f4=np.sqrt(1-dF);                    fac.append(("漂变使 σ_A 下降 √(1-F)（第 1 代）",f4))
f5=1-0.030;                          fac.append(("遗传参数误设（指数相对效率 0.97）",f5))
f6=0.80;                             fac.append(("核心群→商品场的 G×E（r_g=0.80）",f6))
cum=1.0
print(f"\n{'折减项':<42}{'系数':>8}{'累计系数':>10}{'累计反应 σ_P':>14}")
print(f"{'（起点：育种者方程的预测）':<42}{'':>8}{1.0:>10.4f}{R1:>14.4f}")
for nm,f in fac:
    cum*=f
    print(f"{nm:<42}{f:>8.4f}{cum:>10.4f}{cum*R1:>14.4f}")
print(f"\n实测/预测 = {cum:.4f}；即预测值需要打 {100*cum:.0f} 折")

# ---- 遗传趋势估计的偏倚（来自 s12 模拟）----
print("\n=== 遗传趋势估计偏倚（模拟结果摘录）===")
print("无环境趋势：M1(只含总均值) +0.5%；M2(代为固定效应) +6.7%")
print("环境趋势 +0.10 σ_P/代：M1 +17.4%；M2 +7.9%；表型回归 +19.1%")

# ---- 对照群设计的精度 ----
print("\n=== 用对照群估计累计反应的标准误 ===")
sA2=0.25; sP2=1.0
print(f"{'代 t':>5}{'Ne':>6}{'n/代':>7}{'漂变方差':>10}{'抽样方差':>10}{'SE(σ_P)':>10}{'累计反应':>10}{'SE/反应':>9}")
Rg=1.7550*0.25
for t in [5,10,20]:
    for Ne in [30,100]:
        for n in [100,500]:
            vd=2*sA2*t/Ne; vs=2*sP2/n
            se=np.sqrt(vd+vs); R=t*Rg
            print(f"{t:>5}{Ne:>6}{n:>7}{vd:>10.4f}{vs:>10.4f}{se:>10.4f}{R:>10.4f}{se/R:>9.3f}")
print("\n重复 L 个独立对照—选择线对时 SE 除以 √L：")
for L in [1,2,4,8]:
    vd=2*0.25*10/30; vs=2/200
    print(f"  L={L}: SE = {np.sqrt((vd+vs)/L):.4f} σ_P，占 10 代累计反应（{10*Rg:.3f} σ_P）的 {100*np.sqrt((vd+vs)/L)/(10*Rg):.1f}%")
