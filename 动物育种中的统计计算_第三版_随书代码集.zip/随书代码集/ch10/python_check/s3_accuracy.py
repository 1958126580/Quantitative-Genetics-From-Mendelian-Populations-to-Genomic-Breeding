# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_accuracy.py    依赖：numpy
"""§10.2 常见信息源组合的指数权重与准确性：闭式 + 通用 b = P^{-1} g 数值验证。"""
import numpy as np
np.set_printoptions(precision=6, suppress=True)

def idx(P,g):
    b = np.linalg.solve(P,g)
    r = np.sqrt(b@g)          # sigma_A = 1 时 r_IA = sqrt(b'g)/sigma_A
    return b, r

def build(h2, n_own=1, rep=None, n_hs=0, n_fs=0, n_prog=0, c2=0.0, pa=False, rs=None, rd=None):
    """信息源：自身均值(n_own 次记录, 重复力 rep)、n_hs 半同胞均值、n_fs 全同胞均值、n_prog 后裔均值
       sigma_P^2 = 1, sigma_A = sqrt(h2)"""
    srcs=[]
    # 每个信息源：(与 A 的协方差, 自身方差, 与其他源的协方差函数)
    return srcs

# ---- 闭式 ----
def r_own(h2, n=1, rep=None):
    if rep is None: rep = h2
    return np.sqrt(n*h2/(1+(n-1)*rep))
def r_hs(h2, n, c2=0.0):
    t = 0.25*h2 + c2
    return 0.25*np.sqrt(h2)*np.sqrt(n/(1+(n-1)*t))/np.sqrt(h2)*np.sqrt(h2)  # placeholder
def r_rel(h2, n, a, t):
    """n 个同类亲属均值：与目标个体的加性关系 a（协方差 = a*h2*sigmaP^2），
       亲属间相关 t。 r_IA = a*sqrt(h2)*sqrt(n/(1+(n-1)t))"""
    return a*np.sqrt(h2)*np.sqrt(n/(1+(n-1)*t))

print("== 闭式与通用 P^{-1}g 的一致性检验 ==")
h2=0.25
# 半同胞：a=1/4，t=1/4 h2
for n in [5,20,100,1000]:
    a=0.25; t=0.25*h2
    P = np.array([[ (1+(n-1)*t)/n ]]); g=np.array([a*h2])
    b,r = idx(P,g/np.sqrt(h2))            # 目标 A 标准化为 sigma_A=sqrt(h2) -> 用 g/sigma_A
    print(f"HS n={n:>5}: 闭式 {r_rel(h2,n,0.25,t):.6f}  数值 {np.sqrt((np.linalg.solve(P,g)@g)/h2):.6f}")

print("\n== 表：各信息源组合的准确性 r_IA（sigma_P=1）==")
def combo_accuracy(h2, sources, c2=0.0, rep=None):
    """sources: list of dicts with keys: a (加性关系), n (个数), tt (组内相关), name
       返回 P (信息源均值间的方差协方差), g (与目标个体 A 的协方差)"""
    m=len(sources)
    P=np.zeros((m,m)); g=np.zeros(m)
    for j,s in enumerate(sources):
        g[j]=s['a']*h2
        P[j,j]=(1+(s['n']-1)*s['tt'])/s['n']
    for j in range(m):
        for k in range(j+1,m):
            P[j,k]=P[k,j]=sources[j]['cross'][k] if 'cross' in sources[j] else 0.0
    b=np.linalg.solve(P,g)
    return b, np.sqrt(b@g/h2)

rows=[]
H2=[0.05,0.10,0.20,0.25,0.30,0.40,0.50]
print(f"{'信息源':<28}" + "".join(f"{h:>9.2f}" for h in H2))
def line(name, f):
    print(f"{name:<28}" + "".join(f"{f(h):>9.4f}" for h in H2))

line("自身 1 次记录", lambda h: np.sqrt(h))
line("自身 3 次记录 (rep=0.5)", lambda h: np.sqrt(3*h/(1+2*0.5)))
line("双亲均值 (亲本表型)", lambda h: r_rel(h,2,0.5,0.0))
line("20 个半同胞均值", lambda h: r_rel(h,20,0.25,0.25*h))
line("100 个半同胞均值", lambda h: r_rel(h,100,0.25,0.25*h))
line("半同胞 n→∞", lambda h: 0.5*np.ones_like(h) if hasattr(h,'shape') else 0.5)
line("10 个全同胞均值", lambda h: r_rel(h,10,0.5,0.5*h))
line("全同胞 n→∞", lambda h: 1/np.sqrt(2))
line("50 个后裔均值", lambda h: r_rel(h,50,0.5,0.25*h))
line("100 个后裔均值", lambda h: r_rel(h,100,0.5,0.25*h))
