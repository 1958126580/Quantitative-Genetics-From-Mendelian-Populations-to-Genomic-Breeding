# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 10 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s11_limit.py    依赖：numpy, scipy
"""§10.4 选择极限：Robertson (1960) 的 2Ne R1 与 Kimura 固定概率的精确比较。"""
import numpy as np
from scipy.stats import norm
np.set_printoptions(precision=6,suppress=True)

def ufix(q, Nes):
    """Kimura: u(q) = (1-exp(-4 Ne s q))/(1-exp(-4 Ne s))，参数用 Nes = Ne*s"""
    z=4.0*Nes
    if abs(z)<1e-10: return q
    return (1-np.exp(-z*q))/(1-np.exp(-z))

print("=== 表 1：单位点的总反应与 2Ne·R1 的比 ===")
print("（q0=0.5；比值 = 2a(u-q0) / (2Ne · i · 2a²q0(1-q0)/σ_P)）")
print(f"{'Ne·s':>8}{'u(0.5)':>10}{'R∞/R1':>12}{'2Ne':>8}{'比 R∞/(2Ne R1)':>16}")
q0=0.5
for Nes in [0.01,0.05,0.1,0.25,0.5,1.0,2.0,4.0,8.0,16.0]:
    u=ufix(q0,Nes)
    # R∞/R1 = 2a(u-q0) / (i*2a²q0(1-q0)/σ_P) = (u-q0)/(i*a*q0(1-q0)/σ_P) = (u-q0)/(s*q0(1-q0))
    # 以 Ne 为单位： R∞/(2Ne R1) = (u-q0)/(2*Ne*s*q0(1-q0))
    ratio=(u-q0)/(2*Nes*q0*(1-q0))
    print(f"{Nes:>8.2f}{u:>10.6f}{(u-q0)/(Nes/ (Nes))*0+ (u-q0)/( (Nes/Nes)*1 ):>12.6f}{'—':>8}{ratio:>16.4f}")

print("\n=== 表 2：不同初始频率 q0 的比值 R∞/(2Ne R1) ===")
print(f"{'Ne·s':>8}"+"".join(f"{'q0='+str(q):>11}" for q in [0.05,0.1,0.3,0.5,0.7,0.9]))
for Nes in [0.05,0.1,0.25,0.5,1.0,2.0,4.0,8.0]:
    row=[]
    for q in [0.05,0.1,0.3,0.5,0.7,0.9]:
        u=ufix(q,Nes); row.append((u-q)/(2*Nes*q*(1-q)))
    print(f"{Nes:>8.2f}"+"".join(f"{v:>11.4f}" for v in row))

print("\n=== 表 3：一个具体群体的选择极限预算 ===")
h2=0.25; sP=1.0; p=0.10
i=norm.pdf(norm.isf(p))/p
sA=np.sqrt(h2)*sP
R1=i*np.sqrt(h2)*sA
print(f"h²={h2}, σ_P={sP}, 留种率 {p} -> i={i:.4f}, σ_A={sA:.4f}, 第一代反应 R1={R1:.6f} σ_P")
print(f"{'Ne':>6}{'2Ne·R1 (σ_P)':>14}{'2Ne·R1 (σ_A)':>14}{'半衰期 1.4Ne 代':>16}{'累计到 R∞ 一半所需代数':>22}")
for Ne in [20,30,50,100,200,500]:
    print(f"{Ne:>6}{2*Ne*R1:>14.4f}{2*Ne*R1/sA:>14.2f}{1.4*Ne:>16.0f}{int(round(1.4*Ne)):>22d}")

print("\n=== 表 4：有限位点模型的精确极限（L 个等效位点，q0=0.5）===")
print(f"{'L':>6}{'a/σ_P':>9}{'Ne':>6}{'Ne·s':>9}{'R∞ (σ_A)':>11}{'2Ne·R1 (σ_A)':>14}{'比值':>8}{'最大可能 (σ_A)':>16}")
for L in [20,100,500,2000]:
    # 使 σ_A² = 2 L q(1-q) a² = h2 = 0.25 （σ_P=1）
    a=np.sqrt(h2/(2*L*q0*(1-q0)))
    s=i*a/sP
    Ne=50
    u=ufix(q0,Ne*s)
    Rinf=L*2*a*(u-q0)
    Rmax=L*2*a*(1-q0)
    print(f"{L:>6}{a:>9.5f}{Ne:>6}{Ne*s:>9.4f}{Rinf/sA:>11.3f}{2*Ne*R1/sA:>14.3f}{Rinf/(2*Ne*R1):>8.3f}{Rmax/sA:>16.3f}")
