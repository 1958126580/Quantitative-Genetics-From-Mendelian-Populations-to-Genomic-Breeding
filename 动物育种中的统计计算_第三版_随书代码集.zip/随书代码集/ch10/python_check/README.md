# 第 10 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch10/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `s10_inbreeding.py` | §10.4 近交累积：ΔF=1/(8Nm)+1/(8Nf) 在随机 / 表型 / BLUP 选择下的实际表现。 | numpy | 62.8 | `outputs/s10_inbreeding.out` |
| `s11_limit.py` | §10.4 选择极限：Robertson (1960) 的 2Ne R1 与 Kimura 固定概率的精确比较。 | numpy, scipy | 9.9 | `outputs/s11_limit.out` |
| `s13_paths.py` | §10.1 四路径年遗传进展的数值例（奶牛 + 猪），准确性全部由指数公式算出。 | numpy, scipy | 12.3 | `outputs/s13_paths.out` |
| `s14_gap.py` | §10.5 预测反应与实测反应的差距预算；对照群设计的精度。 | numpy, scipy | 10.9 | `outputs/s14_gap.out` |
| `s15_misc.py` | Bulmer 可逆性；间接选择判据的数值表。 | numpy, scipy | 10.4 | `outputs/s15_misc.out` |
| `s2_related.py` | 候选个体间有亲缘时，实现的选择差与遗传反应低于独立候选的预测。 | numpy, scipy | 81.4 | `outputs/s2_related.out` |
| `s2b_related.py` | 全同胞家系 + 共同环境 c^2 时，按表型选择的实际遗传反应。 | numpy, scipy | 78.6 | `outputs/s2b_related.out` |
| `s3_accuracy.py` | §10.2 常见信息源组合的指数权重与准确性：闭式 + 通用 b = P^{-1} g 数值验证。 | numpy | 1.9 | `outputs/s3_accuracy.out` |
| `s4_combos.py` | §10.2 组合信息源的指数权重与准确性（sigma_P^2 = 1）。 | numpy | 1.9 | `outputs/s4_combos.out` |
| `s5_blup_eq.py` | §10.2.x 选择指数与 BLUP 的数值等价（固定效应已知）。 | numpy | 2.0 | `outputs/s5_blup_eq.out` |
| `s6_sens.py` | §10.2.x 指数权重对参数误设的敏感性。相对效率 RE = b'g / sqrt(b'Pb * g'P^{-1}g). | numpy | 86.8 | `outputs/s6_sens.out` |
| `s8_restricted.py` | §10.3 限制性选择指数 (Kempthorne & Nordskog 1959) 的数值例：蛋鸡蛋数 / 蛋重。 | numpy | 1.1 | `outputs/s8_restricted.out` |
| `s8b_restricted.py` | 限制性指数：影子价格解释、与期望反应指数的关系、三性状情形。 | numpy | 1.2 | `outputs/s8b_restricted.out` |
| `s9_bulmer.py` | §10.4 Bulmer 效应：逐代递推、平衡点闭式解、与模拟验证。 | numpy, scipy | 11.1 | `outputs/s9_bulmer.out` |
