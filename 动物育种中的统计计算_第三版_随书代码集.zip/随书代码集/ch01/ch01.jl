# 本脚本由 tools/nb2jl.py 从同目录的 ch01.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 01

# %% [markdown]
# # 第一章　绪论：动物育种中的统计计算 —— 配套代码
#
# 《动物育种中的统计计算（第三版）》随书代码集
#
# ---
#
# 本笔记本对应正文第一章，包含四部分：
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | 环境自检 | §2.1、§1.4.6 |
# | 2 | 计算规模的量级分析（复现正文全部数值） | §1.3 |
# | 3 | 跨语言基准：协议与实现 | §1.4.5 |
# | 4 | 全书数据集总览 | §1.5.5 |
#
# **运行前准备**：在 `code/` 目录下执行 `julia --project=.`，然后 `using Pkg; Pkg.instantiate()`。
#
# **代码分层约定**：本书全部笔记本使用统一标记 —— 【原理实现】可读性优先，【优化实现】性能优先，【对照验证】证明两者一致。第一章以量级分析为主，尚未涉及算法实现，故只有少量代码。

# %% [markdown]
# ## 1　环境自检
#
# 第一件事是确认环境正确。下面的代码检查 Julia 版本、线程数、BLAS 配置与随书代码集的依赖状态。

# %%
using LinearAlgebra, Printf, InteractiveUtils

function 环境自检()
    println("="^62)
    println("Julia 版本      : ", VERSION)
    println("平台            : ", Sys.MACHINE)
    println("CPU 核心数      : ", Sys.CPU_THREADS)
    println("Julia 线程数    : ", Threads.nthreads())
    println("BLAS 实现       : ", BLAS.get_config())
    println("BLAS 线程数     : ", BLAS.get_num_threads())
    println("机器精度 ε      : ", eps(Float64))
    println("="^62)

    # 版本兼容性检查：本书要求 1.10 LTS 及以上
    if VERSION < v"1.10"
        @warn "本书代码要求 Julia ≥ 1.10 (LTS)，当前版本过低，部分代码可能无法运行。"
    else
        println("✓ 版本满足本书要求（≥ 1.10 LTS）")
    end
    return nothing
end

环境自检()

# %%
# 依赖状态：确认 Manifest.toml 已实例化
using Pkg
Pkg.status()

# %% [markdown]
# ## 2　计算规模的量级分析
#
# 本节复现正文 §1.3 中的**全部**数值。读者可以修改参数，观察各项指标随规模的变化。
#
# ### 2.1 三堵墙

# %%
"""
    量级分析(N; flops=2e12, bytes_per_elem=8)

对阶数为 `N` 的稠密线性系统，返回 (运算量 FLOP, 耗时 s, 内存 TiB)。

- `flops`  : 机器的双精度实测性能，默认 2 TFLOPS（2026 年高端工作站的典型值）
- Cholesky 分解的运算量约为 N³/3
"""
function 量级分析(N::Real; flops::Real = 2e12, bytes_per_elem::Int = 8)
    ops    = N^3 / 3                       # Cholesky 分解
    secs   = ops / flops
    mem    = N^2 * bytes_per_elem / 2.0^40  # TiB
    return (ops = ops, secs = secs, mem_TiB = mem)
end

println(rpad("N", 12), rpad("FLOP", 14), rpad("耗时", 20), "稠密内存")
println("-"^62)
for N in (1e4, 1e5, 1e6, 1e7)
    r = 量级分析(N)
    t = r.secs < 3600      ? @sprintf("%.1f s", r.secs) :
        r.secs < 86400     ? @sprintf("%.1f h", r.secs/3600) :
        r.secs < 86400*365 ? @sprintf("%.1f d", r.secs/86400) :
                             @sprintf("%.2f 年", r.secs/86400/365)
    m = r.mem_TiB < 1/1024 ? @sprintf("%.1f MiB", r.mem_TiB*1024^2) :
        r.mem_TiB < 1      ? @sprintf("%.1f GiB", r.mem_TiB*1024)   :
                             @sprintf("%.1f TiB", r.mem_TiB)
    println(rpad(@sprintf("%.0e", N), 12), rpad(@sprintf("%.2e", r.ops), 14), rpad(t, 20), m)
end

# %% [markdown]
# > **正文对照**　$N=10^6$ 时应得 $3.33\times10^{17}$ FLOP、约 46 小时、7.3 TiB；$N=10^7$ 时约 5.3 年、728 TiB。
#
# ### 2.2 算法胜于硬件：Henderson (1976) 的收益
#
# 正文 §1.3.3 比较了两种构建 $\mathbf{A}^{-1}$ 的路径。这里把比较量化。

# %%
"""
    henderson对照(n; flops=2e12)

比较两种获得 A⁻¹ 的路径：
  路径一：显式构建稠密 A（n×n），再求逆      —— O(n³) 运算、O(n²) 存储
  路径二：Henderson(1976)/Quaas(1976) 规则   —— O(n)  运算、≤9n 个非零元
"""
function henderson对照(n::Real; flops::Real = 2e12)
    # 路径一
    ops₁ = n^3 / 3
    mem₁ = n^2 * 8
    t₁   = ops₁ / flops
    # 路径二：每个个体向 A⁻¹ 的 3×3 块贡献至多 9 个非零元
    nz   = 9n            # 非零元个数上界（避免遮蔽 SparseArrays.nnz）
    ops₂ = 9n                       # 每个非零元一次乘加，量级估计
    mem₂ = nz  * (8 + 4 + 4)        # 值 + 行号 + 列指针摊销
    t₂   = ops₂ / 1e8               # 不规则访问，保守按 1e8 次操作/秒估计

    @printf("系谱个体数 n = %.0e\n", n)
    @printf("  路径一（先 A 后求逆）: %.2e FLOP, %.1f TiB, %.2f 年\n",
            ops₁, mem₁/2.0^40, t₁/86400/365)
    @printf("  路径二（Henderson）  : %.2e 次操作, %.2f GiB, %.3f s\n",
            ops₂, mem₂/2.0^30, t₂)
    @printf("  → 运算量之比 %.2e ; 耗时之比 %.2e ; 内存之比 %.2e\n",
            ops₁/ops₂, t₁/t₂, mem₁/mem₂)
    return nothing
end

henderson对照(1e7)

# %% [markdown]
# ### 2.3 共轭梯度法的收敛界
#
# 正文式 (1.3)：
# $$\frac{\|\mathbf x^{(k)}-\mathbf x^*\|_{\mathbf A}}{\|\mathbf x^{(0)}-\mathbf x^*\|_{\mathbf A}}\le 2\left(\frac{\sqrt\kappa-1}{\sqrt\kappa+1}\right)^{k}$$
#
# 这是思考题 1 的计算工具。

# %%
"""
    cg迭代数(κ, tol)

由共轭梯度法的收敛界，估计把相对误差降到 `tol` 所需的迭代次数下界。
"""
function cg迭代数(κ::Real, tol::Real)
    ρ = (sqrt(κ) - 1) / (sqrt(κ) + 1)
    return ceil(Int, log(tol / 2) / log(ρ))
end

println("目标相对误差 1e-6：")
for κ in (1e2, 1e4, 1e6, 1e8)
    @printf("  κ = %.0e  →  至少 %5d 次迭代\n", κ, cg迭代数(κ, 1e-6))
end
println()
println("→ 预处理把 κ 降低两个数量级，迭代次数约降为 1/10。")

# %% [markdown]
# ### 2.4 稀疏格式的内存临界点（思考题 3）
#
# CSC 格式每个非零元需 8 字节值 + `sizeof(Ti)` 字节行号，另有 $(n+1)$ 个列指针。
# 设非零元比例为 $\rho$，CSC 省内存的条件是
# $$\rho\, n^2\,(8+s) + s\,(n+1) < 8n^2$$
# 其中 $s$ 为索引字节数。

# %%
function csc临界ρ(n::Integer; idx_bytes::Int = 8)
    s = idx_bytes
    # ρ·n²·(8+s) + s·(n+1) < 8n²
    return (8n^2 - s*(n+1)) / (n^2 * (8 + s))
end

for n in (10^3, 10^4, 10^5, 10^6)
    @printf("n = %-9d  Int64 索引: ρ < %.4f   Int32 索引: ρ < %.4f\n",
            n, csc临界ρ(n; idx_bytes=8), csc临界ρ(n; idx_bytes=4))
end
println()
println("→ 稀疏格式只在非零元比例低于约 1/2 ~ 2/3 时才省内存；")
println("  而要在【速度】上获益，通常需要 ρ < 0.1。")
println("→ 这就是为什么 A（几乎满）不该用稀疏格式，而 A⁻¹（ρ ≈ 9/n）应该用。")

# %% [markdown]
# ## 3　跨语言基准：协议与实现
#
# 正文 §1.4.5 说明了基准协议。这里给出 Julia 侧的四个任务实现。R/Python/C 的对应实现见 `code/benchmarks/` 目录。
#
# > **协议要点**：(1) 任务贴近真实计算模式；(2) 每种语言用惯用写法；(3) 排除编译时间（预热 + `@btime` 取最小值）；(4) 固定单线程；(5) 报告完整环境。

# %%
using BenchmarkTools, SparseArrays, Random

# 固定单线程，确保比较的是语言而非 BLAS 的多线程实现
BLAS.set_num_threads(1)

rng = Xoshiro(20260918)          # 固定种子，保证可复现

# ---- 任务 (a)：稠密矩阵乘法（BLAS 主导） ----
# 直接在下方基准单元中以 @belapsed 测量，无需单独封装。

# ---- 任务 (b)：按 Henderson 规则构建 A⁻¹（不规则访问 + 标量循环） ----
"""
    build_Ainv(sire, dam, F)

由系谱按 Henderson(1976)/Quaas(1976) 规则直接构建 A⁻¹。
`sire[i]`、`dam[i]` 为个体 i 的父母序号（0 表示未知），`F` 为近交系数向量。
个体已按拓扑序编号（后代序号大于亲本）。第九章将给出完整推导。
"""
function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire)
    I = Int[]; J = Int[]; V = Float64[]
    sizehint!(I, 9n); sizehint!(J, 9n); sizehint!(V, 9n)
    pos = Vector{Int}(undef, 3)
    q   = Vector{Float64}(undef, 3)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        pos[1], pos[2], pos[3] = s, d, i
        if s > 0 && d > 0
            q[1] = -0.5; q[2] = -0.5; q[3] = 1.0
            δ = 0.5 - 0.25 * (F[s] + F[d])
        elseif s > 0
            q[1] = -0.5; q[2] = 0.0;  q[3] = 1.0
            δ = 0.75 - 0.25 * F[s]
        elseif d > 0
            q[1] = 0.0;  q[2] = -0.5; q[3] = 1.0
            δ = 0.75 - 0.25 * F[d]
        else
            q[1] = 0.0;  q[2] = 0.0;  q[3] = 1.0
            δ = 1.0
        end
        b = inv(δ)
        for a in 1:3, c in 1:3
            (pos[a] > 0 && pos[c] > 0) || continue
            push!(I, pos[a]); push!(J, pos[c]); push!(V, q[a] * q[c] * b)
        end
    end
    return sparse(I, J, V, n, n)      # 重复下标自动求和
end

# ---- 任务 (c)：Gibbs 抽样的一轮标记扫描（紧密循环） ----
"""一轮逐标记的残差更新扫描，是贝叶斯字母表的计算内核（第二十二章）。"""
function 标记扫描!(α::Vector{Float64}, e::Vector{Float64},
                   Z::Matrix{Float64}, zpz::Vector{Float64}, λ::Float64)
    n, m = size(Z)
    @inbounds for j in 1:m
        # rhs = z_j' e + z_j'z_j * α_j
        rhs = 0.0
        @simd for i in 1:n
            rhs += Z[i, j] * e[i]
        end
        rhs += zpz[j] * α[j]
        lhs    = zpz[j] + λ
        αold   = α[j]
        α[j]   = rhs / lhs
        Δ      = αold - α[j]
        @simd for i in 1:n
            e[i] += Z[i, j] * Δ
        end
    end
    return α
end

println("四个基准任务已定义。运行下一单元执行基准。")

# %%
# 构造一个小型测试系谱并验证 build_Ainv 的正确性
# 正文第九章的 7 个体算例：
#   个体 1,2 为基础群；3 的父为 1、母未知；4=(1,2)；5=(3,4)；6=(1,4)；7=(5,6)
sire = [0, 0, 1, 1, 3, 1, 5]
dam  = [0, 0, 0, 2, 4, 4, 6]
F    = [0.0, 0.0, 0.0, 0.0, 0.125, 0.25, 0.28125]   # 第九章手算结果

Ainv = build_Ainv(sire, dam, F)

# 验证：A⁻¹ 应当对称，且 A * A⁻¹ = I
# 先按递推规则构建 A（小规模，可用稠密）
function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            asj = s > 0 ? A[j, s] : 0.0
            adj = d > 0 ? A[j, d] : 0.0
            A[i, j] = A[j, i] = 0.5 * (asj + adj)
        end
        A[i, i] = 1.0 + (s > 0 && d > 0 ? 0.5 * A[s, d] : 0.0)
    end
    return A
end

A = build_A(sire, dam)
@printf("对称性误差         : %.3e\n", maximum(abs, Ainv - Ainv'))
@printf("A * A⁻¹ 与 I 的偏差 : %.3e\n", maximum(abs, A * Matrix(Ainv) - I))
@printf("近交系数核对       : %s\n", isapprox(diag(A) .- 1, F; atol=1e-12) ? "✓ 与手算一致" : "✗ 不一致")
println()
println("A⁻¹ 非零元个数 = ", nnz(Ainv), "（上界 9n = ", 9*length(sire), "）")

# %%
# 执行基准（可按机器性能调整规模）
using Statistics

n_dense  = 1000
n_ped    = 100_000
n_ind, n_mrk = 2000, 5000

# (a) 稠密矩阵乘法
A1 = rand(rng, n_dense, n_dense); B1 = rand(rng, n_dense, n_dense)
t_a = @belapsed $A1 * $B1
gflops = 2 * n_dense^3 / t_a / 1e9

# (b) 构建 A⁻¹
s2 = zeros(Int, n_ped); d2 = zeros(Int, n_ped)
for i in 101:n_ped                     # 前 100 个体作基础群
    s2[i] = rand(rng, 1:i-1); d2[i] = rand(rng, 1:i-1)
end
F2 = zeros(n_ped)                      # 演示用，真实近交系数见第九章
t_b = @belapsed build_Ainv($s2, $d2, $F2)

# (c) 标记扫描
Z   = rand(rng, [0.0, 1.0, 2.0], n_ind, n_mrk)
Z .-= mean(Z, dims=1)                  # 中心化
zpz = vec(sum(abs2, Z, dims=1))
α   = zeros(n_mrk); e = randn(rng, n_ind)
t_c = @belapsed 标记扫描!(copy($α), copy($e), $Z, $zpz, 1.0)

# (d) 稀疏矩阵-向量乘
S   = sprand(rng, 200_000, 200_000, 20/200_000)
v   = randn(rng, 200_000)
t_d = @belapsed $S * $v

@printf("(a) 稠密乘法 %d³        : %8.2f ms   (%.1f GFLOPS)\n", n_dense, t_a*1e3, gflops)
@printf("(b) 构建 A⁻¹  n=%d     : %8.2f ms\n", n_ped, t_b*1e3)
@printf("(c) 标记扫描 %d×%d   : %8.2f ms\n", n_ind, n_mrk, t_c*1e3)
@printf("(d) 稀疏乘 200k, nnz≈%d : %8.2f ms\n", nnz(S), t_d*1e3)
println()
println("请把上述结果与 code/benchmarks/ 下 R、Python、C 的对应实现比较。")
println("环境信息："); versioninfo()

# %% [markdown]
# ## 4　全书数据集总览
#
# 随书代码集的 `data/` 目录存放全书算例数据。所有数据都是小型、可复现的，便于读者手算核对。

# %%
using ASC3

function 数据集总览()
    dir = dirname(datapath(""))
    isdir(dir) || (println("data/ 目录尚未创建"); return)
    files = sort(readdir(dir))
    isempty(files) && (println("data/ 目录为空"); return)
    println(rpad("文件", 28), rpad("大小", 12), "说明")
    println("-"^70)
    for f in files
        startswith(f, ".") && continue
        p = joinpath(dir, f)
        isfile(p) || continue
        println(rpad(f, 28), rpad(string(filesize(p), " B"), 12))
    end
end

数据集总览()

# %% [markdown]
# ## 本章代码小结
#
# 1. **环境自检**应当是每个项目的第一个单元格 —— 版本、线程、BLAS 配置都会影响结果与性能。
# 2. **量级分析**可以在写第一行算法代码之前完成，它决定了你应该选择哪类方法（正文表 1.1）。
# 3. **基准测试有协议**：预热、固定线程、多次取最小值、报告完整环境。不遵守协议的基准数字没有意义。
# 4. `build_Ainv` 已经展示了本书的核心模式：**收集三元组 → `sparse(I,J,V)` 一次构造**，而不是向稀疏矩阵逐元素插入。第九章会给出它的完整推导，第十二章会用同样的模式装配 MME。
#
# **下一步**：`ch02.ipynb` 展开 Julia 语言本身，重点是类型稳定性与稀疏矩阵的正确用法。
