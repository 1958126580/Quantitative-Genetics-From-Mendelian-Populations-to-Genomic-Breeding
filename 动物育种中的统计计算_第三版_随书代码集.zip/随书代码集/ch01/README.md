# 第一章　绪论：动物育种中的统计计算 —— 配套代码

**所属**：第一篇　计算基础与 Julia 语言　　**对应正文**：第一章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch01.ipynb` | IJulia 笔记本：10 个代码单元，约 274 行 Julia 代码，穿插与正文对应的说明 |
| `ch01.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |

## 笔记本内容

- 1　环境自检
- 2　计算规模的量级分析
  - 2.1 三堵墙
  - 2.2 算法胜于硬件：Henderson (1976) 的收益
  - 2.3 共轭梯度法的收敛界
  - 2.4 稀疏格式的内存临界点（思考题 3）
- 3　跨语言基准：协议与实现
- 4　全书数据集总览
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 01
```

或在 Jupyter 中打开 `ch01/ch01.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

本章使用公用模块 `ASC3`（`../src/ASC3.jl`）：数据路径、可复现随机数、一致性断言。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 本章没有单独的 Python 复核脚本：正文中的解析数值已在写作时用 Python 逐一复算。
