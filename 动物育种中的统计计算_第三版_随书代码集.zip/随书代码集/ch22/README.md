# 第二十二章　贝叶斯字母表 —— 配套代码

**所属**：第五篇　基因组选择与基因组预测　　**对应正文**：第二十二章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch22.ipynb` | IJulia 笔记本：18 个代码单元，约 608 行 Julia 代码，穿插与正文对应的说明 |
| `ch22.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 7 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　通用框架
  - 1.1 先验接口
  - 1.2 通用 Gibbs 扫描
- 2　六种先验的实现
  - 2.1 RidgePrior —— SNP-BLUP（正文 §22.2.10）
  - 2.2 BayesA（正文式 22.10、22.14）
  - 2.3 BayesB（正文式 22.20、22.28–22.29）
  - 2.4 BayesC / BayesCπ（正文式 22.30–22.33）
  - 2.5 Bayesian LASSO（正文定理 22.1、式 22.39–22.40）
  - 2.6 BayesR（正文式 22.41–22.45）
- 3　单元测试：$\pi=0$ 且 $\sigma_\alpha^2$ 固定时重现 SNP-BLUP
  - 3.1 收敛到 SNP-BLUP 需要多少轮？
- 4　数值稳定性：残差漂移（正文式 22.51）
- 5　收敛诊断（正文 §22.3.4）
- 6　六种方法在不同遗传结构下的基准比较（正文 §22.4.2）
- 7　计算复杂度与性能
- 8　与 JWAS 的逐参数交叉验证（可选，需安装 JWAS）
- 9　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 22
```

或在 Jupyter 中打开 `ch22/ch22.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 可选单元

- 开关 `RUN_JWAS`（默认 `false`）：JWAS 2.4（与 JWAS 的交叉验证单元）；需先实例化 `envs/jwas`：`julia --project=envs/jwas -e 'using Pkg; Pkg.instantiate()'`，再把笔记本中的开关改为 `true`。
- 开关关闭时只打印一行提示并跳过，不影响其余单元（见 `../README.md` 与正文附录 E）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
