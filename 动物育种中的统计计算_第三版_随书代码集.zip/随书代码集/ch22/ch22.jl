# 本脚本由 tools/nb2jl.py 从同目录的 ch22.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 22

# %% [markdown]
# # 第二十二章　贝叶斯字母表 —— 配套代码
#
# 本 Notebook 对应第二十二章。
#
# **设计思想**：正文 §22.2.1 指出，七个模型共享同一个似然与同一个 $\alpha_j$ 完全条件（式 22.7），
# 只在"$\alpha_j$ 的先验如何抽"上分歧。本 Notebook 把这一点直接落实为代码结构：
#
# - 一个**通用的 Gibbs 扫描** `bayes_gibbs`，负责残差维护、固定效应、残差方差、样本收集；
# - 一组**可插拔的先验模块**（`RidgePrior`、`BayesA`、`BayesB`、`BayesC`、`BayesLASSO`、`BayesR`），
#   每个只需实现两个方法：`sample_marker!` 与 `update_global!`。
#
# **内容**
#
# 1. 通用框架与先验接口
# 2. 六种先验的实现（含全部完全条件分布的公式对照）
# 3. **单元测试**：令 $\pi=0$、$\sigma_\alpha^2$ 固定时精确重现 SNP-BLUP（正文 §22.2.10）
# 4. 收敛诊断：$\hat R$、ESS、GEBV 相关（正文式 22.52）
# 5. 数值稳定性：残差漂移的测量（正文式 22.51）
# 6. 不同遗传结构下的基准比较（正文 §22.4.2）
# 7. 性能与复杂度
# 8. **与 JWAS 的逐参数交叉验证**（可选，需安装 JWAS）

# %%
using LinearAlgebra, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-8)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end

"""从尺度逆卡方 χ⁻²(ν, S) 抽样（正文第十九章式 19.3 的参数化：均值 = νS/(ν-2)）。"""
rand_scaled_inv_chisq(rng, nu::Real, S::Real) = nu*S / rand(rng, Chisq(nu))

println("Julia ", VERSION)

# %% [markdown]
# ## 1　通用框架
#
# ### 1.1 先验接口
#
# 每个先验类型必须实现：
#
# ```julia
# sample_marker!(pr, j, rhs, zz, s2e, rng) -> α_j^new
# update_global!(pr, alpha, s2e, rng)      -> nothing
# extra_stats(pr)                          -> NamedTuple   # 供监测的超参数
# ```
#
# 其中 `rhs = z_j' e^{(-j)}`（正文式 22.48），`zz = z_j'z_j`。

# %%
abstract type MarkerPrior end

"""默认：无全局超参数需要更新。"""
update_global!(::MarkerPrior, alpha, s2e, rng) = nothing
extra_stats(::MarkerPrior) = NamedTuple()

"""正文式 (22.7)：给定 σ²_{α_j} 抽 α_j。所有先验共用。"""
@inline function draw_alpha(rhs::Float64, zz::Float64, s2e::Float64,
                            s2aj::Float64, rng)
    Cj  = zz + s2e/s2aj
    mu  = rhs / Cj
    return mu + randn(rng)*sqrt(s2e/Cj), Cj
end

"""正文式 (22.28)：δ_j = 1 的对数几率（已积掉 b_j 的边际似然比）。"""
@inline function logit_delta(rhs::Float64, zz::Float64, s2e::Float64,
                             s2aj::Float64, pi0::Float64)
    Cj = zz + s2e/s2aj
    return log((1 - pi0)/pi0) - 0.5*log(s2aj*Cj/s2e) + rhs^2/(2*s2e*Cj)
end

@inline logistic(x) = 1/(1 + exp(-x))

# %% [markdown]
# ### 1.2 通用 Gibbs 扫描
#
# 要点（正文 §22.3.1–22.3.2）：
#
# - 维护残差 $\mathbf e$，用增量更新（式 22.48–22.49），每轮成本 $O(nm)$；
# - 每 `recompute_every` 轮完全重算残差并记录漂移（式 22.50–22.51）；
# - 固定效应逐元素更新（式 22.9）；
# - 残差方差由式 (22.8) 抽样。

# %%
"""通用贝叶斯回归 Gibbs 抽样（正文 §22.3）。

返回 NamedTuple，含后验均值、样本链与诊断信息。
"""
function bayes_gibbs(y::Vector{Float64}, X::Matrix{Float64}, Z::Matrix{Float64},
                     pr::MarkerPrior;
                     niter::Int=10_000, burnin::Int=2_000, thin::Int=1,
                     nu_e::Float64=4.0, S_e::Float64=NaN,
                     rng=Random.default_rng(), recompute_every::Int=200,
                     keep_alpha::Bool=false)
    n, m = size(Z); p = size(X, 2)
    zz = [dot(view(Z,:,j), view(Z,:,j)) for j in 1:m]
    xx = [dot(view(X,:,l), view(X,:,l)) for l in 1:p]
    isnan(S_e) && (S_e = var(y)*(nu_e-2)/nu_e/2)

    beta  = zeros(p); alpha = zeros(m)
    beta[1] = mean(y)
    e = y .- X*beta
    s2e = var(y)/2

    nsave = length((burnin+1):thin:niter)
    sum_alpha = zeros(m); sum_g = zeros(n)
    chain_s2e = Float64[]; chain_extra = NamedTuple[]
    chain_m1 = Int[]; drift = Float64[]
    alpha_samples = keep_alpha ? Matrix{Float64}(undef, m, nsave) : zeros(0,0)
    ksave = 0

    @inbounds for it in 1:niter
        # ---- 固定效应（式 22.9）----
        for l in 1:p
            xl = view(X, :, l)
            rhs = dot(xl, e) + xx[l]*beta[l]
            old = beta[l]
            beta[l] = rhs/xx[l] + randn(rng)*sqrt(s2e/xx[l])
            @simd for i in 1:n; e[i] -= xl[i]*(beta[l] - old); end
        end

        # ---- 标记效应（式 22.48–22.49）----
        for j in 1:m
            zj  = view(Z, :, j)
            old = alpha[j]
            rhs = dot(zj, e) + zz[j]*old
            new = sample_marker!(pr, j, rhs, zz[j], s2e, rng)
            alpha[j] = new
            d = new - old
            if d != 0.0
                @simd for i in 1:n; e[i] -= zj[i]*d; end
            end
        end

        # ---- 全局超参数 ----
        update_global!(pr, alpha, s2e, rng)

        # ---- 残差方差（式 22.8）----
        s2e = rand_scaled_inv_chisq(rng, nu_e + n, (dot(e,e) + nu_e*S_e)/(nu_e + n))

        # ---- 残差重算与漂移监测（式 22.50–22.51）----
        if it % recompute_every == 0
            e_ref = y .- X*beta .- Z*alpha
            push!(drift, norm(e .- e_ref)/max(norm(e_ref), eps()))
            copyto!(e, e_ref)
        end

        # ---- 收样 ----
        if it > burnin && (it - burnin) % thin == 0
            ksave += 1
            sum_alpha .+= alpha
            mul!(sum_g, Z, alpha, 1.0, 1.0)
            push!(chain_s2e, s2e); push!(chain_extra, extra_stats(pr))
            push!(chain_m1, count(!=(0.0), alpha))
            keep_alpha && (alpha_samples[:, ksave] .= alpha)
        end
    end

    return (alpha = sum_alpha ./ ksave, g = sum_g ./ ksave, beta = beta,
            s2e_chain = chain_s2e, extra = chain_extra, m1_chain = chain_m1,
            drift = drift, alpha_samples = alpha_samples, nsave = ksave)
end

# %% [markdown]
# ## 2　六种先验的实现
#
# ### 2.1 RidgePrior —— SNP-BLUP（正文 §22.2.10）
#
# $\sigma_\alpha^2$ 固定，$\pi=0$。这是全部模型的退化特例，也是我们的**单元测试基准**。

# %%
"""SNP-BLUP：所有位点共享固定的 σ²_α，无变量选择。"""
struct RidgePrior <: MarkerPrior
    s2a::Float64
end
sample_marker!(pr::RidgePrior, j, rhs, zz, s2e, rng) =
    draw_alpha(rhs, zz, s2e, pr.s2a, rng)[1]
extra_stats(pr::RidgePrior) = (s2a = pr.s2a,)

# %% [markdown]
# ### 2.2 BayesA（正文式 22.10、22.14）
#
# $$\alpha_j\mid\sigma^2_{\alpha_j}\sim N(0,\sigma^2_{\alpha_j}),\quad
# \sigma^2_{\alpha_j}\sim\chi^{-2}(\nu_\alpha,S_\alpha)$$
#
# $$\sigma^2_{\alpha_j}\mid\alpha_j\sim\chi^{-2}\!\left(\nu_\alpha+1,\ \frac{\alpha_j^2+\nu_\alpha S_\alpha}{\nu_\alpha+1}\right)$$
#
# 可选 `estimate_S=true` 时启用正文式 (22.17) 的经验贝叶斯改良。

# %%
"""BayesA：位点特异方差 + 尺度逆卡方先验。"""
mutable struct BayesAPrior <: MarkerPrior
    nu::Float64
    S::Float64
    s2j::Vector{Float64}
    estimate_S::Bool
    a0::Float64       # S 的 Gamma 超先验（形状）
    b0::Float64       # S 的 Gamma 超先验（率）
end
BayesAPrior(m::Int; nu=4.0, S=0.01, estimate_S=false, a0=1.0, b0=1.0) =
    BayesAPrior(nu, S, fill(nu*S/(nu-2), m), estimate_S, a0, b0)

function sample_marker!(pr::BayesAPrior, j, rhs, zz, s2e, rng)
    a, _ = draw_alpha(rhs, zz, s2e, pr.s2j[j], rng)
    # 式 (22.14)
    pr.s2j[j] = rand_scaled_inv_chisq(rng, pr.nu + 1, (a^2 + pr.nu*pr.S)/(pr.nu + 1))
    return a
end

function update_global!(pr::BayesAPrior, alpha, s2e, rng)
    if pr.estimate_S            # 式 (22.17)
        m = length(pr.s2j)
        sh = pr.a0 + m*pr.nu/2
        rt = pr.b0 + (pr.nu/2)*sum(inv, pr.s2j)
        pr.S = rand(rng, Gamma(sh, 1/rt))
    end
    return nothing
end
extra_stats(pr::BayesAPrior) = (S = pr.S, s2a_mean = mean(pr.s2j))

# %% [markdown]
# ### 2.3 BayesB（正文式 22.20、22.28–22.29）
#
# 指示变量 $\delta_j$ 的完全条件用**积掉 $b_j$ 的边际似然比**（式 22.28）。
# 被排除位点的 $\sigma^2_{\alpha_j}$ 从先验重抽（正文 §22.2.5 步骤 4）。

# %%
"""BayesB：混合先验 + 位点特异方差，纯 Gibbs（指示变量法）。"""
mutable struct BayesBPrior <: MarkerPrior
    nu::Float64
    S::Float64
    pi0::Float64                 # 零效应位点比例
    s2j::Vector{Float64}
    delta::Vector{Bool}
end
BayesBPrior(m::Int; nu=4.0, S=0.01, pi0=0.99) =
    BayesBPrior(nu, S, pi0, fill(nu*S/(nu-2), m), falses(m))

function sample_marker!(pr::BayesBPrior, j, rhs, zz, s2e, rng)
    lg = logit_delta(rhs, zz, s2e, pr.s2j[j], pr.pi0)     # 式 (22.28)
    pr.delta[j] = rand(rng) < logistic(lg)
    if pr.delta[j]
        a, _ = draw_alpha(rhs, zz, s2e, pr.s2j[j], rng)
        pr.s2j[j] = rand_scaled_inv_chisq(rng, pr.nu + 1, (a^2 + pr.nu*pr.S)/(pr.nu + 1))
        return a
    else
        pr.s2j[j] = rand_scaled_inv_chisq(rng, pr.nu, pr.S)   # 从先验重抽
        return 0.0
    end
end
extra_stats(pr::BayesBPrior) = (pi0 = pr.pi0, m1 = count(pr.delta))

# %% [markdown]
# ### 2.4 BayesC / BayesCπ（正文式 22.30–22.33）
#
# 共同的 $\sigma_\alpha^2$，由式 (22.31) 更新；`estimate_pi=true` 时 $\pi$ 由式 (22.33) 更新。
#
# **重要**：按式 (22.19) 每轮用当前 $\pi$ 重标定 $S_\alpha$，否则 $(\pi,\sigma_\alpha^2)$ 沿脊线漂移、收敛极慢
# （正文 §22.2.6 末段）。

# %%
"""BayesC / BayesCπ：共同方差 + 变量选择。"""
mutable struct BayesCPrior <: MarkerPrior
    nu::Float64
    S::Float64
    pi0::Float64
    s2a::Float64
    delta::Vector{Bool}
    estimate_pi::Bool
    s2A_target::Float64          # 目标总加性方差（用于式 22.19 的重标定）
    sum2pq::Float64
    a_pi::Float64
    b_pi::Float64
end
function BayesCPrior(m::Int; nu=4.0, pi0=0.99, s2A=1.0, sum2pq=1.0,
                     estimate_pi=false, a_pi=1.0, b_pi=1.0)
    S = (nu-2)/nu * s2A/((1-pi0)*sum2pq)             # 式 (22.19)
    BayesCPrior(nu, S, pi0, nu*S/(nu-2), falses(m), estimate_pi, s2A, sum2pq, a_pi, b_pi)
end

function sample_marker!(pr::BayesCPrior, j, rhs, zz, s2e, rng)
    lg = logit_delta(rhs, zz, s2e, pr.s2a, pr.pi0)
    pr.delta[j] = rand(rng) < logistic(lg)
    return pr.delta[j] ? draw_alpha(rhs, zz, s2e, pr.s2a, rng)[1] : 0.0
end

function update_global!(pr::BayesCPrior, alpha, s2e, rng)
    m1 = count(pr.delta)
    ssq = 0.0
    @inbounds for j in eachindex(alpha)
        pr.delta[j] && (ssq += alpha[j]^2)
    end
    # 式 (22.31)
    pr.s2a = rand_scaled_inv_chisq(rng, pr.nu + m1, (ssq + pr.nu*pr.S)/(pr.nu + m1))
    if pr.estimate_pi
        m = length(alpha)
        # 式 (22.33)：π 是零效应比例
        pr.pi0 = rand(rng, Beta(pr.a_pi + m - m1, pr.b_pi + m1))
        pr.pi0 = clamp(pr.pi0, 1e-6, 1 - 1e-6)
        pr.S = (pr.nu-2)/pr.nu * pr.s2A_target/((1-pr.pi0)*pr.sum2pq)   # 重标定
    end
    return nothing
end
extra_stats(pr::BayesCPrior) = (pi0 = pr.pi0, s2a = pr.s2a, m1 = count(pr.delta))

# %% [markdown]
# ### 2.5 Bayesian LASSO（正文定理 22.1、式 22.39–22.40）
#
# 尺度混合表示：$\alpha_j\mid\tau_j^2\sim N(0,\sigma_e^2\tau_j^2)$，$\tau_j^2\sim\mathrm{Exp}(\lambda^2/2)$。
#
# $$\frac{1}{\tau_j^2}\ \Big|\ \cdot\ \sim\ \mathrm{InverseGaussian}\!\left(\sqrt{\lambda^2\sigma_e^2/\alpha_j^2},\ \lambda^2\right)$$

# %%
"""Bayesian LASSO（Park & Casella 2008）。"""
mutable struct BayesLASSOPrior <: MarkerPrior
    lam2::Float64
    tau2::Vector{Float64}
    r0::Float64      # λ² 的 Gamma 超先验（形状）
    d0::Float64      # λ² 的 Gamma 超先验（率）
end
BayesLASSOPrior(m::Int; lam2=1.0, r0=1.0, d0=0.1) =
    BayesLASSOPrior(lam2, fill(1.0, m), r0, d0)

function sample_marker!(pr::BayesLASSOPrior, j, rhs, zz, s2e, rng)
    s2aj = s2e * pr.tau2[j]
    a, _ = draw_alpha(rhs, zz, s2e, s2aj, rng)
    # 式 (22.39)：1/τ² ~ InverseGaussian(μ = sqrt(λ² σe² / α²), shape = λ²)
    a2 = max(a^2, 1e-300)
    mu = sqrt(pr.lam2 * s2e / a2)
    invtau2 = rand(rng, InverseGaussian(mu, pr.lam2))
    pr.tau2[j] = 1/max(invtau2, 1e-300)
    return a
end

function update_global!(pr::BayesLASSOPrior, alpha, s2e, rng)
    m = length(pr.tau2)
    # 式 (22.40)
    pr.lam2 = rand(rng, Gamma(m + pr.r0, 1/(0.5*sum(pr.tau2) + pr.d0)))
    return nothing
end
extra_stats(pr::BayesLASSOPrior) = (lambda = sqrt(pr.lam2), tau2_mean = mean(pr.tau2))

# %% [markdown]
# ### 2.6 BayesR（正文式 22.41–22.45）
#
# 四组分正态混合 $\gamma=(0,10^{-4},10^{-3},10^{-2})$，权重 $\boldsymbol\pi\sim\mathrm{Dirichlet}(\mathbf 1)$。
#
# 组分抽样用 **log-sum-exp** 保证数值稳定（正文式 22.43 后的提醒）。

# %%
"""BayesR：四组分正态混合。"""
mutable struct BayesRPrior <: MarkerPrior
    gam::Vector{Float64}
    pis::Vector{Float64}
    k::Vector{Int}
    s2A::Float64
    nu::Float64
    S::Float64
    alpha_dir::Vector{Float64}
end
function BayesRPrior(m::Int; gam=[0.0, 1e-4, 1e-3, 1e-2], s2A=1.0, nu=4.0)
    S = (nu-2)/nu * s2A
    BayesRPrior(collect(gam), fill(1/length(gam), length(gam)), ones(Int, m),
                s2A, nu, S, ones(length(gam)))
end

function sample_marker!(pr::BayesRPrior, j, rhs, zz, s2e, rng)
    K = length(pr.gam)
    lw = Vector{Float64}(undef, K)
    @inbounds for k in 1:K
        if pr.gam[k] == 0.0
            lw[k] = log(pr.pis[k] + 1e-300)                        # 式 (22.43) 中 k=1
        else
            s2k = pr.gam[k]*pr.s2A
            Cjk = zz + s2e/s2k
            lw[k] = log(pr.pis[k] + 1e-300) - 0.5*log(s2k*Cjk/s2e) + rhs^2/(2*s2e*Cjk)
        end
    end
    mx = maximum(lw)
    w  = exp.(lw .- mx); w ./= sum(w)                              # log-sum-exp
    u = rand(rng); acc = 0.0; kk = K
    @inbounds for k in 1:K
        acc += w[k]
        if u <= acc; kk = k; break; end
    end
    pr.k[j] = kk
    return pr.gam[kk] == 0.0 ? 0.0 :
           draw_alpha(rhs, zz, s2e, pr.gam[kk]*pr.s2A, rng)[1]
end

function update_global!(pr::BayesRPrior, alpha, s2e, rng)
    K = length(pr.gam)
    cnt = zeros(Int, K)
    @inbounds for j in eachindex(pr.k); cnt[pr.k[j]] += 1; end
    # 式 (22.44)：Dirichlet 完全条件
    gdraw = [rand(rng, Gamma(pr.alpha_dir[k] + cnt[k], 1.0)) for k in 1:K]
    pr.pis .= gdraw ./ sum(gdraw)
    # 式 (22.45)
    ssq = 0.0; mplus = 0
    @inbounds for j in eachindex(alpha)
        k = pr.k[j]
        if pr.gam[k] > 0
            ssq += alpha[j]^2/pr.gam[k]; mplus += 1
        end
    end
    pr.s2A = rand_scaled_inv_chisq(rng, pr.nu + mplus, (ssq + pr.nu*pr.S)/(pr.nu + mplus))
    return nothing
end
extra_stats(pr::BayesRPrior) = (pi1 = pr.pis[1], pi2 = pr.pis[2],
                                pi3 = pr.pis[3], pi4 = pr.pis[4], s2A = pr.s2A)

# %% [markdown]
# ## 3　单元测试：$\pi=0$ 且 $\sigma_\alpha^2$ 固定时重现 SNP-BLUP
#
# 正文 §22.2.10：这是验证整个框架最可靠的方法。SNP-BLUP 的解由 MME 直接给出：
#
# $$\hat{\boldsymbol\alpha}=\left(\mathbf Z'\mathbf Z+\mathbf I\lambda_\alpha\right)^{-1}\mathbf Z'\mathbf y^*$$

# %%
"""模拟基因组数据。`arch` 指定遗传结构：:infinitesimal / :oligogenic / :mixed。"""
function sim_gs_data(n::Int, m::Int, h2::Float64; arch::Symbol=:infinitesimal,
                     nqtl::Int=0, rng=Random.default_rng())
    p = 0.05 .+ 0.45 .* rand(rng, m)
    Mg = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        Mg[i,j] = Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j])
    end
    Z = Mg .- 2 .* p'
    alpha = zeros(m)
    if arch === :infinitesimal
        alpha .= randn(rng, m)
    elseif arch === :oligogenic
        q = nqtl == 0 ? max(5, m ÷ 200) : nqtl
        idx = randperm(rng, m)[1:q]
        alpha[idx] .= randn(rng, q)
    else  # :mixed  多基因背景 + 少数大效应
        alpha .= randn(rng, m) .* 0.3
        q = nqtl == 0 ? max(5, m ÷ 300) : nqtl
        idx = randperm(rng, m)[1:q]
        alpha[idx] .+= randn(rng, q) .* 5
    end
    g = Z*alpha
    g .*= sqrt(h2)/std(g)                    # 标度到 σ_g² = h²
    y = 10.0 .+ g .+ randn(rng, n).*sqrt(1-h2)
    return (y=y, Z=Z, Mg=Mg, p=p, g=g, alpha=alpha,
            sum2pq = 2*sum(p .* (1 .- p)))
end

"""SNP-BLUP 的解析解（岭回归）。"""
function snp_blup_solve(y, X, Z, lam_a)
    p = size(X,2)
    C = [X'X  X'Z; Z'X  Z'Z + lam_a*I]
    sol = C \ [X'y; Z'y]
    return sol[1:p], sol[p+1:end]
end

D = sim_gs_data(400, 600, 0.5; arch=:infinitesimal, rng=Xoshiro(2201))
X1 = ones(length(D.y), 1)
s2A = 0.5; s2e = 0.5
s2alpha = s2A / D.sum2pq
lam_a = s2e / s2alpha

b_ref, a_ref = snp_blup_solve(D.y, X1, D.Z, lam_a)

res = bayes_gibbs(D.y, X1, D.Z, RidgePrior(s2alpha);
                  niter=40_000, burnin=8_000, rng=Xoshiro(2202),
                  nu_e=1e8, S_e=s2e)          # 近似固定 σe²

@printf("SNP-BLUP  α̂[1:5] = %s\n", string(round.(a_ref[1:5], digits=5)))
@printf("Gibbs 后验均值    = %s\n", string(round.(res.alpha[1:5], digits=5)))
@printf("\ncor(α̂_Gibbs, α̂_MME) = %.6f\n", cor(res.alpha, a_ref))
@printf("相对误差             = %.3e\n", relerr(res.alpha, a_ref))
@printf("cor(ĝ_Gibbs, ĝ_MME)  = %.6f\n", cor(res.g, D.Z*a_ref))
check("正文 §22.2.10：Gibbs 重现 SNP-BLUP（GEBV）", res.g, D.Z*a_ref; tol=5e-3)

# %% [markdown]
# ### 3.1 收敛到 SNP-BLUP 需要多少轮？
#
# 正文思考题 11。

# %%
println("链长对吻合程度的影响\n")
@printf("%-12s%-18s%-18s\n", "总迭代数", "cor(α̂, α̂_MME)", "相对误差")
for T in (2_000, 5_000, 10_000, 20_000, 40_000, 80_000)
    r = bayes_gibbs(D.y, X1, D.Z, RidgePrior(s2alpha);
                    niter=T, burnin=T÷5, rng=Xoshiro(2203),
                    nu_e=1e8, S_e=s2e)
    @printf("%-12d%-18.6f%-18.3e\n", T, cor(r.alpha, a_ref), relerr(r.alpha, a_ref))
end
println("\n=> 后验均值的蒙特卡洛误差以 1/√T 衰减；")
println("   要达到 3–4 位有效数字，通常需要 2×10⁴ 以上的有效样本。")

# %% [markdown]
# ## 4　数值稳定性：残差漂移（正文式 22.51）

# %%
for re in (50, 500, 5_000, 50_000)
    r = bayes_gibbs(D.y, X1, D.Z, RidgePrior(s2alpha);
                    niter=50_000, burnin=10_000, rng=Xoshiro(2204),
                    recompute_every=re)
    d = isempty(r.drift) ? NaN : maximum(r.drift)
    @printf("每 %6d 轮重算一次：最大相对漂移 = %.3e\n", re, d)
end
println("\n=> 双精度下即使 5 万轮不重算，漂移也只有 1e-12 量级；")
println("   若用单精度（Float32）残差，同样条件下漂移可达 1e-3，不可接受（正文 §22.3.2）。")

# 单精度漂移的直接演示
let n = size(D.Z,1), m = size(D.Z,2)
    Z32 = Float32.(D.Z); a32 = Float32.(a_ref)
    e32 = Float32.(D.y) .- Float32(mean(D.y))
    e64 = Float64.(D.y) .- mean(D.y)
    rng = Xoshiro(2205)
    for it in 1:200, j in 1:m
        d32 = Float32(0.01f0*randn(rng, Float32))
        @inbounds for i in 1:n
            e32[i] -= Z32[i,j]*d32
            e64[i] -= Float64(Z32[i,j])*Float64(d32)
        end
    end
    @printf("\n200 轮 × %d 标记的增量更新后：\n", m)
    @printf("  Float32 相对 Float64 的残差漂移 = %.3e\n",
            norm(Float64.(e32) .- e64)/norm(e64))
end

# %% [markdown]
# ## 5　收敛诊断（正文 §22.3.4）

# %%
"""Gelman–Rubin 的 R̂（split-R̂ 的简化版，多链）。"""
function rhat(chains::Vector{Vector{Float64}})
    m = length(chains); n = minimum(length.(chains))
    X = hcat([c[end-n+1:end] for c in chains]...)      # n × m
    means = vec(mean(X, dims=1)); vars = vec(var(X, dims=1))
    W = mean(vars); B = n*var(means)
    varplus = (n-1)/n*W + B/n
    return sqrt(varplus/W)
end

"""有效样本量（用初始正序列估计自相关和）。"""
function ess(x::Vector{Float64})
    n = length(x); xc = x .- mean(x); v0 = dot(xc,xc)/n
    v0 <= 0 && return float(n)
    s = 0.0
    for k in 1:min(n-2, 2000)
        rk = dot(view(xc,1:n-k), view(xc,1+k:n))/(n*v0)
        rk <= 0 && break
        s += rk
    end
    return n/(1 + 2s)
end

# 三条链，BayesCπ
Dm = sim_gs_data(500, 1000, 0.4; arch=:mixed, rng=Xoshiro(2210))
Xm = ones(length(Dm.y), 1)
chains = []
for c in 1:3
    prc = BayesCPrior(size(Dm.Z,2); pi0=0.95, s2A=0.4, sum2pq=Dm.sum2pq, estimate_pi=true)
    push!(chains, bayes_gibbs(Dm.y, Xm, Dm.Z, prc;
                              niter=20_000, burnin=5_000, rng=Xoshiro(3300+c)))
end

pi_chains  = [Float64[e.pi0 for e in ch.extra] for ch in chains]
s2e_chains = [ch.s2e_chain for ch in chains]
m1_chains  = [Float64.(ch.m1_chain) for ch in chains]

@printf("%-14s%-12s%-14s%-14s\n", "参数", "R̂", "ESS(链1)", "后验均值")
@printf("%-14s%-12.4f%-14.0f%-14.4f\n", "π",   rhat(pi_chains),  ess(pi_chains[1]),  mean(vcat(pi_chains...)))
@printf("%-14s%-12.4f%-14.0f%-14.4f\n", "σe²", rhat(s2e_chains), ess(s2e_chains[1]), mean(vcat(s2e_chains...)))
@printf("%-14s%-12.4f%-14.0f%-14.1f\n", "模型大小 m1", rhat(m1_chains), ess(m1_chains[1]), mean(vcat(m1_chains...)))

# 正文式 (22.52)：GEBV 的前后半段相关
g_all = [ch.g for ch in chains]
@printf("\n三条链 GEBV 两两相关： %.6f  %.6f  %.6f\n",
        cor(g_all[1], g_all[2]), cor(g_all[1], g_all[3]), cor(g_all[2], g_all[3]))
println("（正文式 22.52：应监测 GEBV 而非单个 α_j——高 LD 区域的标签切换使后者永不收敛）")

# %% [markdown]
# ## 6　六种方法在不同遗传结构下的基准比较（正文 §22.4.2）
#
# 用**独立验证集**比较，同时报告 $r$ 与 $b_1$（正文第二十四章 §24.1.1）。

# %%
"""在训练/验证划分上评估一组方法。返回 (r, b1) 的表。"""
function benchmark_priors(n_tr, n_va, m, h2, arch; niter=8_000, seed=7000)
    D = sim_gs_data(n_tr + n_va, m, h2; arch=arch, rng=Xoshiro(seed))
    tr = 1:n_tr; va = (n_tr+1):(n_tr+n_va)
    ytr = D.y[tr]; Ztr = D.Z[tr, :]; Xtr = ones(n_tr, 1)
    Zva = D.Z[va, :]; gva = D.g[va]; yva = D.y[va]
    s2alpha = h2/D.sum2pq

    makers = Pair{String,Function}[
        "SNP-BLUP"  => () -> RidgePrior(s2alpha),
        "BayesA"    => () -> BayesAPrior(m; nu=4.0, S=(4.0-2)/4.0*s2alpha),
        "BayesB"    => () -> BayesBPrior(m; nu=4.0, pi0=0.95,
                                          S=(4.0-2)/4.0*h2/(0.05*D.sum2pq)),
        "BayesC"    => () -> BayesCPrior(m; pi0=0.95, s2A=h2, sum2pq=D.sum2pq),
        "BayesCπ"   => () -> BayesCPrior(m; pi0=0.95, s2A=h2, sum2pq=D.sum2pq,
                                          estimate_pi=true),
        "BayesLASSO"=> () -> BayesLASSOPrior(m; lam2=1.0),
        "BayesR"    => () -> BayesRPrior(m; s2A=h2),
    ]
    rows = NamedTuple[]
    for (nm, f) in makers
        r = bayes_gibbs(ytr, Xtr, Ztr, f(); niter=niter, burnin=niter÷4,
                        rng=Xoshiro(seed+17))
        ghat = Zva*r.alpha
        rr = cor(ghat, gva)
        b1 = cov(gva, ghat)/var(ghat)
        ex = isempty(r.extra) ? NamedTuple() : r.extra[end]
        pi_est = haskey(ex, :pi0) ? ex.pi0 : (haskey(ex, :pi1) ? ex.pi1 : NaN)
        push!(rows, (name=nm, r=rr, b1=b1, pi=pi_est))
    end
    return rows
end

for arch in (:infinitesimal, :mixed, :oligogenic)
    println("\n遗传结构：", arch)
    @printf("%-14s%-12s%-12s%-12s\n", "方法", "r(ĝ,g)", "b1", "π̂（零效应）")
    for row in benchmark_priors(500, 500, 800, 0.4, arch; niter=8_000, seed=7100)
        @printf("%-14s%-12.4f%-12.3f%-12s\n", row.name, row.r, row.b1,
                isnan(row.pi) ? "—" : @sprintf("%.3f", row.pi))
    end
end
println("\n=> 与正文 §22.4.2 的表一致：纯多基因时各方法几乎无差别；")
println("   寡基因时 BayesB/BayesR 显著占优。")

# %% [markdown]
# ## 7　计算复杂度与性能

# %%
println("每轮 Gibbs 扫描的耗时（秒）\n")
@printf("%-16s%-14s%-14s%-16s\n", "规模 n×m", "SNP-BLUP", "BayesR", "每轮/nm (ns)")
for (nn, mm) in ((200, 500), (400, 1000), (800, 2000), (800, 4000))
    Db = sim_gs_data(nn, mm, 0.4; rng=Xoshiro(9000))
    Xb = ones(nn, 1)
    t1 = @elapsed bayes_gibbs(Db.y, Xb, Db.Z, RidgePrior(0.4/Db.sum2pq);
                              niter=200, burnin=0, rng=Xoshiro(1))
    t2 = @elapsed bayes_gibbs(Db.y, Xb, Db.Z, BayesRPrior(mm; s2A=0.4);
                              niter=200, burnin=0, rng=Xoshiro(1))
    @printf("%-16s%-14.4f%-14.4f%-16.1f\n", "$(nn)×$(mm)", t1, t2,
            1e9*t1/200/(nn*mm))
end
println("\n=> 每轮成本正比于 n·m（正文 §22.3.3），每个 (i,j) 约数纳秒。")
println("   BayesR 因组分抽样（4 次对数似然 + log-sum-exp）慢约 1.5–2×。")

# 稀疏模型中跳过 δ=0 标记能省多少？
println("\n稀疏度对耗时的影响（BayesB，n=800, m=4000）：")
Db = sim_gs_data(800, 4000, 0.4; arch=:oligogenic, rng=Xoshiro(9100))
Xb = ones(800, 1)
for pi0 in (0.50, 0.90, 0.99, 0.999)
    prb = BayesBPrior(4000; pi0=pi0, S=0.001)
    t = @elapsed bayes_gibbs(Db.y, Xb, Db.Z, prb; niter=200, burnin=0, rng=Xoshiro(2))
    @printf("  π = %.3f  →  %.4f s / 200 轮\n", pi0, t)
end
println("=> 加速有限（≈2× 上限），因为 rhs_j = z_j'e 对每个标记都必须计算（正文 §22.3.3）。")

# %% [markdown]
# ## 8　与 JWAS 的逐参数交叉验证（可选，需安装 JWAS）
#
# **原则**：同一份数据、同一组先验，两个独立实现的后验均值只应相差蒙特卡洛误差。为此必须把先验逐项对齐（已对照 JWAS 2.4 源码核实）：
#
# | 项目 | JWAS 的设定 | 自实现的对应设定 |
# |:--|:--|:--|
# | 基因型中心化 | `center = true`：减去**样本**列均值 | `Zc = Mg .- 2p̂'`，$\hat p$ 取样本频率 |
# | 标记方差先验均值 | $\sigma_g^2/[(1-\pi)\sum 2\hat p\hat q]$，刻度 $=$ 均值 $\times(\nu-2)/\nu$ | `BayesCPrior(...; s2A = σ²_g, sum2pq = Σ2p̂q̂)`（式 22.19） |
# | 标记方差抽样 | 自由度 $\nu+\sum_j\delta_j$ | 式 (22.31)，相同 |
# | 残差方差先验 | 均值 `R`，刻度 $R(\nu-2)/\nu$ | `S_e = R(ν-2)/ν` |
# | $\pi$ | 零效应比例；本例固定 | `pi0`，本例固定（`estimate_pi = false`） |
# | 质控 | 关闭（`quality_control = false`），保证两边位点完全相同 | — |
#
# **注意**：自实现的 BayesCπ 在更新 $\pi$ 时会按式 (22.19) **重标定**刻度参数，JWAS 不做重标定；所以逐参数对照要在 $\pi$ **固定**时进行——这正是"对照实验只改变一个因素"的原则。

# %%
RUN_JWAS = false            # 先实例化可选环境 envs/jwas（附录 E），再改为 true
if RUN_JWAS
    let env = joinpath(dirname(Base.active_project()), "envs", "jwas")
        isdir(env) || (env = normpath(joinpath(pwd(), "..", "envs", "jwas")))
        env in LOAD_PATH || push!(LOAD_PATH, env)   # 叠加可选环境（附录 E）
    end
    using JWAS, DataFrames
end

# %%
if RUN_JWAS
    Dj = sim_gs_data(500, 800, 0.4; arch = :mixed, rng = Xoshiro(2290))
    n_j, m_j = size(Dj.Mg)
    ids  = string.(1:n_j)
    gdf  = DataFrame(Dj.Mg, ["m$j" for j in 1:m_j])
    insertcols!(gdf, 1, :ID => ids)                  # JWAS：第一列必须是个体编号
    phen = DataFrame(ID = ids, y = Dj.y)

    s2g0 = var(Dj.y)/2; s2e0 = var(Dj.y)/2           # 与 JWAS 默认（h² = 0.5）一致
    pi0  = 0.95
    niter, burn, thin = 30_000, 5_000, 10

    # ---- JWAS（基因型对象必须是 Main 中的全局变量，名字与模型式一致）----
    geno_j = get_genotypes(gdf, s2g0; method = "BayesC", Pi = pi0, estimatePi = false,
                           quality_control = false, center = true)
    model  = build_model("y = intercept + geno_j", s2e0)
    out    = runMCMC(model, phen; chain_length = niter, burnin = burn,
                     output_samples_frequency = thin, seed = 2291,
                     printout_model_info = false, output_folder = "jwas_ch22")

    # ---- 自实现：同样的中心化、同样的先验超参数 ----
    pbar = vec(mean(Dj.Mg; dims = 1)) ./ 2
    Zc   = Dj.Mg .- 2 .* pbar'
    s2pq = 2 * sum(pbar .* (1 .- pbar))
    me   = bayes_gibbs(Dj.y, ones(n_j, 1), Zc,
                       BayesCPrior(m_j; nu = 4.0, pi0 = pi0, s2A = s2g0, sum2pq = s2pq);
                       niter = niter, burnin = burn, thin = thin,
                       nu_e = 4.0, S_e = s2e0*(4.0 - 2)/4.0,
                       rng = Xoshiro(2292), keep_alpha = true)

    vg_me = [var(Zc * view(me.alpha_samples, :, k)) for k in 1:me.nsave]
    h2_me = vg_me ./ (vg_me .+ me.s2e_chain)
    pip_me = vec(mean(me.alpha_samples .!= 0; dims = 2))

    mk  = out["marker effects geno_j"]
    a_j = Float64.(mk[!, :Estimate]); pip_j = Float64.(mk[!, :Model_Frequency])
    ebv = out["EBV_y"]; ebv_j = Float64.(ebv[!, :EBV])
    ebv_me = Zc * me.alpha
    ve  = out["residual variance"]; vg = out["genetic_variance"]; hh = out["heritability"]

    row(nm, a, b, sd) = @printf("%-18s%-14.5f%-14.5f%-10.3f\n", nm, a, b, abs(a - b)/sd)
    @printf("%-18s%-14s%-14s%-10s\n", "参数", "自实现", "JWAS", "|差|/SD")
    row("σ²_e",          mean(me.s2e_chain), Float64(ve[1, :Estimate]), Float64(ve[1, :SD]))
    row("遗传方差 var(Mα)", mean(vg_me),      Float64(vg[1, :Estimate]), Float64(vg[1, :SD]))
    row("h²",            mean(h2_me),        Float64(hh[1, :Estimate]), Float64(hh[1, :SD]))
    @printf("\ncor(α̂_自实现, α̂_JWAS)   = %.4f\n", cor(me.alpha, a_j))
    @printf("cor(PIP_自实现, PIP_JWAS) = %.4f\n", cor(pip_me, pip_j))
    @printf("cor(EBV_自实现, EBV_JWAS) = %.5f ；  max|ΔEBV|/sd(EBV) = %.4f\n",
            cor(ebv_me, ebv_j), maximum(abs.(ebv_me .- ebv_j))/std(ebv_j))
    println("\n判读：标量参数 |差|/SD < 0.25、EBV 相关 > 0.995 即为一致；")
    println("      α̂ 与 PIP 的蒙特卡洛误差较大，相关 > 0.95 即可。")
    rm("jwas_ch22"; recursive = true, force = true)
else
    println("RUN_JWAS = false：跳过 JWAS 逐参数交叉验证。")
end

# %% [markdown]
# ## 9　自检汇总

# %%
ok = Bool[]
push!(ok, check("Gibbs(π=0, 固定 σα²) ≈ SNP-BLUP", res.g, D.Z*a_ref; tol=5e-3))

# logit_delta 的三项分解自检（正文式 22.28）
let rhs = 1.5, zz = 400.0, s2e = 0.5, s2aj = 1e-3, pi0 = 0.99
    Cj = zz + s2e/s2aj
    manual = log((1-pi0)/pi0) - 0.5*log(s2aj*Cj/s2e) + rhs^2/(2*s2e*Cj)
    push!(ok, check("logit_delta 与式 (22.28) 逐项一致",
                    logit_delta(rhs, zz, s2e, s2aj, pi0), manual; tol=1e-14))
    # rhs = 0 时应退化为"先验几率 - 奥卡姆因子"
    @printf("\nrhs = 0 时：P(δ=1) = %.3e ， 先验 1-π = %.3e  （必然更小，因奥卡姆因子）\n",
            logistic(logit_delta(0.0, zz, s2e, s2aj, pi0)), 1-pi0)
end

# 式 (22.19) 的方差重标定自检
let m = 50_000, pi0 = 0.99, s2A = 1.0, sum2pq = 10_000.0, nu = 4.0
    S_ok   = (nu-2)/nu * s2A/((1-pi0)*sum2pq)
    S_bad  = (nu-2)/nu * s2A/sum2pq
    @printf("\n式 (22.19)：S_α = %.3e ；漏掉 (1-π) 则为 %.3e ，小 %.0f 倍\n",
            S_ok, S_bad, S_ok/S_bad)
    push!(ok, check("式 (22.19) 的 (1-π) 因子", S_ok/S_bad, 1/(1-pi0); tol=1e-12))
end

# 定理 22.1：Laplace 的正态尺度混合表示（蒙特卡洛验证）
let lam = 2.0, rng = Xoshiro(555), nrep = 4_000_000
    t2 = rand(rng, Exponential(2/lam^2), nrep)      # τ² ~ Exp(λ²/2)，Julia 用均值参数化
    a  = sqrt.(t2) .* randn(rng, nrep)
    @printf("\n定理 22.1 蒙特卡洛：Var(α) = %.4f （理论 2/λ² = %.4f）\n",
            var(a), 2/lam^2)
    @printf("                    E|α|    = %.4f （理论 1/λ  = %.4f）\n",
            mean(abs, a), 1/lam)
    push!(ok, check("定理 22.1：Var(α) = 2/λ²", var(a), 2/lam^2; tol=5e-3))
end

@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
