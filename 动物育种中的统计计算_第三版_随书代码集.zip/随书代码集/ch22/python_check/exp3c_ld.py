# -*- coding: utf-8 -*-
"""Exp 3c (section 22.3): single-site Gibbs mixing vs LD strength.
n = 1000, one segment of m = 200 SNPs, all with allele frequency 0.3; latent AR(1) correlation rho.
Genotype seed 2231 (same for every rho), residual seed 2232.  QTL = SNP index 100, Var(z a) = 0.2,
e ~ N(0, 0.8).  Genotypes centered by the sample mean (so mu is orthogonal to Z).
Model 1: SNP-BLUP Gibbs, sigma_e^2 = 0.8 and sigma_alpha^2 = 0.2/(2 sum pq) fixed (Gaussian target).
Model 2: BayesC, pi = 0.99 fixed, sigma_alpha^2 = 0.2/((1-pi) 2 sum pq) fixed (eq 22.19), sigma_e^2 = 0.8 fixed.
Chains: 50000 iterations, burn-in 5000, MCMC seed 22.  tau_int: Geyer initial positive sequence.
Exact tau for model 1 from the Gauss-Seidel iteration matrix B = -(D+L)^{-1}U:
  Cov(alpha^{t+k}, alpha^t) = B^k Sigma, Sigma = se2 * (Z'Z + lam I)^{-1}.
"""
import os, sys, json
os.environ['OPENBLAS_NUM_THREADS'] = '1'; os.environ['OMP_NUM_THREADS'] = '1'
import numpy as np
from scipy.linalg import solve_triangular
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from simdata import sim_haplotypes
from bayes import Data, run
from common import ess_geyer

HERE = os.path.dirname(os.path.abspath(__file__))
NIT, BURN = 50000, 5000
n, m, q = 1000, 200, 100


def exact_tau(A, se2, f, kmax=200000, tol=1e-12):
    """Exact integrated autocorrelation time of f'alpha for systematic-scan Gibbs on N(., se2 A^{-1})."""
    Lw = np.tril(A)            # D + L
    U = np.triu(A, 1)
    Sigma = se2 * np.linalg.inv(A)
    v = Sigma @ f              # Sigma f
    var = f @ v
    tau = 1.0
    x = v.copy()
    for k in range(1, kmax):
        x = -solve_triangular(Lw, U @ x, lower=True)     # B^k Sigma f
        rk = (f @ x) / var
        tau += 2 * rk
        if abs(rk) < tol and k > 10:
            break
    return tau


def main():
    rhos = [float(x) for x in sys.argv[1:]] or [0.0, 0.8, 0.9, 0.95, 0.98, 0.99, 0.995, 0.999]
    out = []
    for rho in rhos:
        rng = np.random.default_rng(2231)
        p = np.full(m, 0.3)
        H = sim_haplotypes(rng, 2 * n, 1, m, rho, p)
        X = (H[0::2] + H[1::2]).astype(float)
        Z = X - X.mean(0)
        sd = Z.std(0)
        R = np.corrcoef(Z.T)
        adj_r2 = float(np.mean(np.diag(R, 1) ** 2))
        r2q = R[q] ** 2
        nb = [float(r2q[q - 1]), float(r2q[q + 1])]
        n_hi = int(np.sum(r2q > 0.8) - 1)
        aq = np.sqrt(0.2 / np.var(Z[:, q]))
        re = np.random.default_rng(2232)
        y = Z[:, q] * aq + re.standard_normal(n) * np.sqrt(0.8)
        s2pq = float(np.sum(Z.var(0)))
        sa2_rr = 0.2 / s2pq
        sa2_c = 0.2 / (0.01 * s2pq)
        D = Data(Z.T, y)
        A = Z.T @ Z + (0.8 / sa2_rr) * np.eye(m)
        Lw = np.tril(A); U = np.triu(A, 1)
        B = -solve_triangular(Lw, U, lower=True)
        rhoB = float(np.max(np.abs(np.linalg.eigvals(B))))
        w = np.zeros(m); w[q - 5:q + 6] = 1.0
        fq = np.zeros(m); fq[q] = 1.0
        rec = dict(rho=rho, adj_r2=adj_r2, r2_nb=nb, n_r2_gt08=n_hi, rhoB=rhoB,
                   tau_theory_max=(1 + rhoB) / (1 - rhoB))
        rec['exact_tau_alpha'] = exact_tau(A, 0.8, fq)
        rec['exact_tau_win'] = exact_tau(A, 0.8, w)
        rec['exact_tau_gebv'] = [exact_tau(A, 0.8, Z[i]) for i in range(10)]
        # second pass: store functionals by using Zpred trick (pred = mu + Zpred alpha)
        Zf = np.vstack([fq, w, Z[:10]])           # rows: alpha_q, window sum, 10 GEBVs
        for model, hp in [('RR', dict(nu_e=4, S_e=0.4, se2_0=0.8, fixed_se2=True, nu_a=4, S_a=sa2_rr / 2,
                                       fixed_sa2=True)),
                          ('C', dict(nu_e=4, S_e=0.4, se2_0=0.8, fixed_se2=True, nu_a=4, S_a=sa2_c / 2,
                                     fixed_sa2=True))]:
            init = dict(se2=0.8, sa2=sa2_rr if model == 'RR' else sa2_c, pi=0.99)
            o = run(model, D, hp, NIT, BURN, 1, seed=22, init=init, est_pi=False, Zpred=Zf)
            P = o['pred_draws'] - o['mu_draws'][:, None]   # remove mu
            taus = [ess_geyer(P[:, i])[1] for i in range(P.shape[1])]
            T = o['traces']
            r = dict(tau_alpha=taus[0], tau_win=taus[1], tau_gebv=taus[2:], tau_gebv_med=float(np.median(taus[2:])),
                     tau_vg=ess_geyer(T['vg'][BURN:])[1],
                     post_alpha_q=float(o['alpha'][q]), post_sd_alpha_q=float(o['alpha_sd'][q]),
                     post_win=float(np.mean(P[:, 1])), cpu=o['cpu'], true_aq=float(aq))
            if model == 'C':
                r['tau_m1'] = ess_geyer(T['m1'][BURN:])[1]
                r['incl_q'] = float(o['incl'][q])
                r['incl_nb'] = [float(o['incl'][q - 1]), float(o['incl'][q + 1])]
                # number of switches of the "carrier" marker: argmax |alpha| in window
            rec[model + '_f'] = r
        print(json.dumps(rec), flush=True)
        out.append(rec)
    json.dump(out, open(os.path.join(HERE, 'exp3c_%s.json' % ('_'.join(str(r) for r in rhos))), 'w'), indent=1)


if __name__ == '__main__':
    main()
