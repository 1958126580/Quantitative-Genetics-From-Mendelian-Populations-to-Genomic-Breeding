# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 22 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 exp2_bayesA.py    依赖：numpy
"""Exp 2 (section 22.2): BayesA prior sensitivity to (nu_a, S_a), architecture S.
S_a = mult * S*(nu),  S*(nu) = (nu-2)/nu * sigma_A^2 / (2 sum pq)  (eq 22.15), so the prior mean of
sigma^2_{alpha_j} equals mult * sigma_A^2/(2 sum pq) for every nu.
Chains: 10000 iterations, burn-in 2000, MCMC seed 22.  Remedy rows: S_a ~ Gamma(1, 1e-6) (eq 22.17).
Usage: python3 exp2_bayesA.py [part]  (part 0 = grid, part 1 = remedy + n=500 check)
"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import os, sys, json
os.environ['OPENBLAS_NUM_THREADS'] = '1'; os.environ['OMP_NUM_THREADS'] = '1'
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import make_data, centered, accuracy
from bayes import Data, run
from exp1_main import metrics

HERE = os.path.dirname(os.path.abspath(__file__))
NIT, BURN, THIN = 10000, 2000, 10


def one(d, Z, idx_tr, iva, nu, mult, S_hyper=None, start_mult=None, tagname=''):
    y = d['yS']; ytr = y[idx_tr]
    pf = d['pf']; tpq = 2 * pf * (1 - pf); sum2pq = float(tpq.sum())
    vp = float(np.var(ytr)); sA, sE = 0.5 * vp, 0.5 * vp
    Sstar = (nu - 2) / nu * sA / sum2pq
    S_a = mult * Sstar if start_mult is None else start_mult * Sstar
    hp = dict(nu_e=4.0, S_e=0.5 * sE, se2_0=sE, nu_a=nu, S_a=S_a, S_hyper=S_hyper)
    D = Data(Z[idx_tr].T, ytr)
    o = run('A', D, hp, NIT, BURN, THIN, seed=22, verbose=0)
    alpha = o['alpha']
    met = metrics('S', d, Z, alpha, o['mu_mean'], iva, idx_tr)
    T = o['traces']
    prior_mean = mult * sA / sum2pq if S_hyper is None else float('nan')
    qtl = d['qtl']; big = met['big_qtl']
    far = np.ones(len(alpha), bool)
    for q in qtl:
        far[max(q - 20, 0):q + 21] = False
    s2m = o['s2_mean']
    Ea2 = alpha ** 2 + o['alpha_sd'] ** 2
    if S_hyper is not None:
        S_post = float(np.mean(T['S_a'][BURN:]))
        nuS = nu * S_post
        prior_mean_post = nu * S_post / (nu - 2)
    else:
        S_post = S_a; nuS = nu * S_a; prior_mean_post = prior_mean
    met.update(nu=nu, mult=mult, S_a=S_a, Sstar=Sstar, S_post=S_post, prior_mean=prior_mean_post,
               vg=float(np.mean(T['vg'][BURN:])), se2=o['se2_mean'],
               s2_far_ratio=float(np.mean(s2m[far]) / prior_mean_post),
               s2_big_ratio=float(s2m[big] / prior_mean_post),
               data_share_big=float(Ea2[big] / (Ea2[big] + nuS)),
               data_share_far=float(np.mean(Ea2[far] / (Ea2[far] + nuS))),
               time=o['time'], tag=tagname)
    print(json.dumps({k: v for k, v in met.items() if k != 'per_qtl'}), flush=True)
    return met


def main():
    part = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    d = make_data(); Z = centered(d)
    itr, iva = d['itr'], d['iva']
    fn = os.path.join(HERE, 'exp2_grid.json' if part == 0 else 'exp2_remedy.json')
    out = json.load(open(fn)) if os.path.exists(fn) else []
    done = {(r['tag'], r['nu'], r['mult']) for r in out}
    def add(rec):
        out.append(rec); json.dump(out, open(fn, 'w'), indent=1)
    if part == 0:
        for nu in [3.0, 4.012, 10.0, 50.0]:
            for mult in [0.1, 1.0, 10.0]:
                if ('grid', nu, mult) not in done:
                    add(one(d, Z, itr, iva, nu, mult, tagname='grid'))
    else:
        # remedy: estimate S_a (eq 22.17), starting from 0.1 S* and 10 S*
        for sm in [0.1, 10.0]:
            if ('estS', 4.012, sm) not in done:
                add(one(d, Z, itr, iva, 4.012, sm, S_hyper=(1.0, 1e-6), start_mult=sm, tagname='estS'))
        # n = 500 training subset: does the posterior of sigma^2_alpha_j sharpen with n?
        sub = itr[:500]
        for mult in [0.1, 1.0, 10.0]:
            if ('n500', 4.012, mult) not in done:
                add(one(d, Z, sub, iva, 4.012, mult, tagname='n500'))


if __name__ == '__main__':
    main()
