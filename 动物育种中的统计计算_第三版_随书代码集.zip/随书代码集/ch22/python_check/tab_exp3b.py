# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 22 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 tab_exp3b.py    依赖：numpy
"""Diagnostics table for exp3b (4 chains x 20000, burn 5000): Rhat, split-Rhat, ESS (sum of Geyer per chain),
tau (mean over chains), MCSE; GEBV agreement between chains."""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import os, sys, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import make_data, centered, ess_geyer, gelman_rubin, split_rhat
from exp3c_bc import tau_bm

HERE = os.path.dirname(os.path.abspath(__file__))
BURN = 5000
d = make_data(); Z = centered(d); iva = d['iva']
out = {}
for arch in 'SI':
    f = os.path.join(HERE, f'exp3b_{arch}.npz')
    if not os.path.exists(f):
        continue
    z = np.load(f)
    g = d['g' + arch][iva]
    res = {}
    for key in ['pi', 'sa2', 'siga2', 'vg', 'se2', 'm1']:
        M = z[key][:, BURN:]
        allv = M.ravel()
        e_t = [ess_geyer(M[c]) for c in range(M.shape[0])]
        ess = float(sum(e for e, t in e_t))
        taus = [t for e, t in e_t]
        bm = [tau_bm(M[c]) for c in range(M.shape[0])]
        res[key] = dict(mean=float(allv.mean()), sd=float(allv.std(ddof=1)), rhat=gelman_rubin(M),
                        srhat=split_rhat(M), ess=ess, tau=float(np.mean(taus)), tau_bm=float(np.mean(bm)),
                        mcse=float(allv.std(ddof=1) / np.sqrt(ess)),
                        chain_means=[float(x) for x in M.mean(1)],
                        rhat_burn={str(b): gelman_rubin(z[key][:, b:]) for b in [0, 1000, 5000, 10000]})
        r = res[key]
        print(f"{arch} {key:6s} mean={r['mean']:.6g} sd={r['sd']:.4g} Rhat={r['rhat']:.4f} sRhat={r['srhat']:.4f} "
              f"ESS={r['ess']:.0f} tau={r['tau']:.1f} tauBM={r['tau_bm']:.1f} MCSE={r['mcse']:.3g} "
              f"chains={['%.4g' % x for x in r['chain_means']]} Rhat(burn0)={r['rhat_burn']['0']:.3f}")
    A = z['alphas']
    G = A @ Z[iva].T
    C = np.corrcoef(G)
    iu = np.triu_indices(4, 1)
    res['gebv_corr_min'] = float(C[iu].min())
    res['gebv_corr_max'] = float(C[iu].max())
    res['r_chains'] = [float(np.corrcoef(G[c], g)[0, 1]) for c in range(4)]
    # first-half vs second-half style criterion (eq 22.52) is not available per chain; use chain agreement
    print(arch, 'GEBV corr between chains min %.6f max %.6f' % (res['gebv_corr_min'], res['gebv_corr_max']),
          'r per chain', ['%.4f' % x for x in res['r_chains']])
    out[arch] = res
json.dump(out, open(os.path.join(HERE, 'tab_exp3b.json'), 'w'), indent=1)
