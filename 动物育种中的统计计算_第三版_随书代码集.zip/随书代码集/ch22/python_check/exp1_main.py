# -*- coding: utf-8 -*-
"""Exp 1 (sections 22.1-22.2): six methods on the same simulated data, two architectures.
Usage: python3 exp1_main.py S|I [n_iter burn thin]
Chain: 20000 iterations, burn-in 5000, thin 10 (default); MCMC seed 22 for every model.
"""
import os, sys, json, time
os.environ['OPENBLAS_NUM_THREADS'] = '1'; os.environ['OMP_NUM_THREADS'] = '1'
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import make_data, centered, GBLUP, accuracy
from bayes import Data, run

HERE = os.path.dirname(os.path.abspath(__file__))


def hyper(ytr, sum2pq, m):
    vp = float(np.var(ytr))
    sA, sE = 0.5 * vp, 0.5 * vp           # prior guess h2 = 0.5
    nu_e = 4.0
    hp = dict(nu_e=nu_e, S_e=(nu_e - 2) / nu_e * sE, se2_0=sE)
    nuA = 4.012
    H = {}
    H['A'] = dict(hp, nu_a=nuA, S_a=(nuA - 2) / nuA * sA / sum2pq)                          # eq 22.15
    H['B'] = dict(hp, nu_a=nuA, S_a=(nuA - 2) / nuA * sA / ((1 - 0.95) * sum2pq), pi=0.95)  # eq 22.19
    H['C'] = dict(hp, nu_a=4.0, S_a=(4.0 - 2) / 4.0 * sA / ((1 - 0.95) * sum2pq))           # eq 22.19, pi_guess .95
    H['R'] = dict(hp, gamma=[0.0, 1e-4, 1e-3, 1e-2], nu_A=4.0, S_A=(4.0 - 2) / 4.0 * sA)
    H['L'] = dict(hp, r=1.0, delta=1e-4, lam2_0=2 * sE * sum2pq / sA)
    return H


def metrics(arch, d, Z, alpha, mu, iva, itr):
    g = d['g' + arch]; a_true = d['a' + arch]
    ghat_va = mu + Z[iva] @ alpha
    r, b = accuracy(ghat_va, g[iva])
    out = dict(r=r, b=b)
    qtl = d['qtl']
    m = len(alpha)
    if arch == 'S':
        big = int(qtl[np.argmax([np.var(Z[:, q] * a_true[q]) for q in qtl])])
        out['big_qtl'] = big
        out['big_ratio'] = float(alpha[big] / a_true[big])
        num, den = 0.0, 0.0
        per = []
        for q in qtl:
            lo, hi = max(q - 10, (q // 200) * 200), min(q + 11, (q // 200 + 1) * 200)
            gq = Z[:, q] * a_true[q]
            gw = Z[:, lo:hi] @ alpha[lo:hi]
            c = float(np.cov(gw, gq)[0, 1]); v = float(np.var(gq, ddof=1))
            num += c; den += v
            per.append(dict(q=int(q), share=float(np.var(gq) / np.var(g)), at=float(alpha[q] / a_true[q]),
                            win=c / v))
        out['win_capture'] = num / den
        out['per_qtl'] = per
        far = np.ones(m, bool)
        for q in qtl:
            far[max(q - 20, 0):q + 21] = False
        out['far_mean_abs'] = float(np.mean(np.abs(alpha[far])))
        out['far_n'] = int(far.sum())
    else:
        top = np.argsort(-np.abs(a_true))[:10]
        out['top10_ratio'] = float(np.mean(alpha[top] / a_true[top]))
        out['slope_alpha'] = float(np.cov(alpha, a_true)[0, 1] / np.var(a_true, ddof=1))
        out['corr_alpha'] = float(np.corrcoef(alpha, a_true)[0, 1])
    return out


def main():
    arch = sys.argv[1]
    n_iter, burn, thin = (int(x) for x in sys.argv[2:5]) if len(sys.argv) > 4 else (20000, 5000, 10)
    tag = sys.argv[5] if len(sys.argv) > 5 else 'main'
    d = make_data()
    Z = centered(d)
    itr, iva = d['itr'], d['iva']
    y = d['y' + arch]
    ytr = y[itr]
    pf = d['pf']
    tpq = 2 * pf * (1 - pf)
    sum2pq = float(tpq.sum())
    m = Z.shape[1]
    H = hyper(ytr, sum2pq, m)
    res = {}
    # GBLUP
    t0 = time.perf_counter()
    gb = GBLUP(Z[itr], sum2pq).fit(ytr)
    tg = time.perf_counter() - t0
    met = metrics(arch, d, Z, gb.alpha, gb.mu, iva, itr)
    met.update(time=tg, sg2=gb.sg2, se2=gb.se2, h2=gb.sg2 / (gb.sg2 + gb.se2))
    res['GBLUP'] = met
    np.save(os.path.join(HERE, f'{tag}_{arch}_GBLUP_alpha.npy'), gb.alpha)
    print('GBLUP', json.dumps({k: v for k, v in met.items() if k != 'per_qtl'}), flush=True)
    Dc = Data(Z[itr].T, ytr)
    sd = np.sqrt(tpq)
    Ds = Data((Z[itr] / sd).T, ytr)
    for model in ['A', 'B', 'C', 'R', 'L']:
        DD = Ds if model == 'R' else Dc
        Zp = (Z[iva] / sd) if model == 'R' else Z[iva]
        o = run(model, DD, H[model], n_iter, burn, thin, seed=22, Zpred=Zp, store_resid=True,
                verbose=5000)
        alpha = o['alpha'] / sd if model == 'R' else o['alpha']
        met = metrics(arch, d, Z, alpha, o['mu_mean'], iva, itr)
        T = o['traces']
        met.update(time=o['time'], se2=o['se2_mean'], vg=float(np.mean(T['vg'][burn:])),
                   m1=float(np.mean(T['m1'][burn:])))
        if model == 'C':
            met['pi'] = float(np.mean(T['pi'][burn:]))
            met['sa2'] = float(np.mean(T['sa2'][burn:]))
        if model == 'R':
            met['pi'] = [float(x) for x in T['pi'][burn:].mean(0)]
            met['sA2'] = float(np.mean(T['sA2'][burn:]))
        if model == 'L':
            met['lam2'] = float(np.mean(T['lam2'][burn:]))
        res[model] = met
        print(model, json.dumps({k: v for k, v in met.items() if k != 'per_qtl'}), flush=True)
        np.savez_compressed(os.path.join(HERE, f'{tag}_{arch}_{model}.npz'), alpha=alpha,
                            alpha_raw=o['alpha'], incl=o['incl'],
                            res_draws=o['res_draws'], se2_draws=o['se2_draws'], mu_draws=o['mu_draws'],
                            pred_draws=o['pred_draws'],
                            **{'tr_' + k: v for k, v in T.items()},
                            **({'s2_mean': o['s2_mean']} if 's2_mean' in o else {}))
    json.dump(res, open(os.path.join(HERE, f'{tag}_{arch}.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
