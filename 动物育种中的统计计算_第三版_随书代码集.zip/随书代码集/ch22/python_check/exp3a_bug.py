# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 22 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 exp3a_bug.py    依赖：numpy, scipy
"""Exp 3a (bug demo): BayesCpi in float64 with a typical implementation bug:
when alpha_j leaves the model (new value 0, old value nonzero) the residual is NOT updated.
Drift (eq 22.51) checked every 100 iterations without reset; 2000 iterations; MCMC seed 22."""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import os, sys, json
os.environ['OPENBLAS_NUM_THREADS'] = '1'; os.environ['OMP_NUM_THREADS'] = '1'
import numpy as np
from math import sqrt, log, exp
from scipy.linalg.blas import daxpy, ddot
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import make_data, centered
from exp1_main import hyper

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    d = make_data(); Z = centered(d)
    itr = d['itr']; y = d['yS'][itr].copy()
    pf = d['pf']; s2pq = float((2 * pf * (1 - pf)).sum())
    hp = hyper(y, s2pq, Z.shape[1])['C']
    Zt = np.ascontiguousarray(Z[itr].T); m, n = Zt.shape
    rows = [Zt[j] for j in range(m)]; zz = [float(ddot(r, r)) for r in rows]
    rng = np.random.default_rng(22)
    nu_a, S_a, nu_e, S_e = hp['nu_a'], hp['S_a'], hp['nu_e'], hp['S_e']
    se2 = hp['se2_0']; sa2 = nu_a * S_a / (nu_a - 2); pi = 0.5
    mu = float(y.mean()); a = [0.0] * m; e = y - mu
    drift = []; se2s = []; vgs = []
    for it in range(2000):
        e += mu
        mu = float(e.mean()) + sqrt(se2 / n) * rng.standard_normal()
        e -= mu
        rn = rng.standard_normal(m).tolist(); ru = rng.random(m).tolist()
        lo = log((1 - pi) / pi); lam = se2 / sa2; hl = 0.5 * log(sa2 / se2)
        for j in range(m):
            zj = rows[j]; aj = a[j]; zzj = zz[j]
            rhs = float(ddot(zj, e)) + zzj * aj
            C = zzj + lam
            lg = lo - hl - 0.5 * log(C) + rhs * rhs / (2.0 * se2 * C)
            P = 1.0 / (1.0 + exp(-lg)) if lg >= 0 else exp(lg) / (1.0 + exp(lg))
            new = rhs / C + sqrt(se2 / C) * rn[j] if ru[j] < P else 0.0
            if new != aj and new != 0.0:          # BUG: should be  if new != aj:
                daxpy(zj, e, a=aj - new)
            a[j] = new
        aa = np.array(a)
        m1 = int(np.count_nonzero(aa))
        sa2 = (float(aa @ aa) + nu_a * S_a) / rng.chisquare(nu_a + m1)
        pi = rng.beta(m - m1 + 1.0, m1 + 1.0)
        se2 = (float(ddot(e, e)) + nu_e * S_e) / rng.chisquare(n + nu_e)
        se2s.append(se2); vgs.append(float(np.var(y - mu - Zt.T @ aa)))
        if (it + 1) % 100 == 0:
            e_ref = y - mu - Zt.T @ aa
            drift.append((it + 1, float(np.linalg.norm(e_ref - e) / np.linalg.norm(e_ref))))
            print(it + 1, 'drift %.3e se2 %.4f m1 %d pi %.4f' % (drift[-1][1], se2, m1, pi), flush=True)
    json.dump(dict(drift=drift, se2_mean=float(np.mean(se2s[1000:])), se2_first=se2s[:5]),
              open(os.path.join(HERE, 'exp3a_bug.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
