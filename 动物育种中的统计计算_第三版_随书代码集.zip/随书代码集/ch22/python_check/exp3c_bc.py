# -*- coding: utf-8 -*-
"""Exp 3c part 2 (section 22.3): BayesC label switching under LD (empirical).
Segment as in exp3c_exact (n = 1000, m = 200, p = 0.3, genotype seed 2231); QTL = SNP 100 with
Var(z a) = 0.05; e ~ N(0, 0.95) (seed 2232).  BayesC: pi = 0.99 fixed, slab variance from eq 22.19
(sigma_A^2 = 0.05), sigma_e^2 = 0.95 fixed.  100000 iterations, burn-in 5000, MCMC seed 22.
tau by batch means (batch size 1000) and by Geyer IPS.
"""
import os, sys, json
os.environ['OPENBLAS_NUM_THREADS'] = '1'; os.environ['OMP_NUM_THREADS'] = '1'
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exp3c_exact import geno, n, m, q
from bayes import Data, run
from common import ess_geyer

HERE = os.path.dirname(os.path.abspath(__file__))
NIT, BURN, BS = 100000, 5000, 1000


def tau_bm(x, b=BS):
    x = np.asarray(x, float)
    a = len(x) // b
    xb = x[:a * b].reshape(a, b).mean(1)
    v = x.var(ddof=1)
    return float(b * xb.var(ddof=1) / v) if v > 0 else float('nan')


def main():
    rhos = [float(x) for x in sys.argv[1:]] or [0.9, 0.98, 0.99, 0.995, 0.999]
    out = []
    for rho in rhos:
        Z = geno(rho)
        R = np.corrcoef(Z.T)
        aq = np.sqrt(0.05 / np.var(Z[:, q]))
        re = np.random.default_rng(2232)
        y = Z[:, q] * aq + re.standard_normal(n) * np.sqrt(0.95)
        s2pq = float(np.sum(Z.var(0)))
        sa2 = 0.05 / (0.01 * s2pq)
        D = Data(Z.T, y)
        W = list(range(q - 5, q + 6))
        F = np.zeros((len(W) + 1 + 10, m))
        for i, k in enumerate(W):
            F[i, k] = 1.0
        F[len(W), q - 5:q + 6] = 1.0
        F[len(W) + 1:] = Z[:10]
        hp = dict(nu_e=4, S_e=0.475, se2_0=0.95, fixed_se2=True, nu_a=4, S_a=sa2 / 2, fixed_sa2=True)
        o = run('C', D, hp, NIT, BURN, 1, seed=22, init=dict(se2=0.95, sa2=sa2, pi=0.99), est_pi=False, Zpred=F)
        P = o['pred_draws'] - o['mu_draws'][:, None]
        Aw = P[:, :len(W)]
        win = P[:, len(W)]
        G = P[:, len(W) + 1:]
        nz = np.abs(Aw) > 0
        carrier = np.where(nz.any(1), np.argmax(np.abs(Aw), 1), -1)
        sw = int(np.sum((carrier[1:] != carrier[:-1]) & (carrier[1:] >= 0) & (carrier[:-1] >= 0)))
        # switches between distinct carriers counting through empty states
        last = -1; sw2 = 0
        for c in carrier:
            if c >= 0:
                if last >= 0 and c != last:
                    sw2 += 1
                last = c
        incl = nz.mean(0)
        rec = dict(rho=rho, r2_nb=[float(R[q, q - 1] ** 2), float(R[q, q + 1] ** 2)],
                   n_r2_gt09=int(np.sum(R[q, W] ** 2 > 0.9) - 1),
                   incl_window=[float(x) for x in incl], incl_q=float(incl[5]),
                   incl_nb_max=float(max(np.delete(incl, 5))),
                   p_any=float(nz.any(1).mean()),
                   switches=sw2, switches_adjacent=sw,
                   tau_bm_alpha=tau_bm(Aw[:, 5]), tau_bm_win=tau_bm(win),
                   tau_bm_gebv_med=float(np.median([tau_bm(G[:, i]) for i in range(10)])),
                   tau_geyer_alpha=ess_geyer(Aw[:, 5])[1], tau_geyer_win=ess_geyer(win)[1],
                   tau_geyer_gebv_med=float(np.median([ess_geyer(G[:, i])[1] for i in range(10)])),
                   post_alpha_q=float(np.mean(Aw[:, 5])), post_win=float(np.mean(win)), true_aq=float(aq),
                   cpu=o['cpu'])
        print(json.dumps(rec), flush=True)
        out.append(rec)
    json.dump(out, open(os.path.join(HERE, 'exp3c_bc.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
