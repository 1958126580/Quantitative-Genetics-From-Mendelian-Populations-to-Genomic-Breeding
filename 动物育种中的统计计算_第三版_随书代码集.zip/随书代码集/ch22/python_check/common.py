# -*- coding: utf-8 -*-
"""Chapter 22 (3rd ed.) numerical experiments: shared data, GBLUP/REML, diagnostics.

Main data set (used by all section 22.1-22.4 experiments):
  * n = 2000 unrelated individuals (haplotypes drawn independently), 1500 training / 500 validation
    (random split, seed 2204).
  * m = 2000 SNPs on 10 chromosomes x 200 SNPs. Haplotypes: latent Gaussian AR(1) along the chromosome,
    adjacent latent correlation rho = 0.95; allele frequency p_j ~ U(0.05, 0.5). Seed 2201.
  * Architecture S ("few large"): 10 QTL among the SNPs (positions >= 20 SNPs apart, >= 10 from
    chromosome ends), effects N(0,1), seed 2202.  Architecture I ("infinitesimal"): all 2000 SNPs
    causal, effects N(0,1), seed 2203.  Both scaled so that Var(g) = 0.5 over the 2000 individuals;
    e ~ N(0, 0.5) (h2 = 0.5, sigma_P^2 = 1).
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np
from scipy import optimize
from simdata import sim_genotypes

HERE = os.path.dirname(os.path.abspath(__file__))
NCHR, MCHR, RHO = 10, 200, 0.95
N, NTRAIN = 2000, 1500
H2 = 0.5


def make_data():
    f = os.path.join(HERE, 'data.npz')
    if os.path.exists(f):
        d = np.load(f)
        return {k: d[k] for k in d.files}
    X, p = sim_genotypes(2201, N, NCHR, MCHR, RHO)
    m = X.shape[1]
    rng = np.random.default_rng(2204)
    perm = rng.permutation(N)
    itr, iva = np.sort(perm[:NTRAIN]), np.sort(perm[NTRAIN:])
    # architecture S
    rs = np.random.default_rng(2202)
    cand = [c * MCHR + k for c in range(NCHR) for k in range(10, MCHR - 10)]
    qtl = []
    while len(qtl) < 10:
        j = int(rs.choice(cand))
        if all(abs(j - q) >= 20 for q in qtl):
            qtl.append(j)
    qtl = np.array(sorted(qtl))
    aS = np.zeros(m)
    aS[qtl] = rs.standard_normal(10)
    Xf = X.astype(float)
    pf = Xf.mean(0) / 2.0
    Z = Xf - 2 * pf
    gS = Z @ aS
    c = np.sqrt(H2 / gS.var())
    aS *= c; gS *= c
    eS = rs.standard_normal(N) * np.sqrt(1 - H2)
    yS = gS + eS
    # architecture I
    ri = np.random.default_rng(2203)
    aI = ri.standard_normal(m)
    gI = Z @ aI
    c = np.sqrt(H2 / gI.var())
    aI *= c; gI *= c
    eI = ri.standard_normal(N) * np.sqrt(1 - H2)
    yI = gI + eI
    d = dict(X=X, p_true=p, pf=pf, itr=itr, iva=iva, qtl=qtl, aS=aS, gS=gS, yS=yS,
             aI=aI, gI=gI, yI=yI)
    np.savez_compressed(f, **d)
    return d


def centered(d):
    X = d['X'].astype(float)
    return X - 2 * d['pf']


# ---------------- GBLUP via REML (EMMA-style, VanRaden G method 1) ----------------
class GBLUP:
    def __init__(self, Ztr, sum2pq):
        self.Ztr = Ztr
        self.k = sum2pq
        G = Ztr @ Ztr.T / sum2pq
        self.G = G
        n = G.shape[0]
        # REML with intercept: project out 1 via eigen decomposition of S G S
        S = np.eye(n) - np.ones((n, n)) / n
        SGS = S @ G @ S
        w, U = np.linalg.eigh(SGS)
        # keep n-1 eigenvectors orthogonal to 1 (drop the one for eigenvalue ~0 along 1)
        align = np.abs(U.T @ np.ones(n)) / np.sqrt(n)
        drop = int(np.argmax(align))
        idx = [i for i in range(n) if i != drop]
        self.w = w[idx]
        self.U = U[:, idx]
        self.n = n

    def fit(self, y):
        n = self.n
        eta = self.U.T @ y
        w = self.w
        nm1 = n - 1

        def nll(logdelta):
            delta = np.exp(logdelta)
            dd = w + delta
            s2 = np.sum(eta ** 2 / dd) / nm1   # sigma_g^2 profile
            return 0.5 * (nm1 * np.log(s2) + np.sum(np.log(dd)))
        r = optimize.minimize_scalar(nll, bounds=(-10, 10), method='bounded', options={'xatol': 1e-10})
        delta = float(np.exp(r.x))
        sg2 = float(np.sum(eta ** 2 / (w + delta)) / nm1)
        se2 = delta * sg2
        self.sg2, self.se2, self.delta = sg2, se2, delta
        # BLUP: V = sg2 (G + delta I); mu_hat = GLS mean; g_hat = sg2 G V^{-1}(y - 1 mu)
        G = self.G
        V = G + delta * np.eye(n)
        L = np.linalg.cholesky(V)
        from scipy.linalg import solve_triangular
        def solve(b):
            return solve_triangular(L.T, solve_triangular(L, b, lower=True), lower=False)
        one = np.ones(n)
        Vi1 = solve(one)
        Viy = solve(y)
        mu = float(one @ Viy / (one @ Vi1))
        r_ = solve(y - mu)
        self.mu = mu
        self.ghat = G @ r_
        # SNP effects (back-solving): alpha = Z' r / sum2pq   (since G = ZZ'/k, g = Z alpha)
        self.alpha = self.Ztr.T @ r_ / self.k
        self.Vinv_r = r_
        self.L = L
        return self

    def predict(self, Zpred):
        return self.mu + Zpred @ self.alpha

    def predictive_var(self, Zpred):
        """Var(g_new | y) for new individuals, given REML variances (mu treated as known)."""
        k = self.k
        Gpt = Zpred @ self.Ztr.T / k            # (npred, n)
        gpp = np.einsum('ij,ij->i', Zpred, Zpred) / k
        from scipy.linalg import solve_triangular
        A = solve_triangular(self.L, Gpt.T, lower=True)      # L^{-1} G_tp
        # Var = sg2*(gpp - Gpt (G+delta I)^{-1} Gtp)
        return self.sg2 * (gpp - np.einsum('ij,ij->j', A, A))

    def fitted_posterior(self, y):
        """Posterior of fitted values f = mu + g (training) under flat prior on mu, fixed variances:
        f | y ~ N(H y, se2 H), H = I - se2 * P  (P: REML projection)."""
        n = self.n
        V = self.sg2 * (self.G + self.delta * np.eye(n))
        Vi = np.linalg.inv(V)
        one = np.ones(n)
        Vi1 = Vi @ one
        P = Vi - np.outer(Vi1, Vi1) / (one @ Vi1)
        H = np.eye(n) - self.se2 * P
        H = 0.5 * (H + H.T)
        return H @ y, self.se2 * H, H


# ---------------- MCMC diagnostics (same definitions as chapter 19) ----------------
def acf(x, maxlag):
    x = np.asarray(x, float); x = x - x.mean()
    n = len(x)
    nf = 1 << (2 * n - 1).bit_length()
    f = np.fft.rfft(x, nf)
    ac = np.fft.irfft(f * np.conjugate(f), nf)[:maxlag + 1].real
    if ac[0] == 0:
        return np.ones(maxlag + 1)
    return ac / ac[0]


def ess_geyer(x):
    """Geyer (1992) initial positive sequence estimator; returns (ESS, tau_int)."""
    x = np.asarray(x, float); n = len(x)
    if np.all(x == x[0]):
        return float('nan'), float('inf')
    maxlag = min(n - 1, 20000)
    r = acf(x, maxlag)
    G = []
    k = 0
    while 2 * k + 1 <= maxlag:
        g = r[2 * k] + r[2 * k + 1]
        if g <= 0:
            break
        G.append(g); k += 1
    G = np.array(G)
    if len(G) == 0:
        return float(n), 1.0
    for i in range(1, len(G)):
        if G[i] > G[i - 1]:
            G[i] = G[i - 1]
    tau = -1.0 + 2.0 * G.sum()
    tau = max(tau, 1.0)
    return n / tau, tau


def gelman_rubin(chains):
    ch = np.asarray(chains, float)
    mm, n = ch.shape
    W = ch.var(axis=1, ddof=1).mean()
    B = n * ch.mean(axis=1).var(ddof=1)
    varhat = (n - 1) / n * W + B / n
    return float(np.sqrt(varhat / W))


def split_rhat(chains):
    ch = np.asarray(chains, float)
    half = ch.shape[1] // 2
    return gelman_rubin(np.vstack([ch[:, :half], ch[:, half:2 * half]]))


def accuracy(ghat, g):
    r = float(np.corrcoef(ghat, g)[0, 1])
    b = float(np.cov(g, ghat)[0, 1] / np.var(ghat, ddof=1))
    return r, b
