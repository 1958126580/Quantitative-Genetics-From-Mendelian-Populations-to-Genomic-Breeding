# 第 22 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch22/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `bench.py` | 数值复核 | numpy, scipy | 2.0 | `outputs/bench.out` |
| `data_summary.py` | Summary statistics of the chapter-22 simulated data (for section 22.1). | numpy, scipy | 3.4 | `outputs/data_summary.out` |
| `exp2_bayesA.py` | Exp 2 (section 22.2): BayesA prior sensitivity to (nu_a, S_a), architecture S. | numpy, scipy | 3.5 | `outputs/exp2_bayesA.out` |
| `exp3a_bug.py` | Exp 3a (bug demo): BayesCpi in float64 with a typical implementation bug: | numpy, scipy | 34.5 | `outputs/exp3a_bug.out` |
| `exp4_ic.py` | Exp 4 (section 22.4): DIC / WAIC from the main chains (20000 it, burn 5000, thin 10 -> 1500 draws), | numpy, scipy | 12.1 | `outputs/exp4_ic.out` |
| `tab_exp2.py` | 数值复核 | 标准库 | 0.0 | `outputs/tab_exp2.out` |
| `tab_exp3b.py` | Diagnostics table for exp3b (4 chains x 20000, burn 5000): Rhat, split-Rhat, ESS (sum of Geyer per chain), | numpy, scipy | 1.9 | `outputs/tab_exp3b.out` |

公共函数模块（被上列脚本导入，不单独运行）：`bayes.py`、`common.py`、`exp1_main.py`、`exp3c_bc.py`、`exp3c_exact.py`、`exp3c_ld.py`、`simdata.py`。
