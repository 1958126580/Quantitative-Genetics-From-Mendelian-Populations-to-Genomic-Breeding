# -*- coding: utf-8 -*-
"""Exp 3c part 1 (section 22.3): exact mixing of single-site Gibbs for SNP-BLUP vs LD and shrinkage.
Segment: n = 1000, m = 200 SNPs, allele frequency 0.3, latent AR(1) correlation rho; genotype seed 2231.
Coefficient matrix A = Z'Z + lam I with lam = kappa * mean(z_j'z_j) (kappa = shrinkage ratio).
Gauss-Seidel iteration matrix B = -(D+L)^{-1} U; rho(B) = spectral radius;
tau_max = (1+rho(B))/(1-rho(B)); exact tau of f'alpha = 1 + 2 sum_k f'B^k Sigma f / f'Sigma f.
Also the two-marker closed form.
"""
import os, sys, json
os.environ['OPENBLAS_NUM_THREADS'] = '1'
import numpy as np
from scipy.linalg import solve_triangular
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from simdata import sim_haplotypes
from exp3c_ld import exact_tau as exact_tau_iter


def exact_tau_mat(A, F):
    """Closed form: tau(f) = 1 + 2 f' B (I-B)^{-1} Sigma f / f' Sigma f, Sigma = A^{-1} (se2 cancels).
    F: (k, m) matrix of functionals."""
    mm = A.shape[0]
    B = -solve_triangular(np.tril(A), np.triu(A, 1), lower=True)
    Sig = np.linalg.inv(A)
    SF = Sig @ F.T                                  # m x k
    X = np.linalg.solve(np.eye(mm) - B, SF)         # (I-B)^{-1} Sigma f
    num = np.einsum('ij,ji->i', F, B @ X)
    den = np.einsum('ij,ji->i', F, SF)
    return 1 + 2 * num / den

HERE = os.path.dirname(os.path.abspath(__file__))
n, m, q = 1000, 200, 100


def geno(rho):
    rng = np.random.default_rng(2231)
    H = sim_haplotypes(rng, 2 * n, 1, m, rho, np.full(m, 0.3))
    X = (H[0::2] + H[1::2]).astype(float)
    return X - X.mean(0)


def main():
    out = dict(two_marker=[], segment=[])
    # two-marker closed form: standardized z, z'z = n, z1'z2 = n r, lam = kappa n
    for r in [0.5, 0.9, 0.99]:
        for kappa in [10.0, 1.0, 0.1, 0.01]:
            c = -r / (1 + kappa)               # posterior correlation
            tau = (1 + c * c) / (1 - c * c)
            out['two_marker'].append(dict(r=r, kappa=kappa, corr=c, lag1=c * c, tau=tau))
            print('two-marker r=%.2f kappa=%.2f corr=%.4f lag1=%.4f tau=%.2f' % (r, kappa, c, c * c, tau))
    for rho in [0.0, 0.8, 0.9, 0.95, 0.98, 0.99, 0.995, 0.999]:
        Z = geno(rho)
        R = np.corrcoef(Z.T)
        adj = float(np.mean(np.diag(R, 1) ** 2))
        zz = float(np.mean(np.sum(Z * Z, 0)))
        rec = dict(rho=rho, adj_r2=adj, max_r2_q=float(max(R[q, q - 1] ** 2, R[q, q + 1] ** 2)))
        for kappa in [10.0, 1.0, 0.1, 0.01]:
            lam = kappa * zz
            A = Z.T @ Z + lam * np.eye(m)
            B = -solve_triangular(np.tril(A), np.triu(A, 1), lower=True)
            ev = np.linalg.eigvals(B)
            rb = float(np.max(np.abs(ev)))
            fq = np.zeros(m); fq[q] = 1.0
            tt = exact_tau_mat(A, np.vstack([fq, Z[:10]]))
            tq = float(tt[0]); tg = tt[1:]
            # slowest-mode functional: Sigma^{-1}-weighted leading left eigvec is complex in general;
            # report tau_max from the spectral radius.
            rec['k%g' % kappa] = dict(rhoB=rb, tau_max=(1 + rb) / (1 - rb), tau_alpha_q=tq,
                                     tau_gebv_med=float(np.median(tg)), tau_gebv_max=float(np.max(tg)))
        print(json.dumps(rec), flush=True)
        out['segment'].append(rec)
    json.dump(out, open(os.path.join(HERE, 'exp3c_exact.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
