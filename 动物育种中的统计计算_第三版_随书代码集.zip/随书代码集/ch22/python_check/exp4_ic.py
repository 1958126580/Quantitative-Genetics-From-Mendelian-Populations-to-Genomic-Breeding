# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 22 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 exp4_ic.py    依赖：numpy, scipy
"""Exp 4 (section 22.4): DIC / WAIC from the main chains (20000 it, burn 5000, thin 10 -> 1500 draws),
exact LOO for GBLUP (fixed REML variances), external validation log score, and comparison with 5-fold CV.
DIC = Dbar + pD, pD = Dbar - D(theta_bar)   (Spiegelhalter et al. 2002);
WAIC = -2 (lppd - p_WAIC), p_WAIC = sum_i Var_s log p(y_i | theta_s)   (BDA3, ch. 7).
"""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import os, sys, json
os.environ['OPENBLAS_NUM_THREADS'] = '1'
import numpy as np
from scipy.special import logsumexp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import make_data, centered, GBLUP

HERE = os.path.dirname(os.path.abspath(__file__))


def ic_from_draws(y, res, se2, res_bar, se2_bar):
    ll = -0.5 * np.log(2 * np.pi * se2)[:, None] - res ** 2 / (2 * se2[:, None])   # S x n
    S = ll.shape[0]
    lppd_i = logsumexp(ll, axis=0) - np.log(S)
    pw_i = ll.var(axis=0, ddof=1)
    Dbar = float(np.mean(-2 * ll.sum(1)))
    Dhat = float(-2 * np.sum(-0.5 * np.log(2 * np.pi * se2_bar) - res_bar ** 2 / (2 * se2_bar)))
    pD = Dbar - Dhat
    pV = float(np.var(-2 * ll.sum(1), ddof=1) / 2)
    return dict(lppd=float(lppd_i.sum()), p_waic=float(pw_i.sum()), waic=float(-2 * (lppd_i.sum() - pw_i.sum())),
                Dbar=Dbar, Dhat=Dhat, pD=pD, pV=pV, dic=Dbar + pD, pw_max=float(pw_i.max()),
                pw_frac04=float(np.mean(pw_i > 0.4)), elpd_waic_i=(lppd_i - pw_i).tolist())


def lpd_ext(y, pred, se2):
    ll = -0.5 * np.log(2 * np.pi * se2)[:, None] - (y[None, :] - pred) ** 2 / (2 * se2[:, None])
    return logsumexp(ll, axis=0) - np.log(len(se2))


def main():
    d = make_data(); Z = centered(d)
    itr, iva = d['itr'], d['iva']
    pf = d['pf']; sum2pq = float((2 * pf * (1 - pf)).sum())
    out = {}
    for arch in 'SI':
        y = d['y' + arch]; ytr = y[itr]; yva = y[iva]; g = d['g' + arch]
        n = len(itr)
        A = {}
        # ---- GBLUP: exact posterior of fitted values with REML variances ----
        gb = GBLUP(Z[itr], sum2pq).fit(ytr)
        fhat, Cf, H = gb.fitted_posterior(ytr)
        w, U = np.linalg.eigh(Cf)
        w = np.clip(w, 0, None)
        rng = np.random.default_rng(2241)
        S = 1500
        F = fhat[None, :] + (rng.standard_normal((S, n)) * np.sqrt(w)[None, :]) @ U.T
        res = ytr[None, :] - F
        se2 = np.full(S, gb.se2)
        r = ic_from_draws(ytr, res, se2, ytr - fhat, gb.se2)
        r['trH'] = float(np.trace(H))
        # exact LOO with fixed variances: y_i | y_-i ~ N(y_i - (Py)_i / P_ii, 1 / P_ii)
        n_ = n
        V = gb.sg2 * gb.G + gb.se2 * np.eye(n_)
        Vi = np.linalg.inv(V)
        one = np.ones(n_)
        Vi1 = Vi @ one
        P = Vi - np.outer(Vi1, Vi1) / (one @ Vi1)
        Py = P @ ytr
        pdg = np.diag(P)
        loo_mean = ytr - Py / pdg
        loo_var = 1.0 / pdg
        loo_lpd = -0.5 * np.log(2 * np.pi * loo_var) - (ytr - loo_mean) ** 2 / (2 * loo_var)
        r['loo_elpd'] = float(loo_lpd.sum())
        r['loo_r_tbv'] = float(np.corrcoef(loo_mean, g[itr])[0, 1])
        # brute-force check of the LOO formula for 3 individuals
        chk = []
        for i in [0, 1, 2]:
            keep = np.arange(n_) != i
            Vk = V[np.ix_(keep, keep)]; vik = V[i, keep]
            Vki = np.linalg.inv(Vk)
            o1 = np.ones(n_ - 1)
            muk = float(o1 @ Vki @ ytr[keep] / (o1 @ Vki @ o1))
            mean_i = muk + vik @ Vki @ (ytr[keep] - muk)
            # variance incl. uncertainty of mu (flat prior): v_ii - v' Vk^{-1} v + (1 - v'Vk^{-1}1)^2/(1'Vk^{-1}1)
            c = 1 - vik @ Vki @ o1
            var_i = V[i, i] - vik @ Vki @ vik + c * c / (o1 @ Vki @ o1)
            chk.append([float(mean_i - loo_mean[i]), float(var_i - loo_var[i])])
        r['loo_check'] = chk
        # external validation (mu treated as known)
        mu_p = gb.predict(Z[iva]); vp = gb.predictive_var(Z[iva]) + gb.se2
        ext = -0.5 * np.log(2 * np.pi * vp) - (yva - mu_p) ** 2 / (2 * vp)
        r['ext_elpd_mean'] = float(ext.mean())
        r['ext_r'] = float(np.corrcoef(mu_p, g[iva])[0, 1])
        r.pop('elpd_waic_i')
        A['GBLUP'] = r
        print(arch, 'GBLUP', json.dumps({k: v for k, v in r.items()}), flush=True)
        # ---- Bayesian models from the main chains ----
        for model in ['A', 'B', 'C', 'R', 'L']:
            f = os.path.join(HERE, f'main_{arch}_{model}.npz')
            if not os.path.exists(f):
                continue
            z = np.load(f)
            res = z['res_draws']; se2 = z['se2_draws']; mu = z['mu_draws']
            alpha = z['alpha']
            mu_bar = float(np.mean(z['tr_mu'][5000:]))
            se2_bar = float(np.mean(z['tr_se2'][5000:]))
            res_bar = ytr - mu_bar - Z[itr] @ alpha
            r = ic_from_draws(ytr, res, se2, res_bar, se2_bar)
            ext = lpd_ext(yva, z['pred_draws'], se2)
            r['ext_elpd_mean'] = float(ext.mean())
            r['ext_r'] = float(np.corrcoef(z['pred_draws'].mean(0), g[iva])[0, 1])
            r.pop('elpd_waic_i')
            A[model] = r
            print(arch, model, json.dumps(r), flush=True)
        out[arch] = A
    json.dump(out, open(os.path.join(HERE, 'exp4_ic.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
