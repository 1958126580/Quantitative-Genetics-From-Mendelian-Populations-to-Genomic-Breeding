# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 22 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 data_summary.py    依赖：numpy
"""Summary statistics of the chapter-22 simulated data (for section 22.1)."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from common import make_data, centered, NCHR, MCHR
from simdata import adjacent_r2, r2_by_distance
d = make_data(); Z = centered(d); X = d['X']
r2 = adjacent_r2(X, NCHR, MCHR)
dist = r2_by_distance(X, NCHR, MCHR, [1, 2, 5, 10, 20, 50])
pf = d['pf']; maf = np.minimum(pf, 1 - pf)
out = dict(adj_mean=float(r2.mean()), adj_median=float(np.median(r2)), adj_gt08=float(np.mean(r2 > 0.8)),
           adj_max=float(r2.max()), dist={str(k): v for k, v in dist.items()},
           maf_min=float(maf.min()), maf_mean=float(maf.mean()), sum2pq=float((2 * pf * (1 - pf)).sum()))
for a in 'SI':
    g, y = d['g' + a], d['y' + a]
    out[a] = dict(var_g=float(g.var()), var_y=float(y.var()), h2=float(g.var() / y.var()),
                  var_y_tr=float(y[d['itr']].var()), h2_tr=float(g[d['itr']].var() / y[d['itr']].var()))
qtl = d['qtl']; aS = d['aS']; g = d['gS']
sh = [float(np.var(Z[:, q] * aS[q]) / np.var(g)) for q in qtl]
out['qtl'] = [dict(idx=int(q), chr=int(q // MCHR) + 1, pos=int(q % MCHR) + 1, a=float(aS[q]), share=s,
                   maf=float(maf[q])) for q, s in zip(qtl, sh)]
out['qtl_share_sorted'] = sorted(sh, reverse=True)
out['qtl_share_sum'] = float(sum(sh))
# max r2 of each QTL with any other SNP within +-10
R2nb = []
for q in qtl:
    lo, hi = max(q - 10, (q // MCHR) * MCHR), min(q + 11, (q // MCHR + 1) * MCHR)
    rr = [np.corrcoef(Z[:, q], Z[:, k])[0, 1] ** 2 for k in range(lo, hi) if k != q]
    R2nb.append(float(max(rr)))
out['qtl_max_r2_nb'] = R2nb
aI = d['aI']; gI = d['gI']
shI = (Z * aI).var(0) / gI.var()
out['I_top_share'] = sorted(shI.tolist(), reverse=True)[:5]
out['I_share_sum'] = float(shI.sum())
print(json.dumps(out, indent=1))
json.dump(out, open('data_summary.json', 'w'), indent=1)
