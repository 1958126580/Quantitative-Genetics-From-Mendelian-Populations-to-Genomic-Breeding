# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 22 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 bench.py    依赖：numpy, scipy
import numpy as np, time
from math import sqrt
from scipy.linalg.blas import daxpy, ddot
n, m = 1500, 2000
rng = np.random.default_rng(1)
Zt = rng.standard_normal((m, n))
e = rng.standard_normal(n)
rows = [Zt[j] for j in range(m)]
zz = [float(r @ r) for r in rows]
s2 = [0.001] * m
a = [0.0] * m
dot = np.dot

def sweep1(a, e, se2, rn):
    for j in range(m):
        zj = rows[j]; aj = a[j]
        rhs = dot(zj, e) + zz[j] * aj
        C = zz[j] + se2 / s2[j]
        new = rhs / C + sqrt(se2 / C) * rn[j]
        daxpy(zj, e, a=aj - new)
        a[j] = new

def sweep2(a, e, se2, rn):
    for j in range(m):
        zj = rows[j]; aj = a[j]
        rhs = float(ddot(zj, e)) + zz[j] * aj
        C = zz[j] + se2 / s2[j]
        new = rhs / C + sqrt(se2 / C) * rn[j]
        daxpy(zj, e, a=aj - new)
        a[j] = new

def sweep3(a, e, se2, rn):
    for j in range(m):
        zj = rows[j]; aj = a[j]
        rhs = zj.dot(e).item() + zz[j] * aj
        C = zz[j] + se2 / s2[j]
        new = rhs / C + sqrt(se2 / C) * rn[j]
        e -= zj * (new - aj)
        a[j] = new

for f in [sweep1, sweep2, sweep3]:
    rn = rng.standard_normal(m).tolist()
    t0 = time.perf_counter()
    for it in range(20):
        f(a, e, 1.0, rn)
    print(f.__name__, (time.perf_counter() - t0) / 20 * 1000, 'ms/iter')
