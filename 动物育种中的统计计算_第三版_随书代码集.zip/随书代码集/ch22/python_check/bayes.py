# -*- coding: utf-8 -*-
"""Single-site Gibbs samplers for the Bayesian alphabet (chapter 22), pure numpy + BLAS level-1.

Model: y = 1 mu + sum_j z_j alpha_j + e,  e ~ N(0, I se2).
  mu: flat prior (eq 22.9);  se2 ~ chi^-2(nu_e, S_e) (eq 22.8).
Residual e is maintained incrementally (eqs 22.48-22.49).
Models: 'A' (BayesA), 'B' (BayesB, fixed pi), 'C' (BayesC / BayesCpi), 'R' (BayesR, standardized
genotypes), 'L' (Bayesian LASSO, Park-Casella parameterization), 'RR' (pi = 0, common variance).
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import time
import numpy as np
from math import sqrt, log, exp
from scipy.linalg.blas import daxpy, ddot, saxpy, sdot


class Data:
    def __init__(self, Zt, y, dtype=np.float64):
        self.Zt = np.ascontiguousarray(Zt, dtype=dtype)
        self.m, self.n = self.Zt.shape
        self.rows = [self.Zt[j] for j in range(self.m)]
        if dtype == np.float64:
            self.zz = [float(ddot(r, r)) for r in self.rows]
        else:
            self.zz = [float(np.dot(r.astype(float), r.astype(float))) for r in self.rows]
        self.y = np.asarray(y, dtype=dtype).copy()
        self.dtype = dtype


def run(model, D, hp, n_iter, burn, thin, seed, init=None, Zpred=None, store_resid=False,
        recompute=0, reset=True, Zt64=None, y64=None, est_pi=True, verbose=False):
    """Returns dict with posterior means, traces and (optionally) thinned draws."""
    rng = np.random.default_rng(seed)
    m, n = D.m, D.n
    rows, zz, y = D.rows, D.zz, D.y
    f32 = D.dtype == np.float32
    dot_ = sdot if f32 else ddot
    axpy_ = saxpy if f32 else daxpy
    init = init or {}
    nu_e, S_e = hp['nu_e'], hp['S_e']
    se2 = float(init.get('se2', hp.get('se2_0', float(np.var(y)) * 0.5)))
    mu = float(np.mean(y))
    a = [0.0] * m
    e = (y - D.dtype(mu)).astype(D.dtype)
    # model-specific state
    if model in ('A', 'B'):
        nu_a, S_a = hp['nu_a'], hp['S_a']
        s2 = [nu_a * S_a / (nu_a - 2)] * m
        pi = hp.get('pi', 0.0)
        S_hyper = hp.get('S_hyper')   # (a, b) Gamma prior on S_a (eq 22.17) or None
    if model in ('C', 'RR'):
        nu_a, S_a = hp['nu_a'], hp['S_a']
        sa2 = float(init.get('sa2', nu_a * S_a / (nu_a - 2)))
        pi = float(init.get('pi', hp.get('pi', 0.5))) if model == 'C' else 0.0
        fixed_sa2 = hp.get('fixed_sa2', False)
    if model == 'R':
        gam = hp['gamma']
        nu_A, S_A = hp['nu_A'], hp['S_A']
        sA2 = float(init.get('sA2', nu_A * S_A / (nu_A - 2)))
        pis = np.array(init.get('pis', [0.5, 0.25, 0.15, 0.10]), float)
        cls = [0] * m
    if model == 'L':
        r_l, d_l = hp['r'], hp['delta']
        lam2 = float(init.get('lam2', hp.get('lam2_0', 100.0)))
        itau2 = [1.0 / (2.0 / lam2)] * m   # 1/E(tau2)
    # storage
    T = {k: np.empty(n_iter) for k in ('se2', 'mu', 'vg', 'm1')}
    if model == 'C':
        T['pi'] = np.empty(n_iter); T['sa2'] = np.empty(n_iter)
    if model == 'RR':
        T['sa2'] = np.empty(n_iter)
    if model == 'R':
        T['pi'] = np.empty((n_iter, 4)); T['sA2'] = np.empty(n_iter)
    if model == 'L':
        T['lam2'] = np.empty(n_iter)
    if model in ('A', 'B') and S_hyper is not None:
        T['S_a'] = np.empty(n_iter)
    asum = np.zeros(m); a2sum = np.zeros(m); incl = np.zeros(m); nkeep = 0
    s2sum = np.zeros(m) if model in ('A', 'B') else None
    draws_se2, draws_pred, draws_res, draws_mu = [], [], [], []
    drift = []
    t0 = time.perf_counter(); c0 = time.process_time()
    for it in range(n_iter):
        # ---- intercept (eq 22.9) ----
        e += D.dtype(mu)
        mu = float(np.mean(e, dtype=np.float64)) + sqrt(se2 / n) * rng.standard_normal()
        e -= D.dtype(mu)
        rn = rng.standard_normal(m).tolist()
        ru = rng.random(m).tolist()
        # ---- marker sweep ----
        if model == 'A':
            for j in range(m):
                zj = rows[j]; aj = a[j]; zzj = zz[j]
                rhs = float(dot_(zj, e)) + zzj * aj
                C = zzj + se2 / s2[j]
                new = rhs / C + sqrt(se2 / C) * rn[j]
                axpy_(zj, e, a=aj - new)
                a[j] = new
        elif model == 'B':
            lo = log((1 - pi) / pi)
            for j in range(m):
                zj = rows[j]; aj = a[j]; zzj = zz[j]
                rhs = float(dot_(zj, e)) + zzj * aj
                v = s2[j]
                C = zzj + se2 / v
                lg = lo - 0.5 * log(v * C / se2) + rhs * rhs / (2.0 * se2 * C)
                if lg >= 0:
                    P = 1.0 / (1.0 + exp(-lg))
                else:
                    t_ = exp(lg); P = t_ / (1.0 + t_)
                if ru[j] < P:
                    new = rhs / C + sqrt(se2 / C) * rn[j]
                else:
                    new = 0.0
                if new != aj:
                    axpy_(zj, e, a=aj - new)
                    a[j] = new
        elif model == 'C':
            lo = log((1 - pi) / pi)
            lam = se2 / sa2
            hl = 0.5 * log(sa2 / se2)
            for j in range(m):
                zj = rows[j]; aj = a[j]; zzj = zz[j]
                rhs = float(dot_(zj, e)) + zzj * aj
                C = zzj + lam
                lg = lo - hl - 0.5 * log(C) + rhs * rhs / (2.0 * se2 * C)
                if lg >= 0:
                    P = 1.0 / (1.0 + exp(-lg))
                else:
                    t_ = exp(lg); P = t_ / (1.0 + t_)
                if ru[j] < P:
                    new = rhs / C + sqrt(se2 / C) * rn[j]
                else:
                    new = 0.0
                if new != aj:
                    axpy_(zj, e, a=aj - new)
                    a[j] = new
        elif model == 'RR':
            lam = se2 / sa2
            for j in range(m):
                zj = rows[j]; aj = a[j]; zzj = zz[j]
                rhs = float(dot_(zj, e)) + zzj * aj
                C = zzj + lam
                new = rhs / C + sqrt(se2 / C) * rn[j]
                axpy_(zj, e, a=aj - new)
                a[j] = new
        elif model == 'R':
            lp0, lp1, lp2, lp3 = [log(x) for x in pis]
            v1, v2, v3 = gam[1] * sA2, gam[2] * sA2, gam[3] * sA2
            l1, l2, l3 = se2 / v1, se2 / v2, se2 / v3
            h1, h2, h3 = 0.5 * log(v1 / se2), 0.5 * log(v2 / se2), 0.5 * log(v3 / se2)
            tse = 2.0 * se2
            for j in range(m):
                zj = rows[j]; aj = a[j]; zzj = zz[j]
                rhs = float(dot_(zj, e)) + zzj * aj
                r2 = rhs * rhs
                C1 = zzj + l1; C2 = zzj + l2; C3 = zzj + l3
                w1 = lp1 - h1 - 0.5 * log(C1) + r2 / (tse * C1)
                w2 = lp2 - h2 - 0.5 * log(C2) + r2 / (tse * C2)
                w3 = lp3 - h3 - 0.5 * log(C3) + r2 / (tse * C3)
                mx = lp0
                if w1 > mx: mx = w1
                if w2 > mx: mx = w2
                if w3 > mx: mx = w3
                p0 = exp(lp0 - mx); p1 = exp(w1 - mx); p2 = exp(w2 - mx); p3 = exp(w3 - mx)
                u = ru[j] * (p0 + p1 + p2 + p3)
                if u < p0:
                    k = 0; new = 0.0
                elif u < p0 + p1:
                    k = 1; new = rhs / C1 + sqrt(se2 / C1) * rn[j]
                elif u < p0 + p1 + p2:
                    k = 2; new = rhs / C2 + sqrt(se2 / C2) * rn[j]
                else:
                    k = 3; new = rhs / C3 + sqrt(se2 / C3) * rn[j]
                cls[j] = k
                if new != aj:
                    axpy_(zj, e, a=aj - new)
                    a[j] = new
        elif model == 'L':
            for j in range(m):
                zj = rows[j]; aj = a[j]; zzj = zz[j]
                rhs = float(dot_(zj, e)) + zzj * aj
                C = zzj + itau2[j]
                new = rhs / C + sqrt(se2 / C) * rn[j]
                axpy_(zj, e, a=aj - new)
                a[j] = new
        aa = np.array(a)
        # ---- hyperparameters ----
        extra_df, extra_ss = 0.0, 0.0
        if model == 'A':
            if S_hyper is not None:
                ga, gb = S_hyper
                S_a = rng.gamma(ga + m * nu_a / 2.0, 1.0 / (gb + nu_a / 2.0 * np.sum(1.0 / np.array(s2))))
                T['S_a'][it] = S_a
            s2 = ((aa * aa + nu_a * S_a) / rng.chisquare(nu_a + 1, size=m)).tolist()
        elif model == 'B':
            nz = aa != 0
            post = (aa * aa + nu_a * S_a) / rng.chisquare(nu_a + 1, size=m)
            prior = nu_a * S_a / rng.chisquare(nu_a, size=m)
            s2 = np.where(nz, post, prior).tolist()
        elif model == 'C':
            m1 = int(np.count_nonzero(aa))
            if not fixed_sa2:
                sa2 = (float(aa @ aa) + nu_a * S_a) / rng.chisquare(nu_a + m1)
            if est_pi:
                pi = rng.beta(m - m1 + 1.0, m1 + 1.0)
            T['pi'][it] = pi; T['sa2'][it] = sa2
        elif model == 'RR':
            if not fixed_sa2:
                sa2 = (float(aa @ aa) + nu_a * S_a) / rng.chisquare(nu_a + m)
            T['sa2'][it] = sa2
        elif model == 'R':
            ca = np.array(cls)
            cnt = np.bincount(ca, minlength=4)
            pis = rng.dirichlet(1.0 + cnt)
            nzm = ca > 0
            gv = np.array(gam)[ca[nzm]]
            mp = int(nzm.sum())
            sA2 = (float(np.sum(aa[nzm] ** 2 / gv)) + nu_A * S_A) / rng.chisquare(nu_A + mp)
            T['pi'][it] = pis; T['sA2'][it] = sA2
        elif model == 'L':
            with np.errstate(divide='ignore'):
                mean_ig = np.sqrt(lam2 * se2 / np.maximum(aa * aa, 1e-300))
            itau2_arr = rng.wald(mean_ig, lam2)
            itau2 = itau2_arr.tolist()
            lam2 = rng.gamma(m + r_l, 1.0 / (0.5 * float(np.sum(1.0 / itau2_arr)) + d_l))
            extra_df = m
            extra_ss = float(np.sum(aa * aa * itau2_arr))
            T['lam2'][it] = lam2
        # ---- residual variance (eq 22.8) ----
        ee = float(np.dot(e.astype(np.float64), e.astype(np.float64))) if f32 else float(ddot(e, e))
        if not hp.get('fixed_se2', False):
            se2 = (ee + extra_ss + nu_e * S_e) / rng.chisquare(n + nu_e + extra_df)
        # ---- optional full recomputation of the residual (eq 22.50) ----
        if recompute and (it + 1) % recompute == 0:
            if f32:
                e_ref = y64 - mu - Zt64.T @ aa      # exact float64 reference
                drift.append((it + 1, float(np.linalg.norm(e_ref - e.astype(np.float64)) / np.linalg.norm(e_ref))))
                if reset:
                    e[:] = e_ref.astype(np.float32)
            else:
                e_ref = y - mu - D.Zt.T @ aa
                drift.append((it + 1, float(np.linalg.norm(e_ref - e) / np.linalg.norm(e_ref))))
                if reset:
                    e[:] = e_ref
        # ---- traces ----
        g = (y - mu - e) if not f32 else (y.astype(float) - mu - e.astype(float))
        T['se2'][it] = se2; T['mu'][it] = mu; T['vg'][it] = float(np.var(g))
        T['m1'][it] = float(np.count_nonzero(aa))
        if it >= burn:
            asum += aa; a2sum += aa * aa; incl += (aa != 0); nkeep += 1
            if s2sum is not None:
                s2sum += np.asarray(s2)
            if (it - burn) % thin == 0:
                draws_se2.append(se2); draws_mu.append(mu)
                if Zpred is not None:
                    draws_pred.append(mu + Zpred @ aa)
                if store_resid:
                    draws_res.append(e.astype(np.float64).copy())
        if verbose and (it + 1) % verbose == 0:
            print(model, it + 1, 'se2=%.4f vg=%.4f m1=%d' % (se2, T['vg'][it], T['m1'][it]),
                  '%.1fs' % (time.perf_counter() - t0), flush=True)
    elapsed = time.perf_counter() - t0
    cpu = time.process_time() - c0
    out = dict(model=model, alpha=asum / nkeep, alpha_sd=np.sqrt(np.maximum(a2sum / nkeep - (asum / nkeep) ** 2, 0)),
               incl=incl / nkeep, traces=T, time=elapsed, cpu=cpu, n_iter=n_iter, burn=burn, thin=thin,
               se2_draws=np.array(draws_se2), mu_draws=np.array(draws_mu), drift=drift)
    if s2sum is not None:
        out['s2_mean'] = s2sum / nkeep
    if Zpred is not None:
        out['pred_draws'] = np.array(draws_pred)
    if store_resid:
        out['res_draws'] = np.array(draws_res)
    out['mu_mean'] = float(np.mean(T['mu'][burn:]))
    out['se2_mean'] = float(np.mean(T['se2'][burn:]))
    return out
