# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 22 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 tab_exp2.py    依赖：仅标准库
import os; HERE = os.path.dirname(os.path.abspath(__file__))
# -*- coding: utf-8 -*-
import json, os
HERE = os.path.dirname(os.path.abspath(__file__))
G = json.load(open(os.path.join(HERE, 'exp2_grid.json')))
print('| nu | S/S* | r | b1 | big a/a | far|a|e3 | E(Vg) | null s2 ratio | theory (nu-2)/(nu-1) | big s2 ratio | data share big | win |')
for r in G:
    nu = r['nu']
    print('| %g | %g | %.4f | %.3f | %.3f | %.3f | %.3f | %.3f | %.3f | %.2f | %.3f | %.3f |' % (
        nu, r['mult'], r['r'], r['b'], r['big_ratio'], r['far_mean_abs'] * 1e3, r['vg'], r['s2_far_ratio'],
        (nu - 2) / (nu - 1), r['s2_big_ratio'], r['data_share_big'], r['win_capture']))
    print('     prior_mean %.4e S_a %.4e se2 %.4f time %.0f' % (r['prior_mean'], r['S_a'], r['se2'], r['time']))
f = os.path.join(HERE, 'exp2_remedy.json')
if os.path.exists(f):
    for r in json.load(open(f)):
        nu = r['nu']
        print(r['tag'], '| %g | %g | %.4f | %.3f | %.3f | %.3f | %.3f | %.3f | %.3f | %.2f | %.3f | %.3f |' % (
            nu, r['mult'], r['r'], r['b'], r['big_ratio'], r['far_mean_abs'] * 1e3, r['vg'], r['s2_far_ratio'],
            (nu - 2) / (nu - 1), r['s2_big_ratio'], r['data_share_big'], r['win_capture']),
            'S_post %.4e prior_mean_post %.4e' % (r['S_post'], r['prior_mean']))
