# -*- coding: utf-8 -*-
"""Chapter 22 simulated data: genotypes with LD via latent Gaussian AR(1) haplotypes.

Each haplotype on a chromosome: u_1 ~ N(0,1), u_k = rho*u_{k-1} + sqrt(1-rho^2)*eps_k.
Allele (coded 1) present iff u_k < Phi^{-1}(p_k). Genotype = sum of two independent haplotypes.
"""
import numpy as np
from scipy.stats import norm


def sim_haplotypes(rng, nhap, nchr, mchr, rho, p):
    m = nchr * mchr
    H = np.empty((nhap, m), dtype=np.int8)
    thr = norm.ppf(p)
    s = np.sqrt(1.0 - rho * rho)
    for c in range(nchr):
        u = rng.standard_normal(nhap)
        for k in range(mchr):
            j = c * mchr + k
            if k > 0:
                u = rho * u + s * rng.standard_normal(nhap)
            H[:, j] = (u < thr[j]).astype(np.int8)
    return H


def sim_genotypes(seed, n, nchr, mchr, rho, maf_lo=0.05, maf_hi=0.5):
    rng = np.random.default_rng(seed)
    m = nchr * mchr
    p = rng.uniform(maf_lo, maf_hi, size=m)
    H = sim_haplotypes(rng, 2 * n, nchr, mchr, rho, p)
    X = (H[0::2] + H[1::2]).astype(np.int8)
    return X, p


def adjacent_r2(X, nchr, mchr):
    Xf = X.astype(float)
    Xc = Xf - Xf.mean(0)
    sd = Xc.std(0)
    r2 = []
    for c in range(nchr):
        for k in range(mchr - 1):
            j = c * mchr + k
            if sd[j] > 0 and sd[j + 1] > 0:
                r = np.mean(Xc[:, j] * Xc[:, j + 1]) / (sd[j] * sd[j + 1])
                r2.append(r * r)
    return np.array(r2)


def r2_by_distance(X, nchr, mchr, dists):
    Xf = X.astype(float)
    Xc = Xf - Xf.mean(0)
    sd = Xc.std(0)
    out = {}
    for d in dists:
        vals = []
        for c in range(nchr):
            for k in range(mchr - d):
                j = c * mchr + k
                if sd[j] > 0 and sd[j + d] > 0:
                    r = np.mean(Xc[:, j] * Xc[:, j + d]) / (sd[j] * sd[j + d])
                    vals.append(r * r)
        out[d] = float(np.mean(vals))
    return out


if __name__ == '__main__':
    for rho in [0.0, 0.5, 0.8, 0.9, 0.95, 0.98, 0.99]:
        X, p = sim_genotypes(1, 1000, 2, 200, rho)
        r2 = adjacent_r2(X, 2, 200)
        print(rho, 'adj r2 mean %.3f median %.3f' % (r2.mean(), np.median(r2)), r2_by_distance(X, 2, 200, [1, 5, 10, 20, 50]))
