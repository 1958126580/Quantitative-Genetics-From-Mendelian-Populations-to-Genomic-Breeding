# 第二十章　基因组选择的理论基础 —— 配套代码

**所属**：第五篇　基因组选择与基因组预测　　**对应正文**：第二十章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch20.ipynb` | IJulia 笔记本：10 个代码单元，约 293 行 Julia 代码，穿插与正文对应的说明 |
| `ch20.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 11 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　Beavis 效应：为什么 MAS 会失败
- 2　$\sigma_A^2=2\sum p_jq_j\sigma_\alpha^2$ 的数值验证
- 3　SNP-BLUP 与 GBLUP 的等价性（正文定理 20.1）
- 4　有效染色体片段数 $M_e$
- 5　三个准确性公式
- 6　用模拟验证 Daetwyler 公式
- 7　参考群体规模的设计实验
- 8　四路径年遗传进展的比较（正文 §20.4.1）
- 9　本章小结与自检

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 20
```

或在 Jupyter 中打开 `ch20/ch20.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
