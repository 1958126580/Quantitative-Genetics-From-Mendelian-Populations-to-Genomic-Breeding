# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_lande.py    依赖：numpy, scipy
"""§20.1.5 Lande-Thompson (1990) index: weights, accuracy, relative efficiency table."""
import numpy as np


def lt(p, h2):
    by = h2 * (1 - p) / (1 - p * h2)
    bm = (1 - h2) / (1 - p * h2)
    r2 = (h2 + p - 2 * p * h2) / (1 - p * h2)
    re = np.sqrt(p / h2 + (1 - p) ** 2 / (1 - h2 * p))
    return by, bm, r2, re


# numeric check of the closed form against P^{-1}G
for p, h2 in [(0.2, 0.1), (0.3, 0.5)]:
    P = np.array([[1, p * h2], [p * h2, p * h2]]); G = np.array([h2, p * h2])
    b = np.linalg.solve(P, G)
    by, bm, r2, re = lt(p, h2)
    print('check p=%.2f h2=%.2f: solve b=%s closed=(%.6f,%.6f)  r2=%.6f vs %.6f  RE=%.6f vs %.6f' % (
        p, h2, b, by, bm, b @ G / h2, r2, np.sqrt(b @ G / h2) / np.sqrt(h2), re))

ps = [0.05, 0.10, 0.20, 0.30, 0.50]
hs = [0.05, 0.10, 0.20, 0.30, 0.50, 0.80]
print('\nRE table (rows p, cols h2):', hs)
for p in ps:
    print('p=%.2f ' % p + ' '.join('%.3f' % lt(p, h)[3] for h in hs))
print('\n1/h (p=1):', ' '.join('%.3f' % (1 / np.sqrt(h)) for h in hs))
# weights for a worked example
for p, h2 in [(0.2, 0.1), (0.2, 0.5), (0.1, 0.1)]:
    by, bm, r2, re = lt(p, h2)
    print('example p=%.2f h2=%.2f: by=%.4f bm=%.4f  r_I=%.4f  h=%.4f  RE=%.4f  bm/by=%.3f' % (
        p, h2, by, bm, np.sqrt(r2), np.sqrt(h2), re, bm / by))
# how much of the RE comes from p: limit h2->0 : RE^2 ~ p/h2
for h2 in [0.05, 0.1]:
    for p in [0.1, 0.2]:
        print('h2=%.2f p=%.2f  RE=%.4f  sqrt(1+p/h2)=%.4f  sqrt(p/h2)=%.4f' % (h2, p, lt(p, h2)[3], np.sqrt(1 + p / h2), np.sqrt(p / h2)))
# p needed for RE=1.10 / 1.5 at various h2
from scipy.optimize import brentq
for target in [1.1, 1.5]:
    out = []
    for h in hs:
        f = lambda p: lt(p, h)[3] - target
        try:
            out.append('%.4f' % brentq(f, 1e-9, 0.999999))
        except ValueError:
            out.append('NA')
    print('p needed for RE=%.2f at h2 %s: %s' % (target, hs, out))
# marker-only selection accuracy sqrt(p) vs phenotype h : when is markers-alone better
for h2 in hs:
    print('h2=%.2f  p for sqrt(p)=h -> p=h2=%.2f' % (h2, h2))
