# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4_decomp.py    依赖：numpy, scipy
"""§20.4.5 decomposition of the annual-gain ratio into i, r, L contributions (Shapley on log scale).
Inputs reproduce Tables 10.4-10.6 (ch10, script ch10b/s13_paths.py)."""
import numpy as np, itertools
from scipy.stats import norm


def ii(p):
    x = norm.isf(p); return norm.pdf(x) / p


def r_prog(n, h2): return np.sqrt(n / (n + (4 - h2) / h2))


def r_own_sire(n, h2, t, rs):
    P = np.array([[(1 + (n - 1) * t) / n, 0.5 * rs * rs * h2], [0.5 * rs * rs * h2, rs * rs * h2]])
    g = np.array([h2, 0.5 * rs * rs * h2])
    b = np.linalg.solve(P, g); return np.sqrt(b @ g / h2)


def r_idx3(h2, nfs, nhs, c2):
    tf = 0.5 * h2 + c2; th = 0.25 * h2
    P = np.array([[1.0, tf, th], [tf, (1 + (nfs - 1) * tf) / nfs, th], [th, th, (1 + (nhs - 1) * th) / nhs]])
    g = np.array([h2, 0.5 * h2, 0.25 * h2]); b = np.linalg.solve(P, g)
    return np.sqrt(b @ g / h2)


def dG(i, r, L):
    return np.sum(np.array(i) * np.array(r)) / np.sum(L)


def shapley(T, G):
    """T, G: dicts with i, r, L arrays. Exact Shapley decomposition of ln(dG_G/dG_T) over factors i, r, L."""
    fac = ['i', 'r', 'L']
    phi = {f: 0.0 for f in fac}
    for perm in itertools.permutations(fac):
        cur = dict(T)
        v0 = np.log(dG(cur['i'], cur['r'], cur['L']))
        for f in perm:
            cur = dict(cur); cur[f] = G[f]
            v1 = np.log(dG(cur['i'], cur['r'], cur['L']))
            phi[f] += (v1 - v0) / 6.0
            v0 = v1
    return phi


h2 = 0.25; t = 0.50
rb = r_prog(100, h2); rc3 = r_own_sire(3, h2, t, rb); rc2 = r_own_sire(2, h2, t, rb)
T = dict(i=[ii(0.05), ii(0.20), ii(0.005), ii(0.85)], r=[rb, rb, rc3, rc2], L=[6.5, 6.0, 5.0, 4.5])
G = dict(i=[ii(0.02), ii(0.10), ii(0.01), ii(0.85)], r=[0.70, 0.70, 0.62, 0.62], L=[2.0, 2.0, 2.5, 4.0])
rp = r_idx3(0.30, 10, 40, 0.08)
PT = dict(i=[ii(0.02), ii(0.08), ii(0.15), ii(0.50)], r=[rp] * 4, L=[1.4, 1.4, 1.8, 2.0])
PG = dict(i=PT['i'], r=[0.62] * 4, L=[1.0, 1.0, 1.5, 1.8])

for name, A, B in (('dairy', T, G), ('pig', PT, PG)):
    gA = dG(**A); gB = dG(**B)
    print('\n== %s: dG trad %.4f  GS %.4f  ratio %.4f  ln ratio %.4f' % (name, gA, gB, gB / gA, np.log(gB / gA)))
    print('   i: %s -> %s' % (np.round(A['i'], 4), np.round(B['i'], 4)))
    print('   r: %s -> %s' % (np.round(A['r'], 4), np.round(B['r'], 4)))
    print('   sum ir: %.4f -> %.4f ; sum L %.1f -> %.1f' % (np.dot(A['i'], A['r']), np.dot(B['i'], B['r']), sum(A['L']), sum(B['L'])))
    phi = shapley(A, B)
    tot = sum(phi.values())
    for f in ['i', 'r', 'L']:
        print('   %s: phi=%+.4f  factor=%.4f  share of log-gain=%+.1f%%' % (f, phi[f], np.exp(phi[f]), 100 * phi[f] / tot))
    print('   check sum phi %.6f vs ln ratio %.6f ; product of factors %.4f' % (tot, np.log(gB / gA), np.exp(tot)))
    # one-at-a-time from trad
    for f in ['i', 'r', 'L']:
        C = dict(A); C[f] = B[f]
        print('   only %s changed: ratio %.4f' % (f, dG(**C) / gA))
    # one-at-a-time back from GS (removing one factor)
    for f in ['i', 'r', 'L']:
        C = dict(B); C[f] = A[f]
        print('   GS but %s reverted: ratio %.4f' % (f, dG(**C) / gA))
    # path shares and elasticities in GS scheme
    ir = np.array(B['i']) * np.array(B['r'])
    print('   GS path shares of sum ir: %s ; L shares: %s' % (np.round(ir / ir.sum(), 4), np.round(np.array(B['L']) / sum(B['L']), 4)))

# break-even accuracy given i and L of GS (all GS r scaled by c)
from scipy.optimize import brentq
gT = dG(**T)
c = brentq(lambda c: dG(G['i'], [c * x for x in G['r']], G['L']) - gT, 0.01, 2)
print('\nbreak-even scale on GS r: %.4f -> bull r %.4f' % (c, c * 0.70))
# what if GS kept trad i (no gain in intensity)
C = dict(G); C['i'] = T['i']
print('GS with trad i: ratio %.4f' % (dG(**C) / gT))
# gain from +0.1 accuracy in GS for all paths vs -0.5 yr in DD path
C = dict(G); C['r'] = [x + 0.10 for x in G['r']]
print('GS r+0.10 all paths: dG %.4f (x%.4f vs GS)' % (dG(**C), dG(**C) / dG(**G)))
C = dict(G); C['L'] = [2.0, 2.0, 2.5, 3.0]
print('GS DD L 4.0->3.0: dG %.4f (x%.4f vs GS)' % (dG(**C), dG(**C) / dG(**G)))
C = dict(G); C['L'] = [1.5, 1.5, 2.5, 4.0]
print('GS SS,SD L 2.0->1.5: dG %.4f (x%.4f vs GS)' % (dG(**C), dG(**C) / dG(**G)))

# marginal effects evaluated at the GS end, and accuracy-equivalent of one year of L
gG = dG(**G)
for f in ['i', 'r']:
    C = dict(G); C[f] = T[f]
    print('marginal %s at GS end: %.4f ; at trad end: %.4f' % (f, gG / dG(**C), dG(**dict(T, **{f: G[f]})) / gT))
num = np.dot(G['i'], G['r']); si = np.sum(G['i'])
target = 10.5 / 9.5          # one year less in sum L
delta = (target - 1) * num / si
print('one year off sum L = x%.4f ; equivalent uniform accuracy increase delta=%.4f' % (target, delta))
C = dict(G); C['r'] = [x + delta for x in G['r']]
print('check: %.4f' % (dG(**C) / gG))
print('L-factor exact 22/10.5 = %.4f ; pig 6.6/5.3 = %.4f' % (22 / 10.5, 6.6 / 5.3))
print('sum L ratio GS/trad = %.4f ; numerator ratio = %.4f' % (10.5 / 22.0, np.dot(G['i'], G['r']) / np.dot(T['i'], T['r'])))
