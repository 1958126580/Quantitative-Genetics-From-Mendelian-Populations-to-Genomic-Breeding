# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4_dF_post.py    依赖：numpy
"""post-processing numbers quoted in §20.4.6"""
import json, numpy as np
d = json.load(open('dF.json'))
r = 0.6
print('h2 equivalent of r_MS=0.6: %.4f' % (2 * r * r / (1 + r * r)))
print('max |icc0 - th| = %.4f' % max(abs(v['icc0'] - v['icc_th']) for v in d.values()))
for k, v in d.items():
    print(k, 'icc0 %.4f th %.4f diff %.4f' % (v['icc0'], v['icc_th'], v['icc0'] - v['icc_th']))
print('dF(r=1)/random = %.4f' % (d['1.0']['dF'] / (1 / 160 + 1 / 800)))
print('max se = %.5f' % max(v['dF_se'] for v in d.values()))
