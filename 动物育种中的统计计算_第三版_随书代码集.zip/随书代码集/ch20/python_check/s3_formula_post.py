# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_formula_post.py    依赖：numpy
"""post-processing of formula.json for §20.3.6"""
import json, numpy as np
res = json.load(open('formula.json'))
keys = ['d30_32', 'd29_32', 'd30_31', 'd30_33', 'd30_emp', 'd29_emp', 'g_32', 'g_31', 'g_emp']
scen = sorted(set(r['scen'] for r in res))
print('Me per scenario')
for s in scen:
    r = [x for x in res if x['scen'] == s][0]
    print('%s Ne=%d L=%d markers=%d 2NeL=%d me32=%.1f me33=%.1f emp=%.1f emp_vt=%.1f' % (
        s, r['ne'], r['L'], r['nmk'], r['me31'], r['me32'], r['me33'], r['me_emp'], r['me_emp_vt']))
print('\nbias by scenario (mean pred-obs) and RMSE')
for s in scen + ['ALL']:
    rows = [x for x in res if s == 'ALL' or x['scen'] == s]
    obs = np.array([x['obs'] for x in rows])
    line = '%-4s n=%2d ' % (s, len(rows))
    for k in keys:
        b = np.array([x[k] for x in rows]) - obs
        line += '%s %+.4f/%.4f ' % (k, b.mean(), np.sqrt((b ** 2).mean()))
    print(line)
print('\nrelative bias (pred/obs - 1) mean, all settings')
obs = np.array([x['obs'] for x in res])
for k in keys:
    pr = np.array([x[k] for x in res])
    print('%-8s mean rel %+.4f  max|abs bias| %.4f  frac pred>obs %.3f' % (k, np.mean(pr / obs - 1), np.abs(pr - obs).max(), np.mean(pr > obs)))
print('\nbias vs N (all scenarios, d30_32, d30_emp, g_32)')
for N in (500, 1000, 2000, 4000):
    rows = [x for x in res if x['N'] == N]
    o = np.array([x['obs'] for x in rows])
    print('N=%d ' % N + ' '.join('%s %+.4f' % (k, np.mean(np.array([x[k] for x in rows]) - o)) for k in ['d30_32', 'd30_emp', 'd29_emp', 'g_32', 'd30_33']))
print('\nbias vs h2')
for h2 in (0.1, 0.3, 0.5):
    rows = [x for x in res if x['h2'] == h2]
    o = np.array([x['obs'] for x in rows])
    print('h2=%.1f ' % h2 + ' '.join('%s %+.4f' % (k, np.mean(np.array([x[k] for x in rows]) - o)) for k in ['d30_32', 'd30_emp', 'd29_emp', 'g_32', 'd30_33']))
print('\nsame 2NeL=2000 (S2 Ne100 L10, S4 Ne50 L20, S5 Ne200 L5): observed')
for h2 in (0.1, 0.3, 0.5):
    for N in (500, 1000, 2000, 4000):
        o = {x['scen']: x for x in res if x['h2'] == h2 and x['N'] == N and x['scen'] in ('S2', 'S4', 'S5')}
        if len(o) == 3:
            print('h2=%.1f N=%d  S2 %.4f  S4 %.4f  S5 %.4f | D30(32) %.4f | G(32): S2 %.4f S4 %.4f S5 %.4f' % (
                h2, N, o['S2']['obs'], o['S4']['obs'], o['S5']['obs'], o['S2']['d30_32'], o['S2']['g_32'], o['S4']['g_32'], o['S5']['g_32']))
# implied Me: solve Daetwyler for Me given observed r
print('\nimplied Me (Daetwyler 20.30) from observed r, by scenario (median over settings)')
for s in scen:
    rows = [x for x in res if x['scen'] == s]
    im = [x['N'] * x['h2'] * (1 / x['obs'] ** 2 - 1) for x in rows]
    print('%s implied Me median %.1f  range %.1f-%.1f   emp %.1f  me32 %.1f' % (s, np.median(im), min(im), max(im), rows[0]['me_emp'], rows[0]['me32']))
