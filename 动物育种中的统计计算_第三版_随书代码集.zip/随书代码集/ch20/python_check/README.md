# 第 20 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch20/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `c20.py` | 数值复核 | scipy | 2.6 | `outputs/c20.out` |
| `s1_beavis_table.py` | 数值复核 | numpy | 0.3 | `outputs/s1_beavis_table.out` |
| `s1_lande.py` | §20.1.5 Lande-Thompson (1990) index: weights, accuracy, relative efficiency table. | numpy, scipy | 1.6 | `outputs/s1_lande.out` |
| `s2_df_post.py` | post-processing for §20.2.6 | numpy | 0.3 | `outputs/s2_df_post.out` |
| `s2_equiv_post.py` | derived numbers quoted in §20.2.5 (from equiv.json) | 标准库 | 0.1 | `outputs/s2_equiv_post.out` |
| `s3_formula_post.py` | post-processing of formula.json for §20.3.6 | numpy | 0.4 | `outputs/s3_formula_post.out` |
| `s3_post2.py` | extra numbers for §20.3.6 and §20.3.7 | numpy, scipy | 2.3 | `outputs/s3_post2.out` |
| `s3_post3.py` | final summary table numbers for §20.3.6 (Table 20.9) and S2/S4/S5 comparison | numpy | 0.4 | `outputs/s3_post3.out` |
| `s4_dF_post.py` | post-processing numbers quoted in §20.4.6 | numpy | 0.3 | `outputs/s4_dF_post.out` |
| `s4_decomp.py` | §20.4.5 decomposition of the annual-gain ratio into i, r, L contributions (Shapley on log scale). | numpy, scipy | 2.4 | `outputs/s4_decomp.out` |
| `s5_questions_check.py` | sanity checks for the new exercises (answers are not printed in the book) | numpy, scipy | 1.5 | `outputs/s5_questions_check.out` |
