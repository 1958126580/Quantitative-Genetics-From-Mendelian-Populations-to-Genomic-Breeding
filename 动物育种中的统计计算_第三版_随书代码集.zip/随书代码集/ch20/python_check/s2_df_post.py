# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_df_post.py    依赖：numpy
"""post-processing for §20.2.6"""
import json, numpy as np
d = json.load(open('df.json'))
n = 1000
for h2 in (0.1, 0.3, 0.5):
    print('n h2 = %.1f' % (n * h2))
print('LD vs LE at h2=0.3:')
for m in ['100', '250', '500', '1000', '2000', '4000', '8000']:
    le = d['LE'][m]['df_0.3']; ld = d['LD'][m]['df_0.3']
    print(' m=%s LE %.1f LD %.1f ratio LD/LE %.4f' % (m, le, ld, ld / le))
full = d['LD']['9061']
me = full['Me_hat']
for h2 in (0.1, 0.3, 0.5):
    r2 = n * h2 / (n * h2 + me * (1 - h2))
    print('LD full m=9061: Me_hat=%.1f h2=%.1f  r2(20.29 with N=n,Me=Me_hat)=%.4f  Me*r2=%.1f  actual df=%.1f' % (me, h2, r2, me * r2, full['df_%.1f' % h2]))
me32 = 4000 / np.log(8000)
print('Me(20.32) Ne=100 L=20 = %.1f' % me32)
for h2 in (0.1, 0.3, 0.5):
    r2 = n * h2 / (n * h2 + me32 * (1 - h2))
    print('  with Me(20.32): h2=%.1f r2=%.4f Me*r2=%.1f' % (h2, r2, me32 * r2))
# lambda growth with m (eq 20.9) for LE: lambda = s (1-h2)/h2 ; s ~ m * mean(2pq)
for m in ['1000', '8000']:
    print('LE m=%s df/m %.4f' % (m, d['LE'][m]['dfm_0.3']))
print('identity', d['identity'])
# approx error at m=n
le = d['LE']['1000']
print('approx overshoot at m=n: %.1f vs %.1f -> %.4f' % (le['approx_0.3'], le['df_0.3'], le['approx_0.3'] / le['df_0.3'] - 1))
for m in ['100', '250', '500', '2000', '4000', '8000', '20000']:
    x = d['LE'][m]
    print(' m=%s approx/df -1 = %+.4f' % (m, x['approx_0.3'] / x['df_0.3'] - 1))
