# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 c20.py    依赖：scipy
from scipy.stats import norm
import math, itertools
def i_of_p(p):
    x=norm.isf(p); return norm.pdf(x)/p
i=[2.2,1.8,1.4,0.8]
rt=[0.95,0.95,0.65,0.55]; rg=[0.75,0.75,0.72,0.65]
st=sum(a*b for a,b in zip(i,rt)); sg=sum(a*b for a,b in zip(i,rg))
print("sum i r trad",st,"GS",sg)
print("rel dG trad",st/21.5,"GS",sg/10.0,"ratio",(sg/10)/(st/21.5))
print("max over perms trad",max(sum(a*b for a,b in zip(p,rt)) for p in itertools.permutations(i)))
print("book ratio",0.451/0.247)
for p in [0.05,0.01,0.1,0.001,0.012]:
    print(p,i_of_p(p))
from scipy.optimize import brentq
print("p for i=2.63",brentq(lambda p:i_of_p(p)-2.63,1e-4,0.5))
print(math.log(12000),6000/math.log(12000),math.log(3000),6000/math.log(3000))
print(3000/9000,math.sqrt(1/3),3000/3639,math.sqrt(3000/3639))
print("wolc geo 3 gens",1-(0.35/0.6)**(1/3),"4 gens",1-(0.35/0.6)**(1/4),"lin3",(0.25/3)/0.6)
