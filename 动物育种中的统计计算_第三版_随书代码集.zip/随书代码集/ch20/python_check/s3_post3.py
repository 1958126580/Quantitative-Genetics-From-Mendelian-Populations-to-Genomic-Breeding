# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_post3.py    依赖：numpy
"""final summary table numbers for §20.3.6 (Table 20.9) and S2/S4/S5 comparison"""
import json, numpy as np
res = json.load(open('formula.json'))
obs = np.array([x['obs'] for x in res])
print('Table 20.9 rows: key | mean bias | rmse | max|b| | n over | corr')
for k in ['d30_31', 'd30_32', 'd30_33', 'd30_emp', 'd29_32', 'd29_emp', 'g_31', 'g_32', 'g_emp']:
    pr = np.array([x[k] for x in res]); b = pr - obs
    print('%-8s %+.4f %.4f %.4f %2d/60 %.4f' % (k, b.mean(), np.sqrt((b ** 2).mean()), np.abs(b).max(), int((pr > obs).sum()), np.corrcoef(pr, obs)[0, 1]))
print('\nS2/S4/S5 mean over 12 settings: obs, g_32, d30_32, d30_emp')
for s in ['S2', 'S4', 'S5']:
    r = [x for x in res if x['scen'] == s]
    print(s, 'obs %.4f g32 %.4f d30_32 %.4f d30_emp %.4f emp Me %.1f' % (np.mean([x['obs'] for x in r]), np.mean([x['g_32'] for x in r]),
          np.mean([x['d30_32'] for x in r]), np.mean([x['d30_emp'] for x in r]), r[0]['me_emp']))
print('S4 emp / S5 emp = %.4f ; S4/S2 = %.4f' % ([x for x in res if x['scen'] == 'S4'][0]['me_emp'] / [x for x in res if x['scen'] == 'S5'][0]['me_emp'],
      [x for x in res if x['scen'] == 'S4'][0]['me_emp'] / [x for x in res if x['scen'] == 'S2'][0]['me_emp']))
print('2NeL / emp ratio by scenario: ' + ' '.join('%s %.2f' % (s, [x for x in res if x['scen'] == s][0]['me31'] / [x for x in res if x['scen'] == s][0]['me_emp']) for s in ['S1', 'S2', 'S3', 'S4', 'S5']))
