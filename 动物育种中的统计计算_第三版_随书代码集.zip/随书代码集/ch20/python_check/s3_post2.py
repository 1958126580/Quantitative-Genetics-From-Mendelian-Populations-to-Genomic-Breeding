# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3_post2.py    依赖：numpy, scipy
"""extra numbers for §20.3.6 and §20.3.7"""
import json, numpy as np
from scipy.optimize import brentq
res = json.load(open('formula.json'))


def goddard(N, h2, me, ne):
    lam = me / (h2 * np.log(2 * ne)); a = 1 + 2 * lam / N; sa = np.sqrt(a)
    return np.sqrt(max(1 - lam / (2 * N * sa) * np.log((1 + a + 2 * sa) / (1 + a - 2 * sa)), 0))


print('implied Me: Daetwyler(20.30) and Goddard(20.34), median by scenario; ratios to 1/Var(Gij) and to Me(20.32)')
for s in ['S1', 'S2', 'S3', 'S4', 'S5']:
    rows = [x for x in res if x['scen'] == s]
    imD = [x['N'] * x['h2'] * (1 / x['obs'] ** 2 - 1) for x in rows]
    imG = [brentq(lambda m: goddard(x['N'], x['h2'], m, x['ne']) - x['obs'], 1, 1e6) for x in rows]
    e = rows[0]['me_emp']; m32 = rows[0]['me32']
    print('%s  D: %.1f (x%.2f emp, x%.2f me32)   G: %.1f (x%.2f emp, x%.2f me32, x%.3f 2NeL)  mean obs %.4f' % (
        s, np.median(imD), np.median(imD) / e, np.median(imD) / m32, np.median(imG), np.median(imG) / e, np.median(imG) / m32,
        np.median(imG) / rows[0]['me31'], np.mean([x['obs'] for x in rows])))
for k in ['d30_32', 'd30_33', 'd30_emp', 'g_32', 'g_emp', 'd29_32']:
    n_over = sum(1 for x in res if x[k] > x['obs'])
    print('%s: pred>obs in %d of %d' % (k, n_over, len(res)))
print('\nS3 detail rows')
for x in [x for x in res if x['scen'] == 'S3']:
    print('h2=%.1f N=%4d obs %.4f (%.4f) | d30_32 %.4f d29_32 %.4f d30_emp %.4f g_32 %.4f' % (
        x['h2'], x['N'], x['obs'], x['sd'], x['d30_32'], x['d29_32'], x['d30_emp'], x['g_32']))
h = json.load(open('habier.json'))
print('\nHabier: %d reps' % len(h))
m = {k: np.mean([r[k] for r in h]) for k in h[0] if k != 'rep'}
sd = {k: np.std([r[k] for r in h], ddof=1) for k in h[0] if k != 'rep'}
for p in ['LD', 'LDs']:
    print('%s: A3 %.4f B3 %.4f drop %.4f ratio B3/A3 %.4f ; A3->A5 drop %.4f' % (p, m[p + '_A3'], m[p + '_B3'], m[p + '_A3'] - m[p + '_B3'],
          m[p + '_B3'] / m[p + '_A3'], m[p + '_A3'] - m[p + '_A5']))
print('ped A3->A5 drop %.4f ; LE A3->A5 drop %.4f ; LE/ped at A3 %.4f' % (m['ped_A3'] - m['ped_A5'], m['LE_A3'] - m['LE_A5'], m['LE_A3'] / m['ped_A3']))
print('LE_B3 mean %.4f sd %.4f se %.4f t %.2f' % (m['LE_B3'], sd['LE_B3'], sd['LE_B3'] / np.sqrt(len(h)), m['LE_B3'] / (sd['LE_B3'] / np.sqrt(len(h)))))
# paired differences A3 - B3 per rep
for p in ['LD', 'LDs']:
    dd = np.array([r[p + '_A3'] - r[p + '_B3'] for r in h])
    print('%s paired A3-B3: mean %.4f sd %.4f se %.4f min %.4f max %.4f' % (p, dd.mean(), dd.std(ddof=1), dd.std(ddof=1) / np.sqrt(len(h)), dd.min(), dd.max()))
s3 = [x for x in res if x['scen'] == 'S3'][0]
for nm, me in (('me32', s3['me32']), ('emp', s3['me_emp'])):
    print('Daetwyler N=2000 h2=0.3 Me=%s %.1f -> r=%.4f' % (nm, me, np.sqrt(600 / (600 + me))))
print('mean nLD %.1f nLE %.1f' % (m['nLD'], m['nLE']))
