# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s1_beavis_table.py    依赖：numpy
import json
import numpy as np
d = json.load(open('beavis.json'))
print('h2 nd | P(k=0) | k|k>0 | infl | p_app|k>0 | p_real|k>0 | RE pred | RE naive | RE opt | P(naive<1|k>0) | RR | slope_rr | maxshare')
for k, v in d.items():
    print('%.1f %4d | %.3f | %.2f | %.3f | %.4f | %.4f | %.4f | %.4f | %.4f | %.3f | %.4f | %.3f | %.4f' % (
        v['h2'], v['nd'], v['frac_k0'], v['c_k'], v['infl'], v['c_p_app'], v['c_p_real'], v['c_re_pred'], v['c_re_naive'],
        v['c_re_opt'], v['c_frac_naive_lt1'], v['re_rr'], v['slope_rr'], v['share_max']))
print('max share mean over settings: %.4f' % np.mean([v['share_max'] for v in d.values()]))
print('range share max: %.4f-%.4f' % (min(v['share_max'] for v in d.values()), max(v['share_max'] for v in d.values())))
print('ratio p_app/p_real: ' + ' '.join('%s:%.2f' % (k, v['c_p_app'] / v['c_p_real']) for k, v in d.items()))
