# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s5_questions_check.py    依赖：numpy, scipy
"""sanity checks for the new exercises (answers are not printed in the book)"""
import numpy as np, json
from scipy import integrate
# Q11(b): h2=0.1, p_app=0.2, true unbiased score explains p=0.05, score inflated m=2 m0
h2, pa, p, k = 0.1, 0.2, 0.05, 2.0
by = h2 * (1 - pa) / (1 - pa * h2); bm = (1 - h2) / (1 - pa * h2)
V = k * k * p * h2; C = k * p * h2
r = (by * h2 + bm * C) / np.sqrt((by ** 2 + 2 * by * bm * C + bm ** 2 * V) * h2)
print('Q11b realized RE = %.4f ; predicted (p_app) RE = %.4f' % (r / np.sqrt(h2), np.sqrt(pa / h2 + (1 - pa) ** 2 / (1 - h2 * pa))))
# Q13: E(2pq), p~U(0.05,0.5)
E2pq = integrate.quad(lambda x: 2 * x * (1 - x), 0.05, 0.5)[0] / 0.45
print('Q13 E(2pq) = %.4f -> expected inflation m/s = %.4f' % (E2pq, 1 / E2pq))
# Q16(b)
d = json.load(open('dF.json'))
own = d[[k_ for k_ in d if k_.startswith('0.420')][0]]; gs = d['0.6']
print('Q16b dF/yr ratio %.4f dG/yr ratio %.4f ; dF/gen cap to keep dF/yr: %.5f' % ((gs['dF'] / 1.0) / (own['dF'] / 1.5), (gs['dG'] / 1.0) / (own['dG'] / 1.5), own['dF'] / 1.5 * 1.0))
