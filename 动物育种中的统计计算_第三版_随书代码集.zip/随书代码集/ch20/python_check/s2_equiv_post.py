# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 20 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2_equiv_post.py    依赖：仅标准库
"""derived numbers quoted in §20.2.5 (from equiv.json)"""
import json
d = json.load(open('equiv.json'))
rows = {r[0]: r for r in d['rows']}
r1 = rows['pitfall1 sample-centred inv(G)']
print('pitfall1 max diff / max|g|: ref %.4f%%  cand %.4f%%' % (r1[3] / 1.2550 * 100, r1[4] / 1.0789 * 100))
print('pitfall3 sd ratio wrong/right = %.4f' % (d['p3_wrong']['sd'] / d['p3_right']['sd']))
print('m/s = %.4f' % (3000 / d['s']))
print('G base min eig %.6f cond %.2f' % (d['G_base_mineig'], d['G_base_cond']))
for k in ['GBLUP MME G^-1', 'GBLUP V-form', 'sample-centred V-form', 'pitfall2 (1-0.01)G+0.01I', 'pitfall2 (1-0.05)G+0.05I', 'pitfall3 s2a=s2g/m']:
    print(k, ' '.join('%.6g' % x for x in rows[k][2:]))
