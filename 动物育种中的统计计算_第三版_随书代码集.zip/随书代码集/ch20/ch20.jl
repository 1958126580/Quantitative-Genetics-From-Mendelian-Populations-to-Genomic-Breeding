# 本脚本由 tools/nb2jl.py 从同目录的 ch20.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 20

# %% [markdown]
# # 第二十章　基因组选择的理论基础 —— 配套代码
#
# 本 Notebook 对应《动物育种中的统计计算（第三版）》第二十章。
#
# **内容**
#
# 1. 环境与工具函数
# 2. Beavis 效应（选择偏差）的模拟验证——正文式 (20.3)
# 3. $\sigma_A^2=2\sum p_jq_j\sigma_\alpha^2$ 的数值验证——正文式 (20.17)
# 4. SNP-BLUP 与 GBLUP 等价性的数值验证——正文定理 20.1 与式 (20.25)
# 5. $M_e$ 的三种解析估计与从 $\mathbf G$ 矩阵的经验估计——正文式 (20.31)–(20.33)
# 6. 三个准确性公式的实现与比较——正文式 (20.30)、(20.34)、(20.37)
# 7. 模拟验证 Daetwyler 公式
# 8. 参考群体规模的设计实验
# 9. 四路径年遗传进展的比较——正文式 (20.42)
#
# **运行环境**：Julia 1.13.0（兼容 1.10 LTS）。首次运行请先在项目根目录执行 `] instantiate`。

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions
using InteractiveUtils: versioninfo

const BOOKSEED = 20260918
bookrng() = Xoshiro(BOOKSEED)

"""相对误差，用于数值验证。"""
relerr(a, b) = norm(a .- b) / max(norm(b), eps())

"""断言两个量在给定容差内相等，并打印结果。"""
function check(name::AbstractString, a, b; tol=1e-10)
    e = relerr(a, b)
    @printf("%-46s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end

versioninfo(); println()

# %% [markdown]
# ## 1　Beavis 效应：为什么 MAS 会失败
#
# 正文式 (20.3)：在显著性阈值 $c$ 上条件化之后，被"发现"的 QTL 效应期望为
#
# $$E(\hat a\mid \hat a>c)=a+\sigma_{\hat a}\frac{\phi\!\left(\frac{c-a}{\sigma_{\hat a}}\right)}{1-\Phi\!\left(\frac{c-a}{\sigma_{\hat a}}\right)}$$
#
# 下面同时给出解析值与蒙特卡洛值。

# %%
"""正文式 (20.3)：单侧截断正态的条件期望（选择偏差）。"""
function beavis_expectation(a::Real, sd::Real, c::Real)
    z = (c - a) / sd
    d = Normal()
    return a + sd * pdf(d, z) / ccdf(d, z)
end

"""蒙特卡洛验证：只保留 |â| > c 的"显著"位点。"""
function beavis_mc(a, sd, c; nrep=2_000_000, rng=Random.default_rng())
    s = 0.0; k = 0
    for _ in 1:nrep
        ah = a + sd*randn(rng)
        if ah > c
            s += ah; k += 1
        end
    end
    return s/k, k/nrep
end

println("真效应 a = 0.20σP ，  σ_â 取三档，  阈值 c = 2.5 σ_â\n")
@printf("%-10s%-14s%-14s%-14s%-10s\n", "σ_â", "阈值 c", "解析期望", "蒙特卡洛", "高估倍数")
for sd in (0.15, 0.075, 0.0375)
    a = 0.20; c = 2.5*sd
    ana = beavis_expectation(a, sd, c)
    mc, pw = beavis_mc(a, sd, c; nrep=400_000, rng=Xoshiro(11))
    @printf("%-10.4f%-14.4f%-14.4f%-14.4f%-10.2f\n", sd, c, ana, mc, ana/a)
end
println("\n=> 检验功效越低（σ_â 越大），被报告的效应高估越严重（正文 §20.1.2 陷阱一）。")

# %% [markdown]
# ## 2　$\sigma_A^2=2\sum p_jq_j\sigma_\alpha^2$ 的数值验证
#
# 正文式 (20.17)。这里验证两件事：
#
# - 在**连锁平衡**且**效应与频率独立**时，式 (20.17) 成立；
# - 当效应与频率相关（$\mathrm{Var}(\alpha_j)\propto 1/(2p_jq_j)$）时，式 (20.17) 失效——正文式 (20.18)。

# %%
"""在连锁平衡下模拟基因型矩阵（每个位点独立二项抽样）。"""
function sim_genotypes_LE(n::Int, m::Int; maf_min=0.05, rng=Random.default_rng())
    p = maf_min .+ (1 - 2maf_min) .* rand(rng, m)
    Mg = Matrix{Float64}(undef, n, m)
    @inbounds for j in 1:m, i in 1:n
        Mg[i,j] = Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j])
    end
    return Mg, p
end

n, m = 4000, 5000
Mg, p = sim_genotypes_LE(n, m; rng=Xoshiro(20))
q = 1 .- p
twopq = 2 .* sum(p .* q)
Z = Mg .- 2 .* p'

# 情形 A：效应与频率独立
s2alpha = 0.001
alphaA = sqrt(s2alpha) .* randn(Xoshiro(21), m)
uA = Z * alphaA
@printf("情形 A（效应与频率独立）\n")
@printf("  理论 σ_A² = 2Σp q σ_α² = %.5f\n", twopq * s2alpha)
@printf("  实际 Var(u)              = %.5f     相对差 %.2f%%\n",
        var(uA), 100*abs(var(uA) - twopq*s2alpha)/(twopq*s2alpha))

# 情形 B：Var(α_j) ∝ 1/(2 p q)（低频位点效应更大）
cB = s2alpha * mean(2 .* p .* q)
alphaB = sqrt.(cB ./ (2 .* p .* q)) .* randn(Xoshiro(22), m)
uB = Z * alphaB
@printf("\n情形 B（Var(α_j) ∝ 1/(2pq)）\n")
@printf("  按式 (20.17) 误用的“理论”值 = %.5f\n", twopq * mean(alphaB.^2))
@printf("  正确的 Σ 2p q α_j²          = %.5f\n", sum(2 .* p .* q .* alphaB.^2))
@printf("  实际 Var(u)                 = %.5f\n", var(uB))
println("\n=> 情形 B 中每个位点贡献相同的方差，σ_A² = m·c_B，与 2Σpq 无关（正文式 20.18）。")
@printf("     m·c_B = %.5f\n", m*cB)

# %% [markdown]
# ## 3　SNP-BLUP 与 GBLUP 的等价性（正文定理 20.1）
#
# 同时验证 back-solving 公式 (20.25)：
#
# $$\hat{\boldsymbol\alpha}=\frac{\mathbf Z'\mathbf G^{-1}\hat{\mathbf g}}{2\sum_jp_jq_j}$$

# %%
"""解 SNP-BLUP 的 MME（标记效应模型），返回 (β̂, α̂)。"""
function snp_blup(y::Vector{Float64}, X::Matrix{Float64}, Z::Matrix{Float64}, lam_a::Float64)
    p_ = size(X,2); m_ = size(Z,2)
    C = [X'X       X'Z;
         Z'X       Z'Z + lam_a*I]
    rhs = [X'y; Z'y]
    sol = (C + 1e-9I) \ rhs
    return sol[1:p_], sol[p_+1:end]
end

"""解 GBLUP 的 MME（育种值模型），返回 (β̂, ĝ, ê)。"""
function gblup(y::Vector{Float64}, X::Matrix{Float64}, G::Matrix{Float64}, lam::Float64)
    n_ = length(y); p_ = size(X,2)
    Gi = inv(Symmetric(G + 1e-8I))
    C = [X'X        X';
         X          I + lam*Gi]
    rhs = [X'y; y]
    sol = (C + 1e-10I) \ rhs
    b = sol[1:p_]; g = sol[p_+1:end]
    return b, g, y - X*b - g
end

# 小规模验证
nv, mv = 300, 800
Mv, pv = sim_genotypes_LE(nv, mv; rng=Xoshiro(30))
Zv = Mv .- 2 .* pv'
sv = 2*sum(pv .* (1 .- pv))
Gv = (Zv*Zv') ./ sv

h2 = 0.4; s2A = h2; s2e = 1 - h2
s2alpha_v = s2A / sv
alpha_true = sqrt(s2alpha_v) .* randn(Xoshiro(31), mv)
yv = 10.0 .+ Zv*alpha_true .+ sqrt(s2e) .* randn(Xoshiro(32), nv)
Xv = ones(nv, 1)

lam  = s2e / s2A          # GBLUP 的 λ
lam_a = s2e / s2alpha_v   # SNP-BLUP 的 λ_α = λ · 2Σpq

b1, alpha_hat = snp_blup(yv, Xv, Zv, lam_a)
b2, g_hat, e_hat = gblup(yv, Xv, Gv, lam)

check("定理 20.1：ĝ_GBLUP  vs  Z α̂_SNPBLUP", g_hat, Zv*alpha_hat; tol=1e-6)
check("定理 20.1：β̂ 一致",                   b1, b2; tol=1e-6)

# back-solving：式 (20.25) 与式 (21.31) 两条路径
alpha_bs1 = (Zv' * (inv(Symmetric(Gv + 1e-8I)) * g_hat)) ./ sv
alpha_bs2 = (Zv' * e_hat) ./ (lam * sv)      # 正文式 (21.31)，无需求逆
check("back-solving 式 (20.25)", alpha_bs1, alpha_hat; tol=1e-5)
check("back-solving 式 (21.31)", alpha_bs2, alpha_hat; tol=1e-5)
@printf("\nλ_α / λ = %.2f ，  2Σpq = %.2f （应相等）\n", lam_a/lam, sv)

# %% [markdown]
# ## 4　有效染色体片段数 $M_e$
#
# 三个解析近似（正文式 20.31–20.33）与一个经验估计。
#
# 经验估计基于 Goddard 等 (2011)：对**非亲缘**个体对，$\mathrm{Var}(G_{ik})\approx 1/M_e$，故
#
# $$\hat M_e=\frac{1}{\mathrm{Var}_{i\ne k}(G_{ik})}$$

# %%
"""正文式 (20.31)：Hayes 等 (2009)。"""
Me_hayes(Ne, L) = 2*Ne*L

"""正文式 (20.32)：Goddard (2009)。"""
Me_goddard(Ne, L) = 2*Ne*L / log(4*Ne*L)

"""正文式 (20.33)：Meuwissen (2009) 变体。"""
Me_meuwissen(Ne, L) = 2*Ne*L / log(Ne*L)

"""由 G 矩阵的非对角元方差经验估计 Me（Goddard 等 2011）。"""
function Me_from_G(G::AbstractMatrix)
    n = size(G,1)
    v = Float64[]
    @inbounds for i in 1:n-1, k in i+1:n
        push!(v, G[i,k])
    end
    return 1 / var(v)
end

println("解析估计（L = 30 M）\n")
@printf("%-8s%-14s%-14s%-14s\n", "Ne", "Hayes", "Goddard", "Meuwissen")
for Ne in (50, 100, 200, 500)
    @printf("%-8d%-14.0f%-14.0f%-14.0f\n", Ne,
            Me_hayes(Ne,30), Me_goddard(Ne,30), Me_meuwissen(Ne,30))
end

@printf("\n由上面 LE 模拟的 G 矩阵经验估计： Me ≈ %.0f\n", Me_from_G(Gv))
println("（注意：LE 模拟没有真实的连锁结构，此处仅演示算法；")
println("  真实数据上应使用含重组的模拟或实测基因型，见 XSim.jl 示例。）")

# %% [markdown]
# ## 5　三个准确性公式
#
# - Daetwyler 等 (2008)：式 (20.30) $r^2=\dfrac{Nh^2}{Nh^2+M_e}$
# - 本书式 (20.29)（Rabier 等 2016 等价形式）：$r^2=\dfrac{Nh^2}{Nh^2+M_e(1-h^2)}$
# - Goddard (2009)：式 (20.34)–(20.35)
# - Goddard 等 (2011) 有限标记修正：式 (20.36)–(20.37)

# %%
"""正文式 (20.30)：Daetwyler 等 (2008)。"""
acc_daetwyler(N, h2, Me) = sqrt(N*h2 / (N*h2 + Me))

"""正文式 (20.29)：含 (1-h²) 的形式。"""
acc_ridge(N, h2, Me) = sqrt(N*h2 / (N*h2 + Me*(1-h2)))

"""正文式 (20.34)–(20.35)：Goddard (2009) 的确定性公式。"""
function acc_goddard(N, h2, Me, Ne)
    lam = Me / (h2 * log(2Ne))
    a   = 1 + 2*lam/N
    r2  = 1 - (lam/(2N*sqrt(a))) * log((1 + a + 2sqrt(a)) / (1 + a - 2sqrt(a)))
    return sqrt(clamp(r2, 0.0, 1.0))
end

"""正文式 (20.36)–(20.37)：Goddard 等 (2011)，有限标记数 M 的修正。"""
function acc_goddard2011(N, h2, Me, Mmark)
    b = Mmark / (Mmark + Me)
    t = N*b*h2 / Me
    return sqrt(b * t / (1 + t))
end

Ne, L = 100, 30.0
Me_ = Me_goddard(Ne, L)
h2_ = 0.30
@printf("Ne = %d ， L = %.0f M ， Me = %.0f ， h² = %.2f\n\n", Ne, L, Me_, h2_)
@printf("%-10s%-14s%-14s%-14s%-14s\n", "N", "Daetwyler", "含(1-h²)", "Goddard09", "Goddard11(50K)")
for N in (500, 1000, 2000, 5000, 10_000, 50_000, 200_000)
    @printf("%-10d%-14.3f%-14.3f%-14.3f%-14.3f\n", N,
            acc_daetwyler(N,h2_,Me_), acc_ridge(N,h2_,Me_),
            acc_goddard(N,h2_,Me_,Ne), acc_goddard2011(N,h2_,Me_,50_000))
end
@printf("\nGoddard(2011) 的准确性上限 √b = %.3f （M = 50 000）\n",
        sqrt(50_000/(50_000+Me_)))
@printf("全序列 M = 10⁷ 时上限 √b = %.4f\n", sqrt(1e7/(1e7+Me_)))

# %% [markdown]
# ## 6　用模拟验证 Daetwyler 公式
#
# 构造一个"$M_e$ 个独立片段"的理想化基因组，直接检验式 (20.30) / (20.29)。

# %%
"""在"Me 个独立正交片段"的理想模型下模拟并做岭回归预测。

返回 (实测 r, 式 20.30 预测, 式 20.29 预测)。
"""
function daetwyler_sim(N::Int, h2::Float64, Me::Int; nval=2000, rng=Random.default_rng())
    # 片段剂量标准化为方差 1
    Wtr = randn(rng, N,    Me)
    Wva = randn(rng, nval, Me)
    gam = randn(rng, Me) .* sqrt(h2/Me)      # 片段效应
    gtr = Wtr*gam; gva = Wva*gam
    ytr = gtr .+ randn(rng, N) .* sqrt(1-h2)
    # 岭回归（BLUP），λ = σe²/(σA²/Me)
    lam = (1-h2) / (h2/Me)
    gam_hat = (Wtr'Wtr + lam*I) \ (Wtr'ytr)
    ghat = Wva*gam_hat
    return cor(ghat, gva), acc_daetwyler(N,h2,Me), acc_ridge(N,h2,Me)
end

println("Me = 300 ， h² = 0.30 ， 验证群体 2000")
@printf("\n%-10s%-16s%-16s%-16s\n", "N", "模拟实测 r", "式(20.30)", "式(20.29)")
for N in (200, 500, 1000, 2000, 5000)
    r_sim, r30, r29 = daetwyler_sim(N, 0.30, 300; rng=Xoshiro(40+N))
    @printf("%-10d%-16.3f%-16.3f%-16.3f\n", N, r_sim, r30, r29)
end
println("\n=> 在正交片段的理想模型下，实测值与式 (20.29) 吻合得更好；")
println("   式 (20.30) 更保守。正文 §20.3.1 对此有说明。")

# %% [markdown]
# ## 7　参考群体规模的设计实验
#
# 回答一个具体问题：**要达到目标准确性，参考群体需要多大？**

# %%
"""由目标准确性反解所需的参考群体规模（式 20.30）。"""
required_N(r_target, h2, Me) = Me * r_target^2 / (h2 * (1 - r_target^2))

println("达到目标准确性所需的参考群体规模（Me = 640，牛，Ne=100）\n")
Me640 = Me_goddard(100, 30.0)
@printf("%-10s", "h²")
for rt in (0.5, 0.6, 0.7, 0.8, 0.9); @printf("%-12s", "r=$(rt)"); end
println()
for h2x in (0.05, 0.10, 0.20, 0.30, 0.40, 0.60)
    @printf("%-10.2f", h2x)
    for rt in (0.5, 0.6, 0.7, 0.8, 0.9)
        @printf("%-12.0f", required_N(rt, h2x, Me640))
    end
    println()
end
println("\n=> 遗传力减半，所需参考群体加倍（正文 §20.3.4 的非对称性）。")

# 边际收益
println("\n准确性对 N 的边际收益（h²=0.30, Me=640）：")
for N in (1000, 5000, 20_000, 100_000)
    dr2 = Me640*0.30 / (N*0.30 + Me640)^2
    @printf("  N = %-8d  dr²/dN = %.3e   再加 1000 头带来 Δr² = %.4f\n",
            N, dr2, dr2*1000)
end

# %% [markdown]
# ## 8　四路径年遗传进展的比较（正文 §20.4.1）
#
# $$\Delta G_y=\frac{\sum_{k=1}^4 i_k r_k\sigma_A}{\sum_{k=1}^4 L_k}$$

# %%
"""由留种率计算选择强度 i = φ(x_p)/p （截断正态）。"""
function sel_intensity(p::Float64)
    d = Normal()
    x = quantile(d, 1 - p)
    return pdf(d, x) / p
end

"""正文式 (20.42)：四路径年遗传进展（以 σ_A 为单位）。"""
function delta_G_year(i::Vector{Float64}, r::Vector{Float64}, L::Vector{Float64})
    return sum(i .* r) / sum(L)
end

paths = ["公→公", "公→母", "母→公", "母→母"]
p_sel = [0.02, 0.05, 0.10, 0.50]
i_vec = sel_intensity.(p_sel)

@printf("%-10s%-12s%-12s\n", "路径", "留种率", "选择强度 i")
for (k, nm) in enumerate(paths)
    @printf("%-10s%-12.3f%-12.3f\n", nm, p_sel[k], i_vec[k])
end

r_trad = [0.95, 0.95, 0.65, 0.55];  L_trad = [6.5, 6.5, 4.0, 4.5]
r_gs   = [0.75, 0.75, 0.72, 0.65];  L_gs   = [2.0, 2.0, 2.5, 3.5]

dG_trad = delta_G_year(i_vec, r_trad, L_trad)
dG_gs   = delta_G_year(i_vec, r_gs,   L_gs)

@printf("\n%-16s%-12s%-12s%-12s\n", "方案", "Σ i·r", "Σ L", "ΔG_y (σ_A/年)")
@printf("%-16s%-12.3f%-12.1f%-12.4f\n", "传统后裔测定", sum(i_vec.*r_trad), sum(L_trad), dG_trad)
@printf("%-16s%-12.3f%-12.1f%-12.4f\n", "基因组选择",   sum(i_vec.*r_gs),   sum(L_gs),   dG_gs)
@printf("\n相对提升 = %.1f%%\n", 100*(dG_gs/dG_trad - 1))

# 敏感性：GEBV 准确性下降会怎样？
println("\nGEBV 准确性的敏感性分析（公畜路径）：")
for acc in (0.55, 0.60, 0.65, 0.70, 0.75, 0.80)
    rg = [acc, acc, 0.72, 0.65]
    d = delta_G_year(i_vec, rg, L_gs)
    @printf("  公畜 GEBV 准确性 %.2f  →  ΔG_y = %.4f  （相对传统 %+.1f%%）\n",
            acc, d, 100*(d/dG_trad - 1))
end

# %% [markdown]
# ## 9　本章小结与自检
#
# 下面把本 Notebook 中所有的数值断言集中复核一遍。

# %%
ok = Bool[]
push!(ok, check("等价性：ĝ = Zα̂",                 g_hat, Zv*alpha_hat; tol=1e-6))
push!(ok, check("back-solving 两条路径一致",       alpha_bs1, alpha_bs2; tol=1e-5))
push!(ok, check("Me_goddard(100,30) = 2NeL/ln(4NeL)",
                Me_goddard(100,30.0), 6000/log(12000); tol=1e-12))
push!(ok, check("acc_daetwyler 单调性（N↑）",
                acc_daetwyler(2000,0.3,640) > acc_daetwyler(1000,0.3,640) ? 1.0 : 0.0, 1.0))
push!(ok, check("required_N 与 acc_daetwyler 互逆",
                acc_daetwyler(required_N(0.7,0.3,640), 0.3, 640), 0.7; tol=1e-10))
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
