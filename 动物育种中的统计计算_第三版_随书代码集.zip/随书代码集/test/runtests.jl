# 随书代码集自检：在 code/ 目录下执行  julia --project=. -e 'using Pkg; Pkg.test()'
#   快速测试（秒级）：公用模块、手算对照、37 个章节文件夹的完整性与语法解析、.jl 与笔记本同步
#   慢速测试（需设置环境变量 ASC3_SLOW_TESTS=1）：依次执行全部章节脚本并检查其自检汇总
using Test

@testset "快速" begin include("test_fast.jl") end
if get(ENV, "ASC3_SLOW_TESTS", "0") == "1"
    @testset "慢速（执行全部章节脚本）" begin include("test_slow.jl") end
end
