using Test, ASC3, LinearAlgebra, JSON

@testset "ASC3 公用模块" begin
    @test isfile(joinpath(dirname(dirname(pathof(ASC3))), "Project.toml"))
    @test ASC3.relerr([1.0, 2.0], [1.0, 2.0]) == 0.0
    @test ASC3.isclose([1.0, 2.0], [1.0, 2.0 + 1e-12])
    r1 = rand(ASC3.bookrng(), 5); r2 = rand(ASC3.bookrng(), 5)
    @test r1 == r2                                   # 同一会话、同一版本内可复现
end

@testset "手算对照：第九章 7 个体系谱" begin
    sire = [0, 0, 1, 1, 3, 1, 5]; dam = [0, 0, 0, 2, 4, 4, 6]
    n = 7; A = zeros(n, n)
    for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i, j] = A[j, i] = 0.5 * ((s > 0 ? A[j, s] : 0.0) + (d > 0 ? A[j, d] : 0.0))
        end
        A[i, i] = 1.0 + (s > 0 && d > 0 ? 0.5 * A[s, d] : 0.0)
    end
    @test diag(A) .- 1 ≈ [0, 0, 0, 0, 0.125, 0.25, 0.28125] atol = 1e-12
    @test issymmetric(A) && isposdef(A)
end

"递归查找解析结果中的语法错误节点。"
haserror(ex) = ex isa Expr && (ex.head in (:error, :incomplete) || any(haserror, ex.args))

@testset "章节文件夹完整，代码单元可被 Julia 解析，.jl 与笔记本同步" begin
    root = dirname(@__DIR__)
    dirs = sort(filter(d -> occursin(r"^(ch\d\d|app[AB])$", d), readdir(root)))
    @test length(filter(d -> startswith(d, "ch"), dirs)) == 35      # 第 1–35 章
    @test length(dirs) == 37                                         # 另有附录 A、B
    for ch in dirs
        nbf = joinpath(root, ch, ch * ".ipynb")
        jlf = joinpath(root, ch, ch * ".jl")
        @test isfile(nbf) && isfile(jlf) && isfile(joinpath(root, ch, "README.md"))
        nb = JSON.parsefile(nbf)
        jl = read(jlf, String)
        for (k, cell) in enumerate(nb["cells"])
            cell["cell_type"] == "code" || continue
            src = cell["source"] isa AbstractString ? cell["source"] : join(cell["source"])
            ok = try
                !haserror(Meta.parseall(src; filename = "$(ch).ipynb#cell$(k)"))
            catch
                false
            end
            ok || @warn "语法错误" ch k
            @test ok
            @test occursin(rstrip(src), jl)          # .jl 由 tools/nb2jl.py 生成，必须与笔记本一致
        end
    end
end
