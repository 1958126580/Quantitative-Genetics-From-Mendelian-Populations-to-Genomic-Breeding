# 依次执行全部 37 个章节脚本（可选单元的开关保持关闭），并检查各章"自检汇总"单元的结果。
# 不需要额外的包：直接 include 各章的 .jl 脚本。全部运行约需数十分钟。
using Test

root = dirname(@__DIR__)
for ch in sort(filter(d -> occursin(r"^(ch\d\d|app[AB])$", d), readdir(root)))
    f = joinpath(root, ch, ch * ".jl")
    @testset "$ch" begin
        m = Module(Symbol(ch))
        ok = try
            cd(() -> Base.include(m, f), dirname(f))
            true
        catch e
            @error "执行失败" ch exception = (e, catch_backtrace())
            false
        end
        @test ok
        # 多数章节的自检汇总单元把断言结果收集在向量 ok 中
        if ok && isdefined(m, :ok) && getfield(m, :ok) isa AbstractVector{Bool}
            @test all(getfield(m, :ok))
        end
    end
end
