# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 t_adamw_shift.py    依赖：numpy
import os
os.environ['OMP_NUM_THREADS']='1'
import numpy as np
from opt import Opt
d, kappa = 50, 1e4
lam = 10 ** np.linspace(0, 4, d)
z0 = np.random.default_rng(30212).standard_normal(d)
c = z0.copy()     # minimiser x* = c ; start at 0 -> displacement -c (same size as before)
f0 = 0.5*np.sum(lam*c**2)
LRS = np.array([1e-3, 3e-3, 1e-2, 3e-2, 1e-1, 3e-1, 1.0])
for kind, wd in (('adam',0.0),('adamw',0.01),('adamw',0.001)):
    G=len(LRS); x=np.zeros((G,d)); lr=LRS.reshape(G,1)
    o=Opt(kind, lr, wd=wd)
    hit=np.full(G,-1); fl=[]
    for t in range(1,60001):
        g=(x-c)*lam
        x=o.step(x,g)
        f=0.5*np.sum(lam*(x-c)**2,axis=1)
        newly=(f<=1e-10*f0)&(hit<0); hit[newly]=t
        if t in (1000,5000,20000,60000): fl.append(f/f0)
    print(kind,wd,'hit',hit.tolist())
    for tt,ff in zip((1000,5000,20000,60000),fl): print('  t=%d f/f0='%tt, ' '.join('%.1e'%v for v in ff))
