# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 emit_s2a.py    依赖：仅标准库
import json, math
d = json.load(open('s2a_results.json'))
def sci(x, nd=1):
    if x == 0: return '0'
    e = int(math.floor(math.log10(abs(x)))); m = x / 10 ** e
    s = ('%.' + str(nd) + 'f') % m
    if float(s) >= 10: s = ('%.' + str(nd) + 'f') % (m / 10); e += 1
    return '$%s\\times10^{%d}$' % (s, e)
def fm(x):
    if x < 1e-3: return sci(x)
    if x >= 0.1: return '%.3f' % x
    return '%.4f' % x if x < 0.01 else '%.3f' % x
print('--- Table A: correct implementation')
nm = {'tanh': 'tanh', 'sigmoid': 'sigmoid', 'silu': 'SiLU', 'relu': 'ReLU'}
print('| 激活 | $L=2$（81 个参数） | $L=3$（153 个） | $L=5$（297 个） |')
print('|:--|--:|--:|--:|')
for r in d['correct']:
    print('| %s | %s | %s | %s |' % (nm[r['act']], sci(r['L2']), sci(r['L3']), sci(r['L5'])))
print('all:', min(min(r['L2'], r['L3'], r['L5']) for r in d['correct']), max(max(r['L2'], r['L3'], r['L5']) for r in d['correct']))
print('--- Table B: eps sweep')
s32 = dict((e, v) for e, v in d['sweep32'])
print('| $\\epsilon$ | float64 | float32 |')
for e, v in d['sweep64']:
    print('| $10^{%d}$ | %s | %s |' % (round(math.log10(e)), sci(v), sci(s32[e]) if e in s32 else '—'))
print('--- Table C: bugs')
names = ['correct', 'forgot 1/B', 'W instead of W^T', "sigma'(a) instead of sigma'(z)", "sigma' at next layer z"]
for nmx in names:
    row = []
    for act in ('tanh', 'sigmoid', 'relu'):
        b = d['bugs'][act][nmx]
        row.append('%s / %s' % (fm(b['total']), fm(b['per'][0])))
    print(nmx, '|', ' | '.join(row))
print('B sweep', d['nomean_B'])
print('relu kink', d['relu_kink'])
# per-layer for the transposed bug (tanh)
for act in ('tanh', 'sigmoid', 'relu'):
    print(act, 'transposed per-tensor', ['%.2e' % e for e in d['bugs'][act]['W instead of W^T']['per']])
