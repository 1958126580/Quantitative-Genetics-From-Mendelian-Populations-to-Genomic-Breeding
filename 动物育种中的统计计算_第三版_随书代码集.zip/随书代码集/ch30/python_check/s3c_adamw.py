# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3c_adamw.py    依赖：numpy
"""Section 30.3.7: L2 penalty vs decoupled weight decay under Adam.  Seeds 30351 (data), 30352+run (batches)."""
import json, sys
import numpy as np
from opt import Opt
out = {}
# ------------------------------------------------ (A) pure-penalty limit: one parameter, no data gradient
print('== A: pure penalty, theta0=1, eta=1e-3, T=500 ==')
A = {}
for lam in (0.1, 1.0, 10.0):
    row = {}
    for name, kind in (('SGD+L2', 'sgd'), ('Adam+L2', 'adam'), ('AdamW', 'adamw')):
        th = np.array([1.0])
        o = Opt(kind, 1e-3, wd=lam if kind == 'adamw' else 0.0)
        for t in range(500):
            g = lam * th if kind != 'adamw' else np.zeros(1)
            th = o.step(th, g)
        row[name] = float(th[0])
    A[str(lam)] = row
    print('lambda=%-5g  SGD+L2 %.4f  Adam+L2 %.4f  AdamW %.4f   (theory: SGD+L2 (1-eta*lam)^T = %.4f; AdamW (1-eta*lam)^T = %.4f; Adam+L2 ~ 1-eta*T = 0.5)' % (
        lam, row['SGD+L2'], row['Adam+L2'], row['AdamW'], (1 - 1e-3 * lam) ** 500, (1 - 1e-3 * lam) ** 500))
out['A'] = A
# ------------------------------------------------ (B) linear regression with two feature scales, minibatch noise
rng = np.random.default_rng(30351)
n, p = 2000, 20
scales = np.r_[np.ones(10), 10 * np.ones(10)]
X = rng.standard_normal((n, p)) * scales
wstar = rng.standard_normal(p) / scales
y = X @ wstar + 3.0 * rng.standard_normal(n)
S = X.T @ X / n
w_ols = np.linalg.solve(S, X.T @ y / n)
lam = 0.5
w_ridge = np.linalg.solve(S + lam * np.eye(p), X.T @ y / n)
def grp(w): return np.linalg.norm(w[:10]), np.linalg.norm(w[10:])
go, gl = grp(w_ols)
def summ(w, name):
    a, b = grp(w)
    return dict(name=name, dist=float(np.linalg.norm(w - w_ridge) / np.linalg.norm(w_ridge)), shrink_S=a / go, shrink_L=b / gl,
                dist_ols=float(np.linalg.norm(w - w_ols) / np.linalg.norm(w_ols)))
rows = [summ(w_ols, 'OLS'), summ(w_ridge, 'ridge lambda=0.5 (exact)')]
print('== B: n=%d p=%d, scales 1 and 10, sigma=3, ridge lambda=%.2f ==' % (n, p, lam))
def train(kind, eta, wd=0.0, l2=0.0, T=60000, B=50, seed=0, mode='mini'):
    r = np.random.default_rng(30352 + seed)
    w = np.zeros(p)
    o = Opt(kind, eta, wd=wd)
    avg = np.zeros(p); cnt = 0
    for t in range(1, T + 1):
        if mode == 'mini':
            idx = r.integers(0, n, B)
            xb, yb = X[idx], y[idx]
            g = xb.T @ (xb @ w - yb) / B + l2 * w
        else:
            g = X.T @ (X @ w - y) / n + l2 * w
        w = o.step(w, g)
        if t > 0.9 * T:
            avg += w; cnt += 1
    return avg / cnt
res = {}
for mode in ('mini', 'full'):
    cfgs = [('SGD + L2(0.5), eta=0.005', dict(kind='sgd', eta=0.005, l2=lam)),
            ('Adam + L2(0.5), eta=1e-3', dict(kind='adam', eta=1e-3, l2=lam)),
            ('Adam + L2(0.5), eta=1e-2', dict(kind='adam', eta=1e-2, l2=lam)),
            ('AdamW wd=0.5, eta=1e-3', dict(kind='adamw', eta=1e-3, wd=0.5)),
            ('AdamW wd=0.5, eta=1e-2', dict(kind='adamw', eta=1e-2, wd=0.5)),
            ('AdamW wd=5, eta=1e-3', dict(kind='adamw', eta=1e-3, wd=5.0)),
            ('AdamW wd=50, eta=1e-3', dict(kind='adamw', eta=1e-3, wd=50.0))]
    res[mode] = []
    for name, kw in cfgs:
        w = train(mode=mode, T=60000 if mode == 'mini' else 20000, **kw)
        sm = summ(w, name)
        res[mode].append(sm)
        print('%-5s %-28s dist to ridge %.4f  shrink S %.3f  shrink L %.3f   dist to OLS %.3f' % (mode, name, sm['dist'], sm['shrink_S'], sm['shrink_L'], sm['dist_ols']))
        sys.stdout.flush()
for r in rows: print('%-28s dist to ridge %.4f  shrink S %.3f  shrink L %.3f  dist to OLS %.3f' % (r['name'], r['dist'], r['shrink_S'], r['shrink_L'], r['dist_ols']))
out['rows'] = rows; out['res'] = res
# best ridge lambda matching AdamW(wd=0.5) solution (what penalty does AdamW implicitly impose?)
w = train('adamw', 1e-3, wd=0.5, T=60000)
best = (np.inf, None)
for l in np.logspace(-3, 3, 3000):
    wr = np.linalg.solve(S + l * np.eye(p), X.T @ y / n)
    dd = np.linalg.norm(wr - w) / np.linalg.norm(w)
    if dd < best[0]: best = (dd, l)
print('AdamW(wd=0.5): best isotropic ridge lambda=%.4f, distance %.4f' % (best[1], best[0]))
out['adamw_best_iso'] = dict(lam=float(best[1]), dist=float(best[0]))
json.dump(out, open('s3c_adamw.json', 'w'), indent=1)
