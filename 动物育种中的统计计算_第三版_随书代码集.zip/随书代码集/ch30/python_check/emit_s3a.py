# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 emit_s3a.py    依赖：numpy
import json, numpy as np
d = json.load(open('s3a_es.json'))
eta = 0.1 / 1741.8946  # placeholder, recomputed below
# recompute eta exactly from lam and t: lam = 1/(eta t)
rows = d['eta=0.1/d1^2']['rows']
eta = 1.0 / (rows[0]['lam'] * rows[0]['t'])
print('eta = %.4e   d1^2 = %.4f' % (eta, 0.1 / eta))
sel = [1, 5, 20, 50, 100, 500, 2000, 10000, 50000]
print('| $t$ | $\\lambda=1/(\\eta t)$ | df（早停） | df（岭回归，$\\lambda=1/(\\eta t)$） | $r(\\hat{\\mathbf y}_{\\text{早停}},\\hat{\\mathbf y}_{\\text{岭}})$ | 测试 $r$（早停） | 测试 $r$（岭） | 风险比 |')
print('|--:|--:|--:|--:|--:|--:|--:|--:|')
for r in rows:
    if r['t'] in sel:
        print('| %d | %.1f | %.1f | %.1f | %.4f | %.4f | %.4f | %.3f |' % (r['t'], r['lam'], r['df_gd'], r['df_ridge'], r['cor_pred'], r['r_gd'], r['r_ridge'], r['ratio']))
print()
print('all rows: max |r_gd - r_rr| = %.4f at t=%d' % max((abs(r['r_gd'] - r['r_ridge']), r['t']) for r in rows))
print('min cor_pred = %.4f at t=%d ; max ratio = %.3f at t=%d ; min ratio %.3f' % (min((r['cor_pred'], r['t']) for r in rows) + max((r['ratio'], r['t']) for r in rows) + (min(r['ratio'] for r in rows),)))
print('lam_df/lam:', [(r['t'], round(r['lam_df'] / r['lam'], 3)) for r in rows if r['t'] in sel])
print('opt', d['eta=0.1/d1^2']['opt'])
print('worst filter ratio (eta=0.1/d1^2): %.4f sq %.4f ; (eta=1/d1^2): %.4f sq %.4f' % (d['eta=0.1/d1^2']['worst_filter_ratio'], d['eta=0.1/d1^2']['worst_filter_ratio_sq'], d['eta=1/d1^2']['worst_filter_ratio'], d['eta=1/d1^2']['worst_filter_ratio_sq']))
print('opt eta=1/d1^2', d['eta=1/d1^2']['opt'])
print('cont', d['cont'], 'ex10', d['ex10'])
print('closed-form maxdiff', d['eta=1/d1^2']['maxdiff'], d['eta=0.1/d1^2']['maxdiff'])
r1 = d['eta=1/d1^2']['rows'][0]; print('t=1,eta=1/d1^2: df_gd %.2f df_rr %.2f cor %.4f r_gd %.4f r_rr %.4f ratio %.3f' % (r1['df_gd'], r1['df_ridge'], r1['cor_pred'], r1['r_gd'], r1['r_ridge'], r1['ratio']))
