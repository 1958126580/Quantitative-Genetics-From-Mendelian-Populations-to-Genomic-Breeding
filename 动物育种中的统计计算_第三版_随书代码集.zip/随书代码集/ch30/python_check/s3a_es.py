# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3a_es.py    依赖：scipy
"""Section 30.3.5: early stopping vs ridge in a linear model (n=400 < m=500), seed 30311.
Loss 1/2||y-Xb||^2, GD from b=0 with step eta; ridge with lambda=1/(eta t)."""
import json
from gsim import *
M, N = 500, 400
pop = Pop(30311, m=M, nq=100, va=0.40)
G, g, ga, y = pop.draw(N)
Gt, gt, gat, yt = pop.draw(4000)
X, Xt = standardise(G, Gt)
alpha = np.zeros(M); alpha[pop.qtl] = pop.alpha            # true effects on the standardised scale
Xc = X - X.mean(0); yc = y - y.mean()
U, d, Vt = np.linalg.svd(Xc, full_matrices=False)
r0 = int(np.sum(d > 1e-8 * d[0])); U, d, Vt = U[:, :r0], d[:r0], Vt[:r0]
d2 = d ** 2
print('singular values: d1^2=%.1f  d_n^2=%.2f  (n=%d, m=%d, rank=%d)' % (d2[0], d2[-1], N, M, len(d)))
sig2 = 1 - 0.40
Uty = U.T @ yc
valpha = Vt @ alpha                                         # coordinates of true effects in the row space
null_part = float(alpha @ alpha - valpha @ valpha)          # common irreducible part
def risk(filt):
    # exact expected ||b_hat - alpha||^2 over noise (sigma^2 = 0.6): bias^2 + variance
    return float(np.sum((1 - filt) ** 2 * valpha ** 2) + null_part + sig2 * np.sum(filt ** 2 / d2))
def corr_test(filt):
    b = Vt.T @ (filt / d * Uty)
    return corr(Xt @ b, gt), b
def df_gd(t, eta): return float(np.sum(1 - (1 - eta * d2) ** t))
def df_ridge(lam): return float(np.sum(d2 / (d2 + lam)))
out = {}
TS = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000]
for tag, eta in (('eta=1/d1^2', 1.0 / d2[0]), ('eta=0.1/d1^2', 0.1 / d2[0])):
    rows = []
    # sanity: actual GD iterates vs closed form (30.43)
    b = np.zeros(M); tt = 0
    maxdiff = 0.0
    for t in TS:
        if t > 5000: break
        while tt < t:
            b = b - eta * (Xc.T @ (Xc @ b - yc)); tt += 1
        fgd = 1 - (1 - eta * d2) ** t
        b_cf = Vt.T @ (fgd / d * Uty)
        maxdiff = max(maxdiff, np.linalg.norm(b - b_cf) / np.linalg.norm(b_cf))
    print(tag, 'closed form vs actual GD iterates (t<=5000): max rel diff = %.2e' % maxdiff)
    for t in TS:
        fgd = 1 - (1 - eta * d2) ** t
        lam = 1.0 / (eta * t)
        frd = d2 / (d2 + lam)
        r_gd, b_gd = corr_test(fgd)
        r_rd, b_rd = corr_test(frd)
        p_gd = Xt @ b_gd; p_rd = Xt @ b_rd
        # lambda that matches the df of GD at step t
        from scipy.optimize import brentq
        dfg = df_gd(t, eta)
        lam_df = brentq(lambda l: df_ridge(l) - dfg, 1e-8, 1e12) if 0.01 < dfg < len(d) - 0.01 else float('nan')
        rows.append(dict(t=t, lam=lam, df_gd=dfg, df_ridge=df_ridge(lam), lam_df=lam_df,
                         cor_pred=corr(p_gd, p_rd), r_gd=r_gd, r_ridge=r_rd,
                         reldist=float(np.linalg.norm(b_gd - b_rd) / np.linalg.norm(b_rd)),
                         risk_gd=risk(fgd), risk_ridge=risk(frd), ratio=risk(fgd) / risk(frd)))
    out[tag] = dict(rows=rows, maxdiff=float(maxdiff))
    print(tag)
    for r in rows:
        print('t=%-6d lam=%-10.2f df_gd=%7.2f df_rr=%7.2f lam_df/lam=%6.3f cor=%.4f r_gd=%.4f r_rr=%.4f reldist=%.3f risk_gd=%.4f risk_rr=%.4f ratio=%.3f' % (
            r['t'], r['lam'], r['df_gd'], r['df_ridge'], r['lam_df'] / r['lam'], r['cor_pred'], r['r_gd'], r['r_ridge'], r['reldist'], r['risk_gd'], r['risk_ridge'], r['ratio']))
    # optimum
    tg = np.unique(np.round(np.logspace(0, 5, 400)).astype(int))
    rg = [risk(1 - (1 - eta * d2) ** t) for t in tg]
    ib = int(np.argmin(rg)); tstar = int(tg[ib])
    lg = np.logspace(-3, 6, 600)
    rr = [risk(d2 / (d2 + l)) for l in lg]
    jb = int(np.argmin(rr)); lstar = float(lg[jb])
    print('  risk-optimal t*=%d (risk %.4f; 1/(eta t*)=%.1f)   ridge lambda*=%.1f (risk %.4f)  ratio=%.4f' % (tstar, rg[ib], 1 / (eta * tstar), lstar, rr[jb], rg[ib] / rr[jb]))
    fgd_s = 1 - (1 - eta * d2) ** tstar; frd_s = d2 / (d2 + lstar)
    print('  test r at optimum: GD %.4f  ridge %.4f ; df GD %.1f ridge %.1f' % (corr_test(fgd_s)[0], corr_test(frd_s)[0], df_gd(tstar, eta), df_ridge(lstar)))
    out[tag]['opt'] = dict(tstar=tstar, lam_from_t=1 / (eta * tstar), lstar=lstar, risk_gd=rg[ib], risk_ridge=rr[jb],
                           r_gd=corr_test(fgd_s)[0], r_ridge=corr_test(frd_s)[0], df_gd=df_gd(tstar, eta), df_ridge=df_ridge(lstar))
    # worst-case variance-factor ratio over the singular values and t grid
    worst = 0.0
    for t in TS:
        fg = 1 - (1 - eta * d2) ** t; fr = d2 / (d2 + 1.0 / (eta * t))
        worst = max(worst, float(np.max(fg / fr)))
    out[tag]['worst_filter_ratio'] = worst
    out[tag]['worst_filter_ratio_sq'] = worst ** 2
    print('  max over t,k of f_gd/f_ridge = %.4f  (squared %.4f)' % (worst, worst ** 2))
# continuous-time constant
x = np.logspace(-6, 4, 2000001)
f = (1 - np.exp(-x)) * (1 + x) / x
i = int(np.argmax(f))
print('continuous-time: max_x (1-e^-x)(1+x)/x = %.5f at x=%.3f ; squared = %.5f' % (f[i], x[i], f[i] ** 2))
out['cont'] = dict(fmax=float(f[i]), xmax=float(x[i]), sq=float(f[i] ** 2))
# single singular value example (exercise 10): d^2=1, eta=0.01
for t in (69, 100):
    print('d2=1 eta=0.01 t=%d  GD factor=%.4f  (ridge lambda=1: 0.5000)' % (t, 1 - 0.99 ** t))
out['ex10'] = dict(f69=1 - 0.99 ** 69, f100=1 - 0.99 ** 100, t_half=float(np.log(2) / -np.log(0.99)))
print('t_half = %.3f' % out['ex10']['t_half'])
json.dump(out, open('s3a_es.json', 'w'), indent=1)
