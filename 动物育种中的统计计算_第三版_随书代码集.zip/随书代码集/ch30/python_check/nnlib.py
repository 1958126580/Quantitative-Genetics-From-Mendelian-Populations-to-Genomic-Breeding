# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 nnlib.py    依赖：numpy
"""Generic L-layer MLP in numpy (rows = samples) with explicit forward/backward, bug injection for the
gradient-check experiments, and parameter flatten helpers."""
import os
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


def act_fn(name, z):
    if name == 'tanh':
        return np.tanh(z)
    if name == 'sigmoid':
        return sigmoid(z)
    if name == 'relu':
        return np.maximum(z, 0.0)
    if name == 'silu':
        return z * sigmoid(z)
    if name == 'identity':
        return z
    raise ValueError(name)


def act_grad(name, z):
    """sigma'(z): derivative *as a function of its argument* z."""
    if name == 'tanh':
        t = np.tanh(z)
        return 1.0 - t * t
    if name == 'sigmoid':
        s = sigmoid(z)
        return s * (1.0 - s)
    if name == 'relu':
        return (z > 0).astype(z.dtype)
    if name == 'silu':
        s = sigmoid(z)
        return s * (1.0 + z * (1.0 - s))
    if name == 'identity':
        return np.ones_like(z)
    raise ValueError(name)


def init_params(dims, rng, scheme='he', act='relu', dtype=np.float64):
    """dims=[p,h1,...,1]; weights stored as (in, out)."""
    P = []
    for l in range(len(dims) - 1):
        nin, nout = dims[l], dims[l + 1]
        if scheme == 'he':
            s = np.sqrt(2.0 / nin)
        elif scheme == 'xavier':
            s = np.sqrt(2.0 / (nin + nout))
        elif scheme == 'lecun':
            s = np.sqrt(1.0 / nin)
        else:
            s = float(scheme)
        W = (rng.standard_normal((nin, nout)) * s).astype(dtype)
        b = (0.1 * rng.standard_normal(nout)).astype(dtype)
        P.append([W, b])
    return P


def forward(P, X, act):
    Z, A = [], [X]
    a = X
    L = len(P)
    for l, (W, b) in enumerate(P):
        z = a @ W + b
        Z.append(z)
        a = act_fn(act, z) if l < L - 1 else z
        A.append(a)
    return Z, A


def loss_fn(P, X, y, act, l2=0.0):
    Z, A = forward(P, X, act)
    r = A[-1][:, 0] - y
    L = 0.5 * np.mean(r * r)
    if l2:
        L += 0.5 * l2 * sum(np.sum(W * W) for W, b in P)
    return L


def backward(P, X, y, act, l2=0.0, bug=None):
    """Analytic gradient of loss_fn.  bug in {None,'nomean','transpose','deriv_a','deriv_off'}."""
    Z, A = forward(P, X, act)
    B = X.shape[0]
    L = len(P)
    d = (A[-1][:, 0] - y)[:, None]
    if bug != 'nomean':
        d = d / B
    grads = [None] * L
    delta = d
    for l in range(L - 1, -1, -1):
        W, b = P[l]
        gW = A[l].T @ delta
        if l2:
            gW = gW + l2 * W
        gb = delta.sum(0)
        grads[l] = [gW, gb]
        if l > 0:
            Wm = W
            if bug == 'transpose' and W.shape[0] == W.shape[1]:
                back = delta @ Wm            # should be delta @ Wm.T  (silent when W is square)
            else:
                back = delta @ Wm.T
            if bug == 'deriv_a':
                sp = act_grad(act, A[l])      # derivative evaluated at the activation, not at z
            elif bug == 'deriv_off':
                sp = act_grad(act, Z[l])      # off-by-one layer index: sigma' taken at the *next* layer's z
            else:
                sp = act_grad(act, Z[l - 1])
            delta = back * sp
    return grads


def flat(grads):
    return np.concatenate([np.concatenate([g[0].ravel(), g[1].ravel()]) for g in grads])


def flat_params(P):
    return np.concatenate([np.concatenate([W.ravel(), b.ravel()]) for W, b in P])


def set_flat(P, v):
    k = 0
    for W, b in P:
        W[...] = v[k:k + W.size].reshape(W.shape); k += W.size
        b[...] = v[k:k + b.size]; k += b.size


def numeric_grad(P, X, y, act, eps, l2=0.0):
    v = flat_params(P).copy()
    g = np.zeros_like(v)
    for i in range(v.size):
        old = v[i]
        v[i] = old + eps; set_flat(P, v); lp = loss_fn(P, X, y, act, l2)
        v[i] = old - eps; set_flat(P, v); lm = loss_fn(P, X, y, act, l2)
        v[i] = old
        g[i] = (lp - lm) / (2 * eps)
    set_flat(P, v)
    return g


def rel_err(a, b):
    return float(np.linalg.norm(a - b) / (np.linalg.norm(a) + np.linalg.norm(b)))


def layer_slices(P):
    sl = []
    k = 0
    for W, b in P:
        sl.append(('W', slice(k, k + W.size)))
        k += W.size
        sl.append(('b', slice(k, k + b.size)))
        k += b.size
    return sl
