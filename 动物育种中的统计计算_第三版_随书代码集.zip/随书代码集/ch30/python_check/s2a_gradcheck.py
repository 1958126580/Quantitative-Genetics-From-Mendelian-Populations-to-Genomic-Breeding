# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s2a_gradcheck.py    依赖：仅标准库
"""Section 30.2.7: gradient check of hand-written backprop; correct implementation and three typical bugs."""
import json
from nnlib import *

out = {}
rng = np.random.default_rng(30201)

def make(dims, B, act, dtype=np.float64, seed=30201):
    r = np.random.default_rng(seed)
    P = init_params(dims, r, 'lecun', act, dtype)
    X = r.standard_normal((B, dims[0])).astype(dtype)
    y = r.standard_normal(B).astype(dtype)
    return P, X, y

# ---------- (1) correct implementation: activation x depth, eps=1e-6, float64
print('== correct implementation (float64, eps=1e-6, B=16, widths 8) ==')
tab = []
for act in ['tanh', 'sigmoid', 'silu', 'relu']:
    row = {'act': act}
    for L in (2, 3, 5):
        dims = [8] + [8] * (L - 1) + [1]
        P, X, y = make(dims, 16, act)
        ga = flat(backward(P, X, y, act))
        gn = numeric_grad(P, X, y, act, 1e-6)
        row['L%d' % L] = rel_err(ga, gn)
        row['np%d' % L] = int(ga.size)
    tab.append(row)
    print(row)
out['correct'] = tab

# ---------- (2) epsilon sweep (tanh, [8,6,6,1]) float64 and float32
print('== eps sweep ==')
dims = [8, 6, 6, 1]
sweep = []
for eps in [1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10, 1e-12]:
    P, X, y = make(dims, 16, 'tanh')
    ga = flat(backward(P, X, y, 'tanh'))
    gn = numeric_grad(P, X, y, 'tanh', eps)
    sweep.append((eps, rel_err(ga, gn)))
    print('f64 eps=%g  rel=%.3e' % (eps, sweep[-1][1]))
out['sweep64'] = sweep
sweep32 = []
for eps in [1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6]:
    P, X, y = make(dims, 16, 'tanh', np.float32)
    ga = flat(backward(P, X, y, 'tanh')).astype(np.float64)
    # numeric gradient in float32 arithmetic
    v = flat_params(P).copy(); g = np.zeros(v.size)
    for i in range(v.size):
        old = v[i]
        v[i] = np.float32(old + np.float32(eps)); set_flat(P, v); lp = loss_fn(P, X, y, 'tanh')
        v[i] = np.float32(old - np.float32(eps)); set_flat(P, v); lm = loss_fn(P, X, y, 'tanh')
        v[i] = old
        g[i] = (float(lp) - float(lm)) / (2 * eps)
    set_flat(P, v)
    sweep32.append((eps, rel_err(ga, g)))
    print('f32 eps=%g  rel=%.3e' % (eps, sweep32[-1][1]))
out['sweep32'] = sweep32

# ---------- (3) three bugs, tanh, dims [8,6,6,1], B=16 (and B=1 for the 1/n bug)
print('== bugs ==')
bugs = [(None, 'correct'), ('nomean', 'forgot 1/B'), ('transpose', 'W instead of W^T'),
        ('deriv_a', "sigma'(a) instead of sigma'(z)"), ('deriv_off', "sigma' at next layer z")]
res = {}
for act in ['tanh', 'sigmoid', 'relu']:
    res[act] = {}
    for bug, nm in bugs:
        P, X, y = make(dims, 16, act)
        ga = flat(backward(P, X, y, act, bug=bug))
        gn = numeric_grad(P, X, y, act, 1e-6)
        sl = layer_slices(P)
        per = [rel_err(ga[s], gn[s]) for kind, s in sl]
        res[act][nm] = dict(total=rel_err(ga, gn), per=per, ratio=float(np.linalg.norm(ga) / np.linalg.norm(gn)))
        print(act, '%-30s total=%.3e ratio=%.3f per=%s' % (nm, res[act][nm]['total'], res[act][nm]['ratio'],
                                                        ' '.join('%.1e' % e for e in per)))
out['bugs'] = res
# B=1 for the 1/B bug
b1 = {}
for B in (1, 2, 4, 16, 64, 256):
    P, X, y = make(dims, B, 'tanh')
    ga = flat(backward(P, X, y, 'tanh', bug='nomean'))
    gn = numeric_grad(P, X, y, 'tanh', 1e-6)
    b1[B] = rel_err(ga, gn)
    print('B=%d nomean total=%.3e (theory (B-1)/(B+1)=%.3e)' % (B, b1[B], (B - 1) / (B + 1)))
out['nomean_B'] = b1

# ---------- (4) ReLU kinks: eps large
print('== relu kink ==')
kink = []
for eps in [1e-6, 1e-4, 1e-3, 1e-2, 1e-1]:
    errs = []
    for sd in range(20):
        P, X, y = make([8, 8, 8, 1], 16, 'relu', seed=500 + sd)
        ga = flat(backward(P, X, y, 'relu'))
        gn = numeric_grad(P, X, y, 'relu', eps)
        errs.append(rel_err(ga, gn))
    kink.append((eps, float(np.median(errs)), float(np.max(errs))))
    print('relu eps=%g median=%.2e max=%.2e' % kink[-1])
out['relu_kink'] = kink
json.dump(out, open('s2a_results.json', 'w'), indent=1)
