# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4a_params.py    依赖：numpy
"""Section 30.4.6: parameter counts / multiply-adds / largest activation for SNP models, m = 1e4 and 1e5.
Parameters are counted from actually allocated arrays (np.zeros) for every layer."""
import json
import numpy as np

def conv_len(L, k, s, pad=0):
    return (L + 2 * pad - k) // s + 1

def build(arch, m):
    """returns list of (name, param_arrays_shapes, macs, out_activation_size)"""
    layers = []
    if arch == 'FC64':
        layers = [('dense m->64', [(m, 64), (64,)], m * 64, 64), ('dense 64->1', [(64, 1), (1,)], 64, 1)]
    elif arch == 'FC256-64':
        layers = [('dense m->256', [(m, 256), (256,)], m * 256, 256), ('dense 256->64', [(256, 64), (64,)], 256 * 64, 64),
                  ('dense 64->1', [(64, 1), (1,)], 64, 1)]
    elif arch == 'conv_k9s1_C16_flat1':
        k, s, C = 9, 1, 16
        Lo = conv_len(m, k, s)
        layers = [('conv k9 s1 C16', [(k, 1, C), (C,)], Lo * k * 1 * C, Lo * C), ('flatten->1', [(Lo * C, 1), (1,)], Lo * C, 1)]
    elif arch == 'conv_k9s1_C16_flat64':
        k, s, C = 9, 1, 16
        Lo = conv_len(m, k, s)
        layers = [('conv k9 s1 C16', [(k, 1, C), (C,)], Lo * k * 1 * C, Lo * C), ('flatten->64', [(Lo * C, 64), (64,)], Lo * C * 64, 64),
                  ('dense 64->1', [(64, 1), (1,)], 64, 1)]
    elif arch == 'conv_k9s9_C16_flat64':
        k, s, C = 9, 9, 16
        Lo = conv_len(m, k, s)
        layers = [('conv k9 s9 C16', [(k, 1, C), (C,)], Lo * k * 1 * C, Lo * C), ('flatten->64', [(Lo * C, 64), (64,)], Lo * C * 64, 64),
                  ('dense 64->1', [(64, 1), (1,)], 64, 1)]
    elif arch == 'convpool3_flat64':
        # 3 x [conv k9 s1 'same' + maxpool 4], channels 16/32/64, then flatten -> 64 -> 1
        L = m; cin = 1; layers = []
        for C in (16, 32, 64):
            layers.append(('conv k9 same C%d' % C, [(9, cin, C), (C,)], L * 9 * cin * C, L * C))
            L = L // 4
            cin = C
        layers += [('flatten->64', [(L * cin, 64), (64,)], L * cin * 64, 64), ('dense 64->1', [(64, 1), (1,)], 64, 1)]
    elif arch == 'conv_gap':
        k, s, C = 9, 1, 16
        Lo = conv_len(m, k, s)
        layers = [('conv k9 s1 C16', [(k, 1, C), (C,)], Lo * k * C, Lo * C), ('GAP->1', [(C, 1), (1,)], C, 1)]
    return layers

ARCHS = [('FC64', '全连接 $m\\to64\\to1$'), ('FC256-64', '全连接 $m\\to256\\to64\\to1$'),
         ('conv_k9s1_C16_flat1', '卷积（$k=9$，$s=1$，16 通道）→展平→线性'),
         ('conv_k9s9_C16_flat64', '卷积（$k=9$，$s=9$，16 通道）→展平→64→1'),
         ('convpool3_flat64', '3 级卷积+池化（16/32/64 通道，池化 4）→展平→64→1'),
         ('conv_gap', '卷积（$k=9$，16 通道）→全局平均池化→1')]
res = {}
for m in (10_000, 100_000):
    res[m] = {}
    for key, label in ARCHS:
        ls = build(key, m)
        # count parameters from really allocated arrays
        total = 0
        for name, shapes, macs, act in ls:
            for sh in shapes:
                total += np.zeros(sh, dtype=np.float32).size
        macs = sum(l[2] for l in ls)
        peak = max(l[3] for l in ls)
        res[m][key] = dict(params=int(total), macs=int(macs), peak_act=int(peak), layers=[(l[0], [list(s) for s in l[1]]) for l in ls])
        print('m=%-7d %-24s params=%-12d  MACs/sample=%-12d  largest activation=%d' % (m, key, total, macs, peak))
# one-hot (3 channels) variant of the conv input: only the first conv changes
print('conv first layer with 3 input channels (one-hot genotype): params k*3*C+C =', 9 * 3 * 16 + 16)
# validate one conv forward shape with numpy for m=10000 (stride tricks)
m = 10000
x = np.random.default_rng(1).standard_normal(m).astype(np.float32)
for k, s in ((9, 1), (9, 9)):
    from numpy.lib.stride_tricks import sliding_window_view
    win = sliding_window_view(x, k)[::s]
    W = np.random.default_rng(2).standard_normal((k, 16)).astype(np.float32)
    z = win @ W
    print('conv k=%d s=%d: output length %d (formula %d), output shape %s' % (k, s, z.shape[0], conv_len(m, k, s), z.shape))
json.dump({str(k): v for k, v in res.items()}, open('s4a_params.json', 'w'), indent=1)
# receptive field / "how many SNPs does one output see" for the 3-level stack: k=9, pools 4
rf = 1; jump = 1
for k in (9, 9, 9):
    rf = rf + (k - 1) * jump
    jump *= 4
print('receptive field of the 3rd conv (before pooling 3rd): %d SNPs' % rf)
