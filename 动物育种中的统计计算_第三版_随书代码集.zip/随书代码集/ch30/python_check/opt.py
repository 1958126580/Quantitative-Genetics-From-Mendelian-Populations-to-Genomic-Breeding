# -*- coding: utf-8 -*-
"""Hand-written optimizers (SGD, momentum, Nesterov, RMSprop, Adam, AdamW) acting on flat arrays.
`lr` may be an array broadcastable against theta (used to run a whole learning-rate grid at once)."""
import os
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import numpy as np


class Opt:
    def __init__(self, kind, lr, mu=0.9, rho=0.9, b1=0.9, b2=0.999, eps=1e-8, wd=0.0):
        self.kind, self.lr, self.mu, self.rho = kind, lr, mu, rho
        self.b1, self.b2, self.eps, self.wd = b1, b2, eps, wd
        self.t = 0
        self.v = None
        self.m = None

    def lookahead(self, theta):
        if self.kind == 'nesterov' and self.v is not None:
            return theta - self.lr * self.mu * self.v
        return theta

    def step(self, theta, g):
        k = self.kind
        self.t += 1
        if k == 'sgd':
            theta -= self.lr * g
        elif k in ('momentum', 'nesterov'):
            if self.v is None:
                self.v = np.zeros_like(theta)
            self.v *= self.mu
            self.v += g
            theta -= self.lr * self.v
        elif k == 'rmsprop':
            if self.v is None:
                self.v = np.zeros_like(theta)
            self.v *= self.rho
            self.v += (1 - self.rho) * g * g
            theta -= self.lr * g / (np.sqrt(self.v) + self.eps)
        elif k in ('adam', 'adamw'):
            if self.v is None:
                self.v = np.zeros_like(theta)
                self.m = np.zeros_like(theta)
            self.m *= self.b1
            self.m += (1 - self.b1) * g
            self.v *= self.b2
            self.v += (1 - self.b2) * g * g
            mh = self.m / (1 - self.b1 ** self.t)
            vh = self.v / (1 - self.b2 ** self.t)
            upd = mh / (np.sqrt(vh) + self.eps)
            if k == 'adamw':
                upd = upd + self.wd * theta
            theta -= self.lr * upd
        else:
            raise ValueError(k)
        return theta
