# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s3c2_adamw_diag.py    依赖：numpy
"""Diagnostics for 30.3.7: second-moment scale per group and normalised-update magnitude. Same data as s3c (seed 30351)."""
import json
import numpy as np
from opt import Opt
rng = np.random.default_rng(30351)
n, p = 2000, 20
scales = np.r_[np.ones(10), 10 * np.ones(10)]
X = rng.standard_normal((n, p)) * scales
wstar = rng.standard_normal(p) / scales
y = X @ wstar + 3.0 * rng.standard_normal(n)
def train(kind, eta, wd=0.0, l2=0.0, T=60000, B=50, seed=0, mode='mini'):
    r = np.random.default_rng(30352 + seed)
    w = np.zeros(p); o = Opt(kind, eta, wd=wd)
    for t in range(1, T + 1):
        if mode == 'mini':
            idx = r.integers(0, n, B); xb, yb = X[idx], y[idx]
            g = xb.T @ (xb @ w - yb) / B + l2 * w
        else:
            g = X.T @ (X @ w - y) / n + l2 * w
        w = o.step(w, g)
    vh = o.v / (1 - o.b2 ** o.t); mh = o.m / (1 - o.b1 ** o.t)
    return w, np.sqrt(vh), mh
out = {}
for mode, T in (('mini', 60000), ('full', 20000)):
    for name, kw in (('Adam+L2', dict(kind='adam', eta=1e-3, l2=0.5)), ('AdamW', dict(kind='adamw', eta=1e-3, wd=0.5))):
        w, sv, mh = train(mode=mode, T=T, **kw)
        ratio = np.abs(mh) / (sv + 1e-8)
        out['%s_%s' % (mode, name)] = dict(sqrtv_S=float(sv[:10].mean()), sqrtv_L=float(sv[10:].mean()),
                                           norm_upd_S=float(ratio[:10].mean()), norm_upd_L=float(ratio[10:].mean()))
        print(mode, name, 'sqrt(v) S %.4f L %.4f (L/S %.2f)   |m|/sqrt(v): S %.4f  L %.4f' % (
            sv[:10].mean(), sv[10:].mean(), sv[10:].mean() / sv[:10].mean(), ratio[:10].mean(), ratio[10:].mean()))
json.dump(out, open('s3c2_diag.json', 'w'), indent=1)
