# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s4b_attn.py    依赖：numpy
"""Section 30.4.6: measured cost of self-attention vs sequence length (numpy, float32, single thread). Seed 30401."""
import os
os.environ['OMP_NUM_THREADS'] = '1'; os.environ['OPENBLAS_NUM_THREADS'] = '1'; os.environ['MKL_NUM_THREADS'] = '1'
import time, json, tracemalloc, sys
import numpy as np
d = 64
D = 512
LS = [256, 512, 1024, 2048, 4096]
rng = np.random.default_rng(30401)

def attn_inplace(Q, K, V):
    S = Q @ K.T
    S *= np.float32(1.0 / np.sqrt(d))
    S -= S.max(axis=1, keepdims=True)
    np.exp(S, out=S)
    S /= S.sum(axis=1, keepdims=True)
    return S @ V

def attn_naive(Q, K, V):
    S = (Q @ K.T) / np.sqrt(d).astype(np.float32)
    E = np.exp(S - S.max(axis=1, keepdims=True))
    P = E / E.sum(axis=1, keepdims=True)
    return P @ V

def best_time(fn, reps):
    ts_w, ts_c = [], []
    for _ in range(reps):
        c0 = time.process_time(); w0 = time.perf_counter()
        fn()
        ts_c.append(time.process_time() - c0); ts_w.append(time.perf_counter() - w0)
    return min(ts_w), min(ts_c)

res = {}
for L in LS:
    Q = rng.standard_normal((L, d)).astype(np.float32); K = rng.standard_normal((L, d)).astype(np.float32); V = rng.standard_normal((L, d)).astype(np.float32)
    X = rng.standard_normal((L, D)).astype(np.float32); W = rng.standard_normal((D, D)).astype(np.float32)
    reps = 15 if L <= 1024 else 7
    attn_inplace(Q, K, V); X @ W                       # warm-up
    tw_a, tc_a = best_time(lambda: attn_inplace(Q, K, V), reps)
    # pieces
    S = Q @ K.T
    tw_qk, tc_qk = best_time(lambda: Q @ K.T, reps)
    def soft():
        S2 = S.copy(); S2 *= np.float32(0.125); S2 -= S2.max(axis=1, keepdims=True); np.exp(S2, out=S2); S2 /= S2.sum(axis=1, keepdims=True)
    tw_sm, tc_sm = best_time(soft, reps)
    tw_d, tc_d = best_time(lambda: X @ W, reps)
    # memory
    tracemalloc.start(); tracemalloc.reset_peak()
    attn_inplace(Q, K, V); pk_in = tracemalloc.get_traced_memory()[1]
    tracemalloc.reset_peak(); attn_naive(Q, K, V); pk_nv = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    res[L] = dict(t_attn_wall=tw_a, t_attn_cpu=tc_a, t_qk_cpu=tc_qk, t_soft_cpu=tc_sm, t_dense_wall=tw_d, t_dense_cpu=tc_d,
                  peak_inplace=pk_in, peak_naive=pk_nv, score_bytes=4 * L * L)
    print('L=%-5d attn %.4fs cpu %.4fs | QK %.4f softmax %.4f | dense(%dx%d) %.5fs cpu %.5fs | peak in-place %.2f MiB naive %.2f MiB  (4L^2=%.2f MiB)' % (
        L, tw_a, tc_a, tc_qk, tc_sm, L, D, tw_d, tc_d, pk_in / 2 ** 20, pk_nv / 2 ** 20, 4 * L * L / 2 ** 20)); sys.stdout.flush()
base = res[LS[0]]
print('\nratios vs L=256 (CPU time)')
for L in LS:
    r = res[L]
    print('L=%-5d attn %.1f (theory %d)   QK %.1f   softmax %.1f   dense %.1f (theory %d)  mem in-place %.2f naive %.2f' % (
        L, r['t_attn_cpu'] / base['t_attn_cpu'], (L // 256) ** 2, r['t_qk_cpu'] / base['t_qk_cpu'], r['t_soft_cpu'] / base['t_soft_cpu'],
        r['t_dense_cpu'] / base['t_dense_cpu'], L // 256, r['peak_inplace'] / base['peak_inplace'], r['peak_naive'] / base['peak_naive']))
# effective throughput
for L in LS:
    r = res[L]
    fl = 4 * L * L * d
    print('L=%d attention matmul flops %.3e ; effective GFLOP/s (matmul part / total attn time) = %.2f ; QK alone %.2f GFLOP/s' % (
        L, fl, fl / r['t_attn_cpu'] / 1e9, 2 * L * L * d / r['t_qk_cpu'] / 1e9))
json.dump({str(k): v for k, v in res.items()}, open('s4b_attn.json', 'w'), indent=1)
