# -*- coding: utf-8 -*-
"""Genomic simulation + ridge (GBLUP-equivalent) + hand-written two-layer MLP (numpy only).
Used by s1_mlp_vs_ridge.py and the optimizer experiments."""
import os
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import numpy as np


# ------------------------------------------------------------------ data
class Pop:
    """One simulated population: m independent SNPs (LE), MAF~U(0.05,0.5), nq additive QTL,
    K epistatic pairs among the QTL.  Genotypes are standardised with the *population* frequencies,
    so that Var(z_j)=1 exactly and products of distinct columns are uncorrelated with everything else."""

    def __init__(self, seed, m=500, nq=100, va=0.40, ve=0.0, K=0):
        rng = np.random.default_rng(seed)
        self.rng = rng
        self.m = m
        self.p = rng.uniform(0.05, 0.5, m)
        self.qtl = rng.choice(m, nq, replace=False)
        a = rng.standard_normal(nq)
        self.alpha = a * np.sqrt(va / np.sum(a ** 2))
        self.K = K
        if K > 0:
            pairs = []
            while len(pairs) < K:
                i, j = rng.choice(self.qtl, 2, replace=False)
                key = (min(i, j), max(i, j))
                if key not in pairs:
                    pairs.append(key)
            self.pairs = np.array(pairs)
            u = rng.standard_normal(K)
            self.u = u * np.sqrt(ve / np.sum(u ** 2))
        self.va, self.ve = va, ve
        self.sig_e = np.sqrt(max(1.0 - va - ve, 1e-12))

    def draw(self, n):
        rng = self.rng
        G = rng.binomial(2, self.p, size=(n, self.m)).astype(np.float64)
        Zs = (G - 2 * self.p) / np.sqrt(2 * self.p * (1 - self.p))
        ga = Zs[:, self.qtl] @ self.alpha
        ge = np.zeros(n)
        if self.K > 0:
            ge = (Zs[:, self.pairs[:, 0]] * Zs[:, self.pairs[:, 1]]) @ self.u
        g = ga + ge
        y = g + self.sig_e * rng.standard_normal(n)
        return G, g, ga, y


def standardise(Gtr, *others):
    mu = Gtr.mean(0)
    sd = Gtr.std(0)
    sd[sd < 1e-8] = 1.0
    out = [(Gtr - mu) / sd] + [(G - mu) / sd for G in others]
    return out


def corr(a, b):
    a = a - a.mean()
    b = b - b.mean()
    return float(a @ b / np.sqrt((a @ a) * (b @ b)))


# ------------------------------------------------------------------ ridge with closed-form LOO
def ridge_loo(X, y, lams):
    """Ridge on centred X,y; lambda chosen by leave-one-out PRESS (closed form, SVD).
    Returns (beta, b0, lam_best, df_best)."""
    xm = X.mean(0)
    ym = y.mean()
    Xc = X - xm
    yc = y - ym
    U, d, Vt = np.linalg.svd(Xc, full_matrices=False)
    Uty = U.T @ yc
    best = (np.inf, None)
    d2 = d ** 2
    U2 = U ** 2
    for lam in lams:
        s = d2 / (d2 + lam)
        fit = U @ (s * Uty)
        h = U2 @ s
        loo = (yc - fit) / (1 - h)
        press = np.mean(loo ** 2)
        if press < best[0]:
            best = (press, lam)
    lam = best[1]
    s = d / (d2 + lam)
    beta = Vt.T @ (s * Uty)
    b0 = ym - xm @ beta
    df = float(np.sum(d2 / (d2 + lam)))
    return beta, b0, lam, df


# ------------------------------------------------------------------ two-layer MLP (m -> h -> 1), rows = samples
def init_mlp(m, h, rng, act='relu'):
    W1 = rng.standard_normal((m, h)) * np.sqrt(2.0 / m if act == 'relu' else 1.0 / m)
    b1 = np.zeros(h)
    w2 = rng.standard_normal(h) * np.sqrt(1.0 / h)
    b2 = np.zeros(1)
    return [W1, b1, w2, b2]


def mlp_predict(params, X, act='relu'):
    W1, b1, w2, b2 = params
    Z1 = X @ W1 + b1
    A1 = np.maximum(Z1, 0.0) if act == 'relu' else np.tanh(Z1)
    return A1 @ w2 + b2[0]


def train_mlp(Xtr, ytr, Xva=None, yva=None, h=32, act='relu', l2=0.1, lr=1e-3, B=64,
              epochs=100, patience=10, seed=0, fixed_epochs=None):
    """Mini-batch Adam on L = 1/(2B) sum (yhat-y)^2 + (l2/2)(||W1||^2+||w2||^2).
    If a validation set is given, early stopping on validation MSE (restore best).
    If fixed_epochs is given, train exactly that many epochs (refit)."""
    rng = np.random.default_rng(seed)
    n, m = Xtr.shape
    P = init_mlp(m, h, rng, act)
    ymu = ytr.mean()
    yt = ytr - ymu
    mom = [np.zeros_like(p) for p in P]
    var = [np.zeros_like(p) for p in P]
    b1c, b2c, eps = 0.9, 0.999, 1e-8
    t = 0
    best = (np.inf, None, 0)
    hist = []
    nep = fixed_epochs if fixed_epochs is not None else epochs
    for ep in range(1, nep + 1):
        perm = rng.permutation(n)
        for s in range(0, n, B):
            idx = perm[s:s + B]
            xb = Xtr[idx]
            yb = yt[idx]
            W1, b1, w2, b2 = P
            Z1 = xb @ W1 + b1
            if act == 'relu':
                A1 = np.maximum(Z1, 0.0)
                D1 = (Z1 > 0).astype(np.float64)
            else:
                A1 = np.tanh(Z1)
                D1 = 1.0 - A1 ** 2
            out = A1 @ w2 + b2[0]
            d = (out - yb) / len(idx)
            g_w2 = A1.T @ d + l2 * w2
            g_b2 = np.array([d.sum()])
            dZ1 = np.outer(d, w2) * D1
            g_W1 = xb.T @ dZ1 + l2 * W1
            g_b1 = dZ1.sum(0)
            G = [g_W1, g_b1, g_w2, g_b2]
            t += 1
            c1 = 1 - b1c ** t
            c2 = 1 - b2c ** t
            for k in range(4):
                mom[k] = b1c * mom[k] + (1 - b1c) * G[k]
                var[k] = b2c * var[k] + (1 - b2c) * G[k] ** 2
                P[k] = P[k] - lr * (mom[k] / c1) / (np.sqrt(var[k] / c2) + eps)
        if Xva is not None and fixed_epochs is None:
            pv = mlp_predict(P, Xva, act) + ymu
            mse = float(np.mean((pv - yva) ** 2))
            hist.append(mse)
            if mse < best[0]:
                best = (mse, [p.copy() for p in P], ep)
            elif ep - best[2] >= patience:
                break
    if fixed_epochs is not None:
        best = (None, P, fixed_epochs)
    P = best[1]
    return P, ymu, best[2], hist


# ------------------------------------------------------------------ GBLUP by REML (ridge with lambda = m * sigma_e^2 / sigma_g^2)
def reml_ridge(X, y):
    """X: n x m standardised (columns centred). Model y = mu + X b + e, b ~ N(0, sg2/m I).
    Profile REML over delta = se2/sg2 (closed form for sg2). Returns beta, b0, lam, df, h2hat."""
    from scipy.optimize import minimize_scalar
    n, m = X.shape
    xm = X.mean(0)
    Xc = X - xm
    ym = y.mean()
    yc = y - ym
    U, d, Vt = np.linalg.svd(Xc, full_matrices=False)
    r = int(np.sum(d > 1e-8 * d[0]))
    U, d, Vt = U[:, :r], d[:r], Vt[:r]
    s = d ** 2 / m
    ys = U.T @ yc
    S0 = max(float(yc @ yc - ys @ ys), 0.0)
    nc = n - 1

    def negll(logdelta):
        delta = np.exp(logdelta)
        q = np.sum(ys ** 2 / (s + delta)) + S0 / delta
        sg2 = q / nc
        return 0.5 * (nc * np.log(sg2) + np.sum(np.log(s + delta)) + (nc - r) * np.log(delta))

    res = minimize_scalar(negll, bounds=(-9.0, 9.0), method='bounded', options=dict(xatol=1e-6))
    delta = float(np.exp(res.x))
    lam = m * delta
    d2 = d ** 2
    beta = Vt.T @ (d / (d2 + lam) * ys)
    b0 = ym - xm @ beta
    df = float(np.sum(d2 / (d2 + lam)))
    q = np.sum(ys ** 2 / (s + delta)) + S0 / delta
    sg2 = q / nc
    h2 = sg2 / (sg2 + delta * sg2)
    return beta, b0, lam, df, h2
