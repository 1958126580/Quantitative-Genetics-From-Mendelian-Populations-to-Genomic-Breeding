# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 pilot1.py    依赖：仅标准库
import time, sys
from gsim import *
lams = np.logspace(-1, 5, 40)
def run(n, va, ve, K, seed, l2s=(0.03,0.1,0.3,1.0), h=32, act='relu', lr=1e-3):
    pop = Pop(seed, m=500, nq=100, va=va, ve=ve, K=K)
    G, g, ga, y = pop.draw(n)
    Gt, gt, gat, yt = pop.draw(2000)
    X, Xt = standardise(G, Gt)
    t0=time.time()
    beta, b0, lam, df = ridge_loo(X, y, lams)
    pr = Xt @ beta + b0
    r_ridge = corr(pr, gt)
    t1=time.time()
    # inner split
    nv = n//5
    rng = np.random.default_rng(seed+99)
    perm = rng.permutation(n)
    iv, itr = perm[:nv], perm[nv:]
    res=[]
    for l2 in l2s:
        P, ymu, ep, hist = train_mlp(X[itr], y[itr], X[iv], y[iv], h=h, act=act, l2=l2, lr=lr, epochs=100, patience=10, seed=seed)
        pv = mlp_predict(P, X[iv], act)+ymu
        res.append((min(hist), l2, ep, corr(pv, y[iv]), corr(mlp_predict(P, Xt, act)+ymu, gt)))
    t2=time.time()
    return r_ridge, lam, df, res, t1-t0, t2-t1
for (n,va,ve,K) in [(1000,0.4,0,0),(1000,0.25,0.15,20)]:
    r_ridge, lam, df, res, ta, tb = run(n,va,ve,K,seed=7)
    print(n,va,ve,K,'ridge r=%.3f lam=%.1f df=%.1f (%.1fs)'%(r_ridge,lam,df,ta),'mlp %.1fs'%tb)
    for r in res: print('   l2=%.3f best_val_mse=%.4f ep=%d val_r=%.3f test_r=%.3f'%(r[1],r[0],r[2],r[3],r[4]))
