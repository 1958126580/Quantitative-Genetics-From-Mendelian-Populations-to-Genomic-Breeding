# 第 30 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch30/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `agg_s1.py` | 数值复核 | numpy | 0.1 | `outputs/agg_s1.out` |
| `emit_s2a.py` | 数值复核 | 标准库 | 0.0 | `outputs/emit_s2a.out` |
| `emit_s3a.py` | recompute eta exactly from lam and t: lam = 1/(eta t) | numpy | 0.2 | `outputs/emit_s3a.out` |
| `pilot1.py` | 数值复核 | numpy, scipy | 3.2 | `outputs/pilot1.out` |
| `s2a_gradcheck.py` | Section 30.2.7: gradient check of hand-written backprop; correct implementation and three typical bugs. | numpy | 2.2 | `outputs/s2a_gradcheck.out` |
| `s3a_es.py` | Section 30.3.5: early stopping vs ridge in a linear model (n=400 < m=500), seed 30311. | numpy, scipy | 2.7 | `outputs/s3a_es.out` |
| `s3c2_adamw_diag.py` | Diagnostics for 30.3.7: second-moment scale per group and normalised-update magnitude. Same data as s3c (seed 30351). | numpy | 10.5 | `outputs/s3c2_adamw_diag.out` |
| `s3c_adamw.py` | Section 30.3.7: L2 penalty vs decoupled weight decay under Adam.  Seeds 30351 (data), 30352+run (batches). | numpy | 33.8 | `outputs/s3c_adamw.out` |
| `s4a_params.py` | Section 30.4.6: parameter counts / multiply-adds / largest activation for SNP models, m = 1e4 and 1e5. | numpy | 0.2 | `outputs/s4a_params.out` |
| `s4b_attn.py` | Section 30.4.6: measured cost of self-attention vs sequence length (numpy, float32, single thread). Seed 30401. | numpy | 4.3 | `outputs/s4b_attn.out` |
| `t_adamw_shift.py` | 数值复核 | numpy | 10.8 | `outputs/t_adamw_shift.out` |

公共函数模块（被上列脚本导入，不单独运行）：`gsim.py`、`nnlib.py`、`opt.py`。
