# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 30 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 agg_s1.py    依赖：numpy
import json, numpy as np
R = json.load(open('s1_results.json'))
def se(x): x = np.asarray(x); return x.std(ddof=1) / np.sqrt(len(x))
for a in (0, 1):
    print('=== arch', a)
    for n in (250, 500, 1000, 2000, 4000):
        sub = [r for r in R if r['arch'] == a and r['n'] == n]
        if not sub: continue
        rr = np.array([r['ridge_r'] for r in sub]); mm = np.array([r['mlp_r'] for r in sub]); ee = np.array([r['ens_r'] for r in sub])
        m5 = np.array([r['mlp_r_mean5'] for r in sub]); lo = np.array([r['loo_r'] for r in sub])
        d = mm - rr; de = ee - rr
        print('n=%-5d reps=%d ridge %.3f (%.3f) | loo %.3f | mlp %.3f (%.3f) mean5 %.3f | diff %.3f (se %.3f) pos %d | ens %.3f diff %.3f (se %.3f) pos %d | df %.1f lam %.0f h2hat %.3f | l2 %s ep %.1f' % (
            n, len(sub), rr.mean(), se(rr), lo.mean(), mm.mean(), se(mm), m5.mean(), d.mean(), se(d), (d > 0).sum(), ee.mean(), de.mean(), se(de), (de > 0).sum(),
            np.mean([r['df'] for r in sub]), np.mean([r['lam'] for r in sub]), np.mean([r['h2hat'] for r in sub]),
            {l: sum(1 for r in sub if r["mlp_l2"] == l) for l in (0.03, 0.1, 0.3, 1.0, 3.0)}, np.mean([r['mlp_ep'] for r in sub])))
        print('        train r(y): ridge %.3f mlp %.3f | test r(y): ridge %.3f mlp %.3f | eff-cor: ridge %.3f mlp %.3f ens %.3f | sd5 of mlp r %.3f | ridge_r_add %.3f' % (
            np.mean([r['ridge_tr_y'] for r in sub]), np.mean([r['mlp_tr_y'] for r in sub]), np.mean([r['ridge_r_y'] for r in sub]), np.mean([r['mlp_r_y'] for r in sub]),
            np.mean([r['ridge_eff_cor'] for r in sub]), np.mean([r['mlp_eff_cor'] for r in sub]), np.mean([r['ens_eff_cor'] for r in sub]),
            np.mean([r['mlp_r_sd5'] for r in sub]), np.mean([r['ridge_r_add'] for r in sub])))
