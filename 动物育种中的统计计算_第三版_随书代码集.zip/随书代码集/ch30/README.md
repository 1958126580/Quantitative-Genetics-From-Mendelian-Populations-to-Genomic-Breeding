# 第三十章　深度学习原理与 Julia 实现 —— 配套代码

**所属**：第七篇　机器学习与深度学习在动物遗传育种中的应用　　**对应正文**：第三十章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch30.ipynb` | IJulia 笔记本：19 个代码单元，约 570 行 Julia 代码，穿插与正文对应的说明 |
| `ch30.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 11 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　激活函数与梯度消失（正文式 30.5）
- 2　从零实现 MLP 与反向传播（正文式 30.10–30.16）
- 3　梯度的数值校验
- 4　优化器对比（正文式 30.19–30.29）
  - 4.1 Adam 偏差校正的必要性（正文式 30.25–30.27）
- 5　初始化对各层激活方差的影响（正文式 30.33–30.35）
- 6　Dropout 的期望等价与"加权岭回归"解释（正文式 30.40–30.42）
- 7　早停 ≈ $\ell_2$ 正则（正文式 30.43）
- 8　注意力中 $\sqrt{d_k}$ 的作用（正文式 30.46）
- 9　系谱 BLUP 就是线性图神经网络（正文式 30.49）
- 10　在基因组数据上训练一个 MLP
- 11　Flux.jl 与 Lux.jl 的对照实现（可选）
- 12　自检汇总

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 30
```

或在 Jupyter 中打开 `ch30/ch30.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 可选单元

- 开关 `RUN_DL`（默认 `false`）：Flux / Lux（深度学习栈）；需先实例化 `envs/ml`：`julia --project=envs/ml -e 'using Pkg; Pkg.instantiate()'`，再把笔记本中的开关改为 `true`。
- 开关关闭时只打印一行提示并跳过，不影响其余单元（见 `../README.md` 与正文附录 E）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
