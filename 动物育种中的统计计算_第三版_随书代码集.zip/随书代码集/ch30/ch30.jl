# 本脚本由 tools/nb2jl.py 从同目录的 ch30.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 30

# %% [markdown]
# # 第三十章　深度学习原理与 Julia 实现 —— 配套代码
#
# 本 Notebook 对应第三十章。**全部核心算法从零实现，不依赖深度学习框架**，
# Flux/Lux 的用法放在最后一节作为对照（需要额外安装这两个包）。
#
# **内容**
#
# 1. 激活函数与梯度消失的定量演示（正文式 30.5）
# 2. **从零实现 MLP 与反向传播**（正文式 30.10–30.16）
# 3. **梯度的数值校验**（中心差分，相对误差应 $<10^{-6}$）
# 4. 优化器：SGD / 动量 / Adam / AdamW 的从零实现与对比（正文式 30.19–30.29）
# 5. Adam 偏差校正的必要性（正文式 30.25–30.27）
# 6. 初始化：He 与 Xavier 对各层激活方差的影响（正文式 30.33–30.35）
# 7. Dropout 的期望等价与"加权岭回归"解释（正文式 30.40–30.42）
# 8. 早停 ≈ $\ell_2$ 正则（正文式 30.43）
# 9. 注意力中 $\sqrt{d_k}$ 的作用（正文式 30.46）
# 10. 系谱 BLUP 就是线性图神经网络（正文式 30.49）
# 11. Flux.jl 与 Lux.jl 的对照实现

# %%
using LinearAlgebra, Random, Printf, Statistics, Distributions

relerr(a, b) = norm(a .- b) / max(norm(b), eps())
function check(name::AbstractString, a, b; tol=1e-9)
    e = relerr(a, b); @printf("%-52s 相对误差 = %.3e   %s\n", name, e, e < tol ? "✔" : "✘")
    return e < tol
end
println("Julia ", VERSION)

# %% [markdown]
# ## 1　激活函数与梯度消失（正文式 30.5）

# %%
sigmoid(z) = 1/(1 + exp(-z))
dsigmoid(z) = (s = sigmoid(z); s*(1-s))
dtanh_(z) = 1 - tanh(z)^2
drelu(z) = z > 0 ? 1.0 : 0.0
gelu(z) = z*cdf(Normal(), z)
silu(z) = z*sigmoid(z)

@printf("%-12s%-16s%-16s%-16s\n", "z", "σ'(sigmoid)", "tanh'", "ReLU'")
for z in (-4.0, -2.0, 0.0, 2.0, 4.0)
    @printf("%-12.1f%-16.5f%-16.5f%-16.1f\n", z, dsigmoid(z), dtanh_(z), drelu(z))
end
@printf("\nsigmoid 导数的最大值 = %.4f （在 z=0 处）\n", dsigmoid(0.0))

println("\n梯度沿深度的衰减（正文式 30.5，取 ‖W‖≈1）：")
@printf("%-10s%-20s%-20s%-20s\n", "层数 L", "sigmoid (c=0.25)", "tanh (c≈0.6)", "ReLU (c=1)")
for L in (1, 3, 5, 10, 20)
    @printf("%-10d%-20.3e%-20.3e%-20.1f\n", L, 0.25^L, 0.6^L, 1.0)
end
println("\n=> sigmoid 在 10 层之后梯度衰减到 1e-6 量级，浅层几乎不更新。")

# 残差连接的效果（正文式 30.6）
println("\n残差连接：∂a^(l)/∂a^(l-1) = I + ∂F/∂a")
for gF in (0.0, 0.1, 0.5)
    @printf("  ∂F/∂a = %.1f 时，20 层的累积因子 = %.3f （无残差时 = %.3e）\n",
            gF, (1 + gF)^20, gF^20)
end

# %% [markdown]
# ## 2　从零实现 MLP 与反向传播（正文式 30.10–30.16）

# %%
# ============ 原理实现：从零的 MLP（正文式 30.10–30.16）============

"""一个全连接层：W (h_out × h_in)、b (h_out)。"""
mutable struct DenseLayer
    W::Matrix{Float64}
    b::Vector{Float64}
    act::Symbol            # :relu / :tanh / :identity
end

"""正文式 (30.35)：He 初始化（ReLU）/ 式 (30.34)：Xavier（tanh）。"""
function DenseLayer(nin::Int, nout::Int, act::Symbol; rng=Random.default_rng())
    s = act === :relu ? sqrt(2/nin) : sqrt(2/(nin + nout))
    DenseLayer(randn(rng, nout, nin) .* s, zeros(nout), act)
end

@inline actfun(z, s::Symbol) = s === :relu ? max(z, 0.0) :
                               s === :tanh ? tanh(z) : z
@inline actgrad(z, a, s::Symbol) = s === :relu ? (z > 0 ? 1.0 : 0.0) :
                                   s === :tanh ? 1 - a^2 : 1.0

"""前向传播，返回 (输出, 每层的 Z 与 A 用于反传)。正文式 (30.14)。"""
function forward(layers::Vector{DenseLayer}, X::Matrix{Float64})
    A = X                              # h_in × B
    Zs = Matrix{Float64}[]; As = Matrix{Float64}[X]
    for L in layers
        Z = L.W*A .+ L.b
        A = actfun.(Z, L.act)
        push!(Zs, Z); push!(As, A)
    end
    return A, Zs, As
end

"""反向传播（平方损失），返回梯度。正文式 (30.10)、(30.15)、(30.16)。"""
function backward(layers::Vector{DenseLayer}, Zs, As, Y::Matrix{Float64})
    Lnum = length(layers); B = size(Y, 2)
    gW = [zeros(size(L.W)) for L in layers]
    gb = [zeros(size(L.b)) for L in layers]
    # 输出层：dL/dA = 2(A - Y)/B，再逐元素乘 σ'（式 30.10）
    dA = 2 .* (As[end] .- Y) ./ B
    D  = dA .* actgrad.(Zs[end], As[end], layers[end].act)
    for l in Lnum:-1:1
        gW[l] .= D * As[l]'                       # 式 (30.16)
        gb[l] .= vec(sum(D; dims=2))
        if l > 1                                   # 式 (30.15)
            D = (layers[l].W' * D) .* actgrad.(Zs[l-1], As[l], layers[l-1].act)
        end
    end
    return gW, gb
end

mse_loss(P, Y) = sum(abs2, P .- Y)/size(Y, 2)

"""把全部参数展平成一个向量（用于数值梯度校验）。"""
function flatten_params(layers)
    v = Float64[]
    for L in layers; append!(v, vec(L.W)); append!(v, L.b); end
    return v
end
function set_params!(layers, v)
    k = 1
    for L in layers
        nW = length(L.W); L.W .= reshape(view(v, k:k+nW-1), size(L.W)); k += nW
        nb = length(L.b); L.b .= view(v, k:k+nb-1); k += nb
    end
    return layers
end
function flatten_grads(gW, gb)
    v = Float64[]
    for (a, b) in zip(gW, gb); append!(v, vec(a)); append!(v, b); end
    return v
end

# %%
# ============ 优化器（正文式 30.19–30.29）============

abstract type Optimizer end

mutable struct SGD <: Optimizer; eta::Float64; end
init_state(::SGD, v) = nothing
step!(o::SGD, theta, g, st) = (theta .-= o.eta .* g; st)

mutable struct Momentum <: Optimizer; eta::Float64; mu::Float64; end
init_state(::Momentum, v) = zeros(length(v))
function step!(o::Momentum, theta, g, st)
    @. st = o.mu*st + g                       # 式 (30.20)
    @. theta -= o.eta*st
    return st
end

mutable struct Adam <: Optimizer
    eta::Float64; b1::Float64; b2::Float64; eps::Float64; t::Int
end
Adam(eta=1e-3; b1=0.9, b2=0.999, eps=1e-8) = Adam(eta, b1, b2, eps, 0)
init_state(::Adam, v) = (zeros(length(v)), zeros(length(v)))
function step!(o::Adam, theta, g, st)
    m, v = st; o.t += 1
    @. m = o.b1*m + (1-o.b1)*g                # 式 (30.23)
    @. v = o.b2*v + (1-o.b2)*g^2              # 式 (30.24)
    mh = m ./ (1 - o.b1^o.t)                  # 式 (30.27)
    vh = v ./ (1 - o.b2^o.t)
    @. theta -= o.eta*mh/(sqrt(vh) + o.eps)   # 式 (30.28)
    return (m, v)
end

mutable struct AdamW <: Optimizer
    eta::Float64; b1::Float64; b2::Float64; eps::Float64; wd::Float64; t::Int
end
AdamW(eta=1e-3; b1=0.9, b2=0.999, eps=1e-8, wd=1e-2) = AdamW(eta, b1, b2, eps, wd, 0)
init_state(::AdamW, v) = (zeros(length(v)), zeros(length(v)))
function step!(o::AdamW, theta, g, st)
    m, v = st; o.t += 1
    @. m = o.b1*m + (1-o.b1)*g
    @. v = o.b2*v + (1-o.b2)*g^2
    mh = m ./ (1 - o.b1^o.t); vh = v ./ (1 - o.b2^o.t)
    @. theta -= o.eta*(mh/(sqrt(vh) + o.eps) + o.wd*theta)   # 式 (30.29)
    return (m, v)
end

# %%
"""小批量训练循环（含早停与 Dropout）。"""
function train_mlp!(layers, Xtr, Ytr, Xva, Yva; opt=AdamW(1e-3),
                    epochs=300, batch=64, dropout=0.0, patience=30,
                    rng=Random.default_rng(), verbose=false)
    theta = flatten_params(layers)
    st = init_state(opt, theta)
    n = size(Xtr, 2)
    best = (Inf, copy(theta), 0)
    hist = NamedTuple[]
    for ep in 1:epochs
        perm = randperm(rng, n)
        for s in 1:batch:n
            idx = perm[s:min(s+batch-1, n)]
            Xb = Xtr[:, idx]; Yb = Ytr[:, idx]
            if dropout > 0                       # 式 (30.39)：inverted dropout
                keep = 1 - dropout
                Xb = Xb .* (rand(rng, size(Xb)...) .< keep) ./ keep
            end
            set_params!(layers, theta)
            P, Zs, As = forward(layers, Xb)
            gW, gb = backward(layers, Zs, As, Yb)
            st = step!(opt, theta, flatten_grads(gW, gb), st)
        end
        set_params!(layers, theta)
        lva = mse_loss(forward(layers, Xva)[1], Yva)
        ltr = mse_loss(forward(layers, Xtr)[1], Ytr)
        push!(hist, (epoch=ep, train=ltr, valid=lva))
        if lva < best[1]
            best = (lva, copy(theta), ep)
        elseif ep - best[3] >= patience
            verbose && @printf("  早停于第 %d 轮（最优第 %d 轮）\n", ep, best[3])
            break
        end
    end
    set_params!(layers, best[2])                 # 恢复最优检查点
    return layers, best, hist
end

# %% [markdown]
# ## 3　梯度的数值校验
#
# 用中心差分 $\dfrac{\partial L}{\partial\theta_k}\approx\dfrac{L(\theta+\epsilon e_k)-L(\theta-\epsilon e_k)}{2\epsilon}$
# 与反向传播的结果比较。**相对误差应小于 $10^{-6}$。**

# %%
function numerical_gradient(layers, X, Y; eps=1e-6)
    theta = flatten_params(layers)
    g = similar(theta)
    for k in eachindex(theta)
        t = theta[k]
        theta[k] = t + eps; set_params!(layers, theta)
        lp = mse_loss(forward(layers, X)[1], Y)
        theta[k] = t - eps; set_params!(layers, theta)
        lm = mse_loss(forward(layers, X)[1], Y)
        theta[k] = t
        g[k] = (lp - lm)/(2eps)
    end
    set_params!(layers, theta)
    return g
end

let rng = Xoshiro(3001)
    # 小网络便于逐参数数值校验
    layers = [DenseLayer(6, 5, :tanh; rng=rng),
              DenseLayer(5, 4, :relu; rng=rng),
              DenseLayer(4, 1, :identity; rng=rng)]
    X = randn(rng, 6, 12); Y = randn(rng, 1, 12)
    P, Zs, As = forward(layers, X)
    gW, gb = backward(layers, Zs, As, Y)
    ga = flatten_grads(gW, gb)
    gn = numerical_gradient(layers, X, Y)
    @printf("参数个数 = %d\n", length(ga))
    @printf("解析梯度与数值梯度的相对误差 = %.3e\n", relerr(ga, gn))
    @printf("最大绝对差 = %.3e （梯度范数 %.3e）\n", maximum(abs.(ga .- gn)), norm(ga))
    global grad_ok = relerr(ga, gn) < 1e-6
    println(grad_ok ? "✔ 反向传播实现正确" : "✘ 实现有误")
end

# %% [markdown]
# ## 4　优化器对比（正文式 30.19–30.29）
#
# 在一个"峡谷型"的二次函数上比较，直观看出动量与自适应步长的作用。

# %%
"""峡谷型二次函数 f(x) = 0.5(a x₁² + b x₂²)，a ≪ b。"""
function optimizer_race(opt; x0=[10.0, 1.0], a=1.0, b=100.0, steps=200)
    x = copy(x0); st = init_state(opt, x)
    path = [copy(x)]
    for _ in 1:steps
        g = [a*x[1], b*x[2]]
        st = step!(opt, x, g, st)
        push!(path, copy(x))
    end
    return path
end

@printf("%-20s%-16s%-16s\n", "优化器", "200 步后 ‖x‖", "达到 ‖x‖<0.01 的步数")
for (nm, o) in ("SGD η=0.01"=>SGD(0.01),
                "SGD η=0.019"=>SGD(0.019),
                "动量 η=0.005 μ=0.9"=>Momentum(0.005, 0.9),
                "Adam η=0.3"=>Adam(0.3),
                "AdamW η=0.3"=>AdamW(0.3; wd=0.0))
    path = optimizer_race(o)
    k = findfirst(p -> norm(p) < 0.01, path)
    @printf("%-20s%-16.4e%-16s\n", nm, norm(path[end]),
            k === nothing ? ">200" : string(k))
end
println("\n=> 峡谷型问题上 SGD 受限于最陡方向的稳定性（η<2/b=0.02）；")
println("   动量放大平缓方向的有效步长；Adam 逐参数自适应，对尺度差异不敏感。")

# %% [markdown]
# ### 4.1 Adam 偏差校正的必要性（正文式 30.25–30.27）

# %%
# 在梯度恒定为 g 的情形下，比较有/无偏差校正的前若干步
let g = 1.0, b1 = 0.9, b2 = 0.999, eta = 0.1
    m = 0.0; v = 0.0
    @printf("%-8s%-16s%-16s%-16s%-16s\n", "t", "m_t", "m̂_t（校正）", "步长（无校正）", "步长（有校正）")
    for t in 1:8
        m = b1*m + (1-b1)*g
        v = b2*v + (1-b2)*g^2
        mh = m/(1 - b1^t); vh = v/(1 - b2^t)
        @printf("%-8d%-16.5f%-16.5f%-16.5f%-16.5f\n", t, m, mh,
                eta*m/(sqrt(v) + 1e-8), eta*mh/(sqrt(vh) + 1e-8))
    end
    @printf("\n理论：E(m_t) = g(1-β₁^t)，t=1 时 m₁ = %.2f 而 m̂₁ = %.2f（式 30.26）\n",
            (1-b1)*g, g)
    println("=> 无校正时前几步的步长被严重低估；校正后立刻达到目标步长 η。")
end

# %% [markdown]
# ## 5　初始化对各层激活方差的影响（正文式 30.33–30.35）

# %%
"""前向传播若干层，记录每层激活的方差。"""
function activation_variance(nin, widths, act, scale_rule; rng=Random.default_rng())
    A = randn(rng, nin, 512)
    out = Float64[var(A)]
    for (k, w) in enumerate(widths)
        n_in = size(A, 1)
        s = scale_rule === :he      ? sqrt(2/n_in) :
            scale_rule === :xavier  ? sqrt(2/(n_in + w)) :
            scale_rule === :naive   ? 0.05 : 1.0
        W = randn(rng, w, n_in) .* s
        A = actfun.(W*A, act)
        push!(out, var(A))
    end
    return out
end

widths = fill(128, 10)
println("ReLU 网络（10 层，每层 128 单元）各层激活的方差\n")
@printf("%-8s", "层")
for r in (:he, :xavier, :naive); @printf("%-16s", String(r)); end
println()
vs = Dict(r => activation_variance(128, widths, :relu, r; rng=Xoshiro(3010))
          for r in (:he, :xavier, :naive))
for l in 1:11
    @printf("%-8d", l-1)
    for r in (:he, :xavier, :naive); @printf("%-16.4e", vs[r][l]); end
    println()
end
println("\n=> He 初始化（式 30.35）使 ReLU 网络的激活方差稳定；")
println("   Xavier 在 ReLU 下略有衰减；固定小尺度（naive）指数衰减，网络无法训练。")

# %% [markdown]
# ## 6　Dropout 的期望等价与"加权岭回归"解释（正文式 30.40–30.42）

# %%
# (a) inverted dropout 的期望等价（式 30.40）
let rng = Xoshiro(3020), a = 3.7, p = 0.7, nrep = 2_000_000
    s = 0.0
    for _ in 1:nrep
        s += (rand(rng) < p ? 1.0 : 0.0)/p * a
    end
    @printf("E(ã) 蒙特卡洛 = %.5f ， 理论 = a = %.5f\n", s/nrep, a)
end

# (b) 线性模型上 dropout ≡ 加权岭回归（式 30.41–30.42）
let rng = Xoshiro(3021), n = 4000, p = 6
    X = randn(rng, n, p) .* [1.0 2.0 0.5 3.0 1.5 0.8]     # 各列尺度不同
    w_true = randn(rng, p)
    y = X*w_true .+ 0.5.*randn(rng, n)
    keep = 0.8
    # dropout 训练的期望目标（式 30.41）的闭式解
    XtX = X'X
    pen = Diagonal(diag(XtX) .* (1-keep)/keep)
    w_do = (XtX + pen) \ (X'y)
    # 直接做 dropout 的 SGD 训练，看是否收敛到同一处
    w = zeros(p); eta = 5e-4
    for ep in 1:60, s in 1:100:n
        idx = s:min(s+99, n)
        mask = (rand(rng, length(idx), p) .< keep) ./ keep
        Xb = X[idx, :] .* mask
        g = -2 .* Xb'*(y[idx] .- Xb*w)/length(idx)
        w .-= eta .* g
    end
    @printf("\n闭式解（式 30.41）  ： %s\n", string(round.(w_do, digits=4)))
    @printf("dropout-SGD 的解    ： %s\n", string(round.(w, digits=4)))
    @printf("相对差 = %.3f\n", relerr(w, w_do))
    @printf("\n各列的隐含岭惩罚 λ_j = (1-p)/p · x_j'x_j：\n  %s\n",
            string(round.(diag(pen), digits=1)))
    println("=> 尺度大的特征受到更强的惩罚（正文式 30.42）；")
    println("   在基因组数据上 x_j'x_j ≈ n·2p_jq_j，即对常见变异惩罚更强。")
end

# %% [markdown]
# ## 7　早停 ≈ $\ell_2$ 正则（正文式 30.43）

# %%
let rng = Xoshiro(3030), n = 200, p = 50
    X = randn(rng, n, p)
    U, d, V = svd(X)
    beta = randn(rng, p) ./ sqrt(p)
    y = X*beta .+ 0.5.*randn(rng, n)
    b_ols = V*Diagonal(1 ./ d)*U'y
    eta = 1e-3
    @printf("%-12s%-18s%-18s%-14s\n", "梯度步数 t", "等价 λ ≈ 1/(ηt)", "cor(GD_t, 岭_λ)", "‖β_t‖")
    b = zeros(p)
    for t in 1:4000
        b .-= eta .* (2 .* X'*(X*b .- y) ./ n)
        if t in (50, 200, 800, 2000, 4000)
            lam_eq = n/(2*eta*t)
            b_ridge = (X'X + lam_eq*I) \ (X'y)
            @printf("%-12d%-18.2f%-18.5f%-14.4f\n", t, lam_eq, cor(b, b_ridge), norm(b))
        end
    end
    println("\n=> 梯度下降的轨迹与岭回归的正则化路径高度一致（正文式 30.43）。")
end

# %% [markdown]
# ## 8　注意力中 $\sqrt{d_k}$ 的作用（正文式 30.46）

# %%
softmax_(v) = (m = maximum(v); e = exp.(v .- m); e ./ sum(e))

let rng = Xoshiro(3040)
    @printf("%-10s%-20s%-22s%-22s\n", "d_k", "Var(q'k)", "softmax 最大权重(未缩放)", "(缩放后)")
    for dk in (8, 64, 512)
        q = randn(rng, dk); K = randn(rng, dk, 16)
        s_raw = vec(q'K)
        s_scaled = s_raw ./ sqrt(dk)
        @printf("%-10d%-20.2f%-22.4f%-22.4f\n", dk, var(s_raw),
                maximum(softmax_(s_raw)), maximum(softmax_(s_scaled)))
    end
    println("\n=> 未缩放时 d_k 越大 softmax 越接近 one-hot（饱和，梯度消失）；")
    println("   除以 √d_k 后权重分布保持平缓（正文式 30.46）。")
    # 梯度的量级
    for dk in (8, 512)
        q = randn(Xoshiro(1), dk); K = randn(Xoshiro(2), dk, 16)
        for (nm, s) in ("未缩放"=>vec(q'K), "缩放"=>vec(q'K)./sqrt(dk))
            a = softmax_(s)
            J = Diagonal(a) - a*a'          # softmax 的 Jacobian
            @printf("  d_k=%-4d %-8s ‖J‖_F = %.4e\n", dk, nm, norm(J))
        end
    end
end

# %% [markdown]
# ## 9　系谱 BLUP 就是线性图神经网络（正文式 30.49）

# %%
"""消息传递：h_i = ½h_s + ½h_d + m_i（式 30.49），与第九章 A = TDT' 等价。"""
function gnn_pedigree(sire::Vector{Int}, dam::Vector{Int}, m::Vector{Float64})
    n = length(sire); h = zeros(n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        h[i] = 0.5*(s > 0 ? h[s] : 0.0) + 0.5*(d > 0 ? h[d] : 0.0) + m[i]
    end
    return h
end

"""第九章的 A = TDT'：由孟德尔抽样项生成育种值。"""
function tdt_breeding_values(sire, dam, m)
    return gnn_pedigree(sire, dam, m)     # 结构完全相同
end

let rng = Xoshiro(3050), n = 500
    sire = zeros(Int, n); dam = zeros(Int, n)
    for i in 51:n
        sire[i] = rand(rng, 1:i-1); dam[i] = rand(rng, 1:i-1)
    end
    # 孟德尔抽样方差（非近交、双亲已知时为 0.5）
    dvec = [(sire[i] > 0 && dam[i] > 0) ? 0.5 : 1.0 for i in 1:n]
    mz = randn(rng, n) .* sqrt.(dvec)
    u = gnn_pedigree(sire, dam, mz)
    # 与显式构造的 A 比较
    A = zeros(n, n)
    for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    @printf("消息传递得到的 Var(u) = %.4f ，  mean(diag(A)) = %.4f\n", var(u), mean(diag(A)))
    # 理论：Cov(u_i,u_j) = A_ij。用大量重复验证
    S = zeros(n, n)
    R = 400
    for r in 1:R
        mz2 = randn(Xoshiro(9000+r), n) .* sqrt.(dvec)
        ur = gnn_pedigree(sire, dam, mz2)
        S .+= ur*ur'
    end
    S ./= R
    @printf("蒙特卡洛 Cov(u) 与 A 的相对误差 = %.3f （R = %d 次重复）\n", relerr(S, A), R)
    println("=> 正文式 (30.49) ≡ 第九章式 (9.4)：系谱 BLUP 是一个线性 GNN。")
end

# %% [markdown]
# ## 10　在基因组数据上训练一个 MLP
#
# **注意**：本节的目的不是"让 MLP 赢"，而是给第三十一章的公平比较提供一个正确实现的基线。

# %%
"""模拟基因组数据（与第二十九章一致）。"""
function sim_geno(n::Int, m::Int, h2::Float64; eps2=0.0, rng=Random.default_rng())
    p = 0.05 .+ 0.45 .* rand(rng, m)
    Mg = [Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j]) for i in 1:n, j in 1:m]
    Z = Mg .- 2 .* p'
    alpha = randn(rng, m)
    glin = Z*alpha; glin ./= std(glin)
    gnl = zeros(n)
    if eps2 > 0
        npair = 50
        j1 = rand(rng, 1:m, npair); j2 = rand(rng, 1:m, npair); w = randn(rng, npair)
        for k in 1:npair; gnl .+= w[k].*(view(Z,:,j1[k]).*view(Z,:,j2[k])); end
        gnl ./= std(gnl)
    end
    g = sqrt(max(h2-eps2,0)).*glin .+ sqrt(eps2).*gnl
    y = 10.0 .+ g .+ randn(rng, n).*sqrt(1-h2)
    return (y=y, Z=Z, g=g, p=p, sum2pq=2*sum(p.*(1 .- p)), h2=h2)
end

let rng = Xoshiro(3060)
    D = sim_geno(1200, 400, 0.4; eps2=0.10, rng=rng)
    tr = 1:800; va = 801:1000; te = 1001:1200
    mu = vec(mean(D.Z[tr,:]; dims=1)); sd = vec(std(D.Z[tr,:]; dims=1))
    sd[sd .< 1e-12] .= 1.0
    Xall = ((D.Z .- mu') ./ sd')'                    # 特征 × 样本
    Yall = reshape(D.y .- mean(D.y[tr]), 1, :)

    layers = [DenseLayer(size(Xall,1), 32, :relu; rng=rng),
              DenseLayer(32, 8, :relu; rng=rng),
              DenseLayer(8, 1, :identity; rng=rng)]
    layers, best, hist = train_mlp!(layers, Xall[:,tr], Yall[:,tr],
                                    Xall[:,va], Yall[:,va];
                                    opt=AdamW(1e-3; wd=1e-2), epochs=400, batch=64,
                                    dropout=0.2, patience=40, rng=rng, verbose=true)
    pred = vec(forward(layers, Xall[:,te])[1])
    # GBLUP 基线
    Ztr = D.Z[tr,:]; G = (Ztr*Ztr')./D.sum2pq
    a = (G + (1-D.h2)/D.h2*I) \ (D.y[tr] .- mean(D.y[tr]))
    pg = (D.Z[te,:]*Ztr')./D.sum2pq*a
    @printf("\n参数个数 = %d ， 训练样本 = %d （比值 %.1f）\n",
            length(flatten_params(layers)), length(tr),
            length(flatten_params(layers))/length(tr))
    @printf("MLP   ： cor(ĝ, g) = %.4f ， b1 = %.3f\n",
            cor(pred, D.g[te]), cov(D.g[te], pred)/var(pred))
    @printf("GBLUP ： cor(ĝ, g) = %.4f ， b1 = %.3f\n",
            cor(pg, D.g[te]), cov(D.g[te], pg)/var(pg))
    @printf("最优验证轮 = %d / %d （早停生效）\n", best[3], length(hist))
end

# %% [markdown]
# ## 11　Flux.jl 与 Lux.jl 的对照实现（可选）
#
# 以下单元需要可选环境 `envs/ml`（Flux、Lux、Optimisers、Zygote，见附录 E）。默认 `RUN_DL = false`。
#
# * 数据与 §10 **完全相同**（同一函数、同一种子、同一划分），网络结构也相同（$400\to32\to8\to1$、ReLU、dropout 0.2、AdamW、早停），因此三种实现的 $r(\hat g,g)$ 应处于同一水平，差异只来自随机初始化与小批次顺序。
# * 本笔记本前面**自己定义了** `sigmoid`、`Adam`、`AdamW` 等名字。为避免与框架导出的同名对象冲突，这里用 `import`（而不是 `using`）并**全部写全限定名**——这是在同一会话中混用"从零实现"与框架时的标准做法。
# * 框架约定"特征 × 样本"（每列一个样本）且默认 `Float32`。接口已对照 Flux 0.16、Lux 1.x、Optimisers 0.4 的源码核实。
# * Lux 单元采用**设备无关**写法：`Lux.gpu_device()` 在装有 GPU 后端（如 `LuxCUDA`）时自动使用 GPU，否则回落到 CPU——同一段代码即是 GPU 训练流水线。

# %%
RUN_DL = false            # 先实例化可选环境 envs/ml（附录 E），再改为 true
if RUN_DL
    let env = joinpath(dirname(Base.active_project()), "envs", "ml")
        isdir(env) || (env = normpath(joinpath(pwd(), "..", "envs", "ml")))
        env in LOAD_PATH || push!(LOAD_PATH, env)   # 叠加可选环境（附录 E）
    end
    import Flux, Lux, Optimisers, Zygote
end

# %%
if RUN_DL
    Ddl = sim_geno(1200, 400, 0.4; eps2 = 0.10, rng = Xoshiro(3060))   # 与 §10 同一份数据
    trd = 1:800; vad = 801:1000; ted = 1001:1200
    mu_d = vec(mean(Ddl.Z[trd, :]; dims = 1)); sd_d = vec(std(Ddl.Z[trd, :]; dims = 1))
    sd_d[sd_d .< 1e-12] .= 1.0
    Xdl = Float32.(((Ddl.Z .- mu_d') ./ sd_d')')            # 特征 × 样本，Float32
    Ydl = Float32.(reshape(Ddl.y .- mean(Ddl.y[trd]), 1, :))
    println("数据：", size(Xdl, 1), " 个特征，训练/验证/测试 = ",
            length(trd), "/", length(vad), "/", length(ted))
end

# %%
# ===== Flux.jl：模型对象内含参数（"隐式"风格）=====
if RUN_DL
    fmodel = Flux.Chain(Flux.Dense(size(Xdl, 1) => 32, Flux.relu), Flux.Dropout(0.2),
                        Flux.Dense(32 => 8, Flux.relu), Flux.Dense(8 => 1))
    fopt   = Flux.setup(Optimisers.AdamW(1f-3, (0.9f0, 0.999f0), 1f-2), fmodel)
    loader = Flux.DataLoader((Xdl[:, trd], Ydl[:, trd]); batchsize = 64,
                             shuffle = true, rng = Xoshiro(3061))
    fbest = (Inf32, deepcopy(fmodel), 0)
    for epoch in 1:400
        Flux.trainmode!(fmodel)                              # dropout 生效
        for (xb, yb) in loader
            gs = Flux.gradient(m -> Flux.mse(m(xb), yb), fmodel)
            Flux.update!(fopt, fmodel, gs[1])
        end
        Flux.testmode!(fmodel)                               # 评估时关闭 dropout
        lv = Flux.mse(fmodel(Xdl[:, vad]), Ydl[:, vad])
        lv < fbest[1] && (fbest = (lv, deepcopy(fmodel), epoch))
        epoch - fbest[3] > 40 && break                       # 早停（正文式 30.43）
    end
    pf = vec(fbest[2](Xdl[:, ted]))
    @printf("Flux ： cor(ĝ, g) = %.4f ， b1 = %.3f ， 最优轮 = %d\n",
            cor(pf, Ddl.g[ted]), cov(Ddl.g[ted], pf)/var(pf), fbest[3])
else
    println("RUN_DL = false：跳过 Flux 对照（正文 §30.5.1）。")
end

# %%
# ===== Lux.jl：参数与状态显式分离（本书推荐）；设备无关写法 =====
if RUN_DL
    dev  = Lux.gpu_device()     # 装有 LuxCUDA / AMDGPU / Metal 等后端时返回 GPU，否则回落到 CPU（并提示）
    cdev = Lux.cpu_device()
    rngl   = Xoshiro(20260918)
    lmodel = Lux.Chain(Lux.Dense(size(Xdl, 1) => 32, Lux.relu), Lux.Dropout(0.2f0),
                       Lux.Dense(32 => 8, Lux.relu), Lux.Dense(8 => 1))
    ps, st = Lux.setup(rngl, lmodel) |> dev                  # 模型本身不含参数
    ts = Lux.Training.TrainState(lmodel, ps, st,
                                 Optimisers.AdamW(1f-3, (0.9f0, 0.999f0), 1f-2))
    Xva_d = dev(Xdl[:, vad]); Xte_d = dev(Xdl[:, ted])
    lbest = (Inf32, deepcopy(ts.parameters), 0)
    for epoch in 1:400
        perm = randperm(rngl, length(trd))
        for k in 1:64:length(perm)
            idx = trd[perm[k:min(k + 63, end)]]
            batch = (dev(Xdl[:, idx]), dev(Ydl[:, idx]))       # 小批量在主机上切好再传到设备
            _, _, _, ts = Lux.Training.single_train_step!(Lux.AutoZygote(), Lux.MSELoss(),
                                                          batch, ts)
        end
        ŷv, _ = lmodel(Xva_d, ts.parameters, Lux.testmode(ts.states))
        lv = mean(abs2, cdev(ŷv) .- Ydl[:, vad])
        lv < lbest[1] && (lbest = (lv, deepcopy(ts.parameters), epoch))
        epoch - lbest[3] > 40 && break
    end
    ŷt, _ = lmodel(Xte_d, lbest[2], Lux.testmode(ts.states))
    pl = vec(cdev(ŷt))
    @printf("Lux  ： cor(ĝ, g) = %.4f ， b1 = %.3f ， 最优轮 = %d （设备：%s）\n",
            cor(pl, Ddl.g[ted]), cov(Ddl.g[ted], pl)/var(pl), lbest[3], string(typeof(dev)))
    println("\n显式参数的四个优势（正文 §30.5.2）：")
    println("  1. 模型是纯函数 f(x; θ)，可与任意优化器/采样器/ODE 求解器组合；")
    println("  2. 贝叶斯神经网络可直接对 ps 做 MCMC 或变分推断；")
    println("  3. 深度集成（第三十一章）只需保存多组 ps；")
    println("  4. 状态（dropout/BatchNorm）与参数分离，训练/推断切换不会出错。")
    println("GPU 要点（正文 §30.5.4）：数据与参数必须在同一设备上；小批量在主机上切片后整体传输，")
    println("避免在 GPU 数组上做逐元素（标量）索引；计算量太小时（如本例）GPU 并不会更快。")
else
    println("RUN_DL = false：跳过 Lux 对照（正文 §30.5.2）。本书推荐新项目使用 Lux.jl。")
end

# %% [markdown]
# ## 12　自检汇总

# %%
ok = Bool[]
push!(ok, grad_ok)
@printf("反向传播的数值梯度校验： %s\n", grad_ok ? "通过 ✔" : "失败 ✘")
# sigmoid + 交叉熵的误差信号 = p̂ - y（正文式 30.8）
let z = 0.7, y = 1.0
    p = sigmoid(z)
    dL_dz_analytic = p - y
    eps = 1e-7
    L(zz) = -(y*log(sigmoid(zz)) + (1-y)*log(1-sigmoid(zz)))
    dL_dz_num = (L(z+eps) - L(z-eps))/(2eps)
    push!(ok, check("式 (30.8)：∂L/∂z = p̂ - y", dL_dz_analytic, dL_dz_num; tol=1e-6))
end
# Adam 的偏差校正：t=1 时 m̂ = g
let g = 2.3, b1 = 0.9
    m1 = (1-b1)*g
    push!(ok, check("Adam 偏差校正 t=1：m̂₁ = g", m1/(1-b1^1), g; tol=1e-14))
end
# He 初始化保持 ReLU 网络的方差
let v = activation_variance(128, fill(128, 10), :relu, :he; rng=Xoshiro(1))
    @printf("He 初始化：第 0 层方差 %.4f → 第 10 层 %.4f （比值 %.2f）\n",
            v[1], v[end], v[end]/v[1])
    push!(ok, 0.3 < v[end]/v[1] < 3.0)
end
# softmax 的性质
let v = [1.0, 2.0, 3.0]
    push!(ok, check("softmax 和为 1", sum(softmax_(v)), 1.0; tol=1e-14))
end
@printf("\n全部 %d 项检查：%s\n", length(ok), all(ok) ? "通过 ✔" : "存在失败 ✘")
