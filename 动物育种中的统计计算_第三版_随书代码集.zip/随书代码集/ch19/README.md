# 第十九章　贝叶斯与基因组方差组分估计 —— 配套代码

**所属**：第四篇　方差组分估计　　**对应正文**：第十九章

## 文件

| 文件 | 说明 |
|:--|:--|
| `ch19.ipynb` | IJulia 笔记本：8 个代码单元，约 310 行 Julia 代码，穿插与正文对应的说明 |
| `ch19.jl` | 同一内容的"百分号格式"脚本（`# %%` 分隔单元），可直接 `include`，也可用 Jupytext 转回笔记本；由 `tools/nb2jl.py` 生成 |
| `python_check/` | 4 个 Python 独立复核脚本及其输出（正文中的数值先由它们独立算出，再与 Julia 实现对照） |

## 笔记本内容

- 1　逆卡方的三种参数化（正文 §19.1.2）
- 2　Gibbs 抽样估计方差组分（正文式 19.4–19.6）
- 3　收敛诊断（正文 §19.1.6）
- 4　先验敏感性分析（正文 §19.1.5）
- 5　GREML 与 $h^2_{\text{SNP}}$（正文 §19.2）
- 6　LD 得分回归（正文式 19.14）
  - 6.1 群体分层时截距的诊断作用
- 本章代码小结

## 运行

```bash
cd code
julia --project=. -e 'using Pkg; Pkg.instantiate()'     # 首次：安装核心依赖
julia --project=. tools/run_chapter.jl 19
```

或在 Jupyter 中打开 `ch19/ch19.ipynb`（IJulia 内核的 `--project=@.` 会自动找到上一级目录的 `Project.toml`）。

## 验证状态

- 代码单元已用 tree-sitter-julia 做**语法检查**（0 错误）；`test/test_fast.jl` 在 Julia 中再做一次 `Meta.parseall` 解析并检查 `.jl` 与笔记本同步。
- **本代码集编写环境没有可用的 Julia，章节脚本未在 Julia 中实际运行**；语法正确不等于运行正确，首次运行请留意各章"自检汇总"单元（✔/✘）。
- 书中数值用 `python_check/` 里的 Python 脚本（NumPy/SciPy 等）**独立复算**，这些脚本已实际运行通过，输出保存在 `python_check/outputs/`。
