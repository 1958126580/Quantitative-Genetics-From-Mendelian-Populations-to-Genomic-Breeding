# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 19 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s7_ld.py    依赖：numpy, scipy
"""19.2: incomplete LD between causal variants and markers -> attenuation of h2_SNP."""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import numpy as np, sys, json
from scipy import stats
sys.path.insert(0, os.path.join(HERE, 'ch19b'))
from greml import *

def sim_hap(n_hap, M, rho, p, rng):
    """AR(1) latent Gaussian thresholded at Phi^{-1}(p) -> haplotypes with decaying LD."""
    thr = stats.norm.ppf(p)
    H = np.empty((n_hap, M), dtype=np.int8)
    g = rng.standard_normal(n_hap)
    s = np.sqrt(1-rho**2)
    for j in range(M):
        if j: g = rho*g + s*rng.standard_normal(n_hap)
        H[:, j] = (g < thr[j])
    return H

n, M, RHO, H2 = 2000, 6000, 0.985, 0.50
rng = np.random.default_rng(777)
p = rng.uniform(0.05, 0.5, M)
H = sim_hap(2*n, M, RHO, p, rng)
Xg = (H[0::2].astype(float) + H[1::2].astype(float))
pe = Xg.mean(0)/2.0
keep = (pe > 0.01) & (pe < 0.99)
Xg = Xg[:, keep]; pe = pe[keep]; M = Xg.shape[1]
print(f'M kept = {M}, mean MAF = {np.minimum(pe,1-pe).mean():.4f}')

# LD decay check
Zs = (Xg - 2*pe)/np.sqrt(2*pe*(1-pe))
def r2_lag(d, k=800):
    idx = rng.choice(M-d, k, replace=False)
    a = Zs[:, idx]; b = Zs[:, idx+d]
    r = (a*b).mean(0)
    return float(np.mean(r**2))
lag_tab = {d: r2_lag(d) for d in [1, 2, 5, 10, 20, 50, 100]}
print('mean r^2 by lag:', {k: round(v, 4) for k, v in lag_tab.items()})

caus = np.arange(0, M, 4)                 # every 4th SNP is causal
chip = np.setdiff1d(np.arange(M), caus)
print(f'causal={len(caus)}  chip={len(chip)}')

# best tagging r^2 of each causal by the chip (within +/- 50 SNPs)
best = np.empty(len(caus))
for i, c in enumerate(caus):
    lo, hi = max(0, c-50), min(M, c+51)
    win = np.array([j for j in range(lo, hi) if j != c and j in set(chip.tolist())]) if False else \
          np.array([j for j in range(lo, hi) if j % 4 != 0])
    r = (Zs[:, c][:, None]*Zs[:, win]).mean(0)
    best[i] = np.max(r**2)
print(f'mean best tagging r^2 = {best.mean():.4f}  median = {np.median(best):.4f}')

X1 = np.ones((n, 1))
G_chip = G_vr2(Xg[:, chip], pe[chip])
G_all = G_vr2(Xg, pe)
E_chip = EigREML(G_chip, X1); E_all = EigREML(G_all, X1)
hzc = (Xg[:, caus] - 2*pe[caus])/np.sqrt(2*pe[caus]*(1-pe[caus]))
res = {'lag': lag_tab, 'best_r2': float(best.mean()), 'best_r2_med': float(np.median(best))}
for lab, E in [('chip (causal excluded)', E_chip), ('all SNPs (causal included)', E_all)]:
    est = []
    for rep in range(40):
        b = rng.standard_normal(len(caus))
        g = hzc @ b; g = g/g.std()*np.sqrt(H2)
        e = rng.standard_normal(n); e = e/e.std()*np.sqrt(1-H2)
        est.append(E.fit(g+e)[0])
    print(f'  {lab}: h2_SNP={np.mean(est):.4f} (SE {np.std(est,ddof=1)/np.sqrt(40):.4f})  ratio={np.mean(est)/H2:.4f}')
    res[lab] = [float(np.mean(est)), float(np.std(est, ddof=1)/np.sqrt(40))]
json.dump(res, open(os.path.join(HERE, 's7.json'),'w'), indent=1)
