# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 19 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s6_bias.py    依赖：numpy
"""19.2: closed-form attenuation factor for VanRaden-1 G under Var(b_j) ~ (2pq)^alpha."""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import numpy as np, sys, json
sys.path.insert(0, os.path.join(HERE, 'ch19b'))
from greml import maf_spectrum, genotypes
M, n = 5000, 2000
rng = np.random.default_rng(1902)
obs = json.load(open(os.path.join(HERE, 's5.json')))
for spec in ['neutral', 'chip']:
    p = maf_spectrum(M, spec, rng=rng)
    Xg = genotypes(p, n, rng)
    pe = Xg.mean(0)/2.0
    t = 2*pe*(1-pe)
    cv2 = t.var()/t.mean()**2
    print(f'=== {spec}: mean(2pq)={t.mean():.5f}  CV^2(2pq)={cv2:.5f}  CV={np.sqrt(cv2):.5f}')
    for a in [0.0, -0.25, -0.5, -0.75, -1.0]:
        pred = (t.sum()*np.sum(t**(a+2)))/(np.sum(t**2)*np.sum(t**(a+1)))
        got = obs[spec]['res'][str(a)]['G1'][0]/0.5
        print(f'   alpha={a:+.2f}  predicted ratio={pred:.4f}   simulated={got:.4f}   diff={got-pred:+.4f}')
    print(f'   at alpha=-1 the formula is 1/(1+CV^2) = {1/(1+cv2):.4f}')
