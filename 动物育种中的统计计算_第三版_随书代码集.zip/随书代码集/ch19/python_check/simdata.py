# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 19 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 simdata.py    依赖：numpy
"""The single simulated data set used throughout 19.1 (example 19.1)."""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import numpy as np, sys
sys.path.insert(0, os.path.join(HERE, 'ch19b'))
from common import *
SA2, SE2 = 30.0, 70.0
def get():
    sire, dam, q = make_ped(20, 40, 400, seed=19)
    A, Ainv = a_inverse(sire, dam)
    n_base, N = 60, 400
    La = np.linalg.cholesky(A + 1e-10*np.eye(q))
    Z = np.zeros((N, q)); Z[np.arange(N), n_base + np.arange(N)] = 1.0
    rng = np.random.default_rng(2020)
    u_true = La @ rng.standard_normal(q)*np.sqrt(SA2)
    cg = rng.integers(0, 4, N)
    xcov = rng.standard_normal(N)
    X = np.column_stack([np.ones(N), xcov] + [(cg == k).astype(float) for k in (1, 2, 3)])
    bt = np.array([10.0, 2.0, 1.5, -2.0, 0.8])
    y = X @ bt + Z @ u_true + rng.standard_normal(N)*np.sqrt(SE2)
    return dict(y=y, X=X, Z=Z, A=A, Ainv=Ainv, q=q, N=N, p=X.shape[1], u_true=u_true)
