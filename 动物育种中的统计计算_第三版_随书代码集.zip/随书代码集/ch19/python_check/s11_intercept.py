# -*- coding: utf-8 -*-
# 《动物育种中的统计计算（第三版）》第 19 章 —— 数值复核脚本（Python，独立于 Julia 实现）。
# 运行：python3 s11_intercept.py    依赖：numpy, scipy
"""19.3: LDSC intercept vs lambda_GC under polygenicity and under stratification."""
import os; HERE = os.path.dirname(os.path.abspath(__file__))
import numpy as np, sys, json
from scipy import stats
sys.path.insert(0, os.path.join(HERE, 'ch19b'))
from greml import *

M, W, RHO = 16000, 150, 0.985
NPOP, FST = 1500, 0.02
rng = np.random.default_rng(606)
p0 = rng.uniform(0.05, 0.5, M)
def bn(p0, F, rg):
    return np.clip(rg.beta(p0*(1-F)/F, (1-p0)*(1-F)/F), 0.005, 0.995)
p1, p2 = bn(p0, FST, rng), bn(p0, FST, rng)
def geno(nind, pv, rg):
    H = sim_hap(2*nind, M, RHO, pv, rg)
    return H[0::2].astype(np.float32) + H[1::2].astype(np.float32)
Xa, Xb = geno(NPOP, p1, rng), geno(NPOP, p2, rng)
Xg = np.vstack([Xa, Xb]); del Xa, Xb
N = 2*NPOP
pg = Xg.mean(0)/2.0
ok = (pg > 0.01) & (pg < 0.99); Xg = Xg[:, ok]; pg = pg[ok]; Mk = Xg.shape[1]
Zg = ((Xg - 2*pg)/np.sqrt(2*pg*(1-pg))).astype(np.float32); del Xg
print(f'N={N} M={Mk}  mean |p1-p2| = {np.abs(p1-p2)[ok].mean():.4f}')

def ldscores(Z, W):
    n, M = Z.shape; ell = np.zeros(M); B = 400
    for s in range(0, M, B):
        e = min(s+B, M); lo, hi = max(0, s-W), min(M, e+W)
        R = (Z[:, s:e].astype(np.float64).T @ Z[:, lo:hi].astype(np.float64))/n
        r2 = R**2 - (1-R**2)/(n-2)
        ell[s:e] = r2.sum(1)
    return ell
ell = ldscores(Zg, W)
Z1 = Zg[:NPOP]
Z1 = ((Z1 - Z1.mean(0))/Z1.std(0)).astype(np.float32)     # re-standardise within pop 1
ell1 = ldscores(Z1, W)
print(f'pooled in-sample ell: mean={ell.mean():.3f}   within-pop1 ell: mean={ell1.mean():.3f}'
      f'   corr={np.corrcoef(ell, ell1)[0,1]:.4f}')

def chi2_stats(Z, y):
    n = Z.shape[0]; ys = (y-y.mean())/y.std()
    r = (Z.astype(np.float64).T @ ys)/n
    return (n-2)*r**2/(1-r**2)
def ldsc_fit(chi2, ell, N, M, nblock=100):
    x = ell*N/M; A0 = np.column_stack([np.ones(len(x)), x])
    def one(idx):
        b, *_ = np.linalg.lstsq(A0[idx], chi2[idx], rcond=None)
        for _ in range(2):
            h2g = min(max(b[1], 0.0), 1.0)
            w = 1.0/(np.maximum(ell[idx], 1.0)*(max(b[0], 1.0)+h2g*x[idx])**2)
            sw = np.sqrt(w)
            b, *_ = np.linalg.lstsq(A0[idx]*sw[:, None], chi2[idx]*sw, rcond=None)
        return b
    full = one(np.arange(len(chi2)))
    bl = np.array_split(np.arange(len(chi2)), nblock)
    ps = np.array([one(np.concatenate([bl[j] for j in range(nblock) if j != k])) for k in range(nblock)])
    se = np.sqrt((nblock-1)/nblock*np.sum((ps-ps.mean(0))**2, axis=0))
    return full, se

pop = np.r_[np.zeros(NPOP), np.ones(NPOP)]
Zg64 = Zg.astype(np.float64)
CHI2MED = stats.chi2.ppf(0.5, 1)
scen = [('A 纯多基因 h2=0.3, 无分层', 0.30, 0.0),
        ('B h2=0, 纯分层', 0.0, 0.9),
        ('C h2=0.3 + 分层', 0.30, 0.9),
        ('D h2=0.6, 无分层', 0.60, 0.0)]
res = {'ell_mean': float(ell.mean()), 'M': Mk, 'N': N, 'FST': FST}
for lab, h2, delta in scen:
    ests = []
    for rep in range(12):
        b = rng.standard_normal(Mk)*np.sqrt(h2/Mk)
        g = Zg64 @ b if h2 > 0 else np.zeros(N)
        e = rng.standard_normal(N)*np.sqrt(1-h2 if h2 > 0 else 1.0)
        y = g + delta*pop + e
        c2 = chi2_stats(Zg, y)
        f, se = ldsc_fit(c2, ell, N, Mk)
        f1, _ = ldsc_fit(c2, ell1, N, Mk)
        lam = np.median(c2)/CHI2MED
        ests.append((c2.mean(), lam, f[0], f[1], se[0], se[1], f1[0], f1[1]))
    a = np.array(ests).mean(0); sd = np.array(ests).std(0, ddof=1)
    print(f'{lab}: mean chi2={a[0]:.3f}  lambda_GC={a[1]:.3f}  intercept={a[2]:.4f}(sd {sd[2]:.3f})  '
          f'h2_LDSC={a[3]:.4f}(sd {sd[3]:.3f})   SE_jk(icpt)={a[4]:.3f}'
          f'  || within-pop1 LD scores: intercept={a[6]:.4f} h2={a[7]:.4f}')
    res[lab] = dict(mchi2=float(a[0]), lam=float(a[1]), icpt=float(a[2]), icpt_sd=float(sd[2]),
                    h2=float(a[3]), h2_sd=float(sd[3]), se_icpt=float(a[4]), se_h2=float(a[5]),
                    icpt1=float(a[6]), h21=float(a[7]))
json.dump(res, open(os.path.join(HERE, 's11.json'),'w'),
          indent=1, ensure_ascii=False)
