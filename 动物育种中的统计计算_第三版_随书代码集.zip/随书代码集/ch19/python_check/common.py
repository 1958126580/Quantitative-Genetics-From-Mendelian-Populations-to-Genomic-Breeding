# -*- coding: utf-8 -*-
"""Shared utilities for ch19 numerical experiments."""
import numpy as np
from scipy import linalg, optimize

# ---------- pedigree / A-inverse ----------
def make_ped(n_s=20, n_d=40, n_off=400, seed=19):
    rng = np.random.default_rng(seed)
    q = n_s + n_d + n_off
    sire = np.zeros(q, dtype=int); dam = np.zeros(q, dtype=int)   # 0 = unknown
    for k in range(n_off):
        i = n_s + n_d + k
        sire[i] = 1 + rng.integers(0, n_s)
        dam[i] = 1 + n_s + rng.integers(0, n_d)
    return sire, dam, q

def a_inverse(sire, dam):
    """Henderson's rules; returns dense A^{-1} and inbreeding F (assume F=0 base, compute via A)."""
    q = len(sire)
    A = np.zeros((q, q))
    for i in range(q):
        s, d = sire[i]-1, dam[i]-1
        for j in range(i):
            asj = A[s, j] if s >= 0 else 0.0
            adj = A[d, j] if d >= 0 else 0.0
            A[i, j] = A[j, i] = 0.5*(asj + adj)
        asd = A[s, d] if (s >= 0 and d >= 0) else 0.0
        A[i, i] = 1.0 + 0.5*asd
    Ainv = linalg.inv(A)
    return A, Ainv

# ---------- REML (2 components) via ML of the REML likelihood ----------
def reml_loglik(theta, y, X, Z, Ainv, A):
    sa2, se2 = theta
    n = len(y)
    V = Z @ A @ Z.T * sa2 + np.eye(n)*se2
    L = linalg.cho_factor(V, lower=True)
    Vi_X = linalg.cho_solve(L, X)
    XtViX = X.T @ Vi_X
    Vi_y = linalg.cho_solve(L, y)
    P = linalg.cho_solve(L, np.eye(n)) - Vi_X @ linalg.solve(XtViX, Vi_X.T)
    ld_V = 2*np.sum(np.log(np.diag(L[0])))
    sgn, ld_XtVX = np.linalg.slogdet(XtViX)
    return -0.5*(ld_V + ld_XtVX + y @ P @ y), P

def reml_fit(y, X, Z, Ainv, A, start=(1.0, 1.0)):
    f = lambda t: -reml_loglik(np.exp(t), y, X, Z, Ainv, A)[0]
    r = optimize.minimize(f, np.log(np.array(start)), method='Nelder-Mead',
                          options=dict(xatol=1e-10, fatol=1e-12, maxiter=20000, maxfev=20000))
    return np.exp(r.x)

# ---------- ESS (Geyer initial positive sequence) ----------
def acf(x, maxlag):
    x = np.asarray(x, float); x = x - x.mean()
    n = len(x)
    nf = 1 << (2*n - 1).bit_length()
    f = np.fft.rfft(x, nf)
    ac = np.fft.irfft(f*np.conjugate(f), nf)[:maxlag+1].real
    return ac/ac[0]

def ess_geyer(x):
    """Geyer (1992) initial positive sequence estimator; returns (ESS, tau_int)."""
    x = np.asarray(x, float); n = len(x)
    maxlag = min(n-1, 5000)
    r = acf(x, maxlag)
    # pair sums Gamma_m = r[2m] + r[2m+1]
    G = []
    m = 0
    while 2*m+1 <= maxlag:
        g = r[2*m] + r[2*m+1]
        if g <= 0: break
        G.append(g); m += 1
    G = np.array(G)
    if len(G) == 0:
        return float(n), 1.0
    # enforce monotone decreasing
    for i in range(1, len(G)):
        if G[i] > G[i-1]: G[i] = G[i-1]
    tau = -1.0 + 2.0*G.sum()
    tau = max(tau, 1.0)
    return n/tau, tau

def geweke(x, first=0.1, last=0.5):
    x = np.asarray(x, float); n = len(x)
    a = x[:int(first*n)]; b = x[int((1-last)*n):]
    def spec0(v):
        e, t = ess_geyer(v)
        return v.var(ddof=1)*t/len(v)
    return (a.mean()-b.mean())/np.sqrt(spec0(a)+spec0(b))

def gelman_rubin(chains):
    """chains: (m, n) array of m chains after burn-in. Returns (Rhat, Rhat_split_ok)."""
    ch = np.asarray(chains, float)
    m, n = ch.shape
    W = ch.var(axis=1, ddof=1).mean()
    B = n*ch.mean(axis=1).var(ddof=1)
    varhat = (n-1)/n*W + B/n
    return np.sqrt(varhat/W)

def post_mode(x, grid=512):
    """KDE-free mode: histogram-smoothed mode via Gaussian KDE on a grid."""
    from scipy.stats import gaussian_kde
    x = np.asarray(x, float)
    k = gaussian_kde(x)
    g = np.linspace(x.min(), x.max(), grid)
    return g[np.argmax(k(g))]
