# 第 19 章 · Python 独立复核脚本

正文中的数值例（解析结果、模拟结果、算法对照）在写作时都先用这里的 Python 脚本**独立复算**，再写进书里；它们与 Julia 笔记本互为交叉验证。下列脚本均已实际运行通过，标准输出保存在 `outputs/`。

```bash
cd code/ch19/python_check
python3 <脚本名>.py        # 依赖见下表；脚本只读写本目录
```

| 脚本 | 说明 | 依赖 | 用时(秒) | 输出 |
|:--|:--|:--|--:|:--|
| `s11_intercept.py` | 19.3: LDSC intercept vs lambda_GC under polygenicity and under stratification. | numpy, scipy | 59.1 | `outputs/s11_intercept.out` |
| `s6_bias.py` | 19.2: closed-form attenuation factor for VanRaden-1 G under Var(b_j) ~ (2pq)^alpha. | numpy, scipy | 5.4 | `outputs/s6_bias.out` |
| `s7_ld.py` | 19.2: incomplete LD between causal variants and markers -> attenuation of h2_SNP. | numpy, scipy | 33.4 | `outputs/s7_ld.out` |
| `simdata.py` | The single simulated data set used throughout 19.1 (example 19.1). | numpy, scipy | 1.8 | `outputs/simdata.out` |

公共函数模块（被上列脚本导入，不单独运行）：`common.py`、`greml.py`。
