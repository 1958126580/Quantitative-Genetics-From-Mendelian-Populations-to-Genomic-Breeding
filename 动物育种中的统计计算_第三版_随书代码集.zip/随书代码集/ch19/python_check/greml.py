# -*- coding: utf-8 -*-
"""GREML helpers: G construction (VanRaden 1 / 2), eigen-REML, exact SE of h2."""
import numpy as np
from scipy import optimize

def maf_spectrum(M, kind='neutral', lo=0.01, hi=0.5, rng=None):
    rng = rng or np.random.default_rng(0)
    if kind == 'neutral':                      # density ~ 1/p on [lo,hi]
        u = rng.random(M)
        return lo*np.exp(u*np.log(hi/lo))
    if kind == 'chip':                         # ascertained: ~uniform on [0.05,0.5]
        return rng.uniform(0.05, 0.5, M)
    raise ValueError(kind)

def genotypes(p, n, rng):
    return rng.binomial(2, p[None, :], size=(n, len(p))).astype(float)

def G_vr1(Xg, p):
    Zc = Xg - 2*p[None, :]
    return Zc @ Zc.T/(2*np.sum(p*(1-p)))

def G_vr2(Xg, p):
    s = np.sqrt(2*p*(1-p))
    Zs = (Xg - 2*p[None, :])/s[None, :]
    return Zs @ Zs.T/Xg.shape[1]

class EigREML:
    """y = X b + g + e,  Var(g) = G sg2.  Uses eigendecomposition of M G M."""
    def __init__(self, G, X):
        self.X = X
        n = G.shape[0]
        Qx, _ = np.linalg.qr(X)
        self.Qx = Qx
        # basis of the orthogonal complement of col(X)
        Full = np.linalg.qr(np.hstack([X, np.random.default_rng(1).standard_normal((n, n-X.shape[1]))]))[0]
        self.S = Full[:, X.shape[1]:]                  # n x (n-p), S'S = I, S'X = 0
        Gs = self.S.T @ G @ self.S
        self.lam, self.U = np.linalg.eigh(Gs)
        self.n, self.p = n, X.shape[1]
    def prep(self, y):
        return self.U.T @ (self.S.T @ y)
    def loglik(self, h2, yt):
        d = h2*self.lam + (1-h2)
        m = len(yt)
        s2 = np.sum(yt**2/d)/m
        return -0.5*(np.sum(np.log(d)) + m*np.log(s2) + m), s2
    def fit(self, y, lo=1e-7, hi=1-1e-7):
        yt = self.prep(y)
        r = optimize.minimize_scalar(lambda h: -self.loglik(h, yt)[0], bounds=(lo, hi), method='bounded',
                                     options=dict(xatol=1e-10))
        h2 = r.x; ll, s2 = self.loglik(h2, yt)
        return h2, s2*h2, s2*(1-h2), ll
    def se_h2(self, h2):
        """exact REML asymptotic SE of h2 with (sp2,h2) parameterisation."""
        d = h2*self.lam + (1-h2)
        a = (self.lam - 1)/d                       # d/dh2 of log-ish
        m = len(self.lam)
        # info for (sp2, h2): I11 = m/(2 sp4); I12 = tr(a)/(2 sp2); I22 = tr(a^2)/2
        I22 = 0.5*np.sum(a**2); I12 = 0.5*np.sum(a); I11 = 0.5*m
        # in units where sp2 is profiled out: Var(h2) = 1/(I22 - I12^2/I11)
        return float(1.0/np.sqrt(I22 - I12**2/I11))

def sim_hap(n_hap, M, rho, p, rng):
    """AR(1) latent Gaussian thresholded at Phi^{-1}(p) -> haplotypes with decaying LD."""
    from scipy import stats
    thr = stats.norm.ppf(p)
    H = np.empty((n_hap, M), dtype=np.int8)
    g = rng.standard_normal(n_hap); s = np.sqrt(1-rho**2)
    for j in range(M):
        if j: g = rho*g + s*rng.standard_normal(n_hap)
        H[:, j] = (g < thr[j])
    return H
