# 本脚本由 tools/nb2jl.py 从同目录的 ch19.ipynb 自动导出（"百分号格式"，# %% 分隔单元，Jupytext 兼容），内容与笔记本一致。
# 运行：在 code/ 目录下执行  julia --project=. tools/run_chapter.jl 19

# %% [markdown]
# # 第十九章　贝叶斯与基因组方差组分估计 —— 配套代码
#
# | 节 | 内容 | 对应正文 |
# |:--|:--|:--|
# | 1 | **逆卡方的三种参数化**与先验抽样检验 | §19.1.2 |
# | 2 | Gibbs 抽样估计方差组分 | §19.1.3 |
# | 3 | 收敛诊断与后验推断 | §19.1.6 |
# | 4 | 先验敏感性分析 | §19.1.5 |
# | 5 | GREML 与 $h^2_{\text{SNP}}$ | §19.2 |
# | 6 | LD 得分回归（LDSC） | §19.3 |

# %%
using LinearAlgebra, SparseArrays, Random, Printf, Statistics, Distributions
rng = Xoshiro(20260918)

function build_A(sire::Vector{Int}, dam::Vector{Int})
    n = length(sire); A = zeros(n, n)
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]
        for j in 1:i-1
            A[i,j] = A[j,i] = 0.5*((s>0 ? A[j,s] : 0.0) + (d>0 ? A[j,d] : 0.0))
        end
        A[i,i] = 1.0 + (s>0 && d>0 ? 0.5*A[s,d] : 0.0)
    end
    return A
end

function build_Ainv(sire::Vector{Int}, dam::Vector{Int}, F::Vector{Float64})
    n = length(sire); I_=Int[]; J_=Int[]; V_=Float64[]
    @inbounds for i in 1:n
        s, d = sire[i], dam[i]; pos = (s, d, i)
        if s>0 && d>0;  q=(-0.5,-0.5,1.0); delta=0.5-0.25*(F[s]+F[d])
        elseif s>0;     q=(-0.5, 0.0,1.0); delta=0.75-0.25*F[s]
        elseif d>0;     q=( 0.0,-0.5,1.0); delta=0.75-0.25*F[d]
        else;           q=( 0.0, 0.0,1.0); delta=1.0
        end
        b = inv(delta)
        for a in 1:3, c in 1:3
            (pos[a]>0 && pos[c]>0) || continue
            push!(I_,pos[a]); push!(J_,pos[c]); push!(V_,q[a]*q[c]*b)
        end
    end
    return sparse(I_, J_, V_, n, n)
end

function random_pedigree(n::Int; nbase::Int=max(10,n÷50), rng=Random.default_rng())
    sire=zeros(Int,n); dam=zeros(Int,n)
    for i in nbase+1:n; sire[i]=rand(rng,1:i-1); dam[i]=rand(rng,1:i-1); end
    return sire, dam
end

"""按给定方差组分，在给定系谱上模拟单性状动物模型数据。"""
function sim_animal_model(sire, dam, s2a, s2e; nherd=10, rng=Random.default_rng())
    n = length(sire)
    A = build_A(sire, dam)
    L = cholesky(Symmetric(A + 1e-10I)).L
    u = L*randn(rng, n).*sqrt(s2a)
    recs = collect((n÷10+1):n)
    nr = length(recs)
    hd = rand(rng, 1:nherd, nr)
    he = randn(rng, nherd).*2.0
    y  = 10.0 .+ he[hd] .+ u[recs] .+ randn(rng, nr).*sqrt(s2e)
    X = zeros(nr, nherd); for k in 1:nr; X[k, hd[k]] = 1.0; end
    Z = zeros(nr, n);     for k in 1:nr; Z[k, recs[k]] = 1.0; end
    return (y=y, X=X, Z=Z, A=A, u=u, recs=recs)
end

# %% [markdown]
# ## 1　逆卡方的三种参数化（正文 §19.1.2）
#
# **这是本领域 MCMC 实现最常见的错误来源。检测方法：无数据下的先验抽样。**

# %%
nu, S = 4.0, 2.0

# 约定 A（本书）：sigma2 = nu*S / chi2_nu ，均值 nu*S/(nu-2)
draw_A(k, rng) = [nu*S / rand(rng, Chisq(nu)) for _ in 1:k]
# 常见错误：漏掉 nu
draw_bad(k, rng) = [S / rand(rng, Chisq(nu)) for _ in 1:k]
# 约定 C：InvGamma(nu/2, nu*S/2)，与 A 等价
draw_C(k, rng) = rand(rng, InverseGamma(nu/2, nu*S/2), k)

K = 400_000
theo_mean = nu*S/(nu-2)
theo_mode = nu*S/(nu+2)
@printf("理论先验均值 nu*S/(nu-2) = %.4f ; 众数 nu*S/(nu+2) = %.4f\n\n", theo_mean, theo_mode)
println(rpad("参数化", 28), rpad("样本均值", 14), rpad("相对偏差", 14), "结论")
println("-"^70)
for (nm, f) in (("A: nu*S/chi2 (正确)", draw_A),
                ("误: S/chi2 (漏 nu)",  draw_bad),
                ("C: InvGamma(nu/2,nuS/2)", draw_C))
    sm = mean(f(K, Xoshiro(hash(nm))))
    @printf("%-28s%-14.4f%-14.1f%%%s\n", nm, sm, 100*(sm-theo_mean)/theo_mean,
            abs(sm-theo_mean)/theo_mean < 0.02 ? "通过" : "不一致！")
end
println("\n=> 漏掉 nu 使先验均值只有正确值的 1/nu。在 BayesA/B 中每个标记一个方差、")
println("   数据信息极少，先验直接决定结果（第五章案例三）。")

# %% [markdown]
# ## 2　Gibbs 抽样估计方差组分（正文式 19.4–19.6）

# %%
"""
    gibbs_vc(y, X, Z, Ainv; nu_a, S_a, nu_e, S_e, niter, burn)

单性状动物模型的 Gibbs 抽样（式 19.4–19.6）。
逐分量抽样 = 加噪声的 Gauss-Seidel（正文 §19.1.3）。
"""
function gibbs_vc(y, X, Z, Ainv; nu_a=4.0, S_a=1.0, nu_e=4.0, S_e=1.0,
                  niter=20_000, burn=5_000, rng=Random.default_rng())
    N = length(y); nf = size(X,2); q = size(Z,2)
    W = hcat(X, Z)
    WtW = W'W; Wty = W'y
    diagWtW = diag(WtW)
    Ai = Matrix(Ainv)
    theta = zeros(nf+q)
    s2a, s2e = var(y)/2, var(y)/2
    keep_a = Float64[]; keep_e = Float64[]
    for it in 1:niter
        lam = s2e/s2a
        # 逐分量抽样（式 19.4）
        for j in 1:(nf+q)
            cjj = diagWtW[j] + (j > nf ? lam*Ai[j-nf, j-nf] : 0.0)
            cjj <= 0 && continue
            s = Wty[j]
            for l in 1:(nf+q)
                l == j && continue
                cjl = WtW[j,l] + ((j>nf && l>nf) ? lam*Ai[j-nf, l-nf] : 0.0)
                cjl == 0 && continue
                s -= cjl*theta[l]
            end
            theta[j] = s/cjj + randn(rng)*sqrt(s2e/cjj)
        end
        u = @view theta[nf+1:end]
        # 方差组分（式 19.5、19.6）
        uAu = u'*Ai*u
        s2a = (uAu + nu_a*S_a) / rand(rng, Chisq(q + nu_a))
        e = y .- W*theta
        s2e = (dot(e,e) + nu_e*S_e) / rand(rng, Chisq(N + nu_e))
        if it > burn
            push!(keep_a, s2a); push!(keep_e, s2e)
        end
    end
    return keep_a, keep_e
end

sire, dam = random_pedigree(300; rng=Xoshiro(7))
F = diag(build_A(sire, dam)) .- 1
Ainv = build_Ainv(sire, dam, F)
D = sim_animal_model(sire, dam, 3.0, 7.0; nherd=6, rng=Xoshiro(8))

ka, ke = gibbs_vc(D.y, D.X, D.Z, Ainv; nu_a=4.0, S_a=2.0, nu_e=4.0, S_e=5.0,
                  niter=12_000, burn=3_000, rng=Xoshiro(123))
h2s = ka ./ (ka .+ ke)
@printf("真值:     sigma2_a = 3.000 , sigma2_e = 7.000 , h2 = 0.300\n")
@printf("后验均值: sigma2_a = %.4f , sigma2_e = %.4f , h2 = %.4f\n",
        mean(ka), mean(ke), mean(h2s))
@printf("后验中位: sigma2_a = %.4f , sigma2_e = %.4f , h2 = %.4f\n",
        median(ka), median(ke), median(h2s))
@printf("h2 的 95%% 后验区间 = [%.4f, %.4f]\n", quantile(h2s, 0.025), quantile(h2s, 0.975))
@printf("P(h2 > 0.25) = %.3f   <- 贝叶斯方法可以直接回答这类问题\n", mean(h2s .> 0.25))

# %% [markdown]
# ## 3　收敛诊断（正文 §19.1.6）

# %%
"""有效样本量（ESS）：考虑自相关后的等价独立样本数。"""
function ess(x::Vector{Float64}; maxlag::Int=200)
    n = length(x); xc = x .- mean(x); v = var(x)
    v <= 0 && return float(n)
    rho = Float64[]
    for k in 1:min(maxlag, n-2)
        r = sum(xc[1:end-k] .* xc[k+1:end]) / ((n-k)*v)
        r < 0.05 && break
        push!(rho, r)
    end
    return n / (1 + 2*sum(rho))
end

"""Gelman–Rubin R-hat：多链间方差与链内方差之比。"""
function rhat(chains::Vector{Vector{Float64}})
    m = length(chains); n = minimum(length.(chains))
    ch = [c[end-n+1:end] for c in chains]
    means = mean.(ch); vars = var.(ch)
    B = n*var(means); W = mean(vars)
    Vhat = (n-1)/n*W + B/n
    return sqrt(Vhat/W)
end

# 多链
chains_a = Vector{Float64}[]; chains_h = Vector{Float64}[]
for c in 1:4
    a_, e_ = gibbs_vc(D.y, D.X, D.Z, Ainv; nu_a=4.0, S_a=2.0, nu_e=4.0, S_e=5.0,
                      niter=8_000, burn=2_000, rng=Xoshiro(1000+c))
    push!(chains_a, a_); push!(chains_h, a_ ./ (a_ .+ e_))
end
@printf("sigma2_a : R-hat = %.4f , ESS = %.0f\n", rhat(chains_a), ess(chains_a[1]))
@printf("h2       : R-hat = %.4f , ESS = %.0f\n", rhat(chains_h), ess(chains_h[1]))
println("\n判据：R-hat < 1.01 且 ESS > 400 为可接受（正文 §19.1.6）。")
println("方差组分的 MCMC 混合通常很慢（sigma2_a 与 u 强相关），需要数万次迭代。")

# 轨迹的粗略文本可视化
println("\nsigma2_a 的轨迹（每 300 步取一点，文本图）：")
tr_ = chains_a[1][1:300:end]
lo, hi = minimum(tr_), maximum(tr_)
for (i, v) in enumerate(tr_[1:min(18,end)])
    pos = round(Int, 40*(v-lo)/(hi-lo+1e-12))
    println("  ", lpad(string(i), 3), " ", " "^pos, "*", " "^(40-pos), @sprintf("%.3f", v))
end

# %% [markdown]
# ## 4　先验敏感性分析（正文 §19.1.5）

# %%
println(rpad("先验设定", 26), rpad("后验均值 h2", 16), rpad("95% 区间", 22), "说明")
println("-"^82)
for (nm, na, sa, ne, se) in (
        ("弱 (nu=3, S=文献值)",   3.0, 2.0, 3.0, 5.0),
        ("中 (nu=5, S=文献值)",   5.0, 2.0, 5.0, 5.0),
        ("强 (nu=20, S=文献值)", 20.0, 2.0,20.0, 5.0),
        ("强但错 (nu=20, S 偏大)",20.0, 6.0,20.0, 3.0),
    )
    a_, e_ = gibbs_vc(D.y, D.X, D.Z, Ainv; nu_a=na, S_a=sa, nu_e=ne, S_e=se,
                      niter=8_000, burn=2_000, rng=Xoshiro(777))
    h_ = a_ ./ (a_ .+ e_)
    @printf("%-26s%-16.4f[%.3f, %.3f]      %s\n", nm, mean(h_),
            quantile(h_,0.025), quantile(h_,0.975),
            na >= 20 ? "先验主导" : "数据主导")
end
println("\n=> 若结论随先验显著变化，说明数据信息不足，应当如实报告（正文 §19.1.5）。")

# %% [markdown]
# ## 5　GREML 与 $h^2_{\text{SNP}}$（正文 §19.2）

# %%
using Optim

"""模拟基因型并构建 VanRaden 方法 1 的 G 矩阵（第二十一章）。"""
function sim_G(n::Int, m::Int; rng=Random.default_rng())
    p = 0.05 .+ 0.45 .* rand(rng, m)
    Mg = [Float64(rand(rng) < p[j]) + Float64(rand(rng) < p[j]) for i in 1:n, j in 1:m]
    Zc = Mg .- 2 .* p'
    denom = 2*sum(p .* (1 .- p))
    return (Zc*Zc') ./ denom, Mg, p
end

"""用特征分解加速的 GREML（正文式 19.11）。"""
function greml(y::Vector{Float64}, G::Matrix{Float64}; maxiter=100)
    n = length(y)
    ev = eigen(Symmetric(G))
    lam = max.(ev.values, 1e-8); Q = ev.vectors
    yq = Q'*(y .- mean(y))
    function negll(g)
        s2g, s2e = exp(g[1]), exp(g[2])
        d = s2g .* lam .+ s2e
        return 0.5*(sum(log.(d)) + sum(yq.^2 ./ d))
    end
    res = Optim.optimize(negll, [log(var(y)/2), log(var(y)/2)], NelderMead(),
                         Optim.Options(g_tol=1e-10, iterations=10_000))
    th = exp.(Optim.minimizer(res))
    return th[1], th[2]
end

n, m = 600, 3000
G, Mg, pfreq = sim_G(n, m; rng=Xoshiro(21))
# 用全部标记作为"因果变异"（此时 h2_SNP = h2）
h2_true = 0.4
Lg = cholesky(Symmetric(G + 1e-6I)).L
g_true = Lg*randn(Xoshiro(22), n).*sqrt(h2_true)
yg = 10.0 .+ g_true .+ randn(Xoshiro(23), n).*sqrt(1-h2_true)

s2g, s2e = greml(yg, G)
@printf("真值 h2       = %.4f\n", h2_true)
@printf("GREML h2_SNP  = %.4f   (sigma2_g = %.4f , sigma2_e = %.4f)\n",
        s2g/(s2g+s2e), s2g, s2e)

# 情形二：因果变异只占标记的一部分且不在芯片上 -> h2_SNP < h2
_, Mfull, pfull = sim_G(n, m*2; rng=Xoshiro(31))
Gchip = let Z = Mfull[:, 1:m] .- 2 .* pfull[1:m]'
    (Z*Z') ./ (2*sum(pfull[1:m].*(1 .- pfull[1:m])))
end
Gcaus = let Z = Mfull[:, m+1:end] .- 2 .* pfull[m+1:end]'
    (Z*Z') ./ (2*sum(pfull[m+1:end].*(1 .- pfull[m+1:end])))
end
gc = cholesky(Symmetric(Gcaus + 1e-6I)).L*randn(Xoshiro(32), n).*sqrt(h2_true)
y2 = 10.0 .+ gc .+ randn(Xoshiro(33), n).*sqrt(1-h2_true)
s2g2, s2e2 = greml(y2, Gchip)
@printf("\n因果变异不在芯片上时：\n")
@printf("  真实 h2 = %.4f ， GREML 估计的 h2_SNP = %.4f\n", h2_true, s2g2/(s2g2+s2e2))
println("  => 差额就是「缺失的遗传力」（正文 §19.2.1）。")

# %% [markdown]
# ## 6　LD 得分回归（正文式 19.14）

# %%
"""
    ld_scores(M, p; window) -> l_j

计算每个 SNP 的 LD 得分 l_j = sum_k r2_jk（窗口内）。
"""
function ld_scores(Mg::Matrix{Float64}, p::Vector{Float64}; window::Int=100)
    n, m = size(Mg)
    Z = (Mg .- 2 .* p') ./ sqrt.(2 .* p .* (1 .- p))'
    l = zeros(m)
    for j in 1:m
        lo = max(1, j-window); hi = min(m, j+window)
        for k in lo:hi
            r = dot(Z[:,j], Z[:,k])/n
            r2 = r^2 - (1 - r^2)/(n - 2)      # 偏倚校正
            l[j] += max(r2, 0.0)
        end
    end
    return l
end

"""LDSC：chi2 对 LD 得分回归（式 19.14）。返回 (h2_hat, intercept)。"""
function ldsc(chi2::Vector{Float64}, ldsc_scores::Vector{Float64}, N::Int, M::Int)
    Xd = hcat(ones(length(chi2)), ldsc_scores)
    b = Xd \ chi2
    return b[2]*M/N, b[1]
end

# 模拟一个 GWAS：无穷小模型
nG, mG = 1500, 2000
Ggen, Mgen, pgen = sim_G(nG, mG; rng=Xoshiro(41))
h2g = 0.5
alpha = randn(Xoshiro(42), mG) .* sqrt(h2g/mG)
Zstd = (Mgen .- 2 .* pgen') ./ sqrt.(2 .* pgen .* (1 .- pgen))'
gv = Zstd*alpha
yG = gv ./ std(gv) .* sqrt(h2g) .+ randn(Xoshiro(43), nG).*sqrt(1-h2g)
yG = (yG .- mean(yG)) ./ std(yG)

# 单标记 GWAS
chi2 = [ (dot(Zstd[:,j], yG)/sqrt(nG))^2 for j in 1:mG ]
ls = ld_scores(Mgen, pgen; window=50)
h2_ldsc, icpt = ldsc(chi2, ls, nG, mG)
@printf("真值 h2            = %.4f\n", h2g)
@printf("LDSC 估计 h2       = %.4f\n", h2_ldsc)
@printf("LDSC 截距          = %.4f   <- 无分层时应接近 1\n", icpt)
@printf("平均 chi2          = %.4f\n", mean(chi2))
@printf("基因组膨胀因子 lambda_GC = %.4f\n", median(chi2)/quantile(Chisq(1), 0.5))
println("\n=> 截距接近 1 说明没有群体分层；lambda_GC > 1 只反映真实的多基因性。")
println("   这正是 LDSC 截距优于 lambda_GC 的地方（正文 §19.3.1）。")

# %% [markdown]
# ### 6.1 群体分层时截距的诊断作用

# %%
# 人为引入群体分层：两个亚群，表型与亚群相关
grp2 = vcat(fill(0.0, nG÷2), fill(1.0, nG - nG÷2))
yS = yG .+ 0.8 .* grp2
yS = (yS .- mean(yS)) ./ std(yS)
chi2S = [ (dot(Zstd[:,j], yS)/sqrt(nG))^2 for j in 1:mG ]
h2S, icptS = ldsc(chi2S, ls, nG, mG)
@printf("无分层: LDSC 截距 = %.4f , lambda_GC = %.4f , h2 = %.4f\n",
        icpt, median(chi2)/quantile(Chisq(1),0.5), h2_ldsc)
@printf("有分层: LDSC 截距 = %.4f , lambda_GC = %.4f , h2 = %.4f\n",
        icptS, median(chi2S)/quantile(Chisq(1),0.5), h2S)
println("\n=> 分层使截距显著大于 1，而 lambda_GC 无法区分分层与多基因性。")

# %% [markdown]
# ## 本章代码小结
#
# 1. **逆卡方的三种参数化**：先验抽样检验立刻暴露"漏掉 $\nu$"的错误（先验均值只有正确值的 $1/\nu$）。
# 2. **Gibbs 抽样给出完整后验**，可直接回答 "$P(h^2>0.25)$ 是多少" 这类问题，**无需 delta 法**。
# 3. **收敛诊断**：$\hat R<1.01$ 且 ESS > 400。方差组分的 MCMC 混合慢，需数万次迭代。
# 4. **先验敏感性分析是必须的**：强先验会主导结论，此时应如实报告而非选一个"好看"的先验。
# 5. **GREML 与 $h^2_{\text{SNP}}$**：当因果变异不在芯片上时，$h^2_{\text{SNP}}<h^2$，差额即"缺失的遗传力"。
# 6. **LDSC 的截距诊断群体分层**，而 $\lambda_{GC}$ 无法区分分层与真实的多基因性 —— 模拟直接演示了这一差别。
