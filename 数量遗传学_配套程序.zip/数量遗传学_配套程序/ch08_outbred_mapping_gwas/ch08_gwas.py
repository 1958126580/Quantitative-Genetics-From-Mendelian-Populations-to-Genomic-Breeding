"""第8章 远交群体连锁分析、关联定位与全基因组关联研究。

内容：半同胞家系内连锁分析；分层群体的 GWAS（简单回归、主成分校正、
混合模型 P3D/EMMAX）；基因组控制 λ；QQ 图与曼哈顿图；功效与 r^2。
运行：python ch08_gwas.py   （需要 msprime）
"""
import json, os, sys
import numpy as np
from scipy import stats, optimize

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt
import msprime

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
DATA = os.path.join(HERE, 'data'); os.makedirs(DATA, exist_ok=True)
rng = np.random.default_rng(81)
res = {}

# ---------- 1. 两个亚群的溯祖模拟 ----------
dem = msprime.Demography()
dem.add_population(name='A', initial_size=500); dem.add_population(name='B', initial_size=500)
dem.add_population(name='anc', initial_size=1000)
dem.add_population_split(time=150, derived=['A', 'B'], ancestral='anc')
nA, nB = 600, 400
G_list, chrom, pos_list = [], [], []
for c in range(10):
    ts = msprime.sim_ancestry(samples={'A': nA, 'B': nB}, demography=dem, sequence_length=1e7,
                              recombination_rate=1e-8, random_seed=100 + c)
    ts = msprime.sim_mutations(ts, rate=1.2e-8 * 4, random_seed=200 + c)
    H = ts.genotype_matrix().astype(np.int8)            # 位点 × 单倍型
    Gd = (H[:, 0::2] + H[:, 1::2]).T                    # 个体 × 位点
    f = Gd.mean(0) / 2; keep = (f > 0.05) & (f < 0.95)
    G_list.append(Gd[:, keep]); chrom += [c + 1] * keep.sum(); pos_list.append(ts.tables.sites.position[keep])
G = np.hstack(G_list).astype(float); chrom = np.array(chrom); pos = np.concatenate(pos_list)
n, m = G.shape
pop = np.array([0] * nA + [1] * nB)
p = G.mean(0) / 2
fst_num = ((G[pop == 0].mean(0) / 2 - G[pop == 1].mean(0) / 2) ** 2).mean()
res['data'] = dict(n=n, m=int(m), mean_Fst_approx=float(fst_num / np.mean(2 * p * (1 - p))))

# ---------- 2. 表型：20 个 QTL + 亚群均值差异（混杂） ----------
qtl = rng.choice(m, 20, replace=False)
beta = rng.normal(0, 1, 20)
g = G[:, qtl] @ beta; g = (g - g.mean()) / g.std() * np.sqrt(0.3)
strat = np.where(pop == 1, 0.8, 0.0)          # 环境/管理差异与亚群混杂
y = g + strat + rng.normal(0, np.sqrt(0.7), n)
y -= y.mean()

Z = (G - 2 * p) / np.sqrt(2 * p * (1 - p))
def assoc_ols(y, X0):
    """对每个 SNP 做回归 y ~ X0 + snp，返回 t 统计量与 p 值"""
    Q, _ = np.linalg.qr(X0)
    yr = y - Q @ (Q.T @ y)
    Gr = Z - Q @ (Q.T @ Z)
    ss = (Gr ** 2).sum(0)
    b = Gr.T @ yr / ss
    resid_ss = (yr ** 2).sum() - b ** 2 * ss
    df = len(y) - X0.shape[1] - 1
    se = np.sqrt(resid_ss / df / ss)
    t = b / se
    return t, 2 * stats.t.sf(np.abs(t), df), b

X0 = np.ones((n, 1))
t_naive, p_naive, _ = assoc_ols(y, X0)
# PCA
K = Z @ Z.T / m
evals, evecs = np.linalg.eigh(K); evals, evecs = evals[::-1], evecs[:, ::-1]
pcs = evecs[:, :5]
t_pca, p_pca, _ = assoc_ols(y, np.column_stack([X0, pcs]))
# 混合模型：REML 估计 delta = se2/sg2（谱分解），再 GLS（P3D/EMMAX 近似）
U, S = evecs, np.clip(evals, 0, None)
yt = U.T @ y; Xt = U.T @ X0
def neg_reml(logd):
    d = np.exp(logd); w = 1 / (S + d)
    XtWX = Xt.T @ (Xt * w[:, None]); b = np.linalg.solve(XtWX, Xt.T @ (yt * w))
    r = yt - Xt @ b; sg2 = np.sum(w * r * r) / (n - 1)
    return 0.5 * ((n - 1) * np.log(sg2) + np.sum(np.log(S + d)) + np.log(np.linalg.det(XtWX)))
opt = optimize.minimize_scalar(neg_reml, bounds=(-6, 6), method='bounded')
delta = np.exp(opt.x)
w = 1 / (S + delta); sw = np.sqrt(w)
yw = (U.T @ y) * sw; Xw = (U.T @ X0) * sw[:, None]; Zw = (U.T @ Z) * sw[:, None]
Q, _ = np.linalg.qr(Xw); yr = yw - Q @ (Q.T @ yw); Zr = Zw - Q @ (Q.T @ Zw)
ss = (Zr ** 2).sum(0); b = Zr.T @ yr / ss; rss = (yr ** 2).sum() - b ** 2 * ss
t_mm = b / np.sqrt(rss / (n - 2) / ss); p_mm = 2 * stats.t.sf(np.abs(t_mm), n - 2)
h2_snp = 1 / (1 + delta)

def lam(pv): return float(np.median(stats.chi2.isf(pv, 1)) / stats.chi2.ppf(0.5, 1))
thr = 0.05 / m
def summary(pv):
    sig = pv < thr
    near = np.zeros(m, bool)
    for q in qtl:
        near |= (chrom == chrom[q]) & (np.abs(pos - pos[q]) < 5e5)
    return dict(lambda_GC=lam(pv), n_sig=int(sig.sum()), n_sig_near_QTL=int((sig & near).sum()),
                n_sig_false=int((sig & ~near).sum()))
res['gwas'] = dict(bonferroni=thr, naive=summary(p_naive), pca5=summary(p_pca), mixed=summary(p_mm),
                   h2_snp_null=float(h2_snp), top_pc_var=float(evals[0] / evals.sum()))
# 基因组控制
chi = stats.chi2.isf(p_naive, 1) / res['gwas']['naive']['lambda_GC']
res['gwas']['gc_corrected'] = summary(stats.chi2.sf(chi, 1))
np.save(os.path.join(DATA, 'sim_genotypes_small.npy'), G[:, :2000].astype(np.int8))
np.savetxt(os.path.join(DATA, 'sim_phenotype.csv'), np.column_stack([pop, y]), fmt=['%d', '%.5f'], delimiter=',', header='subpop,y', comments='')

# ---------- 3. 半同胞家系内连锁分析（回归区间作图的嵌套模型） ----------
hc = lambda d: 0.5 * (1 - np.exp(-2 * d))
def halfsib(nsire=10, nprog=100, a=0.5, markers=np.arange(0, 101, 10), qpos=47.0, p_Q=0.5):
    """每头公畜在标记上全杂合（相位已知），QTL 杂合与否由频率决定"""
    out = []
    allpos = np.sort(np.append(markers, qpos))
    rows = []
    for s in range(nsire):
        het = rng.random() < 2 * p_Q * (1 - p_Q)
        sign = rng.choice([-1, 1])
        g = np.zeros((nprog, len(allpos)), int); g[:, 0] = rng.integers(0, 2, nprog)
        for j in range(1, len(allpos)):
            rec = rng.random(nprog) < hc((allpos[j] - allpos[j - 1]) / 100); g[:, j] = np.where(rec, 1 - g[:, j - 1], g[:, j - 1])
        kq = np.where(allpos == qpos)[0][0]
        y = (sign * a * (g[:, kq] - 0.5) if het else 0) + rng.normal(0, 1, nprog)
        mk = [np.where(allpos == mm)[0][0] for mm in markers]
        rows.append((g[:, mk], y, het))
    return rows
fam = halfsib()
grid = np.arange(0, 100.5, 1.0); markers = np.arange(0, 101, 10)
def prob_sire_allele(gm, posx):
    k = min(np.searchsorted(markers, posx, side='right') - 1, len(markers) - 2)
    c1 = hc((posx - markers[k]) / 100); c2 = hc((markers[k + 1] - posx) / 100)
    mL, mR = gm[:, k], gm[:, k + 1]
    p1 = np.where(mL == 1, 1 - c1, c1) * np.where(mR == 1, 1 - c2, c2)
    p0 = np.where(mL == 0, 1 - c1, c1) * np.where(mR == 0, 1 - c2, c2)
    return p1 / (p1 + p0)
Fprof = []
N = sum(len(f[1]) for f in fam); ns = len(fam)
for x in grid:
    rss0 = sum(np.sum((f[1] - f[1].mean()) ** 2) for f in fam); rss1 = 0
    for gm, yy, _ in fam:
        P = prob_sire_allele(gm, x); X = np.column_stack([np.ones(len(yy)), P])
        bb = np.linalg.lstsq(X, yy, rcond=None)[0]; rss1 += np.sum((yy - X @ bb) ** 2)
    Fprof.append(((rss0 - rss1) / ns) / (rss1 / (N - 2 * ns)))
Fprof = np.array(Fprof); kb = int(np.argmax(Fprof))
sire_eff = []
for gm, yy, het in fam:
    P = prob_sire_allele(gm, grid[kb]); X = np.column_stack([np.ones(len(yy)), P])
    bb, *_ = np.linalg.lstsq(X, yy, rcond=None)
    r = yy - X @ bb; se = np.sqrt(np.sum(r * r) / (len(yy) - 2) * np.linalg.inv(X.T @ X)[1, 1])
    sire_eff.append(dict(het_true=bool(het), effect=float(bb[1]), se=float(se), t=float(bb[1] / se)))
res['halfsib'] = dict(best_pos=float(grid[kb]), maxF=float(Fprof[kb]), p=float(stats.f.sf(Fprof[kb], ns, N - 2 * ns)), sires=sire_eff)

# ---------- 4. 功效与 r^2 ----------
def power(N, q2, r2, alpha=5e-8):
    ncp = N * r2 * q2 / (1 - r2 * q2); c = stats.chi2.isf(alpha, 1)
    return float(stats.ncx2.sf(c, 1, ncp))
res['power'] = {f'N={N},q2={q2},r2={r2}': power(N, q2, r2) for N in (1000, 10000, 100000) for q2 in (0.001, 0.01) for r2 in (1.0, 0.5)}

json.dump(res, open(os.path.join(OUT, 'ch08_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

# ---------------- 图 ----------------
ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
ax = axes[0]
exp_ = -np.log10((np.arange(1, m + 1) - 0.5) / m)
for pv, col, lab in [(p_naive, ps.ORANGE, '简单回归'), (p_pca, ps.GREEN, '5 个主成分校正'), (p_mm, ps.NAVY, '混合模型')]:
    ax.plot(exp_, -np.log10(np.sort(pv)), '.', ms=2, color=col, label=f'{lab}（$\\lambda$={lam(pv):.2f}）')
ax.plot([0, exp_.max()], [0, exp_.max()], color='k', lw=0.8)
ax.set_xlabel(r'期望 $-\log_{10}p$'); ax.set_ylabel(r'观察 $-\log_{10}p$')
ps.panel_title(ax, 'A', 'QQ 图：群体分层造成的膨胀'); ax.legend(markerscale=4, fontsize=8)
ax = axes[1]
ax.scatter(evecs[:, 0], evecs[:, 1], c=[ps.NAVY if k == 0 else ps.ORANGE for k in pop], s=5)
ax.set_xlabel('主成分 1'); ax.set_ylabel('主成分 2')
ps.panel_title(ax, 'B', '基因组主成分揭示两个亚群')
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig08_1_qq_pca.png')); plt.close(fig)

fig, axes = plt.subplots(2, 1, figsize=(10, 5.2), sharex=True)
offs = 0; xt = []; xpos = np.zeros(m)
for c in range(1, 11):
    idx = chrom == c; xpos[idx] = pos[idx] / 1e6 + offs; xt.append(offs + 5); offs += 10.5
for ax, pv, title in [(axes[0], p_naive, 'A  简单回归（未校正群体分层）'), (axes[1], p_mm, 'B  混合模型')]:
    cols = np.where(chrom % 2 == 0, ps.NAVY, '#8aa6c1')
    ax.scatter(xpos, -np.log10(pv), c=cols, s=2)
    ax.scatter(xpos[qtl], -np.log10(pv[qtl]), facecolors='none', edgecolors=ps.ORANGE, s=30, lw=1, label='模拟的 QTL')
    ax.axhline(-np.log10(thr), color=ps.ORANGE, ls='--', lw=1)
    ax.set_ylabel(r'$-\log_{10}p$'); ax.set_title(title, loc='left', fontweight='bold')
axes[0].legend(fontsize=8, loc='upper right')
axes[1].set_xticks(xt); axes[1].set_xticklabels([f'{c}' for c in range(1, 11)]); axes[1].set_xlabel('染色体')
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig08_2_manhattan.png')); plt.close(fig)

fig, ax = plt.subplots(figsize=(6.2, 3.6))
ax.plot(grid, Fprof, color=ps.NAVY, lw=2)
ax.axvline(47, color=ps.ORANGE, ls=':', lw=1.2); ax.text(48, Fprof.max() * 0.9, '真实 QTL', color=ps.ORANGE, fontsize=8)
for mm in markers: ax.plot([mm], [0], '^', color='k', ms=4)
ax.set_xlabel('染色体位置（cM）'); ax.set_ylabel('$F$ 统计量（公畜内嵌套）')
ax.set_title('10 头公畜、各 100 个半同胞后代的区间作图', fontsize=10.5)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig08_3_halfsib.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
