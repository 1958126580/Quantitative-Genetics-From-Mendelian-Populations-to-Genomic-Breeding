"""依次运行全部各章程序。用法：python run_all.py [章号 ...]，例如 python run_all.py 3 7 25。"""
import subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
want = {int(x) for x in sys.argv[1:]}
failed = []
for d in sorted(p for p in ROOT.iterdir() if p.is_dir() and p.name[:2] == 'ch'):
    ch = int(d.name[2:4])
    if want and ch not in want:
        continue
    scripts = sorted(d.glob('ch*.py'))
    # 第35章：full_experiments 已包含 core 与 extended，单独入口不重复运行
    if ch == 35:
        scripts = [s for s in scripts if 'core_experiment' not in s.name and 'extended_experiment' not in s.name]
    for s in scripts:
        out = d / 'results'
        out.mkdir(exist_ok=True)
        t0 = time.time()
        r = subprocess.run([sys.executable, str(s)], cwd=out, capture_output=True, text=True)
        status = '通过' if r.returncode == 0 else '失败'
        print(f'[{status}] {d.name}/{s.name}  {time.time() - t0:.1f} s')
        if r.returncode:
            failed.append(s.name)
            print(r.stderr[-1500:])
        elif s.name.endswith('leakage_control.py'):
            (out / 'leakage_control.json').write_text(r.stdout, encoding='utf-8')
print('全部完成' if not failed else f'失败：{failed}')
