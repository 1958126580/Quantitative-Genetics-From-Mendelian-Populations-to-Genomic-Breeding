"""《数量遗传学——从孟德尔群体到基因组育种》第17章 推导与算例数值复核

复核内容：约束指数的 KKT 条件与对偶、标准化响应、稳健锥响应、CVaR 权重与矩约束界。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch17_derivation_checks.py
输出：results/ch17_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch17_derivation_checks.json'
results = {}


def close(a, b):
    assert np.allclose(a, b, rtol=1e-7, atol=1e-8), (a, b)


# 第17章：KKT, normalized responses, robust cone, CVaR and moment bounds.
P17=np.diag([2.,1.]);g17=np.array([2.,1.]);b17=np.array([1.,.3]);lam=.7
close(P17@b17-g17+np.array([0.,lam]),[0,0])
f=lambda b:.5*b@P17@b-g17@b
close(f(b17)-f(np.ones(2)),.245)
dual=-.5*(g17-np.array([0.,lam]))@np.linalg.solve(P17,g17-np.array([0.,lam]))-lam*.3
close(dual,f(b17))
resp03=2*np.sqrt(1-.3**2)+.3;resp06=2*np.sqrt(1-.6**2)+.6
robust=1.8/np.sqrt(1.04)
loss=np.array([-4.,0.,2.,10.]);probs=np.array([.1,.2,.5,.2]);qtail=np.array([0.,0.,1/3,2/3])
close(probs@loss,2.6);close(qtail@loss,22/3)
assert np.all(qtail<=probs/.3+1e-12);close(sum(qtail),1.)
single=np.array([-.4,-.2])+np.sqrt(19)*np.array([.1,.05])
combo0=-.3+np.sqrt(19)*np.sqrt(.003125)
combo8=-.3+np.sqrt(19)*np.sqrt(.005125)
assert np.all(single>0) and combo0<0 and combo8>0
results['17']={'KKT_weights':b17.tolist(),'KKT_multiplier':lam,'quadratic_loss':f(b17)-f(np.ones(2)),
'dual_gap':f(b17)-dual,'responses_d03_d06':[resp03,resp06],
'robust_cone_response':robust,'CVaR_07':float(qtail@loss),'CVaR_weights':qtail.tolist(),
'moment_coefficient':float(np.sqrt(19)),'required_sd':float(.3/np.sqrt(19)),
'moment_single_bounds':single.tolist(),'moment_combo_bounds':[combo0,combo8],'status':'PASS'}

OUT_FILE.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
assert all(v['status'] == 'PASS' for v in results.values())
print(f'第17章：共 {len(results)} 项复核全部通过')
