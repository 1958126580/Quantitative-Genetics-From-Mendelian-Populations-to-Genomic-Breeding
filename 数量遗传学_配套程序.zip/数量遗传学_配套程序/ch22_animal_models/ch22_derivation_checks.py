"""《数量遗传学——从孟德尔群体到基因组育种》第22章 推导与算例数值复核

复核内容：投影观测核可识别性、母体效应条件协方差、社会网络效应、状态预测、正反交系数与设计增益。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch22_derivation_checks.py
输出：results/ch22_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch22_derivation_checks.json'
records = []


def check(name, actual, expected, atol=1e-9, rtol=1e-8):
    a, b = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
    error = float(np.max(np.abs(a - b)))
    passed = bool(np.allclose(a, b, atol=atol, rtol=rtol))
    records.append({"name": name, "passed": passed,
                    "actual": a.tolist(), "expected": b.tolist(),
                    "max_absolute_error": error})
    if not passed:
        raise AssertionError(records[-1])


# 第22章：identifiable observation kernels, origin effects and designs.
for m, expected_rank in [(2, 2), (3, 3)]:
    Z = np.repeat(np.eye(m), 2, axis=0)
    A = np.eye(m)
    A[0, 1] = A[1, 0] = .5
    J = np.eye(2 * m) - np.ones((2 * m, 2 * m)) / (2 * m)
    kernels = [J @ Z @ A @ Z.T @ J, J @ Z @ Z.T @ J, J]
    cols = np.stack([x.ravel() for x in kernels], axis=1)
    check(f"22.18 residual kernel rank with {m} mothers",
          np.linalg.matrix_rank(cols), expected_rank)
    if m == 2:
        check("22.18 exact proportional projected kernels", kernels[0],
              .5 * kernels[1])
    else:
        check("22.18 projected Gram eigenvalues",
              np.linalg.eigvalsh(cols.T @ cols),
              [.49875807, 2.61997154, 16.32571483], atol=6e-9)
genetic = np.array([[9., -3.], [-3., 4.]])
transform = np.array([[1., 0.], [1 / 3, 1.]])
check("22.19 orthogonal conditional covariance",
      transform @ genetic @ transform.T, np.diag([9., 3.]))
check("22.19 weighted total variance", np.array([1, 2]) @ genetic @ [1, 2], 13)
check("22.19 offspring maternal variance", 9 + 4 + 2 * .5 * (-3), 10)
Wnet = np.array([[0, .5, .5], [1, 0, 0], [0, 1, 0.]])
social = np.array([.5, -.4, .8])
qnet = Wnet.sum(axis=0)
check("22.20 network received phenotype", np.ones(3) + Wnet @ social, [1.2, 1.5, .6])
check("22.20 network output contribution", np.ones(3) + qnet * social, [1.5, .4, 1.4])
check("22.20 network total identity", (np.ones(3) + Wnet @ social).sum(),
      (np.ones(3) + qnet * social).sum())
check("22.20 contribution variances", 4 - qnet + qnet ** 2, [4, 4.75, 3.75])
check("22.20 simultaneous feedback",
      np.linalg.solve(np.eye(3) - .2 * Wnet, np.ones(3)), [1.25] * 3)
check("22.21 total state prediction and variance", [10 / 12 * 6, 10 - 100 / 12],
      [5, 5 / 3])
check("22.21 genetic endpoint predictions", [2 / 12 * 6, 6 / 12 * 6], [1, 3])
Xcross = np.array([[1, 1, 1, 0], [1, 0, 0, 0],
                   [1, .5, 0, 1], [1, .5, 1, 1.]])
coef = np.linalg.solve(Xcross, [12, 8, 13, 15])
check("22.22 reciprocal cross coefficients", coef, [8, 2, 2, 4])
check("22.22 backcross extrapolation", np.array([1, .75, .5, .5]) @ coef, 12.5)
Cdesign, h = np.array([[4., -1.5], [-1.5, 2.]]), np.array([1., 2.])
gains = []
for z in [np.array([1, 0]), np.array([0, 1]), np.array([1, 1])]:
    Cnew = Cdesign - np.outer(Cdesign @ z, Cdesign @ z) / (z @ Cdesign @ z + 1)
    gains.append(h @ Cdesign @ h - h @ Cnew @ h)
check("22.23 three design gains", gains, [.2, 25 / 12, 49 / 16])


result = {"status": "passed", "chapter": 22, "check_count": len(records), "checks": records,
          "conditions": "Synthetic teaching experiments; no empirical animal validation claimed."}
OUT_FILE.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第22章：共 {len(records)} 项复核全部通过')
