"""第5章 二基因座群体模型与连锁不平衡：单倍型 EM、LD 度量、衰减与漂变—重组平衡。

运行：python ch05_ld.py   （需要 msprime 用于溯祖模拟）
"""
import json, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
DATA = os.path.join(HERE, 'data')
res = {}

def ld_measures(r, s, t, u):
    """单倍型频率 A1B1=r, A1B2=s, A2B1=t, A2B2=u"""
    pA = r + s; pB = r + t
    D = r * u - s * t
    Dmax = min(pA * (1 - pB), (1 - pA) * pB) if D > 0 else min(pA * pB, (1 - pA) * (1 - pB))
    r2 = D * D / (pA * (1 - pA) * pB * (1 - pB))
    return dict(pA=pA, pB=pB, D=D, Dprime=D / Dmax, r2=r2)

# 1. 课堂例：r=0.4, pA=pB=0.5
res['example'] = ld_measures(0.4, 0.1, 0.1, 0.4)

# 2. 单倍型频率 EM（200 个个体的两位点基因型）
rows = [l.split(',') for l in open(os.path.join(DATA, 'two_locus_genotypes.csv')).read().split()[1:]]
cnt = {r[0]: int(r[1]) for r in rows}
N = sum(cnt.values())
# 计数确定单倍型（双杂合除外）
def known_haps(g):
    a1, a2, b1, b2 = g[1], g[3], g[5], g[7]
    return (a1, b1), (a2, b2)
hap_index = {('1', '1'): 0, ('1', '2'): 1, ('2', '1'): 2, ('2', '2'): 3}
fixed = np.zeros(4); dh = 0
for g, c in cnt.items():
    a = sorted([g[1], g[3]]); b = sorted([g[5], g[7]])
    if a[0] != a[1] and b[0] != b[1]:
        dh = c; continue
    # 至多一个杂合位点时相位确定
    h1 = (a[0], b[0]); h2 = (a[1], b[1])
    fixed[hap_index[h1]] += c; fixed[hap_index[h2]] += c
# 简单方法：双杂合等分到两种相位
simple = (fixed + dh * 0.5 * np.ones(4)) / (2 * N)
h = np.array([0.25, 0.25, 0.25, 0.25]); trace = [h.copy()]
for it in range(100):
    r, s, t, u = h
    w = r * u / (r * u + s * t)        # 双杂合为 A1B1/A2B2 的概率
    newc = fixed + dh * np.array([w, 1 - w, 1 - w, w])
    h = newc / (2 * N); trace.append(h.copy())
    if np.abs(trace[-1] - trace[-2]).sum() < 1e-12: break
res['haplotype_em'] = dict(N=N, double_het=dh, simple=simple.tolist(), simple_ld=ld_measures(*simple),
                           em=h.tolist(), em_ld=ld_measures(*h), iterations=len(trace) - 1,
                           p_coupling=float(h[0] * h[3] / (h[0] * h[3] + h[1] * h[2])), trace=[x.tolist() for x in trace[:6]])
# 基因型相关（复合 LD）
gA = []; gB = []
for g, c in cnt.items():
    xa = (g[1] == '1') + (g[3] == '1'); xb = (g[5] == '1') + (g[7] == '1')
    gA += [xa] * c; gB += [xb] * c
res['genotype_r2'] = float(np.corrcoef(gA, gB)[0, 1] ** 2)

# 3. D 的衰减
gens = np.arange(0, 31)
decay = {c: (1 - c) ** gens for c in [0.5, 0.2, 0.05, 0.01]}
res['decay_half_life'] = {str(c): float(np.log(0.5) / np.log(1 - c)) for c in [0.5, 0.2, 0.05, 0.01]}

# 4. 漂变—重组平衡：Sved 期望与溯祖模拟
try:
    import msprime
    Ne = 100; L = 2e7  # 20 Mb，重组率 1e-8 /bp/代 => 0.2 Morgan
    ts = msprime.sim_ancestry(samples=200, population_size=Ne, sequence_length=L, recombination_rate=1e-8, random_seed=7)
    ts = msprime.sim_mutations(ts, rate=2.5e-7, random_seed=8)
    G = ts.genotype_matrix().astype(float)  # 位点 × 单倍型
    pos = ts.tables.sites.position
    maf = G.mean(1); keep = (maf > 0.05) & (maf < 0.95)
    G = G[keep]; pos = pos[keep]
    rng = np.random.default_rng(1)
    idx = rng.choice(len(pos), size=min(1500, len(pos)), replace=False); idx.sort()
    G = G[idx]; pos = pos[idx]
    C = np.corrcoef(G)
    iu = np.triu_indices(len(pos), 1)
    dist_M = (pos[iu[1]] - pos[iu[0]]) * 1e-8
    r2 = C[iu] ** 2
    bins = np.linspace(0, 0.2, 21)
    mids = 0.5 * (bins[1:] + bins[:-1]); mean_r2 = []
    for i in range(20):
        m = (dist_M >= bins[i]) & (dist_M < bins[i + 1]); mean_r2.append(float(r2[m].mean()))
    nhap = G.shape[1]
    sved = 1 / (1 + 4 * Ne * mids) + 1 / nhap
    res['sved'] = dict(Ne=Ne, n_snps=int(len(pos)), dist_cM=(mids * 100).tolist(), mean_r2=mean_r2, sved_expect=sved.tolist())
    ld_ok = True
    sub = rng.choice(len(r2), 15000, replace=False)
    sc_d, sc_r2 = dist_M[sub], r2[sub]
except Exception as e:
    print('msprime 不可用：', e); ld_ok = False

# 5. 杂交 F2 与远交群体：不连锁位点的 LD
c = np.linspace(0, 0.5, 51)
res['F1_gamete_D'] = {'c=0.1': (1 - 2 * 0.1) / 4, 'c=0.5': 0.0}

# 6. 混合产生的 LD
c1 = c2 = 0.5; pa1, pa2, pb1, pb2 = 0.9, 0.1, 0.8, 0.2
res['admixture_D'] = c1 * c2 * (pa1 - pa2) * (pb1 - pb2)

json.dump(res, open(os.path.join(OUT, 'ch05_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
ax = axes[0]
for (cc, d), col in zip(decay.items(), ps.PALETTE):
    ax.plot(gens, d, '-o', ms=2.5, color=col, label=f'$c={cc}$')
ax.set_xlabel('随机交配世代 $t$'); ax.set_ylabel('$D_t/D_0=(1-c)^t$')
ps.panel_title(ax, 'A', '重组使连锁不平衡按几何速率衰减')
ax.legend()
ax = axes[1]
if ld_ok:
    ax.scatter(sc_d * 100, sc_r2, s=2, color=ps.LIGHT, edgecolors='none', label='SNP 对（随机抽取）')
    ax.plot(np.array(res['sved']['dist_cM']), res['sved']['mean_r2'], 'o-', color=ps.NAVY, ms=4, label='各距离区间平均 $r^2$')
    dd = np.linspace(0.001, 0.2, 200)
    ax.plot(dd * 100, 1 / (1 + 4 * Ne * dd) + 1 / nhap, '--', color=ps.ORANGE, lw=1.6, label=r'Sved：$1/(1+4N_ec)+1/n$')
    ax.plot(dd * 100, 1 / (1 + 4 * 1000 * dd), ':', color=ps.GREEN, lw=1.6, label=r'$N_e=1000$ 时的期望')
    ax.set_ylim(0, 0.6)
ax.set_xlabel('标记间距离（cM）'); ax.set_ylabel('$r^2$')
ps.panel_title(ax, 'B', '漂变—重组平衡下的 LD 随距离衰减（$N_e=100$）')
ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig05_1_ld_decay.png')); plt.close(fig)
print(json.dumps({k: v for k, v in res.items() if k != 'sved'}, ensure_ascii=False, indent=1, default=float))
if ld_ok: print(res['sved'])
