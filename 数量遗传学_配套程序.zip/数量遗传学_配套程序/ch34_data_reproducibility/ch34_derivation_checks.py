"""《数量遗传学——从孟德尔群体到基因组育种》第34章 推导与算例数值复核

复核内容：分块更新与删除诊断、相关信息量、身份混合方差分解与修订归因的 Shapley 值。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch34_derivation_checks.py
输出：results/ch34_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch34_derivation_checks.json'


def close(a, b, tol=1e-10):
    assert np.max(np.abs(np.asarray(a) - np.asarray(b))) < tol


out = {}
C = np.array([[2.0, .5], [.5, 1.0]])
m = np.array([1.0, 0.0])
k = C[:, 0]
s = C[0, 0] + 1
new_m = m + k / s * (4 - m[0])
new_C = C - np.outer(k, k) / s
close(new_m, [3, .5])
close(new_C, [[2/3, 1/6], [1/6, 11/12]])
a = np.array([1., -1.])
out['34_block_update'] = {
    'mean': new_m.tolist(), 'covariance': new_C.tolist(),
    'old_contrast_pev': float(a @ C @ a),
    'new_contrast_pev': float(a @ new_C @ a)}
J = np.diag([1., 1.])
X = np.array([[1., 0.], [1., 1.], [0., 1.]])
y = np.array([2., 4., 1.])
H = J + X.T @ X
P = np.linalg.inv(H)
mu = P @ X.T @ y
i = 1
v = X[i]
h = float(v @ P @ v)
res = float(y[i] - v @ mu)
deleted = mu - P @ v * res / (1-h)
keep = [0, 2]
direct = np.linalg.solve(J+X[keep].T@X[keep], X[keep].T@y[keep])
close(deleted, direct)
out['34_deletion'] = {'full_mean':mu.tolist(), 'hat':h,
    'residual':res, 'deleted':deleted.tolist()}
R = np.array([[4., 2.], [2., 4.]])
one = np.ones(2)
info = float(one @ np.linalg.solve(R, one))
out['34_information'] = {'information': info, 'variance': 1/info,
    'effective_n_relative_variance4': 4*info,
    'nuisance_adjusted_information':5-4*4/4,
    'independent_two_posterior_variance':1/(1+2/4),
    'correlated_two_posterior_variance':1/(1+info)}
weights=np.array([.75,.25])
means=np.array([[1.,0.],[0.,1.]])
covs=np.array([np.diag([.5,1.]),np.diag([1.,.5])])
mix_mean=weights@means
within=np.einsum('k,kij->ij',weights,covs)
between=sum(w*np.outer(t-mix_mean,t-mix_mean)
            for w,t in zip(weights,means))
out['34_identity_mixture']={'mean':mix_mean.tolist(),
    'within':within.tolist(),'between':between.tolist(),
    'total':(within+between).tolist()}
out['34_revision_attribution']={'old':2/4,'new':4/2,
    'data_shapley':((4/4-2/4)+(4/2-2/2))/2,
    'parameter_shapley':((2/2-2/4)+(4/2-4/4))/2}


OUT_FILE.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第34章：共 {len(out)} 项复核全部通过')
