"""第3章 统计推断、似然与线性模型基础：全部数值例题与插图。

运行：python ch03_inference.py
输出：results/ 下的数值结果 JSON 与图形 PNG。
"""
import json, os, sys
import numpy as np
from scipy import stats, optimize

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
DATA = os.path.join(HERE, 'data')
res = {}

# ---------- 1. 身高体重：矩估计、回归与准确度 ----------
hw = np.loadtxt(os.path.join(DATA, 'height_weight.csv'), delimiter=',', skiprows=1)
h, w = hw[:, 1], hw[:, 2]
n = len(h)
cov_pop = np.mean((h - h.mean()) * (w - w.mean()))
b = cov_pop / np.var(h)
r = np.corrcoef(h, w)[0, 1]
res['height_weight'] = dict(mean_h=h.mean(), mean_w=w.mean(), var_h_pop=np.var(h), var_h_smp=np.var(h, ddof=1),
                            var_w_pop=np.var(w), var_w_smp=np.var(w, ddof=1), cov_pop=cov_pop,
                            cov_smp=cov_pop * n / (n - 1), b=b, r=r, r2=r ** 2,
                            pred_180=w.mean() + b * (180 - h.mean()),
                            se_b=np.sqrt(np.sum((w - w.mean() - b * (h - h.mean())) ** 2) / (n - 2) / np.sum((h - h.mean()) ** 2)))

# ---------- 2. 两位点基因型联合分布 ----------
J = np.array([[0.10, 0.04, 0.02], [0.14, 0.18, 0.16], [0.06, 0.10, 0.20]])  # 行 aa,Aa,AA；列 bb,Bb,BB
x = np.array([0, 1, 2])
pA = J.sum(1); pB = J.sum(0)
EX = x @ pA; EY = x @ pB
EXY = x @ J @ x
VX = (x ** 2) @ pA - EX ** 2; VY = (x ** 2) @ pB - EY ** 2
res['joint'] = dict(EX=EX, EY=EY, EXY=EXY, cov=EXY - EX * EY, VX=VX, VY=VY, corr=(EXY - EX * EY) / np.sqrt(VX * VY),
                    p_Aa_given_BB=J[1, 2] / pB[2], E_X_given_BB=(x @ J[:, 2]) / pB[2])

# ---------- 3. ABO 血型 EM 算法 ----------
nA, nB, nAB, nO = 725, 258, 72, 1073
N = nA + nB + nAB + nO

def loglik_abo(p):
    a, b_, o = p
    return (nA * np.log(a * a + 2 * a * o) + nB * np.log(b_ * b_ + 2 * b_ * o) + nAB * np.log(2 * a * b_) + nO * np.log(o * o))

p = np.array([1 / 3, 1 / 3, 1 / 3])
trace = [p.copy()]; lls = [loglik_abo(p)]
for it in range(30):
    a, b_, o = p
    nAA = nA * a * a / (a * a + 2 * a * o); nAO = nA - nAA
    nBB = nB * b_ * b_ / (b_ * b_ + 2 * b_ * o); nBO = nB - nBB
    pa = (2 * nAA + nAO + nAB) / (2 * N)
    pb = (2 * nBB + nBO + nAB) / (2 * N)
    p = np.array([pa, pb, 1 - pa - pb])
    trace.append(p.copy()); lls.append(loglik_abo(p))
    if np.abs(trace[-1] - trace[-2]).sum() < 1e-12:
        break
trace = np.array(trace)
# 观测信息与标准误（数值二阶导，自由参数 pA,pB）
f2 = lambda t: -loglik_abo([t[0], t[1], 1 - t[0] - t[1]])
th = trace[-1][:2]
eps = 1e-5
H = np.zeros((2, 2))
for i in range(2):
    for j in range(2):
        e_i = np.eye(2)[i] * eps; e_j = np.eye(2)[j] * eps
        H[i, j] = (f2(th + e_i + e_j) - f2(th + e_i - e_j) - f2(th - e_i + e_j) + f2(th - e_i - e_j)) / (4 * eps * eps)
V = np.linalg.inv(H)
# 拟合优度
pa, pb, po = trace[-1]
expct = N * np.array([pa * pa + 2 * pa * po, pb * pb + 2 * pb * po, 2 * pa * pb, po * po])
obs = np.array([nA, nB, nAB, nO])
chi2 = np.sum((obs - expct) ** 2 / expct)
G2 = 2 * np.sum(obs * np.log(obs / expct))
res['abo'] = dict(iterations=len(trace) - 1, pA=pa, pB=pb, pO=po, se_pA=np.sqrt(V[0, 0]), se_pB=np.sqrt(V[1, 1]),
                  cov_AB=V[0, 1], expected=expct.tolist(), chi2=chi2, G2=G2, df=1, p_chi2=1 - stats.chi2.cdf(chi2, 1),
                  trace=trace[:8].tolist(), loglik=lls[:8])
# 收敛速率：误差比
err = np.abs(trace[:-1, 0] - trace[-1, 0])
res['abo']['rate'] = (err[3:7] / err[2:6]).tolist()

# ---------- 4. 二项比例的似然、LRT、LOD 与 Wald ----------
k, m = 30, 100  # 100 个配子中 30 个重组型
c_hat = k / m
ll = lambda c: k * np.log(c) + (m - k) * np.log(1 - c)
LRT = 2 * (ll(c_hat) - ll(0.5))
LOD = (ll(c_hat) - ll(0.5)) / np.log(10)
se = np.sqrt(c_hat * (1 - c_hat) / m)
# 似然区间（LOD 下降 1 及卡方 3.84）
g = lambda c, drop: ll(c) - ll(c_hat) + drop
lo95 = optimize.brentq(g, 1e-6, c_hat, args=(3.841459 / 2,)); hi95 = optimize.brentq(g, c_hat, 0.5 - 1e-9 + 0.4999, args=(3.841459 / 2,))
lo1 = optimize.brentq(g, 1e-6, c_hat, args=(np.log(10),)); hi1 = optimize.brentq(g, c_hat, 0.999, args=(np.log(10),))
res['binomial'] = dict(c_hat=c_hat, LRT=LRT, LOD=LOD, p=1 - stats.chi2.cdf(LRT, 1), se=se,
                       wald95=[c_hat - 1.96 * se, c_hat + 1.96 * se], lik95=[lo95, hi95], lod1=[lo1, hi1])

# ---------- 5. 方差分析：单因素随机模型的期望均方 ----------
rng = np.random.default_rng(20261001)
s, nn = 40, 8
sig_s2, sig_e2 = 0.25, 0.75
y = rng.normal(0, np.sqrt(sig_s2), s)[:, None] + rng.normal(0, np.sqrt(sig_e2), (s, nn))
ssb = nn * np.sum((y.mean(1) - y.mean()) ** 2); ssw = np.sum((y - y.mean(1, keepdims=True)) ** 2)
msb = ssb / (s - 1); msw = ssw / (s * (nn - 1))
s2s = (msb - msw) / nn
t = s2s / (s2s + msw)
# 区间（基于F分布的组内相关精确区间）
F = msb / msw
Fl, Fu = stats.f.ppf([0.975, 0.025], s - 1, s * (nn - 1))
tl = (F / Fl - 1) / (F / Fl - 1 + nn); tu = (F / Fu - 1) / (F / Fu - 1 + nn)
res['anova'] = dict(MSB=msb, MSW=msw, sigma_s2=s2s, t=t, F=F, p=1 - stats.f.cdf(F, s - 1, s * (nn - 1)), t_CI=[tl, tu])

# ---------- 6. Delta 方法与自助法：亲子回归遗传力 ----------
npairs = 200; h2 = 0.4
Gp = rng.normal(0, np.sqrt(h2), npairs); Pp = Gp + rng.normal(0, np.sqrt(1 - h2), npairs)
Go = 0.5 * Gp + rng.normal(0, np.sqrt(0.75 * h2), npairs); Po = Go + rng.normal(0, np.sqrt(1 - h2), npairs)
bop = np.cov(Po, Pp)[0, 1] / np.var(Pp, ddof=1)
resid = Po - Po.mean() - bop * (Pp - Pp.mean())
se_b = np.sqrt(np.sum(resid ** 2) / (npairs - 2) / np.sum((Pp - Pp.mean()) ** 2))
boot = []
for _ in range(2000):
    idx = rng.integers(0, npairs, npairs)
    boot.append(2 * np.cov(Po[idx], Pp[idx])[0, 1] / np.var(Pp[idx], ddof=1))
res['parent_offspring'] = dict(b=bop, h2=2 * bop, se_h2_analytic=2 * se_b, se_h2_boot=float(np.std(boot, ddof=1)),
                               boot_CI=np.percentile(boot, [2.5, 97.5]).tolist())

# ---------- 7. 多重检验：Bonferroni、BH 与 q 值 ----------
M, M1 = 10000, 200
z = rng.normal(0, 1, M); z[:M1] += rng.normal(3.5, 0.6, M1)
pv = 2 * stats.norm.sf(np.abs(z))
alpha = 0.05
bonf = pv < alpha / M
order = np.argsort(pv); ps_ = pv[order]
crit = alpha * np.arange(1, M + 1) / M
kmax = np.max(np.where(ps_ <= crit)[0]) + 1 if np.any(ps_ <= crit) else 0
bh = np.zeros(M, bool); bh[order[:kmax]] = True
lam = 0.5
pi0 = np.mean(pv > lam) / (1 - lam)
truth = np.zeros(M, bool); truth[:M1] = True
res['multiple'] = dict(M=M, M1=M1, bonf_n=int(bonf.sum()), bonf_true=int((bonf & truth).sum()),
                       bh_n=int(bh.sum()), bh_false=int((bh & ~truth).sum()), bh_fdp=float((bh & ~truth).sum() / max(1, bh.sum())),
                       pi0_hat=pi0, raw005=int((pv < 0.05).sum()), raw005_false=int(((pv < 0.05) & ~truth).sum()))

json.dump(res, open(os.path.join(OUT, 'ch03_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

# ---------- 图 3.1：ABO 似然曲面与 EM 轨迹 ----------
ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
ax = axes[0]
A_, B_ = np.meshgrid(np.linspace(0.12, 0.30, 220), np.linspace(0.04, 0.14, 220))
Z = np.full(A_.shape, np.nan)
for i in range(A_.shape[0]):
    for j in range(A_.shape[1]):
        o = 1 - A_[i, j] - B_[i, j]
        Z[i, j] = loglik_abo([A_[i, j], B_[i, j], o])
Z = Z - np.nanmax(Z)
cs = ax.contour(A_, B_, Z, levels=[-40, -20, -10, -5, -2, -0.5], colors=ps.GREY, linewidths=0.7)
ax.clabel(cs, fontsize=7, fmt='%g')
tr = trace[1:]
ax.plot(tr[:, 0], tr[:, 1], '-o', color=ps.ORANGE, ms=4, lw=1.2, label='EM 迭代轨迹（自第1步）')
ax.plot(pa, pb, '*', color=ps.NAVY, ms=12, label='最大似然估计')
ax.set_xlabel('$p_A$'); ax.set_ylabel('$p_B$')
ps.panel_title(ax, 'A', 'ABO 血型频率的对数似然轮廓')
ax.legend(loc='upper right')
ax = axes[1]
lls_arr = np.array(lls)
d = lls_arr[-1] - lls_arr[:-1]; keep = d > 1e-10
ax.semilogy(np.arange(len(d))[keep], d[keep], '-o', color=ps.NAVY, ms=4)
ax.set_xlabel('迭代次数'); ax.set_ylabel('与最大对数似然之差（对数尺度）')
ps.panel_title(ax, 'B', 'EM 的单调上升与线性收敛')
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig03_1_em_abo.png')); plt.close(fig)

# ---------- 图 3.2：多重检验 ----------
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
ax = axes[0]
ax.hist(pv, bins=40, color=ps.LIGHT, edgecolor=ps.NAVY, lw=0.6)
ax.axhline(pi0 * M / 40, color=ps.ORANGE, ls='--', lw=1.2, label=r'$\hat\pi_0 M/40$（零假设的均匀高度）')
ax.set_xlabel('$p$ 值'); ax.set_ylabel('位点数')
ps.panel_title(ax, 'A', '一万次检验的 $p$ 值分布')
ax.legend()
ax = axes[1]
kk = np.arange(1, 801)
ax.plot(kk, -np.log10(ps_[:800]), '.', color=ps.NAVY, ms=2.5, label='排序后的 $p_{(k)}$')
ax.plot(kk, -np.log10(crit[:800]), color=ps.ORANGE, lw=1.3, label=r'BH 界限 $\alpha k/M$')
ax.axhline(-np.log10(alpha / M), color=ps.GREEN, ls='--', lw=1.1, label='Bonferroni 界限')
ax.axvline(kmax, color=ps.GREY, ls=':', lw=1)
ax.set_xlabel('排序位置 $k$'); ax.set_ylabel(r'$-\log_{10} p$')
ps.panel_title(ax, 'B', '错误发现率控制的阶梯规则')
ax.legend()
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig03_2_multiple_testing.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float)[:6000])
