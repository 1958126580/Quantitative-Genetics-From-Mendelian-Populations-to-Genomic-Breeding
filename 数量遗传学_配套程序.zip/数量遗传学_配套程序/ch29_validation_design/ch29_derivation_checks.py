"""《数量遗传学——从孟德尔群体到基因组育种》第29章 推导与算例数值复核

复核内容：LR 法条件/无条件二次型矩（含合成蒙特卡洛）、不等家系有效数、LD 迁移风险与局部适应收缩。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch29_derivation_checks.py
输出：results/ch29_derivation_checks.json
"""
from pathlib import Path
import json
import math
import numpy as np
from numpy.testing import assert_allclose as eq

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch29_derivation_checks.json'
results = {}


def save(name, value):
    if isinstance(value, np.ndarray): value = value.tolist()
    results[name] = value


# 第29章：conditional LR, unconditional quadratic-form moments and clustered weights
n=4;J=np.eye(n)-np.ones((n,n))/n;f=np.array([-1,-1,1,1.]);Vd=.2*np.eye(n)+.3*np.ones((n,n))
slopevar=f@J@Vd@J@f/(f@J@f)**2;meanvar=np.ones(n)@Vd@np.ones(n)/n**2
eq(slopevar,.05);eq(meanvar,.35)
save("29.16_LR_conditional",{"slope_SE":math.sqrt(slopevar),"mean_SE":math.sqrt(meanvar)})
mom=[]
for n in [3,21]:
    J=np.eye(n)-np.ones((n,n))/n;Vf=.4*np.eye(n)+.2*np.ones((n,n));Vd=.3*np.eye(n)+.1*np.ones((n,n));Vu=Vf+Vd+.5*np.eye(n)
    en=np.trace(J@Vf)/(n-1);vn=(2*np.trace(J@Vf@J@Vf)+np.trace(J@Vd@J@Vf))/(n-1)**2
    vt=np.trace(J@Vu)/(n-1)
    eq(en,.4);eq(vt,1.2);eq(vn,.44/(n-1))
    mom.append({"n":n,"E_N":float(en),"Var_N":float(vn),"SD_reliability":float(math.sqrt(vn)/vt)})
save("29.17_LR_unconditional",mom)
# independent Monte Carlo: synthetic Gaussian orthogonal innovation, n=3
rng=np.random.default_rng(13616);nn=200000;n=3;J=np.eye(3)-np.ones((3,3))/3
ff=rng.normal(size=(nn,3))*math.sqrt(.4)+rng.normal(size=(nn,1))*math.sqrt(.2)
dd=rng.normal(size=(nn,3))*math.sqrt(.3)+rng.normal(size=(nn,1))*math.sqrt(.1)
nstat=np.einsum("bi,ij,bj->b",ff,J,ff+dd)/2
assert abs(nstat.mean()-.4)<.006 and abs(nstat.var()-.22)<.006
save("29.17_synthetic_monte_carlo",{"draws":nn,"seed":13616,"mean":float(nstat.mean()),"variance":float(nstat.var())})
vmean=.5/10+.5*(2**2+8**2)/100
eq(vmean,.39);eq(.25*(.5+.5/2+.5+.5/8),.328125)
save("29.18_unequal_families",{"animal_mean_variance_ratio":vmean,"effective_n":1/vmean,"family_mean_variance_ratio":.328125})
eq((1-.2**2)+(.8-(-.2))**2,1.96)
save("29.19_LD_migration",{"source_risk":.36,"target_optimal_linear_risk":.96,"transferred_risk":1.96})
w=.09/(.09+.04);bb=(1-w)*1+w*.2;pv=.09*.04/.13;risk=(1-w)**2*.8**2+w*w*.04
eq(bb,.446153846153846);eq(pv,.0276923076923077);eq(risk,.0797633136094675)
save("29.20_local_adaptation",{"weight":w,"mean":bb,"internal_variance":pv,"actual_MSE":risk,"benefit_threshold":(1+w)/(1-w)*.04})


n_checks = len(results)
results["status"] = "passed"
results["scope"] = "Independent synthetic mathematical checks only; no empirical animal data or document dependencies."
OUT_FILE.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第29章：共 {n_checks} 项复核全部通过')
