"""《数量遗传学——从孟德尔群体到基因组育种》第9章 推导与算例数值复核

复核内容：剂量回归的加性/剩余方差分解、两位点上位方差、连锁不平衡下的边际/偏回归与迁移误差、选择响应与传递差。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch09_derivation_checks.py
输出：results/ch09_derivation_checks.json
"""
from fractions import Fraction as F
from pathlib import Path
import json
import math

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch09_derivation_checks.json'
results = []


def check(name, actual, expected, tol=1e-10):
    assert math.isclose(float(actual), float(expected), rel_tol=tol, abs_tol=tol), (name, actual, expected)
    results.append({'name': name, 'actual': float(actual), 'expected': float(expected), 'passed': True})


def avg(values, probs):
    return sum(v*p for v,p in zip(values,probs))

def variance(values, probs):
    m=avg(values,probs)
    return avg([(v-m)**2 for v in values],probs)

def covariance(x,y,probs):
    mx,my=avg(x,probs),avg(y,probs)
    return avg([(a-mx)*(b-my) for a,b in zip(x,y)],probs)

x=[F(0),F(1),F(2)]
g=[F(0),F(1),F(4)]
probs=[F(1,2),F(1,5),F(3,10)]
check('9.18 dose mean',avg(x,probs),F(4,5))
check('9.18 dose variance',variance(x,probs),F(19,25))
check('9.18 genotype mean',avg(g,probs),F(7,5))
check('9.18 covariance',covariance(x,g,probs),F(37,25))
slope=covariance(x,g,probs)/variance(x,probs)
check('9.18 slope',slope,F(37,19))
res=[yi-(-F(3,19)+slope*xi) for xi,yi in zip(x,g)]
check('9.18 residual mean',avg(res,probs),0)
check('9.18 residual orthogonality',covariance(x,res,probs),0)
check('9.18 genotype variance',variance(g,probs),F(76,25))
check('9.18 additive variance',slope*slope*variance(x,probs),F(1369,475))
check('9.18 residual variance',variance(res,probs),F(3,19))
for p,q,em,va,vi in [(F(1,2),F(1,2),1,1,F(1,4)),(F(1,10),F(1,2),F(1,5),F(1,5),F(9,100))]:
    px=[(1-p)**2,2*p*(1-p),p*p];pz=[(1-q)**2,2*q*(1-q),q*q]
    vals=[a*b for a in range(3) for b in range(3)]
    ps=[pa*pb for pa in px for pb in pz]
    check(f'9.19 mean p={p}',avg(vals,ps),em)
    check(f'9.19 total variance p={p}',variance(vals,ps),va+vi)
    check(f'9.19 additive variance p={p}',2*p*(1-p)*(2*q)**2+2*q*(1-q)*(2*p)**2,va)
    check(f'9.19 interaction variance p={p}',4*p*(1-p)*q*(1-q),vi)
vx,vz,s=F(12,25),F(1,2),F(1,5)
cx,cz=2*vx-s,2*s-vz
check('9.20 marginal first',cx/vx,F(19,12))
check('9.20 marginal second',cz/vz,-F(1,5))
vg=4*vx+vz-4*s
check('9.20 total variance',vg,F(81,50))
check('9.20 residual variance',vz-s*s/vx,F(5,12))
check('9.20 partial covariance',cz-s/vx*cx,-F(5,12))
check('9.20 explained variance',cx*cx/vx,F(361,300))
check('9.20 omitted variance',vg-cx*cx/vx,F(5,12))
newc=2*vx+s;newvg=4*vx+vz+4*s
check('9.20 changed-LD slope',newc/vx,F(29,12))
check('9.20 changed-LD old risk',newvg-2*F(19,12)*newc+F(19,12)**2*vx,F(3,4))
check('9.20 transfer excess',F(5,6)**2*vx,F(1,3))
pr=[F(1,4),F(1,2),F(1,4)];ww=[1,1,2]
mw=avg(ww,pr);selected=[p*w/mw for p,w in zip(pr,ww)]
check('9.21 mean contribution',mw,F(5,4))
check('9.21 selected mean',avg(g,selected),2)
pf=avg(x,selected)/2
check('9.21 selected frequency',pf,F(3,5))
offspring=[(1-pf)**2,2*pf*(1-pf),pf*pf]
check('9.21 offspring mean',avg(g,offspring),F(48,25))
check('9.21 response',avg(g,offspring)-avg(g,pr),F(21,50))
check('9.21 selection covariance',covariance(ww,g,pr)/mw,F(1,2))
check('9.21 transmission gap',avg(g,offspring)-avg(g,selected),-F(2,25))
check('9.22 pooled covariance',F(4,25)+F(1,4)*F(3,5)*(-F(7,5)),-F(1,20))
check('9.22 pooled slope',(-F(1,20))/(F(4,25)+F(1,4)*F(3,5)**2),-F(1,5))
check('9.22 dosage1 reference0',(1-.4)*2.6,1.56)
check('9.22 dosage1 reference1',(1-1.6)*1.4,-.84)
check('9.22 dosage2 reference0',(2-.4)*2.6,4.16)
check('9.22 dosage2 reference1',(2-1.6)*1.4,.56)

OUT_FILE.write_text(json.dumps({'chapter': 9, 'checks': results, 'count': len(results), 'all_passed': True},
                               ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第9章：共 {len(results)} 项复核全部通过')
