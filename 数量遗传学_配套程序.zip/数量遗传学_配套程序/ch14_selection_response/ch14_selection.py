"""第14章 选择反应的数量遗传理论：选择强度、育种者方程、Bulmer 效应、
个体模拟（有限位点）、长期反应与选择极限、选择试验资料的实现遗传力分析。

数据：data/selection_experiment.csv（3 个对照系与 3 个选择系，0—10 世代均值）
运行：python ch14_selection.py
"""
import json, os, sys
import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
DATA = os.path.join(HERE, 'data')
rng = np.random.default_rng(14)
res = {}

def intensity(p):
    x = stats.norm.isf(p); return stats.norm.pdf(x) / p, x
res['intensity_table'] = {f'{p}': dict(i=intensity(p)[0], x=intensity(p)[1], k=intensity(p)[0] * (intensity(p)[0] - intensity(p)[1]))
                          for p in (0.5, 0.4, 0.3, 0.2, 0.1, 0.05, 0.02, 0.01, 0.005, 0.001)}
# 有限群体：从 N 个中选 n 个的期望次序统计量均值
def finite_i(n, N, R=20000):
    z = np.sort(rng.normal(size=(R, N)), axis=1)[:, -n:]
    return float(z.mean())
res['finite_i'] = {f'{n}/{N}': dict(finite=finite_i(n, N), infinite=intensity(n / N)[0]) for n, N in [(1, 10), (2, 20), (5, 50), (10, 100), (20, 200)]}

# 绵羊断奶重例
im, _ = intensity(0.05); iff, _ = intensity(0.60)
h2, sP = 0.3, 3.6; sA = np.sqrt(h2) * sP; L = 14 / 12
res['sheep'] = dict(im=im, if_=iff, sigmaA=sA, L=L, R_year=(im + iff) / (2 * L) * np.sqrt(h2) * sA)

# Bulmer 递推（无限小模型，不连锁）
def bulmer(h2_0, VP0, p, T=12, c=0.5):
    i, x = intensity(p); k = i * (i - x)
    VA0 = h2_0 * VP0; VE = VP0 - VA0; d = 0.0; out = []
    for t in range(T + 1):
        VA = VA0 + d; VP = VA + VE; h2 = VA / VP
        out.append(dict(t=t, VA=VA, h2=h2, d=d, R=i * h2 * np.sqrt(VP)))
        d = 0.5 * d - 0.5 * k * h2 * VA   # 雌雄同强度
    return out
res['bulmer'] = bulmer(0.5, 200, 0.05)
bul = res['bulmer']; i5, x5 = intensity(0.05); k5 = i5 * (i5 - x5)
# 平衡值的近似（解析）：d* 满足 d = -k h2(d) VA(d)
res['bulmer_equilibrium'] = dict(VA=bul[-1]['VA'], h2=bul[-1]['h2'], reduction=1 - bul[-1]['VA'] / bul[0]['VA'])

# 个体模拟：有限位点，比较 Bulmer 预测与长期反应
def simulate(L=200, N=200, nsel_m=10, nsel_f=50, h2=0.5, T=60, effect_dist='normal', seed=1):
    r = np.random.default_rng(seed)
    p0 = r.uniform(0.2, 0.8, L)
    a = r.normal(0, 1, L) if effect_dist == 'normal' else r.exponential(1, L) * r.choice([-1, 1], L)
    H = (r.random((N, 2, L)) < p0).astype(np.int8)       # 个体 × 两条单倍型 × 位点（各位点不连锁）
    VA0 = np.sum(2 * p0 * (1 - p0) * a ** 2); sE = np.sqrt(VA0 * (1 - h2) / h2)
    rec = []
    for t in range(T + 1):
        g = H.sum(1) @ a
        P = g + r.normal(0, sE, N)
        rec.append([t, g.mean(), g.var(), np.mean(H.mean((0, 1)) * (1 - H.mean((0, 1))) > 0)])
        sex = np.arange(N) % 2
        males = np.where(sex == 0)[0]; females = np.where(sex == 1)[0]
        sm = males[np.argsort(P[males])[-nsel_m:]]; sf = females[np.argsort(P[females])[-nsel_f:]]
        newH = np.empty_like(H)
        for j in range(N):
            for par, slot in ((r.choice(sm), 0), (r.choice(sf), 1)):
                pick = r.integers(0, 2, L)   # 每个位点独立随机传递（不连锁）
                newH[j, slot] = H[par, pick, np.arange(L)]
        H = newH
    maxR = float(np.sum(np.where(a > 0, 2 * a * (1 - p0), -2 * a * p0)))
    return np.array(rec), VA0, sE, maxR
runs = [simulate(seed=s_) for s_ in range(1, 9)]
sim = np.mean([r_[0] for r_ in runs], axis=0); VA0 = float(np.mean([r_[1] for r_ in runs]))
maxR = float(np.mean([r_[3] for r_ in runs]))
res['individual_sim'] = dict(VA0=VA0, gen1_VA=float(sim[1, 2]), gen3_VA=float(sim[3, 2]), gen60_VA=float(sim[60, 2]),
                             total_response_sd=float((sim[-1, 1] - sim[0, 1]) / np.sqrt(VA0)),
                             first_gen_response=float(sim[1, 1] - sim[0, 1]),
                             loci_segregating_end=float(sim[-1, 3]))
Ne = 4 * 10 * 50 / 60
i_m = intensity(10 / 100)[0]; i_f = intensity(50 / 100)[0]
R1_pred = 0.5 * (i_m + i_f) * 0.5 * np.sqrt(VA0 / 0.5)
res['robertson_limit'] = dict(Ne=Ne, R1_pred=R1_pred, limit_2NeR1=2 * Ne * R1_pred, observed_total=float(sim[-1, 1] - sim[0, 1]), max_possible=maxR, replicates=8)

# 选择试验资料：实现遗传力
X = np.genfromtxt(os.path.join(DATA, 'selection_experiment.csv'), delimiter=',', names=True)
gen = X['generation']; C = np.column_stack([X['C1'], X['C2'], X['C3']]); S = np.column_stack([X['S1'], X['S2'], X['S3']])
diff = S.mean(1) - C.mean(1)
# 每代选择差：每代 25 个雄性选 5、25 个雌性选 10（每雌 5 后代，50/50 性比）
im_e = intensity(5 / 25)[0]; if_e = intensity(10 / 25)[0]
Sg = 0.5 * (im_e + if_e) * 10.0
cumS = Sg * gen
b = np.polyfit(cumS, diff, 1)
resid = diff - np.polyval(b, cumS); se_b = np.sqrt(resid @ resid / (len(gen) - 2) / np.sum((cumS - cumS.mean()) ** 2))
# 不经截距的回归（过原点）
b0 = (cumS @ diff) / (cumS @ cumS); se_b0 = np.sqrt(np.sum((diff - b0 * cumS) ** 2) / (len(gen) - 1) / (cumS @ cumS))
# 第1代与第10代的 t 检验
def ttest_gen(g):
    s = S[gen == g][0]; c = C[gen == g][0]
    t = stats.ttest_ind(s, c); return dict(diff=float(s.mean() - c.mean()), t=float(t.statistic), p=float(t.pvalue))
dF = 1 / (8 * 5) + 1 / (8 * 10)
NeL = 4 * 5 * 10 / 15
res['selection_experiment'] = dict(S_per_gen=Sg, i_m=im_e, i_f=if_e, realized_h2=b[0], se=se_b, realized_h2_origin=b0, se_origin=se_b0,
                                   gen1=ttest_gen(1), gen10=ttest_gen(10), deltaF=dF, Ne_line=NeL,
                                   var_line_means_expected_g10=100 * (10 * b0 / NeL + 1 / 50),
                                   var_line_means_observed_g10_control=float(np.var(C[gen == 10][0], ddof=1)),
                                   var_line_means_observed_g10_sel=float(np.var(S[gen == 10][0], ddof=1)))
json.dump(res, open(os.path.join(OUT, 'ch14_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

# 图
ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 3.9))
ax = axes[0]
pp = np.logspace(-3, np.log10(0.99), 200)
ax.plot(pp * 100, [intensity(p)[0] for p in pp], color=ps.NAVY, lw=2)
ax.set_xscale('log'); ax.set_xlabel('留种率（%）'); ax.set_ylabel('选择强度 $i=z/p$')
for p in (0.5, 0.2, 0.1, 0.05, 0.01):
    ax.plot(p * 100, intensity(p)[0], 'o', color=ps.ORANGE); ax.annotate(f'{intensity(p)[0]:.2f}', (p * 100, intensity(p)[0]), textcoords='offset points', xytext=(4, 4), fontsize=8)
ps.panel_title(ax, 'A', '截断选择的选择强度')
ax = axes[1]
t = [b_['t'] for b_ in bul]
ax.plot(t, [b_['VA'] for b_ in bul], 'o-', color=ps.NAVY, label='Bulmer 递推（无限小模型）')
ax.plot(sim[:13, 0], sim[:13, 2] / VA0 * bul[0]['VA'], 's--', color=ps.ORANGE, label='200 位点个体模拟（按比例换算）')
ax.set_xlabel('世代'); ax.set_ylabel('加性方差 $V_A$')
ps.panel_title(ax, 'B', 'Bulmer 效应：选择造成的方差下降'); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig14_1_intensity_bulmer.png')); plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10, 3.9))
ax = axes[0]
for k in range(3):
    ax.plot(gen, C[:, k], 'o-', color=ps.GREY, ms=3, lw=1, label='对照系' if k == 0 else None)
    ax.plot(gen, S[:, k], 's-', color=ps.NAVY, ms=3, lw=1, label='选择系' if k == 0 else None)
ax.set_xlabel('世代'); ax.set_ylabel('世代表型均值')
ps.panel_title(ax, 'A', '三个重复的选择系与对照系'); ax.legend()
ax = axes[1]
ax.plot(cumS, diff, 'o', color=ps.NAVY)
xx = np.linspace(0, cumS.max(), 10); ax.plot(xx, b0 * xx, color=ps.ORANGE, lw=1.8, label=f'过原点回归：$h^2_R$={b0:.2f}')
ax.set_xlabel('累积选择差'); ax.set_ylabel('选择系与对照系均值之差')
ps.panel_title(ax, 'B', '实现遗传力'); ax.legend()
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig14_2_selection_experiment.png')); plt.close(fig)

fig, ax = plt.subplots(figsize=(6.4, 3.6))
ax.plot(sim[:, 0], (sim[:, 1] - sim[0, 1]) / np.sqrt(VA0), color=ps.NAVY, lw=2, label='累积反应（以初始 $\\sigma_A$ 为单位）')
ax2 = ax.twinx(); ax2.spines['right'].set_visible(True)
ax2.plot(sim[:, 0], sim[:, 2] / VA0, color=ps.ORANGE, lw=1.6, ls='--', label='$V_A/V_{A,0}$')
ax.set_xlabel('世代'); ax.set_ylabel('累积反应'); ax2.set_ylabel('相对加性方差')
h1, l1 = ax.get_legend_handles_labels(); h2_, l2 = ax2.get_legend_handles_labels(); ax.legend(h1 + h2_, l1 + l2, fontsize=8, loc='center right')
ax.set_title('有限位点、有限群体中的长期选择（$N_e\\approx33$，8 个重复平均）', fontsize=10.5)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig14_3_long_term.png')); plt.close(fig)
print(json.dumps({k: v for k, v in res.items() if k not in ('bulmer',)}, ensure_ascii=False, indent=1, default=float))
print([round(b_['VA'], 2) for b_ in bul])
