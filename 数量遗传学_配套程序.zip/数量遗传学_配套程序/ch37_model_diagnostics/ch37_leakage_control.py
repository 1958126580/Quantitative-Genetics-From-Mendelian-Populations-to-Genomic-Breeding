"""《数量遗传学——从孟德尔群体到基因组育种》第37章 信息泄漏负对照：无信号特征筛选实验（教学模拟资料）。"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
import numpy as np
null_rng=np.random.default_rng(24002)
leakrows=[]
for rr in range(200):
    XX=null_rng.normal(size=(120,500)); yy=null_rng.normal(size=120)
    train=np.arange(80);valid=np.arange(80,120)
    for label,screen in [("train_only",train),("all_records",np.arange(120))]:
        xs=XX[screen]-XX[screen].mean(0)
        ys=yy[screen]-yy[screen].mean()
        scores=(xs.T@ys)/np.sqrt(np.sum(xs*xs,axis=0)*np.sum(ys*ys))
        j=int(np.argmax(abs(scores)))
        design=np.c_[np.ones(80),XX[train,j]]
        coef=np.linalg.lstsq(design,yy[train],rcond=None)[0]
        pred=coef[0]+coef[1]*XX[valid,j]
        leakrows.append(dict(rep=rr,mode=label,
                             correlation=float(np.corrcoef(yy[valid],pred)[0,1]),
                             rmse=float(np.sqrt(np.mean((yy[valid]-pred)**2)))))
null_report={
    label:{k:float(np.mean([r[k] for r in leakrows if r["mode"]==label]))
           for k in ["correlation","rmse"]}
    for label in ["train_only","all_records"]}
print(json.dumps(null_report, indent=2))
