"""《数量遗传学——从孟德尔群体到基因组育种》第37章 推导与算例数值复核

复核内容：后验预测、新息与对数评分、离散 Brier 评分、功效与样本量、模拟基校准（SBC）秩统计。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch37_derivation_checks.py
输出：results/ch37_derivation_checks.json
"""
from pathlib import Path
import json
import math
import numpy as np
from scipy.stats import norm

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch37_derivation_checks.json'


out = {}
out['37_prediction']={'posterior_u_mean':1.5,'posterior_u_variance':.5,
    'same_animal_predictive_variance':1.5,
    'new_animal_predictive_mean':0.,'new_animal_predictive_variance':2.}
z2=(1-.8)/math.sqrt(1-.8**2)
out['37_innovations']={'z1':1.,'z2':z2,
    'logscore_joint':float(norm.logpdf(1)+norm.logpdf(1,loc=.8,scale=.6)),
    'expected_logscore_excess_v4_vs_v1':.5*(math.log(4)+1/4-1)}
out['37_discrete']={'p0':.2,'u_if_y0_at_vhalf':.4,
    'u_if_y1_at_vhalf':.9,
    'brier_correct':.2*.8,'brier_forecast_half':.2*.8+(.5-.2)**2}
za=norm.ppf(.975)
zb=norm.ppf(.8)
required=math.ceil(((za+zb)*.08/.02)**2)
required_unpaired=math.ceil(((za+zb)*math.sqrt(2)*.08/.02)**2)
power=lambda n: float(norm.cdf(.02*math.sqrt(n)/.08-za)
    +norm.cdf(-.02*math.sqrt(n)/.08-za))
out['37_power']={'z_975':float(za),'z_80':float(zb),
    'paired_required':required,'unpaired_required':required_unpaired,
    'power_at30':power(30),'power_at126':power(126),
    'coverage_one_sided_required':math.ceil(
        ((norm.ppf(.95)*math.sqrt(.9*.1)+zb*math.sqrt(.85*.15))/.05)**2),
    'cluster_effective_count':400/(1+9*.1)}
# An optional algorithmic calibration experiment. This is not field evidence.
rng=np.random.default_rng(20261001)
reps=20000
draws=19
theta=rng.normal(size=reps)
obs=theta+rng.normal(size=reps)
proper=obs[:,None]/2+rng.normal(size=(reps,draws))/math.sqrt(2)
ignored=rng.normal(size=(reps,draws))
ranks_proper=np.sum(proper<theta[:,None],axis=1)
ranks_ignored=np.sum(ignored<theta[:,None],axis=1)
out['37_sbc']={'replicates':reps,'posterior_draws':draws,
    'proper_rank_counts':np.bincount(ranks_proper,minlength=draws+1).tolist(),
    'ignored_data_rank_counts':np.bincount(ranks_ignored,minlength=draws+1).tolist(),
    'mean_squared_error_proper':float(np.mean((theta-obs/2)**2)),
    'mean_squared_error_ignored':float(np.mean(theta**2)),
    'note':'Marginal rank uniformity alone is not sufficient validation.'}


OUT_FILE.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第37章：共 {len(out)} 项复核全部通过')
