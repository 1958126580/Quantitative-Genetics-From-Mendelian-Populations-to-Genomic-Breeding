"""《数量遗传学——从孟德尔群体到基因组育种》第35章 推导与算例数值复核

复核内容：标量风险、嵌套分配、析因风险、矩匹配、截断选择尾部的方差与相关。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch35_derivation_checks.py
输出：results/ch35_derivation_checks.json
"""
from pathlib import Path
import json
import math
from scipy.stats import norm

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch35_derivation_checks.json'


out = {}
out['35_scalar_risk']={'oracle_weight':2/5,'oracle_risk':2-4/5,
    'wrong_risk':2-2*.7*2+.7**2*5,
    'excess':5*(.7-.4)**2,
    'risk_with_bias_half':2-2*.7*2+.7**2*5+.5**2}
allocation=[]
for inner in range(1,21):
    outer=900//(9+inner)
    allocation.append({'inner':inner,'outer':outer,
                      'variance':(.04+.09/inner)/outer})
out['35_nested_allocation']={'continuous_inner':math.sqrt(9*.09/.04),
    'best_integer':min(allocation,key=lambda d:d['variance']),
    'k1':allocation[0],'k4':allocation[3],'k5':allocation[4]}
factor={f'q={q},r={r}':1-q*q/(1+r)
        for q in [.4,.8] for r in [1.,4.]}
out['35_factorial']={'risk':factor,'interaction':(.92-.68)-(.968-.872),
    'misspecified_q_risk':1-2*.4*.4+.4**2*2}
out['35_moment_matching']={'posterior_y2':math.tanh(2),
                         'posterior_y4':math.tanh(4)}
t=norm.ppf(.9)
intensity=norm.pdf(t)/.1
vz=1+t*intensity-intensity**2
rho=.6
out['35_selected_tail']={'cutoff':float(t),'intensity':float(intensity),
    'selected_u_mean':float(rho*intensity),
    'selected_z_variance':float(vz),
    'selected_u_variance':float(rho*rho*vz+1-rho*rho),
    'selected_correlation':float(rho*math.sqrt(vz/(rho*rho*vz+1-rho*rho))),
    'correct_pev':1-rho*rho,
    'miscalibration_excess':float((.8-.6)**2*(1+t*intensity))}


OUT_FILE.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第35章：共 {len(out)} 项复核全部通过')
