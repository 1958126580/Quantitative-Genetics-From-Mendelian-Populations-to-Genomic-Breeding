"""Complete numerical example for 《数量遗传学——从孟德尔群体到基因组育种》第34—37章; synthetic data only."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
import json
from pathlib import Path
import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize, linprog

def population(seed):
    r = np.random.default_rng(seed)
    n, m = 280, 240
    p = r.uniform(.15, .5, m)
    M = np.zeros((n, m))
    M[:40] = r.binomial(2, p, (40, m))
    sex = np.tile([0, 1], 140)
    A = np.zeros((n, n))
    for i in range(n):
        if i < 40:
            A[i, i] = 1.
        else:
            pool = np.arange(40) if i < 200 else np.arange(40, 200)
            s = int(r.choice(pool[sex[pool] == 0]))
            d = int(r.choice(pool[sex[pool] == 1]))
            M[i] = r.binomial(1, M[s]/2)+r.binomial(1, M[d]/2)
            A[i, :i] = .5*(A[s, :i]+A[d, :i])
            A[:i, i] = A[i, :i]
            A[i, i] = 1.+.5*A[s, d]
    Z = M-2*p
    scale = np.sum(2*p*(1-p))
    G = Z@Z.T/scale
    u = Z@(r.normal(size=m)/np.sqrt(scale))
    X = np.column_stack([np.ones(n), sex, r.integers(0, 2, n)])
    y = X@np.array([10., .4, -.3])+u+r.normal(0, np.sqrt(1.5), n)
    return A, G, Z, scale, X, u, y

def blup(K, X, y):
    C = cho_factor(K[:200, :200]+1.5*np.eye(200), lower=True)
    Vx = cho_solve(C, X[:200])
    Vy = cho_solve(C, y[:200])
    B = np.linalg.inv(X[:200].T@Vx)
    beta = B@(X[:200].T@Vy)
    Kt = K[:, :200]
    uh = Kt@cho_solve(C, y[:200]-X[:200]@beta)
    Q = Kt@Vx
    pev = np.diag(K)-np.sum(Kt*cho_solve(C, Kt.T).T, axis=1)
    pev += np.sum((Q@B)*Q, axis=1)
    assert pev.min() > -1e-9
    return uh, np.maximum(pev, 0)

names = ["ABLUP", "GBLUP"]
rows = []
first = None
for rep in range(30):
    pop = population(21001+rep)
    if rep == 0:
        first = pop
    A, G, Z, scale, X, u, y = pop
    for method, K in enumerate([A, G]):
        uh, pev = blup(K, X, y)
        truth, pred, v = u[200:], uh[200:], pev[200:]
        slope, intercept = np.polyfit(pred, truth, 1)
        acc = np.corrcoef(truth, pred)[0, 1]
        rmse = np.sqrt(np.mean((truth-pred)**2))
        cover = np.mean(abs(truth-pred) <= 1.6448536269514722*np.sqrt(v))
        rows.append([rep, method, acc, rmse, slope, intercept, cover])
rows = np.array(rows)
np.savetxt("replicates.csv", rows, delimiter=",",
           header="rep,method,r,rmse,slope,intercept,coverage", comments="")
report = {}
for method, name in enumerate(names):
    vals = rows[rows[:, 1] == method, 2:]
    report[name] = dict(mean=vals.mean(0).tolist(),
                        sd=vals.std(0, ddof=1).tolist())

A, G, Z, scale, X, u, y = first
r = np.random.default_rng(23001)
T = np.array([[1, -.2, .3], [-.2, 1, -.1], [.3, -.1, 1]])
effects = r.normal(size=(240, 3))@np.linalg.cholesky(T).T/np.sqrt(scale)
U = Z@effects
fixed = np.array([[10, 2, 5], [.4, .1, .2], [-.3, .2, .1]])
Y = X@fixed+U+r.normal(0, np.sqrt(1.5), (280, 3))
ebv = np.column_stack([blup(G, X, Y[:, j])[0] for j in range(3)])
idx = np.r_[np.arange(200, 216, 2), np.arange(201, 217, 2)]
K = A[np.ix_(idx, idx)]
E = ebv[idx]
H = np.zeros((2, 16))
H[0, :8] = 1
H[1, 8:] = 1
c0 = np.full(16, 1/16)
bounds = [(0, .125)]*16
eq = dict(type="eq", fun=lambda c: H@c-.5, jac=lambda c: H)
opts = dict(ftol=1e-12, maxiter=1000)
res = minimize(lambda c: .5*c@K@c, c0, jac=lambda c: K@c,
               bounds=bounds, constraints=[eq], method="SLSQP",
               options=opts)
assert res.success
cap = .5*res.x@K@res.x+.008
weights = [[.75, .10, -.15], [.40, .35, -.25], [.20, .65, -.15]]
goals = ["Growth", "Balanced", "Fertility"]
report["coancestry_cap"] = float(cap)
for name, w in zip(goals, weights):
    score = E@w
    iq = dict(type="ineq", fun=lambda c: cap-.5*c@K@c,
              jac=lambda c: -K@c)
    sol = minimize(lambda c: -score@c, res.x, jac=lambda c: -score,
                   bounds=bounds, constraints=[eq, iq], method="SLSQP",
                   options=opts)
    assert sol.success
    c = sol.x
    assert abs(H@c-.5).max() < 1e-8
    assert .5*c@K@c <= cap+1e-8
    row, col = 2*c[:8], 2*c[8:]
    random = np.outer(row, col)
    cost = .5*K[:8, 8:]
    ae, be = [], []
    for i in range(8):
        z = np.zeros((8, 8))
        z[i, :] = 1
        ae.append(z.ravel())
        be.append(row[i])
    for j in range(8):
        z = np.zeros((8, 8))
        z[:, j] = 1
        ae.append(z.ravel())
        be.append(col[j])
    lp = linprog(cost.ravel(), A_eq=ae, b_eq=be,
                 bounds=(0, None), method="highs")
    assert lp.success
    mating = lp.x.reshape(8, 8)
    report[name] = dict(response=(E.T@c).tolist(),
                        coancestry=float(.5*c@K@c),
                        F_random=float(np.sum(random*cost)),
                        F_optimized=float(np.sum(mating*cost)))
    np.savetxt(name+"_contributions.csv", np.c_[idx, E, c],
               delimiter=",", header="animal,growth,fertility,feed,c",
               comments="")
    np.savetxt(name+"_mating.csv", mating, delimiter=",")
Path("results_core.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))

# Append to the complete program in Appendix C.2.
def fit_extended(K, X, y, ve=1.5):
    Xt = X[:200]
    C = cho_factor(K[:200, :200]+ve*np.eye(200), lower=True)
    VX = cho_solve(C, Xt)
    B = np.linalg.inv(Xt.T@VX)
    beta = B@Xt.T@cho_solve(C, y[:200])
    Kt = K[:, :200]
    uh = Kt@cho_solve(C, y[:200]-Xt@beta)
    Q = Kt@VX
    pev = np.diag(K)-np.sum(Kt*cho_solve(C, Kt.T).T, axis=1)
    pev += np.sum((Q@B)*Q, axis=1)
    assert pev.min() > -1e-8
    return uh, np.maximum(pev, 0)

def validation_metrics(u, uh, pev):
    truth, pred, v = u[200:], uh[200:], pev[200:]
    return [np.corrcoef(truth, pred)[0, 1],
            np.sqrt(np.mean((truth-pred)**2)),
            np.polyfit(pred, truth, 1)[0],
            np.mean(abs(truth-pred) <= 1.6448536269514722*np.sqrt(v))]

density, misspec = {}, {}
for rep in range(30):
    seed = 21001+rep
    A, G, W, scale, X, u, y = population(seed)
    p = np.random.default_rng(seed).uniform(.15, .5, 240)
    matrices = dict(ABLUP=A, M240=G)
    for m in [30, 60, 120]:
        sm = np.sum(2*p[:m]*(1-p[:m]))
        Gm = W[:, :m]@W[:, :m].T/sm
        matrices['M'+str(m)] = Gm
        matrices['Hybrid'+str(m)] = (sm/scale)*Gm+(1-sm/scale)*A
    perm = np.arange(280)
    perm[200:208] = perm[200:208][::-1]
    matrices['Eight_swapped'] = G[np.ix_(perm, perm)]
    for name, K in matrices.items():
        uh, pev = fit_extended(K, X, y)
        density.setdefault(name, []).append(validation_metrics(u, uh, pev))
    for ve in [.375, 1.5, 6.]:
        uh, pev = fit_extended(G, X, y, ve)
        misspec.setdefault(str(ve), []).append(validation_metrics(u, uh, pev))

metrics = ['r', 'rmse', 'slope', 'coverage90']
def summarize_experiment(result):
    return {name:dict(zip(metrics, np.mean(vals, axis=0).tolist()))
            for name, vals in result.items()}

extended = dict(marker_density=summarize_experiment(density),
                residual_misspecification=summarize_experiment(misspec))
# Four parents: two sires, two dams, total contributions .5 each sex.
Ac = np.eye(4)
Ac[0, 1] = Ac[1, 0] = .5
h = np.array([12., 11., 8., 7.])
S = np.array([[1., 1., 0, 0], [0, 0, 1., 1.]])
equalities = dict(type='eq', fun=lambda c:S@c-.5, jac=lambda c:S)
frontier = []
for cap4 in [.15625, .16, .18, .20, .25]:
    limit = dict(type='ineq', fun=lambda c:cap4-.5*c@Ac@c,
                 jac=lambda c:-Ac@c)
    z = minimize(lambda c:-h@c, np.full(4, .25), jac=lambda c:-h,
                 constraints=[equalities, limit], bounds=[(0, .5)]*4,
                 method='SLSQP', options=dict(ftol=1e-12, maxiter=1000))
    assert z.success and abs(S@z.x-.5).max() < 1e-8
    assert .5*z.x@Ac@z.x <= cap4+1e-8
    frontier.append(dict(cap=cap4, c=z.x.tolist(), goal=float(h@z.x),
                         coancestry=float(.5*z.x@Ac@z.x)))
extended['four_parent_frontier'] = frontier

# Exhaust all marginal allocations for twenty offspring.
feasible = []
for ks in range(21):
    for kd in range(21):
        c = np.array([ks, 20-ks, kd, 20-kd])/40
        q = float(.5*c@Ac@c)
        if q <= .18+1e-12:
            feasible.append((float(h@c), q, ks, kd, c.tolist()))
best = max(row[0] for row in feasible)
extended['integer_best'] = [row for row in feasible if abs(row[0]-best)<1e-10]
naive = np.array([.425, .075, .35, .15])
extended['naive_rounded_coancestry'] = float(.5*naive@Ac@naive)
Path('results_extended.json').write_text(json.dumps(extended, indent=2))
print(json.dumps(extended, indent=2))

null_rng=np.random.default_rng(24002)
leakrows=[]
for rr in range(200):
    XX=null_rng.normal(size=(120,500)); yy=null_rng.normal(size=120)
    train=np.arange(80);valid=np.arange(80,120)
    for label,screen in [("train_only",train),("all_records",np.arange(120))]:
        xs=XX[screen]-XX[screen].mean(0)
        ys=yy[screen]-yy[screen].mean()
        scores=(xs.T@ys)/np.sqrt(np.sum(xs*xs,axis=0)*np.sum(ys*ys))
        j=int(np.argmax(abs(scores)))
        design=np.c_[np.ones(80),XX[train,j]]
        coef=np.linalg.lstsq(design,yy[train],rcond=None)[0]
        pred=coef[0]+coef[1]*XX[valid,j]
        leakrows.append(dict(rep=rr,mode=label,
                             correlation=float(np.corrcoef(yy[valid],pred)[0,1]),
                             rmse=float(np.sqrt(np.mean((yy[valid]-pred)**2)))))
null_report={
    label:{k:float(np.mean([r[k] for r in leakrows if r["mode"]==label]))
           for k in ["correlation","rmse"]}
    for label in ["train_only","all_records"]}
print(json.dumps(null_report, indent=2))
