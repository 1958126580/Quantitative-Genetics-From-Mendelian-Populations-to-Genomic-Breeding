# 第35章　从系谱BLUP到GBLUP：一个可复算的肉羊教学实验

本文件夹为《数量遗传学——从孟德尔群体到基因组育种》第35章的配套程序与资料。

**内容**：肉羊教学模拟：ABLUP与GBLUP比较、标记密度、方差参数错设、身份错配、多性状贡献与配种（含扩展实验）；正文推导与数值例题的独立复核。

**文件**：

- `ch35_core_experiment.py`
- `ch35_derivation_checks.py`
- `ch35_extended_experiment.py`
- `ch35_full_experiments.py`
- `reference_results/`：参考结果，供逐项比较
- `results/`：运行输出（JSON、CSV与图形）

**运行**：在本文件夹下执行 `python <脚本名>`，或在上一级目录执行 `python run_all.py 35`。

