"""第11章 亲属间的相似性：IBD 系数（基因下落模拟）、遗传协方差的验证、
全同胞实际共享比例的分布、家系均值方差与双生子设计。

运行：python ch11_resemblance.py
"""
import json, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(11)
res = {}

# ---------- 1. 基因下落估计亲缘系数与显性关系 ----------
# 系谱：1,2 为祖代；3=1x2，4=1x2（全同胞）；5=外来；6=3x5，7=4x5? 构造常见关系
ped = {1: (0, 0), 2: (0, 0), 3: (1, 2), 4: (1, 2), 5: (0, 0), 6: (0, 0), 7: (3, 5), 8: (4, 6), 9: (3, 5), 10: (0, 0), 11: (1, 10)}
pairs = {'亲子(1,3)': (1, 3), '全同胞(3,4)': (3, 4), '半同胞(3,11)': (3, 11), '祖孙(1,7)': (1, 7),
         '叔侄(4,7)': (4, 7), '堂表兄弟(7,8)': (7, 8), '全同胞(7,9)': (7, 9)}
def gene_drop(ped, R=200000):
    ids = sorted(ped); allele = {}
    nxt = 0
    for i in ids:
        s, d = ped[i]
        if s == 0:
            allele[i] = np.column_stack([np.full(R, nxt), np.full(R, nxt + 1)]); nxt += 2
        else:
            ps_ = allele[s][np.arange(R), rng.integers(0, 2, R)]
            pd = allele[d][np.arange(R), rng.integers(0, 2, R)]
            allele[i] = np.column_stack([ps_, pd])
    return allele
al = gene_drop(ped)
tab = {}
for name, (i, j) in pairs.items():
    a, b = al[i], al[j]
    ibd = [(a[:, x] == b[:, y]) for x in range(2) for y in range(2)]
    f = np.mean([m.mean() for m in ibd])
    u = np.mean((ibd[0] & ibd[3]) | (ibd[1] & ibd[2]))
    tab[name] = dict(coancestry=f, r=2 * f, u=u)
res['gene_drop'] = tab

# ---------- 2. 单位点模拟验证 Cov = r VA + u VD ----------
p, a, d = 0.3, 1.0, 0.8
q = 1 - p; alpha = a + d * (q - p); VA = 2 * p * q * alpha ** 2; VD = (2 * p * q * d) ** 2
N = 400000
def gval(x): return np.where(x == 2, a, np.where(x == 1, d, -a))
s = rng.binomial(1, p, (N, 2)); dm = rng.binomial(1, p, (N, 2)); dm2 = rng.binomial(1, p, (N, 2))
def child(par1, par2):
    return par1[np.arange(N), rng.integers(0, 2, N)] + par2[np.arange(N), rng.integers(0, 2, N)]
o1 = child(s, dm); o2 = child(s, dm); o3 = child(s, dm2)
gs = gval(s.sum(1)); g1 = gval(o1); g2 = gval(o2); g3 = gval(o3)
res['single_locus_check'] = dict(VA=VA, VD=VD,
    parent_offspring=dict(sim=float(np.cov(gs, g1)[0, 1]), theory=0.5 * VA),
    full_sib=dict(sim=float(np.cov(g1, g2)[0, 1]), theory=0.5 * VA + 0.25 * VD),
    half_sib=dict(sim=float(np.cov(g1, g3)[0, 1]), theory=0.25 * VA))

# ---------- 3. 实际共享比例：全同胞 ----------
def realized_fs(chrom_lengths_M, nrep=4000):
    out = []
    for _ in range(nrep):
        tot = 0; L = 0
        for Lc in chrom_lengths_M:
            grid = np.linspace(0, Lc, max(int(Lc * 200), 20))
            share = np.zeros(len(grid))
            for parent in range(2):
                # 两个后代分别从该亲本得到的配子：沿染色体的来源状态（0/1），Haldane 交换
                st = []
                for kid in range(2):
                    nco = rng.poisson(Lc); pts = np.sort(rng.uniform(0, Lc, nco))
                    s0 = rng.integers(0, 2)
                    state = (s0 + np.searchsorted(pts, grid)) % 2
                    st.append(state)
                share += (st[0] == st[1]) * 0.5
            tot += share.mean() * Lc; L += Lc
        out.append(tot / L)
    return np.array(out)
human = [2.78, 2.63, 2.24, 2.14, 2.04, 1.92, 1.87, 1.68, 1.66, 1.81, 1.58, 1.74, 1.25, 1.20, 1.41, 1.34, 1.28, 1.17, 1.07, 1.08, 0.62, 0.74]
cattle = [1.0] * 29 + [1.4]  # 约 30 M
fs_h = realized_fs(human, 3000); fs_c = realized_fs(cattle, 3000)
res['realized_fullsib'] = dict(human=dict(mean=float(fs_h.mean()), sd=float(fs_h.std()), q025=float(np.quantile(fs_h, .025)), q975=float(np.quantile(fs_h, .975))),
                               cattle_like=dict(mean=float(fs_c.mean()), sd=float(fs_c.std())))

# ---------- 4. 双生子 ----------
rMZ, rDZ = 0.86, 0.47
res['twins'] = dict(rMZ=rMZ, rDZ=rDZ, falconer_h2=2 * (rMZ - rDZ), c2=2 * rDZ - rMZ, e2=1 - rMZ)

json.dump(res, open(os.path.join(OUT, 'ch11_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

# ---------- 图 ----------
ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 3.9))
ax = axes[0]
n = np.arange(1, 201)
for t, col in zip([1.0, 0.75, 0.5, 0.3, 0.2, 0.1, 0.0], ['#222'] + ps.PALETTE):
    ax.plot(n, t + (1 - t) / n, color=col, lw=1.6, label=f'$t={t}$')
ax.set_xlabel('个体数 $n$'); ax.set_ylabel(r'$\mathrm{Var}(\bar P_n)/V_P$'); ax.set_ylim(0, 1.02)
ps.panel_title(ax, 'A', '相关个体均值的方差'); ax.legend(ncol=2, fontsize=8)
ax = axes[1]
bins = np.linspace(0.3, 0.7, 50)
ax.hist(fs_h, bins=bins, color=ps.NAVY, alpha=0.6, density=True, label=f'人类（约 35 M），SD={fs_h.std():.3f}')
ax.hist(fs_c, bins=bins, color=ps.ORANGE, alpha=0.6, density=True, label=f'约 30 M 基因组，SD={fs_c.std():.3f}')
ax.axvline(0.5, color='k', lw=0.8)
ax.set_xlabel('全同胞间同祖同源的实际比例'); ax.set_ylabel('密度')
ps.panel_title(ax, 'B', '期望关系与实际共享')
ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig11_1_family_means_realized.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
