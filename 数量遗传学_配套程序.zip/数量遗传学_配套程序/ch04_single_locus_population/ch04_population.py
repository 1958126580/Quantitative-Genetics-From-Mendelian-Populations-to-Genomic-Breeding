"""第4章 单基因座群体模型：Hardy–Weinberg 检验、进化力与漂变模拟。

运行：python ch04_population.py
"""
import json, os, sys
import numpy as np
from scipy import stats
from math import lgamma, log, exp

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
DATA = os.path.join(HERE, 'data')
res = {}

# 1. MN 血型（冰岛）
mn = {r.split(',')[0]: int(r.split(',')[1]) for r in open(os.path.join(DATA, 'mn_iceland.csv')).read().split()[1:]}
N = sum(mn.values()); p = (2 * mn['MM'] + mn['MN']) / (2 * N); q = 1 - p
exp_ = np.array([p * p, 2 * p * q, q * q]) * N
obs = np.array([mn['MM'], mn['MN'], mn['NN']])
X2 = np.sum((obs - exp_) ** 2 / exp_)
res['mn'] = dict(N=N, p=p, q=q, expected=exp_.tolist(), X2=X2, p_value=1 - stats.chi2.cdf(X2, 1),
                 F_hat=1 - mn['MN'] / (2 * p * q * N), se_p=np.sqrt(p * q / (2 * N)))

# 2. 三等位基因微卫星
ms = np.loadtxt(os.path.join(DATA, 'microsat_3allele.csv'), delimiter=',', skiprows=1, dtype=str)
cnt = {r[0]: int(r[1]) for r in ms}
n_all = 2 * sum(cnt.values())
freq = np.zeros(3)
for g, c in cnt.items():
    a, b = int(g[1]) - 1, int(g[3]) - 1
    freq[a] += c; freq[b] += c
freq /= n_all
X2m = 0; tab = []
for g, c in cnt.items():
    a, b = int(g[1]) - 1, int(g[3]) - 1
    e = (freq[a] ** 2 if a == b else 2 * freq[a] * freq[b]) * sum(cnt.values())
    X2m += (c - e) ** 2 / e; tab.append([g, c, e, (c - e) ** 2 / e])
het_obs = sum(c for g, c in cnt.items() if g[1] != g[3]) / sum(cnt.values())
het_exp = 1 - np.sum(freq ** 2)
res['microsat'] = dict(freq=freq.tolist(), table=tab, X2=X2m, df=3, p_value=1 - stats.chi2.cdf(X2m, 3),
                       Ho=het_obs, He=het_exp, F=1 - het_obs / het_exp)

# 3. 双等位精确检验（Levene/Haldane 条件分布）
def hwe_exact(nAA, nAa, naa):
    n = nAA + nAa + naa; nA = 2 * nAA + nAa; na = 2 * n - nA
    def logp(h):
        hom_A = (nA - h) // 2; hom_a = (na - h) // 2
        return (lgamma(n + 1) - lgamma(hom_A + 1) - lgamma(h + 1) - lgamma(hom_a + 1) + h * log(2)
                + lgamma(nA + 1) + lgamma(na + 1) - lgamma(2 * n + 1))
    hs = [h for h in range(nA % 2, min(nA, na) + 1, 2)]
    lp = np.array([logp(h) for h in hs]); pr = np.exp(lp)
    pobs = exp(logp(nAa))
    return float(pr[pr <= pobs * (1 + 1e-7)].sum()), hs, pr

pe, hs, pr = hwe_exact(1, 10, 89)     # 稀有等位基因例
X2r = None
nn = 100; pr_ = (2 * 1 + 10) / 200
er = np.array([pr_ ** 2, 2 * pr_ * (1 - pr_), (1 - pr_) ** 2]) * nn
X2r = float(np.sum((np.array([1, 10, 89]) - er) ** 2 / er))
pe2, _, _ = hwe_exact(*obs)
res['exact'] = dict(rare_example=[1, 10, 89], p_exact=pe, X2=X2r, p_chi2=1 - stats.chi2.cdf(X2r, 1), mn_exact_p=pe2)

# 4. 隐性有害基因携带者频率
q_pku = np.sqrt(1 / 10000)
res['carrier'] = dict(q=q_pku, carrier_among_normal=2 * q_pku / (1 + q_pku), carrier_freq=2 * q_pku * (1 - q_pku))

# 5. 选择轨迹
def select(q0, w11, w12, w22, T):
    qs = [q0]
    for _ in range(T):
        q = qs[-1]; p = 1 - q
        wbar = p * p * w11 + 2 * p * q * w12 + q * q * w22
        qs.append((p * q * w12 + q * q * w22) / wbar)
    return np.array(qs)

T = 200; s = 0.1
traj = {
    '对隐性纯合子选择（$aa$ 适合度 $1-s$）': select(0.9, 1, 1, 1 - s, T),
    '对显性有害等位基因选择（$Aa,aa$ 适合度 $1-s$）': select(0.9, 1, 1 - s, 1 - s, T),
    '加性选择（$Aa$ 适合度 $1-s/2$）': select(0.9, 1, 1 - s / 2, 1 - s, T),
}
# 完全隐性淘汰：q_t = q0/(1+t q0)
q0 = 0.5
res['recessive_elimination'] = dict(q0=q0, generations_to_0_01=1 / 0.01 - 1 / q0,
                                    generations_to_0_001=1 / 0.001 - 1 / q0)
# 超显性平衡
s1, s2 = 0.1, 0.3
res['overdominance'] = dict(s1=s1, s2=s2, q_eq=s1 / (s1 + s2), sim_q_after_300=float(select(0.05, 1 - s1, 1, 1 - s2, 300)[-1]))
# 突变—选择平衡
u = 1e-5
res['mut_sel'] = dict(u=u, s=0.1, q_recessive=np.sqrt(u / 0.1), q_partial_h_0_1=u / (0.1 * 0.1))

# 6. Wright–Fisher 漂变
rng = np.random.default_rng(4)
Npop = 20; G = 100; R = 30
paths = np.zeros((R, G + 1)); paths[:, 0] = 0.5
for r in range(R):
    for t in range(G):
        paths[r, t + 1] = rng.binomial(2 * Npop, paths[r, t]) / (2 * Npop)
reps = 4000
P = np.full(reps, 0.5); Hbar = [np.mean(2 * P * (1 - P))]
for t in range(G):
    P = rng.binomial(2 * Npop, P) / (2 * Npop); Hbar.append(np.mean(2 * P * (1 - P)))
Hbar = np.array(Hbar)
res['drift'] = dict(N=Npop, H_sim_t10=float(Hbar[10]), H_theory_t10=0.5 * (1 - 1 / (2 * Npop)) ** 10,
                    H_sim_t50=float(Hbar[50]), H_theory_t50=0.5 * (1 - 1 / (2 * Npop)) ** 50,
                    fixed_frac_t100=float(np.mean((P == 0) | (P == 1))), fixed_A_frac=float(np.mean(P == 1)))

# 7. 选择 + 漂变：Kimura 固定概率
def kimura(p0, Ne, s):
    # 加性选择，杂合子 1+s/2... 采用 Aa 适合度 1+s, AA 1+2s 近似，u = (1-exp(-4Ne s p))/(1-exp(-4Ne s))
    return (1 - np.exp(-4 * Ne * s * p0)) / (1 - np.exp(-4 * Ne * s))
sim = []
Nk = 50; p0 = 1 / (2 * Nk)
for s_ in [0.0, 0.005, 0.01, 0.02, 0.05]:
    P = np.full(40000, p0)
    for t in range(2000):
        w = np.where(True, 1.0, 1.0)
        pp = P * (1 + 2 * s_) * P + P * (1 - P) * (1 + s_)
        wbar = P * P * (1 + 2 * s_) + 2 * P * (1 - P) * (1 + s_) + (1 - P) ** 2
        pnext = pp / wbar
        P = rng.binomial(2 * Nk, pnext) / (2 * Nk)
        if np.all((P == 0) | (P == 1)):
            break
    sim.append(dict(s=s_, sim=float(np.mean(P == 1)), kimura=float(kimura(p0, Nk, s_)) if s_ > 0 else p0))
res['kimura'] = sim

json.dump(res, open(os.path.join(OUT, 'ch04_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

# ---------------- 图 ----------------
ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
ax = axes[0]
pp = np.linspace(0, 1, 201)
ax.plot(pp, pp ** 2, color=ps.NAVY, lw=2, label='$A_1A_1$：$p^2$')
ax.plot(pp, 2 * pp * (1 - pp), color=ps.ORANGE, lw=2, label='$A_1A_2$：$2pq$')
ax.plot(pp, (1 - pp) ** 2, color=ps.GREEN, lw=2, label='$A_2A_2$：$q^2$')
for F, ls in [(0.25, '--'), (0.5, ':')]:
    ax.plot(pp, 2 * pp * (1 - pp) * (1 - F), color=ps.ORANGE, ls=ls, lw=1.2, label=f'杂合子，$F={F}$')
ax.set_xlabel('等位基因 $A_1$ 的频率 $p$'); ax.set_ylabel('基因型频率')
ps.panel_title(ax, 'A', 'Hardy–Weinberg 比例与近交的影响')
ax.legend(loc='upper center', ncol=2, fontsize=8)
ax = axes[1]
# de Finetti 三角图
def tern(P, H, Q):
    return H * 0 + (Q + 0.5 * H), H * np.sqrt(3) / 2  # x = 位置, y
tri = np.array([[0, 0], [1, 0], [0.5, np.sqrt(3) / 2], [0, 0]])
ax.plot(tri[:, 0], tri[:, 1], color='#333', lw=0.8)
x, y = tern(pp ** 2, 2 * pp * (1 - pp), (1 - pp) ** 2)
ax.plot(x, y, color=ps.NAVY, lw=2, label='Hardy–Weinberg 抛物线')
xs, ys = tern(np.array([233 / 747]), np.array([385 / 747]), np.array([129 / 747]))
ax.plot(xs, ys, 'o', color=ps.ORANGE, ms=7, label='冰岛 MN 血型资料')
F = res['microsat']
ax.text(0, -0.05, '$A_1A_1$', ha='center', va='top'); ax.text(1, -0.05, '$A_2A_2$', ha='center', va='top')
ax.text(0.5, np.sqrt(3) / 2 + 0.03, '$A_1A_2$', ha='center')
ax.set_aspect('equal'); ax.axis('off')
ps.panel_title(ax, 'B', 'de Finetti 图：基因型频率空间')
ax.legend(loc='upper right', fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig04_1_hwe.png')); plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10, 4))
ax = axes[0]
for (lab, tr), c in zip(traj.items(), [ps.NAVY, ps.ORANGE, ps.GREEN]):
    ax.plot(np.arange(T + 1), tr, color=c, lw=1.8, label=lab)
od = select(0.05, 1 - s1, 1, 1 - s2, T)
ax.plot(np.arange(T + 1), od, color=ps.GOLD, lw=1.8, label='超显性（平衡点 $s_1/(s_1+s_2)$）')
ax.set_xlabel('世代'); ax.set_ylabel('有害等位基因 $a$ 的频率 $q$')
ps.panel_title(ax, 'A', '确定性选择下的频率轨迹（$s=0.1$）')
ax.legend(fontsize=7.5)
ax = axes[1]
for r in range(R):
    ax.plot(paths[r], color=ps.NAVY, alpha=0.35, lw=0.8)
ax2 = ax.twinx()
ax2.plot(Hbar / 0.5, color=ps.ORANGE, lw=2, label='平均杂合度 $H_t/H_0$（模拟）')
ax2.plot(np.arange(G + 1), (1 - 1 / (2 * Npop)) ** np.arange(G + 1), '--', color=ps.GOLD, lw=1.5, label='理论 $(1-1/2N)^t$')
ax2.set_ylim(0, 1.02); ax2.spines['right'].set_visible(True); ax2.set_ylabel('杂合度比例')
ax2.legend(loc='upper right', fontsize=8)
ax.set_xlabel('世代'); ax.set_ylabel('等位基因频率')
ps.panel_title(ax, 'B', f'Wright–Fisher 漂变（$N={Npop}$，30 个重复群体）')
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig04_2_selection_drift.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
