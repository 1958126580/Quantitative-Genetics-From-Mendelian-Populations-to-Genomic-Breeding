"""《数量遗传学——从孟德尔群体到基因组育种》第27章 推导与算例数值复核

复核内容：原始/对偶广义岭后验、目标/源风险、稀疏混合后验（含数值积分）与留一/家系留出误差。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch27_derivation_checks.py
输出：results/ch27_derivation_checks.json
"""
from pathlib import Path
import json
import math
import numpy as np
from numpy.testing import assert_allclose as eq
from scipy.integrate import quad

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch27_derivation_checks.json'
results = {}


def save(name, value):
    if isinstance(value, np.ndarray): value = value.tolist()
    results[name] = value


# 第27章：primal/dual posterior and differing test cross-covariance
W=np.array([[1.,1.]]);D=np.diag([1.,4.]);R=np.eye(1);Y=np.array([2.]);star=np.array([1.,-1.])
C=np.linalg.inv(np.linalg.inv(D)+W.T@W)
alpha=C@W.T@Y;K=W@D@W.T
eq(alpha,D@W.T@np.linalg.solve(K+R,Y))
eq(alpha,[1/3,4/3]);eq(star@alpha,-1);eq(star@C@star,3.5)
Dp=np.diag([4.,1.]);alphap=Dp@W.T@np.linalg.solve(W@Dp@W.T+R,Y)
eq(star@alphap,1)
save("27.16_generalized_ridge",{"alpha":alpha.tolist(),"test_variance":float(star@C@star)})
S=np.diag([9.,1.]);beta=np.array([1.,0.])
def risk(lam,T):
    ai=np.linalg.inv(S+lam*np.eye(2));bias=-lam*ai@beta
    return float(bias@T@bias+np.trace(T@ai@S@ai))
tar=[risk(l,np.diag([1.,9.])) for l in [1,3,9]]
src=[risk(l,np.diag([9.,1.])) for l in [1,3,9]]
eq(tar,[2.35,.6875,.367777777777778]);eq(src,[1.15,1.1875,2.51])
save("27.17_target_risks",{"target":tar,"source":src})
s2=.25;t2=1.;pi=.05;z=1.5
bf=math.sqrt(s2/(s2+t2))*math.exp(z*z*t2/(2*s2*(s2+t2)))
q=pi*bf/(1-pi+pi*bf);k=t2/(s2+t2)
v=q*s2*t2/(s2+t2)+q*(1-q)*(k*z)**2
def mixmean(z):
    bf=math.sqrt(s2/(s2+t2))*math.exp(z*z*t2/(2*s2*(s2+t2)))
    qq=pi*bf/(1-pi+pi*bf)
    return qq*k*z
eq((mixmean(z+1e-6)-mixmean(z-1e-6))/(2e-6),v/s2,rtol=1e-8)
# independent integration over slab plus spike mass
phi=lambda x,vv:math.exp(-x*x/(2*vv))/math.sqrt(2*math.pi*vv)
norm=(1-pi)*phi(z,s2)+pi*quad(lambda a:phi(z-a,s2)*phi(a,t2),-np.inf,np.inf)[0]
mi=pi*quad(lambda a:a*phi(z-a,s2)*phi(a,t2),-np.inf,np.inf)[0]/norm
ei2=pi*quad(lambda a:a*a*phi(z-a,s2)*phi(a,t2),-np.inf,np.inf)[0]/norm
eq(mi,mixmean(z),rtol=1e-10);eq(ei2-mi*mi,v,rtol=1e-10)
save("27.18_sparse_posterior",{"BF":bf,"q":q,"mean":mi,"variance":v,"derivative":v/s2})
K=np.array([[1.,.5],[.5,1.]])
eq(1-np.ones(2)@np.linalg.solve(K,np.ones(2)),-1/3)
eq(1-np.ones(2)@np.linalg.solve(K+.25*np.eye(2),np.ones(2)),-1/7)
eq(1-np.full(2,.8)@np.linalg.solve(K,np.full(2,.8)),.146666666666667)
K=np.kron(np.eye(2),np.ones((2,2)));Y=np.array([1,1,-1,-1.])
Sm=K@np.linalg.inv(K+np.eye(4));e=Y-Sm@Y
loo=e/(1-np.diag(Sm))
groups=[]
for inds in [[0,1],[2,3]]:
    idx=np.array(inds);groups.extend(np.linalg.solve(np.eye(2)-Sm[np.ix_(idx,idx)],e[idx]))
eq(np.mean(loo**2),.25);eq(np.mean(np.array(groups)**2),1)
gcv=np.mean(e**2)/(1-np.trace(Sm)/4)**2;eq(gcv,.25)
save("27.20_leaveout",{"LOO_MSE":float(np.mean(loo**2)),"family_MSE":1.,"GCV":gcv})


n_checks = len(results)
results["status"] = "passed"
results["scope"] = "Independent synthetic mathematical checks only; no empirical animal data or document dependencies."
OUT_FILE.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第27章：共 {n_checks} 项复核全部通过')
