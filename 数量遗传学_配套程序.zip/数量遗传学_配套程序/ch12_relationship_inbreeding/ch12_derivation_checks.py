"""《数量遗传学——从孟德尔群体到基因组育种》第12章 推导与算例数值复核

复核内容：递推亲缘矩阵 A、行列式与孟德尔创新方差、二次型、分数亲本方差、精度矩阵公式与图拉普拉斯对比方差。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch12_derivation_checks.py
输出：results/ch12_derivation_checks.json
"""
from fractions import Fraction as F
from pathlib import Path
import json
import math
import numpy as np

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch12_derivation_checks.json'
results = []


def check(name, actual, expected, tol=1e-10):
    assert math.isclose(float(actual), float(expected), rel_tol=tol, abs_tol=tol), (name, actual, expected)
    results.append({'name': name, 'actual': float(actual), 'expected': float(expected), 'passed': True})


A=np.zeros((4,4))
parents=[(-1,-1),(-1,-1),(0,1),(0,2)]
D=np.zeros(4);T=np.zeros((4,4))
for i,(s,d) in enumerate(parents):
    if s<0:
        A[i,i]=1;D[i]=1
    else:
        T[i,s]=T[i,d]=.5
        for j in range(i):
            A[i,j]=A[j,i]=.5*(A[s,j]+A[d,j])
        A[i,i]=1+.5*A[s,d]
        D[i]=1-.25*(A[s,s]+A[d,d])
expect=np.array([[1,0,.5,.75],[0,1,.5,.25],[.5,.5,1,.75],[.75,.25,.75,1.25]])
check('12.18 recursive A',np.max(np.abs(A-expect)),0)
check('12.18 determinant',np.linalg.det(A),.25)
check('12.18 innovation last',D[-1],.5)
uv=np.array([2.,0.,1.,2.]);eta=(np.eye(4)-T)@uv
check('12.18 quadratic via inverse',uv@np.linalg.solve(A,uv),4.5)
check('12.18 quadratic via innovation',np.sum(eta**2/D),4.5)
check('12.18 next-generation innovation',.5-.25*.25,F(7,16))
q=.5
check('12.19 averaged conditional variance',.5+.5*q*(1-q),F(5,8))
check('12.19 incorrect fractional-parent variance',.25**2+.25**2+.5**2+.5,F(7,8))
check('12.19 correct fractional-parent variance',.25**2+.25**2+.5**2+F(5,8),1)
check('12.19 different-mean mixture variance',1+.5*1**2+.5*(-1)**2,2)
AF=np.array([[1,.4,.7],[.4,1,.7],[.7,.7,1.2]])
inverse_expect=np.array([[71/42,1/42,-1],[1/42,71/42,-1],[-1,-1,2.]])
check('12.20 determinant',np.linalg.det(AF),.42)
check('12.20 precision formula',np.max(np.abs(np.linalg.inv(AF)-inverse_expect)),0)
check('12.20 offspring group mean',.5*2+.5*(-1),.5)
edges=[np.array([-1.,1.,0.]),np.array([0.,-1.,1.]),np.array([-1.,0.,1.])]
c=edges[-1];LP=sum(np.outer(b,b) for b in edges[:2]);LT=sum(np.outer(b,b) for b in edges)
ip=np.linalg.pinv(LP);it=np.linalg.pinv(LT)
check('12.21 path contrast variance',c@ip@c,2)
check('12.21 triangle contrast variance',c@it@c,F(2,3))
check('12.21 combined contrast estimate',(2+3/2)/(1+1/2),F(7,3))
check('12.21 cycle residual variance',1+1+1,3)
for j,b in enumerate(edges):
    reduced=LT-np.outer(b,b)
    expected=2 if j==2 else 1
    check(f'12.22 delete edge {j}',c@np.linalg.pinv(reduced)@c,expected)
check('12.22 direct-edge deletion formula',(c@it@c)**2/(1-c@it@c),F(4,3))
check('12.22 direct-edge bias coefficient',c@it@c,F(2,3))
check('12.22 average single-edge-loss variance',F(1,3)*(2+1+1),F(4,3))

OUT_FILE.write_text(json.dumps({'chapter': 12, 'checks': results, 'count': len(results), 'all_passed': True},
                               ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第12章：共 {len(results)} 项复核全部通过')
