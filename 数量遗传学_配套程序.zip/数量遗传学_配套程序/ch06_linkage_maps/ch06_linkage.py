"""第6章 遗传连锁与连锁图谱：作图函数、LOD、分组、排序与图距估计。

运行：python ch06_linkage.py
"""
import json, os, sys, itertools
import numpy as np
from scipy import stats, optimize

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
DATA = os.path.join(HERE, 'data')
res = {}

haldane_c = lambda d: 0.5 * (1 - np.exp(-2 * d))
haldane_d = lambda c: -0.5 * np.log(1 - 2 * c)
kosambi_c = lambda d: 0.5 * np.tanh(2 * d)
kosambi_d = lambda c: 0.25 * np.log((1 + 2 * c) / (1 - 2 * c))
res['map_functions'] = dict(d=0.2, haldane=haldane_c(0.2), kosambi=kosambi_c(0.2), complete=0.2,
                            c_AC_no_interf=0.2 + 0.3 - 2 * 0.2 * 0.3)

# 1. 回交两点连锁
n1, n2 = 38 + 36, 16 + 10
c = n2 / (n1 + n2)
ll = lambda c: n1 * np.log(1 - c) + n2 * np.log(c)
res['backcross'] = dict(c_hat=c, ll_hat=ll(c), ll_half=ll(0.5), LR=2 * (ll(c) - ll(0.5)), LOD=(ll(c) - ll(0.5)) / np.log(10),
                        p=1 - stats.chi2.cdf(2 * (ll(c) - ll(0.5)), 1), se=np.sqrt(c * (1 - c) / 100),
                        d_haldane_cM=100 * haldane_d(c), d_kosambi_cM=100 * kosambi_d(c))

# 2. 三点排序
counts = {'ABC': 50, 'ABc': 7, 'Abc': 32, 'AbC': 11}
def order_ll(n):
    n1, n2, n3, n4 = n; N = sum(n)
    c12 = (n3 + n4) / N; c23 = (n2 + n4) / N
    p = [(1 - c12) * (1 - c23), (1 - c12) * c23, c12 * (1 - c23), c12 * c23]
    return sum(k * np.log(pp) for k, pp in zip(n, p)), c12, c23
orders = {'ABC': (50, 7, 32, 11), 'ACB': (50, 11, 32, 7), 'BAC': (50, 7, 11, 32)}
res['three_point'] = {k: dict(zip(['loglik', 'c12', 'c23'], order_ll(v))) for k, v in orders.items()}

# 3. 分组
L = np.array([[0, .4, 9.0, 2.9, .6], [.4, 0, .6, .4, 11.7], [9.0, .6, 0, 7.8, .7], [2.9, .4, 7.8, 0, .3], [.6, 11.7, .7, .3, 0]])
names = 'ABCDE'
def group(L, thr):
    left = set(range(len(L))); groups = []
    while left:
        idx = sorted(left)
        sub = L[np.ix_(idx, idx)]
        i, j = np.unravel_index(np.argmax(sub), sub.shape)
        if sub[i, j] < thr:
            groups += [[k] for k in idx]; break
        g = {idx[i], idx[j]}; changed = True
        while changed:
            changed = False
            for k in list(left - g):
                if max(L[k, m] for m in g) >= thr: g.add(k); changed = True
        groups.append(sorted(g)); left -= g
    return [''.join(names[k] for k in g) for g in groups]
res['grouping'] = {'thr5': group(L, 5.0), 'thr3': group(L, 3.0), 'thr2': group(L, 2.0)}

# 4. 模拟回交资料：12 个标记、一条 120 cM 染色体
rng = np.random.default_rng(6)
true_pos = np.sort(np.concatenate([[0, 120], rng.uniform(0, 120, 10)]))
M = len(true_pos); n = 150
gaps = np.diff(true_pos) / 100
G = np.zeros((n, M), int)
G[:, 0] = rng.integers(0, 2, n)
for j in range(1, M):
    rec = rng.random(n) < haldane_c(gaps[j - 1])
    G[:, j] = np.where(rec, 1 - G[:, j - 1], G[:, j - 1])
perm = rng.permutation(M)              # 打乱标记顺序
Gs = G[:, perm]
np.savetxt(os.path.join(DATA, 'backcross_sim_genotypes.csv'), Gs, fmt='%d', delimiter=',',
           header=','.join(f'M{k+1}' for k in range(M)), comments='')
C = np.zeros((M, M)); LOD = np.zeros((M, M))
for i in range(M):
    for j in range(M):
        if i == j: continue
        r = np.mean(Gs[:, i] != Gs[:, j]); r = min(max(r, 1e-6), 0.5)
        C[i, j] = r
        LOD[i, j] = (n * (r * np.log10(r) + (1 - r) * np.log10(1 - r)) - n * np.log10(0.5)) if r < 0.5 else 0
# 排序：最小化相邻重组率之和（贪心 + 2-opt）
def total(order): return sum(C[order[k], order[k + 1]] for k in range(M - 1))
best = None
for start in range(M):
    order = [start]; left = set(range(M)) - {start}
    while left:
        nxt = min(left, key=lambda k: C[order[-1], k]); order.append(nxt); left.remove(nxt)
    improved = True
    while improved:
        improved = False
        for i in range(1, M - 1):
            for j in range(i + 1, M):
                new = order[:i] + order[i:j + 1][::-1] + order[j + 1:]
                if total(new) < total(order) - 1e-12: order = new; improved = True
    if best is None or total(order) < total(best): best = order
est_order = best
true_rank = np.argsort(np.argsort(true_pos[perm]))
rank_est = [true_rank[k] for k in est_order]
if rank_est[0] > rank_est[-1]: est_order = est_order[::-1]; rank_est = rank_est[::-1]
# Stam 加权最小二乘估计图距（Kosambi，相距不超过 3 个区间的标记对）
def stam(order, mapd=None):
    mapd = mapd or kosambi_d
    k = len(order) - 1
    rows, y, w = [], [], []
    for a in range(len(order)):
        for b in range(a + 1, min(len(order), a + 4)):
            r = C[order[a], order[b]]
            if r >= 0.49: continue
            row = np.zeros(k); row[a:b] = 1
            rows.append(row); y.append(mapd(r)); w.append(max(LOD[order[a], order[b]], 0.1) ** 2)
    X = np.array(rows); y = np.array(y); W = np.diag(w)
    return np.linalg.solve(X.T @ W @ X, X.T @ W @ y)
dist = stam(est_order, haldane_d)
dist_k = stam(est_order, kosambi_d)
est_pos = np.concatenate([[0], np.cumsum(dist)]) * 100
true_sorted = np.sort(true_pos)
res['simulated_map'] = dict(n=n, true_positions=true_sorted.tolist(), est_order_true_rank=[int(x) for x in rank_est],
                            est_positions_cM=est_pos.tolist(), est_length=float(est_pos[-1]), est_length_kosambi=float(100*dist_k.sum()), true_length=120.0)

# 5. F2 互交中重组率的 EM 估计（共显性两点）
cF = 0.2; nF = 300
def f2_sim(c, n):
    g1 = rng.random((n, 2)) < 0.5  # 每条配子 A 位点是否来自亲本1
    rec = rng.random((n, 2)) < c
    g2 = np.where(rec, ~g1, g1)
    return g1.sum(1), g2.sum(1)
a, b = f2_sim(cF, nF)
tab = np.zeros((3, 3), int)
for x, y in zip(a, b): tab[x, y] += 1
def f2_em(tab, c=0.25, it=200):
    N = tab.sum()
    for _ in range(it):
        dh = tab[1, 1]
        # 双杂合中相引相（两个非重组配子）概率
        pc = (1 - c) ** 2 / ((1 - c) ** 2 + c ** 2)
        # 期望重组配子数
        R = (tab[0, 1] + tab[1, 0] + tab[1, 2] + tab[2, 1]) * 1 + (tab[0, 2] + tab[2, 0]) * 2 + dh * (1 - pc) * 2
        c = R / (2 * N)
    return c
res['f2_em'] = dict(true_c=cF, n=nF, table=tab.tolist(), c_hat=f2_em(tab))

json.dump(res, open(os.path.join(OUT, 'ch06_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
ax = axes[0]
d = np.linspace(0, 1.5, 300)
ax.plot(d * 100, d, color=ps.GREY, ls=':', label='完全干涉 $c=d$')
ax.plot(d * 100, haldane_c(d), color=ps.NAVY, lw=2, label='Haldane（无干涉）')
ax.plot(d * 100, kosambi_c(d), color=ps.ORANGE, lw=2, label='Kosambi（部分干涉）')
ax.axhline(0.5, color='#999', lw=0.7)
ax.set_ylim(0, 0.6); ax.set_xlabel('图距 $d$（cM）'); ax.set_ylabel('重组率 $c$')
ps.panel_title(ax, 'A', '作图函数'); ax.legend()
ax = axes[1]
ordL = LOD[np.ix_(est_order, est_order)]
im = ax.imshow(ordL, cmap='Blues', vmin=0, vmax=np.percentile(ordL, 98))
for k in range(M):
    ax.text(k, k, '', ha='center')
ax.set_xticks(range(M)); ax.set_yticks(range(M))
lab = [f'M{perm[k]+1}' for k in est_order]
lab = [f'M{k+1}' for k in est_order]
ax.set_xticklabels(lab, rotation=90, fontsize=7); ax.set_yticklabels(lab, fontsize=7)
cb = fig.colorbar(im, ax=ax, shrink=0.8); cb.set_label('两点 LOD')
ps.panel_title(ax, 'B', '排序后的两点 LOD 矩阵（模拟回交）')
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig06_1_map_functions_lod.png')); plt.close(fig)

fig, ax = plt.subplots(figsize=(8, 2.6))
for y, pos, col, lab in [(1, true_sorted, ps.NAVY, '真实位置'), (0, est_pos, ps.ORANGE, '估计位置')]:
    ax.plot([0, pos[-1]], [y, y], color=col, lw=3, solid_capstyle='round', alpha=0.35)
    ax.plot(pos, [y] * len(pos), '|', color=col, ms=18, mew=2)
    ax.text(-4, y, lab, ha='right', va='center')
for k in range(M):
    ax.plot([true_sorted[rank_est[k]], est_pos[k]], [0.9, 0.1], color=ps.GREY, lw=0.6)
ax.set_xlim(-30, 135); ax.set_ylim(-0.5, 1.5); ax.set_yticks([]); ax.set_xlabel('cM')
ax.spines['left'].set_visible(False)
ax.set_title('150 个回交后代、12 个标记的图谱重建（Haldane 函数，Stam 加权最小二乘）', fontsize=10.5)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig06_2_map_reconstruction.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
