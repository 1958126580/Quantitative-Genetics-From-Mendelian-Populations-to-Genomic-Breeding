"""《数量遗传学——从孟德尔群体到基因组育种》第36章 推导与算例数值复核

复核内容：KKT 最优配种贡献（含界约束解）、运输线性规划、整数可行解、联合风险与信息价值。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch36_derivation_checks.py
输出：results/ch36_derivation_checks.json
"""
from pathlib import Path
import json
import math
import numpy as np
from scipy.stats import norm
from scipy.optimize import minimize, linprog

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch36_derivation_checks.json'


def close(a, b, tol=1e-10):
    assert np.max(np.abs(np.asarray(a) - np.asarray(b))) < tol


out = {}
h=np.array([4.,2.,3.,1.])
fun=lambda c: -float(h@c)
qfun=lambda c: float(c@c/2)
constraints=[{'type':'eq','fun':lambda c:c[:2].sum()-.5},
             {'type':'eq','fun':lambda c:c[2:].sum()-.5},
             {'type':'ineq','fun':lambda c:.145-qfun(c)}]
sol=minimize(fun,np.ones(4)/4,bounds=[(0,.5)]*4,
             constraints=constraints,method='SLSQP',
             options={'ftol':1e-13,'maxiter':1000})
assert sol.success
close(sol.x,[.35,.15,.35,.15],1e-6)
yb=math.sqrt(.02-.07**2)
out['36_kkt']={'solution':sol.x.tolist(),'objective':-sol.fun,
    'coancestry':qfun(sol.x),'lambda':10.,
    'bound_active_solution':[.32,.18,.25+yb,.25-yb],
    'bound_objective':2.5+2*(.07+yb),
    'bound_lambda':1/yb,'bound_multiplier':2-2*.07/yb}
cost=np.array([[.2,0.],[0.,.1]])
Ae=np.array([[1,1,0,0],[0,0,1,1],[1,0,1,0],[0,1,0,1]])
rhs=[.6,.4,.5,.5]
transport=linprog(cost.ravel(),A_eq=Ae,b_eq=rhs,
                   bounds=(0,None),method='highs')
assert transport.success
close(transport.x,[.1,.5,.4,0.])
bad=linprog(cost.ravel(),A_eq=Ae,b_eq=rhs,
            bounds=[(0,0),(0,None),(0,None),(0,None)],method='highs')
assert bad.status==2
out['36_transport']={'plan':transport.x.reshape(2,2).tolist(),
    'cost':float(transport.fun),'dual_value':.4*(-.2)+.5*.2,
    'forbidden11_infeasible':True}
cap=.138
feasible=[]
for ks in range(11):
    for kd in range(11):
        c=np.array([ks,10-ks,kd,10-kd])/20
        if qfun(c)<=cap+1e-12:
            feasible.append((float(h@c),ks,kd,qfun(c)))
best=max(row[0] for row in feasible)
out['36_integer']={'cap':cap,'continuous':2.5+2*math.sqrt(2*(cap-.125)),
    'continuous_first_count':5+20*math.sqrt((cap-.125)/2),
    'integer_best':best,
    'all_best':[list(row) for row in feasible if abs(row[0]-best)<1e-12],
    'naive_7_7_coancestry':qfun(np.array([7,3,7,3])/20)}
out['36_joint_risk']={'joint_success_independent':float(norm.cdf(2)*norm.cdf(1.5)),
    'failure1':float(norm.cdf(-2)),'failure2':float(norm.cdf(-1.5)),
    'joint_success_sd_doubled':float(norm.cdf(1)*norm.cdf(.75))}
positive_part=lambda mu,sd: sd*norm.pdf(mu/sd)+mu*norm.cdf(mu/sd)
out['36_information_value']={'evpi':float(positive_part(.2,.5)-.2),
    'evsi':float(positive_part(.2,math.sqrt(.125))-.2),
    'posterior_variance_difference':.125,
    'prior_variance_posterior_mean':.125}


OUT_FILE.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第36章：共 {len(out)} 项复核全部通过')
