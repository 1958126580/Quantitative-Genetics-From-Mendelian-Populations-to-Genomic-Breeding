# 第25章　基因组时代的遗传力：缺失遗传力与多基因架构

本文件夹为《数量遗传学——从孟德尔群体到基因组育种》第25章的配套程序与资料。

**内容**：GREML与HE回归估计SNP遗传力、LD分数回归、Daetwyler预测准确度公式（msprime模拟）。

**文件**：

- `ch25_heritability.py`
- `results/`：运行输出（JSON、CSV与图形）

**运行**：在本文件夹下执行 `python <脚本名>`，或在上一级目录执行 `python run_all.py 25`。

