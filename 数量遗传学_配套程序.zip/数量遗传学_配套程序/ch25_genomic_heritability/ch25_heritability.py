"""第25章 基因组时代的遗传力：GREML 与 HE 回归估计 SNP 遗传力、致因变异频率
对“被捕获遗传力”的影响、LD 分数回归、多基因得分预测准确度（Daetwyler 公式）。

运行：python ch25_heritability.py   （需要 msprime）
"""
import json, os, sys
import numpy as np
from scipy import stats, optimize
import msprime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(25)
res = {}

# 1. 溯祖模拟：3000 个无关个体，10 条染色体
n = 3000
Hs, chroms = [], []
for c in range(10):
    ts = msprime.sim_ancestry(samples=n, population_size=5000, sequence_length=5e6, recombination_rate=1e-8, random_seed=500 + c)
    ts = msprime.sim_mutations(ts, rate=1e-8, random_seed=600 + c)
    G = ts.genotype_matrix().astype(np.int8)
    Hs.append(G[:, 0::2] + G[:, 1::2]); chroms += [c] * G.shape[0]
X = np.vstack(Hs).T.astype(float)  # 个体 × 全部变异
chroms = np.array(chroms)
freq = X.mean(0) / 2; maf = np.minimum(freq, 1 - freq)
res['n_variants_total'] = int(X.shape[1])
# “芯片”：常见变异（MAF>=0.05）中随机取 30000 个
common = np.where(maf >= 0.05)[0]; rare = np.where((maf > 0.001) & (maf < 0.01))[0]
chip = np.sort(rng.choice(common, min(30000, len(common)), replace=False))
def stdz(M):
    p = M.mean(0) / 2; return (M - 2 * p) / np.sqrt(2 * p * (1 - p))
Zc = stdz(X[:, chip]); Mchip = Zc.shape[1]
Gm = Zc @ Zc.T / Mchip
off = Gm[np.triu_indices(n, 1)]
res['chip'] = dict(M=Mchip, var_offdiag_G=float(off.var()), mean_diag=float(np.diag(Gm).mean()))
ev, U = np.linalg.eigh(Gm)

def reml_h2(y):
    y = y - y.mean(); yt = U.T @ y; Xt = U.T @ np.ones(n)
    def nll(logd):
        d = np.exp(logd); w = 1 / (ev + d)
        XtWX = np.sum(Xt * Xt * w); b = np.sum(Xt * yt * w) / XtWX; r = yt - Xt * b
        sg2 = np.sum(w * r * r) / (n - 1)
        return 0.5 * ((n - 1) * np.log(sg2) + np.sum(np.log(ev + d)) + np.log(XtWX))
    o = optimize.minimize_scalar(nll, bounds=(-7, 7), method='bounded')
    return 1 / (1 + np.exp(o.x))
def he_h2(y):
    y = (y - y.mean()) / y.std()
    iu = np.triu_indices(n, 1); prod = np.outer(y, y)[iu]
    return float(np.sum(Gm[iu] * prod) / np.sum(Gm[iu] ** 2))

def make_trait(idx, h2):
    Zq = stdz(X[:, idx]); b = rng.normal(0, 1, len(idx))
    g = Zq @ b; g = (g - g.mean()) / g.std() * np.sqrt(h2)
    return g + rng.normal(0, np.sqrt(1 - h2), n)

scen = {}
for name, pool in [('致因为常见变异', common), ('致因为稀有变异（MAF<0.01）', rare)]:
    est_r, est_h = [], []
    for r in range(10):
        idx = rng.choice(pool, 500, replace=False)
        y = make_trait(idx, 0.5)
        est_r.append(reml_h2(y)); est_h.append(he_h2(y))
    scen[name] = dict(true_h2=0.5, reml_mean=float(np.mean(est_r)), reml_sd=float(np.std(est_r)), he_mean=float(np.mean(est_h)))
res['scenarios'] = scen
res['se_theory_316_over_N'] = 316 / n
res['se_from_varG'] = float(np.sqrt(2 / (n ** 2 * off.var())))

# 2. LD 分数回归（使用芯片位点，以样本 r^2 计算 LD 分数，窗口：整条染色体）
Zs = Zc
ld = np.zeros(Mchip); chipchr = chroms[chip]
for c in range(10):
    ix = np.where(chipchr == c)[0]
    R = (Zs[:, ix].T @ Zs[:, ix]) / n
    R2 = R ** 2 - (1 - R ** 2) / (n - 2)
    for k in range(len(ix)):
        lo, hi = 0, len(ix)
        ld[ix[k]] = R2[k, lo:hi].sum()
idx = rng.choice(common, 1000, replace=False)
y = make_trait(idx, 0.5); ys = (y - y.mean()) / y.std()
chi2 = (Zs.T @ ys / np.sqrt(n)) ** 2 / (1 - 0)  # 近似
# 加入分层：给一半个体加常数，与少量位点相关（简化：模拟一个与第一主成分相关的偏移）
w = 1 / np.maximum(ld, 1)
A = np.column_stack([np.ones(Mchip), n * ld / Mchip])
coef = np.linalg.lstsq(A * np.sqrt(w)[:, None], chi2 * np.sqrt(w), rcond=None)[0]
res['ldsc'] = dict(mean_chi2=float(chi2.mean()), intercept=float(coef[0]), h2_ldsc=float(coef[1]), true_h2=0.5,
                   note='芯片位点捕获的遗传力低于真实 h2 时，LDSC 斜率估计的是被捕获部分')

# 3. Daetwyler 公式
def daet(N, h2, Me): return np.sqrt(N * h2 / (N * h2 + Me))
res['daetwyler'] = {f'N={N},h2={h2},Me={Me}': float(daet(N, h2, Me)) for N in (1e3, 1e4, 1e5, 1e6) for h2 in (0.3,) for Me in (1000, 60000)}
json.dump(res, open(os.path.join(OUT, 'ch25_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 3.9))
ax = axes[0]
bins = np.linspace(0, 20, 41)
cent = 0.5 * (bins[1:] + bins[:-1]); mc = []
for i in range(40):
    m = (ld >= bins[i]) & (ld < bins[i + 1]); mc.append(chi2[m].mean() if m.sum() > 20 else np.nan)
ax.plot(cent, mc, 'o', color=ps.NAVY, ms=4, label='按 LD 分数分组的平均 $\\chi^2$')
xx = np.linspace(0, 20, 50); ax.plot(xx, coef[0] + n * xx / Mchip * coef[1], color=ps.ORANGE, lw=1.8, label='加权回归直线')
ax.set_xlabel('LD 分数 $\\ell_j$'); ax.set_ylabel('平均 $\\chi^2$ 统计量')
ps.panel_title(ax, 'A', 'LD 分数回归'); ax.legend(fontsize=8)
ax = axes[1]
NN = np.logspace(2, 7, 200)
for Me, col in [(1000, ps.NAVY), (10000, ps.GREEN), (60000, ps.ORANGE)]:
    ax.plot(NN, daet(NN, 0.5, Me) ** 2 / 0.5 * 0.5, color=col, lw=1.8, label=f'$M_e$={Me}')
ax.axhline(0.5, color=ps.GREY, ls='--', lw=1); ax.text(1.5e2, 0.51, '遗传力上限 $h^2=0.5$', fontsize=8, color=ps.GREY)
ax.set_xscale('log'); ax.set_xlabel('训练群体大小 $N$'); ax.set_ylabel('预测解释的表型方差 $R^2$')
ps.panel_title(ax, 'B', '多基因预测的期望准确度'); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig25_1_ldsc_prediction.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
