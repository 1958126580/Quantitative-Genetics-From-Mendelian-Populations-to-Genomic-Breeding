"""《数量遗传学——从孟德尔群体到基因组育种》第23章 推导与算例数值复核

复核内容：非线性 REML 得分与 Hessian 的有限差分复核、有效信息、LRT 尾概率、delta 法与逆伽马/Student 后验。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch23_derivation_checks.py
输出：results/ch23_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np
from scipy.stats import chi2, invgamma, t as student_t

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch23_derivation_checks.json'
records = []


def check(name, actual, expected, atol=1e-9, rtol=1e-8):
    a, b = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
    error = float(np.max(np.abs(a - b)))
    passed = bool(np.allclose(a, b, atol=atol, rtol=rtol))
    records.append({"name": name, "passed": passed,
                    "actual": a.tolist(), "expected": b.tolist(),
                    "max_absolute_error": error})
    if not passed:
        raise AssertionError(records[-1])


def residual_precision(V, X):
    W = np.linalg.inv(V)
    B = np.linalg.inv(X.T @ W @ X)
    Q = W - W @ X @ B @ X.T @ W
    return W, B, Q


# 第23章：analytic nonlinear REML Hessian versus independent finite differences.
X4 = np.ones((4, 1))
y4 = np.array([1., 3., 0., 2.])
dist = np.abs(np.arange(4)[:, None] - np.arange(4)[None, :])


def reml_elements(theta):
    eta, rho = theta
    K = rho ** dist
    Kr = np.zeros((4, 4))
    Krr = np.zeros((4, 4))
    mask = dist > 0
    Kr[mask] = dist[mask] * rho ** (dist[mask] - 1)
    mask2 = dist > 1
    Krr[mask2] = dist[mask2] * (dist[mask2] - 1) * rho ** (dist[mask2] - 2)
    V = np.exp(eta) * K
    Vd = [V, np.exp(eta) * Kr]
    Vdd = [[V, Vd[1]], [Vd[1], np.exp(eta) * Krr]]
    W, _, Q = residual_precision(V, X4)
    ll = -.5 * (np.linalg.slogdet(V)[1]
                 + np.linalg.slogdet(X4.T @ W @ X4)[1] + y4 @ Q @ y4)
    score = np.array([.5 * (y4 @ Q @ Vi @ Q @ y4 - np.trace(Q @ Vi)) for Vi in Vd])
    J = np.zeros((2, 2))
    info = np.zeros((2, 2))
    for i in range(2):
        for j in range(2):
            Vi, Vj, Vij = Vd[i], Vd[j], Vdd[i][j]
            J[i, j] = (y4 @ Q @ Vi @ Q @ Vj @ Q @ y4
                       - .5 * np.trace(Q @ Vi @ Q @ Vj)
                       - .5 * (y4 @ Q @ Vij @ Q @ y4 - np.trace(Q @ Vij)))
            info[i, j] = .5 * np.trace(Q @ Vi @ Q @ Vj)
    return ll, score, J, info


theta = np.array([np.log(2.), .3])
step = 1e-5
fd_score, fd_J = np.zeros(2), np.zeros((2, 2))
for j in range(2):
    direction = np.eye(2)[j] * step
    plus, minus = reml_elements(theta + direction), reml_elements(theta - direction)
    fd_score[j] = (plus[0] - minus[0]) / (2 * step)
    fd_J[:, j] = -(plus[1] - minus[1]) / (2 * step)
_, analytic_score, analytic_J, info = reml_elements(theta)
check("23.18 nonlinear REML score finite difference", analytic_score, fd_score, atol=1e-7)
check("23.18 nonlinear REML Hessian finite difference", analytic_J, fd_J, atol=1e-7)
check("23.18 scalar log variance score, observed, expected, average",
      [1.5, .5 * 4, .5, (.5 * 4 + .5) / 2], [1.5, 2, .5, 1.25])
dshape = np.array([0., .5, .75])
shape_info = .5 * (dshape @ dshape)
eff_info = shape_info - (.5 * dshape.sum()) ** 2 / 1.5
check("23.19 efficient information", [shape_info, eff_info], [13 / 32, 7 / 48])
check("23.19 standard errors", [shape_info ** -.5, eff_info ** -.5],
      [1.5689290811054724, 2.6186146828319083])
lrt = 4 * (1 - np.log(2))
check("23.20 LRT and exact/approximate tails",
      [lrt, chi2.sf(8, 4), .5 * chi2.sf(lrt, 1), chi2.cdf(4, 4)],
      [1.2274112777602189, .0915781944436709, .13395553711621852, .5939941502901616])
check("23.21 delta additional average MSE", 10 * .06 ** 2, .036)
check("23.21 delta conditional parameter variance", (5 * .06) ** 2, .09)
check("23.22 IG mean and mode", [invgamma.mean(3, scale=6), 6 / (3 + 1)], [3, 1.5])
check("23.22 Student posterior variance", student_t.var(6, scale=np.sqrt(2 / 3)), 1)
check("23.22 Student predictive variance", student_t.var(6, scale=np.sqrt(8 / 3)), 4)
J4 = np.eye(4) - np.ones((4, 4)) / 4
Vtrue = 2 * np.eye(4) + 2 * np.ones((4, 4))
check("23.23 fitted residual expectation", np.trace(J4 @ Vtrue) / 3, 2)
check("23.23 true mean variance", np.ones(4) @ Vtrue @ np.ones(4) / 16, 2.5)


result = {"status": "passed", "chapter": 23, "check_count": len(records), "checks": records,
          "conditions": "Synthetic teaching experiments; no empirical animal validation claimed."}
OUT_FILE.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第23章：共 {len(records)} 项复核全部通过')
