"""《数量遗传学——从孟德尔群体到基因组育种》第32章 推导与算例数值复核

复核内容：环境积分目标与 PEV、共享环境方差、设计分配、铰链积分、恢复曲线面积、状态空间更新与再生特征值。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch32_derivation_checks.py
输出：results/ch32_derivation_checks.json
"""
from pathlib import Path
import json
import math
import numpy as np
from scipy.integrate import quad
from scipy.stats import norm

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch32_derivation_checks.json'
checks = []


def verify(name, actual, expected, atol=1e-10, method="direct independent calculation"):
    a = np.asarray(actual, dtype=float)
    e = np.asarray(expected, dtype=float)
    ok = bool(np.allclose(a, e, atol=atol, rtol=0))
    checks.append(dict(name=name, actual=a.tolist(), expected=e.tolist(),
                       tolerance=atol, passed=ok, method=method))
    if not ok:
        raise AssertionError(f"{name}: {a} != {e}")


for env_var, target, pev in [(.2,1.9,.1004),(1,1.5,.11)]:
    a=np.array([2,1,-.5]); moment=np.array([1,0,env_var])
    verify(f"32_integrated_target_{env_var}",moment@a,target)
    verify(f"32_integrated_PEV_{env_var}",moment@np.diag([.1,.04,.01])@moment,pev)
# Shared random environment and uncertain zero-mean coefficient difference.
# Every state has probability 1/16, and the two vectors are independent.
signs=np.array([[-1,-1],[-1,1],[1,-1],[1,1]])
env_states=np.array([1.,.5])+signs*np.sqrt([.2,.3])
diff_states=signs*np.sqrt([.4,.2])
goal_states=(env_states@diff_states.T).ravel()
verify("32_shared_environment_zero_mean_difference_variance",goal_states.var(),.59,
       method="enumeration of 16 joint states; includes nonzero interaction trace .14")
w=np.array([.8,.2]); sd=np.array([1,3])
allocation=100*w*sd/np.sum(w*sd)
verify("32_design_allocation",allocation,[400/7,300/7])
verify("32_optimal_design_variance",np.sum(w*w*sd*sd/allocation),.0196)
verify("32_frequency_design_variance",np.sum(w*w*sd*sd/[80,20]),.026)
for sigma in [1,2]:
    integral=quad(lambda q:max(q,0)*norm.pdf(q,scale=sigma),-np.inf,np.inf)[0]
    verify(f"32_hinge_integral_{sigma}",integral,sigma/math.sqrt(2*math.pi))
    verify(f"32_hinge_animal_A_{sigma}",3-2*integral,2.2021 if sigma==1 else 1.4042,5e-5)
    verify(f"32_hinge_animal_B_{sigma}",2.5-.5*integral,2.3005 if sigma==1 else 2.1011,5e-5)
for label,A,k,area,half,window in [
    ("A",10,.5,20,1.3863,12.6424),
    ("B",6,.2,30,3.4657,9.8904)]:
    verify(f"32_recovery_area_{label}",quad(lambda t:A*np.exp(-k*t),0,np.inf)[0],area)
    verify(f"32_recovery_half_time_{label}",math.log(2)/k,half,5e-5)
    verify(f"32_recovery_two_day_area_{label}",quad(lambda t:A*np.exp(-k*t),0,2)[0],window,5e-5)
rho=.8; Q=.36; R=1
Pm=rho*rho+Q; gain=Pm/(Pm+R); P=(1-gain)*Pm
verify("32_state_predicted_mean",rho*2,1.6)
verify("32_state_predicted_variance",Pm,1)
verify("32_state_gain",gain,.5)
verify("32_state_updated_mean",rho*2+gain*(3-rho*2),2.3)
verify("32_state_updated_variance",P,.5)
P1=rho*rho*P+Q
verify("32_state_first_missing_variance",P1,.68)
verify("32_state_second_missing_variance",rho*rho*P1+Q,.7952)
latent=Q/(1-rho*rho)
verify("32_state_observed_lag_correlation",rho*latent/(latent+R),.4)
K=np.array([[1.2,.3],[.4,.6]])
verify("32_next_generation_eigenvalue",np.linalg.eigvals(K).max(),1.3583,5e-5)
verify("32_reduced_infectivity_eigenvalue",np.linalg.eigvals(K@np.diag([1,.5])).max(),1.2623,5e-5)
intensity=lambda L:(100+300/L)/50
verify("32_lifetime_intensity_3",intensity(3),4)
verify("32_lifetime_intensity_5",intensity(5),3.2)
eps=1e-5
deriv=(intensity(3+eps)-intensity(3-eps))/(2*eps)
verify("32_lifetime_local_derivative",deriv,-2/3,1e-9)


report = dict(status="passed", chapter=32, verified_date="2026-10-01", checks_count=len(checks), checks=checks,
              scope="Independent computations for specified teaching examples; no manuscript, Pandoc, or empirical-data dependency.")
OUT_FILE.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第32章：共 {len(checks)} 项复核全部通过')
