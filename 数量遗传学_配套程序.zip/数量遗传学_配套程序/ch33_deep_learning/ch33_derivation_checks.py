"""《数量遗传学——从孟德尔群体到基因组育种》第33章 推导与算例数值复核

复核内容：加权/不加权校准、先验概率调整、重要性有效样本、家系差标准误、集成方差/MSE 与保形区间。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch33_derivation_checks.py
输出：results/ch33_derivation_checks.json
"""
from pathlib import Path
import json
import math
import numpy as np

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch33_derivation_checks.json'
checks = []


def verify(name, actual, expected, atol=1e-10, method="direct independent calculation"):
    a = np.asarray(actual, dtype=float)
    e = np.asarray(expected, dtype=float)
    ok = bool(np.allclose(a, e, atol=atol, rtol=0))
    checks.append(dict(name=name, actual=a.tolist(), expected=e.tolist(),
                       tolerance=atol, passed=ok, method=method))
    if not ok:
        raise AssertionError(f"{name}: {a} != {e}")


scores=np.array([0.,1.,2.]); observed=np.array([.2,.5,1.4])
X=np.column_stack([np.ones(3),scores]); W=np.diag([10,40,10])
C=np.linalg.inv(X.T@W@X); b=C@X.T@W@observed
verify("33_weighted_calibration",b,[0,.6])
verify("33_unweighted_calibration",np.linalg.lstsq(X,observed,rcond=None)[0],[.1,.6])
verify("33_extrapolated_calibration_mean",np.array([1,3])@b,1.8)
verify("33_extrapolated_calibration_variance",np.array([1,3])@C@np.array([1,3]),.2167,5e-5)
verify("33_central_calibration_variance",np.array([1,1])@C@np.array([1,1]),.01667,5e-6)
for prior, expected in [(.01,.03883),(.05,.1739)]:
    lr=(.8/.2)/(.5/.5)
    target=lr*prior/(1-prior+lr*prior)
    verify(f"33_prior_probability_adjustment_{prior}",target,expected,5e-5)
weights=np.array([1,1,1,9.])
verify("33_importance_effective_n",weights.sum()**2/(weights@weights),12/7)
verify("33_shared_calibration_same_sign",.04*np.sum([1,1])**2,.16)
verify("33_shared_calibration_opposite_sign",.04*np.sum([1,-1])**2,0)
d=np.array([.1,.2,-.1,0])
verify("33_family_mean_difference",d.mean(),.05)
verify("33_family_sd",d.std(ddof=1),.1291,5e-5)
verify("33_family_standard_error",d.std(ddof=1)/math.sqrt(4),.06455,5e-6)
verify("33_ensemble_variance",4*(.8+.2/10),3.28)
verify("33_ensemble_MSE",1.5**2+4*(.8+.2/10),5.53)
verify("33_within_ensemble_spread_expectation",4*(1-.8),.8)
rank=math.ceil((19+1)*(1-.1))
verify("33_conformal_rank",rank,18)
verify("33_conformal_half_width",np.arange(1,20)[rank-1]*.05,.9)


report = dict(status="passed", chapter=33, verified_date="2026-10-01", checks_count=len(checks), checks=checks,
              scope="Independent computations for specified teaching examples; no manuscript, Pandoc, or empirical-data dependency.")
OUT_FILE.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第33章：共 {len(checks)} 项复核全部通过')
