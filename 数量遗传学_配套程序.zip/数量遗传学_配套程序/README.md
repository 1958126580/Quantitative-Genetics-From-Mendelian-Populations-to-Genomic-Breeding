# 《数量遗传学——从孟德尔群体到基因组育种》配套计算程序

梅步俊　著

本程序包与全书正文分离提供。全书三十七章，每章一个独立文件夹（`chNN_主题/`），内含该章的程序、所用资料（`data/`）与运行结果（`results/`）。书中各章的数值例题、插图与表格均可由相应程序重新计算得到。

## 环境与安装

需要 Python 3.10 或更高版本。依赖列于 `requirements.txt`：

```bash
python -m pip install -r requirements.txt
```

本程序包的参考结果在 Python 3.13、NumPy 2.5、SciPy 1.18、Matplotlib 3.11、msprime 1.4 下生成。插图使用思源黑体（Noto Sans CJK SC）显示中文；系统中没有该字体时，图形仍可生成，但中文可能显示为方框。

## 运行

```bash
python run_all.py          # 依次运行全部各章程序（约2分钟）
python run_all.py 7 25     # 只运行第7章与第25章
```

也可以进入任一章节文件夹，单独运行其中的程序。每个程序在本章 `results/` 文件夹中写入结果。全部随机模拟都固定了随机数种子，重复运行得到相同的结果；不同的软件版本或浮点环境可能使极小的尾数略有不同。

## 文件夹一览

| 章 | 文件夹 | 章名 | 程序 | 资料 |
|:--:|:--|:--|:--|:--:|
| 1 | `ch01_probability_prediction` | 概率、期望与遗传预测问题 | `ch01_derivation_checks.py` | — |
| 2 | `ch02_matrix_computation` | 矩阵方法与稳定计算 | `ch02_derivation_checks.py` | — |
| 3 | `ch03_statistical_inference` | 统计推断、似然与数量遗传学方法 | `ch03_inference.py` | 有 |
| 4 | `ch04_single_locus_population` | 单基因座群体模型与等位基因频率的演变 | `ch04_population.py` | 有 |
| 5 | `ch05_two_locus_LD` | 多基因座单倍型、连锁不平衡与重组 | `ch05_ld.py` | 有 |
| 6 | `ch06_linkage_maps` | 遗传连锁与连锁图谱的构建 | `ch06_linkage.py` | 有 |
| 7 | `ch07_qtl_mapping_crosses` | 杂交群体的数量性状位点定位 | `ch07_qtl.py` | 有 |
| 8 | `ch08_outbred_mapping_gwas` | 远交群体的连锁分析、关联定位与全基因组关联研究 | `ch08_gwas.py` | 有 |
| 9 | `ch09_genetic_values_variance` | 数量遗传与群体依赖性 | `ch09_derivation_checks.py` | — |
| 10 | `ch10_variance_components` | 遗传方差组分、重复力与性状间相关 | `ch10_variances.py` | — |
| 11 | `ch11_resemblance_relatives` | 亲属间的相似性与遗传协方差 | `ch11_resemblance.py` | — |
| 12 | `ch12_relationship_inbreeding` | 系谱亲缘、近交与遗传连接 | `ch12_derivation_checks.py` | — |
| 13 | `ch13_parameter_estimation` | 遗传参数的经典估计方法与试验设计 | `ch13_estimation.py` | 有 |
| 14 | `ch14_selection_response` | 选择反应的数量遗传理论 | `ch14_selection.py` | 有 |
| 15 | `ch15_selection_index` | 单性状选择指数与信息融合 | `ch15_derivation_checks.py` | — |
| 16 | `ch16_breeding_objectives` | 多性状育种目标与经济权重 | `ch16_derivation_checks.py` | — |
| 17 | `ch17_restricted_robust_index` | 限制指数、非线性目标与稳健决策 | `ch17_derivation_checks.py` | — |
| 18 | `ch18_index_dynamics` | 选择反应、世代间隔与长期遗传多样性 | `ch18_derivation_checks.py` | — |
| 19 | `ch19_drift_inbreeding` | 遗传漂变、有效群体大小与近交 | `ch19_inbreeding.py` | — |
| 20 | `ch20_heterosis_crossbreeding` | 杂种优势、配合力与杂交育种体系 | `ch20_crossbreeding.py` | 有 |
| 21 | `ch21_blup_mixed_models` | 从最小二乘到最佳线性无偏预测 | `ch21_derivation_checks.py` | — |
| 22 | `ch22_animal_models` | 动物模型与复杂遗传效应 | `ch22_derivation_checks.py` | — |
| 23 | `ch23_variance_components_reml` | 方差组分、限制似然与贝叶斯推断 | `ch23_derivation_checks.py` | — |
| 24 | `ch24_complex_phenotypes` | 多性状、阈值、生存与纵向遗传模型 | `ch24_derivation_checks.py` | — |
| 25 | `ch25_genomic_heritability` | 基因组时代的遗传力：缺失遗传力与多基因架构 | `ch25_heritability.py` | — |
| 26 | `ch26_genomic_relationships` | 基因型质量控制与基因组关系矩阵 | `ch26_derivation_checks.py` | — |
| 27 | `ch27_genomic_prediction_methods` | GBLUP、岭回归、贝叶斯与核方法 | `ch27_derivation_checks.py` | — |
| 28 | `ch28_single_step` | 单步基因组评定与大规模计算 | `ch28_derivation_checks.py` | — |
| 29 | `ch29_validation_design` | 验证设计、准确性、校准与跨群体迁移 | `ch29_derivation_checks.py` | — |
| 30 | `ch30_sequence_pangenome` | 全基因组序列、泛基因组与结构和稀有变异 | `ch30_derivation_checks.py` | — |
| 31 | `ch31_multiomics_causal` | 多组学、功能先验与因果推断 | `ch31_derivation_checks.py` | — |
| 32 | `ch32_gxe_reaction_norms` | 基因与环境互作、韧性和可持续育种 | `ch32_derivation_checks.py` | — |
| 33 | `ch33_deep_learning` | 深度学习与基因组基础模型 | `ch33_derivation_checks.py` | — |
| 34 | `ch34_data_reproducibility` | 从数据字典到可重复遗传评定 | `ch34_derivation_checks.py` | — |
| 35 | `ch35_pedigree_to_gblup_experiment` | 从系谱BLUP到GBLUP：一个可复算的肉羊教学实验 | `ch35_core_experiment.py`、`ch35_derivation_checks.py`、`ch35_extended_experiment.py`、`ch35_full_experiments.py` | — |
| 36 | `ch36_mating_decisions` | 多性状目标与约束配种的完整决策算例 | `ch36_derivation_checks.py` | — |
| 37 | `ch37_model_diagnostics` | 模型诊断、失败分析与可检验的研究设计 | `ch37_derivation_checks.py`、`ch37_leakage_control.py` | — |

`common/plotstyle.py` 为各章插图共用的绘图样式（字体、配色）。

## 程序类型

1. **模拟与资料分析程序**（第3—8、10、11、13、14、19、20、25章）：按正文的模型生成模拟资料，或读入 `data/` 中的教学资料，完成估计、检验与作图，输出正文引用的数值与插图。
2. **推导与算例复核程序**（`chNN_derivation_checks.py`）：用独立的数值计算逐项复核正文推导中的恒等式、解析例题与数值结果，并以断言保证一致；任何一项不符都会使程序报错停止。
3. **综合教学实验**（第35—37章）：肉羊育种的完整模拟流程，从系谱BLUP到GBLUP、方差参数错设与身份错配的影响、最优贡献与配种决策，以及信息泄漏的负对照实验。

## 资料说明

`data/` 中的资料分两类：一类为按正文模型生成的模拟资料；另一类为数量遗传学课程教学中的经典练习资料（如第13章的巢式设计资料、第14章的选择试验资料、第20章的双列杂交资料）。全部资料只用于教学与方法演示，不代表任何真实群体的参数。

程序中的数值复核只说明所规定模型及其实现的一致性；方法在真实群体中的有效性，需要另外的资料与验证设计。
