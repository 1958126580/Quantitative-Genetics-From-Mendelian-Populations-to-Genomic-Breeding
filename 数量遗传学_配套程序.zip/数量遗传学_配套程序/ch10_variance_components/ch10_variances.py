"""第10章 遗传方差组分、重复力与性状间相关：单位点与两位点方差分解、上位、
连锁不平衡对方差的影响、重复测定的收益与多效性产生的遗传相关。

运行：python ch10_variances.py
"""
import json, os, sys, itertools
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
res = {}

def single(p, a, d):
    q = 1 - p; alpha = a + (q - p) * d
    return dict(alpha=alpha, VA=2 * p * q * alpha ** 2, VD=(2 * p * q * d) ** 2, M=a * (p - q) + 2 * p * q * d)
res['pygmy_p0.6'] = single(0.6, 4, 2)
res['locusB'] = single(0.3, 3, -1)

# ---------- 两位点完全分解（单倍型层次，允许 LD 与上位） ----------
def two_locus(pA, pB, aA, dA, aB, dB, D=0.0, epi=None):
    """返回 VG, VA(按平均效应回归), VD, VI；epi 为 3x3 上位偏差矩阵（行 A 基因型 A1A1,A1A2,A2A2；列 B 同）"""
    epi = np.zeros((3, 3)) if epi is None else np.array(epi, float)
    # 单倍型频率：A1B1, A1B2, A2B1, A2B2
    h = np.array([pA * pB + D, pA * (1 - pB) - D, (1 - pA) * pB - D, (1 - pA) * (1 - pB) + D])
    alleles = [(1, 1), (1, 0), (0, 1), (0, 0)]  # (A1?, B1?)
    gA = {2: aA, 1: dA, 0: -aA}; gB = {2: aB, 1: dB, 0: -aB}
    rows = []
    for i, j in itertools.product(range(4), range(4)):
        f = h[i] * h[j]; xa = alleles[i][0] + alleles[j][0]; xb = alleles[i][1] + alleles[j][1]
        g = gA[xa] + gB[xb] + epi[2 - xa, 2 - xb]
        rows.append((f, xa, xb, g))
    R = np.array(rows); f, xa, xb, g = R.T
    mu = f @ g; VG = f @ (g - mu) ** 2
    # 加性：对 xa, xb 的加权最小二乘回归（剂量）
    X = np.column_stack([np.ones_like(xa), xa, xb])
    W = np.diag(f); b = np.linalg.solve(X.T @ W @ X, X.T @ W @ g)
    A = X @ b - mu; VA = f @ A ** 2
    # 显性：在剂量哑变量（含两位点各自杂合指示）上回归后的增量
    X2 = np.column_stack([X, (xa == 1).astype(float), (xb == 1).astype(float)])
    b2 = np.linalg.solve(X2.T @ W @ X2, X2.T @ W @ g)
    AD = X2 @ b2 - mu; VAD_total = f @ AD ** 2
    VD = VAD_total - VA; VI = VG - VAD_total
    return dict(VG=VG, VA=VA, VD=VD, VI=VI, alphaA=b[1], alphaB=b[2], mean=mu)

base = dict(pA=0.6, pB=0.3, aA=4, dA=2, aB=3, dB=-1)
res['two_locus_D0'] = two_locus(**base)
res['two_locus_D+0.1'] = two_locus(**base, D=0.1)
res['two_locus_D-0.1'] = two_locus(**base, D=-0.1)
res['two_locus_epi'] = two_locus(**base, epi=[[3, 0, 0], [0, 0, 0], [0, 0, 0]])
# 公式检验：VA = VA_A + VA_B + 4 D αA αB
for k in ['two_locus_D+0.1', 'two_locus_D-0.1']:
    r = res[k]; Dv = 0.1 if '+' in k else -0.1
    res[k]['formula_VA'] = res['pygmy_p0.6']['VA'] + res['locusB']['VA'] + 4 * Dv * res['pygmy_p0.6']['alpha'] * res['locusB']['alpha']

# ---------- 重复测定 ----------
def h2_ratio(r, n): return 1 / (r + (1 - r) / n)
res['repeatability'] = {f'r={r}': {f'n={n}': h2_ratio(r, n) for n in (2, 3, 5, 10)} for r in (0.2, 0.4, 0.6, 0.8)}

# ---------- 多效性与遗传相关 ----------
rng = np.random.default_rng(10)
L = 200; n = 20000
p = rng.uniform(0.1, 0.9, L)
G = rng.binomial(2, p, (n, L)).astype(float)
ax_ = rng.normal(0, 1, L)
shared = rng.random(L) < 0.4
ay = np.where(shared, 0.7 * ax_ + rng.normal(0, 0.7, L), rng.normal(0, 1, L))
ax_[rng.random(L) < 0.3] = 0.0
gx = G @ ax_; gy = G @ ay
Ex = rng.normal(0, gx.std() * np.sqrt(1 / 0.4 - 1), n); Ey = rng.normal(0, gy.std() * np.sqrt(1 / 0.3 - 1), n)
Ey = 0.3 * Ex / Ex.std() * Ey.std() + np.sqrt(1 - 0.09) * Ey
rA = np.corrcoef(gx, gy)[0, 1]; rE = np.corrcoef(Ex, Ey)[0, 1]
rP = np.corrcoef(gx + Ex, gy + Ey)[0, 1]
hx = np.sqrt(np.var(gx) / np.var(gx + Ex)); hy = np.sqrt(np.var(gy) / np.var(gy + Ey))
res['pleiotropy'] = dict(rA=rA, rE=rE, rP=rP, hX=hx, hY=hy, rP_formula=hx * hy * rA + np.sqrt(1 - hx ** 2) * np.sqrt(1 - hy ** 2) * rE,
                         rA_formula=float(np.sum(2 * p * (1 - p) * ax_ * ay) / np.sqrt(np.sum(2 * p * (1 - p) * ax_ ** 2) * np.sum(2 * p * (1 - p) * ay ** 2))))
json.dump(res, open(os.path.join(OUT, 'ch10_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

# ---------- 图 ----------
ps.setup()
fig, axes = plt.subplots(1, 3, figsize=(11, 3.5), sharey=False)
q = np.linspace(0, 1, 201); pp = 1 - q
for ax, (a, d, title) in zip(axes, [(1, 0, 'A  无显性（$d=0$）'), (1, 1, 'B  完全显性（$d=a$）'), (0, 1, 'C  超显性（$a=0$）')]):
    alpha = a + (q - pp) * d
    VA = 2 * pp * q * alpha ** 2; VD = (2 * pp * q * d) ** 2
    ax.plot(q, VA + VD, color=ps.NAVY, lw=2.4, label='$V_G$')
    ax.plot(q, VA, color=ps.ORANGE, lw=1.6, label='$V_A$')
    ax.plot(q, VD, color=ps.GREEN, lw=1.4, ls='--', label='$V_D$')
    ax.set_title(title, loc='left', fontweight='bold'); ax.set_xlabel('隐性（低值）等位基因频率 $q$')
axes[0].set_ylabel('方差（以 $a^2$ 或 $d^2$ 为单位）'); axes[0].legend()
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig10_1_variance_components.png')); plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
ax = axes[0]
ns = np.arange(1, 11)
for r, col in zip((0.2, 0.4, 0.6, 0.8), ps.PALETTE):
    ax.plot(ns, [h2_ratio(r, n) for n in ns], 'o-', ms=3.5, color=col, label=f'$r={r}$')
ax.set_xlabel('重复测定次数 $n$'); ax.set_ylabel(r'$H^2_{(n)}/H^2=1/[r+(1-r)/n]$')
ps.panel_title(ax, 'A', '重复测定对遗传决定程度的提高'); ax.legend()
ax = axes[1]
idx = rng.choice(n, 2500, replace=False)
ax.scatter(gx[idx] / gx.std(), gy[idx] / gy.std(), s=3, color=ps.NAVY, alpha=0.5)
ax.set_xlabel('性状 X 的标准化育种值'); ax.set_ylabel('性状 Y 的标准化育种值')
ps.panel_title(ax, 'B', f'多效性产生的遗传相关（$r_A$={rA:.2f}）')
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig10_2_repeatability_correlation.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
