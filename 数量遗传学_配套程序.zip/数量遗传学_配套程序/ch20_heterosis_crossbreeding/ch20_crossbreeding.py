"""第20章 杂种优势、配合力与杂交育种体系：单杂交杂种优势 dy^2、F2 保留、
轮回杂交与合成系的杂种优势保持率、Dickerson 模型、双列杂交的 GCA/SCA 估计、
配合力方差随近交系数的变化。

运行：python ch20_crossbreeding.py
"""
import json, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
DATA = os.path.join(HERE, 'data'); os.makedirs(DATA, exist_ok=True)
rng = np.random.default_rng(20)
res = {}

# 1. 单位点杂种优势：H = d y^2
def cross_means(p1, p2, a, d):
    q1, q2 = 1 - p1, 1 - p2
    M1 = a * (p1 - q1) + 2 * d * p1 * q1; M2 = a * (p2 - q2) + 2 * d * p2 * q2
    F1 = a * (p1 * p2 - q1 * q2) + d * (p1 * q2 + q1 * p2)
    pbar = (p1 + p2) / 2; F2 = a * (2 * pbar - 1) + 2 * d * pbar * (1 - pbar)
    return M1, M2, F1, F2
M1, M2, F1, F2 = cross_means(0.9, 0.3, 2.0, 1.5)
res['single_locus'] = dict(P1=M1, P2=M2, F1=F1, F2=F2, H_F1=F1 - (M1 + M2) / 2, dy2=1.5 * 0.6 ** 2, H_F2=F2 - (M1 + M2) / 2)

# 2. 轮回杂交与合成系的杂种优势保持（相对于 F1 杂种优势）
def rotation(nbreeds, T=12):
    # 母本的品种组成向量，后代 = 0.5 * 父本(纯种 k) + 0.5 * 母本组成
    comp = np.zeros(nbreeds); comp[0] = 1.0  # 起始母本为品种 1
    het = []
    for t in range(T):
        sire = np.zeros(nbreeds); sire[(t + 1) % nbreeds] = 1.0
        h = 1 - np.sum(sire * comp)          # 个体杂种优势 = 1 - sum(p_sire_i * p_dam_i)
        het.append(h); comp = 0.5 * sire + 0.5 * comp
    return np.array(het)
rot = {n: rotation(n) for n in (2, 3, 4)}
res['rotation'] = {f'{n}品种': dict(gen=rot[n].tolist(), equilibrium_theory=(2 ** n - 2) / (2 ** n - 1)) for n in (2, 3, 4)}
res['composite'] = {f'{n}品种等比例': 1 - n * (1 / n) ** 2 for n in (2, 3, 4, 6, 8)}

# 3. Dickerson 模型示例：终端杂交 vs 轮回杂交（单位：相对母系纯种）
# 参数：直接加性 gI (品种 A=0, B=+2, C=+6), 母体加性 gM (A=+3, B=+1, C=-2),
#       个体杂种优势 hI=+4, 母体杂种优势 hM=+6, 重组损失 r=-1
gI = {'A': 0, 'B': 2, 'C': 6}; gM = {'A': 3, 'B': 1, 'C': -2}; hI, hM, rI = 4.0, 6.0, -1.0
def perf(sire, dam_comp, dam_het, dam_rec=0.0):
    # 后代组成
    off = {k: 0.5 * (1.0 if k == sire else 0.0) + 0.5 * dam_comp.get(k, 0.0) for k in gI}
    het = 1 - sum((1.0 if k == sire else 0.0) * dam_comp.get(k, 0.0) for k in gI)
    rec_off = 0.5 * dam_het  # 近似：后代重组损失系数取母本杂合配子比例
    return sum(off[k] * gI[k] for k in gI) + sum(dam_comp.get(k, 0) * gM[k] for k in gM) + het * hI + dam_het * hM + rec_off * rI
res['dickerson'] = dict(
    pure_A=perf('A', {'A': 1}, 0), pure_C=perf('C', {'C': 1}, 0),
    F1_CxA=perf('C', {'A': 1}, 0),
    three_way_C_x_AB=perf('C', {'A': 0.5, 'B': 0.5}, 1.0),
    params=dict(gI=gI, gM=gM, hI=hI, hM=hM, rI=rI))

# 4. 双列杂交（6 个自交系，无反交，无自交），估计 GCA/SCA
n = 6
gca_true = rng.normal(0, 2, n); gca_true -= gca_true.mean()
X = np.full((n, n), np.nan); rows = []
for i in range(n):
    for j in range(i + 1, n):
        sca = rng.normal(0, 1.2); y = 100 + gca_true[i] + gca_true[j] + sca + rng.normal(0, 0.8)
        X[i, j] = X[j, i] = y; rows.append((i + 1, j + 1, round(y, 2)))
np.savetxt(os.path.join(DATA, 'diallel_6lines.csv'), np.array(rows), fmt=['%d', '%d', '%.2f'], delimiter=',', header='line_i,line_j,yield', comments='')
Y = np.nan_to_num(X); tot = np.nansum(X) / 2; Ti = np.nansum(X, axis=1)
gca_hat = (Ti - 2 * tot / n) / (n - 2)          # Griffing 方法4
mu = 2 * tot / (n * (n - 1))
sca_hat = np.full((n, n), np.nan)
for i in range(n):
    for j in range(n):
        if i != j: sca_hat[i, j] = X[i, j] - mu - gca_hat[i] - gca_hat[j]
res['diallel'] = dict(gca_true=gca_true.tolist(), gca_hat=gca_hat.tolist(), mean=mu,
                      best_cross_obs=[int(x) + 1 for x in np.unravel_index(np.nanargmax(X), X.shape)],
                      best_cross_by_gca=[int(x) + 1 for x in np.argsort(gca_hat)[-2:][::-1]],
                      corr_gca=float(np.corrcoef(gca_true, gca_hat)[0, 1]))

# 5. 配合力方差随 F（仅 VA 与 VD 两项）
F = np.linspace(0, 1, 101); VA, VD, VAA = 1.0, 0.4, 0.2
res['combining_variance_F1'] = dict(GCA=0.5 * VA + 0.25 * VAA, SCA=0.5 * VAA + VD)
json.dump(res, open(os.path.join(OUT, 'ch20_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 3.9))
ax = axes[0]
for (k, v), col in zip(rot.items(), ps.PALETTE):
    ax.plot(np.arange(1, len(v) + 1), v * 100, 'o-', ms=3.5, color=col, label=f'{k} 品种轮回（平衡 {100*(2**k-2)/(2**k-1):.1f}%）')
for k, ls in [(3, ':'), (4, '--')]:
    ax.axhline(100 * (1 - 1 / k), color=ps.GREY, ls=ls, lw=1, label=f'{k} 品种等比例合成系（{100*(1-1/k):.0f}%）')
ax.set_xlabel('杂交世代'); ax.set_ylabel('个体杂种优势保持率（% F$_1$）'); ax.set_ylim(40, 105)
ps.panel_title(ax, 'A', '轮回杂交与合成系的杂种优势'); ax.legend(fontsize=7.5)
ax = axes[1]
ax.plot(F, 0.5 * F * VA + 0.25 * F ** 2 * VAA, color=ps.NAVY, lw=2, label=r'$\sigma^2_{GCA}=\frac{1}{2}FV_A+\frac{1}{4}F^2V_{AA}$')
ax.plot(F, 0.5 * F ** 2 * VAA + F ** 2 * VD, color=ps.ORANGE, lw=2, label=r'$\sigma^2_{SCA}=\frac{1}{2}F^2V_{AA}+F^2V_D$')
ax.set_xlabel('亲本系的近交系数 $F$'); ax.set_ylabel('方差（$V_A=1$，$V_D=0.4$，$V_{AA}=0.2$）')
ps.panel_title(ax, 'B', '配合力方差随近交程度的变化'); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig20_1_rotation_combining.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
