"""《数量遗传学——从孟德尔群体到基因组育种》第2章 推导与算例数值复核

复核内容：目标误差与预测变化方差、遗漏变量下的风险增量、岭收缩风险、加权组均值与对比方差、二阶系统系数与杠杆。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch02_derivation_checks.py
输出：results/ch02_derivation_checks.json
"""
from fractions import Fraction as F
from pathlib import Path
import json
import math

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch02_derivation_checks.json'
results = []


def check(name, actual, expected, tol=1e-10):
    assert math.isclose(float(actual), float(expected), rel_tol=tol, abs_tol=tol), (name, actual, expected)
    results.append({'name': name, 'actual': float(actual), 'expected': float(expected), 'passed': True})


check('2.18 second target error', 10000*.0001, 1)
check('2.18 prediction change variance', .0001*1**2, .0001)
check('2.19 baseline explained variance', .5*2+.5*.5, 1.25)
check('2.19 original optimum risk', 2-1.25, .75)
b1,b2=F(5,12),F(5,8)
check('2.19 risk increase', 4*(b1-F(1,2))**2+(b2-F(1,2))**2, F(25,576))
check('2.19 full risk', 2-2*(2*b1+F(1,2)*b2)+4*b1*b1+b2*b2, F(3,4)+F(25,576))
check('2.20 ideal strong direction risk', (1-.9)**2*9+.9**2, .9)
check('2.20 ideal weak direction risk', (1-.1)**2+.1**2*9, .9)
check('2.20 ridge total risk', .5**2*9+.5**2+(1-.1)**2+.1**2*9, 3.4)
check('2.21 weighted group mean', (4+6/4)/(1+1/4), 4.4)
check('2.21 contrast variance', (4/5)**2+4*(1/5)**2+1, 1.8)
check('2.21 equal-weight contrast variance', 1/4+4/4+1, 2.25)
check('2.22 first coefficient', 2+.5/2.5, 2.2)
check('2.22 second coefficient', 1/2.5, .4)
check('2.22 sum variance', .4+.6-2*.2, .6)
check('2.22 difference variance', .4+.6+2*.2, 1.4)
check('2.22 determinant', 3*2-1, 5)
check('2.22 leverage', .4+.6-2*.2, .6)

OUT_FILE.write_text(json.dumps({'chapter': 2, 'checks': results, 'count': len(results), 'all_passed': True},
                               ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第2章：共 {len(results)} 项复核全部通过')
