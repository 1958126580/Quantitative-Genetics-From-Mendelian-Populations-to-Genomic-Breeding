"""第13章 遗传参数的经典估计方法与试验设计。

数据：data/nested_design.csv（40 头公畜 × 5 头母畜 × 6 个后代，含双亲表型）
分析：亲子回归、套式方差分析、REML（平衡套式模型）、标准误、最优设计、
      北卡罗来纳设计 II 模拟、两性状协方差分析估计遗传相关。
运行：python ch13_estimation.py
"""
import json, os, sys
import numpy as np
from scipy import stats, optimize

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
DATA = os.path.join(HERE, 'data')
res = {}
D = np.genfromtxt(os.path.join(DATA, 'nested_design.csv'), delimiter=',', names=True)
sire, Ps, dam, Pd, mid, prog, Po = (D[k] for k in D.dtype.names)
n = len(Po)

def reg(x, y):
    X = np.column_stack([np.ones_like(x), x]); b = np.linalg.lstsq(X, y, rcond=None)[0]
    r = y - X @ b; s2 = r @ r / (len(y) - 2); se = np.sqrt(s2 * np.linalg.inv(X.T @ X)[1, 1])
    return b[1], se

b_s, se_s = reg(Ps, Po)
us = np.unique(sire); pm = np.array([Po[sire == s].mean() for s in us]); psv = np.array([Ps[sire == s][0] for s in us])
b_sm, se_sm = reg(psv, pm)
b_d, se_d = reg(Pd, Po)
b_mid, se_mid = reg(mid, Po)
# 正确的标准误：同一公畜的后代非独立 -> 以公畜为单位的回归（b_sm）才是合适的
res['regression'] = dict(
    offspring_on_sire=dict(b=b_s, se_naive=se_s, h2=2 * b_s, se_h2_naive=2 * se_s),
    sire_progeny_mean_on_sire=dict(b=b_sm, se=se_sm, h2=2 * b_sm, se_h2=2 * se_sm),
    offspring_on_dam=dict(b=b_d, se_naive=se_d, h2=2 * b_d, se_h2_naive=2 * se_d),
    offspring_on_midparent=dict(b=b_mid, se_naive=se_mid, h2=b_mid, se_h2_naive=se_mid),
    var_sire_pheno=float(np.var(psv, ddof=1)), var_prog=float(np.var(Po, ddof=1)))

# 套式方差分析
s_, d_, k_ = 40, 5, 6
Y = np.zeros((s_, d_, k_))
for i, s in enumerate(us):
    dams = np.unique(dam[sire == s])
    for j, dd in enumerate(dams):
        Y[i, j] = Po[(sire == s) & (dam == dd)]
gm = Y.mean(); ms_ = Y.mean((1, 2)); md_ = Y.mean(2)
SSS = d_ * k_ * np.sum((ms_ - gm) ** 2); SSD = k_ * np.sum((md_ - ms_[:, None]) ** 2); SSW = np.sum((Y - md_[:, :, None]) ** 2)
dfS, dfD, dfW = s_ - 1, s_ * (d_ - 1), s_ * d_ * (k_ - 1)
MSS, MSD, MSW = SSS / dfS, SSD / dfD, SSW / dfW
sS = (MSS - MSD) / (d_ * k_); sD = (MSD - MSW) / k_; sW = MSW; VP = sS + sD + sW
# 方差组分的近似抽样方差（平衡资料）：Var(MS) = 2 E(MS)^2/(df+2)
vS = 2 / (d_ * k_) ** 2 * (MSS ** 2 / (dfS + 2) + MSD ** 2 / (dfD + 2))
vD = 2 / k_ ** 2 * (MSD ** 2 / (dfD + 2) + MSW ** 2 / (dfW + 2))
res['anova'] = dict(MSS=MSS, MSD=MSD, MSW=MSW, df=[dfS, dfD, dfW], F_sire=MSS / MSD, p_sire=stats.f.sf(MSS / MSD, dfS, dfD),
                    F_dam=MSD / MSW, p_dam=stats.f.sf(MSD / MSW, dfD, dfW),
                    sigma2_S=sS, sigma2_D=sD, sigma2_W=sW, VP=VP,
                    h2_sire=4 * sS / VP, se_h2_sire=4 * np.sqrt(vS) / VP,
                    h2_dam=4 * sD / VP, se_h2_dam=4 * np.sqrt(vD) / VP,
                    h2_sire_dam=2 * (sS + sD) / VP, tHS=sS / VP, tFS=(sS + sD) / VP,
                    VD_plus_4VEc_over_VP=4 * (sD - sS) / VP)

# REML（平衡套式模型，参数 sS,sD,sW）
def neg_reml(theta):
    a, b, c = np.exp(theta)
    l1 = c + k_ * b + d_ * k_ * a; l2 = c + k_ * b; l3 = c
    return 0.5 * (dfS * np.log(l1) + SSS / l1 + dfD * np.log(l2) + SSD / l2 + dfW * np.log(l3) + SSW / l3)
opt = optimize.minimize(neg_reml, np.log([max(sS, 1), max(sD, 1), sW]), method='Nelder-Mead', options=dict(xatol=1e-10, fatol=1e-10, maxiter=5000))
rS, rD, rW = np.exp(opt.x)
res['reml'] = dict(sigma2_S=rS, sigma2_D=rD, sigma2_W=rW, h2_sire=4 * rS / (rS + rD + rW))

# 最优家系大小：半同胞，总记录 T 固定
def se_h2_hs(h2, n, T):
    t = h2 / 4; s = T / n
    return 4 * np.sqrt(2 * (1 - t) ** 2 * (1 + (n - 1) * t) ** 2 / (n * (n - 1) * (s - 1)))
ns_ = np.arange(2, 301)
opt_n = {}
for h2 in (0.1, 0.25, 0.5):
    se = se_h2_hs(h2, ns_, 2000); opt_n[str(h2)] = dict(n_opt=int(ns_[np.argmin(se)]), se_min=float(se.min()), approx_1_over_t=4 / h2)
res['optimal_halfsib_T2000'] = opt_n
def se_po(h2, N, k=1):  # 子代对单亲（k=1）或中亲（k=2）回归，每家系一个后代
    varb = (1 - (h2 / 2 if k == 1 else h2) ** 2 * (1 if k == 1 else 0.5)) / (N * (1 if k == 1 else 0.5))
    return (2 if k == 1 else 1) * np.sqrt(varb)
res['se_parent_offspring_N1000'] = dict(single=se_po(0.3, 1000, 1), mid=se_po(0.3, 1000, 2))

# 北卡罗来纳设计 II 模拟：VA=40, VD=16, VEc=8, VEw=36
rng = np.random.default_rng(13)
VA, VD, VEc, VEw = 40.0, 16.0, 8.0, 36.0
s2, d2, k2 = 30, 30, 4
reps = []
for r in range(200):
    S = rng.normal(0, np.sqrt(VA / 4), s2); Dm = rng.normal(0, np.sqrt(VA / 4 + VEc), d2)
    I = rng.normal(0, np.sqrt(VD / 4), (s2, d2))
    E = rng.normal(0, np.sqrt(VEw + VA / 2 + 3 * VD / 4), (s2, d2, k2))
    Yc = S[:, None, None] + Dm[None, :, None] + I[:, :, None] + E
    g = Yc.mean(); mS = Yc.mean((1, 2)); mD = Yc.mean((0, 2)); mI = Yc.mean(2)
    MSs = d2 * k2 * np.sum((mS - g) ** 2) / (s2 - 1); MSd = s2 * k2 * np.sum((mD - g) ** 2) / (d2 - 1)
    MSi = k2 * np.sum((mI - mS[:, None] - mD[None, :] + g) ** 2) / ((s2 - 1) * (d2 - 1))
    MSe = np.sum((Yc - mI[:, :, None]) ** 2) / (s2 * d2 * (k2 - 1))
    vs = (MSs - MSi) / (d2 * k2); vd = (MSd - MSi) / (s2 * k2); vi = (MSi - MSe) / k2
    reps.append([4 * vs, 4 * vi, vd - vs, MSe - 2 * vs - 3 * vi])
reps = np.array(reps)
res['nc2'] = dict(true=[VA, VD, VEc, VEw], mean=reps.mean(0).tolist(), sd=reps.std(0).tolist())

# 两性状半同胞协方差分析：遗传相关
rA, rE, h1, h2_ = 0.5, -0.2, 0.3, 0.2
s3, k3 = 200, 20
C_A = np.array([[h1, rA * np.sqrt(h1 * h2_)], [rA * np.sqrt(h1 * h2_), h2_]])
C_E = np.array([[1 - h1, rE * np.sqrt((1 - h1) * (1 - h2_))], [rE * np.sqrt((1 - h1) * (1 - h2_)), 1 - h2_]])
ests = []
for r in range(300):
    As = rng.multivariate_normal([0, 0], C_A, s3)
    W = rng.multivariate_normal([0, 0], 0.75 * C_A + C_E, (s3, k3))
    Y2 = 0.5 * As[:, None, :] + W
    m = Y2.mean(1); gmn = Y2.mean((0, 1))
    MPS = k3 * (m - gmn).T @ (m - gmn) / (s3 - 1)
    R = (Y2 - m[:, None, :]).reshape(-1, 2); MPW = R.T @ R / (s3 * (k3 - 1))
    Ssire = (MPS - MPW) / k3
    ests.append([4 * Ssire[0, 0], 4 * Ssire[1, 1], Ssire[0, 1] / np.sqrt(abs(Ssire[0, 0] * Ssire[1, 1])) if Ssire[0, 0] > 0 and Ssire[1, 1] > 0 else np.nan])
ests = np.array(ests)
robertson = (1 - rA ** 2) / np.sqrt(2) * np.sqrt(np.nanstd(ests[:, 0]) * np.nanstd(ests[:, 1]) / (h1 * h2_))
res['genetic_correlation'] = dict(true_rA=rA, mean_rA=float(np.nanmean(ests[:, 2])), sd_rA=float(np.nanstd(ests[:, 2])),
                                  robertson_se=float(robertson), mean_h2=[float(ests[:, 0].mean()), float(ests[:, 1].mean())])
json.dump(res, open(os.path.join(OUT, 'ch13_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

# 图
ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 3.9))
ax = axes[0]
ax.scatter(psv, pm, s=14, color=ps.NAVY)
xx = np.linspace(psv.min(), psv.max(), 10); ax.plot(xx, pm.mean() + b_sm * (xx - psv.mean()), color=ps.ORANGE, lw=1.8)
ax.set_xlabel('公畜表型'); ax.set_ylabel('公畜 30 个后代的平均表型')
ps.panel_title(ax, 'A', f'后代均值对公畜表型的回归（$b$={b_sm:.3f}）')
ax = axes[1]
for h2, col in zip((0.1, 0.25, 0.5), ps.PALETTE):
    se = se_h2_hs(h2, ns_, 2000); ax.plot(ns_, se, color=col, lw=1.8, label=f'$h^2$={h2}')
    ax.plot(opt_n[str(h2)]['n_opt'], opt_n[str(h2)]['se_min'], 'o', color=col)
ax.set_ylim(0, 0.6); ax.set_xscale('log')
ax.set_xlabel('每头公畜的后代数 $n$（总记录 2000）'); ax.set_ylabel(r'$\mathrm{SE}(\hat h^2)$')
ps.panel_title(ax, 'B', '半同胞设计的最优家系大小'); ax.legend()
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig13_1_regression_design.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
