"""Shared figure style for the book's figures."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

NAVY = '#1f4e79'
ORANGE = '#c8602a'
GOLD = '#a8834a'
GREY = '#6b7785'
GREEN = '#3c7a5a'
LIGHT = '#dfe6ee'
PALETTE = [NAVY, ORANGE, GREEN, GOLD, GREY, '#7a4e8a']


def setup():
    plt.rcParams.update({
        'font.family': ['Noto Sans CJK SC', 'DejaVu Sans'],
        'mathtext.fontset': 'stix',
        'axes.unicode_minus': False,
        'font.size': 10.5,
        'axes.titlesize': 11.5,
        'axes.labelsize': 10.5,
        'axes.spines.top': False,
        'axes.spines.right': False,
        'axes.edgecolor': '#333333',
        'axes.linewidth': 0.8,
        'xtick.direction': 'out',
        'ytick.direction': 'out',
        'legend.frameon': False,
        'legend.fontsize': 9,
        'figure.dpi': 110,
        'savefig.dpi': 300,
        'savefig.bbox': 'tight',
        'axes.prop_cycle': matplotlib.cycler(color=PALETTE),
    })


def panel_title(ax, letter, text):
    ax.set_title(f'{letter}  {text}', loc='left', fontweight='bold')
