"""《数量遗传学——从孟德尔群体到基因组育种》第31章 推导与算例数值复核

复核内容：测量误差回归与重复可靠性、条件组学增量 PEV、中介与工具变量、LD 联合后验、混合先验与核不可识别。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch31_derivation_checks.py
输出：results/ch31_derivation_checks.json
"""
from pathlib import Path
import json
import math
import numpy as np

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch31_derivation_checks.json'
checks = []


def verify(name, actual, expected, atol=1e-10, method="direct independent calculation"):
    a = np.asarray(actual, dtype=float)
    e = np.asarray(expected, dtype=float)
    ok = bool(np.allclose(a, e, atol=atol, rtol=0))
    checks.append(dict(name=name, actual=a.tolist(), expected=e.tolist(),
                       tolerance=atol, passed=ok, method=method))
    if not ok:
        raise AssertionError(f"{name}: {a} != {e}")


verify("31_classical_slope", .8*4/(4+5), .3556, 5e-5)
verify("31_latent_mean", 4/9*3, 4/3)
verify("31_y_predict", .8*4/9*3, 1.0667, 5e-5)
verify("31_y_conditional_var", 1+.8**2*4*5/9, 2.4222, 5e-5)
verify("31_correlated_replicate_reliability", 4/(4+2+3/2), .5333, 5e-5)
verify("31_independent_replicate_reliability", 4/(4+5/2), .6154, 5e-5)
S=np.array([[4,1.2,1],[1.2,1,1.1],[1,1.1,2]])
assert np.linalg.eigvalsh(S).min()>0
res_var=2-1.1**2
res_cov=1-1.2*1.1
verify("31_conditional_omics_variance",res_var,.79)
verify("31_conditional_target_covariance",res_cov,-.32)
verify("31_incremental_coefficient",res_cov/res_var,-.4051,5e-5)
increment=res_cov**2/res_var
verify("31_incremental_PEV_gain",increment,.1296,5e-5)
verify("31_full_model_PEV",4-np.array([1.2,1])@np.linalg.solve(S[1:,1:],np.array([1.2,1])),2.4304,5e-5)
verify("31_noisy_incremental_PEV_gain",res_cov**2/(res_var+.5),.07938,5e-6)
# Derive naive mediation directly from observed covariance normal equations.
alpha=.5; theta=.8; direct=.2; ve=1.; vd=3.
varw=alpha**2+ve+vd
covgy=direct+theta*alpha
covwy=alpha*covgy+theta*ve
coef=np.linalg.solve(np.array([[1,alpha],[alpha,varw]]),[covgy,covwy])
verify("31_mediator_adjusted_genetic_coefficient",coef[0],.5)
verify("31_mediator_noisy_coefficient",coef[1],.2)
verify("31_total_effect",covgy,.6)
verify("31_invalid_instrument_ratio",covgy/alpha,1.2)
verify("31_valid_instrument_full_exclusion",(.8*.3)/.3,.8,
       method="instrument correlated with mediator, orthogonal to direct genetic path and outcome error")
Gamma=np.array([[.3,.1],[.6,.2]])
verify("31_multivariable_instrument_rank",np.linalg.matrix_rank(Gamma),1)
verify("31_instrument_null_direction",Gamma@np.array([1,-3]),[0,0])
precision=np.array([[14,8],[8,11.]])
postcov=np.linalg.inv(precision)
verify("31_LD_joint_posterior_mean",np.linalg.solve(precision,[4,2]),[28/90,-4/90])
verify("31_LD_joint_posterior_covariance",postcov,np.array([[11,-8],[-8,14]])/90)
B=math.sqrt(.04/.20)*math.exp(.6**2/2*(1/.04-1/.20))
p=.1*B/(.9+.1*B)
verify("31_mixture_Bayes_factor",B,16.367,5e-4)
verify("31_mixture_class_probability",p,.6452,5e-5)
verify("31_mixture_mean",p*.48,.3097,5e-5)
verify("31_mixture_variance",p*(.032+.48**2)-(p*.48)**2,.07339,5e-6)
K=np.array([[1,.5],[.5,1]])
verify("31_unidentified_kernel_equivalence",.6*K+.2*(2*K),.8*K+.1*(2*K))


report = dict(status="passed", chapter=31, verified_date="2026-10-01", checks_count=len(checks), checks=checks,
              scope="Independent computations for specified teaching examples; no manuscript, Pandoc, or empirical-data dependency.")
OUT_FILE.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第31章：共 {len(checks)} 项复核全部通过')
