"""《数量遗传学——从孟德尔群体到基因组育种》第26章 推导与算例数值复核

复核内容：测量误差与离散后验矩、频率依赖缩放、预测扰动、测量设计增益。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch26_derivation_checks.py
输出：results/ch26_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np
from numpy.testing import assert_allclose as eq

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch26_derivation_checks.json'
results = {}


def save(name, value):
    if isinstance(value, np.ndarray): value = value.tolist()
    results[name] = value


# 第26章：independent discrete joint distribution, measurement moments and contrasts
omega=.09*np.eye(2)+.04*np.ones((2,2));w=np.array([-.5,.5]);G=np.outer(w,w)
eq(G+omega,[[.38,-.21],[-.21,.38]])
eq(np.array([1,-1])@omega@np.array([1,-1]),.18)
eq(np.ones(2)@omega@np.ones(2),.34)
states=np.array([[-1,0],[-1,1],[0,0],[0,1]])
pr=np.array([.24,.16,.16,.44]);mean=pr@states
cov=(states-mean).T@np.diag(pr)@(states-mean)
eq(mean,[-.4,.6]);eq(cov,[[.24,.08],[.08,.24]])
eq(states.T@np.diag(pr)@states,[[.4,-.16],[-.16,.6]])
save("26.16_measurement_and_discrete_posterior",{"mean":mean.tolist(),"covariance":cov.tolist()})
def gc(p):return .5/(2*p*(1-p))
eq(gc(.25),4/3);eq(gc(.3),1.190476190476)
derivative=(gc(.25+1e-6)-gc(.25-1e-6))/(2e-6)
eq(derivative,-3.55555555556,rtol=1e-8)
save("26.17_frequency",{"exact":gc(.3),"linear":gc(.25)-3.55555555556*.05})
K=np.diag([2.,.1]);lam=.5;y=np.ones(2)
pred=lambda k:k@np.linalg.solve(k+lam*np.eye(2),y)
d1=pred(K+np.diag([.05,0]))-pred(K);d2=pred(K+np.diag([0,.05]))-pred(K)
eq(d1[0],.00392156862745098);eq(d2[1],.0641025641025641)
E=np.array([[.03,.01],[.01,.02]])
B=lambda k:k@np.linalg.inv(k+lam*np.eye(2))
eq(B(K+E)-B(K),lam*np.linalg.inv(K+E+lam*np.eye(2))@E@np.linalg.inv(K+lam*np.eye(2)))
save("26.18_prediction_perturbation",{"first":d1.tolist(),"second":d2.tolist()})
eq(np.linalg.eigvalsh(.8*np.eye(2)-.45*np.ones((2,2))),[-.1,.8])
eq(np.linalg.eigvalsh(.8*np.eye(2)-.3*np.ones((2,2))),[.2,.8])
V=np.array([[.36,.12],[.12,.25]]);c=np.array([1,-1])
gains=np.array([(c@V[:,j])**2/(V[j,j]+.04) for j in range(2)])
eq(gains,[.144,.0582758620689655]);eq(c@V@c,.37)
save("26.20_measurement_design",{"gains":gains.tolist(),"posterior_contrast_variances":(.37-gains).tolist()})


n_checks = len(results)
results["status"] = "passed"
results["scope"] = "Independent synthetic mathematical checks only; no empirical animal data or document dependencies."
OUT_FILE.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第26章：共 {n_checks} 项复核全部通过')
