"""《数量遗传学——从孟德尔群体到基因组育种》第30章 推导与算例数值复核

复核内容：基因型状态均值方差、稀有变异斜率标准误、面板覆盖、多后代风险后验与检测信息价值。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch30_derivation_checks.py
输出：results/ch30_derivation_checks.json
"""
from pathlib import Path
import json
import math
import numpy as np

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch30_derivation_checks.json'
checks = []


def verify(name, actual, expected, atol=1e-10, method="direct independent calculation"):
    a = np.asarray(actual, dtype=float)
    e = np.asarray(expected, dtype=float)
    ok = bool(np.allclose(a, e, atol=atol, rtol=0))
    checks.append(dict(name=name, actual=a.tolist(), expected=e.tolist(),
                       tolerance=atol, passed=ok, method=method))
    if not ok:
        raise AssertionError(f"{name}: {a} != {e}")


g = np.arange(3)
for label, q, desired_var in [
        ("甲", np.array([.5, 0, .5]), 1),
        ("乙", np.array([0, 1, 0]), 0)]:
    d = q @ g
    v = q @ (g-d)**2
    verify(f"30_genotype_mean_{label}", d, 1)
    verify(f"30_genotype_var_{label}", v, desired_var)
    verify(f"30_y_var_{label}", 3+4*v, 7 if label=="甲" else 3)
verify("30_local_information_fraction", (.32-.08)/.32, .75)
n = math.ceil(math.log(.05)/(2*math.log(.999)))
verify("30_discovery_minimum_n", n, 1498)
assert 1-.999**(2*n) >= .95 and 1-.999**(2*(n-1)) < .95
for N, se in [(100, 1.2632), (1000, 1.2284)]:
    x = np.r_[np.ones(6), np.zeros(N-6)]
    verify(f"30_rare_slope_se_n{N}", math.sqrt(9/np.sum((x-x.mean())**2)), se, 5e-5)
verify("30_opposite_burden_covariance", np.array([1,1]) @ np.diag([.02,.02]) @ np.array([1,-1]), 0)
verify("30_opposite_true_variance", np.array([1,-1]) @ np.diag([.02,.02]) @ np.array([1,-1]), .04)
J = np.eye(2)-np.ones((2,2))/2
verify("30_centered_uncertainty", J @ (.4*np.eye(2)) @ J,
       [[.2,-.2],[-.2,.2]])
fixed_reference_states = np.array([[-1,-1],[-1,1],[1,-1],[1,1]])*math.sqrt(.4)
verify("30_fixed_posterior_mean_reference_covariance",
       fixed_reference_states.T@fixed_reference_states/4, .4*np.eye(2),
       method="enumeration with a fixed posterior-mean reference")
# Enumerate genotype states; conditional allele-effect moments are exact.
z = np.array([-.5,.5,1.5]); q = np.array([.1,.8,.1])
mean_u = np.sum(q*z*2)
var_u = np.sum(q*z*z*(.25+2**2))-mean_u**2
verify("30_product_mean", mean_u, 1)
verify("30_product_variance", var_u, .9125)
coverage = [1-.99**k for k in (100,200)]
verify("30_panel_100", coverage[0], .6340, 5e-5)
verify("30_panel_200", coverage[1], .8660, 5e-5)
verify("30_panel_increment", coverage[1]-coverage[0], .2321, 5e-5)
verify("30_panel_candidate_A", np.dot([.1,.8],[.9,.1]), .17)
verify("30_panel_candidate_B", np.dot([.1,.8],[.2,.6]), .50)
joint = .8*.5
verify("30_single_offspring_risk", joint/4, .1)
# Enumerate shared parent state before independent Mendelian transmissions.
verify("30_four_offspring_correct_risk", joint*(1-.75**4), .2734375)
verify("30_four_offspring_naive_risk", 1-.9**4, .3439)
post_joint = joint*.75**4/(1-joint+joint*.75**4)
verify("30_joint_posterior_after_four_normal", post_joint, .1742, 5e-5)
verify("30_next_offspring_risk", post_joint/4, .04355, 5e-5)
pi=.2; se=.9; sp=.95
pt=pi*se+(1-pi)*(1-sp)
pos=pi*se/pt
neg=pi*(1-se)/(1-pt)
loss=lambda p:min((1-p)*2,p*20)
verify("30_test_positive_probability", pt, .22)
verify("30_test_positive_posterior", pos, .8182, 5e-5)
verify("30_test_negative_posterior", neg, .02564, 5e-5)
verify("30_test_posterior_expected_loss", pt*loss(pos)+(1-pt)*loss(neg), .48)
verify("30_gross_value_of_information", loss(pi)-.48, 1.12)


report = dict(status="passed", chapter=30, verified_date="2026-10-01", checks_count=len(checks), checks=checks,
              scope="Independent computations for specified teaching examples; no manuscript, Pandoc, or empirical-data dependency.")
OUT_FILE.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第30章：共 {len(checks)} 项复核全部通过')
