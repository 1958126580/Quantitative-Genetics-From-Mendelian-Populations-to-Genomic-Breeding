"""《数量遗传学——从孟德尔群体到基因组育种》第28章 推导与算例数值复核

复核内容：一步法传播协方差、APY 的 KL 散度、核心群迹增益、对偶残差与误差来源分解、真实 MSE 正交恒等式。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch28_derivation_checks.py
输出：results/ch28_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np
from numpy.testing import assert_allclose as eq

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch28_derivation_checks.json'
results = {}


def save(name, value):
    if isinstance(value, np.ndarray): value = value.tolist()
    results[name] = value


# 第28章：propagation, conditional information, core gains and dual residuals
B0=np.array([[-1/3,2/3]]);LG=np.vstack([B0,np.eye(2)]);v0=np.array([1.,-1.])
DH=LG@(.04*np.outer(v0,v0))@LG.T
eq(DH,.04*np.outer([-1.,1.,-1.],[-1.,1.,-1.]))
eq(np.array([1,0,-1])@DH@np.array([1,0,-1]),0,atol=1e-15)
eq(np.array([1,-1,0])@DH@np.array([1,-1,0]),.16)
save("28.16_propagation",DH)
C=np.array([[1.,.6],[.6,1.]])
kl=-.5*np.linalg.slogdet(C)[1];eq(kl,.2231435513142097)
eq(np.linalg.eigvalsh(C),[.4,1.6]);eq(np.linalg.eigvalsh(np.linalg.inv(C)),[.625,2.5])
save("28.17_APY_KL",{"KL":kl,"covariance_eigenvalues":np.linalg.eigvalsh(C).tolist()})
S=np.array([[1.,.8,0],[.8,1,0],[0,0,.9]])
tg=np.array([S[:,j]@S[:,j]/S[j,j] for j in range(3)])
eq(tg,[1.64,1.64,.9])
updated=S-np.outer(S[:,0],S[0,:])/S[0,0];eq(updated[1,1],.36)
save("28.18_core",{"trace_gains":tg.tolist(),"updated":updated.tolist()})
L=np.array([[4.,1.],[1.,3.]]);d=np.array([1.,2.]);th=np.linalg.solve(L,d);thk=np.array([.09,.63]);r=d-L@thk;c=np.array([1.,-1.])
dual=np.linalg.solve(L,c);ztilde=np.array([.36,-.45]);s=c-L@ztilde
eq(th,[1/11,7/11]);eq(r,[.01,.02]);eq(dual,[4/11,-5/11])
eq(c@(th-thk),dual@r);eq(c@(th-thk),ztilde@r+s@np.linalg.solve(L,r))
save("28.19_dual",{"target_error":float(dual@r),"approx_dual_term":float(ztilde@r),"remainder":float(s@np.linalg.solve(L,r))})
# Distinguish propagation in the original system from pure error sources.
Lt=L+np.array([[.2,.04],[.04,.3]]);E=Lt-L;tstar=np.linalg.solve(Lt,d)
rtilde=d-Lt@thk
eq(th-thk,np.linalg.solve(L,rtilde)+np.linalg.solve(L,E@thk))
eq(th-thk,np.linalg.solve(L,E@tstar)+np.linalg.solve(Lt,rtilde))
eq(.5-1/2.2,.0454545454545455)
eq((1-2.2*.5)/2.2,-.0454545454545455)
save("28.20_error_sources",{"original_residual_scalar":-.05,"original_perturbation_scalar":.05,
     "pure_model_scalar":.5-1/2.2,"pure_numerical_scalar":(1-2.2*.5)/2.2})
eq((1-1/3)**2+(1/3)**2,5/9)
# true MSE orthogonality identity for nontrivial matrices
K=np.array([[1.,.2],[.2,1.5]]);R=np.diag([.7,1.2]);V=K+R
M0=K@np.linalg.inv(V);M=M0+np.array([[.02,-.03],[.04,.01]])
mse=lambda MM:K-MM@K-K@MM.T+MM@V@MM.T
eq(mse(M),mse(M0)+(M-M0)@V@(M-M0).T)
save("28.20_true_MSE",{"scalar_wrong_model":5/9,"scalar_internal":1/3})


n_checks = len(results)
results["status"] = "passed"
results["scope"] = "Independent synthetic mathematical checks only; no empirical animal data or document dependencies."
OUT_FILE.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第28章：共 {n_checks} 项复核全部通过')
