"""《数量遗传学——从孟德尔群体到基因组育种》第1章 推导与算例数值复核

复核内容：条件期望作为平方损失最优预测、条件方差分解、加权与绝对损失下的最优预测及域迁移风险。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch01_derivation_checks.py
输出：results/ch01_derivation_checks.json
"""
from fractions import Fraction as F
from pathlib import Path
import json
import math

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch01_derivation_checks.json'
results = []


def check(name, actual, expected, tol=1e-10):
    assert math.isclose(float(actual), float(expected), rel_tol=tol, abs_tol=tol), (name, actual, expected)
    results.append({'name': name, 'actual': float(actual), 'expected': float(expected), 'passed': True})


u = [-2, 0, 2, 4]
m = [-1, -1, 3, 3]
g = [0, 0, 2, 2]
check('1.16 mean', sum(u)/4, 1)
check('1.16 variance', sum((x-1)**2 for x in u)/4, 5)
check('1.16 optimum risk', sum((x-z)**2 for x,z in zip(u,m))/4, 1)
check('1.16 alternative risk', sum((x-z)**2 for x,z in zip(u,g))/4, 2)
check('1.17 prior variance', .5*0+.25*4+.25*4, 2)
check('1.17 average conditional variance', .5*0+.5*4, 2)
check('1.18 quadratic basis variance', F(1,5)-F(1,9), F(4,45))
check('1.18 linear risk', F(1,10)+F(4,45), F(17,90))
check('1.18 square posterior mean', 1**2+2, 3)
check('1.18 square posterior variance', 2*2**2+4*1**2*2, 16)
check('1.19 weighted optimum', (F(1,2)*1*0+F(1,2)*3*2)/(F(1,2)*1+F(1,2)*3), F(3,2))
check('1.19 weighted risk at mean', .5*1*(0-1)**2+.5*3*(2-1)**2, 2)
check('1.19 weighted optimum risk', .5*1*(0-1.5)**2+.5*3*(2-1.5)**2, 1.5)
check('1.19 absolute loss median', .9*0+.1*10, 1)
check('1.19 absolute loss mean', .9*1+.1*9, 1.8)
check('1.20 old domain risk', 4+.25, F(17,4))

OUT_FILE.write_text(json.dumps({'chapter': 1, 'checks': results, 'count': len(results), 'all_passed': True},
                               ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第1章：共 {len(results)} 项复核全部通过')
