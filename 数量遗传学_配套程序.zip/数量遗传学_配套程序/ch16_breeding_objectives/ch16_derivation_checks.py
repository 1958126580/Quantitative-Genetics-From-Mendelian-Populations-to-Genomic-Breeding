"""《数量遗传学——从孟德尔群体到基因组育种》第16章 推导与算例数值复核

复核内容：隐式经济权重的数值导数、生命周期报酬值与导数、管理效应及响应雅可比矩阵。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch16_derivation_checks.py
输出：results/ch16_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch16_derivation_checks.json'
results = {}


def close(a, b):
    assert np.allclose(a, b, rtol=1e-7, atol=1e-8), (a, b)


# 第16章：implicit economic derivatives, management, lifetime rewards.
Qprod,sv,W,c0,cw,price=10000.,.8,50.,100.,3.,10.
profit=lambda surv,weight:Qprod*price-Qprod*c0/(surv*weight)-Qprod*cw
asurv=Qprod*c0/(sv*sv*W);aweight=Qprod*c0/(sv*W*W)
close([asurv,aweight],[31250,500])
eps=1e-5
close((profit(sv+eps,W)-profit(sv-eps,W))/(2*eps),asurv)
close((profit(sv,W+eps)-profit(sv,W-eps))/(2*eps),aweight)
T=np.array([[0.,.8],[0.,.6]]);rewards=np.array([100.,140.]);delta=.95
val=np.linalg.solve(np.eye(2)-delta*T,rewards)
as_=delta*140/(1-delta*.6)
aq=delta**2*.8*140/(1-delta*.6)**2
B=np.diag([4.,1.]);a=np.ones(2);at=np.array([1.,-1.])
best=np.sqrt(a@B@a);wrong=a@B@at/np.sqrt(at@B@at)
jac=B/best-np.outer(B@a,B@a)/best**3
close(jac,np.array([[4.,-4.],[-4.,4.]])/(5*np.sqrt(5)))
results['16']={'fixed_demand_profit':profit(sv,W),'weights':[asurv,aweight],
'finite_survival_gain':profit(.81,W)-profit(.8,W),
'finite_output_gain':profit(.8,51)-profit(.8,50),
'management_delta_fixed':5.,'management_delta_optimized':5.25,
'lifetime_values':val.tolist(),'lifetime_derivatives':[as_,aq],
'reward_effective_weight':.95*.8/(1-.95*.6),
'joint_price_expression_weight':.5*(10*2+30*1),
'value_variance':3**2*1+2**2*4+4*1,
'response_best_wrong_loss':[best,wrong,best-wrong],
'response_jacobian':jac.tolist(),'status':'PASS'}

OUT_FILE.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
assert all(v['status'] == 'PASS' for v in results.values())
print(f'第16章：共 {len(results)} 项复核全部通过')
