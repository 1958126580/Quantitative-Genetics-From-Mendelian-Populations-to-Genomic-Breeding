"""第19章 遗传漂变、有效群体大小与近交：理想群体近交增长、有效群体大小公式、
规则近交体系、近交衰退、遗传方差在系内与系间的再分配、家系选择与共选。

运行：python ch19_inbreeding.py
"""
import json, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(19)
res = {}

# 1. 有效群体大小
Ne_sex = lambda m, f: 4 * m * f / (m + f)
res['Ne_sex'] = {f'{m}m{f}f': Ne_sex(m, f) for m, f in [(1, 100), (5, 100), (10, 100), (20, 100), (50, 50), (10, 1000)]}
sizes = [50, 100, 200, 400, 500]
res['Ne_harmonic'] = dict(sizes=sizes, arithmetic=float(np.mean(sizes)), harmonic=float(len(sizes) / np.sum(1 / np.array(sizes))))
res['Ne_family'] = {f'Vk={v}': 4 * 100 / (v + 2) for v in (0, 2, 4, 10)}

# 2. 规则近交体系（路径系数递推）
def regular(system, T=20):
    F = [0.0, 0.0]
    for t in range(T):
        if system == 'selfing':
            F.append(0.5 * (1 + F[-1]))
        elif system == 'fullsib':
            F.append(0.25 * (1 + 2 * F[-1] + F[-2]))
        elif system == 'halfsib':
            F.append(0.125 * (1 + 6 * F[-1] + F[-2]))
    return np.array(F[1:])
reg = {s: regular(s) for s in ('selfing', 'fullsib', 'halfsib')}
res['regular'] = {s: dict(F5=float(v[5]), F10=float(v[10]), dF_asym=float((v[-1] - v[-2]) / (1 - v[-2]))) for s, v in reg.items()}

# 3. 近交衰退与系内/系间方差再分配（多系模拟）
L = 300; nlines = 2000; N = 10; T = 30
p0 = rng.uniform(0.05, 0.95, L)
a = rng.normal(0, 1, L); d = np.abs(rng.normal(0.4, 0.4, L)) * np.abs(a)   # 方向性显性
VA0 = np.sum(2 * p0 * (1 - p0) * (a + d * (1 - 2 * p0)) ** 2)
M0 = np.sum(a * (2 * p0 - 1) + 2 * p0 * (1 - p0) * d)
P = np.tile(p0, (nlines, 1))
Fs, means, within, between = [], [], [], []
for t in range(T + 1):
    Ft = 1 - (1 - 1 / (2 * N)) ** t
    het = 2 * P * (1 - P)
    line_mean = np.sum(a * (2 * P - 1) + het * d, axis=1)      # 系内随机交配
    Va_w = np.sum(2 * P * (1 - P) * (a + d * (1 - 2 * P)) ** 2, axis=1)
    Fs.append(Ft); means.append(line_mean.mean()); within.append(Va_w.mean()); between.append(line_mean.var())
    P = rng.binomial(2 * N, P) / (2 * N)
Fs = np.array(Fs); means = np.array(means)
# 近交个体（系内近交程度 F）的均值理论：M0 - 2F sum(dpq)
dep_theory = M0 - 2 * Fs * np.sum(d * p0 * (1 - p0))
res['lines'] = dict(VA0=VA0, M0=M0, slope_per_F_theory=float(-2 * np.sum(d * p0 * (1 - p0))),
                    F_at_10=float(Fs[10]), within_VA_ratio_10=float(within[10] / VA0), between_ratio_10=float(between[10] / VA0))
# 注：系内随机交配的均值 = 群体在频率 P 下的均值；其平均随 F 线性下降（无上位）
coef = np.polyfit(Fs, means, 1)
res['lines']['slope_per_F_sim'] = float(coef[0])

# 4. 无显性时的方差再分配验证
a2 = rng.normal(0, 1, L); P = np.tile(p0, (nlines, 1)); Wd, Bd = [], []
for t in range(T + 1):
    Wd.append(np.mean(np.sum(2 * P * (1 - P) * a2 ** 2, axis=1)))
    Bd.append(np.var(np.sum(a2 * (2 * P - 1), axis=1)))
    P = rng.binomial(2 * N, P) / (2 * N)
VG0 = np.sum(2 * p0 * (1 - p0) * a2 ** 2)
res['redistribution_additive'] = dict(F10=float(Fs[10]), within_ratio=float(Wd[10] / VG0), within_theory=float(1 - Fs[10]),
                                      between_ratio=float(Bd[10] / VG0), between_theory=float(2 * Fs[10]))

# 5. 清除（purging）：致死隐性在近交下的频率变化
def purge(q0, s, h, F_rate, T=40):
    q = q0; out = [q]; F = 0
    for t in range(T):
        F = F + F_rate * (1 - F)
        p = 1 - q
        f_aa = q * q + F * p * q; f_Aa = 2 * p * q * (1 - F); f_AA = p * p + F * p * q
        w = f_AA + f_Aa * (1 - h * s) + f_aa * (1 - s)
        q = (f_Aa * (1 - h * s) * 0.5 + f_aa * (1 - s)) / w; out.append(q)
    return np.array(out)
res['purging'] = dict(q_random=float(purge(0.05, 1, 0.02, 0.0)[-1]), q_inbred=float(purge(0.05, 1, 0.02, 0.05)[-1]))
json.dump(res, open(os.path.join(OUT, 'ch19_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 3.9))
ax = axes[0]
labs = {'selfing': '自交', 'fullsib': '全同胞交配', 'halfsib': '半同胞交配'}
for (s, v), col in zip(reg.items(), ps.PALETTE):
    ax.plot(np.arange(len(v)), v, 'o-', ms=3, color=col, label=labs[s])
tt = np.arange(21)
for Ne_, ls in [(10, '--'), (50, ':')]:
    ax.plot(tt, 1 - (1 - 1 / (2 * Ne_)) ** tt, ls=ls, color=ps.GREY, label=f'随机交配 $N_e={Ne_}$')
ax.set_xlabel('世代'); ax.set_ylabel('近交系数 $F$')
ps.panel_title(ax, 'A', '规则近交体系与有限群体'); ax.legend(fontsize=8)
ax = axes[1]
ax.plot(Fs, np.array(within) / VA0, 'o-', ms=3, color=ps.NAVY, label='系内加性方差 / $V_{A0}$')
ax.plot(Fs, np.array(between) / VA0, 's-', ms=3, color=ps.ORANGE, label='系间方差 / $V_{A0}$')
ax.plot(Fs, 1 - Fs, '--', color=ps.NAVY, lw=1, label='$1-F$（无显性理论）')
ax.plot(Fs, 2 * Fs, '--', color=ps.ORANGE, lw=1, label='$2F$（无显性理论）')
ax.set_xlabel('近交系数 $F$'); ax.set_ylabel('相对方差')
ps.panel_title(ax, 'B', '近交使遗传方差在系内与系间再分配'); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig19_1_inbreeding.png')); plt.close(fig)

fig, ax = plt.subplots(figsize=(6.2, 3.6))
ax.plot(Fs, means - M0, 'o', color=ps.NAVY, ms=4, label='2000 个近交系的平均（模拟）')
ax.plot(Fs, dep_theory - M0, color=ps.ORANGE, lw=1.8, label=r'理论：$-2F\sum d_kp_kq_k$')
ax.set_xlabel('近交系数 $F$'); ax.set_ylabel('相对于基础群体的均值变化')
ax.set_title('方向性显性造成的线性近交衰退', fontsize=10.5); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig19_2_depression.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
