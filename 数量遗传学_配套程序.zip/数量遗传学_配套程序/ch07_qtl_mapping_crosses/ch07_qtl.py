"""第7章 杂交群体的 QTL 定位：单标记分析、Haley–Knott 回归区间作图、
最大似然区间作图（EM）、置换阈值、复合区间作图、幽灵 QTL 与 Beavis 效应。

运行：python ch07_qtl.py
"""
import json, os, sys
import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import plotstyle as ps
import matplotlib.pyplot as plt

OUT = os.path.join(HERE, 'results'); os.makedirs(OUT, exist_ok=True)
DATA = os.path.join(HERE, 'data'); os.makedirs(DATA, exist_ok=True)
rng = np.random.default_rng(2015)
res = {}
hc = lambda d: 0.5 * (1 - np.exp(-2 * d))   # Haldane, d in Morgan

# ---------------- F2 模拟 ----------------
def sim_f2(n, markers_cM, qtls, sd_e, rng):
    """qtls: list of (pos_cM, a, d). 返回标记基因型(0/1/2 = 亲本2等位基因数... 这里为亲本1等位基因数)和表型"""
    allpos = np.array(sorted(set(list(markers_cM) + [q[0] for q in qtls])))
    def gamete():
        g = np.zeros((n, len(allpos)), int)
        g[:, 0] = rng.integers(0, 2, n)
        for j in range(1, len(allpos)):
            rec = rng.random(n) < hc((allpos[j] - allpos[j - 1]) / 100)
            g[:, j] = np.where(rec, 1 - g[:, j - 1], g[:, j - 1])
        return g
    G = gamete() + gamete()
    y = rng.normal(0, sd_e, n)
    for pos, a, d in qtls:
        k = np.where(allpos == pos)[0][0]
        y += np.where(G[:, k] == 2, a, np.where(G[:, k] == 1, d, -a))
    midx = [np.where(allpos == m)[0][0] for m in markers_cM]
    return G[:, midx], y

def qtl_probs_f2(M, markers_cM, pos):
    """在位置 pos 处由侧翼标记计算 QQ, Qq, qq 的条件概率（Haldane，无干涉，完全信息标记）"""
    mk = np.array(markers_cM)
    if pos <= mk[0]: L = R = 0
    else:
        L = np.max(np.where(mk <= pos)[0]); R = min(L + 1, len(mk) - 1)
    if pos >= mk[-1]: L = R = len(mk) - 1
    # 每个配子：QTL 等位基因来自亲本1的条件概率，给定侧翼标记配子类型
    # F2 基因型 -> 两个配子组合；对双杂合标记需对相位平均
    n = M.shape[0]
    P = np.zeros((n, 3))
    c1 = hc(abs(pos - mk[L]) / 100); c2 = hc(abs(mk[R] - pos) / 100); th = hc(abs(mk[R] - mk[L]) / 100)
    # 单配子：标记等位基因 (mL, mR) ∈ {0,1}^2，QTL=1 的概率
    def pq(mL, mR):
        if L == R:
            return np.where(mL == 1, 1 - c1, c1)
        num1 = np.where(mL == 1, 1 - c1, c1) * np.where(mR == 1, 1 - c2, c2)
        num0 = np.where(mL == 0, 1 - c1, c1) * np.where(mR == 0, 1 - c2, c2)
        return num1 / (num1 + num0)
    gL, gR = M[:, L], M[:, R]
    table = np.zeros((3, 3, 3))
    for x in range(3):
        for z in range(3):
            opts = []
            for a1 in range(2):
                for b1 in range(2):
                    a2, b2 = x - a1, z - b1
                    if a2 in (0, 1) and b2 in (0, 1):
                        w1 = 0.5 * ((1 - th) if a1 == b1 else th) if L != R else 0.5
                        w2 = 0.5 * ((1 - th) if a2 == b2 else th) if L != R else 0.5
                        opts.append((w1 * w2, a1, b1, a2, b2))
            tot = sum(o[0] for o in opts)
            for w, a1, b1, a2, b2 in opts:
                p1 = float(pq(np.array(a1), np.array(b1))); p2 = float(pq(np.array(a2), np.array(b2)))
                table[x, z] += w / tot * np.array([p1 * p2, p1 * (1 - p2) + (1 - p1) * p2, (1 - p1) * (1 - p2)])
    P = table[gL, gR]
    return P

def hk_scan(M, y, markers_cM, grid, cof=None):
    n = len(y); F = []; LOD = []; est = []
    X0 = np.ones((n, 1)) if cof is None else np.column_stack([np.ones(n), cof])
    rss0 = np.sum((y - X0 @ np.linalg.lstsq(X0, y, rcond=None)[0]) ** 2)
    for pos in grid:
        P = qtl_probs_f2(M, markers_cM, pos)
        X = np.column_stack([X0, P[:, 0] - P[:, 2], P[:, 1]])
        b = np.linalg.lstsq(X, y, rcond=None)[0]
        rss = np.sum((y - X @ b) ** 2)
        df1, df2 = 2, n - X.shape[1]
        F.append(((rss0 - rss) / df1) / (rss / df2)); LOD.append(n / 2 * np.log10(rss0 / rss))
        est.append(b[-2:])
    return np.array(F), np.array(LOD), np.array(est)

# 1. 课堂设计：N=500，6 个标记 0..50 cM，QTL 在 23 cM，a=1, d=0.5, sd=2
markers = [0, 10, 20, 30, 40, 50]
grid = np.arange(0, 50.5, 1.0)
M, y = sim_f2(500, markers, [(23, 1.0, 0.5)], 2.0, rng)
np.savetxt(os.path.join(DATA, 'f2_sim_N500.csv'), np.column_stack([M, y]), fmt=['%d'] * 6 + ['%.4f'], delimiter=',',
           header='M0,M10,M20,M30,M40,M50,y', comments='')
# 单标记分析
single = []
for j, m in enumerate(markers):
    means = [y[M[:, j] == g].mean() for g in (2, 1, 0)]
    a_hat = (means[0] - means[2]) / 2; d_hat = means[1] - (means[0] + means[2]) / 2
    Fv = stats.f_oneway(*[y[M[:, j] == g] for g in (0, 1, 2)]).statistic
    single.append(dict(pos=m, mean_MM=means[0], mean_Mm=means[1], mean_mm=means[2], a_marker=a_hat, d_marker=d_hat, F=Fv,
                       expected_a=(1 - 2 * hc(abs(m - 23) / 100)) * 1.0, expected_d=(1 - 2 * hc(abs(m - 23) / 100)) ** 2 * 0.5))
res['single_marker'] = single
F, LOD, est = hk_scan(M, y, markers, grid)
kbest = int(np.argmax(LOD))
res['hk'] = dict(best_pos=float(grid[kbest]), maxLOD=float(LOD[kbest]), maxF=float(F[kbest]), a_hat=float(est[kbest, 0]),
                 d_hat=float(est[kbest, 1]), var_explained_true=(0.5 * 1 ** 2 + 0.25 * 0.5 ** 2) / (0.5 + 0.0625 + 4))
# LOD-1 支持区间
inside = grid[LOD >= LOD[kbest] - 1]
res['hk']['lod1_interval'] = [float(inside.min()), float(inside.max())]

# 2. 置换阈值（染色体水平）
perm_max = []
for b in range(300):
    yp = rng.permutation(y)
    _, Lp, _ = hk_scan(M, yp, markers, grid[::2])
    perm_max.append(Lp.max())
res['permutation'] = dict(B=300, thr95=float(np.percentile(perm_max, 95)), thr99=float(np.percentile(perm_max, 99)),
                          pointwise_LOD_005=float(stats.chi2.ppf(0.95, 2) / (2 * np.log(10))))

# 3. 最大似然区间作图（EM），在最佳位置
def ml_em(y, P, it=500):
    mu = np.array([y.mean() + 1, y.mean(), y.mean() - 1]); s2 = y.var(); pri = P
    for _ in range(it):
        dens = np.exp(-0.5 * (y[:, None] - mu[None, :]) ** 2 / s2) / np.sqrt(2 * np.pi * s2)
        W = pri * dens; ll = np.sum(np.log(W.sum(1))); W /= W.sum(1, keepdims=True)
        mu = (W * y[:, None]).sum(0) / W.sum(0)
        s2 = np.sum(W * (y[:, None] - mu[None, :]) ** 2) / len(y)
    return mu, s2, ll
P = qtl_probs_f2(M, markers, grid[kbest])
mu, s2, ll1 = ml_em(y, P)
ll0 = np.sum(stats.norm.logpdf(y, y.mean(), y.std()))
res['ml'] = dict(pos=float(grid[kbest]), mu_QQ=mu[0], mu_Qq=mu[1], mu_qq=mu[2], a=(mu[0] - mu[2]) / 2,
                 d=mu[1] - (mu[0] + mu[2]) / 2, sigma=np.sqrt(s2), LOD=(ll1 - ll0) / np.log(10))

# 4. 十次重复的定位精度
reps = []
for r in range(10):
    Mr, yr = sim_f2(500, markers, [(23, 1.0, 0.5)], 2.0, rng)
    Fr, Lr, er = hk_scan(Mr, yr, markers, grid)
    k = int(np.argmax(Lr)); reps.append([grid[k], er[k, 0], er[k, 1], Lr[k]])
reps = np.array(reps)
res['replicates'] = dict(table=reps.tolist(), mean=reps.mean(0).tolist(), sd=reps.std(0, ddof=1).tolist())
res['darvasi_soller_CI_cM'] = {'F2_N500_a0.5sd': 3000 / (2 * 500 * 0.5 ** 2), 'BC_N500_a0.5sd': 3000 / (1 * 500 * 0.5 ** 2)}

# 5. 两个连锁 QTL：幽灵 QTL 与复合区间作图
markers2 = list(range(0, 101, 10)); grid2 = np.arange(0, 100.5, 1.0)
M2, y2 = sim_f2(600, markers2, [(25, 0.6, 0.0), (65, 0.6, 0.0)], 1.5, rng)
F1, L1, _ = hk_scan(M2, y2, markers2, grid2)
# CIM：前向逐步回归选择标记协变量，检验位置 ±10 cM 窗口内的协变量被剔除
Xm = M2 - 1.0; chosen = []
for step in range(3):
    best = None
    for k in range(len(markers2)):
        if k in chosen: continue
        X = np.column_stack([np.ones(len(y2))] + [Xm[:, c] for c in chosen + [k]])
        rss = np.sum((y2 - X @ np.linalg.lstsq(X, y2, rcond=None)[0]) ** 2)
        if best is None or rss < best[0]: best = (rss, k)
    X0 = np.column_stack([np.ones(len(y2))] + [Xm[:, c] for c in chosen])
    rss0 = np.sum((y2 - X0 @ np.linalg.lstsq(X0, y2, rcond=None)[0]) ** 2)
    Fst = (rss0 - best[0]) / (best[0] / (len(y2) - len(chosen) - 2))
    if Fst < 10: break
    chosen.append(best[1])
cof_markers = [markers2[c] for c in chosen]
Lcim = []
for pos in grid2:
    cols = [Xm[:, c] for c in chosen if abs(markers2[c] - pos) > 10]
    cof = np.column_stack(cols) if cols else None
    _, Lc, _ = hk_scan(M2, y2, markers2, [pos], cof=cof)
    Lcim.append(Lc[0])
Lcim = np.array(Lcim)
# 排斥相（反向）情形
M3, y3 = sim_f2(600, markers2, [(25, 0.6, 0.0), (65, -0.6, 0.0)], 1.5, rng)
F3, L3, _ = hk_scan(M3, y3, markers2, grid2)
res['two_qtl'] = dict(cofactors=cof_markers, CIM_peak=float(grid2[np.argmax(Lcim)]), IM_peak=float(grid2[np.argmax(L1)]), IM_max=float(L1.max()), CIM_peaks_LOD_at25=float(Lcim[25]),
                      CIM_LOD_at65=float(Lcim[65]), CIM_LOD_at45=float(Lcim[45]), IM_LOD_at45=float(L1[45]),
                      repulsion_IM_max=float(L3.max()))

# 6. Beavis 效应
beav = []
for N in [100, 200, 500, 1000]:
    a_true = 0.25  # 回交中 a+d 效应，sd_e=1
    hits = []
    for r in range(2000):
        g = rng.integers(0, 2, N); yy = a_true * g + rng.normal(0, 1, N)
        t = stats.ttest_ind(yy[g == 1], yy[g == 0])
        if t.pvalue < 0.001: hits.append(yy[g == 1].mean() - yy[g == 0].mean())
    beav.append(dict(N=N, power=len(hits) / 2000, mean_est_if_sig=float(np.mean(hits)) if hits else None,
                     true=a_true, var_expl_true=a_true ** 2 / 4 / (a_true ** 2 / 4 + 1)))
res['beavis'] = beav

json.dump(res, open(os.path.join(OUT, 'ch07_results.json'), 'w'), ensure_ascii=False, indent=2, default=float)

# ---------------- 图 ----------------
ps.setup()
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
ax = axes[0]
ax.plot(grid, LOD, color=ps.NAVY, lw=2, label='Haley–Knott 回归区间作图')
ax.plot(markers, [stats.f.sf(s['F'], 2, 497) for s in single], alpha=0)
sm_lod = [500 / 2 * np.log10(1 + 2 * s['F'] / 497) for s in single]
ax.plot(markers, sm_lod, 's', color=ps.ORANGE, ms=7, label='单标记分析')
ax.axhline(res['permutation']['thr95'], color=ps.GREEN, ls='--', lw=1.2, label='置换 5% 染色体阈值')
ax.axvline(23, color=ps.GREY, ls=':', lw=1); ax.text(23.5, 0.3, '真实 QTL', color=ps.GREY, fontsize=8)
ax.axvspan(*res['hk']['lod1_interval'], color=ps.LIGHT, alpha=0.6, label='LOD-1 支持区间')
for m in markers: ax.plot([m], [0], '^', color='k', ms=5)
ax.set_xlabel('染色体位置（cM）'); ax.set_ylabel('LOD')
ps.panel_title(ax, 'A', 'F$_2$ 群体的区间作图（$N=500$）'); ax.legend(fontsize=7.5, loc='upper right')
ax = axes[1]
ax.plot(grid2, L1, color=ps.NAVY, lw=1.8, label='区间作图（两 QTL 同相）')
ax.plot(grid2, Lcim, color=ps.ORANGE, lw=1.8, label='复合区间作图')
ax.plot(grid2, L3, color=ps.GREY, lw=1.2, ls='--', label='区间作图（两 QTL 反相）')
for q in (25, 65): ax.axvline(q, color=ps.GREEN, ls=':', lw=1)
for m in markers2: ax.plot([m], [0], '^', color='k', ms=4)
ax.set_xlabel('染色体位置（cM）'); ax.set_ylabel('LOD')
ps.panel_title(ax, 'B', '连锁 QTL：幽灵峰与复合区间作图'); ax.legend(fontsize=7.5)
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig07_1_interval_mapping.png')); plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
ax = axes[0]
ax.hist(perm_max, bins=30, color=ps.LIGHT, edgecolor=ps.NAVY, lw=0.6)
ax.axvline(res['permutation']['thr95'], color=ps.ORANGE, lw=1.5, label='95% 分位数')
ax.axvline(res['permutation']['pointwise_LOD_005'], color=ps.GREEN, ls='--', lw=1.3, label='逐点 5% 界限')
ax.set_xlabel('置换资料中全染色体最大 LOD'); ax.set_ylabel('频数')
ps.panel_title(ax, 'A', '置换检验确定显著阈值'); ax.legend(fontsize=8)
ax = axes[1]
Ns = [b['N'] for b in beav]
ax.plot(Ns, [b['power'] for b in beav], 'o-', color=ps.NAVY, label='检测功效')
ax2 = ax.twinx(); ax2.spines['right'].set_visible(True)
ax2.plot(Ns, [b['mean_est_if_sig'] / b['true'] for b in beav], 's--', color=ps.ORANGE, label='显著结果的效应估计/真值')
ax2.axhline(1, color=ps.GREY, lw=0.8)
ax.set_xlabel('回交后代数 $N$'); ax.set_ylabel('功效'); ax2.set_ylabel('高估倍数')
ps.panel_title(ax, 'B', 'Beavis 效应：低功效下效应被高估')
h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels(); ax.legend(h1 + h2, l1 + l2, fontsize=8, loc='center right')
fig.tight_layout(); fig.savefig(os.path.join(OUT, 'fig07_2_permutation_beavis.png')); plt.close(fig)
print(json.dumps(res, ensure_ascii=False, indent=1, default=float))
