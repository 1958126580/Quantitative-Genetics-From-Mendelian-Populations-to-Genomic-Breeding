"""《数量遗传学——从孟德尔群体到基因组育种》第18章 推导与算例数值复核

复核内容：繁殖值与稳定增益、扩散滞后与贴现冲击、内生 Bulmer 递推平衡、祖先贡献与共祖分解、时间对齐近交率。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch18_derivation_checks.py
输出：results/ch18_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch18_derivation_checks.json'
results = {}


def close(a, b):
    assert np.allclose(a, b, rtol=1e-7, atol=1e-8), (a, b)


# 第18章：reproductive values, diffusion, endogenous Bulmer recursion and ancestry.
M18=np.array([[.25,.75],[1.,0.]])
pi18=np.array([4/7,3/7])
close(pi18@M18,pi18);close(pi18.sum(),1);close(pi18[0]*1.4,.8)
xx=np.zeros(2); newborn=[]
for _ in range(6):
    xx=M18@xx+np.array([1.4,0.]);newborn.append(float(xx[0]))
close(newborn,[1.4,1.75,2.8875,3.434375,4.42421875,5.0818359375])
T18=np.array([[.5,0.],[.25,.75]]);q18=np.array([.5,0.])
lag18=np.linalg.solve(np.eye(2)-T18,np.ones(2));close(lag18,[2,6])
delta=.95;v18=np.array([0.,1.])
imp18=float(delta*v18@np.linalg.solve(np.eye(2)-delta*T18,q18))
direct18=sum(delta**t*(v18@np.linalg.matrix_power(T18,t-1)@q18) for t in range(1,1000))
close(imp18,direct18)
# Check linear-trend solution exactly at an arbitrary date.
g18=.7;t18=100
close(T18@(g18*t18*np.ones(2)-g18*lag18)+q18*g18*t18,g18*(t18+1)*np.ones(2)-g18*lag18)
V18=100.;vars18=[]
for _ in range(5):
    V18=.5*(V18-.8*V18**2/(V18+100))+50;vars18.append(V18)
eq18=100/np.sqrt(1.8)
close(eq18,.5*(eq18-.8*eq18**2/(eq18+100))+50)
close(vars18[:2],[80,75.77777777777778])
cov18=np.eye(2)-.4*np.outer([.6,.3],[.6,.3])
close(cov18,[[.856,-.072],[-.072,.964]])
close(np.linalg.eigvalsh(cov18),[.82,1])
Q18=np.array([[.5,.5,0,0],[.5,0,.5,0],[0,0,.5,.5]])
c18=np.array([.6,.3,.1]);r18=Q18.T@c18
close(r18,[.45,.3,.2,.05]);close(1/(r18@r18),1/.335)
req18=Q18.T@np.ones(3)/3;close(1/(req18@req18),3.6)
# Unrelated, non-inbred founders: adding Mendelian terms restores unit diagonal.
A18=Q18@Q18.T+.5*np.eye(3)
close(np.diag(A18),np.ones(3))
founder_coanc=.5*r18@r18
new_coanc=.25*c18@c18
close(.5*c18@A18@c18,founder_coanc+new_coanc)
x18=.5+1/(4*.9*2)
objective18=lambda x:1+x+.9*2*2*x*(1-x)
close(1+.9*2*2*(1-2*x18),0)
assert objective18(x18)>objective18(0) and objective18(x18)>objective18(1)
rates18=[1-.9**.1,1-.9**.2,1-.9**.5]
close(1-(1-rates18[0])**10,.1);close(1-(1-rates18[1])**5,.1)
close(1-(1-rates18[2])**2,.1)
results['18']={'reproductive_values':pi18.tolist(),'stable_annual_gain':pi18[0]*1.4,
'newborn_trajectory':newborn,'diffusion_lags':lag18.tolist(),'discounted_impulse':imp18,
'discounted_step':imp18/(1-delta),'Bulmer_trajectory':vars18,'Bulmer_equilibrium':eq18,
'equilibrium_accuracy_squared':eq18/(eq18+100),'response_per_i':[100/np.sqrt(200),eq18/np.sqrt(eq18+100)],
'next_covariance':cov18.tolist(),'next_genetic_correlation':cov18[0,1]/np.sqrt(cov18[0,0]*cov18[1,1]),
'ancestral_shares':r18.tolist(),'contribution_count':1/(r18@r18),
'coancestry_decomposition':[founder_coanc,new_coanc,.5*c18@A18@c18],
'dynamic_proxy_optimum':x18,'dynamic_proxy_value':objective18(x18),
'near_term_value':1+x18,'diversity_proxy':2*x18*(1-x18),'time_aligned_inbreeding_rates':rates18,'status':'PASS'}

OUT_FILE.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
assert all(v['status'] == 'PASS' for v in results.values())
print(f'第18章：共 {len(results)} 项复核全部通过')
