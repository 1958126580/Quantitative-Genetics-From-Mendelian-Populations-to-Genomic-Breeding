"""《数量遗传学——从孟德尔群体到基因组育种》第21章 推导与算例数值复核

复核内容：GLS 均值与混合目标权重、完整误差协方差块、序贯新息与批量等价、典范特征值、非线性 MMSE 与稳健最优。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch21_derivation_checks.py
输出：results/ch21_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np
from scipy.integrate import quad
from scipy.optimize import minimize_scalar
from scipy.stats import norm

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch21_derivation_checks.json'
records = []


def check(name, actual, expected, atol=1e-9, rtol=1e-8):
    a, b = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
    error = float(np.max(np.abs(a - b)))
    passed = bool(np.allclose(a, b, atol=atol, rtol=rtol))
    records.append({"name": name, "passed": passed,
                    "actual": a.tolist(), "expected": b.tolist(),
                    "max_absolute_error": error})
    if not passed:
        raise AssertionError(records[-1])


def residual_precision(V, X):
    W = np.linalg.inv(V)
    B = np.linalg.inv(X.T @ W @ X)
    Q = W - W @ X @ B @ X.T @ W
    return W, B, Q


# 第21章：unified target and complete error covariance.
Sigma = np.diag([1., 4.])
V = Sigma + np.eye(2)
X = np.ones((2, 1))
W, B, Q = residual_precision(V, X)
y = np.array([2., 4.])
beta = (B @ X.T @ W @ y).item()
uhat = Sigma @ Q @ y
C = Sigma - Sigma @ Q @ Sigma
cross = -B @ X.T @ W @ Sigma
check("21.18 GLS mean", beta, 18 / 7)
check("21.18 mixed target", beta + uhat[0], 16 / 7)
c = np.array([1., 0.])
d = 1 - (X.T @ W @ c).item()
a = W @ c + (W @ X @ B).ravel() * d
check("21.18 target weights", a, [6 / 7, 1 / 7])
check("21.18 direct target MSE", 1 + a @ V @ a - 2 * a @ c, 6 / 7)
check("21.18 decomposed target MSE", 1 - c @ W @ c + d * d * B.item(), 6 / 7)
Xrank = np.array([[1, 1, 0], [1, 0, 1.]])
check("21.18 null direction", Xrank @ np.array([1, -1, -1]), [0, 0])
check("21.19 random PEV block", C, np.array([[6, 4], [4, 12]]) / 7)
check("21.19 cross error block", cross, [[-5 / 7, -8 / 7]])
full_error = np.block([[B, cross], [cross.T, C]])
for j in range(2):
    target = np.zeros(3)
    target[0] = target[1 + j] = 1
    check(f"21.19 latent individual {j+1} MSE", target @ full_error @ target, 6 / 7)
Vseq = np.array([[16., 4.], [4., 5.]])
cseq = np.array([4., 4.])
check("21.20 batch equals innovation mean",
      cseq @ np.linalg.solve(Vseq, [4., 3.]), 2.5)
check("21.20 batch equals innovation PEV",
      4 - cseq @ np.linalg.solve(Vseq, cseq), .75)
D = np.diag([.5, 1]) @ np.array([[1, .3], [.3, .5]]) @ np.diag([.5, 1])
evals, evecs = np.linalg.eigh(D)
check("21.21 canonical eigenvalues", evals, [.179743758, .570256242], atol=1e-9)
mixture = lambda v: .5 * (norm.pdf(v - 1) + norm.pdf(v + 1))
mmse = quad(lambda v: (1 - np.tanh(v) ** 2) * mixture(v), -12, 12,
            epsabs=1e-12)[0]
linear_mse = quad(lambda v: .5 * ((1 - .5 * v) ** 2 * norm.pdf(v - 1)
                                 + (-1 - .5 * v) ** 2 * norm.pdf(v + 1)),
                  -12, 12)[0]
check("21.22 nonlinear integrated MMSE", mmse, .4495995092066934)
check("21.22 linear integrated MSE", linear_mse, .5)
check("21.22 conditional posterior at y=1", np.tanh(1), .7615941559557649)
robust = lambda b: 2 + 8 * b * b - 4 * b
res = minimize_scalar(robust, bounds=(-1, 1), method="bounded")
check("21.23 robust optimum", res.x, .25, atol=1e-7)
check("21.23 robust risk reduction", [robust(.5), robust(.25)], [2, 1.5])


result = {"status": "passed", "chapter": 21, "check_count": len(records), "checks": records,
          "conditions": "Synthetic teaching experiments; no empirical animal validation claimed."}
OUT_FILE.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第21章：共 {len(records)} 项复核全部通过')
