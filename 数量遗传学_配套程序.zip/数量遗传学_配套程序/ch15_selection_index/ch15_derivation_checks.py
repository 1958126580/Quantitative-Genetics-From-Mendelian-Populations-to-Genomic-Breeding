"""《数量遗传学——从孟德尔群体到基因组育种》第15章 推导与算例数值复核

复核内容：分块选择指数权重与增益、连续/整数设计 PEV、样本信息期望价值（EVSI）与条件数风险。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch15_derivation_checks.py
输出：results/ch15_derivation_checks.json
"""
from pathlib import Path
import json
import math
import numpy as np
from scipy.stats import norm

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch15_derivation_checks.json'
results = {}


def close(a, b):
    assert np.allclose(a, b, rtol=1e-7, atol=1e-8), (a, b)


P=np.array([[4.]]);C=np.array([2.]);Q=np.array([[1.,2.]])
S=np.array([[2.,1.],[1.,3.]]);d=np.array([1.,2.]);R=S+Q.T@np.linalg.solve(P,Q);D=d+Q.T@np.linalg.solve(P,C)
Pall=np.block([[P,Q],[Q.T,R]]);Call=np.r_[C,D];b=np.linalg.solve(Pall,Call)
close(b,[.15,.2,.6]);close(b@Call,2.4);close(b@np.array([2.,1.,3.]),2.3)
assert np.linalg.eigvalsh(np.block([[Pall,Call[:,None]],[Call[None,:],np.array([[6.]])]])).min()>0
close(d@np.linalg.solve(S,d),1.4);close(17/60+67/60,1.4)
J=np.eye(2)+.5*np.array([[1.,-1.],[-1.,1.]])
close(np.linalg.inv(J),[[.75,.25],[.25,.75]])
def evsi(m,v,s):
    t=math.sqrt(v*v/(v+s));return t*norm.pdf(m/t)+m*norm.cdf(m/t)-max(m,0)
ev=[evsi(m,4,4) for m in [0,.5,3]]
results['15']={'block_weights':b.tolist(),'block_gain':float(d@np.linalg.solve(S,d)),'block_prediction':float(b@np.array([2.,1.,3.])),'continuous_cost_design':[8/3,5/6],'continuous_pev':36/11,'integer_pev':10/3,'EVSI_m0_m05_m3':ev,'condition_risk_diff':.01**2/.02,'condition_risk_sum':.01**2/1.98,'status':'PASS'}

OUT_FILE.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
assert all(v['status'] == 'PASS' for v in results.values())
print(f'第15章：共 {len(results)} 项复核全部通过')
