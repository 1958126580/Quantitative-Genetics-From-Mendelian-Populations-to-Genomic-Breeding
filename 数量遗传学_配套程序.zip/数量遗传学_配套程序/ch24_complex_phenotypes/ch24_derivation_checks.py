"""《数量遗传学——从孟德尔群体到基因组育种》第24章 推导与算例数值复核

复核内容：阈值模型后验矩与 Laplace 近似、富集抽样校正、生存混合与条件生存、序贯 Kalman 更新与 IPCW 评分。
所有算例均为人工构造的教学示例，不依赖真实动物数据。

运行：python ch24_derivation_checks.py
输出：results/ch24_derivation_checks.json
"""
from pathlib import Path
import json
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.stats import norm

OUT = Path(__file__).resolve().parent / 'results'
OUT.mkdir(parents=True, exist_ok=True)
OUT_FILE = OUT / 'ch24_derivation_checks.json'
records = []


def check(name, actual, expected, atol=1e-9, rtol=1e-8):
    a, b = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
    error = float(np.max(np.abs(a - b)))
    passed = bool(np.allclose(a, b, atol=atol, rtol=rtol))
    records.append({"name": name, "passed": passed,
                    "actual": a.tolist(), "expected": b.tolist(),
                    "max_absolute_error": error})
    if not passed:
        raise AssertionError(records[-1])


# 第24章：threshold moments, sampling, survival and sequential prediction.
post = lambda u: 2 * norm.pdf(u) * norm.cdf(u)
mean = quad(lambda u: u * post(u), -12, 12, epsabs=1e-12)[0]
second = quad(lambda u: u * u * post(u), -12, 12, epsabs=1e-12)[0]
pred_event = quad(lambda u: norm.cdf(u) * post(u), -12, 12, epsabs=1e-12)[0]
mode = brentq(lambda u: norm.pdf(u) / norm.cdf(u) - u, 0, 2)
check("24.18 threshold posterior normalization", quad(post, -12, 12)[0], 1)
check("24.18 exact posterior moments", [mean, second - mean ** 2],
      [1 / np.sqrt(np.pi), 1 - 1 / np.pi])
check("24.18 posterior mode", mode, .5060544689891809)
check("24.18 Laplace variance", 1 / (1 + 2 * mode ** 2), .661295951085069)
check("24.18 repeated event predictive integral", pred_event, 2 / 3)
check("24.18 plug-in event probability", norm.cdf(mean), .7136874419652335)
first_step = np.sqrt(2 / np.pi) / (1 + 2 / np.pi)
check("24.18 one Newton step", first_step, .4875198102052883, atol=1e-12)
sample_q = .05 / (.05 + .1 * .95)
check("24.19 enriched sample probability", sample_q, .3448275862068966)
check("24.19 recovered risk at sample q=.5", .1 * .5 / (.5 + .1 * .5), 1 / 11)
check("24.19 Brier under wrong baseline",
      .05 * (1 - sample_q) ** 2 + .95 * sample_q ** 2, .134423305588585)
high = 1 / (1 + np.exp(-.3))
survival = (1 - high) * np.exp(-.3) + high * np.exp(-.6)
check("24.20 survivor and measurement posterior", high, .574442516811659)
check("24.20 mixed future survival", survival, .6305214749867536)
check("24.20 plug-in mean risk survival", np.exp(-(.1 + .1 * high) * 3), .6235459903194398)
entry_high = 1 / (1 + np.exp(1))
check("24.21 entry high risk weight", entry_high, .2689414213699951)
check("24.21 entry conditional survival",
      (1 - entry_high) * np.exp(-.2) + entry_high * np.exp(-.6), .7461383221013829)
check("24.21 cumulative incidence by integration",
      quad(lambda v: .1 * np.exp(-.3 * v), 0, 5)[0], .2589566132838567)
C0 = np.diag([4., 2.])
H = np.ones(2)
K1 = C0 @ H / (H @ C0 @ H + 1)
m1 = K1 * 3
C1 = C0 - np.outer(C0 @ H, C0 @ H) / 7
check("24.22 first posterior mean", m1, [12 / 7, 6 / 7])
check("24.22 first posterior covariance", C1, np.array([[12, -8], [-8, 10]]) / 7)
F = np.diag([1., .5])
mp = F @ m1
Cp = F @ C1 @ F.T + np.diag([0., 1.5])
check("24.22 predicted covariance", Cp, np.array([[12, -4], [-4, 13]]) / 7)
K2 = Cp @ H / (H @ Cp @ H + 1)
m2 = mp + K2 * (4 - H @ mp)
C2 = Cp - np.outer(Cp @ H, Cp @ H) / (H @ Cp @ H + 1)
check("24.22 second posterior mean", m2, [7 / 3, 9 / 8])
check("24.22 second posterior covariance", C2, [[4 / 3, -1], [-1, 11 / 8]])
batchV = np.array([[7., 5.], [5., 7.]])
check("24.22 batch genetic prediction", np.array([4., 4.]) @ np.linalg.solve(batchV, [3., 4.]), 7 / 3)
check("24.22 batch genetic error", 4 - np.array([4., 4.]) @ np.linalg.solve(batchV, [4., 4.]), 4 / 3)
check("24.23 IPCW teaching score", (2 * .2 ** 2 / .8 + .8 ** 2 / .9) / 4, .20277777777777778)


result = {"status": "passed", "chapter": 24, "check_count": len(records), "checks": records,
          "conditions": "Synthetic teaching experiments; no empirical animal validation claimed."}
OUT_FILE.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'第24章：共 {len(records)} 项复核全部通过')
